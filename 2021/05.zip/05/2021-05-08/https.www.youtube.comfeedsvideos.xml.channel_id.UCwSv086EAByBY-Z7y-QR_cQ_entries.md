# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Projekt Smart City Charta. Społeczeństwo postwłasnościowe i postdemokratyczne
 - [https://www.youtube.com/watch?v=zHsJwxdrEUQ](https://www.youtube.com/watch?v=zHsJwxdrEUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-05-09 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3uA0i3E
---------------------------------------------------------------
💡 Tagi: #SmartCity
--------------------------------------------------------------

## NIK: Polski wywiad zamieszany w aferę respiratorową! Dlaczego PiS nie rozlicza swojej afery?
 - [https://www.youtube.com/watch?v=C8Xhh8exyes](https://www.youtube.com/watch?v=C8Xhh8exyes)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-05-08 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3twaCbR
2. https://bit.ly/3evFGnH
3. https://bit.ly/2RzB1rY
4. https://bit.ly/3buIy2r
5. https://bit.ly/38aVFmx
6. https://bit.ly/3hYjbHH
7. https://bit.ly/3ob9jhv
8. https://bit.ly/3y0nmuO
---------------------------------------------------------------
💡 Tagi: #Szumowski #respiratory
--------------------------------------------------------------

