# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Perception Documentary - Raising a Family and Making Games
 - [https://www.youtube.com/watch?v=29kCOc6LjnY](https://www.youtube.com/watch?v=29kCOc6LjnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-05-08 00:00:00+00:00

**Re-upload* This documentary originally aired on Gameumentary and we've now ported it over to The Escapist to give it a fresh set of eyes! Enjoy!

The story of The Deep End Games follows Bill and Amanda Gardner's journey through game development leading up to the release of their first indie title, Perception. It's a personal story about managing a family while also working to make it as an independent developer. 

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

