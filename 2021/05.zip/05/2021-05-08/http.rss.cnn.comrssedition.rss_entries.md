# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 'How can we feel safe?': Uyghur on Chinese government policy
 - [https://www.cnn.com/videos/world/2021/05/08/china-uyghurs-xinjiang-policy-host-government-officials-watson-pkg-intl-nr-vpx.cnn](https://www.cnn.com/videos/world/2021/05/08/china-uyghurs-xinjiang-policy-host-government-officials-watson-pkg-intl-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-08 22:42:16+00:00

CNN's Ivan Watson speaks to several Uyghurs about a Chinese government policy that forces Uyghur families to host government officials in their homes.

## Acosta remembers WH Christmas memory with Obamas' dog Bo
 - [https://www.cnn.com/videos/politics/2021/05/08/bo-obama-dog-dies-acosta-vpx.cnn](https://www.cnn.com/videos/politics/2021/05/08/bo-obama-dog-dies-acosta-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-08 21:02:31+00:00

The Obamas announced that their beloved family dog Bo has died. CNN's Jim Acosta reports.

## What a year of mourning taught America's florists about grief
 - [https://www.cnn.com/videos/us/2021/05/07/florists-pandemic-grief-toll-ak-orig.cnn](https://www.cnn.com/videos/us/2021/05/07/florists-pandemic-grief-toll-ak-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-08 13:53:06+00:00

After in-person funeral services were restricted during the pandemic, many sent flowers. From New York City to New Mexico, here's what America's florists have learned after a year of helping us say goodbye.

