# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## What Is Right To Repair?
 - [https://www.youtube.com/watch?v=RTbrXiIzUt4](https://www.youtube.com/watch?v=RTbrXiIzUt4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-05-08 00:00:00+00:00

Do you really own what you buy? And why is it so damn hard to repair your phone?

The new Waveform channel: http://youtube.com/WAVEFORM

0:00 Right To Repair Intro
3:27 They Want Control
8:08 Anti-Right To Repair
12:45 What's Happening in Tech
18:03 Conclusion

The Right to Repair Movement: https://www.repair.org/stand-up
Farmers hacking their John Deere tractors: https://youtu.be/EPYy_g8NzmI
Louis Rossmann: https://youtube.com/user/rossmanngroup
Simone Giertz Truckla: https://youtu.be/jKv_N0IDS2A

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds​
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

