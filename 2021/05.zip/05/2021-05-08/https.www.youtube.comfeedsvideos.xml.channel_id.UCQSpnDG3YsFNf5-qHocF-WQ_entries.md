# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The ULTIMATE USB Boot Drive
 - [https://www.youtube.com/watch?v=CuonyS3xdwg](https://www.youtube.com/watch?v=CuonyS3xdwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-05-09 00:00:00+00:00

THE LAST BOOTABLE USB YOU'LL EVER NEED
Links:
• Samsung USB on Amazon ⇨ https://geni.us/Bb5B (affiliate)
• Ventoy Website ⇨ https://ventoy.net/en/index.html
• Ventoy GitHub ⇨ https://github.com/ventoy/Ventoy
• Gnome-Look ⇨ https://www.gnome-look.org/browse/cat/109/order/latest/

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

Some Boot Disks I have:
• Memtest86: https://www.memtest86.com/
• Hiren Boot CD: https://www.hirensbootcd.org/


Custom Theme json code:
{
    "theme": {
        "file": "ventoy/themes/Vimix/theme.txt"
    }
}  

▼ Time Stamps: ▼
0:00 - Intro
1:22 - Choose a USB Drive
2:05 - Installing Ventoy
5:00 - Set Up Secure Boot
5:57 - Using Ventoy
6:46 - Custom Themes
8:30 - Examples

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

