# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## CHAI - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=OfYsU5lrABI](https://www.youtube.com/watch?v=OfYsU5lrABI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-08 00:00:00+00:00

http://KEXP.ORG presents CHAI performing live, recorded exclusively for KEXP.

Songs:
ACTION
Nobody Knows We Are Fun
Karma Chameleon (Culture Club cover)
Maybe Chocolate Chips
Donut Mind If I Do

Creative Direction & Stage Design: CHAI 
Producer & Director: Takahiro Shimoyama & Masaki Shinozuka (Valderrama)
Director of Photography: Masataka Ohashi (Gonshiro)
Cameras: Yosuke Tominaga & Yuto Ishikawa (Gonshiro)

Mix Engineer: Takayuki Yamashita (Delta Live Sound)
PA Engineer: Natsuko Yoshitake
Recording Engineer: Seiji Okajima (Delta Live Sound)
Assistant Engineers: Ryoyo Shirahase (Delta Live Sound)
Backline Tech: Atsushi Sunaga (A2 C)
Lighting Designer: Suzuki Ichiro (Energy)
Stage Set Coordinator: Hiromi Tayama (Nihonstage)
Stage Set Carpenter: Yuma Ikeda (Nihonstage)

http://chai-band.com
http://kexp.org

