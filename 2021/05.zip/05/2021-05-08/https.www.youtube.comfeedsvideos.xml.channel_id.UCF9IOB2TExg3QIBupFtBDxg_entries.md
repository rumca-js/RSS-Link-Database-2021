# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Global deaths underestimated
 - [https://www.youtube.com/watch?v=XRtRJLRRnpU](https://www.youtube.com/watch?v=XRtRJLRRnpU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-05-09 00:00:00+00:00

Estimation of total mortality due to COVID-19

http://www.healthdata.org/special-analysis/estimation-excess-mortality-due-covid-19-and-scalars-reported-covid-19-deaths

Ecuador, Peru, and the Russian Federation

Discrepancy between reported deaths and excess mortality

COVID-19 death rate is many multiples larger than official reports

Six drivers of mortality

total COVID-19 death rate

increase in mortality due to needed health care being delayed or deferred

mental health disorders including depression, alcohol, opioid use

reduction in mortality due to decreases in injuries

reductions in mortality due to reduced transmission of other viruses, (influenza, RSV, measles)

reductions in mortality due to some chronic conditions

Predicted ratio of total COVID-19 deaths to reported COVID-19 deaths

Eastern European and Central Asian countries, very high

Higher income countries, much closer to 1

Sub-Saharan Africa, 1.6 to 4.1

India, 2.96

May 3, 2021

COVID-19 deaths = 6.93 million

Reported number of deaths = 3.24 million

India

https://www.bbc.co.uk/news/world-asia-india-57027829

India variant UK

https://www.manchestereveningnews.co.uk/news/greater-manchester-news/surge-testing-bolton-escalated-over-20554409

Surge testing in Bolton, Rumworth, Deane, Great Lever

Two mobile testing units for asymptomatic people

Door to door visiting to encourage testing

Multilanguage leaflet distribution

Infection rates increasing

Bolton, 78%

Trafford, 6%

Rochdale, 3%

Wigan, 4%

Dr Helen Lowey, Bolton Director of Public Health 

there is some evidence that the Indian variant spreads more easily than other Covid-19 variants so it is the one that we want to stop and contain

We are working closely with our partners across the community to identify people who have the virus
to increase the numbers of our eligible residents having the vaccine

taking steps to provide additional capacity in these areas

targeted vaccination work to try and nip this in the bud

We are so close to getting things back to normal; let’s keep up the momentum and stop this virus from spreading further

