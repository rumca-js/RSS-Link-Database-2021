# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Reggie Watts Explains NFT's to Joe
 - [https://www.youtube.com/watch?v=T5x7lyWPnX8](https://www.youtube.com/watch?v=T5x7lyWPnX8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-08 00:00:00+00:00

Taken from JRE #1648 w/Reggie Watts:
https://open.spotify.com/episode/4Ct5bhOwlhgMSP77rBupIH?si=gUOqyo8MSkyiLvNqyhJN5Q

## The Controversy Surrounding the "Male Mona Lisa"
 - [https://www.youtube.com/watch?v=jqv6mWHVDUU](https://www.youtube.com/watch?v=jqv6mWHVDUU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-08 00:00:00+00:00

Taken from JRE #1648 w/Reggie Watts:
https://open.spotify.com/episode/4Ct5bhOwlhgMSP77rBupIH?si=gUOqyo8MSkyiLvNqyhJN5Q

