# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 FINEST 2000s Video Game Graphics in 4K
 - [https://www.youtube.com/watch?v=DyM80juIxZY](https://www.youtube.com/watch?v=DyM80juIxZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-09 00:00:00+00:00

Some video game graphics hold up and look great many years later. Here are some examples, now in stunning 4K!
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Resident Evil 8: Village - 10 Things The Game Doesn't Tell You
 - [https://www.youtube.com/watch?v=IaqOwaCj31A](https://www.youtube.com/watch?v=IaqOwaCj31A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-08 00:00:00+00:00

Resident Evil Village (PC, PS5, Xbox, PS4), is filled with secret tricks and things to discover. Here are some beginner tips.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

