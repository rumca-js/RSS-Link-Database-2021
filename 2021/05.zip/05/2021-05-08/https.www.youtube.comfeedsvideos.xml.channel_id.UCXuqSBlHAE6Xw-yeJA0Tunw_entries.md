# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Should NOT Quit My Day Job - MetaHuman Creator Tool
 - [https://www.youtube.com/watch?v=he7uL7Ezv68](https://www.youtube.com/watch?v=he7uL7Ezv68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-09 00:00:00+00:00

Visit https://www.squarespace.com/LTT & use offer code LTT for a free trial & 10% off

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

Recreating Linus digitally is hard, but with the help of the MetaHuman Creator tool from Epic you can do it too! It just might take a little longer than 20 minutes though...

Buy AMD Ryzen 9 3900XT CPU (PAID LINK): https://geni.us/PbWL

Buy Corsair iCUE 5000X Case (PAID LINK): https://geni.us/vhWNxf

Buy ASUS TUF Gaming B550-PLUS (PAID LINK): https://geni.us/RGSQMQ

Buy Crucial 16GB Ballistix DDR4 3600MHz RAM (PAID LINK): https://geni.us/QuuD6g1

Buy SeaSonic FOCUS GX 750W PSU (PAID LINK): https://geni.us/utecHO

Buy Noctua NH-U14S CPU Cooler (PAID LINK): https://geni.us/onoBGxy

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: **https://linustechtips.com/topic/1335713-i-should-not-quit-my-day-job/**


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## You blew your budget on WHAT?? - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=RUI1k-KHXNk](https://www.youtube.com/watch?v=RUI1k-KHXNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-08 00:00:00+00:00

Thanks to Intel for sponsoring this series!

In this Home Upgrade, James spends $5,000 to take his home theater and gaming rig to the next level!

Buy Intel Core i7-11700 CPU (PAID LINK): https://geni.us/FFpf
Buy ASROCK H570M-ITX/AC (PAID LINK): https://geni.us/uqmNPf
Buy EVGA RTX 3080 XC3 ULTRA GAMING GPU (PAID LINK): https://geni.us/QA6kxb
Buy SVS SoundPath Subwoofer Isolation System (PAID LINK): https://geni.us/aeRrl
Buy SVS SB-2000 Pro Subwoofer (PAID LINK): https://geni.us/kM5XqA
Buy Anthem MRX 740 Receiver (PAID LINK): https://geni.us/K4Ehu37
Buy Wood Grain Furniture Tape (PAID LINK): https://geni.us/Oelg0g
Buy APC Surge Protector (PAID LINK): https://geni.us/BXrPE
Buy Nvidia Shield Pro 4K (PAID LINK): https://geni.us/QDanBQ
Buy Banana Plugs (PAID LINK): https://geni.us/VH9g7sp 

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1335692-you-blew-your-budget-on-what-intel-5000-extreme-tech-upgrade/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

