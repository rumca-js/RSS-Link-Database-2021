# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Finrod Felagund, Galadriel's Brother | Tolkien Explained
 - [https://www.youtube.com/watch?v=qbVGESA2wDQ](https://www.youtube.com/watch?v=qbVGESA2wDQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-05-08 00:00:00+00:00

Finrod is one of Galadriel's three siblings and one of the greatest elf lords of the First Age.  He is known as the King of Nargothrond and a great friend of the men of Middle-earth.  Today, we will cover his entire life and his complete travels from his birth in Valinor to his death when he saves Beren from a werewolf.  His journey doesn't stop there, however.  Finrod is one of the few Tolkien characters we will follow into the afterlife!

*Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!*  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, I highly recommend checking out these amazing artists online!

Ted Nasmith - https://www.tednasmith.com/shop/
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Jenny Dolfen - https://goldseven.wordpress.com/

Elf meets Men - Alystraea Art
The Oath of Feanor - Antti Autio
The Crossing of the Helcaraxe - Antti Autio
Feanor and Fingolfin - Jenny Dolfen
Dream - Liga Kjavina
Amarie - Alystraea Art
The Parting of Lovers - Antti Autio
The Curse of Mandos - Lourdes Velez
Finrod Felagund - Turner Mohan
Turgon and Finrod on the bank of Sirion - MySilverGreen
Battle of Sudden Flame - Alan Lee
Nargothrond - Jesse Vandijk
Gondolin - Ted Nasmith
Beleg Departs from Menegroth - Alan Lee
Beren and Luthien in the Court of Thingol and Melian - Donato Giancola
Nargothrond - Felix Sotomayor
Nargothrond - Jonathan Guzi
Nargothrond - the Hidden Kingdom of Finrod - MySilverGreen
Turin in Nargothrond - Klaus Wittman
Beleriand Map - lamaarcana
The Hunt - Jenny Dolfen
Finrod and Beor - Svirina Vera
Finrod - Anna Lee
Of the Coming of Men into the West - Luis F Bejarano
Finrod, Beor, and the Green Elves - Steamey
Beor - Forever Medhok
Rider - Eric Faure Brac
The Lord of the Third House - Tuuliky
Ar-Pharazon - Steamey
Aikanaro and Andreth - Tuuliky
I will tell him - Andreth and Finrod - Sara M Morello
The Music of the Gods - Kip Rasmussen
Aegnor and Andreth - Melkor Was Here
The Oath of Finrod and Barahir - Anke Eissmann
The Oath of Felagund - Antti Autio
Beren's Trial - Anke Eissmann
Beren at Felagund's Throne - Antti Autio
Finrod is reminded of his oath - Anke Eissmann
Celegorm and Curufin - Jenny Dolfen
Curufin - Anke Eissmann
And Finrod fell before the Throne - Kurai Geijutsu
Finrod and Sauron - Rami Fon Verg
Finrod Felagund - Lelia
Alqualonde - Ted Nasmith
Sauron vs Finrod - the Duel of Songs of Power - Anna Kulisz
Finrod - Michael Howe
In a Dungeon - MySilverGreen
Rescue Finrod and Barahir - Marya Filatova
Death of Finrod - Anke Eissmann
In Tol-in-Gaurhoth - Steamey
Minas Tirith - Stefan Meisl
Telperion and Laurelin, the Two Trees of Valinor - MrSvein872
Finrod and Amarie - Alystraea Art

For more on Finrod and the First Age, check out:
The Silmarillion
History of Middle-earth Vol. 10: Morgoth's Ring
The Encyclopedia of Arda
Tolkien Gateway

#finrod #tolkien #silmarillion

