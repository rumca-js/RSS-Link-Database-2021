# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Fixes... Game of Thrones
 - [https://www.youtube.com/watch?v=rVGHjB_c0Ok](https://www.youtube.com/watch?v=rVGHjB_c0Ok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-05-09 00:00:00+00:00

Game of Thrones Season 8 left a scar on most fans that will never heal. But in this video, I do my best to show how the series could have ended in a more satisfying way.

