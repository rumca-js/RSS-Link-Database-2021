# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## Eksperyment książkowy [TARCIE]
 - [https://www.youtube.com/watch?v=W6bahrx5cQQ](https://www.youtube.com/watch?v=W6bahrx5cQQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2021-05-23 11:14:13+00:00

Scifun prawie się zabija w imię nauki.
Powiększone cashbacki w Letyshops z okazji Urodzin - https://letyshops.onelink.me/HKO3/1fc11ab6
Zainstaluj wtyczkę Letyshops - https://bit.ly/3bBW7gk

