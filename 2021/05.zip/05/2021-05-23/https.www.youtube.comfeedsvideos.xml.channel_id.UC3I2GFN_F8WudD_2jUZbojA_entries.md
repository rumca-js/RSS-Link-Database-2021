# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Working Men's Club - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=q9c_3e0wLQY](https://www.youtube.com/watch?v=q9c_3e0wLQY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-24 00:00:00+00:00

http://KEXP.ORG presents Working Men's Club sharing a live performance recorded exclusively for KEXP and talking to Kevin Cole, host of Drive Time. Recorded April 21, 2021.

Songs:
Valleys
X
John Cooper Clark
Be My Guest
Teeth
Angel

Session filmed and directed by IMPATV
Sound recorded and mixed by Nick Gizzi 

Working Men’s Club are:
Sydney Minsky-Sargeant - Vocals/Guitar/Drum Machine/Synth
Mairead O’Connor - Guitar/Keyboards/Vocals
Rob Graham - Guitar / Synth
Liam Ogburn - Bass
Ross Orton - Drums

https://workingmensclub.net
https://www.impatv.com
http://kexp.org

