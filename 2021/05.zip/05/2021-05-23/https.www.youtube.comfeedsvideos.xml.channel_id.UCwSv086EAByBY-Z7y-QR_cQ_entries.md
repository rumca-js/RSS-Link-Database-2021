# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Jakie dane zbierają o nas paszporty covidowe? Możesz się zdziwić!
 - [https://www.youtube.com/watch?v=nkku10hXYKw](https://www.youtube.com/watch?v=nkku10hXYKw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-05-24 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3ww0eT6
2. https://bit.ly/3wA2QQ5
3. https://bit.ly/3djOnAI
---------------------------------------------------------------
💡 Tagi: #Covid19 #QR
--------------------------------------------------------------

## Dziennikarze społeczni w odwiedzinach u ministra Adama Niedzielskiego! Analiza
 - [https://www.youtube.com/watch?v=ltpwCqZakIc](https://www.youtube.com/watch?v=ltpwCqZakIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-05-23 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3oGsNdU
2. https://bit.ly/2ShM5du
3. https://bit.ly/34d9hw6
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
gov.pl - http://bit.ly/2lVWjQr
---------------------------------------------------------------
💡 Tagi: #Niedzielski #polityka
--------------------------------------------------------------

