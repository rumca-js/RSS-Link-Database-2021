# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Never Really Over | Katy Perry | funk cover ft. Jacob Jeffries
 - [https://www.youtube.com/watch?v=KJCX_7kSKb8](https://www.youtube.com/watch?v=KJCX_7kSKb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-05-24 00:00:00+00:00

Join our Vinyl Club tier on Patreon to get vinyl every 3 months! http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Katy Perry's "Never Really Over" by Scary Pockets & Jacob Jeffries.

MUSICIAN CREDITS
Lead vocal: Jacob Jeffries
Drums: Lemar Carter & Kyle Crane
Bass: Anna Butterss
Guitar, Synth Keys, Percussion: Brian Green
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Asst. Engineer: Chad Gordon
Mixing/Mastering: Caleb Parker
Producer: Brian Green

VIDEO CREDITS
Director: Mike Dempsey
DP - Ricky Chavez
Camera Operators: Ricky Chavez, Sammy Rothman, Alex Humphrey
Editor: Adam Kritzberg
Vlog Editor: Cameron Dinwiddie
Tech: Joonas Cohen
Additional Production:  KJ Sadural

Recorded Live at East West in Los Angeles, CA.

#ScaryPockets #Funk #KatyPerry #NeverReallyOver #JacobJeffries

