# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I REALLY Wanted to Try Mini LED... and it's GREAT!
 - [https://www.youtube.com/watch?v=jM-ED97_vKo](https://www.youtube.com/watch?v=jM-ED97_vKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-24 00:00:00+00:00

Get a Free pair of Wireless Bluetooth Headphones at Micro Center: https://micro.center/e37ecd
Check out the Micro Center Custom PC Builder: https://micro.center/c7b719
Join the Micro Center Community: https://micro.center/e2dcb2

Add Honey for FREE and start saving today at https://joinhoney.com/ltt
Thanks, Honey for sponsoring!

Samsung's latest NEO QLED TVs are designed around some brand new tech, also featured in Apple's latest iPad Pro called Mini LEDs. They've been teasing them for a couple years now and today I finally get to try them out!


Buy Samsung NEO QN85A QLED TV: https://geni.us/2B14WQ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1341193-i-really-wanted-to-try-this-samung-neo-qled-mini-led-tvs/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:07 QLED vs OLED History Lesson
2:23 Dimming Zones Explained
3:23 Alternative Options
3:50 Samsung NEO QLED Introduction
4:56 Bright Room Image Comparison
9:10 Dark Room Image Comparison
10:43 Can Linus Tell the Difference?
11:39 Image Comparison Conclusion
12:43 Q-Symphony Audio Test (Fail)
13:41 Outro

## I am Holding a PC - Dell Optiplex 7070 Ultra
 - [https://www.youtube.com/watch?v=jOWc25fLlEo](https://www.youtube.com/watch?v=jOWc25fLlEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-23 00:00:00+00:00

Thanks to Wren for sponsoring this video! Offset your carbon footprint with Wren at https://www.wren.co/join/linustechtips

SmartDeploy: Claim your free IT software (worth $882!) at https://lmg.gg/yMhY8

Dell makes computers. Dell makes monitors. You would think that Dell could find a way to merge the two without making an all-in-one – And you’d be right! Let’s look at the OptiPlex 7070 Ultra…


Buy Dell OptiPlex 7070 Ultra Desktop (PAID LINK): https://geni.us/ONKV

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1339940-i-am-holding-a-pc/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:55 Some background
1:19 Mounting options & box contents
2:29 Setup process
2:49 The drop
2:54 Specs, internals & disassembly
4:37 Testing
5:51 New version
6:54 Conclusion: Dell... WHY??

