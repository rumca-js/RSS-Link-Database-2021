# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Next-Gen Space Stations That Could Replace The ISS | Answers With Joe
 - [https://www.youtube.com/watch?v=dqLLEwbRzn8](https://www.youtube.com/watch?v=dqLLEwbRzn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-05-24 00:00:00+00:00

Get 20% of a premium subscription to Brilliant when you're one of the first 200 people to sign up at http://www.brilliant.org/answerswithjoe
The end of the ISS is less than 10 years away. Here's what's coming next.
From the luxury space hotels of Axiom Space to the inflatable super habitats of Bigelow Aerospace to future international efforts, these are the places where we could be living and working in the coming decades.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

Timestamps:

0.00 - Skylab
2:30 - How we got to the ISS
6:00 - Axiom Space
8:23 - The Chinese Space Station
9:30 - India's Space Station Project
10:05 - Bigelow's Expandable Space Stations
12:15 - Nanoracks
14:30 - Blue Origin's Plans
16:00 - The Lunar Gateway
17:35 - The End of the ISS
19:45 - Sponsor Message

