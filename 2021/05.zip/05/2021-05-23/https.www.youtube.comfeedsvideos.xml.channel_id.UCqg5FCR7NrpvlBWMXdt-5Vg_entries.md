# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Biomutant Is an Ambitious Mess
 - [https://www.youtube.com/watch?v=7C8CueiGjCg](https://www.youtube.com/watch?v=7C8CueiGjCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-05-24 00:00:00+00:00

Biomutant is a fascinating and frustrating game. On paper, it’s an open-world RPG that’s a bit of Zelda, Fable, Fern Gully, and Redwall all mashed together. It had me marveling as it introduced new idea after new idea, only to find them not quite melding together. It’s a game that’s oftentimes clunky to play, but hard to stop talking about. And while it has a litany of problems, it’s ultimately a game that I continue to think about long after rolling credits thanks to its wildly-impressive scope and ambition.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Ghostrunner  | The Editor's Hour with Nick & KC
 - [https://www.youtube.com/watch?v=bHuBeHOoqVA](https://www.youtube.com/watch?v=bHuBeHOoqVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-05-24 00:00:00+00:00

Bloodborne: The Old Hunters has been completed, now we're gonna give Ghostrunner a go. 

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Talking The Expanse and Retro Sci-Fi with Ty Franck | The Escapist Movie Podcast
 - [https://www.youtube.com/watch?v=wHVEQI5n2iw](https://www.youtube.com/watch?v=wHVEQI5n2iw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-05-24 00:00:00+00:00

The Escapist Movie Podcast returns to the main channel with a super exciting debut episode speaking with the co-writer of The Expanse, Ty Franck. 

We'll be talking The Expanse, retro sci-fi and more!

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## A Conversation About Completing Games Before Reviewing Them | The Escapist Show
 - [https://www.youtube.com/watch?v=W2Cynrqj8Kc](https://www.youtube.com/watch?v=W2Cynrqj8Kc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-05-23 00:00:00+00:00

This week on The Escapist Show, Nick's making his way through Luigi's Mansion 3, Jack has nitpicks about Monster Hunter Rise and then we have a conversation about the games media and the never-ending debate about finishing games for review.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps
The games we've been playing 0:00 - 22:40
Games media and finishing games 22:41 - 43:20


---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

