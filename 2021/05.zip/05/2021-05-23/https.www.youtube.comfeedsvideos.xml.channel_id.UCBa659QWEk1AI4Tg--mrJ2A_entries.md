# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The long-forgotten history of the British moon spacesuit
 - [https://www.youtube.com/watch?v=jYgiV4Iz7I0](https://www.youtube.com/watch?v=jYgiV4Iz7I0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-05-24 00:00:00+00:00

Decades before NASA's Apollo program, the British Interplanetary Society wanted to go to the moon: in a spacesuit that looked like a suit of armour. 

Thanks to all the team at the National Space Centre: https://spacecentre.co.uk/
And to the British Interplanetary Society for their archive images: https://www.bis-space.com/

Drone filming by special permission of the National Space Centre. Please do not attempt it yourself, the Rocket Tower is made of ETFE foil on a steel frame and propellers must not get close to it!

More about the BIS spacesuit: https://spacecentre.co.uk/blog-post/the-bis-lunar-spacesuit/

Edited by Michelle Martin (@mrsmmartin)

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

