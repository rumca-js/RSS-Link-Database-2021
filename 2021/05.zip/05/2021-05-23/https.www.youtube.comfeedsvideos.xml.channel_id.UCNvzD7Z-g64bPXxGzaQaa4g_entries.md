# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Things ONLY Open World Gamers Will Understand
 - [https://www.youtube.com/watch?v=6l_dHCYH8dY](https://www.youtube.com/watch?v=6l_dHCYH8dY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-23 00:00:00+00:00

Some open world games do some really silly things that we just have to ignore. Here are the dumbest examples of open world game logic.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Credit: https://www.youtube.com/channel/UCr40yQ0yD6p9ZmGjnkdwc1w

