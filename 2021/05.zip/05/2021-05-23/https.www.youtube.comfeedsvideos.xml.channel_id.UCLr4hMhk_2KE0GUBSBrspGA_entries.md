# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week - Kolorowe komputery atakują! iMac 2021, Android 12 beta, Pixel 6, 6 Pro, smartwatch Sharp
 - [https://www.youtube.com/watch?v=9Tcv4vZk4ik](https://www.youtube.com/watch?v=9Tcv4vZk4ik)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-05-23 00:00:00+00:00

A poza tym:
Odwołali targi w Berlinie: https://bit.ly/3oFj5Zp
Ale te w Barcelonie nadal są: https://mwc-barcelona.org
Android 12 beta: https://bit.ly/3hNrsR9
Lepiej nie instalować go na OnePlusie: https://bit.ly/3fHAxYT
Taki będzie Pixel 6 i 6 Pro: https://youtu.be/VzupAfbY8a4
Google pracuje z Samsungiem nad systemem na smartwatche: https://bit.ly/3oIZasv
Lamborghini na prąd dopiero w 2025: https://bit.ly/3hOCBRQ
Ford będzie wyświetlał billboardy w samochodach? https://bit.ly/3494mwh
Apple Watch jedną ręką: https://youtu.be/2YduyTzZews
Nowy smartwatch Sharpa: https://bit.ly/2TbnkjI
Internet Explorer odchodzi w zapomnienie: https://bit.ly/3v9Rhi6
Hackerzy AI: https://bit.ly/2T7rGrT

W odcinku:
00:00 Wstęp
00:16 Kolorowe iMac'i atakują
01:07 Dobry wieczór!
01:13 iPad Pro
02:35 Za czym kolejka ta stoi?
03:13 Odwołane targi IFA w Berlinie, ale te w Barcelonie będą
04:01 Android 12 beta już jest!
06:25 Taki będzie Pixel 6 i Pixel 6 Pro
07:58 Google i Samsung pracują nad systemem do smartwatchy
08:18 Nowe przepisy dla małych pojazdów elektrycznych weszły w życie
09:25 Dokąd zmierzasz, YouTubie?
10:54 Elektryczne Lamborghini dopiero w 2025
11:03 Billboardy wyświetlane w samochodach Forda
11:44 Apple Watch obsługiwany jedną ręką
12:14 Pominięte tematy
12:35 Pożegnanie
12:54 Znośnego tygodnia!

Moje Sociale: 
Insta: https://www.instagram.com/kubaklawiter/
Twitter: https://twitter.com/KubaKlawiter

