# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## CDC Says You No Longer Have To Wear A Life Jacket Outside In Case Of Rain
 - [https://www.youtube.com/watch?v=C-TZO-hPxp4](https://www.youtube.com/watch?v=C-TZO-hPxp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-05-24 00:00:00+00:00

Kyle Mann is on the scene with an exclusive interview with a pro-life vester. Will he listen to the new CDC guidelines or will he be incredibly dumb?

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

