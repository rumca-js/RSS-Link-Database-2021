# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Resident Evil Village - Full Review
 - [https://www.youtube.com/watch?v=lBCp0rJf5hQ](https://www.youtube.com/watch?v=lBCp0rJf5hQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-05-24 00:00:00+00:00

Now that I've had a chance to complete the latest entry in the Resident Evil series, its time to give my full review of Resident Evil 8. Expect some plot spoilers.

