# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Scammer Leaves a Note After Running Off with $32 Million in Crypto
 - [https://www.youtube.com/watch?v=0TXpx2S1_Mw](https://www.youtube.com/watch?v=0TXpx2S1_Mw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-05-24 00:00:00+00:00

Defi100 took the money and ran.
To see the note they left: https://web.archive.org/web/20210522030957/https://defi100.org/
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

## Scammers Couldn't Stop Bragging Online and Got ARRESTED
 - [https://www.youtube.com/watch?v=BiDhZpchTIY](https://www.youtube.com/watch?v=BiDhZpchTIY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-05-23 00:00:00+00:00

This is the dumbest fraud ever. 

DOJ: https://www.justice.gov/usao-edny/pr/eight-brooklyn-individuals-charged-multi-million-dollar-covid-19-relief-fraud
https://www.nbcnewyork.com/news/local/crime-and-courts/eight-brooklyn-men-stole-millions-of-dollars-in-covid-relief-fraud-scheme-prosecutors/3063305/

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

