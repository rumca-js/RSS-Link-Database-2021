# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ksiądz gra w grę: The Last of Us [09] Kto rozmawia o seksie z twoim dzieckiem?
 - [https://www.youtube.com/watch?v=EsQm4nvVovc](https://www.youtube.com/watch?v=EsQm4nvVovc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-05-24 00:00:00+00:00

@langustanapalmie #ksiadzgrawgre #TheLastOfUs
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#792] Żądamy!
 - [https://www.youtube.com/watch?v=eZXT_JSOT2w](https://www.youtube.com/watch?v=eZXT_JSOT2w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-05-24 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Jonasz z maturalnej [#03] Sake
 - [https://www.youtube.com/watch?v=6sW1x9uTE9k](https://www.youtube.com/watch?v=6sW1x9uTE9k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-05-23 00:00:00+00:00

​@Langustanapalmie  #nowysezon #jonaszzmaturalnej #challenge #wyzwanie #babcia #sushi #sake #tajemnica #tajemnicerodzinne 

Czy Wy też byliście ciekawi, co słychać u Babci Jonasza? O tym, jakie tajemnice może strzec w rodzinie Babcia, dowiecie się w tym odcinku… 

 
Scenariusz - Angelika Olszewska
Reżyseria - Mateusz Olszewski
Zdjęcia - Marcin Lesisz
Montaż: Agata Przygodzka
Asystent operatora, ostrzyciel - Marcin Jończyk
Mistrz oświetlenia - Jędrzej Mańkowski
 
Reżyseria dźwięku: Iga Kałduńska
Do udźwiękowienia wykorzystano: muzykę z bazy Paris Music 
SOLVE THE PUZZLE | Alexander Hitchens
ASIAN DRAMA | Daniel Holter
TELL ME YOUR HEART | Jiyoung Chung
SERIOUS GAMERS | Chris Constantinou/Paul Frazer
LITOST | Derek Allen Jones/Edward Wohl/Mitchell Marlow
FADING SUPERSTITION | Fabien Langard, Philippe Villar
EASTERN GONG 2 | Steve Buick
AGE OF THE GODS | Alexius Tschallener/Dominik Luke Marsden Johnson T
OKYO BAY | Asami Tanaka/Aurelien Chambaud
utwór “Głębia” zespołu Projekt Przebudzenie
 
Jonasz - Piotr Bondyra
Piotrek - Krzysztof Godlewski
Babcia - Tomira Kowalik
Kelnerka - Agata Karpiel
Danka - Maja Barełkowska-Cyrwus
Władziu - Sławomir Głazek
Mieszkanka bloku - Martyna Trawczyńska
 
Serial produkowany przez Stowarzyszenie Działań Twórczych Republika Warszawa  dla Langusty na Palmie 
Śledź JONASZA na FB 
→ https://www.facebook.com/jonasz.serial/
oraz na Instagramie: 
→ https://www.instagram.com/jonasz.serial/

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Rodzaju || Rozdział 26
 - [https://www.youtube.com/watch?v=PNY92-bZ9lw](https://www.youtube.com/watch?v=PNY92-bZ9lw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-05-23 00:00:00+00:00

UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno Stronniczy [#40] Jakie są Twoje bolączki?
 - [https://www.youtube.com/watch?v=QkZpURS0v1Y](https://www.youtube.com/watch?v=QkZpURS0v1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-05-23 00:00:00+00:00

​@Langustanapalmie @STREFAWODZA 

Takich dwóch, jak Ci to nie ma.
Zapraszamy w niedzielę o godz: 10:oo 
na premierę zupełnie niesłychanej serii.

zdjęcia, dźwięk: Marcin Jończyk
montaż: Agnieszka Nowak
grafika, produkcja serii: Sylwia Smoczyńska
dźwięk: Radosław Więcławek OP
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

