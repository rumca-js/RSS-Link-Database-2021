# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## La chanson de Maxence // Michel Legrand // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=NilqH1UjR6Y](https://www.youtube.com/watch?v=NilqH1UjR6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-05-27 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 This might be my favorite song on the upcoming French record.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Michel Legrand's "La chanson de Maxence" by Pomplamoose.

MUSICIAN CREDITS
Vocals: Nataly Dawn
Accordion: Jack Conte
Hi Strung Guitar: John Schroeder
Chromatic Harmonica: Ross Garren
Upright Bass: Eliana Athayde
Acoustic Guitar: Erik Miron
Clarinet: John Tegmeyer
Drums: Ben Rose
Background Vocals: Sarah Dugas

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Branko Presley
Mixing/Mastering: Caleb Parker
Producer: John Schroeder

VIDEO CREDITS
Video Production/Direction: Ricky Chavez, George Sloan
Camera Operators: Merlin Showalter, Sammy Rothman, Dijon Herron, Charlene Gibbs
Art Design: George Sloan, Susannah Honey
Video Editor: Cleveen Dominguez
Colorist: Charlene Gibbs

Recorded at The Village in Los Angeles.

LYRICS (French / English)
Je l'ai cherchée partout / I’ve searched for her everywhere
J'ai fait le tour du monde / I’ve been around the world
De Venise à Java, de Manille à Angkor / From Venice to Java, From Manilla to Angkor
De Jeanne à Victoria, de Vénus en Joconde / From Jeanne to Victoria, from Venus to Joconde*
Je ne l'ai pas trouvée et je la cherche encore / I haven’t found her and I search for her still

Je ne connais rien d'elle et pourtant je la vois / I know nothing about her and yet I see her
J'ai inventé son nom, j'ai entendu sa voix / I’ve made up her name, I’ve heard her voice
J'ai dessiné son corps et j'ai peint son visage / I’ve sketched her body and painted her face
Son portrait et l'amour ne font plus qu'une image / Her portrait and love have become a single image

Sa démarche ressemble aux souvenirs d'enfant / Her walk resembles childhood memories
Qui trottent dans ma tête et dansent en rêvant / That run through my head and dance as they dream
Sur son front, ses cheveux sont de l'or en bataille / On her brow, her hair is tousled gold
Que le vent de la mer et le soleil chamaillent / That the ocean wind and the sun tease

Je pourrais vous parler de ses yeux, de ses mains / I could speak to you of her eyes, of her hands
Je pourrais vous parler d'elle jusqu'à demain / I could tell you about her until tomorrow
Son amour, c'est ma vie mais à quoi bon rêver? / Her love is my life, but what good is this dream?
Je l'ai cherchée partout et je ne l'ai pas trouvée / I’ve looked for her everywhere and I haven’t found her

Je la chercherai à jamais / I’ll search for her always

*La Joconde is another name for the Mona Lisa, from the Italian La Gioconda, which is the feminine version of her husband's last name, del Giocondo. It means jocund or jolly, lighthearted.

