# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Soulja Boy Scammed Us but Accidentally Left The Evidence
 - [https://www.youtube.com/watch?v=iBXXZoyFkJc](https://www.youtube.com/watch?v=iBXXZoyFkJc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-05-27 00:00:00+00:00

DRAAAAAKE?! Soulja Boy accidentally tweeted out a sponsorship offer to shill a scam coin called "safermars" not to be confused with safemoon, safemars or safestar. 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

