## The Takeover has Already Begun - A Secret Video Reveals All by @RICHARD GRANNON
 - [https://www.youtube.com/watch?v=npkZQGD7LOM](https://www.youtube.com/watch?v=npkZQGD7LOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuErSr7xeR763BzTJL7yJ7A
 - date published: 2021-05-27 21:17:48+00:00

The Takeover has Already Begun - A Secret Video Reveals All by @RICHARD GRANNON

