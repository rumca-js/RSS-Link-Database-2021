# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Vex Ruffin - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=B9NSO80rMqU](https://www.youtube.com/watch?v=B9NSO80rMqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-28 00:00:00+00:00

http://KEXP.ORG presents Vex Ruffin sharing a live performance recorded exclusively for KEXP and talking to Larry Mizell, Jr., host of The Afternoon Show. Recorded May 13, 2021.

Songs:
Mabuhay Boy
Hard To See
Know Yourself
I'm Still At It
What Matters The Most
Tapang Naman

Session filmed by Wes Africa 

Vex : vocals 
Shags : bass guitar 
Alex Zhang Hungtai : saxophone 
Mikey Long : guitar
Josh Da Costa : drums

https://www.stonesthrow.com/artist/vex
http://kexp.org

## Femi Kuti and Made Kuti - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=GOqmSv5cIlc](https://www.youtube.com/watch?v=GOqmSv5cIlc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-27 00:00:00+00:00

http://KEXP.ORG presents Femi Kuti and Made Kuti performing live, recorded exclusively for KEXP.

Songs:
Pà Pá Pà (Femi Kuti)
Trouble Sleep Yanga Wake Am (Made Kuti)
Stop The Hate (Femi Kuti)
Free Your Mind (Made Kuti)
Water No Get Enemy (Femi Kuti and Made Kuti)

Filming team:
Director & First Camera - Optimus Dammy
Second Camera - Williams Ediongsenyene 
Third Camera - Kolade Oseni

FEMI KUTI AND THE POSITIVE FORCE 
Femi Kuti - lead vocals, lead sax, lead trumpet, keyboard 
Opeyemi Awomolo - Guitar 
Onome Udi  - Dancer
Anthonia Bernard - Dancer
Seun Ajayi - Keyboard 
Imeh Akpan - Clef
Gbenga Ogundeji - Trumpet
Jumoke Adigun - Dancer
Babatunde Ankra - Trombones 
Ayoola Magbabeola - Baritone 
Ayodeji Adebanjo - Tenor Saxophone 
Mattew Fanibe - Percussion 
Dayo Sowunmi - Trumpet
Alaba Ayodele - Drums
Damilola Adeniyi - Bass guitar

MADE KUTI AND THE MOVEMENT
Made Kuti - Lead vocals, lead sax, lead trumpet 
Oluwaseun Ajike - Bass guitar
Israel Ogundeji - Tenor sax 
Oyewole Taiwo - Trumpet
Adeoye O. Timothy - Trumpet
Emmanuel Idowu - Drums 
Victor Oz Oduche - Keyboard 
Efeoghene Alloh - Guitar 
Ogunyemi Opeyemi Oluwatosin - Baritone Sax 
Mobolaji Nicholas Tayo - Percussion

https://www.femikuti.com
https://www.madekuti.com
http://kexp.org

