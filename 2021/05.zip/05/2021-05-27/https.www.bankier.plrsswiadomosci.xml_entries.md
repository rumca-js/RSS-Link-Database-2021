# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Nvidia z rekordowymi wynikami. Pomogli gracze i kryptowaluty
 - [https://www.bankier.pl/wiadomosc/Nvidia-z-rekordowymi-wynikami-Pomogli-gracze-i-kryptowaluty-8121272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nvidia-z-rekordowymi-wynikami-Pomogli-gracze-i-kryptowaluty-8121272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2021-05-27 06:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/50815050d9f377-945-560-0-90-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rekordowe wyniki Nvidii
za pierwszy kwartał 2021 r. przebiły oczekiwania rynku. Nie przełożyło się to
jednak na wzrost cen akcji, który już teraz znajduje się blisko maksimów.</p>

