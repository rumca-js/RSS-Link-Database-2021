# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## FIRST UNREAL ENGINE 5 USER CREATION IS MIND BLOWING, HORIZON FORBIDDEN WEST GAMEPLAY, & MORE
 - [https://www.youtube.com/watch?v=4bNc_bUIWcA](https://www.youtube.com/watch?v=4bNc_bUIWcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-28 00:00:00+00:00

Thanks to Dr. Squatch for sponsoring. New Dr. Squatch customers can get 20% off on orders of $20 or more when they go to https://bit.ly/3rFioA3

Big Xbox and PS5 news, Far Cry 6 revealed, Sonic and JRPG stuff, new Valve Steam hardware rumors, and more in a week chock full of gaming news.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake’s other channel:
https://youtu.be/0vnk8ra3MtY



 ~~~~STORIES~~~~




Unreal engine stuff
https://www.reddit.com/r/gaming/comments/nm8lo2/the_konami_code_works_in_the_unreal_engine_5_demo/
https://www.youtube.com/watch?v=d1ZnM7CH-v4
https://twitter.com/IonizedGames/status/1397636481913610241

Horizon Forbidden West (still no release date)
https://youtu.be/wQATS4HOxdo

Uncharted 4 coming to PC?
https://www.engadget.com/sony-uncharted-4-pc-093043348.html

Xbox Bethesda event June 13th
https://www.theverge.com/2021/5/26/22453024/microsoft-xbox-bethesda-showcase-presentation-event-e3-2021

Borderlands Sony crossplay
https://www.polygon.com/22456489/borderlands-3-cross-play-update-ps4-ps5-sony


New Switch?
https://www.eurogamer.net/articles/2021-05-27-nintendo-switch-pro-to-be-unveiled-before-e3


Dying Light 2 (December 7th)
https://youtu.be/RJGdMGRAjVA


Dragon Questhttps://youtu.be/gfmOWgfYVjY

Far Cry 6
https://youtu.be/pQwfNEF6cY8

Sonic news!
https://www.youtube.com/watch?v=Z3MCqTdsVKc



Square Enix FF Dark Souls spinoff rumor
https://www.fanbyte.com/news/rumor-square-enix-set-to-announce-a-new-action-rpg-final-fantasy-spinoff/

Portable Steam thing
https://arstechnica.com/gaming/2021/05/exclusive-valve-is-making-a-switch-like-portable-gaming-pc/

## 10 Things Found HIDDEN Inside Video Games Boxes
 - [https://www.youtube.com/watch?v=PK7pyRzWcwI](https://www.youtube.com/watch?v=PK7pyRzWcwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-27 00:00:00+00:00

Physical retail video game boxes and collectors editions are often filled with fun surprises and Easter eggs. Here are our favorite examples of cool hidden stuff.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Borderlands 3 - Box Art Secrets

https://whatculture.com/gaming/10-fiendishly-clever-secrets-hidden-in-video-game-covers?page=6

https://gamerant.com/borderlands-3-art-secrets/

https://www.reddit.com/r/borderlands3/comments/bdmp23/borderlands_3_cover_art_secrets/


Batman: Arkham Origins - Spoiler Bonus!

https://www.reddit.com/r/BatmanArkham/comments/90kyou/i_just_realized_there_was_a_secret_hatch_in_the/


God of War - cloth map secret!

https://www.polygon.com/2018/4/27/17291916/god-of-war-secret-puzzle-cloth-map-muspelheim



GTA 5 - collector's edition map UV light secrets

https://www.reddit.com/r/GrandTheftAutoV/comments/1muxss/specialcollectors_edition_map_with_all_uv_light/



The secret of the INSIDE collector's edition

https://kotaku.com/the-contents-of-the-secret-375-inside-collector-s-edit-1840398301



Assassin's Creed: Valhalla - Isu words on the collector's edition packaging

https://kotaku.com/assassin-s-creed-valhalla-players-figured-out-how-to-l-1846144288

https://youtu.be/ytCakhOlcZg

https://clutchpoints.com/ac-valhalla-fans-solve-big-secret-hidden-collectors-edition/

https://www.ign.com/articles/assassins-creed-valhallas-collectors-edition-mystery-excalibur-nodens-arc-bow-unlock




Undertale Special Edition - secret annoying dog

https://imgur.com/gallery/kPZXWb1




The Bard's Tale -
https://www.news.com.au/technology/home-entertainment/gaming/the-bards-tale-has-a-savage-burn-hiding-on-the-front-of-the-games-disc/news-story/a59b015a71099a50cf3f501d6d02d7d2

 Startropics - 

https://hg101.kontek.net/startropics/startropics.htm  


https://www.reddit.com/r/oneshot/comments/6tjt6t/startropics_nes_came_with_a_letter_containing_a/

https://twitter.com/scully1888/status/970290652117454849/photo/1

