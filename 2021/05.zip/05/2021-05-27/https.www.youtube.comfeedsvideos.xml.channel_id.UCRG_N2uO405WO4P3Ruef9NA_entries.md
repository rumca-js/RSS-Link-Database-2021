# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Google finally rolls out Fuchsia
 - [https://www.youtube.com/watch?v=CgcvkDrTcns](https://www.youtube.com/watch?v=CgcvkDrTcns)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-05-28 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc
You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us. 


▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
►►► This video ◄◄◄

This week, Realme announced a subbrand for it's subbrand, called Dizo to prop up its Realme TechLife portfolio, Microsoft announced a new, Snapdragon powered developer kit, a "Mac Mini", and Google finally brough Fuchsia to a real device: the Nest Hub!

Episode 49

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   


Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-google-finally-rolls-out-fuchsia

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
►►► Other TechAltar links ◄◄◄

Merch: http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 

https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
►►► Attributions & Time stamps◄◄◄

Music by Edemski: 
https://soundcloud.com/edemski 


0:00 Intro
0:39 Release Monitor
1:52 Realme's new brand: Dizo
4:07 Microsoft builds
7:27 Fuchsia is here!

