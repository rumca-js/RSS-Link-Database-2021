# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Buying a Sex Doll
 - [https://www.youtube.com/watch?v=Skj39KcKMOA](https://www.youtube.com/watch?v=Skj39KcKMOA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-05-27 00:00:00+00:00

It looks oddly familiar. Sure sex is great but have you thought about subscribing? Also please go check out Christian's channel here @ChristianNat and give them a sub while you're at it!

Join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

Written by: Julie Nolke
Actors: Christian Smith & Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

