# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## John Danaher on Making Jiu-Jitsu More Palatable to Watch
 - [https://www.youtube.com/watch?v=PnW7Ymnchdw](https://www.youtube.com/watch?v=PnW7Ymnchdw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-28 00:00:00+00:00

Taken from JRE MMA Show #111 w/John Danaher:
https://open.spotify.com/episode/3vFuyfMcitNK9Dl3CqZ1Dh?si=fZpyQUc_RmO8zcrGzdBTFA

## The 3 Things John Danaher Wants to Change About Jiu-Jitsu
 - [https://www.youtube.com/watch?v=2BFG_B1u470](https://www.youtube.com/watch?v=2BFG_B1u470)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-28 00:00:00+00:00

Taken from JRE MMA Show #111 w/John Danaher:
https://open.spotify.com/episode/3vFuyfMcitNK9Dl3CqZ1Dh?si=fZpyQUc_RmO8zcrGzdBTFA

## Alexander Volkanovski on Upcoming Brian Ortega Fight
 - [https://www.youtube.com/watch?v=HUY4KHahkVI](https://www.youtube.com/watch?v=HUY4KHahkVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-27 00:00:00+00:00

Taken from JRE MMA Show #110 w/Alexander Volkanovski & Craig Jones:
https://open.spotify.com/episode/6atedcK3693PQFiWh2AFom?si=l0Uj8q8OTxmTXwmx-l42sg

