# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Bill Gates gets divorced
 - [https://www.youtube.com/watch?v=PzG_D2dHqyA](https://www.youtube.com/watch?v=PzG_D2dHqyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-05-27 00:00:00+00:00

Go to https://nordvpn.com/Flashgitz or use code Flashgitz to get a 2-year plan plus 1 additional month with a huge discount.

Patreon ►
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

Boards ►
Jake Smith

Roughs ► 
Curt Collins

Cleanup ► 
Ollie Kremer
Caleb Jordann

Lip Sync ► 
Lewis Bown

Backgrounds ►  
Soured Apple https://www.twitter.com/SouredApple
Naav Draws

Sound ► 
Justin Greger

Music ► 
Tom Ryan

Ad Compositing ► 
Oddest of the Odd

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/b5ekXbK

