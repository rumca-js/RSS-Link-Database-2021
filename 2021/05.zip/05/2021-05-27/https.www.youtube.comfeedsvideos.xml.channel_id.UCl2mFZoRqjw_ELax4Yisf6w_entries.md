# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## An important question
 - [https://www.youtube.com/watch?v=XmtohaQiA80](https://www.youtube.com/watch?v=XmtohaQiA80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-05-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
Credit to  patriot03062 for the scriptwriting. 
🔵 https://www.theinformation.com/articles/apple-took-three-years-to-cut-ties-with-supplier-that-used-underage-labor
🔵 https://www.bloomberg.com/news/articles/2021-05-20/microsoft-and-apple-wage-war-on-gadget-right-to-repair-laws

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Humblebragging gone too far
 - [https://www.youtube.com/watch?v=SaBLa8U0chw](https://www.youtube.com/watch?v=SaBLa8U0chw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-05-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.marketwatch.com/story/im-49-my-wife-is-34-we-have-4-kids-and-2-3-million-saved-i-earn-300k-a-year-but-lose-a-lot-of-sleep-worrying-about-tomorrow-when-can-i-retire-11621991357

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Tesla replaces radar w/ nothing, kneecaps functionality; be aware when taking delivery of your car!
 - [https://www.youtube.com/watch?v=ROeTm1sxeFI](https://www.youtube.com/watch?v=ROeTm1sxeFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-05-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
Tesla removed radar from the lower end models. As a result, you lose a lot of the functionality of autopilot. Since it often takes a few weeks from the time you order the car to the time you take delivery, it is very possible you could've bought a model 3 or Y when they still had radar, but pick up a car that has no radar. 

When you go to take delivery, they will have you sign a waiver that you are ok with not having radar, which comes with decreased functionality - even though the car costs the SAME AMOUNT OF MONEY. 

Feel free to do whatever you wish - but I think you should be informed before you make your decision. I am a total noob and would 100% fall for something like this if I were presented with some fine print shit to sign at time of delivery and be very pissed when I realized that I didn't get what I paid for. 

🔴 https://europe.autonews.com/automakers/tesla-loses-us-designation-some-advanced-safety-features
🔴 https://www.bloomberg.com/opinion/articles/2021-05-23/cars-are-about-to-get-a-lot-more-expensive-thanks-to-inflation-other-costs
🔴 https://jalopnik.com/teslas-removing-radar-for-semi-automated-driving-on-mod-1846976679
🔴 https://twitter.com/talesftf/status/1397799057234567169/photo/1

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

