# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Chcieli mi ukraść 37 tysięcy złotych! Dlaczego czasami to się udaje?
 - [https://www.youtube.com/watch?v=o_rxgLXPBMc](https://www.youtube.com/watch?v=o_rxgLXPBMc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-05-27 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/
👉 https://niebezpiecznik.pl/

7 maja odebrałem telefon, z którego wynikało, że moje pieniądze mogą być zagrożone. Z jakiegoś powodu postanowiłem, że będę udawał, iż w to wierzę...

🎞 Moja rozmowa z Piotrem:
https://youtu.be/IQL3YoZxNso

🎞 Film Niebezpiecznika
https://www.youtube.com/watch?v=SbCcmLqmQSs

🎞 Cała nagrana rozmowa z oszustem
https://youtu.be/cNN74ZKkcCc

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 Co to za film?
1:10 (H) Telefon z 7 maja
6:30 (H) Dzięki czemu powstał ten film
10:00 (N) Dlaczego scamy czasami działają?
13:28 (N) Uwierz we mnie!
17:01 (N) Dowód społeczny i inne
20:24 (P) Ekspert się ze mną ochoczo zgadza
23:03 (N) Co takiego jest w nas?
24:30 (N) Dobrostan psychiczny
26:26 (N) Wiek
27:49 (N/P) Bycie internautą nas nie chroni
29:15 (N) Efekt Krugera-Dunninga
32:00 (P) Słabe punkty okiem eksperta
37:58 (H) Pierwszy scenariusz
59:46 (P) Co by było...
1:01:32 (H) Scenariusz numer dwa
1:07:25 (H) Scenariusz trzeci
1:12:41 (H) Próba czwarta
1:19:18 (P) Jak się nie dać?
1:23:49 (H) WIELKI FINAŁ

===
Wybrane źródła:

G. Norris i in. -  The Psychology of Internet Fraud Victimisation: a Systematic Review
M. Buton i in. -  Online Frauds: Learning From Victims Why They Fall For These Scams
B. Orbach i in. - Con Men and Their Enablers: The Anatomy of Confidence Games
https://www.consumerreports.org/money/science-of-scams/
https://www.scienceofscams.com/
https://niebezpiecznik.pl/post/jak-internetowi-zlodzieje-okradaja-bankowe-konta-polakow/
https://www.welivesecurity.com/2018/10/19/scams-and-flaws-why-we-get-duped/
[Opracowanie] The psychology of scams: Provoking and committing errors of judgement 
R. A. Judges i in. - The Role of Cognition, Personality, and Trust in Fraud Victimization in Older Adults
https://www.corporatecomplianceinsights.com/psychology-phishing-victims-overcome/

