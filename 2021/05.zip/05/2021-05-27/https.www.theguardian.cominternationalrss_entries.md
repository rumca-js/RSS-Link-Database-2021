# Source:The Guardian - International, URL:https://www.theguardian.com/international/rss, language:en-US

## Every mass shooting in the US – a visual database
 - [https://www.theguardian.com/us-news/ng-interactive/2021/may/27/us-mass-shootings-database](https://www.theguardian.com/us-news/ng-interactive/2021/may/27/us-mass-shootings-database)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2021-05-27 13:13:14+00:00

<p>A normal day in the US involves a mass shooting. Here, we track the incidents since 2014</p> <a href="https://www.theguardian.com/us-news/ng-interactive/2021/may/27/us-mass-shootings-database">Continue reading...</a>

