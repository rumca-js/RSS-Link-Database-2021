# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Apple Has a Slavery Problem
 - [https://www.youtube.com/watch?v=5yqRZo4usjk](https://www.youtube.com/watch?v=5yqRZo4usjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-05-27 00:00:00+00:00

Apple is the largest tech company in the world and puts the heaviest burden on manufacturers with horrible labor practices. This needs to be stopped.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:

Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Sources
Apple's integration in China https://www.nytimes.com/2021/05/17/technology/apple-china-censorship-data.html
Apple suppliers using forced labor
https://www.washingtonpost.com/technology/2020/12/29/lens-technology-apple-uighur/
https://www.washingtonpost.com/technology/2020/11/20/apple-uighur/
https://www.nytimes.com/2020/11/29/business/economy/nike-coca-cola-xinjiang-forced-labor-bill.html
https://news.yahoo.com/multiple-apple-suppliers-accused-using-182539740.html
https://www.techtransparencyproject.org/articles/apples-employee-uniforms-tied-forced-labor-xinjiang
https://goodelectronics.org/seven-apple-suppliers-linked-to-uyghur-forced-labour/
https://www.nationalreview.com/news/china-forces-hundreds-of-thousands-of-uyghurs-to-work-in-xinjiang-cotton-fields-report/
https://dailycaller.com/2020/09/14/chinese-uighur-muslim-forced-reeducation-camps-concentration-camps-forced-labor-goods-suspended/
Labor law violations
https://www.businessinsider.com/apple-halts-business-with-iphone-assembler-after-labour-abuses-2020-11
https://www.businessinsider.com/apple-foxconn-breaking-chinese-labor-law-2019-9
https://www.theverge.com/2020/12/9/22166286/apple-china-labor-violations-temporary-workers
India workers strike against Apple factory https://timesofindia.indiatimes.com/city/bengaluru/violence-breaks-out-at-wistron-corps-iphone-manufacturing-plant-near-bengaluru/articleshow/79691511.cms
https://www.reuters.com/article/india-wistron-workers/violence-at-apple-supplier-in-india-fuels-fears-of-further-worker-unrest-idusl4n2iv1df
Apple lobbying against stopping forced labor products https://news.yahoo.com/apple-spent-90-000-lobbying-205737686.html


Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

