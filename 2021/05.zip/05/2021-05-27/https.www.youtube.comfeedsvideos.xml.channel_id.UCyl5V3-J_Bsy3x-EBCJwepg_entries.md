# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Kissing Chickens, A Hollywood Conservative, And Blue Checks
 - [https://www.youtube.com/watch?v=fhlwgCljJD4](https://www.youtube.com/watch?v=fhlwgCljJD4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-05-28 00:00:00+00:00

In this Bee Weekly, Kyle and Ethan are joined by Adam Yenser, a writer on The Ellen Show and a Republican in Hollywood who has inexplicably not been canceled yet. The CDC has new guidelines about kissing chickens for some reason and we talk about real things blue checks on Twitter say. There’s the usual weird news of the week, unexpected love mail, glorious hate mail, and more!

Check out Adam Yenser on YouTube: https://www.youtube.com/user/adamyenser

Subscribe on iTunes: https://podcasts.apple.com/us/podcast ...

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com​​​​

Follow The Babylon Bee:
Website: https://babylonbee.com​​​​
Twitter: http://twitter.com/thebabylonbee​​​​
Facebook: http://facebook.com/thebabylonbee​​​​
Instagram: http://instagram.com/thebabylonbee​

