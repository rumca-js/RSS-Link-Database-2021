# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Global disinformation
 - [https://www.youtube.com/watch?v=AoSHkuc0hp8](https://www.youtube.com/watch?v=AoSHkuc0hp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-05-27 00:00:00+00:00

Mystery anti-Pfizer campaign offer

https://www.bbc.co.uk/news/world-europe-57250285

Several French social media influencers

Mysterious financial offer to spread negative publicity about Pfizer vaccine

Leo Grasset on YT

https://www.youtube.com/watch?v=dSlh4ONU01M

Colossal budget was offered

from a client who wants to remain incognito

address the agency appeared to be bogus

LinkedIn profiles of the agency's alleged employees he had managed to find later disappeared

he noticed that everybody there has worked in Russia

Present the material as your own independent view

false claim, Pfizer deaths 3 times that of AstraZeneca

Et Ça Se Dit Médecin, offered €2,050 ($2,510; £1,775) for a 30-second story on his account

European External Action Service 

The European External Action Service is the diplomatic service and combined foreign and defence ministry of the European Union.

https://euvsdisinfo.eu/eeas-special-report-update-short-assessment-of-narratives-and-disinformation-around-the-covid-19-pandemic-update-december-2020-april-2021/

Disinformation around the COVID-19 pandemic, measures taken to contain it and vaccine roll-out campaigns continues to be significant. 

vaccine-related disinformation increased and contributed to spreading fear and mistrust in any type of vaccine.

since the beginning of 2021 state-sponsored disinformation also intensified, targeting in particular Western-developed vaccines.

Russia and China, in particular, continue to intensively promote their own state-produced vaccines around the world. 

is combined with disinformation and manipulation efforts to undermine trust in Western-made vaccines, EU institutions and Western/European vaccination strategies. 

Both Russia and China are using state-controlled media, networks of proxy media outlets and social media, including official diplomatic social media accounts, to achieve these goals. 

Viral origins

https://www.foxnews.com/politics/fauci-not-convinced-covid-19-developed-naturally

Q, Katie Sanders

are you still confident that it developed naturally?

A, Dr Fauci

No actually 

I am not convinced about that

I think we should continue to investigate what went on in China until we continue to find out to the best of our ability what happened

Certainly, the people who investigated it say it likely was the emergence from an animal reservoir that then infected individuals

but it could have been something else, and we need to find that out

WHO-convened global study of origins of SARS-CoV-2: China Part

https://www.who.int/publications/i/item/who-convened-global-study-of-origins-of-sars-cov-2-china-part

Team of 17 international experts

Unknown animal species, very likely

Lab-leak idea extremely unlikely

Imported on frozen food

President Biden

https://www.washingtonpost.com/world/2021/05/27/wuhan-lab-theory-evidence/

U.S. intelligence community does not believe there is sufficient information on different scenarios

asking the U.S. intelligence community to redouble its efforts

partner with like-minded partners around the world to press China to participate in a full, transparent, evidence-based international investigation

World Health Assembly, calls to significantly expand upon the WHO-backed investigation

Open letter

https://science.sciencemag.org/content/372/6543/694.1

greater clarity about the origins of this pandemic is necessary and feasible to achieve 

We must take hypotheses about both natural and laboratory spillovers seriously until we have sufficient data. 

A proper investigation should be transparent, objective, data-driven, inclusive of broad expertise, subject to independent oversight

theories of accidental release remained viable

