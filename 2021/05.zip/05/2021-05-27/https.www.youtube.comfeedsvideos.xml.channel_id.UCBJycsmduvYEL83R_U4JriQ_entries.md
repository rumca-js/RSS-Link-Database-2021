# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Ford F150 Lightning Impressions: Better Than I Thought!
 - [https://www.youtube.com/watch?v=J2npVg9ONFo](https://www.youtube.com/watch?v=J2npVg9ONFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-05-28 00:00:00+00:00

Exclusive hands-on with the electric F150 Lightning pickup truck that Ford just unveiled! This or Cybertruck?

Cybertruck First Impressions: https://youtu.be/oTZ84U-K_5k

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

