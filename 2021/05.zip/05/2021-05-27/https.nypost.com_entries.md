## Black Lives Matter co-founder Patrisse Cullors resigns amid controversy
 - [https://nypost.com/2021/05/27/black-lives-matter-co-founder-patrisse-cullors-resigns-amid-controversy/](https://nypost.com/2021/05/27/black-lives-matter-co-founder-patrisse-cullors-resigns-amid-controversy/)
 - RSS feed: https://nypost.com
 - date published: 2021-05-27 19:16:44+00:00

Black Lives Matter co-founder Patrisse Cullors resigns amid controversy

