# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Analysis: This is how dangerous right-wing media actually is
 - [https://www.cnn.com/2021/05/27/politics/far-right-media-conspiracies-trump-qanon-poll/index.html](https://www.cnn.com/2021/05/27/politics/far-right-media-conspiracies-trump-qanon-poll/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 23:07:22+00:00

One of the many noxious developments of Donald Trump's presidency was the rise of several cable TV outlets that aimed to out-Fox Fox News.

## Thousands flee Goma as threat of another volcanic eruption looms
 - [https://www.cnn.com/2021/05/27/africa/drc-volcano-eruption-goma-evacuation-intl/index.html](https://www.cnn.com/2021/05/27/africa/drc-volcano-eruption-goma-evacuation-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 19:12:22+00:00

Tens of thousands of people are trying to escape the Congolese city of Goma after authorities issued an evacuation order warning that the Mount Nyiragongo volcano could erupt again.

## Senate Minority Leader asks for 'personal favor' to block commission that would investigate Capitol insurrection
 - [https://www.cnn.com/2021/05/27/politics/mcconnell-personal-favor-block-january-6-commission/index.html](https://www.cnn.com/2021/05/27/politics/mcconnell-personal-favor-block-january-6-commission/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 18:27:15+00:00

In the last 24 hours, Senate Minority Leader Mitch McConnell has ramped up the pressure on his GOP Senate colleagues to oppose a bill creating a January 6 commission, according to two Republicans familiar with his effort.

## McConnell doubles down to pressure Republicans, asking for 'a personal favor' to block Jan. 6 commission
 - [https://www.cnn.com/collections/capitol-riot-vote-intl-052721/](https://www.cnn.com/collections/capitol-riot-vote-intl-052721/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 17:55:58+00:00



## Russian authorities deny entry to European airlines as EU mulls sanctions on Belarus
 - [https://www.cnn.com/2021/05/27/europe/belarus-airlines-sanctions-intl/index.html](https://www.cnn.com/2021/05/27/europe/belarus-airlines-sanctions-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 17:43:28+00:00

The European Union is mulling fresh sanctions against Belarus in the wake of what EU leaders have described as the state-sanctioned hijacking of a passenger flight over Belarus last Sunday.

## Senate GOP expected to block vote on riot commission
 - [https://www.cnn.com/2021/05/27/politics/senate-vote-january-6-commission/index.html](https://www.cnn.com/2021/05/27/politics/senate-vote-january-6-commission/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 17:29:31+00:00

Senate Republicans are expected to block on Thursday a bill creating a commission to investigate the pro-Trump riot at the US Capitol on January 6, which left five dead and about 140 police officers injured.

## Longtime White House butler retiring after 47 years of service
 - [https://www.cnn.com/2021/05/27/politics/william-carter-white-house-butler/index.html](https://www.cnn.com/2021/05/27/politics/william-carter-white-house-butler/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 16:58:13+00:00

After four decades, William "Buddy" Carter -- one of the longest serving White House butlers -- is set to retire at the end of the week, three people familiar with the matter tell CNN.

## Deadly cyclone batters India's east coast
 - [https://www.cnn.com/videos/weather/2021/05/27/cyclone-yaas-india-ctw-ldn-intl-sot-vpx.cnn](https://www.cnn.com/videos/weather/2021/05/27/cyclone-yaas-india-ctw-ldn-intl-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 16:47:04+00:00

CNN's Becky Anderson reports that Cyclone Yaas has killed at least three people and left tens of thousands homeless after the storm hit villages on India's east coast.

## Architects plan world's second-tallest tower in Russia
 - [https://www.cnn.com/style/article/kettle-collective-tower-russia-scli-intl-gbr/index.html](https://www.cnn.com/style/article/kettle-collective-tower-russia-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 16:22:52+00:00

A Scottish architecture firm has released plans for the second-tallest skyscraper in the world to be built in St. Petersburg, Russia.

## Jewish House Democrats reference Greene and some progressives in concerns over uptick in anti-Semitism incidents
 - [https://www.cnn.com/2021/05/27/politics/congress-reaction-anti-semitism/index.html](https://www.cnn.com/2021/05/27/politics/congress-reaction-anti-semitism/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:56:03+00:00

A group of Democratic House members who are Jewish are calling on President Joe Biden to address a rise in anti-Semitic incidents in the US amid a divide within congressional Democrats, especially between moderate and progressives, on how to address the Israeli-Palestinian conflict.

## Big Oil suffered three big blows
 - [https://www.cnn.com/2021/05/27/investing/stocks-week-ahead/index.html](https://www.cnn.com/2021/05/27/investing/stocks-week-ahead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:51:45+00:00

Big Oil suffered a trio of unprecedented defeats on Wednesday as investors and climate activists used shareholder votes and the courts to press for much greater urgency in rescuing the planet from a climate catastrophe.

## Ariana Grande shares photos from her wedding at home
 - [https://www.cnn.com/2021/05/27/entertainment/ariana-grande-wedding-trnd/index.html](https://www.cnn.com/2021/05/27/entertainment/ariana-grande-wedding-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:42:55+00:00

Ariana Grande has shared a glimpse into her intimate wedding to real estate agent Dalton Gomez earlier this month.

## Rolls-Royce will now build you any car you want, but it'll cost you. A lot
 - [https://www.cnn.com/2021/05/27/success/rolls-royce-coachbuild-custom-car/index.html](https://www.cnn.com/2021/05/27/success/rolls-royce-coachbuild-custom-car/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:39:36+00:00

If you have the money -- and if Rolls-Royce executives like your idea -- the British ultra-luxury carmaker will build you the car of your dreams.

## Macron seeks forgiveness for France's role in Rwanda genocide, but stops short of apology
 - [https://www.cnn.com/2021/05/27/africa/rwanda-france-genocide-macron-forgiveness-intl/index.html](https://www.cnn.com/2021/05/27/africa/rwanda-france-genocide-macron-forgiveness-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:32:20+00:00

French President Emmanuel Macron publicly acknowledged France's "overwhelming responsibility" in the 1994 genocide in Rwanda and said only the survivors could give "the gift of forgiveness."

## Paul Ryan to enter GOP's civil war by criticizing Trump's hold on party
 - [https://www.cnn.com/collections/us-elections-intl-052721/](https://www.cnn.com/collections/us-elections-intl-052721/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:28:03+00:00



## Monkeys change 'accents' when under social and environmental pressure
 - [https://www.cnn.com/2021/05/27/americas/primate-calls-study-scli-intl-scn/index.html](https://www.cnn.com/2021/05/27/americas/primate-calls-study-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:18:22+00:00

If you've ever changed your behavior due to social pressure, it appears you're not alone.

## Growing storm over Covid's origin may have massive consequences
 - [https://www.cnn.com/collections/intl-coronavirus-0526/](https://www.cnn.com/collections/intl-coronavirus-0526/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:15:45+00:00



## Jennifer Aniston and David Schwimmer reveal they had feelings for each other while filming 'Friends'
 - [https://www.cnn.com/2021/05/27/entertainment/friends-reunion-jennifer-aniston-david-schwimmer-feelings-trnd/index.html](https://www.cnn.com/2021/05/27/entertainment/friends-reunion-jennifer-aniston-david-schwimmer-feelings-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:13:27+00:00

Everyone who watched the sitcom "Friends" was hoping that Ross and Rachel, played by David Schwimmer and Jennifer Aniston, would ride off into the sunset and live happily ever after.

## Earliest known war driven by climate change, researchers say
 - [https://www.cnn.com/2021/05/27/africa/violence-war-climate-jebel-sahaba-scn/index.html](https://www.cnn.com/2021/05/27/africa/violence-war-climate-jebel-sahaba-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:12:59+00:00

The 61 human skeletons unearthed in the Nile Valley in the 1960s in what is now Sudan have long been regarded as the earliest evidence of organized warfare between humans.

## How will the GOP handle its Marjorie Taylor Greene problem?
 - [https://www.cnn.com/videos/politics/2021/05/27/gop-marjorie-taylor-greene-problem-cillizza-the-point.cnn](https://www.cnn.com/videos/politics/2021/05/27/gop-marjorie-taylor-greene-problem-cillizza-the-point.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 15:01:09+00:00

Marjorie Taylor Greene continues to shock and offend many Americans with her latest comments comparing life under Covid-19 to living in Nazi Germany, but will these remarks force GOP leadership to actually hold her accountable? In this latest episode of The Point, CNN's Chris Cillizza explains why Republicans are not likely to punish MTG anytime soon.

## New York to raffle off 50 full-ride college scholarships to vaccinated 12 to 17-year-olds
 - [https://www.cnn.com/2021/05/27/us/new-york-vaccine-raffle-trnd/index.html](https://www.cnn.com/2021/05/27/us/new-york-vaccine-raffle-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 14:51:12+00:00

New York plans to award 50 full scholarships to vaccinated young people as part of an effort to encourage children between 12 and 17 to get their Covid-19 vaccinations.

## It's getting more likely the world will reach a climate tipping point in the next five years
 - [https://www.cnn.com/2021/05/27/world/climate-temperatures-increase-wmo-intl/index.html](https://www.cnn.com/2021/05/27/world/climate-temperatures-increase-wmo-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 14:22:52+00:00

The likelihood that the earth's average temperature will at least temporarily breach a crucial tipping point is rising, according to the world's leading weather and climate organization.

## Silicon Valley is in a high-stakes standoff with India
 - [https://www.cnn.com/2021/05/27/tech/whatsapp-twitter-india-hnk-intl/index.html](https://www.cnn.com/2021/05/27/tech/whatsapp-twitter-india-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 13:59:14+00:00

The biggest names in tech are locked in an increasingly tense stand-off with India over strict new social media rules they fear will erode privacy, usher in mass surveillance and harm business in the world's fastest growing market.

## John Davis, real Milli Vanilli singer, dies from Covid aged 66
 - [https://www.cnn.com/2021/05/27/entertainment/john-davis-milli-vanilli-scil-intl/index.html](https://www.cnn.com/2021/05/27/entertainment/john-davis-milli-vanilli-scil-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 13:57:27+00:00

John Davis, one of the true singers behind notorious R&amp;B act Milli Vanilli, has died of coronavirus aged 66, according to his family.

## Critical race theory is a lens. Here are 11 ways looking through it might refine your understanding of history
 - [https://www.cnn.com/2021/05/27/us/critical-race-theory-lens-history-crt/index.html](https://www.cnn.com/2021/05/27/us/critical-race-theory-lens-history-crt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 13:44:50+00:00

Critical race theory is just that -- a theory -- but the term has been weaponized, with its most extreme critics alleging that merely studying the theory is racist.

## Airship to offer low-carbon flights with floor-to-ceiling windows
 - [https://www.cnn.com/travel/article/hybrid-air-vehicles-airship-scli-intl-gbr/index.html](https://www.cnn.com/travel/article/hybrid-air-vehicles-airship-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 13:38:49+00:00

Growing awareness of the climate crisis means conscientious travelers are increasingly looking for alternatives to trips by airplane.

## A Sikh man incarcerated in Arizona was forced to shave his beard against his religion. Advocacy groups want to ensure that doesn't happen to anyone else
 - [https://www.cnn.com/2021/05/27/us/sikh-man-incarcerated-arizona-shave-beard-trnd/index.html](https://www.cnn.com/2021/05/27/us/sikh-man-incarcerated-arizona-shave-beard-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 13:29:44+00:00

In his more than 60 years, Surjit Singh never once cut, trimmed or shaved his hair or his beard.

## Uber drivers win their first ever unionization deal
 - [https://www.cnn.com/2021/05/27/tech/uber-union-uk/index.html](https://www.cnn.com/2021/05/27/tech/uber-union-uk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 13:25:05+00:00

Uber has recognized a labor union for the first time in a move that could boost efforts by gig economy workers to win better employment rights.

## Stephen Hawking's archive and office acquired by UK cultural giants
 - [https://www.cnn.com/2021/05/27/uk/stephen-hawking-archive-scli-scn-intl/index.html](https://www.cnn.com/2021/05/27/uk/stephen-hawking-archive-scli-scn-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 11:26:25+00:00

Two major cultural institutions in Britain have obtained renowned physicist Stephen Hawking's office and archive in a £4.2 million ($5.9 million) deal on behalf of the country.

## Civil rights groups sue West Virginia over new anti-trans sports bill
 - [https://www.cnn.com/2021/05/27/politics/federal-lawsuit-west-virginia-anti-trans-sports-bill/index.html](https://www.cnn.com/2021/05/27/politics/federal-lawsuit-west-virginia-anti-trans-sports-bill/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 11:13:03+00:00

Civil rights groups filed a federal lawsuit Wednesday challenging West Virginia's new anti-trans sports law, arguing that the measure banning transgender girls and women from participating in school sports unconstitutionally "discriminates on the basis of sex and transgender status."

## Could a British aircraft carrier fill a Pacific gap for the US Navy?
 - [https://www.cnn.com/2021/05/27/asia/us-navy-aircraft-carriers-afghanistan-pacific-intl-hnk/index.html](https://www.cnn.com/2021/05/27/asia/us-navy-aircraft-carriers-afghanistan-pacific-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 10:19:18+00:00

United States Navy commanders face a potential shortfall in their Asia sea power in the coming weeks as tensions simmer with China in the region's waters.

## Inside fractured relationship between Capitol Police and Congress
 - [https://www.cnn.com/2021/05/27/politics/fractured-relationship-capitol-police-members-of-congress-jan-6/index.html](https://www.cnn.com/2021/05/27/politics/fractured-relationship-capitol-police-members-of-congress-jan-6/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 10:14:46+00:00

In the weeks after the January 6 riot, Capitol Police officers were shell-shocked and wounded, both physically and psychologically. They'd been through hell, they'd sacrificed their bodies, they'd lost colleagues who died as a result of the attack. But in the end they had safeguarded democracy and upheld their primary directive: Secure and protect the 535 members of Congress.

## 'Perpetual foreigner': Photos explore Asian American belonging in everyday spaces
 - [https://www.cnn.com/style/article/andrew-kung-perpetual-foreigner-hyphenated/index.html](https://www.cnn.com/style/article/andrew-kung-perpetual-foreigner-hyphenated/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 10:09:25+00:00

Andrew Kung was a teenager visiting New York when he was first called a racial slur.

## Man United star received 'at least 70 racial slurs' on social media following Europa League defeat
 - [https://www.cnn.com/2021/05/27/sport/marcus-rashford-racist-abuse-europa-league-final-spt-intl/index.html](https://www.cnn.com/2021/05/27/sport/marcus-rashford-racist-abuse-europa-league-final-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 10:08:36+00:00

Forward Marcus Rashford has said he has received "at least 70 racial slurs" on social media following Manchester United's Europa League defeat to Villarreal on Wednesday.

## US holds 'candid' talks with China as tensions grow
 - [https://www.cnn.com/2021/05/27/economy/us-china-trade-talks-intl-hnk/index.html](https://www.cnn.com/2021/05/27/economy/us-china-trade-talks-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 09:39:54+00:00

President Joe Biden's top trade negotiator spoke for the first time with her Chinese counterpart by phone on Wednesday. It's a sign that Washington and Beijing may be ready to pick trade talks back up, even as relations between the two remain tense.

## San Francisco returns disputed religious artifacts to Thailand
 - [https://www.cnn.com/style/article/san-francisco-thailand-lintels/index.html](https://www.cnn.com/style/article/san-francisco-thailand-lintels/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 09:35:39+00:00

A pair of 1,000-year-old religious relics, which US investigators say were illegally taken from Thailand, have been returned after more than five decades.

## With Olympics nearing, Japan considers extending coronavirus state of emergency
 - [https://www.cnn.com/collections/intl-tokyo-olympics-052721/](https://www.cnn.com/collections/intl-tokyo-olympics-052721/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 09:06:51+00:00



## She suffered from depression after the Olympics. Then it 'all boiled over'
 - [https://www.cnn.com/2021/05/27/sport/raven-saunders-olympics-shot-put-spt-intl-cmd/index.html](https://www.cnn.com/2021/05/27/sport/raven-saunders-olympics-shot-put-spt-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 08:06:47+00:00

It was January 26, 2018 when Raven Saunders hit rock bottom.

## The gunman picked which coworkers he killed in San Jose, a witness says
 - [https://www.cnn.com/collections/san-jose-shooting-intl-052621/](https://www.cnn.com/collections/san-jose-shooting-intl-052621/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 06:51:36+00:00



## White woman sues over termination after calling police on a Black man in Central Park
 - [https://www.cnn.com/2021/05/26/us/amy-cooper-lawsuit-fired/index.html](https://www.cnn.com/2021/05/26/us/amy-cooper-lawsuit-fired/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 03:52:59+00:00

Amy Cooper, who was fired last May after she was videotaped calling police on a Black birdwatcher in New York City's Central Park, is suing her former employer, claiming it did not adequately investigate the incident.

## Ambassador denied entry as writer faces China espionage trial
 - [https://www.cnn.com/2021/05/26/china/china-australia-yang-hengjun-trial-intl-hnk/index.html](https://www.cnn.com/2021/05/26/china/china-australia-yang-hengjun-trial-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 03:40:29+00:00

Australia's ambassador to China was denied entry to a heavily guarded Beijing court on Thursday where the espionage case against Australian blogger Yang Hengjun will be heard at a time of worsening ties between the two nations.

## Hear what Dr. Gupta has to say on origin of Covid-19
 - [https://www.cnn.com/videos/health/2021/05/27/gupta-covid-origins-intv-cpt-sot-vpx.cnn](https://www.cnn.com/videos/health/2021/05/27/gupta-covid-origins-intv-cpt-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 02:33:47+00:00

CNN's Dr. Sanjay Gupta and Chris Cuomo discuss if we are any closer to finding out where and how Covid-19 originated.

## The EU's hypocrisy on China is becoming clear
 - [https://www.cnn.com/2021/05/26/europe/european-union-china-trade-intl-cmd/index.html](https://www.cnn.com/2021/05/26/europe/european-union-china-trade-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 02:25:59+00:00

The European Union has a China problem. The bloc, for financial and strategic reasons, wants to build strong economic ties with Beijing that bolster Brussels' desire to be a serious player on the world stage as the leading light of Western values.

## Report: US companies may have benefited from forced labor of Uyghurs
 - [https://www.cnn.com/videos/world/2021/05/26/uyghur-congressional-report-jake-tapper-dnt-lead-vpx.cnn](https://www.cnn.com/videos/world/2021/05/26/uyghur-congressional-report-jake-tapper-dnt-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-27 00:39:19+00:00

CNN's Jake Tapper looks into a Congressional report that shows how US companies may have benefited from forced labor of Uyghur Muslims.

