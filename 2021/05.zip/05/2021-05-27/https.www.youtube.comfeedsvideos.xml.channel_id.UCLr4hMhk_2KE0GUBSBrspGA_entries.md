# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## ZTE Axon 30 Ultra - wyróżnij się, albo zgiń!
 - [https://www.youtube.com/watch?v=NKCdbZiLqJY](https://www.youtube.com/watch?v=NKCdbZiLqJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-05-27 00:00:00+00:00

Z jednej strony klasyczna konstrukcja, z drugiej świetny ekran i wiele ciekawych rozwiązań. Nie jest to smartfon dla wszystkich, ale na pewno warto zwrócić na niego uwagę. 
Axon 30 Ultra na stronie ZTE: https://bit.ly/3yyioFA
Moje Sociale: 
Insta: https://www.instagram.com/kubaklawiter/
Twitter: https://twitter.com/KubaKlawiter

Spis treści:
00:00 Zakup nowego smartfona - poradnik
00:25 Smartfon firmy produkującej modemy i routery?
01:15 ZTE Axon 30 Ultra – ekran
01:42 Głośniki
02:17 Obiektywy i możliwości foto/video
04:42 Stabilizacja
05:36 Selfie – przedni aparat
06:09 Czytnik linii papilarnych
06:15 Ładowanie
06:22 Zawartość pudełka
06:51 System Snapdragon 888
07:24 Nakładka dla lubiących kontrolę
07:34 Aktualizacje systemów w smartfonach
09:01 Cena
09:12 Czy ZTE to nowy „zabójca flagowców”?
09:36 Podsumowanie
10:14 Zapowiedź recenzji hulajnogi UNAGI
10:36 Pożegnanie

