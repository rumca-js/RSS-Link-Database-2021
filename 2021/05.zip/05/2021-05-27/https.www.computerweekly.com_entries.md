## NGOs file complaints against Clearview AI in five countries | Computer Weekly
 - [https://www.computerweekly.com/news/252501435/NGOs-file-complaints-against-Clearview-AI-in-five-countries](https://www.computerweekly.com/news/252501435/NGOs-file-complaints-against-Clearview-AI-in-five-countries)
 - RSS feed: https://www.computerweekly.com
 - date published: 2021-05-27 19:23:24+00:00

NGOs file complaints against Clearview AI in five countries | Computer Weekly

