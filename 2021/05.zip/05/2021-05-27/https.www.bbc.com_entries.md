## Microsoft president: Orwell’s 1984 could happen in 2024
 - [https://www.bbc.com/news/technology-57122120](https://www.bbc.com/news/technology-57122120)
 - RSS feed: https://www.bbc.com
 - date published: 2021-05-27 20:19:38+00:00

Microsoft president: Orwell’s 1984 could happen in 2024

