# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 22 Things You Didn't Know about Resident Evil Village
 - [https://www.youtube.com/watch?v=4wWlWZ5ru4o](https://www.youtube.com/watch?v=4wWlWZ5ru4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-28 00:00:00+00:00

Resident Evil's 8th installment, Resident Evil Village, is filled with hidden secrets, Easter eggs, and references to previous Resident Evil games. But, did you find them all? Let's go through 22 Things You Didn't Know in Resident Evil Village.

## 9 Minutes Of New Far Cry 6 Gameplay
 - [https://www.youtube.com/watch?v=pQwfNEF6cY8](https://www.youtube.com/watch?v=pQwfNEF6cY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-28 00:00:00+00:00

Come visit tropical Yara!

An island filled with beautiful flora, stunning vistas, friendly locals and of course interesting wildlife!

In this slice of Far Cry 6 gameplay we get to see a little of what we can expect when the game releases on October 7th, 2021. Highlights of course being good wee pals of the scaly and furry variety.

## Far Cry 6 - Everything You Need To Know So Far
 - [https://www.youtube.com/watch?v=t9TDippYaHo](https://www.youtube.com/watch?v=t9TDippYaHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-28 00:00:00+00:00

Far Cry 6 has murder alligators, weapons made of junk, and special super moves powered by gear items--it’s about as crazy as you’d expect for a Far Cry game. Here’s everything we know so far about the upcoming Far Cry 6. 

Far Cry 6 is set to release October 7th, 2021 and Ubisoft revealed some new details about the game’s extensive weapon and vehicle systems. In this video, you’ll learn about the new weapon categories including the Regular, Resolver, and Supremos. According to the devs, there are 49 guns in the game that range from leftover revolutionary weapons like the SKS and M16 to over-the-top homebrew varieties like a minigun built from motorcycle parts, and a CD launcher that that plays Macarena. Far Cry 6 also sees the return of pets, two of which are an aggressive alligator named Guapo and a cute Weiner dog named Chorizo, who is lethal in its own way.

The island of Yara itself has been isolated for fifty years and has a number of biomes like swamps, towns, jungles, and cities with skyscrapers and underground areas. To travel around players can expect a variety of options including guerilla trails, horses, Mad-Max-style technicals, and even a tank. Flying over the island will be limited until Anti Aircraft batteries are destroyed. Players can also expect many of Far Cry’s usual activities including taking over bases and engaging in side-activities with different characters. 

As we approach E3 2021 and a new Ubisoft Forward event in June, we expect to learn a lot more about the plot of Far Cry 6, the motivation for its main villain Anton Castillo, who is played by actor Giancarlo Esposito. We also hope to learn a lot more about how his son Diego may or may not succumb to the dictator and his brutal tactics. Make sure to keep checking back in at GameSpot.com for our Play For All event as the gaming industry's biggest trade show of the year, E3 2021, happens this June.

## Far Cry 6 Gameplay Reveal Livestream
 - [https://www.youtube.com/watch?v=u8qRp2JwvQc](https://www.youtube.com/watch?v=u8qRp2JwvQc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-28 00:00:00+00:00

Tune in on Friday, May 28th at 9:30 PT for the first look at Far Cry 6 gameplay.

Far Cry 6 is set to release October 7th, 2021!

## Dying Light 2 Stay Human - Official Gameplay Trailer
 - [https://www.youtube.com/watch?v=RJGdMGRAjVA](https://www.youtube.com/watch?v=RJGdMGRAjVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-27 00:00:00+00:00

Check out the all new Dying Light 2 Stay Human official gameplay trailer developed by Techland. Dying Light 2 Stay Human is the long awaited sequel to the original Dying Light which built a massive following and hardcore fan base.

## Horizon Forbidden West Gameplay Breakdown | State of Play
 - [https://www.youtube.com/watch?v=aK46bAv6NEs](https://www.youtube.com/watch?v=aK46bAv6NEs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-27 00:00:00+00:00

Guerilla Game Developers breakdown some of the gameplay elements you'll encounter while playing Horizon Forbidden West. You'll get a taste of some of the weapons you can use to defeat your foes, as well as some gameplay mechanics that will elevate combat. We got to watch 14 minutes of gameplay revealed during Sony's State of Play for Horizon Forbidden West.

## Horizon Forbidden West Gameplay Reveal | State of Play
 - [https://www.youtube.com/watch?v=3PIzTl2xo2o](https://www.youtube.com/watch?v=3PIzTl2xo2o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-27 00:00:00+00:00

Check out the all new Horizon Forbidden West Gameplay revealed during the Sony State of Play event!

## Horizon Forbidden West Gameplay Reveal | State of Play
 - [https://www.youtube.com/watch?v=RGlByi_BSio](https://www.youtube.com/watch?v=RGlByi_BSio)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-27 00:00:00+00:00

Tune in to a special State of Play, showing off the first look at gameplay for Horizon Forbidden West.

## Resident Evil Village Mercenaries Mode with MANvsGAME On An 85-Inch TCL TV
 - [https://www.youtube.com/watch?v=d8TsmScmslI](https://www.youtube.com/watch?v=d8TsmScmslI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-27 00:00:00+00:00

(Presented by TCL) Kurt is joined by the one and only MANvsGAME as they try out Mercenaries Mode while playing on a massive 85-Inch TCL TV!

## Sonic Central 30th Anniversary Livestream
 - [https://www.youtube.com/watch?v=Fth61_AVBcw](https://www.youtube.com/watch?v=Fth61_AVBcw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-27 00:00:00+00:00

Tune in to Sonic Central, a virtual event where SEGA’s Sonic team will be joined by special guests to reveal upcoming projects, partnerships and events spanning the Sonic the Hedgehog franchise and beyond.

Check out some all new announcements in the Sonic universe!

