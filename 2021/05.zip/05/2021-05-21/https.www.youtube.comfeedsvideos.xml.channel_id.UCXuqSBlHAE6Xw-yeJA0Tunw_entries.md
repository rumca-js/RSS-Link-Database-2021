# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## What Happens if you Water Cool an Air Cooler?
 - [https://www.youtube.com/watch?v=u6zsHqdNRQ8](https://www.youtube.com/watch?v=u6zsHqdNRQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-22 00:00:00+00:00

Celebrate FlexiSpot's Day from May 24-30, 2021! UP to 35% OFF! 
FlexiSpot Kana Bamboo Standing Desk US: https://bit.ly/3y51U7E, $10 OFF exclusive coupon code: Linus10 

UK: https://bit.ly/3vgEhqr   
CAN: https://bit.ly/2R4FYcr 

Enter to win one of three desks courtesy of FlexiSpot at https://lmg.gg/FlexiSpot (US/Canada only, ends May 29th)

Get your .TECH domain and help children get their start in computer science at: https://go.tech/LTT

Enctec made this motherboard for passive cooling applications, but we has a different idea...

Check out Enctec: https://www.enctec.com.tw/rev-%E4%B8%BB%E6%A9%9F%E6%9D%BF

Buy Intel i7-6700K CPU (PAID LINK): https://geni.us/BL8j7Z

Buy Noctua NH-D15 chromax.Black CPU Cooler (PAID LINK): https://geni.us/JisS

Buy G.SKILL Trident Z Royal RAM (PAID LINK): https://geni.us/NAm4i

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1340591-water-cooling-an-air-cooler/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Water cooling w/ bottle
0:13 Where is the socket?
0:52 .tech
1:07 Intro
1:17 Why does this mobo exist?
3:51 Building a computer but it feels weird
8:23 Testing the passive cooler
9:54 Hello Steve
9:59 Oh no
10:32 lttstore.com shout out
10:35 The dunk
11:29 We realized a clear bin would be better for video
12:45 Thermal imaging is cool
13:34 INGREDIENTS: WATER/EAU (Below 0C)
17:09 FlexiSpot
17:57 End card

## Apple's 40-Core Desktop is Coming! - WAN Show May 21, 2021
 - [https://www.youtube.com/watch?v=v_DOqdyZEG0](https://www.youtube.com/watch?v=v_DOqdyZEG0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-21 00:00:00+00:00

Get a $100 60-day credit on your new account at: http://linode.com/wan

Buy the CORSAIR Virtuoso RGB Wireless XT at https://geni.us/FWcQW
On Amazon (PAID LINK): https://geni.us/Tz9fbvJ

Get your virtual desktop today at https://lmg.gg/ShellsWAN

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Apples-40-Core-Desktop-is-Coming----WAN-Show-May-21--2021-e11io0s

Check out Other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of StarsMarsRadio)
0:00    Intro/Topics
1:39    Sponsors
1:53    Apple topics
3:51    Tangent into comments and Apple leading industry trends
9:30    Back to new Apple products
16:00  Airpods max doesn't support Apple's lossless quality
23:00  Dr. Ian Cutress corrects DRAM market terminology
32:17  Sponsors
35:14  TV's aren't cheap anymore & Silicon shortage
40:44  Sweaty boy discount
42:15  AMD is working on 5000 refresh
43:50  Bitcoin is down, Crypto topics
46:40  Ford F150 Lightning
51:09  Ford Lightning vs Cybertruck poll
56:06  Superchats
58:20  Bill C10
1:03:43  Throwback
1:05:51  Bye

