# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## HTC Vive Tracker 2.0 vs 3.0 vs Tundra Tracker VR Full Body Tracking TESTED
 - [https://www.youtube.com/watch?v=yGEDeecFIOk](https://www.youtube.com/watch?v=yGEDeecFIOk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-05-22 00:00:00+00:00

Hello! Here is my test of the much anticipated Vive Tracker 3.0 and Tundra Tracker VS the old faithful Vive tracker 2.0. I love full body tracking in VR and I want more people to  get into it! In case you're interested in any of these tracker or you know someone else that is interested you should send this video over to clear up any confusion.

My links: 






Affiliate Links:
https://amzn.to/3oEbXw8
https://amzn.to/2T0VSF5

Tundra Tracker links:
https://www.kickstarter.com/projects/tundralabs/tundra-tracker

Video credit:
https://www.youtube.com/watch?v=ok9fMhULFWg
https://www.youtube.com/watch?v=J54dotTt7k0

