# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Why Flying Cars Are A Bad Idea
 - [https://www.youtube.com/watch?v=3nGmKv-tCyo](https://www.youtube.com/watch?v=3nGmKv-tCyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-05-22 00:00:00+00:00

Flying cars are cool right? No. They are not. Let me tell you why they are not cool. Because they are not. They are not cool.

New Channel: https://www.youtube.com/c/Whimsu
Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
secret: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

Additional Video Credits:
Neilogical
Aaron Cortez
Venatus Vox
TheAppMedia
British Pathé
Old Curmudgeon
paralleler
Klowood
Ina Lutterbüse
Business Insider
TheDriver
SIMULIA
Niks V
dtmhncot
AutoMojo
WatchMojo.com
Collectors;Essentials
ACE Wind Tunnel
Canale25
British Pathé

