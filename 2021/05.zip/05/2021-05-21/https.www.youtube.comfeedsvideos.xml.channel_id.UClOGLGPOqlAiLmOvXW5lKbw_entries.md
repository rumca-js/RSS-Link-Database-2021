# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Pathfinder: Kingmaker Review
 - [https://www.youtube.com/watch?v=MR-1t28ngkk](https://www.youtube.com/watch?v=MR-1t28ngkk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2021-05-21 00:00:00+00:00

Pathfinder Kingmaker has an enhanced edition, enhanced plus edition, and definitive edition and I don't know which is which so this is just everything they put out at once.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/mandaloregaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
00:14 - The Pathfinder Setting
01:25 - Character Creation
03:24 - Visuals
05:34 - Sound
08:15 - Adventuring Gameplay
12:10 - Kingdom Management
16:34 - Questing & Story
21:33 - Bugs
22:03 - DLC
23:18 - Conclusions
24:15 - Credits
25:20 - Serstan Returns

#Pathfinder #PathfinderKingmaker #PathfinderReview #PathfinderKingmaker #PathfinderPC

