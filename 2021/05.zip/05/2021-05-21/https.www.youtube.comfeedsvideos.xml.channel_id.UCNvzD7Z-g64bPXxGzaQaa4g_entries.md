# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 GENIUS HIDDEN MECHANICS in Video Games You Can't See
 - [https://www.youtube.com/watch?v=qKUeoxA5uAs](https://www.youtube.com/watch?v=qKUeoxA5uAs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-22 00:00:00+00:00

Some video games use brilliant tricks behind the scenes to make games satisfying. Here are some more of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


Sources and examples: 


https://twitter.com/Gaohmee/status/903510060197744640

https://www.reddit.com/r/Games/comments/6xqtgz/an_insightful_thread_where_game_developers/dmi33u8/

https://www.youtube.com/watch?v=Nt1XmiDwxhY


https://screenrant.com/dodge-offset-bayonetta-nier-metal-gear-rising-platniumgames/

## TAKE-TWO HAS 60 UPCOMING GAMES, NEXT GOD OF WAR INSPIRED BY LAST OF US 2?, & MORE
 - [https://www.youtube.com/watch?v=bbzz0jhVXdI](https://www.youtube.com/watch?v=bbzz0jhVXdI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-21 00:00:00+00:00

Go to https://www.expressvpn.com/gameranx and find out how you can get 3 months of ExpressVPN free!


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake’s other channel:
https://youtu.be/2mY-cLx2_iQ



 ~~~~STORIES~~~~



Next God of War inspiration:
https://www.gamesradar.com/god-of-war-ragnarok-artist-theorizes-how-playable-atreus-would-function/
Podcast: https://youtu.be/2JEI2ec1jr4

Timesplitters returns:
https://www.theverge.com/2021/5/20/22445699/timesplitters-free-radical-design-deep-silver

TAKE-TWO bunch of games
https://www.windowscentral.com/take-two-plans-release-over-60-games-2024
https://www.playstationlifestyle.net/2021/05/19/gta-345-million-sales/GTA in November: https://www.videogameschronicle.com/news/rockstar-confirms-gta-v-ps5-xbox-series-xs-release-for-november/


**Great GTA PS5 video: https://youtu.be/cIHzkjyJbUs



Overwatch changes
https://www.comingsoon.net/games/news/1174784-overwatch-2-team-size-decrease

Starfield rumor suggests 2022
https://www.eurogamer.net/articles/2021-05-20-starfield-release-date-reportedly-late-2022


Pinocchio dark souls
https://youtu.be/5a5JZVf0Xsk

Mario Golf: Super Rush Overview Trailer
https://www.youtube.com/watch?v=5R-EuaUbPvc&t=222s

Normandy in No Man’s Sky
https://youtu.be/VlHBalpdcWM

Call of Duty 80’s heroes
https://youtu.be/5dfcqhYYrJE

Ratchet and Clank: https://youtu.be/PVbfS-e9VHI

Back 4 Blood
https://www.youtube.com/watch?v=CddJQwQbg90

LA Noire
https://www.hollywoodreporter.com/business/digital/l-a-noire-10-video-game-mad-men-4160607/


Biomutant
PS5: https://www.youtube.com/watch?v=O0ilfPo_BSI&t=130shttps://www.youtube.com/watch?v=O0ilfPo_BSI&t=130s
Series X: https://www.youtube.com/watch?v=v7l9Hedk5uo
PC: https://www.youtube.com/watch?v=GgjNf0upii0
PS4 Pro and Xbox One X: https://www.youtube.com/watch?v=wRMrDZc4qLQ&t=29s
PS4 and Xbox One: https://www.youtube.com/watch?v=vXtyhpeayc8

