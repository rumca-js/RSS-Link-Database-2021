# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Army of the Dead - Movie Review
 - [https://www.youtube.com/watch?v=kcSmC7oD1Qw](https://www.youtube.com/watch?v=kcSmC7oD1Qw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-05-21 00:00:00+00:00

Zack Snyder brings us his return to the zombie apocalypse genre in the form of a heist movie. Here's my review of ARMY OF THE DEAD!

#ArmyOfTheDead

