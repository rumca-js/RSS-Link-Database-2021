# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## "Mr. Jones" Backlash Made Adam Duritz Self Conscious
 - [https://www.youtube.com/watch?v=LtRrmr20-hY](https://www.youtube.com/watch?v=LtRrmr20-hY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-21 00:00:00+00:00

Taken from JRE #1656 w/Adam Duritz:
https://open.spotify.com/episode/1PqOUIXVMb53AEd2Vngsae?si=BzwgK6rvSkqPKIv3kkkxjg

## How Adam Duritz Ended Up Bartending at the Viper Room
 - [https://www.youtube.com/watch?v=nX-ir6Jgjus](https://www.youtube.com/watch?v=nX-ir6Jgjus)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-21 00:00:00+00:00

Taken from JRE #1656 w/Adam Duritz:
https://open.spotify.com/episode/1PqOUIXVMb53AEd2Vngsae?si=BzwgK6rvSkqPKIv3kkkxjg

## Sebastian Junger's Scary Near Death Experience
 - [https://www.youtube.com/watch?v=caK7O-T6rJE](https://www.youtube.com/watch?v=caK7O-T6rJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-21 00:00:00+00:00

Taken from JRE #1655 w/Sebastian Junger:
https://open.spotify.com/episode/6TGyUCq1MQrLEkKnAmRmL3?si=0fZfSdOlR2uWo84Haa76_Q

## The Genius of Robin Williams
 - [https://www.youtube.com/watch?v=f2IrPgff1bM](https://www.youtube.com/watch?v=f2IrPgff1bM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-21 00:00:00+00:00

Taken from JRE #1655 w/Sebastian Junger:
https://open.spotify.com/episode/6TGyUCq1MQrLEkKnAmRmL3?si=0fZfSdOlR2uWo84Haa76_Q

