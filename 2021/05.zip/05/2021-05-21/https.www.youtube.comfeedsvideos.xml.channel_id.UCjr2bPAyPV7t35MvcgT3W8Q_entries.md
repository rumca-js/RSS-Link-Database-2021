# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Exposing Tesla's Insane Data Mining Operation
 - [https://www.youtube.com/watch?v=vcu2YUCa0lA](https://www.youtube.com/watch?v=vcu2YUCa0lA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-05-21 00:00:00+00:00

Emulating the Big Tech, Tesla is on its path to become a global automobile monopoly. If Musk's plans play out according to his strategy, Tesla might become the only available option for the majority of people.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Sources

Tesla is not trying to sell you a self-driving car. Once all the technology and relevant regulation is ready, Tesla’s main revenue will come from renting self-driving taxis. Once Tesla’s vision is fully realized, owning a car will be reserved to a small minority class of people. And there is no other company closer to reaching that vision than Tesla.

Plenty of mainstream car companies have entered the autonomous and electric vehicle sphere. But none of them has the Tesla advantage. In 2016, about the time when other companies where just starting out with autopilot, Tesla already collected more than 1.3 billion miles of data from all kinds of real world scenarios, diverse roads and global weather conditions with regular people at the wheel. Their next competitor, Google’s Waymo, only covered 2 million miles since 2009, all with employees on board.

The rate at which Tesla gathers more data is also unparalleled. By 2020, Tesla’s mileage with autopilot activated passed 3 billion. Waymo, on the other hand, only collected 20 million miles in autopilot. That’s Tesla leading by more than a factor of 100. Tesla is competing with other car companies but Tesla is not just a car company. It’s also an energy company, a charging company, a software company and most importantly a data company. 

Footage of Tesla's "vision" feed:
https://www.youtube.com/c/Carscoopscom/
https://www.youtube.com/user/greentheonly/ 


Sources
The Tesla Advantage https://www.bloomberg.com/news/articles/2016-12-20/the-tesla-advantage-1-3-billion-miles-of-data
Tesla's Data Engine https://www.braincreators.com/brainpower/insights/teslas-data-engine-and-what-we-should-all-learn-from-it
Tesla Data Collection:
https://www.tesla.com/about/legal
https://www.axios.com/what-tesla-knows-about-you-1f21d287-a204-4a6e-8b4a-0786b0afac45.html
https://www.zimlon.com/b/comprehensive-list-of-data-tesla-collects-from-their-customers-cm529/
https://electrek.co/2020/10/24/tesla-collecting-insane-amount-data-full-self-driving-test-fleet/
https://electrek.co/2017/05/06/tesla-data-sharing-policy-collecting-video-self-driving/
https://electrek.co/2017/06/14/tesla-autopilot-data-floodgates/
https://electrek.co/2020/04/22/tesla-autopilot-data-3-billion-miles/
https://www.consumerreports.org/privacy/teslas-in-car-cameras-raise-privacy-concerns/
https://fortune.com/2015/10/16/how-tesla-autopilot-learns/
Mobility as a Service https://www.cio.com/article/3433931/tesla-the-data-company.html
https://digital.hbs.edu/platform-digit/submission/tesla-a-data-driven-future/
https://www.consumerreports.org/automotive-technology/who-owns-the-data-your-car-collects/

Federated learning https://ai.googleblog.com/2017/04/federated-learning-collaborative.html
Homomorphic encryption https://www.microsoft.com/en-us/research/publication/cryptonets-applying-neural-networks-to-encrypted-data-with-high-throughput-and-accuracy/

https://www.zdnet.com/article/tesla-deters-owners-from-picking-unofficial-providers-to-boost-car-performance/
https://www.cnet.com/roadshow/news/elon-musk-tesla-autopilot-price-subscription/

On vertical market integration https://www.mckinsey.com/business-functions/strategy-and-corporate-finance/our-insights/when-and-when-not-to-vertically-integrate

Open Source battle:
https://www.zdnet.com/article/tesla-starts-to-release-its-cars-open-source-linux-software-code/
https://www.theregister.com/2018/05/21/tesla_inches_toward_gpl_compliance/
https://gizmodo.com/it-only-took-six-years-but-tesla-is-no-longer-screwing-1826191876
https://sfconservancy.org/blog/2019/oct/30/calling-all-tesla-owners/

Tesla in China https://www.bloomberg.com/news/features/2021-01-13/china-loves-elon-musk-and-tesla-tsla-how-long-will-that-last

Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA


Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

