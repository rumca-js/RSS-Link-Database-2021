# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## iPhone 12 Restoration - Almost Impossible
 - [https://www.youtube.com/watch?v=tKPQ0OFClIc](https://www.youtube.com/watch?v=tKPQ0OFClIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-05-22 00:00:00+00:00

Here we go again...
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Tools I Use: https://www.hughjeffreys.com/tools

Get parts, tools, and thousands of free repair guides from iFixit at: 
                               https://iFixit.com/hughjeffreys
Australian Store: https://ifix.gd/2FPxhKy

Laser Machine: https://bit.ly/2Od5OJ7
-----------------------------------References-----------------------------------
Apple Repairs Scores: https://support.apple.com/fr-fr/circular-economy-repairability-indices

French Repair Index: https://www.ifixit.com/News/49158/france-gave-apple-some-repairability-homework-lets-grade-it
---------------------------------------------------------------------------------------

(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

