# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Answering Patron Questions and Playing Piano
 - [https://www.youtube.com/watch?v=8GW8XrnePdY](https://www.youtube.com/watch?v=8GW8XrnePdY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-05-21 00:00:00+00:00

Patreon Q and A for May 2021, the year of the trial-sized Dove Bar. Also, the state of the channel, what the last year has been like as a full-time creator, and more.

00:00 State of the channel
07:26 This is Really Happening tattoo story?
10:36 What / who influenced your sense of humor?
13:01 Commitment, specialization, vs. generalization?
18:15 Do you like your voice? 
21:18 First track you ever made?
22:25 Video game?
23:00 Does limitation breed creativity?
27:45 How do you restrain yourself from adding too many parts into a song?
32:06 Do you enjoy collaboration in making music? 
34:24 Dragons or eldritch horrors?
34:38 How do you balance interesting onboard effects of the hardware synth vs. adding effects in the DAW?
35:52 What is your favorite thing to put in yogurt?
37:07 How do you manage your sample library?
36:33 If you could rescore a movie in your own way, what movie would it be and why? 
39:48 Deep house music using modular: a fool's errand?
41:55 Do you do sound design sessions only?
43:13 What's in your burrito?
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

