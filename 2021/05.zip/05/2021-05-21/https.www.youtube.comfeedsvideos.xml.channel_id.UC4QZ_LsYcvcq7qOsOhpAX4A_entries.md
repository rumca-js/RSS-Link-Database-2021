# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## When Greed Goes Too Far - The Worldcom Fraud
 - [https://www.youtube.com/watch?v=u_rfIboPyYs](https://www.youtube.com/watch?v=u_rfIboPyYs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-05-21 00:00:00+00:00

Become smarter in 5 minutes by signing up for free today: http://cen.yt/mbcoldfusion9 - Thanks to Morning Brew for sponsoring today’s video/

ColdFusion Discord:  https://discord.gg/3WWKmzqMPY

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.referenceforbusiness.com/history2/10/MCI-WorldCom-Inc.html#ixzz6rUgavnRY
https://www.nbcnews.com/id/wbna3072795
https://knowledge.wharton.upenn.edu/article/what-went-wrong-at-worldcom/
https://www.theguardian.com/business/2002/aug/09/corporatefraud.worldcom2
https://www.pcmag.com/encyclopedia/term/worldcom
https://www.cfo.com/accounting-tax/2008/01/the-big-lie/
https://stars.library.ucf.edu/cgi/viewcontent.cgi?article=2106&context=honorstheses1990-2015
http://etd.fcla.edu/CF/CFH0003811/Ashraf_Javiriyah_201105_BSBA
https://www.sec.gov/Archives/edgar/data/723527/000093176303001862/dex991.htm
https://danielsethics.mgt.unm.edu/pdf/worldcom-case.pdf
https://www.youtube.com/watch?v=hlrmuTRUI1U


My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Sublab - So In Love

Andre Sobota - Concluded

Sonic Future - Remember That 

BUCK UK - Once

Kubix - Run Away (Azaleh Remix)

Sangam & Cholombian - Shelter Me

Jonatan TS - Lost In The Mountains

Julianna Barwick - Look Into Your Own Mind
Burn Water - The Final Push 

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

