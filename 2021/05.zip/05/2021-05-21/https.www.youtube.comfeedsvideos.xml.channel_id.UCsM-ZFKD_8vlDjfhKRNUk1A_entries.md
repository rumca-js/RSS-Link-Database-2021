# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Prezes na Eurowizję (lyric video) - Koncert Krzyczeń w MUZO.FM
 - [https://www.youtube.com/watch?v=YH6yyqvagVg](https://www.youtube.com/watch?v=YH6yyqvagVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2021-05-21 00:00:00+00:00

Pierwsza propozycja na przyszłoroczną edycję Eurovision Song Contest 2022. Zjawiskowy szlagier Prezesa w produkcji Kamila i Milana. Tańcz Polsko!

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

