# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## MADERA - bezludna wyspa, której nie chcieli odkrywcy. Też nie lubią lewad?! 🙄 Madera 3/4
 - [https://www.youtube.com/watch?v=hNFy_BVf2aw](https://www.youtube.com/watch?v=hNFy_BVf2aw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-05-22 00:00:00+00:00

Dzięki za tak liczny odbiór pierwszego odcinka z Madery. Jeszcze nigdy  żaden odcinek nie poszedł tak dobrze jak ten i trochę  mam presję, że ciężko będzie mi go przebić w kolejnych filmach z Madery. Ale spróbujmy :D

Dzisiaj powiemy sobie w końcu co to są te Lewady, pośmiejemy się z Cristiano Ronaldo, a także pójdziemy na najładniejsza trasę jaką odwiedziłem na Maderze - na szczyć Pico Grande.

Wpis praktyczny o Maderze i ciekawych miejscach https://kolemsietoczy.pl/madera-co-zobaczyc-ciekawe-miejsca-przewodnik-maderze/

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

0:00 Madera - drugie starcie!
0:17 Historia Madery
1:58 Lewady na Maderze
6:28 Odkrywcy i historia Madery
8:36 Co łączy Cristiano Ronaldo i Józefa Piłsudskiego?
10:29 Jazda po Maderze na wiklinowych saniach
12:47 Madera, ciekawe miejsca...
15:43 Boca da Corrida i Pico Grande

