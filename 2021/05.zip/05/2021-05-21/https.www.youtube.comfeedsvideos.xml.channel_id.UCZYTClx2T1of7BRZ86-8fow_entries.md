# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Oxygen Enemas Could Save Lives
 - [https://www.youtube.com/watch?v=azBkMZuqu0c](https://www.youtube.com/watch?v=azBkMZuqu0c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-05-22 00:00:00+00:00

To discover more about Nature’s Fynd, visit https://naturesfynd.com. To learn about their remarkable nutritional fungi protein and fermentation process, visit https://www.youtube.com/watch?v=sodONlWRiE0.

Scientists have known for some time that certain animals can breathe using their butts, but now, researchers have determined that certain mammals can too! And in very much other news, researchers in Washington state have developed a new method for turning waste plastics into something useful!

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.cell.com/med/fulltext/S2666-6340(21)00153-7?utm_source=EA
https://www.phlbi.org/divisions/blood-disorders/artificial-blood
https://www.sciencemag.org/news/2021/05/mammals-can-breathe-through-their-intestines
https://www.eurekalert.org/pub_releases/2021-05/cp-mcu050621.php
https://www.sciencedirect.com/science/article/pii/S2667109321000233?via%3Dihub
https://www.eurekalert.org/pub_releases/2021-05/wsu-ntc051121.php
https://www.sciencenews.org/article/chemistry-recycling-plastic-landfills-trash-materials
https://www.pslc.ws/macrog/pe.htm
https://www.epa.gov/facts-and-figures-about-materials-waste-and-recycling/plastics-material-specific-data

Images:
https://www.inaturalist.org/photos/2794155
https://www.istockphoto.com/photo/human-respiratory-system-lungs-anatomy-gm1250973588-364947615
https://www.istockphoto.com/vector/microvilli-detail-of-the-small-intestine-vector-diagram-gm499566195-42565582
https://www.istockphoto.com/photo/3d-illustration-of-microscopic-closeup-of-intestine-villus-and-s-gm864198560-143297523
https://commons.wikimedia.org/wiki/File:Perfluorodecalin-3D-balls.png
https://www.istockphoto.com/photo/doctor-diagnosing-patient%C3%A2s-health-on-asthma-lung-disease-covid-19-or-bone-cancer-gm1284526816-381629841
https://www.istockphoto.com/photo/plastic-recycling-gm1220250268-357231204
https://www.istockphoto.com/photo/eco-container-with-plastic-bottles-gm1160003427-317388426
https://commons.wikimedia.org/wiki/File:Polyethylene.jpg
https://www.istockphoto.com/photo/ruthenium-ru-periodic-table-gm483116725-38069056
https://www.istockphoto.com/photo/refueling-of-the-passenger-plane-gm636807654-113204903
https://www.istockphoto.com/vector/emoji-in-face-mask-gm1218431320-356033178
https://www.istockphoto.com/vector/isolated-peach-illustration-gm630020582-112280117
https://www.istockphoto.com/photo/pork-butt-on-the-farm-gm629555798-112050109

## What Does a 95% Effective Vaccine Really Mean?
 - [https://www.youtube.com/watch?v=5jMeJjVm5k0](https://www.youtube.com/watch?v=5jMeJjVm5k0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-05-22 00:00:00+00:00

If you've received a vaccine that's 95% effective, that does not mean you have a 5% chance of getting sick. That’s just not how the numbers are calculated. So let’s take a closer look at how it does work, why we can’t compare these numbers between different vaccines, and why that’s ok.

SciShow is supported by Brilliant.org. Go to https://Brilliant.org/SciShow to get 20% off of an annual Premium subscription. 

COVID-19 News and Updates Playlist: https://youtube.com/playlist?list=PLsNB4peY6C6IQediwz2GzMTNvm_dMzr47

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.nejm.org/doi/full/10.1056/NEJMoa2034577 
https://www.nejm.org/doi/full/10.1056/NEJMoa2035389 
https://www.cdc.gov/vaccines/basics/test-approve.html 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2536484/ 
https://clinicaltrials.gov/ct2/show/NCT04505722 
https://www.cdc.gov/coronavirus/2019-ncov/vaccines/different-vaccines/janssen.html 
https://www.thelancet.com/article/S1473-3099(20)30773-8/fulltext 
https://www.cnbc.com/2021/02/28/fauci-all-three-covid-vaccines-highly-effective-urges-people-to-take-available-shot.html 
https://www.nytimes.com/2021/01/29/health/Covid-vaccine-explainer.html 
https://www.cdc.gov/coronavirus/2019-ncov/vaccines/effectiveness.html 
https://www.nature.com/articles/s41591-021-01230-y 

Images:
https://www.istockphoto.com/photo/covid-19-coronavirus-vaccine-vials-in-a-row-macro-close-up-gm1253358164-366005110
https://www.istockphoto.com/photo/irus-covid-19-vaccine-bottle-sars-cov-2-vaccine-batch-3d-rendering-4k-gm1250100089-364498780
https://www.istockphoto.com/photo/pattern-of-vaccine-bottles-against-covid-19-with-injection-fluid-3d-ilustration-gm1293494686-387884983
https://www.istockphoto.com/photo/team-of-medical-staff-in-personal-protective-equipment-walking-in-hospital-corridor-gm1221364621-357980003
https://www.istockphoto.com/photo/a-medical-hand-in-a-glove-holds-an-ampoule-with-a-vaccine-and-a-syringe-with-gm1216812369-354959657

