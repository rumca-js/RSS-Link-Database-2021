# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## El Sonido 10th Anniversary Special
 - [https://www.youtube.com/watch?v=xwF8ClQXHA0](https://www.youtube.com/watch?v=xwF8ClQXHA0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-22 00:00:00+00:00

http://KEXP.ORG is excited to present the El Sonido 10th Anniversary Special! DJ Chilly and Albina will share memories of past in-studio sessions, 13 brand new performances, hellos from artists that have been a part of El Sonido over the years and  exclusive conversations with influential musicians and key figures of music en español – all joined together by a shared passion for Latin music and the community that has powered El Sonido for 10 years.

Thanks to everyone who made these sessions possible in each of the more than 10 countries.

Mula: Agencia Creativa Conuco, El Nido Lab, Costa Futuro, Schubert Music, Raúl Fernández, Zobeida Cruz, Charco Música, Contrapedal Música

Francisca Valenzuela: Alejandra Villalba García, Francisco Sánchez de la Vega, Alejandra Villalba García, Sofía Cravioto

Javiera Mena:  Festival Centro

Juan Wauters: Juan Wauters y Gustavo Miguez

Los Blenders: Alejandra Villalba García, Francisco Sánchez de la Vega, Sofía Cravioto

Hidrogenesse: Hidrogenesse:  Austrohúngaro, Stanley Sunday

Barbi Recanati: Lux Raptos, Juan Manuel Segovia, Tomas Molina Lera, Marilina Bertoldi, Florencia Vaccaro, Tota Romero, Estudio Atomo, Agustina Ruiz Teira

Triángulo de Amor Bizarro: Mushroom Pillow, La Fábrica de Chocolate, Vigo, Aleuto S.L., Carolos Hernández Nombela

Luisa Almaguer: Julián, Rocko

Asimov: Orbital Studio, Luis Alonso (Durísimo Producciones), Phantom Records, Vini Wunderlich

ATALHOS: Brain Productions, Delfina Campos, Artsy Club Studio, José TM, Daniel Barosa, Gustavo Vargas, Tata Leon, Rollinos, Vans Brasil and Rock City Agencia

Yanna: Esteban Marchand, Jess and Ágatha, Trinidad, Javi, Ar13$

Tres Leches + Terror Cactus: Mark Mirabile, Ryan Purcell, Paul Breslin, David Salonen, Alaia D'Alessandro


http://kexp.org

## Lea Porcelain - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=uaalXfERB5c](https://www.youtube.com/watch?v=uaalXfERB5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-22 00:00:00+00:00

http://KEXP.ORG presents Lea Porcelain performing live, recorded exclusively for KEXP.

Songs:
100 Years
Bones
Ohio
Pool Song
I Am Ok

Session recorded at Funkhaus Berlin
DOP & Director: Manuel Ruge & Annemarie Falk
Cameras: Leyla Hoppe, Marcel Riedel, Max Hartmann
Additional Musician (Guitar): Philipp Koch 
Styling: Sara El Hailouli

https://www.leaporcelain.com
https://www.funkhaus-berlin.net
http://kexp.org

## Lea Porcelain - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=VE1v7bHxyXo](https://www.youtube.com/watch?v=VE1v7bHxyXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-21 00:00:00+00:00

http://KEXP.ORG presents Lea Porcelain sharing a live performance recorded exclusively for KEXP and talking to John Richards, host of The Morning Show. Recorded May 12, 2021.

Songs:
100 Years
Bones
Ohio
Pool Song
I Am Ok

Session recorded at Funkhaus Berlin
DOP & Director: Manuel Ruge & Annemarie Falk
Cameras: Leyla Hoppe, Marcel Riedel, Max Hartmann
Additional Musician (Guitar): Philipp Koch 
Styling: Sara El Hailouli

https://www.leaporcelain.com
https://www.funkhaus-berlin.net
http://kexp.org

