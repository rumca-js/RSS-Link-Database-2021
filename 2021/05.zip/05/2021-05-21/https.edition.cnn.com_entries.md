## Covid vaccine profits mint 9 new pharma billionaires | CNN Business
 - [https://edition.cnn.com/2021/05/21/business/covid-vaccine-billionaires/index.html](https://edition.cnn.com/2021/05/21/business/covid-vaccine-billionaires/index.html)
 - RSS feed: https://edition.cnn.com
 - date published: 2021-05-21 20:15:15+00:00

Covid vaccine profits mint 9 new pharma billionaires | CNN Business

