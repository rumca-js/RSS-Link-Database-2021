# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Why Jobs Are Bad For America
 - [https://www.youtube.com/watch?v=-hNWKcuKosY](https://www.youtube.com/watch?v=-hNWKcuKosY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-05-22 00:00:00+00:00

Grab your Blue Light Blocking Glasses at https://blublox.com/jp
Use code "JP" for 15% off

Check out my NEW MERCH here! - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

In this video you watched two idiots discuss why jobs are bad for America. And you will be convinced that the rate of unemployment, people collecting unemployment, and people being unwilling to work should only go up!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

