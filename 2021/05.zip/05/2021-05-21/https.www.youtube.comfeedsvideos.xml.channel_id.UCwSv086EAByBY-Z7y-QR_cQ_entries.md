# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Powstaje Armia Europejska. Przemyślenia i analiza dokumentów
 - [https://www.youtube.com/watch?v=b4-H7rY5Wak](https://www.youtube.com/watch?v=b4-H7rY5Wak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-05-22 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3fd2s4d
2. https://bit.ly/3fCivYi
3. https://bit.ly/3ubl48M
4. https://bit.ly/3hMnurS
5. https://bit.ly/3bPivCW
6. https://bit.ly/3wuvpy2
7. https://bit.ly/3bO8vKh
8. https://bit.ly/3yyLXXC
9. https://bit.ly/3fxMws8
10. https://bit.ly/3yrF6iV
11. https://bit.ly/3yupuLj
12. https://bit.ly/346dzFs
---------------------------------------------------------------
💡 Tagi: #UE #polityka
--------------------------------------------------------------

## Unijne regulacje zastosowań sztucznej inteligencji w dziedzinie nadzoru i identyfikacji
 - [https://www.youtube.com/watch?v=00Gk3MaAktg](https://www.youtube.com/watch?v=00Gk3MaAktg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-05-21 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/2OHblb8
2. https://politi.co/3oElW4T
3. https://bit.ly/2T0Iwss
4. https://bit.ly/3bJbyDF
5. https://bit.ly/2SeOiWZ
6. https://bit.ly/3hEGNU6
---------------------------------------------------------------
💡 Tagi: #KlausSchwab #AI #EU
--------------------------------------------------------------

