# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Windows 10 Major "May Update" - Biggest Changes! (21H1)
 - [https://www.youtube.com/watch?v=-elzBP_q_As](https://www.youtube.com/watch?v=-elzBP_q_As)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-05-21 00:00:00+00:00

Found out what's new!
▼ Links Mentioned ▼
• Enablement Packages ⇨ https://www.tenforums.com/windows-10-news/179561-kb5000736-featured-update-windows-10-version-21h1-enablement-package.html
• Windows Download Page ⇨ https://www.microsoft.com/en-us/software-download/windows10
• Bug Fix List ⇨ https://docs.microsoft.com/en-us/windows/whats-new/whats-new-windows-10-version-21h1

▼ Time Stamps: ▼
0:00 - Intro
1:00 - Getting the Update
3:03 - New Features & Changes

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

