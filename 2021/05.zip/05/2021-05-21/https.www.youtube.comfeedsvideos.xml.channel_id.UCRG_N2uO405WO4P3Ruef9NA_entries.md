# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Google and Samsung finally join forces!
 - [https://www.youtube.com/watch?v=eqTiH23jfzA](https://www.youtube.com/watch?v=eqTiH23jfzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-05-21 00:00:00+00:00

Sponsored by Morning Brew. Sign up for free today: https://bit.ly/2RFjazL

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week, Samsung teamed up with Google to combine WearOS and Tizen into a single smartwatch platform, LeEco announced a comeback into phones and Snapchat launched new spectacles.

Episode 48

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-google-and-samsung-finally-join-forces

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:35 Release Monitor
1:39 Samsung x Google 
5:12 LeEco comeback
6:19 Snapchat spectacles

