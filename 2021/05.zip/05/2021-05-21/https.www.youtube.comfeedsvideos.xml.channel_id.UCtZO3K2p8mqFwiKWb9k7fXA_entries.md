# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## The man behind the world's largest phone empire (the story of BBK)
 - [https://www.youtube.com/watch?v=VIggp85vgZA](https://www.youtube.com/watch?v=VIggp85vgZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2021-05-22 00:00:00+00:00

The Nebula / CuriosityStream bundle is no longer active. Instead, you can sign up for Nebula directly with my discount now for about $2.5 a month with a yearly plan, which includes Nebula Originals AND the whole Nebula Classes platform, too, including my own class. Sign up here: https://go.nebula.tv/techaltar

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► About this video ◄◄◄  

OPPO, Vivo, OnePlus, Realme and IQOO form the BBK group, and they have collectively just become the largest phone maker in the world. In this video we explore their history, their strategy and their mysterious founder, Duan Yongping.  The Story Behind - ep. 76

This episode plus bonus footage on Nebula:  https://nebula.app/videos/techaltar-the-man-behind-the-worlds-largest-phone-empire-the-story-of-bbk

Old BBK and Xiaobawang Ads:
https://www.bilibili.com/video/BV1Dp4y1q7eN?from=search&seid=13280808163191315485
https://www.youtube.com/watch?v=uCUh-EF7Lf4
https://www.youtube.com/watch?v=EIVlkhBGdxk
https://www.bilibili.com/video/BV1o54y1k7NV?from=search&seid=4815589132335212576
https://youtu.be/QUjKKc17dio

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  

Music by Edemski: https://soundcloud.com/edemski

