# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Palantíri: Seeing Stones of Middle-earth | Tolkien Explained
 - [https://www.youtube.com/watch?v=Z9TRcHkUL1w](https://www.youtube.com/watch?v=Z9TRcHkUL1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-05-29 00:00:00+00:00

Since it was first revealed that Saruman was using a palantír in The Lord of the Rings, fans have wondered where these seeing stones came from and where they were located.  Today, we will not only cover their likely creation by the greatest craftsman in Tolkien's mythology, but also how they ended up in Middle-earth and where they were placed!  We know that Saruman, Denethor, Sauron, and Aragorn all use various palantíri during the events of the War of the Ring, but there were originally seven in Middle-earth (plus one in Valinor).  Check out the video to see where each was stationed, how they were lost, and how Sauron came to possess on himself!

*Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!*  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, I highly recommend checking out these amazing artists online!

Ted Nasmith - https://www.tednasmith.com/shop/
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Jenny Dolfen - https://goldseven.wordpress.com/

Palantir of Amon SUl - Donato Giancola
Palantir - Donato Giancola
Saruman the White - Matt DeMino
Feanor and the Silmarils - Bella Bergolts
Haven of the Eldar - Frederic Bennett
Amandil - Turner Mohan
Ar-Pharazon - Steamey
Armenellos - SkullB**tard
Beleriand Map - Lamaarcana
Fall of Numenor - Darrell Sweet
Ships of the Faithful - Ted Nasmith
The Palantir of Elostirion - Matej Cadil
The Tower Hills - Ted Nasmith
Gildor, Sam, Pippin, Frodo, and the Elves - Steamey
Annuminas - Ted Nasmith
Across Middle-earth: Weathertop - Ralph Damiani
Arvedui - Lida Holubova
Blue Palantir - Aitor Fernandez
Aragorn and Palantir - Magali Villeneuve
Red Palantir - Aitor Fernandez
The Seeing Stones of Old Numenor - Beregond
Osgiliath - Abe Papakhian
Pyre of Denethor - Anke Eissmann
The Dark Lord and the Palantir - TheBabyDragons
Minas Ithil - Shadow of War
Minas Morgul - Shadow of War
The Shadow of Sauron - Ted Nasmith
Denethor - Daniel Di
Orthanc in the Second Age - Ted Nasmith
Saruman - Angus McBride
Isengard - Ivan Cavini
Pippin Steals the Palantir - Anke Eissmann
Pippin Looks in the Palantir - Peter Xavier Price
The White Rider - Ralph Damiani
The White Tree - Ted Nasmith
The Arkenstone - Ted Nasmith
Feanor's Last Stand - Jenny Dolfen

#palantir #tolkien #lordoftherings

