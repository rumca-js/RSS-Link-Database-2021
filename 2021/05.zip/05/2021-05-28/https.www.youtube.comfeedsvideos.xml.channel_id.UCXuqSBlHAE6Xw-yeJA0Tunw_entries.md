# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Android 12 is here and I like it
 - [https://www.youtube.com/watch?v=B5FDeNog_2A](https://www.youtube.com/watch?v=B5FDeNog_2A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-29 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Get 15% off the ModMic Wireless and other ModMic products at https://antlionaudio.com/pages/linustalktips

At their I/O conference this year, the Google team announced Android 12 and along with it, a massive redesign with loads of new personalization settings, privacy features, and performance improvements for your device... and this time you can actually try it on non-Pixel devices!


Buy Google Pixel 6: https://geni.us/j41UU0N

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1342739-android-12-is-here-and-i-like-it/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:00 Material You & Color Extraction
1:55 New Animations & Lock Screen
2:30 Homescreen & Quick Settings
4:03 New Gestures
4:39 Performance & Backend Improvements
5:35 Privacy
7:21 Rapid Fire
8:43 Conclusion

## AMD's New CPU Socket Just Leaked! - WAN Show May 28, 2021
 - [https://www.youtube.com/watch?v=-4u8_6TJPiQ](https://www.youtube.com/watch?v=-4u8_6TJPiQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-28 00:00:00+00:00

Enter PDFelement Giveaway: https://bit.ly/3422y8f 
Download PDFelement: https://bit.ly/2Q8u6FD
Buy PDFelement with 50% off: https://bit.ly/2RDM8QK

Pre Order your Anker Nano II Charger today: https://lmg.gg/rN4pD

Get your .TECH domain and help children get their start in computer science at: https://go.tech/WAN

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/AMDs-New-CPU-Socket-Just-Leaked----WAN-Show-May-28--2021-e11trq4

Check out Other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Vulcānus)
0:00    Intro and Topics
3:06    AMD AM5, LGA, DDR5 and DDR4
11:43  PCIE Gen 5, Intel Alder Lake
19:49  PGA to LGA for AMD
23:20  Facebook sues India
32:23  Bill C10
35:21  Super chats
__
38:30 Sponsors
Anker Nano II Charger,  PDFelemnent, .TECH Domains
__
40:42  Personal stories of early interactions with tech
42:45  DinoPark Tycoon
43:57  USB C 2.1
46:45  LTT Store, new shirt
47:49  Winget
54:33  New version of Windows incoming
58:25  Steam leaks and hardware
59:55  Amazon "ZenBooth"
1:06:31  16gb iPads
1:06:55  Super chats
1:08:46  Scrapyard wars/PCMR
1:14:58  Birds
1:15:59  His hands...they are diamond
1:19:01  Beat sabre bet
1:21:46  Bye

