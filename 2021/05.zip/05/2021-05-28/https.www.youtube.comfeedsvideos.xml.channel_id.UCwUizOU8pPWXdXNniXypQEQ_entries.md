# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What Health Authorities Are Like in 2021
 - [https://www.youtube.com/watch?v=2_kwFKAmd8M](https://www.youtube.com/watch?v=2_kwFKAmd8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-05-29 00:00:00+00:00

Grab your Red Light Therapy Device and other Blublox Products at https://blublox.com/jp
Use code "JP" for 15% off

Check out my NEW MERCH here! - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

What health authorities are like in 2021. Receiving information from figureheads that are your trusted health authorities and taking it on blind faith is the highest recommendation in 2021. Here’s what that enlightened experience is like.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

