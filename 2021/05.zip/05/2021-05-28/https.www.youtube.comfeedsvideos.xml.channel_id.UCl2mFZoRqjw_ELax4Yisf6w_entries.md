# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## How Clinton the cat could save Right to Repair
 - [https://www.youtube.com/watch?v=C00T0Q8ieIw](https://www.youtube.com/watch?v=C00T0Q8ieIw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-05-29 00:00:00+00:00

https://tinyurl.com/rossmatrix
11:56 is where the revelation comes in.
🔵 Greenies: https://amzn.to/2OSpiRZ

## Senior data recovery manager DUNKS on junior board repair tech, has him MALDING!
 - [https://www.youtube.com/watch?v=chRLKM2_5HY](https://www.youtube.com/watch?v=chRLKM2_5HY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-05-29 00:00:00+00:00

https://tinyurl.com/rossmatrix

## The power of lobbying
 - [https://www.youtube.com/watch?v=JUUGxEZhGeI](https://www.youtube.com/watch?v=JUUGxEZhGeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-05-29 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.thedrive.com/tech/40779/tesla-will-have-to-ship-its-texas-built-cars-out-of-state-to-sell-back-to-residents

https://repair.wiki/w/Repair_Wiki

https://discord.gg/UdHsPtv2ru

