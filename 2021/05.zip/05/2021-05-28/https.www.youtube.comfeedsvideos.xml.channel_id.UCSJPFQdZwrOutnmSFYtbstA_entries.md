# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Highlander Doesn't Need A Remake
 - [https://www.youtube.com/watch?v=fsDofmtMQzI](https://www.youtube.com/watch?v=fsDofmtMQzI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-05-29 00:00:00+00:00

Highlander, the classic 1986 action fantasy starring Christopher Lambert and Sean Connery, is apparently getting a modern remake. Why? Don't know. Join me as I review this awesome movie, and explain why they got it right first time around.

