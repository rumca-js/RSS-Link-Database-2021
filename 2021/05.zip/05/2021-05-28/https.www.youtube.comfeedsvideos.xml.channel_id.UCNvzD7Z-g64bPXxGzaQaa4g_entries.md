# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 CRAZY Things You UNLOCK Only After Finishing The Game
 - [https://www.youtube.com/watch?v=AmYvv_0BgCo](https://www.youtube.com/watch?v=AmYvv_0BgCo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-29 00:00:00+00:00

Some games give you incredible rewards for finishing the game. Here are some of the craziest, over the top postgame unlocks.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## FIRST UNREAL ENGINE 5 USER CREATION IS MIND BLOWING, HORIZON FORBIDDEN WEST GAMEPLAY, & MORE
 - [https://www.youtube.com/watch?v=4bNc_bUIWcA](https://www.youtube.com/watch?v=4bNc_bUIWcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-28 00:00:00+00:00

Thanks to Dr. Squatch for sponsoring. New Dr. Squatch customers can get 20% off on orders of $20 or more when they go to https://bit.ly/3rFioA3

Big Xbox and PS5 news, Far Cry 6 revealed, Sonic and JRPG stuff, new Valve Steam hardware rumors, and more in a week chock full of gaming news.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake’s other channel:
https://youtu.be/0vnk8ra3MtY



 ~~~~STORIES~~~~




Unreal engine stuff
https://www.reddit.com/r/gaming/comments/nm8lo2/the_konami_code_works_in_the_unreal_engine_5_demo/
https://www.youtube.com/watch?v=d1ZnM7CH-v4
https://twitter.com/IonizedGames/status/1397636481913610241

Horizon Forbidden West (still no release date)
https://youtu.be/wQATS4HOxdo

Uncharted 4 coming to PC?
https://www.engadget.com/sony-uncharted-4-pc-093043348.html

Xbox Bethesda event June 13th
https://www.theverge.com/2021/5/26/22453024/microsoft-xbox-bethesda-showcase-presentation-event-e3-2021

Borderlands Sony crossplay
https://www.polygon.com/22456489/borderlands-3-cross-play-update-ps4-ps5-sony


New Switch?
https://www.eurogamer.net/articles/2021-05-27-nintendo-switch-pro-to-be-unveiled-before-e3


Dying Light 2 (December 7th)
https://youtu.be/RJGdMGRAjVA


Dragon Questhttps://youtu.be/gfmOWgfYVjY

Far Cry 6
https://youtu.be/pQwfNEF6cY8

Sonic news!
https://www.youtube.com/watch?v=Z3MCqTdsVKc



Square Enix FF Dark Souls spinoff rumor
https://www.fanbyte.com/news/rumor-square-enix-set-to-announce-a-new-action-rpg-final-fantasy-spinoff/

Portable Steam thing
https://arstechnica.com/gaming/2021/05/exclusive-valve-is-making-a-switch-like-portable-gaming-pc/

