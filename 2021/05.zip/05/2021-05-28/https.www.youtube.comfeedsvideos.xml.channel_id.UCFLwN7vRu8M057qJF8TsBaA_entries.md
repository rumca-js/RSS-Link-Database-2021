# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Stardew Valley Is An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=BT3ivkkjizk](https://www.youtube.com/watch?v=BT3ivkkjizk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2021-05-28 20:23:08+00:00

Stardew Valley Is A Nightmare am I right?!

Patreon bros: https://www.patreon.com/UpIsNotJump
Merch-o-bros: https://www.pixelempire.com/pages/upisnotjump

I really l hope you enjoy this new style of video! I am very anxious about everyone’s thoughts. All in all this is a million subscriber video, a “Stardew Is A Nightmare” game review, and a satirical view on Google and YouTube as a whole.

OKAY so I don’t talk a lot about Stardew Valley exactly. I actually had pretty lofty goals from the start, I wanted to compare the Joja corporation in Stardew Valley to Google, drawing analogues from that to my life, while also reviewing the game. But I had to say COME ON MATT keep it simple for the first of these videos.

Overall though new style is easier to make too, I started with a Stardew Valley review to keep it simple but I have filmed my next video too (a Fallout 1 review) which will be out by the end of the month. I’ve also written two other videos, including a Fallout 2 review next. This new style will hopefully let me reach my goal of monthly review videos I have been trying to achieve for a while.

Special thank you to my members!
Siberial
Superhero3807
Bio Geek

Filming Equipment:
Camera: Canon EOS 90D Digital SLR Camera Body
Lens: Sigma 18-35mm f1.8 DC Art HSM Lens - Canon Fit
Microphone: Deity W.Lav Omnidirectional Lavalier Microphone

