# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Vex Ruffin - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=MenU1M_yGnU](https://www.youtube.com/watch?v=MenU1M_yGnU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-29 00:00:00+00:00

http://KEXP.ORG presents Vex Ruffin performing live, recorded exclusively for KEXP.

Songs:
Mabuhay Boy
Hard To See
Know Yourself
I'm Still At It
What Matters The Most
Tapang Naman

Session filmed by Wes Africa 

Vex : vocals 
Shags : bass guitar 
Alex Zhang Hungtai : saxophone 
Mikey Long : guitar
Josh Da Costa : drums

https://www.stonesthrow.com/artist/vex
http://kexp.org

## Vex Ruffin - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=B9NSO80rMqU](https://www.youtube.com/watch?v=B9NSO80rMqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-28 00:00:00+00:00

http://KEXP.ORG presents Vex Ruffin sharing a live performance recorded exclusively for KEXP and talking to Larry Mizell, Jr., host of The Afternoon Show. Recorded May 13, 2021.

Songs:
Mabuhay Boy
Hard To See
Know Yourself
I'm Still At It
What Matters The Most
Tapang Naman

Session filmed by Wes Africa 

Vex : vocals 
Shags : bass guitar 
Alex Zhang Hungtai : saxophone 
Mikey Long : guitar
Josh Da Costa : drums

https://www.stonesthrow.com/artist/vex
http://kexp.org

