# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## New book calls Obama a 'parasite' on the Democratic Party
 - [https://www.cnn.com/videos/politics/2021/05/28/obama-trump-edward-isaac-dovere-book-lead-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/05/28/obama-trump-edward-isaac-dovere-book-lead-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-28 22:36:04+00:00

CNN's Jake Tapper speaks with author Edward-Isaac Dovere about his new book "Battle for the Soul" and the harsh words former President Barack Obama had for his successor, former President Donald Trump.

## 'Charlie bit my finger' brothers speak out after video sells for $761,000 as an NFT
 - [https://www.cnn.com/videos/business/2021/05/28/charlie-bit-my-finger-youtube-nft-sale-qmb.cnnbusiness](https://www.cnn.com/videos/business/2021/05/28/charlie-bit-my-finger-youtube-nft-sale-qmb.cnnbusiness)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-28 20:32:50+00:00

Harry and Charlie Davies-Carr discuss their iconic viral YouTube video that recently sold for $761,000 as an NFT. According to the boys' father, Howard Davies-Carr, the buyer has decided to leave the video up on the platform.

## 'It's really hard': Parents of former Marine jailed in Russia speak out
 - [https://www.cnn.com/videos/politics/2021/05/28/jailed-american-trevor-reed-russia-coronavirus-paula-joey-intv-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/05/28/jailed-american-trevor-reed-russia-coronavirus-paula-joey-intv-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-28 20:30:41+00:00

The parents of Trevor Reed, an American imprisoned in Russia who recently tested positive for Covid-19, said neither they nor the US Embassy have been able to contact him since he was taken into isolation for the disease. Paula and Joey Reed told CNN's Victor Blackwell they found out about their son's positive diagnosis through his legal team.

## This boat-inspired Rolls-Royce could be the most expensive new car ever
 - [https://www.cnn.com/videos/business/2021/05/28/rolls-royce-boat-tail-orig.cnn-business](https://www.cnn.com/videos/business/2021/05/28/rolls-royce-boat-tail-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-28 17:36:38+00:00

Three nautical-inspired vehicles named the Rolls-Royce Boat Tail are being made as part of Rolls-Royce's inaugural Coachbuild project. The cars are estimated to go for $25 million each, making them the most expensive new cars ever sold.

## Kamala Harris praises McCain at graduation. Hear the crowd's reaction
 - [https://www.cnn.com/videos/politics/2021/05/28/kamala-harris-us-naval-academy-commencement-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/05/28/kamala-harris-us-naval-academy-commencement-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-28 15:38:59+00:00

Vice President Kamala Harris became the first woman to give the commencement speech at the United States Naval Academy, telling the 2021 graduating class that the US was "designed to be a team sport and we are in this together."

## Tiger Woods talks about his injury in first interview since car crash
 - [https://www.cnn.com/2021/05/28/us/tiger-woods-first-interview-crash-spt/index.html](https://www.cnn.com/2021/05/28/us/tiger-woods-first-interview-crash-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-28 09:59:30+00:00

Tiger Woods has given his first interview since he was involved in a massive car crash in February, discussing his rehab and physical therapy with Golf Digest.

