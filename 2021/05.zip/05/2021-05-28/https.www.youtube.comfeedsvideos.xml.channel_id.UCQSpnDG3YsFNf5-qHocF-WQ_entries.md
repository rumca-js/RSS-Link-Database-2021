# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Windows FINALLY Got a Package Manager - Here's Why It's Awesome
 - [https://www.youtube.com/watch?v=uxr7m8wDeGA](https://www.youtube.com/watch?v=uxr7m8wDeGA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-05-29 00:00:00+00:00

The feature you didn't even know you needed!
⚠️ NOTE: For now you'll have to manually install the latest version of App Installer with the WinGet client, by copy-pasting this whole thing below into your browser URL bar (without quotes):   
" ms-appinstaller:?source=https://aka.ms/getwinget "

• Microsoft's Blog Post Announcement ⇨ https://devblogs.microsoft.com/commandline/windows-package-manager-1-0/

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
0:52 - What is a Package Manager?
3:09 - How to Get It
3:54 - How to Use It & Demonstration
5:53 - Current Bugs
7:51 - More Features
8:29 - More Demos
9:39 - How to Submit a New Package

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

