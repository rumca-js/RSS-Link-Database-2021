# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## Risking My Life To Settle A Physics Debate
 - [https://www.youtube.com/watch?v=jyQwgBAaBag](https://www.youtube.com/watch?v=jyQwgBAaBag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-05-29 00:00:00+00:00

Even some physics professors say this craft breaks the laws of physics. This video is sponsored by Kiwico, For 50% off your first month of any subscription crate from KiwiCo (available in 40 countries!) head to https://www.kiwico.com/Veritasium50 

 ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
A HUGE thanks to Rick and Neil for letting me drive Blackbird. Check out Rick's YouTube Channel for more in depth videos and explanations on going faster than the wind downwind -- https://ve42.co/Rick 

Gene Nagata made the shoot possible. If you’re a video nerd like me, check out his channel, Potato Jet: https://www.youtube.com/c/PotatoJet/featured. 

Xyla Foxlin for made the model cart used in this video. Xyla builds amazing things like rockets and canoes, check it out!  https://www.youtube.com/c/xylafoxlin/

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
References
Jack Goodman's YouTube video -- https://ve42.co/Goodman
Rick's treadmill footage -- https://ve42.co/Treadmill
Rick's multiple explanations of how Blackbird works -- https://ve42.co/DDWFTTW
Forum discussions -- https://ve42.co/forum Blog -- https://ve42.co/blog1 and retraction https://ve42.co/BlogRetraction

Gaunaa, M., Øye, S., & Mikkelsen, R. F. (2009). Theory and design of flow driven vehicles using rotors for energy conversion. In EWEC 2009 Proceedings online EWEC  

Md. Sadak Ali Khan, Syed Ali Sufiyan, Jibu Thomas George, Md. Nizamuddin Ahmed. Analysis of Down-Wind Propeller Vehicle. International Journal of Scientific and Research Publications, 3, 4. (April 2013) ISSN 2250-3153. (www.ijsrp.org)

 ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Special thanks to Patreon supporters: Bill Linder, Paul Peijzel, Crated Comments, Anna, Mac Malkawi, Michael Schneider, Oleksii Leonov, Jim Osmun, Tyson McDowell, Ludovic Robillard, Jim buckmaster, fanime96, Juan Benet, Ruslan Khroma, Robert Blum, Richard Sundvall, Lee Redden, Vincent, Marinus Kuivenhoven, Alfred Wallace, Arjun Chakroborty, Joar Wandborg, Clayton Greenwell, Pindex, Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal

 ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Thanks to James Lincoln for building the initial prototypes for a model blackbird.

Written by Derek Muller, James Lincoln, and Petr Lebedev
Animation by Mike Radjabov and Ivy Tello
Filmed by Gene Nagata, Derek Muller, Trenton Oliver, AJ Fillo and Emily Zhang
Edited by Trenton Oliver 
Music from Epidemic Sound https://epidemicsound.com
Additional video supplied by Getty Images 
Produced by AJ Fillo

