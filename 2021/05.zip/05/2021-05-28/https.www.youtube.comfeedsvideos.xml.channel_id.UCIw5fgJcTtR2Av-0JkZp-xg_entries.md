# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## 1-Hour Movie Remixes For Train Ride / Drive (Dudewave / Lofi / Coffeehop / Vaporchill / Pinkiecore)
 - [https://www.youtube.com/watch?v=SlmjNSG1IgY](https://www.youtube.com/watch?v=SlmjNSG1IgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-05-29 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong 0:00 I’m a Dude
4:06 Gorlami
7:54 Number 1
11:28 For Ants
14:59 Covid-19 (The Wind of God)
19:21 Inconceivable
22:01 Two at a Time
25:20 1.21 Gigawatts
28:30 The Brains & The Brawn
31:38 Rushing / Dragging (Not Quite My Tempo)
34:17 Furious Anger
37:32 Omae Wa Mou Shindeiru
40:56 You Sonofa……
43:34 Hello There (General Kenobi)
46:53 Solemn (Coffin Dance)
50:45 First Rule (of Fight Club)
54:08 The Truth
56:48 Pickle Homer
59:20 Honey Badger (Don’t Give a Sh*t)
1:01:33 Boom (I’m Pickle Rick)

