# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 11 Minutes of Scarlet Nexus Preview Gameplay
 - [https://www.youtube.com/watch?v=Fb22V8tXwFw](https://www.youtube.com/watch?v=Fb22V8tXwFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-12 00:00:00+00:00

Scarlet Nexus is the upcoming anime-style action RPG from Bandai Namco, and here are 11 minutes of brand new gameplay for you to check out!

In a futuristic world threatened by otherworldly monsters called 'Others', Scarlet Nexus sees you play as either Kasani or Yuito with the task of putting a stop to them. Each protagonist have different paths through the same story, and you can see both of them in action in the above gameplay.

You'll not be fighting along, as you'll be fighting alongside a merry band of anime boys and girls who are part of a special forces unit who can support you in combat encounters. But of course, there seems to be a deeper mystery to unravel in the main story.

We got out hands on with the game for about 3 hours, but the gameplay in the above video was provided by Bandai Namco. Scarlet Nexus is set to launch on June 25th for PC, Xbox Series X and S, Xbox One, PS5, and PS4.

You can check out our full preview right here - https://www.gamespot.com/articles/scarlet-nexus-anime-style-action-has-potential-but-hasnt-fully-impressed-yet/1100-6491378/

## Hilarious Battlefield Bugs & Glitches Compilation
 - [https://www.youtube.com/watch?v=gptfbke3lGk](https://www.youtube.com/watch?v=gptfbke3lGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-12 00:00:00+00:00

With Battlefield 6 on the horizon we take a moment to reflect on some of the hilarious bugs and glitches that went on a rampage throughout the Battlefield games.

## Rarest Mass Effect Moments You Might Not Know About
 - [https://www.youtube.com/watch?v=ru8LbcqbBFc](https://www.youtube.com/watch?v=ru8LbcqbBFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-12 00:00:00+00:00

Jean-Luc lists some of the rarest moments in the Mass Effect Trilogy that you might not have experienced in your playthrough.

Intro:
There’s this side quest in the original Mass Effect where you must collect 16 ancient asari writings, which you do by scanning planets as well as landing on uncharted worlds and searching for them. It's an awful collection task quest, deathly boring to do even with a guide. The reward isn’t even all that great, being nothing but some measly experience points.  The saving grace being that because the whole thing is so meaningless, you can skip it without fear of missing out.

However, in Mass Effect 3, there is a small side quest on the Citadel for Shepard stan Conrad Verner. Turns out that before Conrad devoted his life to worshiping the Commander, he wrote a doctoral dissertation on xenotechnology and dark energy integration and can help Shepard obtain some ancient tech, tech that happens to be written in ancient asari dialect. If you collected 10 of the 16 asari writings all the way back in Mass Effect 1, you get some special dialogue as well as a plus five bonus to your war assets.

This is one of those rare moments most players didn’t fully experience in their Mass Effect trilogy playthrough: Strange or unique outcomes that required you to do something either really obscure to get or because you made choices in the past that fall in-between the cracks of the series’ mortality system. Most players tend to play a pure pure paragon or renegade playthrough, but if you mix and match you get some pretty interesting consequences. In this video, I’m going to go through a few of my favourite rare Mass Effect outcomes.

Originally this video was really long, so if you have other moments you’d love to see, or have your own favourites, drop them in the comments below or like this video and subscribe so we know you want to see more. It goes without saying this video contains spoilers for the whole series, except Andromeda cause I don’t talk about that game.

## Ratchet & Clank: Rift Apart - The Final Preview (4K)
 - [https://www.youtube.com/watch?v=AJmt7S6x298](https://www.youtube.com/watch?v=AJmt7S6x298)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-05-12 00:00:00+00:00

Ratchet & Clank: Rift Apart is shaping up to be a PS5 showpiece. Our in-depth preview delves into environments, weapons, and how Spider-Man shaped it.

Insomniac showed some of the opening tutorial along with a big action set piece starring the new co-protagonist Rivet. The studio also shared loads of details on weapon and environment design, the influence of its other recent hit Spider-Man, and how it's using the DualSense to make the weapons feel better than ever. Check out the video to hear our impressions on all the new additions coming to Ratchet & Clank's (and Rivet's) next planet-hopping adventure.

Ratchet & Clank: Rift Apart will release exclusively for PlayStation 5 on June 11, 2021. For more coverage on Ratchet & Clank: Rift Apart, including our review, consider subscribing to GameSpot. You can also read the written preview by Steve Watts on GameSpot.com: https://www.gamespot.com/articles/ratchet-clank-rift-apart-is-ps5s-gorgeous-new-comfort-food/1100-6491353/

