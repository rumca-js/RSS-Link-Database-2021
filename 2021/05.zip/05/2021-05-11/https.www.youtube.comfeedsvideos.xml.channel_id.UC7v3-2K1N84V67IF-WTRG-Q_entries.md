# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Venom: Let There Be Carnage -  Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=Ip2_V_LDGME](https://www.youtube.com/watch?v=Ip2_V_LDGME)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-05-11 00:00:00+00:00

The first trailer to VENOM: LET THERE BE CARNAGE has hit the internet with a look at Carnage, and a glimpse into every 90's Spider-Man fans dream! Here are my thoughts!

Watch the trailer here: https://www.youtube.com/watch?v=-ezfi6FQ8Ds&ab_channel=SonyPicturesEntertainment

#Venom #VenomLetThereBeCarnage

