# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Covid Cover-Up: Did It Come From A Lab?
 - [https://www.youtube.com/watch?v=2LgGPygFHh4](https://www.youtube.com/watch?v=2LgGPygFHh4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-05-12 00:00:00+00:00

Science writer Nicholas Wade has written an article in which he concludes that evidence around the origins of COVID-19 is “fairly firmly in favour” of the virus coming from the lab at Wuhan. With other scientists contesting his reasoning, what does this scientific debate signify? 
#Wuhan #Coronavirus #VirusOrigin #COVID-19

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

My Audible Original, ‘Revelation', is out NOW!
US: 
http://adbl.co/revelation
UK: 
http://adbl.co/revelationuk
AU: 
http://adbl.co/revelationau
CA: 
http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

