# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## TRUE Limits Of Humanity – The Final Border We Will Never Cross
 - [https://www.youtube.com/watch?v=uzkD5SeuwzM](https://www.youtube.com/watch?v=uzkD5SeuwzM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2021-05-11 00:00:00+00:00

If you want to support kurzgesagt and get something beautiful in return check our shop:
https://kgs.link/shop-142

Sources & further reading:
https://sites.google.com/view/sources-truelimitsofhumanity/

The original Limits of Humanity: https://www.youtube.com/watch?v=ZL4yYHdDSWs

Is there a border we will never cross? Are there places we will never reach, no matter how hard we try? It turns out, there are. Even with sci-fi technology, we are trapped in a limited pocket of the Universe and the finite stuff within it. How much universe is there for us and how far can we go?

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ https://kgs.link/shop-142  
Join the Patreon Bird Army 🐧  https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          http://kgs.link/music-youtube2021
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:

Soundcloud:   https://bit.ly/2RJq6M4
Bandcamp:     https://bit.ly/2SFUPdG


🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons (from http://kgs.link/patreon) who support us every month and made this video possible:
Denrage, Hugo Novotny, Bombibom, Bryant & Angel, Matthew, Ngoc B Khuong, Zormoe, Caoimhe Gilbert, Brandon James, Adrith Nayak, Zachary Kern, Eric Downes, Marcuss, Anthony Adkins, tomworkshere, Michael Tedder, DeepWaters, Greg Powell, fresh crystal mangos, Finalpenguin 726, Kareto Phase, Vincent Guerra, Michelle Sichting, Martin Hlaváč, Zwackelmann0, RottingMyBrain, meldanor, sprung, Pedro Antunes, supermeme, Guillaume Hellin, Carl Schanz, Drago Draco, Stephen Barker, Rors, Paco Avila, Ro-ni-n, Pol Duran Casademont, Courtney Hill, Sharbel Zarzour, Vicky, Carsten Guhr, Gary Gilbody, Jacob Geeo, Nathan Schroeder, Mark Frelih, Cédric Lothe, Joshua Valji, Thea Ilona, Jonathan Geaney, Arber, Matt Woodham, Dominic Juarez, Nelson Gollop, Дмитрий Киселёв, Adam Ellum, Lucy B, ghostman, dibidave, Dan Morris, lindryd aldar, Alberto Simonazzi, Jakub Kotucha, Hannes Burner, Mike Koss, henrythasler, Ryan McPartlan, Denis Leonte, Kai Fic, Jeremy Krall, Thomas Adamick, Andreas, Richard j, Eroviaa Hunter, PaddyO‘Lantern, Vishrut Joshi, Gwendolyn Jones, Nazar Beknazarov, Eric Rowland, José Castillo Fallas, Eben Alguire, Jesse, Greg Belote, AlphaTaco, Craig, Ryan G. Hornberger, Christien Lomax, SURGE, Ben Udris

