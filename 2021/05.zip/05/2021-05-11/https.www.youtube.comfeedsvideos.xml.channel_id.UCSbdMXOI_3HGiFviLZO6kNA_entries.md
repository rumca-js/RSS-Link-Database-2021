# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## HTC's New VR Headsets are TROUBLESOME...
 - [https://www.youtube.com/watch?v=uZtyEaeu0g4](https://www.youtube.com/watch?v=uZtyEaeu0g4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-05-12 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. HOLY COW, SO MUCH IS HAPPENING. ViveCon just happened leaving us with two new HTC VR Headsets which i'll talk about here. Facebook talks about Quest pro, Pico neo 3 launches for sub $400, PCVR 2 leaks.. this was a MASSIVE WEEK. 

Here is LowFi on Steam on Itch:
https://anticleric.itch.io/low-fi
Wishlist here: https://store.steampowered.com/app/395830/LOWFI/

My links:
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Sources:
UploadVR's trailer of "LowFi"
https://venturebeat.com/2021/05/11/htc-vive-launches-2-vr-headsets-and-pro-tools-for-enterprises/
https://uploadvr.com/psvr-playstation-4k-eye/
https://www.roadtovr.com/htc-vive-focus-3-specs-price-release-date-announcement/
https://www.roadtovr.com/htc-vive-pro-2-specs-price-release-date-announcement/
https://www.roadtovr.com/pico-neo-3-pro-eye-release-date-price/
https://developer.nvidia.com/nvidia-cloudxr-sdk
https://www.roadtovr.com/mark-zuckerberg-oculus-quest-pro/
https://www.roadtovr.com/huawei-motion-controller-patent-vr-glass/
https://uploadvr.com/vive-pro-2-focus-3-eye-tracking-add-on/
https://www.reddit.com/r/virtualreality/comments/jk8ady/vr_will_surpass_human_eye_resolution_in_2034/
https://www.theverge.com/2018/1/8/16863304/htc-vive-wireless-adapter-features-ces-2018

