# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 MESSED UP Moments In Games That Nobody Talks About
 - [https://www.youtube.com/watch?v=kNNvl4KcR-4](https://www.youtube.com/watch?v=kNNvl4KcR-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-12 00:00:00+00:00

Many games have disturbing or strange moments or themes that people often forget to acknowledge. Here's some messed up stuff.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Hood: Outlaws & Legends - Before You Buy
 - [https://www.youtube.com/watch?v=vhGDbNXkBUY](https://www.youtube.com/watch?v=vhGDbNXkBUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-11 00:00:00+00:00

Hood: Outlaws and Legends (PC, PlayStation 4, Xbox One, PlayStation 5, Xbox Series X and Series S) is a unique Robin Hood-themed multiplayer game. How is it? Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?su...​ ↓↓

