# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Harvard's Alleged Anti-Asian Discrimination
 - [https://www.youtube.com/watch?v=6gIEKGxL7zo](https://www.youtube.com/watch?v=6gIEKGxL7zo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-12 00:00:00+00:00

Taken from JRE #1650 w/Russell Peters:
https://open.spotify.com/episode/1GC9qr0mhi6wfJrKbzeL8W?si=RxASyJEbQMiouiTSKQ-S6Q

## Joe on Canelo Alvarez vs. Billy Joe Saunders w/Russell Peters
 - [https://www.youtube.com/watch?v=tK8YLq2LC4o](https://www.youtube.com/watch?v=tK8YLq2LC4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-12 00:00:00+00:00

Taken from JRE #1650 w/Russell Peters:
https://open.spotify.com/episode/1GC9qr0mhi6wfJrKbzeL8W?si=RxASyJEbQMiouiTSKQ-S6Q

## Michael Easter on The Comfort Crisis
 - [https://www.youtube.com/watch?v=wh-LTVrdOPQ](https://www.youtube.com/watch?v=wh-LTVrdOPQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-11 00:00:00+00:00

Taken from JRE #1649 w/Michael Easter:
https://open.spotify.com/episode/0OZrk81nGEPTk9KfeJbtaC?si=rGQyK0o0Sauk0qow9lF7sg

## Overcoming the Pull of Social Media
 - [https://www.youtube.com/watch?v=aOhx6fGBLso](https://www.youtube.com/watch?v=aOhx6fGBLso)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-05-11 00:00:00+00:00

Taken from JRE #1649 w/Michael Easter:
https://open.spotify.com/episode/0OZrk81nGEPTk9KfeJbtaC?si=rGQyK0o0Sauk0qow9lF7sg

