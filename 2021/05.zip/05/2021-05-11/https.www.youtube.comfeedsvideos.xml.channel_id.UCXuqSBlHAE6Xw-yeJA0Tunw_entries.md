# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Building a PC with my Wife was a MISTAKE - Lounge VR PC Build
 - [https://www.youtube.com/watch?v=PLLu44pwhV4](https://www.youtube.com/watch?v=PLLu44pwhV4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-12 00:00:00+00:00

Get 20% OFF + Free Shipping @MANSCAPED with promo code TECH at
https://manscaped.com/TECH

Check out VOLTA Spark cables here: https://geni.us/Jo8c

With the rebuild of our employee gaming lounge mostly complete, we figured it was also a good time to rebuild our wireless VR gaming rig for it.... it just didn't quite go as expected.


Buy ASUS ROG Crosshair VIII Dark Hero: https://geni.us/Ea7Iae

Buy AMD Ryzen 9 5900X CPU: https://geni.us/oz8uNF

Buy G.Skill TridentZ RGB 4x16GB 3600MHz CL14 RAM: https://geni.us/XKBZ

Buy EVGA RTX 3090 XC3 GPU: https://geni.us/B6NB

Buy Crucial P5 2TB: https://geni.us/o66tvpf

Buy Sabrent 8TB NVMe SSD: https://geni.us/6Kydu

Buy EVGA 1000W Gold PSU: https://geni.us/ICAF

Buy Corsair 5000X RGB Case: https://geni.us/dBQnolB

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1337244-building-a-pc-with-my-wife-actually-gone-wrong/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## The Moment of Truth… - Next Gen ULTIMATE Desk PC Part 3
 - [https://www.youtube.com/watch?v=UAR9cccDKSI](https://www.youtube.com/watch?v=UAR9cccDKSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-05-11 00:00:00+00:00

Join us in War Thunder for FREE at https://playwt.link/LinusTechTipsBonus Get an exclusive bonus using our link - thanks for supporting the channel!

Part 3 of our EPIC desk PC Saga continues with a bench build of this SICK ultra thin desk - we’re gonna get it fired up for the first time! 

Buy AMD Threadripper 3970X CPU (PAID LINK): https://geni.us/N3bJ7

Buy Alphacool Eisblock XPX Pro 1U (PAID LINK): https://geni.us/N3bJ7

Buy ASUS ROG Zenith II Extreme Alpha (PAID LINK): https://geni.us/ReXk5

Buy Crucial Ballistix MAX RGB 16GB 4400MHz DDR4 RAM (PAID LINK): https://geni.us/j8qJWZx

Buy Sabrent 2TB Rocket 4 Plus NVMe SSD (PAID LINK): https://geni.us/Ixaa4c

Buy Crucial MX500 2TB SATA SSD (PAID LINK): https://geni.us/88f8

Buy ASUS RTX 3070 ROG Strix GPU (PAID LINK): https://geni.us/8idJAb

Check out the HDPLEX 800W DC-ATX PSU at: https://lmg.gg/apT8V

Buy Noctua NF-F12 Fans (PAID LINK): https://geni.us/BFaWCuh

Buy Alphacool ES1U Reservoir (PAID LINK): https://geni.us/dXaF

Buy Alphacool Laing DDC310 Pump (PAID LINK): https://geni.us/3WrnB91 

Buy Alphacool NexXxoS UT60 Radiator (PAID LINK): https://geni.us/KGrlp

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1336902-the-moment-of-truth%E2%80%A6-next-gen-desk-pc-pt3/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

