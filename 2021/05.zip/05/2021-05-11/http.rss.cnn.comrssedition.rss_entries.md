# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## CNN anchor presses Sierra Leone's president on corruption claims
 - [https://www.cnn.com/videos/world/2021/05/11/julius-maada-bio-sierra-leone-zain-asher-interview-oneworld-vpx.cnn](https://www.cnn.com/videos/world/2021/05/11/julius-maada-bio-sierra-leone-zain-asher-interview-oneworld-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 23:08:12+00:00

CNN's Zain Asher speaks to Sierra Leone President Julius Maada Bio about how he's performing against his campaign promises to root out corruption in the country.

## 'Trojan Footprint' training hopes to send powerful message to Russia
 - [https://www.cnn.com/videos/world/2021/05/11/us-training-troops-black-sea-russia-marquardt-pkg-lead-vpx.cnn](https://www.cnn.com/videos/world/2021/05/11/us-training-troops-black-sea-russia-marquardt-pkg-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 21:59:12+00:00

Alex Marquardt reports as CNN gets exclusive access to military exercises being conducted by US troops in conjunction with Eastern European forces as tensions with Russia rise.

## The best home workouts designed by the fittest people on the planet
 - [https://www.cnn.com/videos/sports/2020/05/06/crossfit-home-workouts-quarantine-lockdown-coronavirus-spt-intl-lon-orig-cmd.cnn](https://www.cnn.com/videos/sports/2020/05/06/crossfit-home-workouts-quarantine-lockdown-coronavirus-spt-intl-lon-orig-cmd.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 18:34:51+00:00

How would you like to get in shape? We mean really in shape. Four of the best Crossfitters on the planet share some home workouts to keep you in shape despite the lockdown.

## Dogecoin is still in the dog house after Elon Musk's 'SNL' appearance
 - [https://www.cnn.com/2021/05/11/investing/dogecoin-price-elon-musk-snl/index.html](https://www.cnn.com/2021/05/11/investing/dogecoin-price-elon-musk-snl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 17:56:03+00:00

Dogecoin prices rebounded Tuesday morning after Tesla CEO Elon Musk asked his nearly 54 million Twitter followers if they want his car company to "accept Doge." Nearly 77% of the poll's respondents said yes.

## 'Dangerous' ex-English National Ballet dancer found guilty of sexual assaults
 - [https://www.cnn.com/2021/05/11/uk/yat-sen-chang-sexual-assaults-intl-scli-gbr/index.html](https://www.cnn.com/2021/05/11/uk/yat-sen-chang-sexual-assaults-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 17:55:10+00:00

A "dangerous and predatory" former English National Ballet principal dancer has been found guilty of sexually assaulting his teenage students.

## 2 men accused of using chemical on officer Brian Sicknick at the Capitol riot to stay in jail, judge rules
 - [https://www.cnn.com/2021/05/11/politics/brian-sicknick-capitol/index.html](https://www.cnn.com/2021/05/11/politics/brian-sicknick-capitol/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 17:46:43+00:00

Two men accused of spraying police with chemical spray, including on Capitol Police Officer Brian Sicknick, in the Capitol riot will stay in jail as they await trial, a federal judge ruled on Tuesday.

## Ancient looted statue returned to Libya
 - [https://www.cnn.com/style/article/british-museum-libya-statue-scli-intl-gbr/index.html](https://www.cnn.com/style/article/british-museum-libya-statue-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 17:41:17+00:00

An ancient statue, believed to be looted from Libya during the civil war, has been returned to the country's authorities.

## It's a boat? It's a plane? No, it's a 'seaglider.' And it goes fast...really fast
 - [https://www.cnn.com/videos/business/2021/05/11/all-electric-ground-effect-vehicle-seaglider-regent-orig.cnn-business](https://www.cnn.com/videos/business/2021/05/11/all-electric-ground-effect-vehicle-seaglider-regent-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 17:02:12+00:00

Boston-based REGENT says it's planning to build the first all-electric "seaglider," a ground-effect vehicle with top speeds of 180 mph. The company hopes it will change the future of transportation over water.

## Being a teen is tough. London teenagers share how the pandemic has made it even harder
 - [https://www.cnn.com/2021/05/11/health/mental-health-teenagers-london-pandemic-wellness/index.html](https://www.cnn.com/2021/05/11/health/mental-health-teenagers-london-pandemic-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 16:45:56+00:00

Away from her friends and regular routine, London teenager Eesha Parashara developed an eating disorder during the UK's first national lockdown, which began last March.

## Senior cybersecurity official warns attacks on US are growing more 'sophisticated frequent and aggressive'
 - [https://www.cnn.com/2021/05/11/politics/colonial-pipeline-cyber-hearing-senate-homeland-security-committee/index.html](https://www.cnn.com/2021/05/11/politics/colonial-pipeline-cyber-hearing-senate-homeland-security-committee/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 15:40:21+00:00

A top Biden administration cybersecurity official warned that cyberattacks on the nation's infrastructure are "growing more sophisticated, frequent and aggressive," at a Tuesday hearing focused on a spate of recent incidents impacting the US.

## 'Euphoria' star Sydney Sweeney shuts down online criticism over her looks
 - [https://www.cnn.com/2021/05/11/entertainment/sydney-sweeney-trnd/index.html](https://www.cnn.com/2021/05/11/entertainment/sydney-sweeney-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 15:39:42+00:00

Sydney Sweeney released an emotional video responding to people online who criticized her appearance.

## Family of Andrew Brown Jr. to view body camera footage of his fatal shooting
 - [https://www.cnn.com/2021/05/11/us/andrew-brown-jr-family-police-video-viewing/index.html](https://www.cnn.com/2021/05/11/us/andrew-brown-jr-family-police-video-viewing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 15:32:53+00:00

The immediate family of Andrew Brown Jr. will have the chance Tuesday to view police body camera video of Brown's death, following a judge's order that authorized the viewing.

## At least 7 children killed in Russian school shooting
 - [https://www.cnn.com/2021/05/11/europe/russia-school-shooting-kazan-intl/index.html](https://www.cnn.com/2021/05/11/europe/russia-school-shooting-kazan-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 15:21:37+00:00

At least nine people, including six children, have been killed in a school shooting in the western Russian city of Kazan, according to state media reports, as authorities search the school building for a potential second gunman.

## Sally Buzbee will be first woman to lead Washington Post as new executive editor
 - [https://www.cnn.com/2021/05/11/media/sally-buzbee-washington-post-executive-editor/index.html](https://www.cnn.com/2021/05/11/media/sally-buzbee-washington-post-executive-editor/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 15:11:46+00:00

The Washington Post has selected Sally Buzbee, executive editor and senior vice president at the Associated Press, as its new top editor.

## Analysis: What Mitt Romney nails about the removal of Cheney
 - [https://www.cnn.com/2021/05/11/politics/mitt-romney-liz-cheney-kevin-mccarthy-donald-trump/index.html](https://www.cnn.com/2021/05/11/politics/mitt-romney-liz-cheney-kevin-mccarthy-donald-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 14:58:57+00:00

In a single sentence on Monday night, Mitt Romney explained why the planned removal of Wyoming Rep. Liz Cheney from her leadership position in the House on Wednesday is such a giant mistake for Republicans.

## A slice of pure American folklore goes racing
 - [https://www.cnn.com/2021/05/11/motorsport/king-of-the-baggers-motorsport-cmd-spt-intl/index.html](https://www.cnn.com/2021/05/11/motorsport/king-of-the-baggers-motorsport-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 14:57:01+00:00

Take a ramshackle group of racing misfits and some wildly inappropriate machinery, add a couple of finely honed professional athletes, throw in a rivalry that dates back more than a century, top it off with a beer and a cheeseburger, and what do you get?  The answer is the King of the Baggers, the wackiest and perhaps most entertaining racing series on any serious racetrack right now.

## This rare purple-pink diamond could make $38M at auction
 - [https://www.cnn.com/style/article/sakura-diamond-auction-christies/index.html](https://www.cnn.com/style/article/sakura-diamond-auction-christies/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 14:55:28+00:00

A 15.81-carat diamond could fetch up to $38 million when it goes on sale in Hong Kong next week.

## Voyager spacecraft detects 'persistent hum' beyond our solar system
 - [https://www.cnn.com/2021/05/11/world/nasa-voyager-1-intl-scli-scn/index.html](https://www.cnn.com/2021/05/11/world/nasa-voyager-1-intl-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 14:43:34+00:00

One of the Earth's longest-flying spacecraft has detected a "persistent hum" beyond our solar system, according to a new study.

## Federal investigators press for cooperation from two key witnesses in Gaetz probe
 - [https://www.cnn.com/2021/05/11/politics/gaetz-investigators-cooperation-two-key-witnesses/index.html](https://www.cnn.com/2021/05/11/politics/gaetz-investigators-cooperation-two-key-witnesses/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 14:22:39+00:00

Federal investigators scrutinizing Rep. Matt Gaetz are seeking the cooperation of a former Capitol Hill intern who was once a girlfriend of the Florida Republican, sources familiar with the matter tell CNN.

## Victoria's Secret is becoming a publicly traded company
 - [https://www.cnn.com/2021/05/11/investing/victorias-secret-l-brands-spin-off/index.html](https://www.cnn.com/2021/05/11/investing/victorias-secret-l-brands-spin-off/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 14:15:45+00:00

L Brands has officially given up on seeking a buyer for Victoria's Secret and is spinning off the struggling underwear brand to become its own publicly traded company instead.

## Timeline: How Cheney went from GOP scion to party pariah
 - [https://www.cnn.com/2021/05/10/politics/liz-cheney-gop-career-timeline/index.html](https://www.cnn.com/2021/05/10/politics/liz-cheney-gop-career-timeline/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 13:36:43+00:00

The House Republican Conference is expected to vote Wednesday morning to replace Wyoming Rep. Liz Cheney as GOP conference chair. It's a dramatic turnaround for the conservative congresswoman, who was elected to the position less than three years ago at the encouragement of Republican leadership.

## Zoo waited a week before alerting public 3 leopards were loose
 - [https://www.cnn.com/videos/world/2021/05/11/china-zoo-leopards-escape-kept-from-public-ripley-pkg-newday-vpx.cnn](https://www.cnn.com/videos/world/2021/05/11/china-zoo-leopards-escape-kept-from-public-ripley-pkg-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 13:32:09+00:00

Three rare leopards escaped from Hangzhou Safari Park in one of China's biggest cities but it took staff a week to alert the public. While two leopards have been returned, one remains on the run. CNN's Will Ripley reports.

## Queen sets out UK plans to ban LGBT conversion therapy
 - [https://www.cnn.com/2021/05/11/uk/queens-speech-2021-scli-gbr-intl/index.html](https://www.cnn.com/2021/05/11/uk/queens-speech-2021-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 13:24:36+00:00

Queen Elizabeth II carried out her first major engagement since the funeral of her husband Prince Philip on Tuesday, unveiling the UK government's legislative agenda and confirming plans to ban LGBTQ conversion therapy in a formal ceremony at the Houses of Parliament.

## Unsolved homicide case gets big DNA break
 - [https://www.cnn.com/videos/us/2021/05/11/montana-christy-creek-indentified-marshall-dnt-vpx.ktmf](https://www.cnn.com/videos/us/2021/05/11/montana-christy-creek-indentified-marshall-dnt-vpx.ktmf)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 13:21:35+00:00

After three decades, Montana police have been able to identify the skeletal remains of the woman found by a bear hunter in Missoula County as Janet Lee Lucas, a missing mother from Washington. KTMF's Angela Marshall reports.

## Watch Queen Elizabeth's full speech opening parliament
 - [https://www.cnn.com/videos/world/2021/05/11/queens-speech-2021-queen-elizabeth-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/05/11/queens-speech-2021-queen-elizabeth-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 13:20:28+00:00

Queen Elizabeth II carried out her first major engagement since the funeral of her husband Prince Philip on Tuesday, unveiling the UK government's legislative agenda and confirming plans to ban LGBTQ conversion therapy in a formal ceremony at the Houses of Parliament.

## Caitlyn Jenner reveals whether she voted for Trump in 2020
 - [https://www.cnn.com/videos/politics/2021/05/11/caitlyn-jenner-dana-bash-2020-election-trump-vpx.cnn](https://www.cnn.com/videos/politics/2021/05/11/caitlyn-jenner-dana-bash-2020-election-trump-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 13:16:59+00:00

California Gubernatorial Candidate Caitlyn Jenner tells CNN's Dana Bash that she did not vote in the 2020 election and that she is willing to have former Trump campaign staffers work on her campaign.

## CNN's John Avlon breaks down Trump's recent approval ratings
 - [https://www.cnn.com/videos/politics/2021/05/11/trump-popularity-republicans-avlon-reality-check-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/05/11/trump-popularity-republicans-avlon-reality-check-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 12:47:11+00:00

CNN's John Avlon breaks down former President Donald Trump's current approval rating among Republicans.

## Top women's league in Finland donates sport hijabs to any player who wants one
 - [https://www.cnn.com/2021/05/11/football/hijab-finland-womens-football-national-league-spt-intl/index.html](https://www.cnn.com/2021/05/11/football/hijab-finland-womens-football-national-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 12:30:11+00:00

It's a country that takes the issue of equality seriously, and now the top division of women's football in Finland -- the National League -- is to offer hijabs to any player that wants one.

## Social media companies are doing 'bare minimum,' to protect players, says ex-Premier League star
 - [https://www.cnn.com/2021/05/11/football/social-media-blackout-nedum-onuoha-spt-intl/index.html](https://www.cnn.com/2021/05/11/football/social-media-blackout-nedum-onuoha-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 12:25:35+00:00

Former Manchester City star Nedum Onuoha says social media companies have been doing the "bare minimum" to protect players from online racist abuse.

## Some big risks to investors have been hiding in plain sight
 - [https://www.cnn.com/2021/05/11/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/05/11/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 12:24:39+00:00

What do stretched supply chains, rising prices and the ransomware attack on the Colonial Pipeline have in common? They all stem from risks that investors should have had on their radar.

## One of Italy's most idyllic islands says it is 'Covid-free'
 - [https://www.cnn.com/travel/article/capri-covid-free-vaccination/index.html](https://www.cnn.com/travel/article/capri-covid-free-vaccination/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 12:04:47+00:00

As Europe plans its gradual reopening to visitors from further afield, the battle lines are being drawn between destinations eager to get the tourist dollars flowing.

## CNN team takes cover as sirens sound in Israel
 - [https://www.cnn.com/videos/world/2021/05/11/israel-sirens-rockets-ashkelon-gold-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/05/11/israel-sirens-rockets-ashkelon-gold-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 12:00:44+00:00

CNN's Hadas Gold and her team rush to cover as warning sirens were heard in Ashkelon, Israel amid rising tensions between Israelis and Palestinians. Israel and Gaza militants have been exchanging fire after clashes in Jerusalem and an uptick in violence.

## Genevieve Nnaji joins cast of Clubhouse musical on Afrobeat star Fela Kuti
 - [https://www.cnn.com/2021/05/11/africa/genevieve-fela-adaptation-clubhouse-intl/index.html](https://www.cnn.com/2021/05/11/africa/genevieve-fela-adaptation-clubhouse-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 11:25:23+00:00

Nollywood actress and filmmaker Genevieve Nnaji is among the cast of an audio adaptation of Broadway musical 'FELA!' premiering on the Clubhouse app this weekend.

## Tom Cruise returns Golden Globes Awards in protest of HFPA
 - [https://www.cnn.com/videos/media/2021/05/11/tom-cruise-golden-globes-sot-mxp-vpx.hln](https://www.cnn.com/videos/media/2021/05/11/tom-cruise-golden-globes-sot-mxp-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 11:16:53+00:00

Tom Cruise has returned his Golden Globe Awards to the Hollywood Foreign Press Association, a source close to the actor told CNN, amid growing controversy surrounding the HFPA. HLN's Kristina Fitzpatrick has the details.

## Here's where Melinda Gates will focus her multi-billion-dollar fortune after her divorce
 - [https://www.cnn.com/2021/05/11/business/melinda-gates-money/index.html](https://www.cnn.com/2021/05/11/business/melinda-gates-money/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 10:24:48+00:00

Together, Bill and Melinda Gates were one of the richest and most philanthropic couples in the world. After splitting, they will be two of the wealthiest individuals in the world.

## German priests defy Vatican ban and bless same-sex unions
 - [https://www.cnn.com/2021/05/11/europe/german-priests-vatican-same-sex-scli-intl-grm/index.html](https://www.cnn.com/2021/05/11/europe/german-priests-vatican-same-sex-scli-intl-grm/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 10:14:52+00:00

The Catholic Church has lost touch with the "living reality" of LGBT+ people, said one of more than 100 German priests who are defying the Vatican this week by blessing same-sex couples.

## US Navy releases video of altercation with Iran in Strait of Hormuz
 - [https://www.cnn.com/videos/world/2021/05/11/us-iran-strait-of-hormuz-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/05/11/us-iran-strait-of-hormuz-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 09:33:02+00:00

A US Coast Guard ship fired approximately 30 warning shots as a "large group" of Iranian Islamic Revolutionary Guard Corps Navy fast boats conducted "unsafe and unprofessional maneuvers" near US naval vessels in the Strait of Hormuz, Pentagon spokesman John Kirby said.

## Arrest of journalists a litmus test for how Thailand treats those fleeing persecution in Myanmar
 - [https://www.cnn.com/2021/05/11/media/myanmar-thailand-arrested-journalists-intl-hnk/index.html](https://www.cnn.com/2021/05/11/media/myanmar-thailand-arrested-journalists-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 09:29:45+00:00

Three senior reporters who fled Myanmar for Thailand after the brutal military coup "face certain arrest and persecution" if they are deported following their arrest in Chiang Mai on Sunday, journalist groups say.

## Meet the trampolinist giving Germany's Green party a bounce in the race to succeed Merkel
 - [https://www.cnn.com/2021/05/11/europe/annalena-baerbock-german-green-party-leader-cmd-grm-intl/index.html](https://www.cnn.com/2021/05/11/europe/annalena-baerbock-german-green-party-leader-cmd-grm-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 09:29:15+00:00

Cast an eye over the candidates hoping to succeed Angela Merkel as German Chancellor, and one of the phrases most often used by political pundits describing the Green party's nominee Annalena Baerbock is: "A breath of fresh air."

## Japanese government adviser sparks ire with tweet laughing off calls for Olympic cancellation
 - [https://www.cnn.com/2021/05/11/sport/yoichi-takahashi-olympics-spt-intl/index.html](https://www.cnn.com/2021/05/11/sport/yoichi-takahashi-olympics-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 09:25:13+00:00

A tweet by a top Japanese government adviser downplaying the pandemic and laughing off calls for the Olympics to be canceled is drawing public ire a few days after Japan extended a state of emergency in Tokyo and three other areas until the end of May.

## Gnawed bones of 9 Neanderthals found in 'extraordinary' discovery
 - [https://www.cnn.com/2021/05/11/world/neanderthal-remains-italy-scn/index.html](https://www.cnn.com/2021/05/11/world/neanderthal-remains-italy-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 08:54:28+00:00

The discovery of the ancient remains of nine Neanderthals, a pack of hyenas and several elephants in the Guattari Cave near the Italian resort town of San Felice Circeo has astounded archaeologists, who have long suspected that a considerable population lived in the area.

## Immigration detainees dig tunnel in failed escape plot
 - [https://www.cnn.com/2021/05/11/asia/australia-immigration-escape-tunnel-hnk-intl/index.html](https://www.cnn.com/2021/05/11/asia/australia-immigration-escape-tunnel-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 08:31:21+00:00

Detainees at an immigration center in Australia spent five months digging an escape tunnel hidden beneath a chest of drawers in one of their rooms, a source within the country's immigration system told CNN.

## See these 50,000-year-old Neanderthal skulls discovered in Italy
 - [https://www.cnn.com/videos/world/2021/05/10/neanderthal-remains-italy-orig-jk-scn.cnn](https://www.cnn.com/videos/world/2021/05/10/neanderthal-remains-italy-orig-jk-scn.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 08:17:34+00:00

Researchers discovered remains of Neanderthals, an early ancestor of humans, that are more than 50,000 years old in a cave near Rome.

## Covid-19 outbreak reported near casino run by alleged crime boss
 - [https://www.cnn.com/2021/05/11/asia/golden-triangle-covid-19-outbreak-intl-hnk/index.html](https://www.cnn.com/2021/05/11/asia/golden-triangle-covid-19-outbreak-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 07:35:06+00:00

Authorities in Laos have reported a significant Covid-19 outbreak near the notorious Kings Romans casino, whose Chinese owner is accused by the United States of trafficking people, wildlife and drugs.

## Dracula's castle is offering free vaccines
 - [https://www.cnn.com/videos/travel/2021/05/10/dracula-castle-coronavirus-vaccine-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/travel/2021/05/10/dracula-castle-coronavirus-vaccine-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 06:49:00+00:00

A Romanian castle said to be the home of Dracula is offering free Covid-19 jabs to visitors as part of a vaccination drive. Bran Castle, in Transylvania, announced its Pfizer BioNTech Vaccine Marathon in a Facebook post. Completed in 1388, the castle sits outside the city of Brasov.

## Devastating scenes show how Covid-19 is ravaging rural India
 - [https://www.cnn.com/videos/world/2021/05/11/india-gujurat-village-coronavirus-covid-19-kiley-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/05/11/india-gujurat-village-coronavirus-covid-19-kiley-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 06:37:34+00:00

India's devastating second wave of Covid-19 shows no sign of abating and there are signs the virus is spreading fast into rural areas. CNN's Sam Kiley reports from a remote village in the state of Gujarat where 90 people have died in the last month.

## The move against Liz Cheney cements a disdain for democracy in the Republican Party
 - [https://www.cnn.com/2021/05/11/politics/donald-trump-liz-cheney-joe-biden/index.html](https://www.cnn.com/2021/05/11/politics/donald-trump-liz-cheney-joe-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-11 05:21:55+00:00

• Kinzinger comes out swinging at McCarthy and Trump as he defends Cheney
• Analysis: What Romney nails about the removal of Cheney

