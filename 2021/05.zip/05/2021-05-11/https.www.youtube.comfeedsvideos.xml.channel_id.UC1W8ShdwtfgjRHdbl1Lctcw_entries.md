# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## A day in Germany 1945 during World War II in color [60fps, Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=mdqjHwhv47w](https://www.youtube.com/watch?v=mdqjHwhv47w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2021-05-12 00:00:00+00:00

I colorized, restored and applied face restoration and created a sound design for this video  Germany in 1945. during WW-II like you have never seen it before! This film footage is very rare. It is of extremely high quality,

Video Enhancement Process:
✔ FPS boosted to 60 frames per second 
✔ Image boosted up
✔ Improved video sharpness and brightness 
✔restoration:(stabilisation,denoise,cleand,deblur) 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound only for the ambiance (do not represent real historical data)


Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

B&W Video Source from: Douglas Hackney
B&W Video  Provenance: Several high definition film transfers from National Archives and Records Administration were obtained by Douglas Hackney as part of his family history reseach on his grandfather, Zane L. Strickland, who appears in one of the Nordhausen films carrying a stretcher with a liberated prisoner. Mr. Hackney donated HD copies of the WWII materials to USHMM in November 2016.

Credit: United States Holocaust Memorial Museum, gift of Douglas Hackney in memory of Zane L. Strickland

B&W Video Source: https://collections.ushmm.org/search/catalog/irn557805

Rights:  To the best of the Museum's knowledge, this material is in the public domain.

-------
Disclaimer: you are responsible for your comments, these videos it's just for learn from and enjoy.
-------

- - - - - - - - - - - - - - - - - - - -
📨 Contact me at :nassthegoodman@gmail.com
- - - - - - - - - - - - - - - - - - - -
For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page! Please consider "fair use" before filing a claim. Thank You!

