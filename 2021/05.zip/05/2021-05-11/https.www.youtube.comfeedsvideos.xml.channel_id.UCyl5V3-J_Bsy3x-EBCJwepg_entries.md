# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Disney To Remove Problematic Kiss From Classic Movie, Snow White Will Now Remain Dead
 - [https://www.youtube.com/watch?v=dCQZEbZYCYg](https://www.youtube.com/watch?v=dCQZEbZYCYg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-05-12 00:00:00+00:00

The non-consensual kiss in Snow White and The Seven Dwarves is obviously problematic so The Walt Disney Company did the only sensible thing... remove the kiss leaving Snow White dead. Social progress victory!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Joe Biden: Catholic Icon
 - [https://www.youtube.com/watch?v=VaGGb-KaJVY](https://www.youtube.com/watch?v=VaGGb-KaJVY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-05-12 00:00:00+00:00

On the Babylon Bee Podcast, Ethan and guest hosts Trevor and Thaddeus try to make sense of the Washington Post tweet that called Joe Biden “very catholic."

See the full show: https://www.youtube.com/watch?v=6XCoFUqg1P8

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

Hit the bell to get your daily dose of fake news that you can trust.

## Skillet’s John Cooper On Listening To Christ Over Celebrities
 - [https://www.youtube.com/watch?v=1RNMh42yTRk](https://www.youtube.com/watch?v=1RNMh42yTRk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-05-11 00:00:00+00:00

On The Babylon Bee Interview Show, Kyle and Ethan talk to John Cooper of Skillet. They talk about CCM fame, discovering Petra, and weird band names. John Cooper is the lead singer, bassist, and producer for Skillet. Skillet has become one of the best-selling bands with two Grammy award nominations and has gone platinum twelve times.  He has recently written a book titled Awake and Alive to Truth, where he dives into the most asked questions in modern culture. 

00:02:26 Start of interview
00:05:32 John's viral Facebook post
00:19:10 Growing up without Christian rock
00:31:08 Secret to naming a band in the 90s

Subscribe on iTunes: https://podcasts.apple.com/us/podcast...​

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans​​​​

The Official The Babylon Bee Store: https://shop.babylonbee.com​​​​

Follow The Babylon Bee:
Website: https://babylonbee.com​​​​
Twitter: http://twitter.com/thebabylonbee​​​​
Facebook: http://facebook.com/thebabylonbee​​​​
Instagram: http://instagram.com/thebabylonbee​

