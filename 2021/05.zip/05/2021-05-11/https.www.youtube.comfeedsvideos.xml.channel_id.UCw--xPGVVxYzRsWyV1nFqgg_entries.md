# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## 2021 Books Tier List Pt. 1
 - [https://www.youtube.com/watch?v=OiwzFrWMZds](https://www.youtube.com/watch?v=OiwzFrWMZds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-05-12 00:00:00+00:00

My tier list of fantasy scifi books I have read and reviewed in 2021 so far! 
BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1

## TROLLOC SIGHTING!👀 Best Women In Fantasy?📚 Retracting Lightsabers😱 -Fantasy News
 - [https://www.youtube.com/watch?v=4t1yOVF8ylk](https://www.youtube.com/watch?v=4t1yOVF8ylk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-05-11 00:00:00+00:00

LET'S GET INTO THE FANTASY NEWS! 
Check out Campfire here: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q2_21 

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 

00:00 intro

00:23 Trolloc sighting: https://twitter.com/PrimeVideoDE/status/1391045224667942912?s=20 

01:33 LotR Podcast: https://deadline.com/2021/05/the-lord-of-the-rings-dominic-monaghan-billy-boyd-launch-podcast-1234749628/ 

02:10 Gene Wolfe Release: https://twitter.com/theotherbecca/status/1390649413064970243 

04:19 Women in fantasy: https://www.reddit.com/r/Fantasy/comments/n713om/rfantasys_top_books_by_women_2021_results/ 

05:23 Gifts Of Pandora: https://fanfiaddict.com/2021/05/07/cover-reveal-the-gifts-of-pandora-tapestry-of-fate-1-by-matt-larkin/ 

06:05 1899: https://www.youtube.com/watch?v=soj6bA35ABk&ab_channel=NetflixUK%26Ireland 

06:20 Sailor Moon Trailer: https://www.youtube.com/watch?v=XDnKDYpvEgo&ab_channel=Netflix 

06:31 Stranger Things Teaser: https://www.youtube.com/watch?v=AM-yohW7aiw 

06:48 Baldur’s Gate https://www.youtube.com/watch?v=rwyk7AFLcFM&ab_channel=IGN 

06:54 Dr. Strange Written Out: https://movieweb.com/doctor-strange-not-in-wandavision-explained/ 

08:01 Lightsaber: https://www.youtube.com/watch?v=YTztDAsqmSc&ab_channel=IGN 
(Real lightsaber: https://www.youtube.com/watch?v=xC6J4T_hUKg ) 

08:56 Venom Trailer: https://twitter.com/DiscussingFilm/status/1391739874299064321?s=20 

09:34 Love Death Robots S2 https://www.youtube.com/watch?v=AUaXtfAFva8&ab_channel=Netflix 

10:02 Catwoman Leak: https://www.cbr.com/the-batman-catwoman-zoe-kravitz-footage/

