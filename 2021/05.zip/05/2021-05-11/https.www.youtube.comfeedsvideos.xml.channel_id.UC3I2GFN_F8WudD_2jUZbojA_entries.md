# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Wild Pink - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=PffDR4vWOvM](https://www.youtube.com/watch?v=PffDR4vWOvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-12 00:00:00+00:00

http://KEXP.ORG presents Wild Pink performing live, recorded exclusively for KEXP.

Songs:
The Shining But Tropical
You Can Have It Back
Pacific City
Die Outside
If I Needed You

https://www.wildpinkmusic.com
http://kexp.org

## Wild Pink - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=a4rVfMZt67I](https://www.youtube.com/watch?v=a4rVfMZt67I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-11 00:00:00+00:00

http://KEXP.ORG presents Wild Pink sharing a live performance recorded exclusively for KEXP and talking to DJ Troy Nelson. Recorded April 27, 2021.

Songs:
The Shining But Tropical
You Can Have It Back
Pacific City
Die Outside
If I Needed You

https://www.wildpinkmusic.com
http://kexp.org

