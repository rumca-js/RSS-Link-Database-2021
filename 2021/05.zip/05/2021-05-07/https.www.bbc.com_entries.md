## Report: China emissions exceed all developed nations combined
 - [https://www.bbc.com/news/world-asia-57018837](https://www.bbc.com/news/world-asia-57018837)
 - RSS feed: https://www.bbc.com
 - date published: 2021-05-07 08:02:06+00:00

Report: China emissions exceed all developed nations combined

