# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Chinese luxury cars have entered Europe
 - [https://www.youtube.com/watch?v=kWcfMUTy5Hg](https://www.youtube.com/watch?v=kWcfMUTy5Hg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-05-07 00:00:00+00:00

Sponsored by Skillshare. The first 1000 to sign up with this link can try Skillshare Premium for free: https://skl.sh/thefridaycheckout05211

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► From this video ◄◄◄

This week HMD Global launched HMD Mobile, its own MVNO, Nio became the first premium Chinese car to enter Europe, and Twitter announced a ton of new content features like a Tip Jar.

The Friday Checkout - Episode 46

Poll: Do you know about Nio? https://twitter.com/TechAltar/status/1390693316191260676?s=20

-

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-chinese-luxury-cars-are-coming-to-europe

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:45 Release Highlights
1:46 Nokia carrier
4:18 Chinese cars in Europe
5:28 Twitter on a roll

