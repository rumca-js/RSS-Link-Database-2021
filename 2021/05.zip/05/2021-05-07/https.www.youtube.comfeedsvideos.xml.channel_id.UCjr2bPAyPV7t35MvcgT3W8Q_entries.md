# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Your Passwords Are Useless!
 - [https://www.youtube.com/watch?v=ze2i9V1_aIc](https://www.youtube.com/watch?v=ze2i9V1_aIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-05-07 00:00:00+00:00

Passwords are obsolete. Technology has far surpassed the level of protection passwords can offer. Abandon them!

Join my channel and become a member to enjoy perks https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Just realized I never elaborated on the 1 -  6 percent of the global GDB costs. It's from estimates of damages cost by cybercrime that range from $1 trillion to $6 trillion annually. 
Sources: 
https://cisomag.eccouncil.org/cybercrime-will-cost-the-world-us6-trillion-by-the-end-of-the-year-study/
https://www.techradar.com/news/cybercrime-cost-the-world-over-dollar1-trillion-in-2020

Passwords have been the default authentication method for decades and not much has changed about that. Except, we went from counting computing power in megahertz to gigahertz. But we are still using them, only with a non-binding recommendation of “try to make them more complicated.”

Half of your password security depends on making sure you do everything right. Create and manage complicated and unique password for each of your accounts, that should periodically change every few months, store your passwords somewhere safe, with properly encrypted backups you should rotate every time you make a change in any of the dozens of your accounts. And you need to make sure that all of the devices and software you are using to store your password is up to date and your system isn’t compromised and that you never fall a victim of a phishing attack.

Sources
Cybercrime cost $1 trillion in 2020 https://www.techradar.com/news/cybercrime-cost-the-world-over-dollar1-trillion-in-2020

The password is dead https://securityintelligence.com/passwords-are-dead-we-need-a-better-system-now/
https://www.digitaltrends.com/computing/why-the-password-is-dying/
https://blog.lastpass.com/2019/05/passwords-still-problem-according-2019-verizon-data-breach-investigations-report/
https://www.wired.com/2012/11/ff-mat-honan-password-hacker/
Phishing https://atlasvpn.com/blog/a-record-2-million-phishing-sites-reported-in-2020-highest-in-a-decade/
https://www.techradar.com/news/huge-rise-in-phishing-domains-since-covid-vaccines-began
https://www.helpnetsecurity.com/2021/04/27/defend-organization-phishing-attack/

Cybersecurity of data bases https://www.complianceweek.com/cyber-security/data-breach-disclosures-drop-in-2020-report-says/30234.article

Facebook password fail https://www.nbcnews.com/tech/tech-news/facebook-left-hundreds-millions-user-passwords-unencrypted-n985876
Facebook data leak https://edition.cnn.com/2021/04/06/tech/facebook-data-leaked-what-to-do/index.html

Passwords vs passwordless https://www.globenewswire.com/news-release/2018/06/13/1521214/0/en/New-Behavioral-Research-Shows-Over-70-of-Consumers-Choose-Passwordless-MFA-Login-Over-Traditional-Usernames-and-Passwords.html
https://services.google.com/fh/files/blogs/google_security_infographic.pdf
https://www.helpnetsecurity.com/2018/04/11/phishing-resistant-security/
FIDO https://fidoalliance.org/how-fido-works/
https://fidoalliance.org/specifications/
https://fidoalliance.org/specs/fido-v2.0-ps-20190130/fido-client-to-authenticator-protocol-v2.0-ps-20190130.html
https://fidoalliance.org/specs/u2f-specs-master/fido-u2f-overview.html
https://docs.microsoft.com/en-us/azure/active-directory/develop/support-fido2-authentication
https://fidoalliance.org/fido2/
https://eprint.iacr.org/2020/1298.pdf

Nitrokey: https://www.nitrokey.com/
SoloKeys: https://solokeys.com/
* I am not sponsored nor affiliated with either of these.

Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

