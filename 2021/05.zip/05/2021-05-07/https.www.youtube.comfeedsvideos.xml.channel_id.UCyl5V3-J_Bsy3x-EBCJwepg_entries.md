# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY:  Linkin’ Pork and Very Catholic Presidents
 - [https://www.youtube.com/watch?v=6XCoFUqg1P8](https://www.youtube.com/watch?v=6XCoFUqg1P8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-05-07 00:00:00+00:00

On The Babylon Bee Weekly, Ethan is joined by guest hosts Trevor Andersen and Dr. Thaddeus Williams. They talk about the weirdest of news like an elderly couple using morse code to escape an assisted living facility and Biden being called “a very Catholic president who supports abortion rights.” Thaddeus gives the best Linkin Park stories while Ethan and Trevor share little known pork facts in our newest segment: Linkin’ Pork. Hate mail this week comes from a reader who found our comments on Latter Day Saints to be “tasteless and unfunny.” 

Dr. Thaddeus Williams wrote a new book recently: Confronting Injustice Without Compromising Truth available at Amazon today! 

Become a premium subscriber:  https://babylonbee.com/plans 

The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Babylon Bee Attempts A World Record
 - [https://www.youtube.com/watch?v=_YYe7kqQY9w](https://www.youtube.com/watch?v=_YYe7kqQY9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-05-07 00:00:00+00:00

On The Babylon Bee Podcast, Kyle, Ethan and guest host Trevor attempt to break the world record for the fastest time to drink a Capri Sun. Can they do it? Or is this challenge harder than it would seem?

See the full show here: https://www.youtube.com/watch?v=suPkid7HpvM

Hit the bell to get your daily dose of fake news that you can trust.

