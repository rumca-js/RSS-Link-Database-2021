# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Tygrysy prawdopodobnie jechały na śmierć. Jest akt oskarżenia
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-136,S00E136,191053?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-136,S00E136,191053?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2021-05-07 11:22:47+00:00

<img alt="Tygrysy prawdopodobnie jechały na śmierć. Jest akt oskarżenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie3be3556434e2b48babc1bf8c81dfd1ad-w-czarno-na-bialym-historia-tygrysow-uratowanych-z-transportu-5012267/alternates/LANDSCAPE_1280" />
    Reporterka Katarzyna Górniak dotarła do ludzi, którzy wysłali tygrysy w podróż, i tych, do których miały one jechać. Przypominamy nagrodzony reportaż.

