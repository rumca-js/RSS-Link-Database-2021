# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Vaccine Gold Rush: Do You Trust Gates?
 - [https://www.youtube.com/watch?v=TCYz8B33UHA](https://www.youtube.com/watch?v=TCYz8B33UHA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-05-07 00:00:00+00:00

The pharmaceutical industry has been pouring resources into the growing political fight over generic coronavirus vaccines. They a useful and powerful ally in Bill Gates, so does this undermine his status as a philanthropist and make a mockery of his stated aim of getting the world “back to normal”?
#BillGates #VaccinePatent #Vaccine #Coronavirus #Covid19

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

My Audible Original, ‘Revelation', is out NOW!
US: 
http://adbl.co/revelation
UK: 
http://adbl.co/revelationuk
AU: 
http://adbl.co/revelationau
CA: 
http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

