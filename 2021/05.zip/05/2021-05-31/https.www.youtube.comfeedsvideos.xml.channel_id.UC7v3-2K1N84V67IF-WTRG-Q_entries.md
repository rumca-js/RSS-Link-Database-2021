# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Conjuring: The Devil Made Me Do It - Movie Review
 - [https://www.youtube.com/watch?v=ps08JllpMiY](https://www.youtube.com/watch?v=ps08JllpMiY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-06-01 00:00:00+00:00

We've Had many movies in the Conjuring universe. Now we get part 3 of the core lore....which sounds and feels like a spin off. Here's my review for THE CONJURING: THE DEVIL MADE ME DO IT!

#TheConjuring #TheConjuring3

## Castlevania - Season 4 (My Thoughts)
 - [https://www.youtube.com/watch?v=WscGPx8MUZg](https://www.youtube.com/watch?v=WscGPx8MUZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-05-31 00:00:00+00:00

Go to https://bit.ly/3qCEbYy use promo code DSCJAHNS, and new customers get 20% off their orders of $20 or more! Thank you Dr. Squatch for sponsoring!

CASTLEVANIA on Netflix comes to a close with the 4th and final season. Here are my thoughts on the big send off!

#Castlevania

