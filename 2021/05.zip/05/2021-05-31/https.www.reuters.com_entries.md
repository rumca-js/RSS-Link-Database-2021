## U.S. spied on Merkel and other Europeans through Danish cables - broadcaster DR
 - [https://www.reuters.com/world/europe/us-security-agency-spied-merkel-other-top-european-officials-through-danish-2021-05-30/](https://www.reuters.com/world/europe/us-security-agency-spied-merkel-other-top-european-officials-through-danish-2021-05-30/)
 - RSS feed: https://www.reuters.com
 - date published: 2021-05-31 11:51:40+00:00

U.S. spied on Merkel and other Europeans through Danish cables - broadcaster DR

