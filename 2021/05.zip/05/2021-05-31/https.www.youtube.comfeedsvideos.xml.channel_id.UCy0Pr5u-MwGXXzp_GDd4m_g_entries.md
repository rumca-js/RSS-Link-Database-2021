# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## LIVE Q&A and Merch Launch!
 - [https://www.youtube.com/watch?v=pJV_KpWCuFU](https://www.youtube.com/watch?v=pJV_KpWCuFU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-06-01 00:00:00+00:00

Tune in for a LIVE Q&A and peep my brand new merch drop!!!🤸‍♀️🌺🥓🤠https://julienolke.com/

