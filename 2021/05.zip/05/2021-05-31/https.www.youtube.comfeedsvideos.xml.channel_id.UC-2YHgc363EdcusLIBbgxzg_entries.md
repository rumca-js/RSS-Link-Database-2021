# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Woman Who Recorded Everything | Answers With Joe
 - [https://www.youtube.com/watch?v=sgVdZDFGqcs](https://www.youtube.com/watch?v=sgVdZDFGqcs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-05-31 00:00:00+00:00

Use code JOESCOTT12 to get up to 12 free meals, including shipping at https://bit.ly/3tXML4Q
Marion Stokes was an eccentric Philadelphia native who obsessively recorded multiple TV channels on VHS tapes for 35 years. Her archive of over 40,000 tapes have become a priceless document of a pivotal period of American history - and may help us to better understand the world today.


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

