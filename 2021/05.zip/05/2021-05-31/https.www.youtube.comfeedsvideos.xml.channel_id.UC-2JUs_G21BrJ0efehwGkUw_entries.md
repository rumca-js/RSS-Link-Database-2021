# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## It's Your Thing | The Isley Brothers | funk cover ft. Brooke Simpson
 - [https://www.youtube.com/watch?v=kTJmBIFbBpw](https://www.youtube.com/watch?v=kTJmBIFbBpw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-05-31 00:00:00+00:00

Join our Vinyl Club tier on Patreon to get vinyl every 3 months! http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of The Isley Brothers' "It's Your Thing" by Scary Pockets & Brooke Simpson. You may or may not have heard this song on a TV commercial for GOLF by the PGA Tour...

MUSICIAN CREDITS
Lead vocal: Brooke Simpson
Drums, Organ, Percussion, BGVs: Louis Cato
Bass: Solomon Dorsey
Guitar: Tiana Ohara
Guitar: Ryan Lerman
Keys: Jack Conte

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker
Producer: Louis Cato

VIDEO CREDITS
Director: Merlin Camozzi
DP: Marc Patterson
Camera Operator: Silvia Lara
Editor: Adam Kritzberg
Vlog Editor: Jude Smith
Lighting Design: Cole Peterson 
Production Design: Justin O’Brien
Tech: Joonas Cohen

Recorded Live at East West Studios in Los Angeles, CA.

#ScaryPockets #Funk #ItsYourThing #TheIsleyBrothers #BrookeSimpson

