# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Necromunda: Hired Gun Review
 - [https://www.youtube.com/watch?v=mOt6Nl1K5xU](https://www.youtube.com/watch?v=mOt6Nl1K5xU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2021-05-31 00:00:00+00:00

Streum-On has returned after Space Hulk Deathwing with a new Warhammer 40K FPS. Is it EYE Divine Cybermancy 2? Not exactly, but it's the janky fun you would expect.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/mandaloregaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
00:37 - State of the Launch
02:40 - Visuals
04:51 - Music & Sound Design
07:05 - Gameplay Mechanics
14:53 - Conclusions
15:34 - Credits
16:41 - Brother I Am Pinned Here
#Necromunda #NecromundaHiredGun #NecromundaReview #NecromundaHiredGunReview #NecromundaPC #NecromundaGame #Warhammer #Warhammer40K #Warhammer40KFPS

