# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Exploring XAOC Devices Moskwa II and Ostankino II (Eurorack Sequencing)
 - [https://www.youtube.com/watch?v=YCnlc70uHA0](https://www.youtube.com/watch?v=YCnlc70uHA0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-06-01 00:00:00+00:00

The XAOC Devices Moskwa II Rotosequencer is a sly powerhouse of sequencing fun. Its expander, the Ostankino, adds some extremely creative possibilities that can drive modulation or events in your system as well as completely change how the Moskwa responds. Let's dive into what makes this sequencing system special and how you might use it! 

Grab these both at Perfect Circuit: 
Moskwa II: https://bit.ly/3wLmmZZ
Ostankino II: https://bit.ly/2SM0xLd

glow cables my modbang: https://www.modbang.com/modbang-store

No talking jam video of this here: https://youtu.be/QA-QdW3ZBfU

XAOC Moskwa II and Ostankino sequence the Noise Engineering Cusus, Basimilus, and Loquelic Iteritas. Effects from Tip-Top z5000, 4ms DLD, and NE Imitor Versio running Electus firmware.

Tip-Top Z5000: http://bit.ly/pc_z5000
Noise Engineering Cursus Iteritas: http://bit.ly/pc_cursus
Noise Engineering Imitor Versio: http://bit.ly/pc_imitor
Noise Engineering BIA: https://bit.ly/3c7v5hi
Noise Engineering Loquelic Iteritas Percido: https://bit.ly/3wPtIeZ

00:00 intro
00:46 Moskwa basic operation
03:36 step options
07:43 custom mode
09:03 step repeat
10:11 micro-patterns
12:31 mini jam
14:14 transport and misc
15:30 Ostankino input modulation
21:05  Ostankino output modulation
26:20 recap
28:27 outro jam

------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

