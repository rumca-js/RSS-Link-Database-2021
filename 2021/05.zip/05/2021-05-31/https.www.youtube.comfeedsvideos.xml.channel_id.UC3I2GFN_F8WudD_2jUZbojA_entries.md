# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Isolated Tracks Episode 9: Anything At All by Bachelor
 - [https://www.youtube.com/watch?v=MdhEM1xB8FA](https://www.youtube.com/watch?v=MdhEM1xB8FA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-05-31 00:00:00+00:00

In this episode of Isolated Tracks, KEXP Audio Engineer Julian Martlew talks to Melina Duterte of Jay Som and Ellen Kempner of Palehound about their collaboration project: Bachelor. They dive into the song "Anything At All" from their debut new album "Doomin' Sun".

To hear the full song: https://www.youtube.com/watch?v=QwhQSTezXSU

http://kexp.org

