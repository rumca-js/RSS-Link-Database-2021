# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The Accidental Rush for Anthrax Island
 - [https://www.youtube.com/watch?v=suAC_PDP3Sk](https://www.youtube.com/watch?v=suAC_PDP3Sk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-05-31 00:00:00+00:00

Gruinard Island, in the north-west of Scotland, was where Britain tested its biological weapons. That story's been told many times: but I found something in the archives that I don't think anyone's ever noticed before.

Thanks to the boat crew and voice artists!
Location fixer: Vikki McCraw at Locations 365 http://www.locations365.co.uk/

SOURCES from the National Archives:
WO 188/2783
WO 188/3169
WO 32/20442
DEFE 55/118
DEFE 68/991, 992, 993

One other stories I found but couldn't fit into the video: the government spent a long time trying to work out the legal ramifications of selling the island back. In the end, they agreed to guarantee the cleanup for 150 years, which to me is the strongest evidence that there's nothing dangerous left there: they wouldn't have taken that risk otherwise!

Filmed safely: https://www.tomscott.com/safe/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

