# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Maybe Yawning Protects You From...Snakes?
 - [https://www.youtube.com/watch?v=ZYttn2jHjZ8](https://www.youtube.com/watch?v=ZYttn2jHjZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-06-01 00:00:00+00:00

Why is yawning contagious? It might be your body trying to keep on the lookout for snakes.

Hosted by: Rose Bear Don't Walk

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources: 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2780782/
https://link.springer.com/article/10.1007/s10071-020-01462-4
https://www.sciencedirect.com/science/article/abs/pii/S0031938419302665 
https://www.nytimes.com/2019/02/22/well/live/why-do-we-yawn.html 
https://apps.who.int/bloodproducts/snakeantivenoms/database/

IMAGE SOURCES
https://www.storyblocks.com/video/stock/two-spinning-fans-inside-a-computer-case-closeup-hagwxnfizjfkzchjx
https://www.storyblocks.com/video/stock/black-man-yawning-at-workplace-tired-man-supporting-head-sitting-near-notebook-in-office-male-professional-falling-asleep-at-coworking-space-hfzhkmayhjxa6sfq0
https://www.storyblocks.com/video/stock/python-snake-in-rainforest-fern-tree---diamond-python-rsgevlmalj15z0zke

## Meet Our Nitrogen-Breathing Bacterial Relative
 - [https://www.youtube.com/watch?v=RtCaGik0DFE](https://www.youtube.com/watch?v=RtCaGik0DFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-05-31 00:00:00+00:00

Oxygen is pretty great stuff, but this recently discovered organism couldn’t care less about oxygen. It breathes nitrogen and may offer a window into how the types of cells in OUR bodies may have evolved billions of years ago.

Go to http://Brilliant.org/SciShow to try their Computational Biology course. Sign up now and get 20% off an annual Premium subscription.

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org

----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://pubmed.ncbi.nlm.nih.gov/12732534/ 
https://www.sciencedirect.com/science/article/pii/S0891584918324006
https://news.mit.edu/2016/oxygen-first-appearance-earth-atmosphere-0513 
https://www.mpg.de/16524858/new-form-of-symbiosis-discovered
https://www.nature.com/articles/s41586-021-03297-6
https://www.earth.com/earthpedia-articles/paleoproterozoic/
http://butane.chem.uiuc.edu/pshapley/Environmental/L30/1.html
https://biologydictionary.net/mitochondria/
https://bio.libretexts.org/Bookshelves/Microbiology/Book%3A_Microbiology_(Kaiser)/Unit_4%3A_Eukaryotic_Microorganisms_and_Viruses/07%3A_The_Eukaryotic_Cell/7.8%3A_The_Endosymbiotic_Theory#:~:text=The%20endosymbiotic%20theory%20states%20that%20some%20of%20the,their%20own%20DNA%20which%20is%20circular%2C%20not%20linear.
https://pubmed.ncbi.nlm.nih.gov/16945388/
https://www.ruf.rice.edu/~bioslabs/studies/mitochondria/mitets.html
https://www.sciencedirect.com/science/article/pii/S0891584918324006

Images:
https://www.istockphoto.com/photo/happy-freedom-in-sunrise-nature-gm626586364-110725019
https://www.istockphoto.com/photo/human-cell-gm525886782-92488601
https://commons.wikimedia.org/wiki/File:CSIRO_ScienceImage_4203_A_bluegreen_algae_species_Cylindrospermum_sp_under_magnification.jpg
https://www.istockphoto.com/photo/human-cell-gm525886782-92488601
https://www.istockphoto.com/vector/cellular-respiration-medical-vector-illustration-diagram-respiration-process-scheme-gm908022116-250161238
https://www.istockphoto.com/photo/animal-cell-structure-gm483673049-25842365
https://www.nature.com/articles/s41586-021-03297-6
https://commons.wikimedia.org/wiki/File:Nitrate-3D-balls.png
https://commons.wikimedia.org/wiki/File:Aussicht_Winter_Rigi_Zugersee.jpg
https://www.istockphoto.com/photo/human-cell-gm525886782-92488601
https://www.istockphoto.com/photo/mitochondria-gm843284668-138573083
https://www.istockphoto.com/photo/four-colorful-protozoons-unicellular-organism-gm486809143-38580612
https://www.istockphoto.com/vector/set-of-flat-elements-for-spearfishing-scuba-diving-underwater-protective-sea-diver-gm855924394-141002385

