# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Memorial Day: 6 American heroes who gave their lives fighting for freedom
 - [https://www.foxnews.com/us/memorial-day-americans-gave-their-lives-fighting-for-freedom](https://www.foxnews.com/us/memorial-day-americans-gave-their-lives-fighting-for-freedom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2021-05-31 07:39:22+00:00

For Memorial Day, find time to honor these six Americans, and the many others, who sacrificed their lives so the United States could stay a free country.

