# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 E3 2021 Announcements That Would FREAK Us Out
 - [https://www.youtube.com/watch?v=7IdbmCddm1w](https://www.youtube.com/watch?v=7IdbmCddm1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-01 00:00:00+00:00

E3 2021 is right around the corner. Here are some big (maybe unrealistic) wishes of things we'd like to see.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Necromunda: Hired Gun - Before You Buy
 - [https://www.youtube.com/watch?v=g0IVC4IqwXI](https://www.youtube.com/watch?v=g0IVC4IqwXI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-05-31 00:00:00+00:00

Necromunda: Hired Gun (PC, PS4, PS5, Xbox One, Series X/S) is a unique FPS set in the Warhammer 40K universe. How is it? Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

