# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Hundreds of thousands are leaving Hong Kong for the UK
 - [https://www.cnn.com/videos/world/2021/05/31/hong-kong-bno-passport-uk-national-security-law-lu-stout-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/05/31/hong-kong-bno-passport-uk-national-security-law-lu-stout-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-05-31 09:51:53+00:00

The sweeping National Security Law has put people in Hong Kong on edge, with many choosing to leave their home city for good. CNN's Kristie Lu Stout speaks to some expected to settle permanently in the UK.

