# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Would NOT Want to be Intel Right Now........ AMD Computex 2021
 - [https://www.youtube.com/watch?v=XUKBa65vNZo](https://www.youtube.com/watch?v=XUKBa65vNZo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-01 00:00:00+00:00

Search, collaborate and share your 3D models with Thangs! Start exploring at https://bit.ly/2Qxzoux

Save 10% and Free Worldwide Shipping at Ridge Wallet by using offer code LINUS at https://www.ridge.com/LINUS

Dr. Lisa Su kicked off COMPUTEX 2021 with a bang, and there’s a LOT to talk about. So let’s do that. Sorry, Intel.

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1343703-intels-family-jewels-rn/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:08 APUs are back!
4:20 RDNA2 Mobile
5:19 FidelityFX Super Resolution
6:50 AMD Advantage program
8:54 The stuff AMD wouldn't tell us about
10:00 Conclusion

## Pour one out for Intel & NVIDIA… - AMD Radeon 6000M
 - [https://www.youtube.com/watch?v=kLNu34iDl4M](https://www.youtube.com/watch?v=kLNu34iDl4M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-01 00:00:00+00:00

Supercharge your Mac with Setapp! Download and install today at http://stpp.co/LinusTechTips2

Check out Crucial at: https://crucial.gg/LinusTechTips

When was the last time a FULLY AMD laptop could compete with the best Intel/Nvidia could muster? Um… never?
Gaming notebooks may never be the same…

Buy ASUS ROG Strix G15 Laptop (PAID LINK): https://geni.us/LtaOmY7

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1343462-pour-one-out-for-intelnvidia%E2%80%A6/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro

