# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## What The 2000s Thought Today Would Be: Phones
 - [https://www.youtube.com/watch?v=ccATWLEA7aQ](https://www.youtube.com/watch?v=ccATWLEA7aQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-05-31 00:00:00+00:00

So if I asked you what people in the 2000s thought 2020 would be like, it almost sounds like a slightly mundane inquiry on the surface. 2 decades isn’t “that much” time, and it stands to reason that their predictions would be that the tech of the day would get better.

Yes, that would make sense. But here’s the thing….modern smartphones, their absolute takeover of modern life, wasn’t a guarantee. IT wasn’t until 2010 or so that it seemed like these smartphones would define the upcoming decade. In 2000, they predicted that things would go a different way. A way that…well…you’ll have to see.

They were a bit off.

New Channel: https://www.youtube.com/c/Whimsu
Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
secret: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...


Additional Footage Credits:
The Gadget Show
9to5Software
Ideum
Buzz Bishop
David Hoffman
Mint Blitz
Linus Tech Tips
DankPods
Adam Savage’s Tested
Keiichi Matsuda
Men and MotorsDigital Foundry
Digital Bear Productions
Crystal edge technology screens
LGR
ovjang
Rene Schulte
CNET
Technology Virsa
Charbax
TechOdyssey
MaxParker

