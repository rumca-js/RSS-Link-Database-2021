# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Brad Smith: Rok 1984 może nadejść już w 2024 r.
 - [https://www.youtube.com/watch?v=lI6NeJp3-xs](https://www.youtube.com/watch?v=lI6NeJp3-xs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-06-01 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bbc.in/3fYwQyl
2. https://bit.ly/3i8T17D
3. https://bit.ly/3wPGFoY
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
microsoft.com - https://bit.ly/34DzFQ0
---------------------------------------------------------------
💡 Tagi: #microsoft #1984 #AI
--------------------------------------------------------------

## Austriacki polityk apeluje o większą kontrolę jakościową testów PCR i maseczek z Chin! Analiza
 - [https://www.youtube.com/watch?v=2-WGva5E_BY](https://www.youtube.com/watch?v=2-WGva5E_BY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-05-31 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3fRC7aU
2. https://bit.ly/3i5P3wp
3. https://bit.ly/3yLwqUJ
4. https://bit.ly/3yT4XAc
5. https://bit.ly/2Tq9n1f
6. https://bit.ly/3p3PoBs
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
youtube.com / Österreich zuerst
https://bit.ly/2Tq9n1f
---------------------------------------------------------------
💡 Tagi: #testyPCR #covid19
--------------------------------------------------------------

