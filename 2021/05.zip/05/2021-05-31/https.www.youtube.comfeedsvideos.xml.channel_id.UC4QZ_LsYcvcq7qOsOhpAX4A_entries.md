# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## When Risk Taking Goes Too Far - The Archegos Collapse
 - [https://www.youtube.com/watch?v=NtP3xT53dkU](https://www.youtube.com/watch?v=NtP3xT53dkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-06-01 00:00:00+00:00

Click the link to sign up to Wise, the world’s most international account: http://bit.ly/coldfusionandwise

ColdFusion Discord:  https://discord.gg/3WWKmzqMPY

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.wsj.com/articles/what-is-archegos-and-how-did-it-rattle-the-stock-market-11617044982

https://www.wsj.com/articles/inside-archegoss-epic-meltdown-11617323530?mod=series_archegos

https://www.wsj.com/articles/ex-tiger-asia-founder-triggers-30-billion-in-large-stocks-sales-11616973350?mod=article_inline

https://www.youtube.com/watch?v=zjHwU6cms0w&ab_channel=BridgerPennington

https://twitter.com/TrungTPhan/status/1378750061731926018

https://www.wsj.com/articles/who-is-archegos-fund-manager-bill-hwang-11617037264

https://www.wsj.com/articles/SB10001424127887323981504578175381113803630?mod=article_inline


My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Ephemerals - You'll Never See Me Cry (Ambassadeurs Remix)

Max 404 - Quiddity (Second Visit)

Marquis Hawkes - Dreamy - Unknown To The Unknown

A Zed And Two L's - Fila Brazillia

Helios - Hope Valley Hill (Arms and Sleepers Remix)

Julian Kruse - Dawn Over the Ocean

Hyphex - Fading Light

Lowercase Noises - The First Glimmer of Wind

Burn Water - She Shines


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

