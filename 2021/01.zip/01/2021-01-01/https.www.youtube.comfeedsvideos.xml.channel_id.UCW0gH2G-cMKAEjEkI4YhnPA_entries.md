# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Smaug & the Dragons of the North | Tolkien Explained
 - [https://www.youtube.com/watch?v=1ZxI2swm_1s](https://www.youtube.com/watch?v=1ZxI2swm_1s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-01-02 00:00:00+00:00

Today we cover the life of Smaug - the greatest dragon of the Third Age.  We also cover his ancestors - the dragons of the North - and their wars with the dwarves of the Grey Mountains - including the ancestors of Thorin Oakenshield.  From Scatha and Cold Drakes to Smaug and the dragons that may have existed after him, we talk about them all!

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings


-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

Conversation with Smaug - JRR Tolkien
Bilbo and Smaug - Diego Gisbert Llorens
Ancalagon the Black - Caglayan Kaya Goksoy
On the Doorstep - Chris Rahn
Erebor - Alan Lee
Fram Slays Scatha the Long Worm - Kip Rasmussen
Gandalf at Bag End - Myles Pinkney
Gandalf vs the Balrog - Daniel Govar
Red Dragon - Kenny Gonzalo
Old Friends - Momofukuu
The Teeth of Scatha - Matthew Stewart
The Slaying of Scatha - Lynton Levengood
Tom Bombadil - Borja Pindado
Smaug - Al Lukehart
The Cold Drake - Alvaro Calvo Escudero
Smaug - Anato Finnstark
Bard Faces Smaug - Kip Rasmussen
Bones of Smaug - Steamey
Dragon Bones - Stefan Koidl
A Conversation with Smaug - Ted Nasmith
Esgaroth is Burning - Moonxels
Smaug Destroys Laketown - Greg Hildebrandt
Dragons - Grzegorz Rutkowski
I Am Death - Tai91
Smaug Chasing Bilbo - Iken
Laketown - Toby Carr
Laketown - Nate Hallinan
Smaug - Nicolo Rigobello
The Hobbit - Bilbo & Smaug - Pablo Olivera
Black Arrow - Paolo Puggioni
Red Dragon - Mazanedo
Scatha - Lynton Levengood
Smaug and His Treasure - Shockbolt
Smaug - Ckgoksoy
Smaug - Mike Azevedo
Smaug - The Rising Soul
Smaug & Bilbo - The Rising Soul
Smaug Destroys Esgaroth - Gaius Duke
Smaug - David Demaret
Smaug's Arrival - Frerin Hagsolb
Smaug the Destroyer - Ted Nasmith
The Draconic War - Pietro Bouvier
Thief - Raoul Vitale
Scouring the Mountain - Ted Nasmith
Smaug Atop Erebor - Ted Nasmith
White Dragon - Vince L Falcone

Check out these resources for this and more info about Smaug, the Dragons of the North, and the War of Dwarves and Dragon:
The Hobbit
The Lord of the Rings Appendix A - Durin’s Folk
The Encyclopedia of Arda
Tolkien Gateway
Theonering.net “Today in Middle-earth History” Calendar

#smaug #thehobbit #tolkien

