# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Report from Oregon
 - [https://www.youtube.com/watch?v=SFfYM6e377s](https://www.youtube.com/watch?v=SFfYM6e377s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-01-02 00:00:00+00:00

Special report from Karli who is an RN in Oregon.
Karli promotes local ecology, check out her site, https://www.instagram.com/beetles_and_bees/
Check out this one as well, https://www.instagram.com/reel/CG53DqEhBDq/?igshid=bhi7i3cpnvah

## First dose COVID vaccination
 - [https://www.youtube.com/watch?v=LIFqzDQJHuw](https://www.youtube.com/watch?v=LIFqzDQJHuw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-01-01 00:00:00+00:00



## Vaccines, one shot or two?
 - [https://www.youtube.com/watch?v=M-jqf6i5OLc](https://www.youtube.com/watch?v=M-jqf6i5OLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-01-01 00:00:00+00:00

Oxford AZ vaccine

https://uk.reuters.com/article/uk-health-coronavirus-india-vaccine/astrazeneca-vaccine-set-to-become-first-to-get-approval-in-india-sources-idUKKBN29628Y

India approves Oxford vaccine

India’s Central Drugs Standard Control Organization (CDSCO)

Rollout to start Wednesday

UK

Argentina

India

What about Europe and the US?

Europe, 400 million does

US, 300 million doses


On different topic

https://news.sky.com/story/covid-19-vaccines-how-do-the-moderna-and-pfizer-coronavirus-jab-candidates-compare-12134062

https://www.businessinsider.com/cost-pfizer-astrazeneca-moderna-vaccine-eu-revealed-belgian-mp-2020-12?r=US&IR=T

Oxford AstraZeneca $2.18 per dose

Pfizer, $20

Moderna, $22.06 to $38 per dose


Where is rollout going well

Israel, 644,000 or 7% so far

Bahrain

UK

US 

Canada

Europe


Oxford/AstraZeneca vaccine

Phase 2 trials

56-day gap

Phase 3 trials

https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)32623-4/fulltext

Good immunity with 6-week gap

https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)32661-1/fulltext

Efficacy after one dose, 64%

Efficacy after 2 doses, 70 – 80%

Cases, 21 days after first SD, 64%

Vaccine group, 51 

Control group, 141 

Efficacy 64% 

Severe cases 21 days after the first dose of Oxford / AZ

Vaccine group, 0

Control group, 10 hospitalised (2 severe, 1 death)


Covid-19: Pfizer BioNTech vaccine efficacy was 52% after first dose and 95% after second dose

https://www.nejm.org/doi/full/10.1056/NEJMoa2034577?query=RP

https://www.bmj.com/content/371/bmj.m4826


Twelve days after the first dose

Vaccine group, 39 cases

Placebo group, 82 cases

52% efficacy

Severe cases after one dose

Vaccine group, 1

Placebo group, 9

New UK vaccine protocol

Change to one dose, second within 3 months

Statement from the UK Chief Medical Officers on the prioritisation of first doses of COVID-19 vaccines

https://www.gov.uk/government/news/statement-from-the-uk-chief-medical-officers-on-the-prioritisation-of-first-doses-of-covid-19-vaccines

Medicines and Healthcare products Regulatory Agency (MHRA)

Oxford, 2 doses 4 to 12 weeks apart

Pfizer, 2 doses 3 to 12 weeks apart 

The Joint Committee on Vaccination and Immunisation (JCVI)

will protect the greatest number of at risk people overall

in the shortest possible time

and will have the greatest impact on reducing mortality, 

severe disease

and hospitalisations

and in protecting the NHS and equivalent health services.

second doses of both vaccines will be administered towards the end of the recommended vaccine dosing schedule of 12 weeks

The Green Book

https://www.gov.uk/government/publications/covid-19-the-green-book-chapter-14a

https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/948757/Greenbook_chapter_14a_v4.pdf

If an interval longer than the recommended interval is left between doses, the second dose should still be given
(preferably using the same vaccine as was given for the first dose). 
The course does not need to be restarted. 
There is no evidence on the interchangeability of the COVID-19 vaccines although studies are underway. 
Therefore, every effort should be made to determine which vaccine the individual received and to complete with the same vaccine. 
There is no evidence of any safety concerns from vaccinating individuals with a past history of COVID-19 infection, or with detectable COVID-19 antibody.

