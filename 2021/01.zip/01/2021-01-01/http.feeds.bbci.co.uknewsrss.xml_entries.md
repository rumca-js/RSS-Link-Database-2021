# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Derided & lambasted – but is Solskjaer bringing the good times back to Man Utd?
 - [https://www.bbc.co.uk/sport/football/55511780](https://www.bbc.co.uk/sport/football/55511780)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 23:29:35+00:00

Derided, ridiculed and lambasted – but is Ole Gunnar Solskjaer bringing the good times back to Manchester United?

## Manchester United 2-1 Aston Villa: Dean Smith has 'a lot of doubt' about Man Utd penalty
 - [https://www.bbc.co.uk/sport/av/football/55510484](https://www.bbc.co.uk/sport/av/football/55510484)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 22:49:37+00:00

Aston Villa boss Dean Smith is unconvinced about the decision to award Manchester United a penalty, which resulted in Villa losing 2-1 at Old Trafford.

## US Congress overrides Trump veto for first time
 - [https://www.bbc.co.uk/news/world-us-canada-55510151](https://www.bbc.co.uk/news/world-us-canada-55510151)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 21:20:41+00:00

It is the first time this has happened in his presidency, just days before he leaves.

## Wham!'s Last Christmas goes to number one for the first time
 - [https://www.bbc.co.uk/news/entertainment-arts-55509575](https://www.bbc.co.uk/news/entertainment-arts-55509575)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 18:43:30+00:00

Wham!'s festive classic sets a new record for longest time taken for a single to top the chart.

## In pictures: The UK welcomes in the new year
 - [https://www.bbc.co.uk/news/uk-55509105](https://www.bbc.co.uk/news/uk-55509105)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 15:55:41+00:00

Fireworks, group video calls and swimmers bracing cold Scottish waters - how 2021 began.

## Tokyo Olympics will go ahead despite rising cases, says Japan's PM
 - [https://www.bbc.co.uk/sport/olympics/55506388](https://www.bbc.co.uk/sport/olympics/55506388)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 13:23:52+00:00

Japan's prime minister says the delayed Tokyo Olympics and Paralympics will go ahead this summer despite concern over rising coronavirus cases.

## Norway landslide: Swedes join search for 10 missing in Ask ravine
 - [https://www.bbc.co.uk/news/world-europe-55506734](https://www.bbc.co.uk/news/world-europe-55506734)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:56:25+00:00

A risky ground search is starting for 10 missing after a landslide swept homes into a chasm.

## Brexit: New era for UK as it completes separation from European Union
 - [https://www.bbc.co.uk/news/uk-politics-55502781](https://www.bbc.co.uk/news/uk-politics-55502781)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:55:05+00:00

Boris Johnson celebrates the "freedom in our hands" as the long Brexit process comes to a conclusion.

## Covid: 'Nail-biting' weeks ahead for NHS, hospitals in England warn
 - [https://www.bbc.co.uk/news/uk-55505722](https://www.bbc.co.uk/news/uk-55505722)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:48:36+00:00

Doctors urge public to "take it seriously" and follow coronavirus restrictions amid rising cases.

## New Year's Eve: UK sees in 2021 with fireworks and light show
 - [https://www.bbc.co.uk/news/uk-55504450](https://www.bbc.co.uk/news/uk-55504450)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:32:08+00:00

It comes as most people heeded warnings to stay home - but police issued fines to those who didn't.

## Four ponies killed in New Forest collision
 - [https://www.bbc.co.uk/news/uk-england-hampshire-55506891](https://www.bbc.co.uk/news/uk-england-hampshire-55506891)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:30:02+00:00

They were hit while licking freshly laid salt on a road which is a black spot for animal accidents.

## Brexit: Seven things changing on 1 January
 - [https://www.bbc.co.uk/news/explainers-54195827](https://www.bbc.co.uk/news/explainers-54195827)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:26:38+00:00

What will be different about the UK's relationship with the EU from 1 January 2021?

## In pictures: New Year, but not quite as we know it
 - [https://www.bbc.co.uk/news/world-55494549](https://www.bbc.co.uk/news/world-55494549)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:22:00+00:00

Firework displays and some religious rituals go ahead, although Covid mutes celebrations.

## Hales stars again as Sydney Thunder go clear at top of Big Bash table
 - [https://www.bbc.co.uk/sport/cricket/55507669](https://www.bbc.co.uk/sport/cricket/55507669)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:11:41+00:00

Exiled England batsman Alex Hales again stars in Sydney Thunder's Big Bash victory over Melbourne Renegades.

## Mobile roaming: What will happen to charges after Brexit?
 - [https://www.bbc.co.uk/news/business-45064268](https://www.bbc.co.uk/news/business-45064268)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 12:11:00+00:00

Will Britons be able to use their mobile phones in Europe after Brexit transition, without paying extra?

## Covid: Councils call for all London schools to stay shut
 - [https://www.bbc.co.uk/news/uk-england-london-55507001](https://www.bbc.co.uk/news/uk-england-london-55507001)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 11:49:02+00:00

Primary schools in only 10 of London's boroughs are due to reopen next week.

## Brexit: What are the rules on driving in the EU after transition?
 - [https://www.bbc.co.uk/news/uk-47459859](https://www.bbc.co.uk/news/uk-47459859)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 11:20:22+00:00

What will change for UK drivers abroad now the UK is no longer following EU rules?

## Covid-19: Barnsley bugler in final tribute to victims
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-55506827](https://www.bbc.co.uk/news/uk-england-south-yorkshire-55506827)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 10:49:12+00:00

Paul Goose played the Last Post every night in memory of those who have died.

## Brexit: New Irish Sea trade border begins operating
 - [https://www.bbc.co.uk/news/uk-northern-ireland-55498775](https://www.bbc.co.uk/news/uk-northern-ireland-55498775)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 09:48:26+00:00

The trade border means most commercial goods entering NI from GB now require a customs declaration.

## NBA: Phoenix Suns beat Utah Jazz to go 4-1, Philadelphia 76ers beat Orlando Magic
 - [https://www.bbc.co.uk/sport/basketball/55505873](https://www.bbc.co.uk/sport/basketball/55505873)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 09:11:12+00:00

Devin Booker scores 25 points as the Phoenix Suns beat the Utah Jazz and move to 4-1 for the first time since 2009.

## Covid: 12-week vaccine gap defended by UK medical chiefs
 - [https://www.bbc.co.uk/news/uk-55503739](https://www.bbc.co.uk/news/uk-55503739)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 07:30:45+00:00

The UK will now leave a 12-week gap between both parts of the Covid vaccination, rather than 21 days.

## Football in 2021: Five reasons why it could be a great footballing year
 - [https://www.bbc.co.uk/sport/football/55468694](https://www.bbc.co.uk/sport/football/55468694)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 07:17:48+00:00

Optimism was in short supply in 2020, but here are five footballing things which could bring us some positivity in 2021.

## New year, new you? 21 ways to get fit in 2021
 - [https://www.bbc.co.uk/sport/55151792](https://www.bbc.co.uk/sport/55151792)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 07:17:25+00:00

Looking to get fit in 2021? We've got you covered with 21 simple ways to get healthy after Christmas.

## Watch New Year's Day Premier League crackers - from rockets to scorpion kicks
 - [https://www.bbc.co.uk/sport/av/football/55469415](https://www.bbc.co.uk/sport/av/football/55469415)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 07:15:36+00:00

Watch some of the greatest Premier League goals scored on New Year's Day, including Yaya Toure's rocket and Olivier Giroud's scorpion kick.

## The Papers: New Year hope and campaign to recruit 'jabs army'
 - [https://www.bbc.co.uk/news/blogs-the-papers-55504029](https://www.bbc.co.uk/news/blogs-the-papers-55504029)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 05:35:40+00:00

The first newspapers of 2021 offer a message of hope after "the worst year in living memory".

## Activists cheer as 'sexist' tampon tax is scrapped
 - [https://www.bbc.co.uk/news/business-55502252](https://www.bbc.co.uk/news/business-55502252)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 03:44:19+00:00

Campaigners say cutting of the 5% VAT rate on tampons and sanitary towels ends a 'sexist' tax.

## Entertainment quiz of 2020
 - [https://www.bbc.co.uk/news/entertainment-arts-55403603](https://www.bbc.co.uk/news/entertainment-arts-55403603)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 01:03:49+00:00

It was a year to forget for the arts and entertainment. But let's see what you can remember.

## Was I wrong to fall for a cheating cat?
 - [https://www.bbc.co.uk/news/stories-54710400](https://www.bbc.co.uk/news/stories-54710400)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 01:03:02+00:00

Anisa Subedar fell in love with a visiting cat. It wanted attention, so she gave it attention. Then it disappeared.

## Adobe Flash Player is finally laid to rest
 - [https://www.bbc.co.uk/news/technology-55497353](https://www.bbc.co.uk/news/technology-55497353)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 00:33:06+00:00

The beleaguered web browser plug-in will no longer receive security updates from Adobe.

## Brexit: 'We welcomed the trade deal like a Christmas present'
 - [https://www.bbc.co.uk/news/world-europe-55497401](https://www.bbc.co.uk/news/world-europe-55497401)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 00:26:07+00:00

Europeans in the UK, and British people around Europe, explain what Brexit will mean for them.

## Moscow train carriage helps rehome stray pets
 - [https://www.bbc.co.uk/news/world-europe-55418334](https://www.bbc.co.uk/news/world-europe-55418334)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 00:12:44+00:00

The Tails and Paws train features posters of dozens of animals in need of a new home.

## US politics in 2021: What's in store for President-elect Biden?
 - [https://www.bbc.co.uk/news/world-us-canada-55431724](https://www.bbc.co.uk/news/world-us-canada-55431724)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 00:11:21+00:00

A new president with an agenda that's already set - and an outgoing president who's not leaving quietly.

## India's love affair with classic British motorbikes
 - [https://www.bbc.co.uk/news/business-54997191](https://www.bbc.co.uk/news/business-54997191)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 00:11:02+00:00

BSA, Norton and Royal Enfield are all owned by Indian firms who want to kickstart the brands.

## Why 2021 could be turning point for tackling climate change
 - [https://www.bbc.co.uk/news/science-environment-55498657](https://www.bbc.co.uk/news/science-environment-55498657)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-01 00:09:54+00:00

This year could be a "make or break" moment in the fight against global warming.

