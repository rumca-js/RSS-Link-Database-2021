# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Suspect arrested in Colchester after killing of 83-year-old man
 - [https://www.theguardian.com/uk-news/2021/jan/01/suspect-arrested-in-colchester-after-killing-of-83-year-old-man](https://www.theguardian.com/uk-news/2021/jan/01/suspect-arrested-in-colchester-after-killing-of-83-year-old-man)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 23:05:03+00:00

<p>Police no longer looking for a suspect after arrest of man in connection with death of Donald Ralph in Essex</p><p>Police on the hunt for Leighton Snook in connection with the murder of a pensioner earlier this week have arrested a 28-year-old man in Colchester.</p><p>The suspect was wanted in connection with the killing of 83-year-old Donald Ralph at his home in the Essex village of Aldham on Tuesday.</p> <a href="https://www.theguardian.com/uk-news/2021/jan/01/suspect-arrested-in-colchester-after-killing-of-83-year-old-man">Continue reading...</a>

## Extend Covid measures or households face 'cliff edges', says Labour
 - [https://www.theguardian.com/business/2021/jan/01/covid-measures-labour-universal-credit-evictions](https://www.theguardian.com/business/2021/jan/01/covid-measures-labour-universal-credit-evictions)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 22:30:21+00:00

<p>Universal credit boost, ban on evictions and mortgage holiday must continue, party says</p><ul><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Many low- and middle-income households will face financial hardship unless ministers maintain support for those who have lost their jobs or experienced steep cuts in income during the second wave of Covid-19, Labour has said.</p><p>The shadow chancellor, Anneliese Dodds, said in a new year message to Rishi Sunak that the chancellor must extend a range of Covid-19 rescue measures due to run out over the next three months “to protect struggling households from financial ruin”.</p> <a href="https://www.theguardian.com/business/2021/jan/01/covid-measures-labour-universal-credit-evictions">Continue reading...</a>

## Schools U-turn and rising Covid cases crush hopes of new year easing
 - [https://www.theguardian.com/world/2021/jan/01/schools-u-turn-and-rising-covid-numbers-crush-hopes-of-new-year-easing](https://www.theguardian.com/world/2021/jan/01/schools-u-turn-and-rising-covid-numbers-crush-hopes-of-new-year-easing)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 20:35:55+00:00

<p>London’s Nightingale hospital expected to take patients as NHS struggles with number of severely ill people </p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Government hopes for a new year easing of the Covid pandemic are unravelling, with ministers forced into a U-turn on reopening primary schools and hospitals across the country struggling with rising numbers of severely ill patients.</p><p>As the crisis escalates, the Nightingale hospital built in London’s ExCeL centre is expected to take Covid patients next week, for <a href="https://www.theguardian.com/society/2020/oct/08/what-has-happened-to-englands-seven-nightingale-hospitals">the first time since the spring</a>.</p> <a href="https://www.theguardian.com/world/2021/jan/01/schools-u-turn-and-rising-covid-numbers-crush-hopes-of-new-year-easing">Continue reading...</a>

## NHS staff fear speaking out over crisis in English hospitals
 - [https://www.theguardian.com/world/2021/jan/01/nhs-england-staff-fear-speaking-out-over-covid-crisis-in-hospitals](https://www.theguardian.com/world/2021/jan/01/nhs-england-staff-fear-speaking-out-over-covid-crisis-in-hospitals)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 20:14:50+00:00

<p>Nurses alarmed at staffing levels, infection control and myths spreading on social media</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Nine months ago, Boris Johnson <a href="https://www.theguardian.com/politics/video/2020/apr/12/coronavirus-boris-johnson-nhs-hospital-video">praised staff</a> at St Thomas’ for saving his life. Now, a senior intensive care nurse at the London hospital has warned that patient care is being compromised because of staff shortages and a failure to plan for the second Covid wave.</p><p>Dave Carr, an intensive care charge nurse, is one of many NHS workers desperate for the public to know what is going on inside their hospitals at a time when misinformation and scepticism about the virus are rife.</p> <a href="https://www.theguardian.com/world/2021/jan/01/nhs-england-staff-fear-speaking-out-over-covid-crisis-in-hospitals">Continue reading...</a>

## 20 photographs of the week
 - [https://www.theguardian.com/artanddesign/gallery/2021/jan/01/20-photographs-of-the-week](https://www.theguardian.com/artanddesign/gallery/2021/jan/01/20-photographs-of-the-week)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 19:24:30+00:00

<p>Pro-choice activists celebrate in Buenos Aires, police break up New Year’s Eve celebrations, the enduring impact of Covid-19 and the earthquake in Croatia: the most striking images from around the world</p> <a href="https://www.theguardian.com/artanddesign/gallery/2021/jan/01/20-photographs-of-the-week">Continue reading...</a>

## 'A spoilt brat country': the Australians overseas who decided not to come home
 - [https://www.theguardian.com/lifeandstyle/2021/jan/02/a-spoilt-brat-country-the-australians-overseas-who-decided-not-to-come-home](https://www.theguardian.com/lifeandstyle/2021/jan/02/a-spoilt-brat-country-the-australians-overseas-who-decided-not-to-come-home)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 19:00:18+00:00

<p>While hundreds of thousands of Australians returned in 2020, and thousands more struggled to, most expatriates stayed put – here some share why</p><p>Before the Covid-19 pandemic, the foreign affairs department estimated there were about one million Australians living overseas at any given time. This year, between March and October about<a href="https://www.foreignminister.gov.au/minister/marise-payne/media-release/more-flights-helping-australians-return"> 398,000</a> Australians forked out thousands of dollars and navigated strict border controls to return home, many for good. At least another 36,000 <a href="https://www.theguardian.com/australia-news/2020/dec/06/stranded-australians-are-being-reclassified-to-avoid-embarrassing-pm-labor-says">wanted to return</a>, but were unable to do so. Which means that most decided to stay where they were – and for some the events of 2020 crystallised exactly why.</p><p>“It’s difficult to feel a sense of belonging when fellow Australians act like they don’t want us to come home,” says Ashton Hollwarth, a vet who moved from Perth to the UK five years ago. “People say things like ‘Well, you chose to stay there’ and ‘you were told to come home’ when I have friends that spent thousands trying and had so many flights cancelled. The way Aussies in Australia turned on Aussies abroad is hurtful and a little frightening.”</p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/02/a-spoilt-brat-country-the-australians-overseas-who-decided-not-to-come-home">Continue reading...</a>

## Golden ticket: the lucky tourists sitting out coronavirus in New Zealand
 - [https://www.theguardian.com/world/2021/jan/01/a-golden-ticket-the-tourists-who-sat-out-coronavirus-in-new-zealand](https://www.theguardian.com/world/2021/jan/01/a-golden-ticket-the-tourists-who-sat-out-coronavirus-in-new-zealand)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 19:00:17+00:00

<p>Visitors from UK and North America tell of finding themselves with a pass to one of the best-rated pandemic responses in the world</p><p>For Christmas 2019 Efrain Vega de Varona gave his partner plane tickets to New Zealand – her dream holiday destination. It has proved a gift that keeps on giving.</p><p>A year later they are still in New Zealand, having decided to stay put at the end of their two-week holiday in mid-March rather than return to Los Angeles. “We’ve been living out of two suitcases for 10 months,” says Vega de Varona from their latest Airbnb rental (number 50-something this year) in Island Bay, Wellington.</p> <a href="https://www.theguardian.com/world/2021/jan/01/a-golden-ticket-the-tourists-who-sat-out-coronavirus-in-new-zealand">Continue reading...</a>

## Everton v West Ham United: Premier League – live!
 - [https://www.theguardian.com/football/live/2021/jan/01/everton-v-west-ham-united-premier-league-live](https://www.theguardian.com/football/live/2021/jan/01/everton-v-west-ham-united-premier-league-live)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 18:22:39+00:00

<ul><li>Premier League updates from the 5.30pm (GMT) kick-off </li><li><a href="https://www.theguardian.com/football/premierleague/table">It’s tight at the top: the in-running Premier League table</a></li><li>Get in touch! <a href="mailto:nick.ames@theguardian.com">Email Nick</a> or tweet <a href="https://twitter.com/NickAmes82">@NickAmes82</a></li></ul><p class="block-time published-time"> <time datetime="2021-01-01T18:22:31.353Z">6.22pm <span class="timezone">GMT</span></time> </p><p><strong>Peter Pearson asks:</strong> “Another wish here for Covid to get lost and fans to return to stadiums. I’d love to visit London again and see the new Plough Lane. Also hope Clapton CFC get their new clubhouse roof.</p><p>“It’s been really nice having the MBM chat and community during 2020 so thanks for that. Did you eat anything nice over the holidays?”</p><p class="block-time published-time"> <time datetime="2021-01-01T18:20:18.815Z">6.20pm <span class="timezone">GMT</span></time> </p><p><strong>Brendan O’Sullivan requests of 2021:</strong> “As an Arsenal fan, can I get creative and ask that Silent Stan Kroenke sell Arsenal to a fan-owned co-operative (with me providing much of the financing after I win the lottery...).”</p> <a href="https://www.theguardian.com/football/live/2021/jan/01/everton-v-west-ham-united-premier-league-live">Continue reading...</a>

## Coronavirus live news: Turkey bans arrivals from Britain after variant cases confirmed; 53,285 new UK infections
 - [https://www.theguardian.com/world/live/2021/jan/01/coronavirus-live-news-new-covid-variant-b117-in-united-states-since-october](https://www.theguardian.com/world/live/2021/jan/01/coronavirus-live-news-new-covid-variant-b117-in-united-states-since-october)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 18:20:26+00:00

<p>Latest updates: <a href="https://www.theguardian.com/world/live/2021/jan/01/coronavirus-live-news-new-covid-variant-b117-in-united-states-since-october?page=with:block-5fef5eba8f08d08389ae827a#block-5fef5eba8f08d08389ae827a">15 cases of UK variant confirmed in Turkey</a>; <a href="https://www.theguardian.com/world/live/2021/jan/01/coronavirus-live-news-new-covid-variant-b117-in-united-states-since-october?page=with:block-5fef44508f08d08389ae812c#block-5fef44508f08d08389ae812c">613 Covid-linked deaths recorded in UK</a>; <a href="https://www.theguardian.com/world/live/2021/jan/01/coronavirus-live-news-new-covid-variant-b117-in-united-states-since-october?page=with:block-5fef36068f08d0452b08994e#block-5fef36068f08d0452b08994e">France to impose earlier curfews in 15 departments</a></p><ul><li><a href="https://www.theguardian.com/world/2021/jan/01/france-to-step-up-covid-jabs-after-claims-of-bowing-to-anti-vaxxers">BioNTech criticises EU failure to order enough Covid vaccine</a></li><li><a href="https://www.theguardian.com/world/2020/dec/31/london-hospital-uclh-warns-on-track-become-covid-only">Key London hospital preparing for Covid-only care as cases surge</a></li><li><a href="https://www.theguardian.com/world/2021/jan/01/now-coronavirus-variant-us-since-october">New coronavirus variant may have been in US since October</a></li><li><a href="https://www.theguardian.com/society/2020/dec/31/doctors-despair-over-britons-breaking-coronavirus-rules">UK doctors despair over public’s disregard for rules</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p class="block-time published-time"> <time datetime="2021-01-01T18:17:52.203Z">6.17pm <span class="timezone">GMT</span></time> </p><p>All primary schools in <strong>London</strong> are set to close for the start of the new term after the <strong>UK</strong> government bowed to protests and legal pressure from the capital’s local authorities amid fears of Covid-19 infection rates, <strong>Richard Adams</strong> and <strong>Simon Murphy</strong> report.</p><p>The U-turn comes after the government <a href="https://www.theguardian.com/education/2020/dec/31/school-leaders-and-councils-demand-primary-closure-decisions-explained">initially named 50 education authorities in the south of England</a>, including many of those in and around London, where primary schools would be closed to most pupils for the first two weeks of term.</p><p> <span>Related: </span><a href="https://www.theguardian.com/education/2021/jan/01/all-primary-schools-in-london-to-remain-closed-after-u-turn">All primary schools in London to remain closed after U-turn</a> </p><p class="block-time published-time"> <time datetime="2021-01-01T18:00:51.770Z">6.00pm <span class="timezone">GMT</span></time> </p><p>The <strong>US</strong> <a href="https://coronavirus.jhu.edu/map.html">has become</a> the first country to pass 20m lab-confirmed Covid cases, though the true number of infections is thought to be much higher.</p><p>Back in June, US public health experts <a href="https://www.theguardian.com/us-news/2020/jun/25/us-coronavirus-cases-count-cdc">said they believed</a> more than 20 million Americans could have contracted the respiratory virus – 10 times more than official counts at the time.</p><p> <span>Related: </span><a href="https://www.theguardian.com/world/2021/jan/01/us-surpasses-20m-coronavirus-cases-on-new-years-day">US surpasses 20m coronavirus cases on New Year's Day</a> </p> <a href="https://www.theguardian.com/world/live/2021/jan/01/coronavirus-live-news-new-covid-variant-b117-in-united-states-since-october">Continue reading...</a>

## Closure of Covid-testing facility a factor in Championship match being called off
 - [https://www.theguardian.com/football/2021/jan/01/efl-players-told-to-turn-up-for-training-in-kit-amid-fresh-covid-clampdown](https://www.theguardian.com/football/2021/jan/01/efl-players-told-to-turn-up-for-training-in-kit-amid-fresh-covid-clampdown)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 18:10:02+00:00

<ul><li>Bristol City v Brentford and Luton v QPR postponed on Friday</li><li>EFL players told to arrive for training in kit as indoor areas shut</li></ul><p>Bristol City have announced their Championship match at Brentford on Saturday has been postponed, with the Bristol club arguing the bank holiday closure of a testing facility meant it had not been possible to arrange the testing of the entire squad and backroom staff before Saturday’s match.</p><p>In a statement on their official website, the Robins said coronavirus symptoms had become evident within their squad on New Year’s Day: “Following discussions with Brentford and the English Football League the decision has been taken to postpone the game for the safety of players and staff of both clubs. A new date for the fixture will be announced in due course.”</p> <a href="https://www.theguardian.com/football/2021/jan/01/efl-players-told-to-turn-up-for-training-in-kit-amid-fresh-covid-clampdown">Continue reading...</a>

## All primary schools in London to remain closed after U-turn
 - [https://www.theguardian.com/education/2021/jan/01/all-primary-schools-in-london-to-remain-closed-after-u-turn](https://www.theguardian.com/education/2021/jan/01/all-primary-schools-in-london-to-remain-closed-after-u-turn)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 18:07:48+00:00

<p>Exclusive: government bows to protests over new term amid fears of Covid-19 infection rates </p><p>All primary schools in London are set to close for the start of the new term after the government bowed to protests and legal pressure from the capital’s local authorities.</p><p>The U-turn comes after the government <a href="https://www.theguardian.com/education/2020/dec/31/school-leaders-and-councils-demand-primary-closure-decisions-explained">initially named 50 education authorities in the south of England</a>, including many of those in and around London, where primary schools would be closed to most pupils for the first two weeks of term.</p> <a href="https://www.theguardian.com/education/2021/jan/01/all-primary-schools-in-london-to-remain-closed-after-u-turn">Continue reading...</a>

## Last Christmas by Wham! reaches No 1 for first time after 36 years
 - [https://www.theguardian.com/music/2021/jan/01/last-christmas-by-wham-reaches-no-1-for-first-time-after-36-years](https://www.theguardian.com/music/2021/jan/01/last-christmas-by-wham-reaches-no-1-for-first-time-after-36-years)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 18:00:15+00:00

<p>Festive favourite was kept off No 1 by Band Aid’s Do They Know It’s Christmas? in 1984</p><p>Wham!’s Last Christmas has reached No 1 in the UK singles chart for the first time, 36 years after it was first released.</p><p>Widely regarded as one of the greatest Christmas songs of all time, it was originally held off the top spot in 1984 by Band Aid’s charity single Do They Know It’s Christmas?</p> <a href="https://www.theguardian.com/music/2021/jan/01/last-christmas-by-wham-reaches-no-1-for-first-time-after-36-years">Continue reading...</a>

## What difference will Oxford/AstraZeneca vaccine make in UK?
 - [https://www.theguardian.com/world/2021/jan/01/what-difference-will-the-astrazeneca-vaccine-make-in-the-uk](https://www.theguardian.com/world/2021/jan/01/what-difference-will-the-astrazeneca-vaccine-make-in-the-uk)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 17:57:02+00:00

<p><strong>Analysis:</strong> we look at how the introduction of a new vaccine in the fight against Covid will work</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p> <span>Related: </span><a href="https://www.theguardian.com/world/2021/jan/01/france-to-step-up-covid-jabs-after-claims-of-bowing-to-anti-vaxxers">BioNTech criticises EU failure to order enough Covid vaccine</a> </p> <a href="https://www.theguardian.com/world/2021/jan/01/what-difference-will-the-astrazeneca-vaccine-make-in-the-uk">Continue reading...</a>

## 'Betrayed': Dover residents furious over building of Brexit lorry park
 - [https://www.theguardian.com/politics/2021/jan/01/residents-furious-brexit-lorry-park-kent-village](https://www.theguardian.com/politics/2021/jan/01/residents-furious-brexit-lorry-park-kent-village)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 17:55:07+00:00

<p>Letter from transport minister sent on New Year’s Eve said white cliffs site will be turned into ‘Inland Border Facility’ </p><p>It was <a href="https://www.theguardian.com/politics/2020/dec/31/exit-epilogue-eerily-quiet-dover-meets-brexit-deadline">all quiet on the Dover front</a> in the hours after the UK left the EU, as lorries continued to avoid the port.</p><p>But just minutes away, beyond the famous white cliffs, the sense of fury over Brexit was palpable as local residents came to terms with a government letter they received on New Year’s Eve telling them that from summer, their rural idyll of farmland and ancient Roman ways would be transformed into a customs clearance lorry park for 1,200 trucks.</p> <a href="https://www.theguardian.com/politics/2021/jan/01/residents-furious-brexit-lorry-park-kent-village">Continue reading...</a>

## Mark Eden obituary
 - [https://www.theguardian.com/tv-and-radio/2021/jan/01/mark-eden-obituary](https://www.theguardian.com/tv-and-radio/2021/jan/01/mark-eden-obituary)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 17:51:46+00:00

Prolific screen actor who found TV soap fame as the Coronation Street villain Alan Bradley<p>The actor Mark Eden, who has died aged 92, brought high drama to Coronation Street when he played Alan Bradley, who defrauded the singer-turned-newsagent Rita Fairclough, then terrorised her – before meeting his death under a Blackpool tram.</p><p>Eden joined the TV soap in 1986, when Alan visited his estranged daughter, Jenny, while she was being fostered by Rita, following his ex-wife’s death. Alan dated Rita, played by Barbara Knox, but two-timed her with the barmaid Gloria Todd. He was eventually dumped by Gloria and set up Weatherfield Security Systems – funded by stealing the deeds to Rita’s house and posing as her late husband Len to remortgage it – and tried to rape his receptionist, Dawn Prescott. When Rita found out, he tried to suffocate her, was interrupted by Jenny, then fled. Although sentenced to two years in prison, he was freed immediately after six months on remand.</p> <a href="https://www.theguardian.com/tv-and-radio/2021/jan/01/mark-eden-obituary">Continue reading...</a>

## Change in vaccine policy is a high-stakes gamble | Letters
 - [https://www.theguardian.com/world/2021/jan/01/change-in-vaccine-policy-is-a-high-stakes-gamble](https://www.theguardian.com/world/2021/jan/01/change-in-vaccine-policy-is-a-high-stakes-gamble)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 17:31:48+00:00

<p>The effectiveness of delaying the second dose of Covid vaccines must be carefully monitored, argues <strong>Dr Grizelda George, </strong>while <strong>Jan Mortimer </strong>and <strong>Jenny van Tinteren</strong> fear the move will increase distrust and uncertainty</p><p>The manufacturer of the Pfizer/BioNTech vaccine has said its efficacy has only been assessed for two doses given three weeks apart. Therefore the idea that a single dose will be protective beyond three weeks is speculative (<a href="https://www.theguardian.com/society/2020/dec/31/covid-vaccine-uk-doctors-criticise-rescheduling-of-second-doses" title="">Covid vaccine: chief medical officers defend rescheduling of second doses</a>, 31 December). It would be truly tragic to vaccinate millions of recipients with the Pfizer/ BioNTech vaccine (at considerable effort and financial cost) with a twelve-week gap between doses if this doesn’t give them protection.</p><p>It is worth noting that there is likely to be a correlation between the antibody response and protection from infection. Therefore volunteers who have already completed two doses could be asked to give a small sample of blood to check the level of neutralising antibodies present four weeks from the first dose. Recipients whose second dose has been postponed after 4 January could give a similar sample from 11 January onwards to check their levels at the four-week point. A relatively small number of volunteers (perhaps 20 or 30 in each group) might settle this.</p> <a href="https://www.theguardian.com/world/2021/jan/01/change-in-vaccine-policy-is-a-high-stakes-gamble">Continue reading...</a>

## Iran fears Trump preparing attack in final weeks in office
 - [https://www.theguardian.com/world/2020/dec/31/iran-says-trump-is-trying-to-fabricate-pretext-for-war](https://www.theguardian.com/world/2020/dec/31/iran-says-trump-is-trying-to-fabricate-pretext-for-war)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 17:23:16+00:00

<p>Tehran says it will defend itself forcefully as tensions rise ahead of anniversary of Suleimani killing</p><p>Iran fears that Donald Trump is preparing to order a military attack on its regional interests in the final three weeks of his administration and has warned it would retaliate against US bases in the Middle East.</p><p>Concerns have increased in Tehran over the past week that the US president could authorise a strike against Iranian proxy groups operating in Iraq, or a more extensive attack against Iran, a foe his government has attempted to break through nearly four years of economic sanctions and military muscle.</p> <a href="https://www.theguardian.com/world/2020/dec/31/iran-says-trump-is-trying-to-fabricate-pretext-for-war">Continue reading...</a>

## Charles Piutau and Siva Naulago help Bristol end Newcastle's unbeaten start
 - [https://www.theguardian.com/sport/2021/jan/01/bristol-newcastle-premiership-match-report](https://www.theguardian.com/sport/2021/jan/01/bristol-newcastle-premiership-match-report)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 17:12:24+00:00

<ul><li>Bristol 29-17 Newcastle</li><li>George Kloska try caps bonus-point victory </li></ul><p>Newcastle are the early surprise of a strange season. They started the round second behind Exeter, winning their first three matches before being awarded the fourth and they were unfortunate to leave here with nothing after forcing Bristol to plunder their deep reserves. It is little wonder that some of the Premiership’s more established brethren are trying to use the pandemic as an excuse to pull up the trap-door marked relegation.</p><p>The Falcons took the game to Bristol from the start even if their first attack ended with the Bears scoring when Tom Arscott’s off-balance pass was picked off by Callum Sheedy on his 10-metre line for Ratu Naulago to score. Bristol had a potent back division with Charles Piutau, playing his first match for three months, Siva Naulago and Semi Radradra in harness for the first time, but they were underpowered at forward and spent much of the first half in retreat as they gave away penalties under pressure, so many that Dave Attwood was sent to the sin-bin after 30 minutes.</p> <a href="https://www.theguardian.com/sport/2021/jan/01/bristol-newcastle-premiership-match-report">Continue reading...</a>

## Journalist dies in Afghanistan as targeted killings continue
 - [https://www.theguardian.com/world/2021/jan/01/journalist-dies-in-afghanistan-as-targeted-killings-continue](https://www.theguardian.com/world/2021/jan/01/journalist-dies-in-afghanistan-as-targeted-killings-continue)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 17:06:04+00:00

<p>Violence increases amid stalled Taliban peace talks, with Isis claiming it was behind earlier journalist killing<br /></p><p>An Afghan journalist and human rights activist has been shot and killed by unidentified gunmen in western Afghanistan, the fifth journalist to be killed in the war-ravaged country in the past two months, a provincial spokesman said.</p><p>Bismillah Adil Aimaq was on the road near Feroz Koh, the provincial capital of Ghor, returning home to the city after visiting his family in a village nearby, when gunmen opened fire at the vehicle.</p> <a href="https://www.theguardian.com/world/2021/jan/01/journalist-dies-in-afghanistan-as-targeted-killings-continue">Continue reading...</a>

## MF Doom: a hip-hop genius who built his own universe of poetry
 - [https://www.theguardian.com/music/2021/jan/01/mf-doom-a-hip-hop-genius-who-built-his-own-universe-of-poetry](https://www.theguardian.com/music/2021/jan/01/mf-doom-a-hip-hop-genius-who-built-his-own-universe-of-poetry)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 16:51:27+00:00

<p>The underground rap icon, who has died aged 49, was a voice like no other, plundering and splicing pop culture to deliver wilful, elliptical lines</p><p>It makes twisted sense that we’re only learning of the death of Daniel Dumile, better known as MF Doom, two months after his passing, with scant accompanying detail. An artist who thrived in the shadows, Dumile’s backstory was a chimera of myth-making and real-life tragedy. Even his face was a mystery – he performed for much of his career behind a metal mask, and later exploited this concept to an absurd degree, sending masked impostors out to tour on his behalf (“I’m the writer, I’m the director,” he averred to <a href="https://www.newyorker.com/magazine/2009/09/21/the-mask-of-doom">the New Yorker’s Ta-Nahesi Coates</a> in 2009).</p><p>Dumile made his recorded debut in 1989 as a fresh-faced 18-year-old, delivering the final verse on 3rd Base’s classic diss anthem The Gas Face (MC Pete Nice’s verse testifies that Dumile actually coined the titular slang). London-born Dumile had relocated with his family to Long Island in the 70s, and was now one-third of New York rap trio KMD, performing under the moniker Zev Love X alongside kid brother Dingilizwe, AKA DJ Subroc. Their debut, 1991’s Mr Hood, signalled the trio worthy scions of rap’s golden age – witty and restlessly sample-happy like the Native Tongues posse, with a steely political undertow, evidenced by the acerbic, anti-racist Who Me?</p> <a href="https://www.theguardian.com/music/2021/jan/01/mf-doom-a-hip-hop-genius-who-built-his-own-universe-of-poetry">Continue reading...</a>

## Gary Anderson joins Bunting in PDC worlds semis with comeback win
 - [https://www.theguardian.com/sport/2021/jan/01/gary-anderson-moves-into-pdc-semi-final-with-comeback-win](https://www.theguardian.com/sport/2021/jan/01/gary-anderson-moves-into-pdc-semi-final-with-comeback-win)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 16:46:01+00:00

<ul><li>Former champion beat Dirk van Duijvenbode 5-1</li><li>Anderson to meet winner of Van Gerwen-Chisnall</li></ul><p>The two-time winner Gary Anderson is through to the semi-finals of the PDC World Championship after coming from behind to beat Dirk van Duijvenbode at Alexandra Palace.</p><p>Anderson, the champion in 2015 and 2016, lost the opening set before surging to a 5-1 victory, averaging 101.07. The Scot set up a last-four meeting with the winner of the Michael Van Gerwen-Dave Chisnall contest taking place on Friday evening.</p> <a href="https://www.theguardian.com/sport/2021/jan/01/gary-anderson-moves-into-pdc-semi-final-with-comeback-win">Continue reading...</a>

## UK university students ask for emergency cash to cover fees and rent
 - [https://www.theguardian.com/education/2021/jan/01/uk-university-students-ask-emergency-cash-cover-fees-rent](https://www.theguardian.com/education/2021/jan/01/uk-university-students-ask-emergency-cash-cover-fees-rent)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 16:33:14+00:00

<p>Announcement that most should delay their return has left students scrambling to make plans</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Students have called on the universities minister to provide emergency financial support to cover fees and rent after she announced that most of them should not return until at least the end of January.</p><p>Michelle Donelan also told international students preparing to travel from overseas that they should “consider whether they in fact need to travel to the UK at this time”.</p> <a href="https://www.theguardian.com/education/2021/jan/01/uk-university-students-ask-emergency-cash-cover-fees-rent">Continue reading...</a>

## Pelé's revolutionary status must survive numbers game against Lionel Messi | Barney Ronay
 - [https://www.theguardian.com/football/2021/jan/01/pele-revolutionary-status-must-survive-numbers-game-against-lionel-messi-santos](https://www.theguardian.com/football/2021/jan/01/pele-revolutionary-status-must-survive-numbers-game-against-lionel-messi-santos)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 16:32:49+00:00

<p>After Messi was said to have broken the Brazilian’s record for goals at a single club, Santos updated their statistics</p><p>It seems odd looking back now, but Pelé’s 50th birthday was marked with a star-studded Pelé exhibition match televised live around the world.</p><p>Before kick-off a giant Pelé cake was wheeled out at San Siro, on top of which Pelé himself appeared, waving and punching the air in priestly white Pelé-robes, while a massed Pelé-choir sang Happy Birthday Dear Pelé. The Pelé Supremacy filled the skies. And that moment the Pelé-shaped universe was a complete and coherent entity.</p> <a href="https://www.theguardian.com/football/2021/jan/01/pele-revolutionary-status-must-survive-numbers-game-against-lionel-messi-santos">Continue reading...</a>

## The Guardian view on liberal Christians: is this their moment? | Editorial
 - [https://www.theguardian.com/commentisfree/2021/jan/01/the-guardian-view-on-liberal-christians-is-this-their-moment](https://www.theguardian.com/commentisfree/2021/jan/01/the-guardian-view-on-liberal-christians-is-this-their-moment)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 16:22:14+00:00

<p>The election of practising Catholic Joe Biden is just one reason for religious progressives to be hopeful</p><p>“No one is saved alone,” writes Pope Francis in <a href="https://www.theguardian.com/books/2020/nov/29/let-us-dream-by-pope-francis-review-the-holy-father-of-fraternity" title="">Let Us Dream</a>, a short book of Covid-related reflections published last month. Those words carry an obvious Christian resonance. But the meaning that the pope intends to convey is primarily secular. The pandemic, he believes, has underlined our shared vulnerability and mutual dependency. By shocking us out of everyday indifference and egotism, our present troubles can open up the space for a new spirit of fraternity. A fresh emphasis on looking out for each other, claims the pope, can become the theme of a more generous and caring post-pandemic politics.</p><p>Let Us Dream is a pastoral, spiritual book that aspires to address a lay audience as well as a religious one. In its emphasis on civic solidarity, tolerance, concern for the poor and the environment, it is also the <a href="https://www.bbc.co.uk/news/world-europe-23489702" title="">latest</a> attempt by Pope Francis to shift the dial of 21st-century Christianity away from the culture wars that have consumed it.</p> <a href="https://www.theguardian.com/commentisfree/2021/jan/01/the-guardian-view-on-liberal-christians-is-this-their-moment">Continue reading...</a>

## Cocktail of the week: Aqua Shard's day in the country – recipe | The good mixer
 - [https://www.theguardian.com/food/2021/jan/01/cocktail-of-the-week-aqua-shards-day-in-the-country-recipe](https://www.theguardian.com/food/2021/jan/01/cocktail-of-the-week-aqua-shards-day-in-the-country-recipe)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 16:00:13+00:00

<p>A punchy, post-work pick-me-up featuring gin, Aperol, vermouth and peach liqueur</p><p>Alcohol is, of course, one of the most popular ferments known to humankind, and this punchy, post-work pick-me-up features no fewer than four different sorts of booze. You can’t really say it’s good for you, but it does come in very welcome at the end of a long day at work.</p> <a href="https://www.theguardian.com/food/2021/jan/01/cocktail-of-the-week-aqua-shards-day-in-the-country-recipe">Continue reading...</a>

## This week's home entertainment: from A Perfect Planet to The Great
 - [https://www.theguardian.com/tv-and-radio/2021/jan/01/a-perfect-planet-best-tv-of-week](https://www.theguardian.com/tv-and-radio/2021/jan/01/a-perfect-planet-best-tv-of-week)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 16:00:13+00:00

<p>This week David Attenborough returns to soothe our nerves, while Elle Fanning camps it up as Catherine the Great<br /></p> <a href="https://www.theguardian.com/tv-and-radio/2021/jan/01/a-perfect-planet-best-tv-of-week">Continue reading...</a>

## Trump looks back and Biden looks ahead in contrasting new year messages
 - [https://www.theguardian.com/us-news/2021/jan/01/trump-reflects-on-his-historic-victories-in-new-year-message](https://www.theguardian.com/us-news/2021/jan/01/trump-reflects-on-his-historic-victories-in-new-year-message)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 15:25:42+00:00

<p>Biden calls for quicker distribution of Covid vaccines, while Trump points out he predicted vaccine’s arrival</p><p>The 1 January messages from the president and president-elect were both short, simple and upbeat.</p><p>“Happy New Year,” Donald Trump <a href="https://twitter.com/realDonaldTrump/status/1344999320831946754">tweeted</a> on Friday morning.</p> <a href="https://www.theguardian.com/us-news/2021/jan/01/trump-reflects-on-his-historic-victories-in-new-year-message">Continue reading...</a>

## Al Boum Photo scores easy success in traditional Gold Cup prep-run
 - [https://www.theguardian.com/sport/2021/jan/01/al-boum-photo-easy-success-tramore-talking-horses-horse-racing-tips](https://www.theguardian.com/sport/2021/jan/01/al-boum-photo-easy-success-tramore-talking-horses-horse-racing-tips)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 15:24:13+00:00

<ul><li>Handful of rivals fail to trouble Willie Mullins star</li><li>Bookmakers cut him to 4-1 for third Cheltenham win</li></ul><p>Al Boum Photo faces a rigorous training schedule over the next two months, his reappearance run having seemed to show he is further from peak fitness than connections had expected. “He needed that run badly,” said his trainer, Willie Mullins, after the nine-year-old was a comfortable winner of the Savills New Year’s Day Chase at Tramore in the hands of Paul Townend.</p><p> <span>Related: </span><a href="https://www.theguardian.com/sport/blog/2021/jan/01/talking-horses-harchibald-defence-used-to-fend-off-non-trier-charge">Talking Horses: Harchibald defence used to fend off 'non-trier' charge</a> </p> <a href="https://www.theguardian.com/sport/2021/jan/01/al-boum-photo-easy-success-tramore-talking-horses-horse-racing-tips">Continue reading...</a>

## The KLF reissue music for first time since 1992
 - [https://www.theguardian.com/music/2021/jan/01/the-klf-reissue-music-for-first-time-since-1992](https://www.theguardian.com/music/2021/jan/01/the-klf-reissue-music-for-first-time-since-1992)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 15:12:10+00:00

<p>Singles compilation Solid State Logik 1 appears on streaming services and YouTube years after being deleted, with further reissues anticipated soon</p><p>Rave-pop iconoclasts the KLF have released their greatest hits on to streaming services and YouTube for the first time, and have hinted at further music to follow later this year.</p><p>An eight-track collection entitled Solid State Logik 1 has been released today, including 1988 No 1 novelty single Doctorin’ the Tardis, 1991 UK No 1 dance anthem 3am Eternal, and the Top 5 hits Last Train to Trancentral and America: What Time is Love? also released that year.</p> <a href="https://www.theguardian.com/music/2021/jan/01/the-klf-reissue-music-for-first-time-since-1992">Continue reading...</a>

## How Steven Gerrard reset Rangers and put them on path to title | Ewan Murray
 - [https://www.theguardian.com/football/2021/jan/01/how-steven-gerrard-reset-rangers-and-put-them-on-path-to-title](https://www.theguardian.com/football/2021/jan/01/how-steven-gerrard-reset-rangers-and-put-them-on-path-to-title)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 15:04:12+00:00

<p>Ibrox club have put last season’s bitter campaign behind them as they host Celtic undefeated in the Scottish Premiership</p><p>It is the great Rangers unmentionable. Acrimony associated with curtailment of season 2019-20 in Scotland was fixed, as is depressingly customary, on the Old Firm. Rangers held a game in hand but were 13 points adrift of Celtic when time was called. If there was legitimacy to complaints over the Scottish Professional League’s handling of this situation, broader issues were in play. The Rangers support could demean Celtic’s collection of a ninth title in a row. If the club’s hierarchy could switch focus from a post-new-year collapse, even better. Whisper it, but such a bitter end to the last campaign did Rangers a favour.</p><p>A glance towards Rangers’ predicament in early March emphasises that point. A 1-0 win at Ross County had followed defeats by relegation-threatened Hearts – meaning a Scottish Cup exit – and Hamilton. Despite winning at Celtic on 29 December, Rangers were subsequently defeated at Tynecastle and Rugby Park. Only a point was taken at St Johnstone. Hamilton’s win at Ibrox, their second there since 1926, ensured palpable anger among Glasgow’s blue half. Celtic were cantering towards the championship.</p> <a href="https://www.theguardian.com/football/2021/jan/01/how-steven-gerrard-reset-rangers-and-put-them-on-path-to-title">Continue reading...</a>

## 'Like a mission to Mars': making David Attenborough's A Perfect Planet
 - [https://www.theguardian.com/tv-and-radio/2021/jan/01/a-perfect-planet-david-attenborough-how-they-made](https://www.theguardian.com/tv-and-radio/2021/jan/01/a-perfect-planet-david-attenborough-how-they-made)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 15:00:12+00:00

<p>Disco-dancing crabs, flamingos under a volcano … and a frog freezing itself alive. Behind the scenes of the BBC’s new nature documentary</p><p><strong>Ed Charles, producer, Weather and Oceans</strong><br />We were really lucky on this series in that we had finished our filming and were in the edit when coronavirus hit, so it was something that we could do remotely. I’ve been working on this project since 2016 so it has been a long time in the making.</p> <a href="https://www.theguardian.com/tv-and-radio/2021/jan/01/a-perfect-planet-david-attenborough-how-they-made">Continue reading...</a>

## Brexit trade deal places Europe back at centre of UK politics
 - [https://www.theguardian.com/politics/2021/jan/01/political-demands-of-brexit-now-face-economic-reality](https://www.theguardian.com/politics/2021/jan/01/political-demands-of-brexit-now-face-economic-reality)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 15:00:12+00:00

<p>Analysis: Far from being free of the EU, Johnson now faces the economic reality of his political demands<br /></p><p>In the words of one official in Brussels involved in the Brexit negotiations, the last year “accelerated the grieving process” over the UK’s departure from the EU.</p><p>This is not to say the bloc’s institutions will be celebrating the country’s passing from the single market and customs union, 48 years to the day after its accession to the then European Communities on 1 January 1973. It remains a devastating loss to the EU, from which the full repercussions are yet to be seen even four and a half years after the referendum.</p> <a href="https://www.theguardian.com/politics/2021/jan/01/political-demands-of-brexit-now-face-economic-reality">Continue reading...</a>

## My mum lied to me about having an affair. How can I trust her?
 - [https://www.theguardian.com/lifeandstyle/2021/jan/01/my-mum-lied-to-me-about-having-an-affair-how-can-i-trust-her](https://www.theguardian.com/lifeandstyle/2021/jan/01/my-mum-lied-to-me-about-having-an-affair-how-can-i-trust-her)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 15:00:12+00:00

<p>As long as you expect your mother to be someone different, you will get hurt, says Annalisa Barbieri</p><p><strong>I am 29. When I was nine, I found a letter addressed to a man’s name I didn’t recognise. My parents were married</strong><strong>. When I was 11, my dad told me </strong><strong>my mum was having an affair </strong><strong>that</strong><strong> had begun before their marriage. He told me how she wouldn’t be there when he came home, and would disappear at weekends. Throughout my adolescence, this man would call the house</strong><strong> and hang up, and send cards to </strong><strong>my mum. </strong><strong>My dad said </strong><strong>she was a bad person and that her morals were all mixed up.</strong></p><p><strong>I tried to speak to </strong><strong>her about it as I got older, but she would angrily deny it</strong><strong>. After my parents divorced, she thought </strong><strong>she would be with </strong><strong>the other man, </strong><strong>but this never happened. Twenty years later, she </strong><strong>still </strong><strong>refus</strong><strong>es to admit anything is going on</strong><strong>. But </strong><strong>over the years, I have seen many messages showing her wanting to be with him. </strong></p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/01/my-mum-lied-to-me-about-having-an-affair-how-can-i-trust-her">Continue reading...</a>

## BA among airlines paid millions to fly in Covid testing kits
 - [https://www.theguardian.com/world/2021/jan/01/ba-among-airline-firms-paid-millions-to-ferry-in-covid-testing-kits](https://www.theguardian.com/world/2021/jan/01/ba-among-airline-firms-paid-millions-to-ferry-in-covid-testing-kits)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:54:26+00:00

<p>Documents reveal six contracts totalling £15m to bring lateral flow kits to UK at short notice<br /></p><p>Airlines including British Airways have been paid £15m to fly in Covid testing kits from China at short notice amid UK fears of being “gazumped” for the sought-after tests.</p><p>Disclosures <a href="https://www.contractsfinder.service.gov.uk/Notice/b090f0c0-5713-4c96-8164-11edb25f4ca5?origin=SearchResults&amp;p=1">published on New Year’s Eve</a> show that BA earned £2.7m for air freight services, as part of a contract awarded by the Department of Health and Social Care (DHSC).</p> <a href="https://www.theguardian.com/world/2021/jan/01/ba-among-airline-firms-paid-millions-to-ferry-in-covid-testing-kits">Continue reading...</a>

## Gibraltar hails 'historic day'  as last-minute deal greeted with relief
 - [https://www.theguardian.com/world/2021/jan/01/gibraltar-hails-historic-day-as-last-minute-deal-greeted-with-relief](https://www.theguardian.com/world/2021/jan/01/gibraltar-hails-historic-day-as-last-minute-deal-greeted-with-relief)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:46:03+00:00

<p>Agreement between UK and Spain will allow British territory to become part of Schengen area</p><p>Surrounded by fences and set against the dramatic backdrop of the Rock of Gibraltar, the frontier between Spain and Gibraltar has long set the pace of life in the southern tip of the Iberian peninsula, shuttling through as many as 30,000 cross-border workers and tourists on a daily basis.</p><p>News that border controls could be a thing of the past, following a last-minute <a href="https://www.theguardian.com/world/2020/dec/31/spain-and-uk-reach-draft-deal-on-post-brexit-status-of-gibraltar">New Year’s Eve deal between the UK and Spain,</a> was met with wonder, relief and a heady dose of wariness on both sides of the land border.</p> <a href="https://www.theguardian.com/world/2021/jan/01/gibraltar-hails-historic-day-as-last-minute-deal-greeted-with-relief">Continue reading...</a>

## Antidepressant use in England soars as pandemic cuts counselling access
 - [https://www.theguardian.com/society/2021/jan/01/covid-antidepressant-use-at-all-time-high-as-access-to-counselling-in-england-plunges](https://www.theguardian.com/society/2021/jan/01/covid-antidepressant-use-at-all-time-high-as-access-to-counselling-in-england-plunges)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:43:25+00:00

<p><strong>Exclusive:</strong> more than 6m people receive drugs as experts warn of Covid pandemic’s effects on mental health</p><ul><li><a href="https://www.theguardian.com/society/2021/jan/01/lockdown-anxiety-prescription-drugs-coronavirus-restrictions">How anxiety of lockdown led me on to prescription drugs</a></li><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Calls to mental health helplines and prescriptions for antidepressants have reached an all-time high, while access to potentially life-saving talking therapies has plunged during the coronavirus pandemic, a Guardian investigation has found.</p><p> <span>Related: </span><a href="https://www.theguardian.com/society/2021/jan/01/guardian-and-observer-charity-appeal-hits-1m">Guardian and Observer charity appeal hits £1m</a> </p> <a href="https://www.theguardian.com/society/2021/jan/01/covid-antidepressant-use-at-all-time-high-as-access-to-counselling-in-england-plunges">Continue reading...</a>

## Former Coronation Street actor Mark Eden dies aged 92
 - [https://www.theguardian.com/tv-and-radio/2021/jan/01/former-coronation-street-actor-mark-eden-dies-aged-92](https://www.theguardian.com/tv-and-radio/2021/jan/01/former-coronation-street-actor-mark-eden-dies-aged-92)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:42:26+00:00

<p>Eden, who played Alan Bradley in TV soap and was married to co-star Sue Nicholls, had Alzheimer’s disease<br /></p><ul><li><a href="https://www.theguardian.com/tv-and-radio/2021/jan/01/mark-eden-obituary">Mark Eden obituary</a></li></ul><p>The former Coronation Street actor Mark Eden has died aged 92, his agent has said.</p><p>Eden, best known for playing Alan Bradley in the ITV soap, is survived by his wife and former co-star, Sue Nicholls, who plays Audrey Roberts.</p> <a href="https://www.theguardian.com/tv-and-radio/2021/jan/01/former-coronation-street-actor-mark-eden-dies-aged-92">Continue reading...</a>

## NYSE to delist three Chinese telecom firms, citing 'military links'
 - [https://www.theguardian.com/business/2021/jan/01/new-york-stock-exchange-nyse-to-delist-three-chinese-telecom-firms-alleged-military-links](https://www.theguardian.com/business/2021/jan/01/new-york-stock-exchange-nyse-to-delist-three-chinese-telecom-firms-alleged-military-links)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:34:59+00:00

<p>Stock exchange says companies are ‘no longer suitable for listing’, in move condemned by Beijing</p><p>The New York Stock Exchange (NYSE) has said it will delist three Chinese telecommunications firms because of their alleged links to China’s military.</p><p><a href="https://www.theguardian.com/world/china">China</a> Telecom, China Mobile and China Unicom Hong Kong will be suspended from trading in early January, while delisting proceedings are initiated, according to a statement released by the <a href="https://www.theguardian.com/business/stock-markets">stock exchange</a>.</p> <a href="https://www.theguardian.com/business/2021/jan/01/new-york-stock-exchange-nyse-to-delist-three-chinese-telecom-firms-alleged-military-links">Continue reading...</a>

## Italy begins year of Dante anniversary events with virtual Uffizi exhibition
 - [https://www.theguardian.com/world/2021/jan/01/italy-year-long-celebration-dante-700-anniversary-drawings](https://www.theguardian.com/world/2021/jan/01/italy-year-long-celebration-dante-700-anniversary-drawings)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:20:30+00:00

<p>Gallery puts seldom-seen Divine Comedy sketches on display online to mark 700 years since poet’s death</p><p>Eighty-eight rarely seen drawings of Dante’s The Divine Comedy have been put on virtual display as Italy begins a year-long calendar of events to mark the 700th anniversary of the poet’s death.</p><p>The drawings, by the 16th-century Renaissance artist Federico Zuccari, are being exhibited online, for free, by the <a href="https://www.uffizi.it/en/online-exhibitions-series/to-rebehold-the-stars">Uffizi Gallery</a> in Florence.</p> <a href="https://www.theguardian.com/world/2021/jan/01/italy-year-long-celebration-dante-700-anniversary-drawings">Continue reading...</a>

## Bobi Wine likens Uganda election to 'a war and a battlefield'
 - [https://www.theguardian.com/world/2021/jan/01/bobi-wine-likens-uganda-election-to-a-war-and-a-battlefield](https://www.theguardian.com/world/2021/jan/01/bobi-wine-likens-uganda-election-to-a-war-and-a-battlefield)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:17:10+00:00

<p><strong>Exclusive: </strong>Reggae singer turned opposition leader tells of how he fears for his life<br /></p><p>Bobi Wine, the former reggae singer turned Ugandan opposition leader, has spoken about his country’s bitter and violent presidential election campaign as it moves into its final two weeks.</p><p>“The campaign is crazy. It’s like a war and a battlefield,” Wine said in an interview conducted before <a href="https://www.theguardian.com/world/2020/dec/30/uganda-opposition-candidate-bobi-wine-campaign-team-arrest">he was detained for a third time in two months</a> on Wednesday.</p> <a href="https://www.theguardian.com/world/2021/jan/01/bobi-wine-likens-uganda-election-to-a-war-and-a-battlefield">Continue reading...</a>

## Could Britain rejoin the EU? It seems like a hopelessly lost cause – but so did leaving | Jonathan Freedland
 - [https://www.theguardian.com/commentisfree/2021/jan/01/britain-rejoin-eu-leaving-brexit](https://www.theguardian.com/commentisfree/2021/jan/01/britain-rejoin-eu-leaving-brexit)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:11:23+00:00

<p>It’s easy to assume that the question has been settled for a generation. Remember that Brexit once looked impossible, too</p><p><br />Have I mentioned the <a href="https://www.theguardian.com/politics/2004/oct/08/iraq.iraq1">man in the egg-stained tie</a>? I first spotted him at Tory party conferences two decades ago. A forlorn figure – mocked even by his fellow Conservatives – he stood at the back of fringe meetings, armed with a plastic bag full of leaflets, leaping to his feet to offer “more of a comment than a question”, uniting the room in a collective groan. You’d see him at most political events; he was often in the Question Time audience. His obsession was Europe and the supposed tyranny of Brussels.</p><p>Nobody wanted to be the man in the egg-stained tie. He was a bore and an object of derision. Yet today that man is celebrating a victory, one that, at the turn of this century, would have seemed like the stuff of laughably improbable fantasy. Against all odds, he got his way: the new year begins with Britain having <a href="https://www.theguardian.com/politics/2020/dec/31/brexit-uk-makes-low-key-eu-departure-more-than-four-years-after-referendum">completed its exit</a> from the European Union. What was once the quixotic cause of anoraks and obsessives – to overturn a settled decision on Britain’s relationship with Europe – has proved to be among the most effective political movements in the country’s history. For pro-Europeans, that movement ensured the start of this new year is tinged with regret, even longing, for what’s been lost.</p> <a href="https://www.theguardian.com/commentisfree/2021/jan/01/britain-rejoin-eu-leaving-brexit">Continue reading...</a>

## To exhausted healthcare workers like me, Covid conspiracies are a kick in the teeth | Jeeves Wijesuriya
 - [https://www.theguardian.com/commentisfree/2021/jan/01/healthcare-workers-covid-conspiracies-coronavirus-deniers](https://www.theguardian.com/commentisfree/2021/jan/01/healthcare-workers-covid-conspiracies-coronavirus-deniers)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:08:14+00:00

<p>Coronavirus deniers demanding proof of the pandemic in our hospitals are lucky they have never experienced it first hand<br /></p><ul><li><a href="https://preview.gutools.co.uk/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://preview.gutools.co.uk/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>We are nearly a year into the pandemic, yet widespread denial of the pathogen and the crisis still persists. The hard objective truths are undeniable: millions infected globally, hundreds of thousands dead and a lightning-quick scientific breakthrough with vaccines now beginning to be rolled out around the world.</p><p>For most healthcare workers, life is split into two: the outward reality we share with our family and friends (the Instagram fodder of home-cooked meals and time with loved ones), and the peculiar and often traumatic inner world of working in healthcare, where supposedly once-in-a-lifetime events such as births, deaths and life-changing illness occur daily.</p> <a href="https://www.theguardian.com/commentisfree/2021/jan/01/healthcare-workers-covid-conspiracies-coronavirus-deniers">Continue reading...</a>

## Drink healthy: ferments to kick off the new year | Fiona Beckett on wine
 - [https://www.theguardian.com/food/2021/jan/01/drink-healthy-ferments-to-kick-off-the-new-year](https://www.theguardian.com/food/2021/jan/01/drink-healthy-ferments-to-kick-off-the-new-year)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:00:11+00:00

<p>The benefits of probiotics might still be open to question, but you may find that some kefirs and kombuchas will add new kick and flavour to your repertoire</p><p>If you’re kicking off the new year with a resolution to drink more healthily, fermented drinks such as kefir and kombucha may be on your radar. But are they as good for your gut <a href="https://www.theguardian.com/lifeandstyle/2019/feb/09/is-kombucha-good-for-you">as they’re made out to be</a>?</p><p>For those not familiar with them, kombucha is fermented tea, while kefir is a fermented drink that can be made from milk or water, and in both cases they’re kicked off by a starter culture that is rich in probiotic bacteria, which are <a href="https://www.health.harvard.edu/vitamins-and-supplements/health-benefits-of-taking-probiotics">held by some</a> to promote a healthy digestive and immune system.</p> <a href="https://www.theguardian.com/food/2021/jan/01/drink-healthy-ferments-to-kick-off-the-new-year">Continue reading...</a>

## I used to be a terrible gardener. Then I became a terrible gardening bore
 - [https://www.theguardian.com/lifeandstyle/2021/jan/01/i-used-to-be-a-terrible-gardener-then-i-became-a-terrible-gardening-bore](https://www.theguardian.com/lifeandstyle/2021/jan/01/i-used-to-be-a-terrible-gardener-then-i-became-a-terrible-gardening-bore)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:00:11+00:00

<p>No one wanted to know about my new lawn. But that didn’t stop me telling them all about it</p><p>My wife had wanted to AstroTurf our back garden this summer, but I said no: it had to be real grass, so that our kids could experience worms and soil and nature, even though I find worms and soil (and most of nature) disgusting when it is not on TV. I won the argument, which meant that I – the world’s worst gardener – was charged with maintaining a new lawn. I resolved to make sure that my wife could never say: “I told you we should have got AstroTurf.”</p><p>The process of digging up the rotten tree stumps and laying down fresh turf in the baking heat was extremely arduous (for the gardener – I just watched him while sipping an ice-cold cider). But my real problems were yet to come. Before long, I was spending an hour every day with my hose, trying to out-sprinkle the sun and kick this lawn into life. Amazingly, it started to grow, but it also started doing weird things – bare spots would appear, patches would turn unusual colours. On one occasion, a small area became covered in weird, translucent slime overnight (I still have no clue what that was). Watching things deteriorate despite the time I was putting in became incredibly stressful. “There’s no point,” I would announce to my wife, melodramatically. “It’s clearly all dying.”</p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/01/i-used-to-be-a-terrible-gardener-then-i-became-a-terrible-gardening-bore">Continue reading...</a>

## My new year's resolution is to regret nothing, not even regret itself | Coco Khan
 - [https://www.theguardian.com/lifeandstyle/2021/jan/01/my-new-years-resolution-is-to-regret-nothing-not-even-regret-itself](https://www.theguardian.com/lifeandstyle/2021/jan/01/my-new-years-resolution-is-to-regret-nothing-not-even-regret-itself)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:00:11+00:00

<p>Isn’t a resolution a prime example of how something life-affirming can be built from recognising opportunities lost or missteps taken? </p><p>When I was moving, I took the opportunity to go through The Box – a container for paperwork I’ve ferried from home to home since I was 18. Any time I received something important, it’d go in the box (and often never be seen again).</p><p>It was strange sitting among the papers – seeing my wayward life as told through bureaucracy. There was my degree certificate; a dole approval letter; a lease from a lawless flat where I once looked out the window to see police abseiling down; a pleading letter I’d written to the council when we’d been served an eviction notice; and fines from minor scrapes with law and order. But there were also poems, love letters, stories (and even a clipping from work experience at this newspaper).</p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/01/my-new-years-resolution-is-to-regret-nothing-not-even-regret-itself">Continue reading...</a>

## Why DC's move to the small screen could be great
 - [https://www.theguardian.com/film/2021/jan/01/why-dcs-move-to-the-small-screen-could-be-great](https://www.theguardian.com/film/2021/jan/01/why-dcs-move-to-the-small-screen-could-be-great)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 14:00:11+00:00

<p>DC is aping Marvel’s move to TV, thanks to its superhero streaming deal with HBO Max. It might even iron out the wrinkles in its flawed Extended Universe</p><p>In print, DC Comics was the trailblazer for superheroes more than 80 years ago – while Marvel emerged as a 1960s enfant terrible, shaking up the genre by humanising its costumed crime-fighters and <a href="https://www.vice.com/en/article/wdbxey/how-doctor-strange-helped-create-hippies">engaging with the emerging counterculture</a>. On the big screen, despite mainstays such as Superman and Batman having made it to the multiplex long before Iron Man, the Hulk and Thor, DC Films has found itself playing catch-up following the astounding success of the Marvel Cinematic Universe, a superhero sandpit in which scores of mega-powered titans have been able to play for more than a decade now.</p><p>This picture doesn’t seem likely to change any time soon, following news that DC, owned by Warner Bros, is to <a href="https://ew.com/movies/warner-bros-superhero-movie-plan/">move even more of its content to the streaming platform HBO Max</a>. Industry reports suggest four movies a year will now be released in cinemas, and two will be released straight to the small screen. While the move has come in the wake of the Covid-19 pandemic and <a href="https://www.theguardian.com/film/2020/dec/21/how-covid-19-upturned-film-in-2020">the effect on cinema chains</a>, it also looks a lot like Marvel’s activity at Disney+, where the studio is bringing multiple TV shows and movies featuring its core roster from the MCU over the next two years.</p> <a href="https://www.theguardian.com/film/2021/jan/01/why-dcs-move-to-the-small-screen-could-be-great">Continue reading...</a>

## UK supermarket workers: share your experiences during the second wave of coronavirus
 - [https://www.theguardian.com/world/2021/jan/01/uk-supermarket-workers-share-your-experiences-during-the-second-wave-of-coronavirus](https://www.theguardian.com/world/2021/jan/01/uk-supermarket-workers-share-your-experiences-during-the-second-wave-of-coronavirus)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 13:44:34+00:00

<p>We’d like to speak to supermarket workers about how they’re coping with the second wave of coronavirus, and how it compares to the first</p><p>As much of the UK comes under ever-increasing restrictions due to the second wave of coronavirus, we’d like to find out how workers in essential shops, such as supermarkets or chemists, are coping.</p><p>How are you finding the second wave, how does it compare to the first? Are you finding that people are abiding by the rules or is it difficult to enforce social distancing? Do you feel there are enough safety measures in your workplace?</p> <a href="https://www.theguardian.com/world/2021/jan/01/uk-supermarket-workers-share-your-experiences-during-the-second-wave-of-coronavirus">Continue reading...</a>

## Alexander Wang denies 'grotesquely false' sexual assault claims
 - [https://www.theguardian.com/fashion/2021/jan/01/alexander-wang-denies-sexual-assault-claims-grotesquely-false-fashion](https://www.theguardian.com/fashion/2021/jan/01/alexander-wang-denies-sexual-assault-claims-grotesquely-false-fashion)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 13:43:31+00:00

<p>More claims emerge on social media after British model says fashion designer groped him at party</p><p>The American fashion designer Alexander Wang has denied “grotesquely false” allegations of sexual assault as grassroots advocacy sites claim that there are a high number of victims.</p><p>A British model, Owen Mooney, this week publicly claimed that Wang had groped his crotch at the nightclub Slake in New York during the promoter Ladyfag’s Holy Mountain party on 21 January 2017, following which a number of similar claims, mostly anonymous, emerged.</p> <a href="https://www.theguardian.com/fashion/2021/jan/01/alexander-wang-denies-sexual-assault-claims-grotesquely-false-fashion">Continue reading...</a>

## New year dips, confetti and frost: Friday's best photos
 - [https://www.theguardian.com/news/gallery/2021/jan/01/new-year-dips-confetti-and-frost-fridays-best-photos](https://www.theguardian.com/news/gallery/2021/jan/01/new-year-dips-confetti-and-frost-fridays-best-photos)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 13:24:16+00:00

<p>The Guardian’s picture editors select photo highlights from around the world, including a Channel ferry and sunrise in Japan</p> <a href="https://www.theguardian.com/news/gallery/2021/jan/01/new-year-dips-confetti-and-frost-fridays-best-photos">Continue reading...</a>

## Karen Carney deletes Twitter account after abuse over Leeds comments
 - [https://www.theguardian.com/football/2021/jan/01/karen-carney-deletes-twitter-account-after-abuse-over-leeds-comments](https://www.theguardian.com/football/2021/jan/01/karen-carney-deletes-twitter-account-after-abuse-over-leeds-comments)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 13:09:12+00:00

<ul><li>Carney made comments in role as television pundit</li><li>Leeds mocked her, then ‘completely condemned’ abuse</li></ul><p>Karen Carney has deleted her Twitter account after remarks she made in her role as a TV pundit about Leeds United were <a href="https://www.theguardian.com/football/2020/dec/30/leeds-united-criticised-for-tweet-mocking-amazon-pundit-karen-carney">mocked by the club’s official account</a> and led to waves of sexist abuse.</p><p>Online attacks against the former England international, who played 144 times for her country, are understood to have increased each day since Leeds shared a clip of Carney’s commentary with their 660,000 followers on Tuesday night.</p> <a href="https://www.theguardian.com/football/2021/jan/01/karen-carney-deletes-twitter-account-after-abuse-over-leeds-comments">Continue reading...</a>

## ‘I yowl like a leopard’: Guardian readers’ lockdown fitness tips
 - [https://www.theguardian.com/lifeandstyle/2021/jan/01/guardian-readers-lockdown-fitness-tips](https://www.theguardian.com/lifeandstyle/2021/jan/01/guardian-readers-lockdown-fitness-tips)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 13:00:10+00:00

<p>From exercising with animal noises to the thrills of a mini trampoline, readers share their secrets for staying healthy despite Covid restrictions</p><p>Keeping motivated while doing an online class is hard. When doing any exercise named after an animal, I find that making the sound of that animal makes the whole thing a lot more fun. For example: growl for bear crawls, yowl for leopard leaps, <a href="https://www.theguardian.com/lifeandstyle/2017/dec/30/fit-in-my-40s-zuu-exercise-regime-animal-zoe-williams">ribbit for frog-hop squat jumps</a>, nibbling chatter for bunny hops, roaring for dragon crawls. I’ve also added a Mario-style “woo-hoo” for chest-to-floor burpees. In the gym, it would be hard to do this unless you don’t mind making a fool of yourself, but at home, with your mic on mute, no one knows. <strong>Iszi Lawrence, </strong><strong>Reading</strong></p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/01/guardian-readers-lockdown-fitness-tips">Continue reading...</a>

## New Year's Eve revellers fined by police for breaking UK Covid rules
 - [https://www.theguardian.com/uk-news/2021/jan/01/new-years-eve-revellers-fined-by-police-for-breaking-covid-rules](https://www.theguardian.com/uk-news/2021/jan/01/new-years-eve-revellers-fined-by-police-for-breaking-covid-rules)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 12:48:33+00:00

<p>Large gatherings broken up across country but police say vast majority of people stuck to rules</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Police across the UK have made several arrests and issued hundreds of fines for New Year’s Eve parties and large gatherings that breached strict Covid regulations.</p><p>Parties were broken up in Brighton, Manchester, Leicestershire, Sheffield, Essex, London and Lancashire where breaches of stay-at-home guidelines occurred. In Edinburgh, <a href="https://twitter.com/JGBS/status/1344848570785161216">hundreds of people gathered around the castle</a> despite warnings to keep away.</p> <a href="https://www.theguardian.com/uk-news/2021/jan/01/new-years-eve-revellers-fined-by-police-for-breaking-covid-rules">Continue reading...</a>

## With a heavy heart, Johnson will always remind us who the real victim is: him | Marina Hyde
 - [https://www.theguardian.com/commentisfree/2021/jan/01/boris-johnson-victim-emotions](https://www.theguardian.com/commentisfree/2021/jan/01/boris-johnson-victim-emotions)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 12:43:07+00:00

<p>His compassion for the public may be limited, but never let it be said that our leader is a man who neglects his own emotions</p><p>It is one of the curiosities of this inside-out age that <a href="https://www.theguardian.com/us-news/2021/jan/01/trump-reflects-on-his-historic-victories-in-new-year-message">Donald Trump</a> is loved by conspiracists, even though he is a leader – at last! – who embodies of all their worst fears. He really does hate them, he really is plotting against them, and he really is lying to them, in multiple and increasingly wicked and baroque ways.</p><p>Searching for the lesser ironies native to the UK, we might alight on the puzzle that <a href="https://www.theguardian.com/politics/boris-johnson">Boris Johnson</a> is beloved of many who can’t wait to point out that “facts don’t care about your feelings” – and yet is himself incapable of serving up difficult facts without endless reference to how it’s all making him feel. Is the prime minister in the business of making new year’s resolutions? If so he might consider trying to develop a stiff upper lip this year. It looks like we’re going to need it.</p> <a href="https://www.theguardian.com/commentisfree/2021/jan/01/boris-johnson-victim-emotions">Continue reading...</a>

## NHS staff face burnout as Covid hospital admissions continue to rise
 - [https://www.theguardian.com/world/2021/jan/01/nhs-staff-face-burnout-covid-hospital-admissions-rise](https://www.theguardian.com/world/2021/jan/01/nhs-staff-face-burnout-covid-hospital-admissions-rise)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 12:39:02+00:00

<p>Nurses plead with public to follow official advice to relieve pressure on frontline workers </p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul> <p>England’s chief nurse has said NHS and care staff are working “incredibly hard” to cope with record numbers of Covid-19 patients, amid concern that frontline staff are close to burnout.</p><p>Ruth May pleaded with the public to follow the coronavirus advice to help relieve the pressure on hospital staff, after two days of record hospital admissions.</p> <a href="https://www.theguardian.com/world/2021/jan/01/nhs-staff-face-burnout-covid-hospital-admissions-rise">Continue reading...</a>

## Football, flights and food: how the EU reshaped Britain
 - [https://www.theguardian.com/politics/2021/jan/01/football-flights-and-food-how-the-eu-reshaped-britain](https://www.theguardian.com/politics/2021/jan/01/football-flights-and-food-how-the-eu-reshaped-britain)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 12:30:09+00:00

<p>As Brexit’s tangible effects kick in, we look at the impact the EU’s most far-reaching project has had on British society<br /></p><p>Historians of the future will judge the politics of the half century before the Brexit transition ended on 1 January 2021. What, though, of social and cultural historians, those who study how we live?</p><p>Perhaps the most symbolic cultural artefacts of the last 50 years will turn out not to be a blue flag but a bottle of Blue Nun, a block of mozzarella, a Ryanair boarding printout or a ticket to a Bayern Munich v Manchester City football match.</p> <a href="https://www.theguardian.com/politics/2021/jan/01/football-flights-and-food-how-the-eu-reshaped-britain">Continue reading...</a>

## Hopes for most endangered turtle after discovery of female in Vietnam lake
 - [https://www.theguardian.com/environment/2021/jan/01/hopes-for-most-endangered-turtle-after-discovery-of-female-in-vietnam-lake](https://www.theguardian.com/environment/2021/jan/01/hopes-for-most-endangered-turtle-after-discovery-of-female-in-vietnam-lake)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 12:14:49+00:00

<p>Find is chance for species’ survival say scientists as DNA results confirm turtle found in Hanoi district is a Swinhoe’s softshell </p><p>The last known male giant Swinhoe’s softshell turtle is no longer alone on the planet after the discovery of a female of his species in Vietnam.</p><p>The female 86kg (13 stone) turtle was found in Dong Mo lake, in Hanoi’s Son Tay district, and captured for genetic testing in October.</p> <a href="https://www.theguardian.com/environment/2021/jan/01/hopes-for-most-endangered-turtle-after-discovery-of-female-in-vietnam-lake">Continue reading...</a>

## On race in 2020, we took a step forward – from minus 10 to zero. We can't afford to go back | Afua Hirsch
 - [https://www.theguardian.com/commentisfree/2021/jan/01/race-2020-step-forward-structural-racism-government](https://www.theguardian.com/commentisfree/2021/jan/01/race-2020-step-forward-structural-racism-government)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 12:00:09+00:00

<p>Until this year, even talking about structural racism risked hostility, so there’s progress. If only the UK government felt the same</p><p>This was the year that made achieving nothing look like progress. I mean that in the nicest way.</p><p>A wise old man I spoke to recently put it better. He has spent a lifetime doing anti-racism work, and was reflecting on how, since the traumatic murder of <a href="https://www.theguardian.com/us-news/george-floyd">George Floyd</a> in May, it feels like real gains have been made in 2020. “The good thing about this year,” he said, “is that for a long time we have been stuck at -10. In 2020, it looks like we have finally progressed to zero.”</p> <a href="https://www.theguardian.com/commentisfree/2021/jan/01/race-2020-step-forward-structural-racism-government">Continue reading...</a>

## January transfer window: a guide to every Premier League club's plans
 - [https://www.theguardian.com/football/2021/jan/01/january-transfer-window-a-guide-to-every-premier-league-clubs-plans](https://www.theguardian.com/football/2021/jan/01/january-transfer-window-a-guide-to-every-premier-league-clubs-plans)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 12:00:08+00:00

<p>Loans, not big-money buys, are likely to be flavour of the month, but from top to bottom managers want to do business</p><ul><li><a href="https://www.theguardian.com/football/ng-interactive/2020/dec/31/mens-transfer-window-january-2020-all-deals-from-europes-top-five-leagues">Men’s transfer interactive: all the latest moves</a></li></ul><p>Arsenal need to shift a formidable bulk of dead wood before they can make significant efforts to address, among other things, an enduring lack of creativity. <a href="https://www.theguardian.com/football/2020/dec/31/kolasinac-on-verge-of-schalke-loan-as-arteta-targets-arsenal-clearout">Sead Kolasinac has joined Schalke</a> on loan and is among several they hope to move out, at least temporarily. At this point any incomings are likely to be loans, too, with Isco among the names considered before Mikel Arteta looks longer-term in the summer. <strong>Nick Ames</strong></p> <a href="https://www.theguardian.com/football/2021/jan/01/january-transfer-window-a-guide-to-every-premier-league-clubs-plans">Continue reading...</a>

## French snail farmers lament sluggish year as Covid crisis dents sales
 - [https://www.theguardian.com/world/2021/jan/01/french-snail-farmers-lament-sluggish-year-as-covid-crisis-dents-sales](https://www.theguardian.com/world/2021/jan/01/french-snail-farmers-lament-sluggish-year-as-covid-crisis-dents-sales)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 11:38:50+00:00

<p>Escargots are traditional hors d’oeuvre at end-of-year celebrations that account for 70% of business</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>For France’s <em>heliciculteurs</em>, or snail farmers, 2020 was a desperately sluggish year.</p><p>With seasonal festivities all but cancelled, Christmas markets called off, a lack of tourists and restaurants shut down because of the coronavirus crisis, business has slowed to, well, a snail’s pace.</p> <a href="https://www.theguardian.com/world/2021/jan/01/french-snail-farmers-lament-sluggish-year-as-covid-crisis-dents-sales">Continue reading...</a>

## Avoid using wood burning stoves if possible, warn health experts
 - [https://www.theguardian.com/environment/2021/jan/01/avoid-using-wood-burning-stoves-if-possible-warn-health-experts](https://www.theguardian.com/environment/2021/jan/01/avoid-using-wood-burning-stoves-if-possible-warn-health-experts)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 11:05:13+00:00

<p>Charity calls for people to use alternative, less polluting heating and cooking options if they can</p><p>Campaigners and health experts are calling on people who have alternative heating not to use their wood burning stoves this winter amid growing concern about their impact on public health.</p><p>The Guardian recently reported <a href="https://www.theguardian.com/environment/2020/dec/18/wood-burners-triple-harmful-indoor-air-pollution-study-finds">that wood burners triple</a> the level of harmful particulates inside the home as well as creating dangerous levels of pollution in the surrounding neighbourhood.</p> <a href="https://www.theguardian.com/environment/2021/jan/01/avoid-using-wood-burning-stoves-if-possible-warn-health-experts">Continue reading...</a>

## George Orwell is out of copyright. What happens now?
 - [https://www.theguardian.com/books/booksblog/2021/jan/01/george-orwell-is-out-of-copyright-what-happens-now](https://www.theguardian.com/books/booksblog/2021/jan/01/george-orwell-is-out-of-copyright-what-happens-now)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 11:00:08+00:00

<p>Much of the author’s work may have fallen into public ownership in the UK, but there are more restrictions on its use remaining than you might expect, explains his biographer<br /></p><p>George Orwell died at University College Hospital, London, on 21 January 1950 at the early age of 46. This means that unlike such long-lived contemporaries as Graham Greene (died 1991) or Anthony Powell (died 2000), the vast majority of his compendious output (21 volumes to date) is newly out of copyright as of 1 January. Naturally, publishers – who have an eye for this kind of opportunity – have long been at work to take advantage of the expiry date and the next few months are set to bring a glut of repackaged editions.</p><p>The Oxford University Press is producing World’s Classics versions of the major books and there are several bulky compendia about to hit the shelves – see, for example, the Flame Tree Press’s <a href="https://www.flametreepublishing.com/george-orwell-visions-of-dystopia-isbn-9781839644740.html">George Orwell: Visions of Dystopia</a>. I have to declare an interest myself, having spent much of the spring lockdown preparing annotated editions of Orwell’s six novels, to be issued at the rate of two a year before the appearance of my new Orwell biography (a successor to 2003’s Orwell: The Life) in 2023. As for the tide of non-print spin-offs, an <a href="https://www.youtube.com/watch?v=C9idH7M4TeI">Animal Farm video game</a> hit cyberspace in mid-December.</p> <a href="https://www.theguardian.com/books/booksblog/2021/jan/01/george-orwell-is-out-of-copyright-what-happens-now">Continue reading...</a>

## Beekeepers brace for next round with Canada's 'murder hornets'
 - [https://www.theguardian.com/environment/2021/jan/01/beekeepers-brace-for-next-round-with-canada-murder-hornets-aoe](https://www.theguardian.com/environment/2021/jan/01/beekeepers-brace-for-next-round-with-canada-murder-hornets-aoe)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 11:00:07+00:00

<p>British Columbia resigned to a ‘long fight’ after 2020’s efforts to track and kill the invasive insects ended in frustration</p><ul><li><a href="https://www.theguardian.com/environment/2020/jun/25/hornets-race-to-protect-north-americas-honeybees-from-giant-invader-aoe">‘Murder hornets’: race to protect North America’s honeybees from giant invader</a></li><li><a href="https://www.theguardian.com/environment/series/biodiversity--what-happened-next-">Read more in our series Biodiversity: what happened next?</a></li></ul><p>The year 2020 is not one that beekeepers in Washington state and the Canadian province of British Columbia are likely to forget in a hurry. <a href="https://www.theguardian.com/environment/2020/jun/25/hornets-race-to-protect-north-americas-honeybees-from-giant-invader-aoe">Since the spring</a>, experts in both states have been gripped by fears of <a href="https://www.theguardian.com/world/2013/oct/04/killer-hornets-chinese-city-living-in-fear">Vespa mandarinia</a><em>,</em> a hulking insect whose voracious appetite for honeybees and stealthy spread could pose a threat to the region’s vulnerable ecosystem.</p><p>I squeezed [the queen] on her thorax ... and this huge stinger came out. And the giant mandibles moved, trying to bite me. It was really quite beautiful</p> <a href="https://www.theguardian.com/environment/2021/jan/01/beekeepers-brace-for-next-round-with-canada-murder-hornets-aoe">Continue reading...</a>

## 'The litter was a shock': 2020's Covid-driven rush on UK national parks
 - [https://www.theguardian.com/environment/2021/jan/01/the-litter-was-a-shock-2020-covid-rush-on-uk-national-parks](https://www.theguardian.com/environment/2021/jan/01/the-litter-was-a-shock-2020-covid-rush-on-uk-national-parks)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 10:30:37+00:00

<p>In lockdown, beauty spots such as Snowdonia attracted new visitors – but also fires, parking rows and ‘fly-camping’</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>For some years, Britain’s national parks have been wrestling with the same conundrum: <a href="https://www.theguardian.com/uk-news/2020/jan/02/call-for-more-diverse-lake-district-sparks-row-over-future">how to attract a broader range of visitors</a>.</p><p>This summer, they got what they all thought they wanted: the biggest influx of new visitors in their history. With foreign travel off the agenda for most and the shops closed, people who had never before walked up a hill, let alone worn Gore-Tex, heading to their nearest national park as soon as lockdown restrictions were eased.</p> <a href="https://www.theguardian.com/environment/2021/jan/01/the-litter-was-a-shock-2020-covid-rush-on-uk-national-parks">Continue reading...</a>

## Guardian and Observer charity appeal hits £1m
 - [https://www.theguardian.com/society/2021/jan/01/guardian-and-observer-charity-appeal-hits-1m](https://www.theguardian.com/society/2021/jan/01/guardian-and-observer-charity-appeal-hits-1m)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 10:15:10+00:00

<p>More than 9,000 readers contribute to charities supporting young people through Covid crisis<br /></p><ul><li>Please donate to our appeal <a href="https://guardian.ctdonate.org/?utm_source=gdnwb&amp;utm_medium=editorial&amp;utm_campaign=Marketing_CharityAppeal_1119&amp;CMP_TU=editorial&amp;CMP_BUNIT=edtrl">here</a></li></ul><p>With more than a week still to go, the Guardian and Observer 2020 appeal has raised an amazing £1m for its three partner charities supporting disadvantaged young people living in communities hit by the Covid pandemic.</p><p>More than 9,500 readers have donated to the appeal since it launched in early December, including hundreds who called journalists to donate through the annual <a href="https://www.theguardian.com/society/2020/dec/20/guardian-and-observer-charity-telethon-takes-donations-to-585000">telethon</a> shortly before Christmas. The funds raised will be shared among the charities <a href="https://www.ukyouth.org/">UK Youth</a>, <a href="https://youngminds.org.uk/?gclid=CjwKCAiAlNf-BRB_EiwA2osbxYBZI8ectqjIsD8RS7SPXVlK_V3hx1o6z9MKQlbDf0EFsztL9BBQqxoCFzAQAvD_BwE">YoungMinds</a> and <a href="https://cpag.org.uk/?gclid=CjwKCAiAlNf-BRB_EiwA2osbxdtH_9BQ0mIr6JTmcRibdG9SdaRj5vPuW_3UEmHAQ_Vs7heE238y5RoCKtIQAvD_BwE">Child Poverty Action Group</a>.</p> <a href="https://www.theguardian.com/society/2021/jan/01/guardian-and-observer-charity-appeal-hits-1m">Continue reading...</a>

## Liverpool mayor Joe Anderson withdraws from elections
 - [https://www.theguardian.com/uk-news/2021/jan/01/liverpool-mayor-joe-anderson-withdraws-from-elections](https://www.theguardian.com/uk-news/2021/jan/01/liverpool-mayor-joe-anderson-withdraws-from-elections)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 10:00:31+00:00

<p>Anderson says he will not seek re-election after police extend his bail over corruption investigation<br /></p><p>The mayor of Liverpool, Joe Anderson, has said he will not be seeking re-election after police extended his bail as part of a corruption inquiry.</p><p>Anderson, who was praised by the government <a href="https://www.theguardian.com/uk-news/2020/nov/23/liverpool-mayor-tory-praise-viper-showing-teeth">for his handling of the city’s Covid crisis</a>, said he had decided to step back from his role leading Liverpool city council and would not stand in May’s delayed mayoral election.</p> <a href="https://www.theguardian.com/uk-news/2021/jan/01/liverpool-mayor-joe-anderson-withdraws-from-elections">Continue reading...</a>

## Experience: I found the man who shot me, 46 years later
 - [https://www.theguardian.com/lifeandstyle/2021/jan/01/experience-i-found-the-man-who-shot-me-46-years-later](https://www.theguardian.com/lifeandstyle/2021/jan/01/experience-i-found-the-man-who-shot-me-46-years-later)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 10:00:07+00:00

<p>I pulled up a mugshot. He was older, but there was no doubt – I could spot him a mile away</p><p>I’d just got myself a chocolate milk and was on my way to pick up a Sunday paper when I saw a Chevy with a male and two females in it. It was October 1971, and I was 21. I was a couple of years into my policing career, working the morning shift in Denver, Colorado, out in a car on my own.</p><p>The male was wearing a khaki cap and looked like a rough dude. I went to where he was sitting on the passenger side and he gave me his wallet, which had a social security card.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/01/experience-i-found-the-man-who-shot-me-46-years-later">Continue reading...</a>

## Robin Williams's widow: 'There were so many misunderstandings about what had happened to him'
 - [https://www.theguardian.com/film/2021/jan/01/robin-williamss-widow-there-were-so-many-misunderstandings-about-what-had-happened-to-him](https://www.theguardian.com/film/2021/jan/01/robin-williamss-widow-there-were-so-many-misunderstandings-about-what-had-happened-to-him)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 10:00:07+00:00

<p>Susan Schneider Williams watched her husband suffer with undiagnosed Lewy body dementia before he killed himself in 2014. Her new film tries to educate others about the condition – and put to rest assumptions about his death</p><p>After Robin Williams <a href="https://www.theguardian.com/film/2014/aug/11/robin-williams-found-dead-suicide">died</a> in August 2014, aged 63, a lot of people had a lot of things to say about him. There was the predictable speculation about why a hugely beloved and seemingly healthy Hollywood star would end his own life, with some confidently stating that he was depressed or had succumbed to old addictions.</p><p>Others talked, with more evidence, about Williams as a comic genius (<a href="https://www.theguardian.com/tv-and-radio/2014/aug/14/mork-and-mindy-robin-williams-box-set-review">Mork &amp; Mindy</a>, <a href="https://www.theguardian.com/film/2020/may/13/my-favourite-film-aged-12-mrs-doubtfire">Mrs Doubtfire</a>, <a href="https://www.youtube.com/watch?v=83kTQ6chG4o">The Birdcage</a>, <a href="https://www.theguardian.com/film/2014/aug/12/robin-williams-a-career-in-clips">Aladdin</a>); a brilliant dramatic actor (<a href="https://www.theguardian.com/film/2019/jul/16/dead-poets-society-30-years-on-robin-williams-stirring-call-to-seize-the-day-endures">Dead Poets Society</a>, <a href="https://www.theguardian.com/books/2015/aug/30/oliver-sacks-dies-aged-82-eminent-neurologist-author-awakenings">Awakenings</a>, <a href="https://www.theguardian.com/film/2016/oct/08/matt-damon-ben-affleck-good-will-hunting-screenplay-reading">Good Will Hunting</a>,<a href="https://www.theguardian.com/culture/2002/oct/04/artsfeatures5"> One Hour Photo</a>); and both (<a href="https://www.theguardian.com/tv-and-radio/2015/apr/11/david-hepworth-radio-preview">Good Morning, Vietnam</a>;<a href="https://www.theguardian.com/film/2014/sep/26/terry-gilliam-robin-williams-the-fisher-king"> The Fisher King</a>). One thing everyone agreed on was that he had an extraordinary mind. Comedians spoke about how no one thought faster on stage than Williams; those who made movies with him said he never did the same take twice, always ad-libbing and getting funnier each time.</p> <a href="https://www.theguardian.com/film/2021/jan/01/robin-williamss-widow-there-were-so-many-misunderstandings-about-what-had-happened-to-him">Continue reading...</a>

## ‘She dreamed about giving the poor their own land’: Orita Godoy, died aged 75, of Covid-19
 - [https://www.theguardian.com/society/2021/jan/01/she-dreamed-about-giving-the-poor-their-own-land-orita-godoy-died-aged-75-of-covid-19](https://www.theguardian.com/society/2021/jan/01/she-dreamed-about-giving-the-poor-their-own-land-orita-godoy-died-aged-75-of-covid-19)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 10:00:07+00:00

<p>An activist who escaped Pinochet’s Chile, she was a committed and creative homemaker</p><ul><li>Read more stories from the <a href="https://www.theguardian.com/society/series/lost-to-the-virus">Lost to the virus series</a></li></ul><p>Orita Godoy was born poor in Chile and raised by her grandmother after her parents separated. “She only wore shoes when she went to church,” remembers her daughter, Alejandra Godoy, a 53-year-old NHS worker from London.</p><p>She met Rolando, a paint sprayer, when she worked as a housekeeper for a family in Santiago. “They had a connection I never saw in anyone else,” says Alejandra. “They could never understand why people got divorced.” Orita would know what Rolando was going to say before he said it. They had two children: Alejandra and her younger brother, also called Rolando.</p> <a href="https://www.theguardian.com/society/2021/jan/01/she-dreamed-about-giving-the-poor-their-own-land-orita-godoy-died-aged-75-of-covid-19">Continue reading...</a>

## My life in sex: the man who wears a chastity device
 - [https://www.theguardian.com/lifeandstyle/2021/jan/01/my-life-in-sex-the-man-who-wears-a-chastity-device](https://www.theguardian.com/lifeandstyle/2021/jan/01/my-life-in-sex-the-man-who-wears-a-chastity-device)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 10:00:06+00:00

<p>‘Rather than feeling sexually repressed, it’s given me a kind of freedom’</p><p>I started wearing a male chastity device out of curiosity, after reading about other people’s experiences online. I was single, lived on my own and worked from home, so thought: why not place an order by post?</p><p>Although they come in a multitude of sizes, colours and materials, all are designed to prevent the wearer from getting an erection. They generally consist of three pieces: a ring that sits behind the testicles; a cage that fits tightly around the flaccid penis; and a lock to hold the two other components together.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/01/my-life-in-sex-the-man-who-wears-a-chastity-device">Continue reading...</a>

## As a teacher during the pandemic, I've realised that a school is a genuine community | Jeffrey Boakye
 - [https://www.theguardian.com/commentisfree/2021/jan/01/as-a-teacher-pandemic-covid-school-community](https://www.theguardian.com/commentisfree/2021/jan/01/as-a-teacher-pandemic-covid-school-community)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 09:00:05+00:00

<p>Teaching through Covid has been anxiety-inducing, but we have been the ballast in the deeply uncertain waters of the pandemic</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>If you haven’t been <em>in</em> one since the last time you were <em>at</em> one, you might not appreciate that a school can often feel like a bad theme park: way too exciting, over-stimulating, and liable to produce headaches. It’s what you get if you put hundreds of kids and dozens of caffeinated adults under one roof. It’s a hive of human activity and constant, emotional interaction – buzzing with movement, noise, rapid changes, ups, downs and, in many cases, actual bells to tell everyone when to stand up and go somewhere else.</p><p>For teachers, it’s a bit like hosting an eight-hour Zoom call with nobody on mute and your camera always switched on. That’s a comparison that wouldn’t have made sense a year ago, but the pandemic has ushered in a whole new reality that we’re all struggling to deal with. Not to sound too much like a football score, it’s starting to feel like Covid-19, everyone else – nil.</p> <a href="https://www.theguardian.com/commentisfree/2021/jan/01/as-a-teacher-pandemic-covid-school-community">Continue reading...</a>

## James Cosmo: 'My friend said: They're going to drink beer out of your skull'
 - [https://www.theguardian.com/tv-and-radio/2021/jan/01/james-cosmo-interview-the-bay-the-simpsons](https://www.theguardian.com/tv-and-radio/2021/jan/01/james-cosmo-interview-the-bay-the-simpsons)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 09:00:05+00:00

<p>After his brutal demise on Game of Thrones, the veteran Scottish actor is back in crime drama The Bay. Is he the baddie?</p><p>For the most part, actors have now sussed out the art of the Zoom interview. The trick is to do it in front of a completely blank background, so the interviewer cannot possibly glean any personal details from whatever you happen to be in front of.</p><p>James Cosmo does not subscribe to this notion. We speak in mid-November and, when his Zoom screen clicked into life, he was vaping up a storm before a massive, illuminated wooden Christmas tree. True, he has played Santa Claus many a time, most memorably for most in the Narnia films, but also annually at his son’s school’s Christmas grotto (he was so good his son didn’t recognise him). Yet who knew he was this excessively festive?</p> <a href="https://www.theguardian.com/tv-and-radio/2021/jan/01/james-cosmo-interview-the-bay-the-simpsons">Continue reading...</a>

## 2021 – the  story of a year in 12 leaders
 - [https://www.theguardian.com/world/2021/jan/01/2021-the-story-of-a-year-in-12-leaders](https://www.theguardian.com/world/2021/jan/01/2021-the-story-of-a-year-in-12-leaders)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 08:00:04+00:00

<p>In 2021, the world will slowly begin to fight back against Covid. But what else will change as the vaccines are administered? Here are the figures who will shape a vital year </p><p><strong>Joe Biden </strong>United States</p> <a href="https://www.theguardian.com/world/2021/jan/01/2021-the-story-of-a-year-in-12-leaders">Continue reading...</a>

## Fresh fears for Tokyo Olympics as host city sees surge in Covid-19 infections
 - [https://www.theguardian.com/sport/2021/jan/01/fresh-fears-for-tokyo-olympics-as-host-city-sees-surge-in-covid-19-infections](https://www.theguardian.com/sport/2021/jan/01/fresh-fears-for-tokyo-olympics-as-host-city-sees-surge-in-covid-19-infections)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 08:00:03+00:00

<ul><li>Tokyo reported 1,300 new coronavirus infections on Thursday</li><li>Health experts concerned over stretched medical infrastructure</li></ul><p>When Japanese and International Olympic Committee officials finally accepted defeat in March and <a href="https://www.theguardian.com/sport/2020/mar/24/tokyo-olympics-to-be-postponed-to-2021-due-to-coronavirus-pandemic">postponed the Tokyo 2020 Olympics</a>, there was general agreement that a one-year wait would give the world ample time to overcome the <a href="https://www.theguardian.com/world/coronavirus-outbreak">coronavirus pandemic</a>.</p><p>The delayed Olympics, the then prime minister Shinzo Abe said, would be an opportunity to pay tribute to the human spirit in overcoming the world’s biggest public health crisis for a century.</p> <a href="https://www.theguardian.com/sport/2021/jan/01/fresh-fears-for-tokyo-olympics-as-host-city-sees-surge-in-covid-19-infections">Continue reading...</a>

## No one can read 50 books a week. So why was I buying or borrowing that many?
 - [https://www.theguardian.com/lifeandstyle/2021/jan/01/no-one-can-read-50-books-a-week-so-why-was-i-buying-or-borrowing-that-many](https://www.theguardian.com/lifeandstyle/2021/jan/01/no-one-can-read-50-books-a-week-so-why-was-i-buying-or-borrowing-that-many)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 07:00:05+00:00

<p>I have always been a voracious reader. But one day I realised my passion for books had turned into a mania</p><p>The need for last year’s resolution started in my childhood. (Don’t they all?) By the age of six, I was reading braille at an unheard-of speed, to the point where the teacher at my blind school accused me of lying when I said I had finished the three books she had given me that morning. It was the start of a lifelong problem: braille books were scarce, but I could not get enough of them.</p><p>The school had devised a particularly cruel and subtle form of torture for someone like me: they kept just one title of a child’s favourite author in the school library; for example, just one Famous Five book, one Billy Bunter, one Just William. As I grew older and my tastes changed, the problem remained the same: one Raymond Chandler, one PG Wodehouse, just one even mildly dirty book when puberty hit.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/jan/01/no-one-can-read-50-books-a-week-so-why-was-i-buying-or-borrowing-that-many">Continue reading...</a>

## 10 good news stories for UK travel and tourism in 2021
 - [https://www.theguardian.com/travel/2021/jan/01/10-good-news-stories-for-uk-travel-and-tourism-in-2021](https://www.theguardian.com/travel/2021/jan/01/10-good-news-stories-for-uk-travel-and-tourism-in-2021)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 07:00:04+00:00

<p>From cleaner rivers to greener cities and community projects, there are signs the industry will come out of lockdown travelling in the right direction</p><p>Amid all the challenges, last year’s forced pause sent some hopeful ripples across the travel industry. Talk of renewed purpose, going slow and regenerative travel – the kind that does good, rather than merely less harm – spread among tour operators and across destinations. Although travel has ground to a halt once more, <a href="https://www.gov.uk/foreign-travel-advice">with Britons currently banned</a> from entering many countries - and even other counties - these ripples will help us to travel better once we can.</p> <a href="https://www.theguardian.com/travel/2021/jan/01/10-good-news-stories-for-uk-travel-and-tourism-in-2021">Continue reading...</a>

## Inside the outbreak: photographing England during Covid pandemic
 - [https://www.theguardian.com/world/2021/jan/01/inside-the-outbreak-photographing-england-during-covid-pandemic](https://www.theguardian.com/world/2021/jan/01/inside-the-outbreak-photographing-england-during-covid-pandemic)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 07:00:04+00:00

<p>Guardian photographer Chris Thomond lives in Manchester and spent most of the year under strict lockdown measures while travelling on assignment around the north of England’s coronavirus hotspots photographing life during the pandemic. He looks back on his year</p><p>Early on during the pandemic I’d seen a short film from the Philippines and read an extended blog from northern Italy, both featuring photographers dressed in hazmat suits, toting cameras housed beneath protective covers. Embedded with paramedics as they dealt with seriously ill patients, my fellow photojournalists sensitively showed doctors in sweltering emergency hospital pop-up units or portrayed intimate moments as spouses and other terrified family members bid farewell to their loved ones as they were stretchered from their homes, some for the last time.</p><p>Over the following weeks I was drawn to the frequent updates of the legendary photographer Peter Turnley’s remarkable black-and-white street portraits from New York (and later Paris, his adopted home). They showed exhausted medical staff outside trauma centres, lonely subway travellers, homeless wanderers and an assortment of essential workers and normal residents who were just about holding things together. The biggest city in the US rapidly became <a href="https://www.theguardian.com/us-news/2020/apr/10/new-york-coronavirus-inequality-divide-two-cities">one of the centres of the outbreak</a> and suffered a correspondingly large death toll. Turnley showed immense bravery to walk the streets each day and his empathic approach towards subjects rewarded him as he witnessed tender moments which he skilfully captured for history.</p> <a href="https://www.theguardian.com/world/2021/jan/01/inside-the-outbreak-photographing-england-during-covid-pandemic">Continue reading...</a>

## A different world: could 2021 be the best year for a generation?
 - [https://www.theguardian.com/world/2021/jan/01/different-world-could-2021-best-year-generation](https://www.theguardian.com/world/2021/jan/01/different-world-could-2021-best-year-generation)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 07:00:03+00:00

<p>With the worst potentially behind us, we can be optimistic that somewhere better lies ahead</p><p>Has a new year ever been as eagerly anticipated as 2021? A fresh start, a new era, <a href="https://www.npr.org/2019/12/27/791546842/people-cant-even-agree-on-when-the-decade-ends?t=1606992250777">technically a new decade</a>, a line drawn under an annus horribilis, and some genuine hope to look forward to. Making predictions is always unwise, especially about the future, they say; making optimistic ones even more so. But could 2021 be the best year for a generation?</p><p>Of course this is tempting fate. It would be far safer to predict yet more confrontation, antagonism and misery, and claim vindication the moment the first crisis of the new year erupts, whether it is in Hong Kong, Ethiopia, a snarled-up British port or an unfortunate lowland that happens to be on the receiving end of 2021’s first deluge.</p> <a href="https://www.theguardian.com/world/2021/jan/01/different-world-could-2021-best-year-generation">Continue reading...</a>

## Fear, mistrust – and hope: Britain's long walk away from the EU
 - [https://www.theguardian.com/politics/2021/jan/01/fear-mistrust-and-hope-britains-long-walk-away-from-the-eu](https://www.theguardian.com/politics/2021/jan/01/fear-mistrust-and-hope-britains-long-walk-away-from-the-eu)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 07:00:03+00:00

<p>For many, Friday marks a departure as mind-boggling as it is heartbreaking. But the path to Brexit was laid years before the referendum</p><p>As a previous Tory prime minister trying to find his way through difficult times <a href="https://www.theguardian.com/theguardian/2009/nov/11/churchill-blood-sweat-tears">once said</a>: this is not the end. It is not even the beginning of the end. But it is, perhaps, the end of the beginning.</p><p>Brexit is hardly complete. The last-minute nature of the UK’s trade deal with the EU and the fact that it barely covers whole swaths of the economy – financial services are a good example – means some negotiations will have to grind on. The new bodies set up to arbitrate between the two sides will soon have work to do. Northern Ireland remains part of the single market for goods and will be enforcing EU customs rules, the most vivid example of the deal’s contorted provisions, which may have no end of political consequences. Certainly, given that public opinion in Scotland now <a href="https://www.theguardian.com/politics/2020/sep/13/covid-crisis-changing-minds-scottish-independence">suggests unprecedented levels of support for independence</a> and that elections to the Scottish parliament will take place in May, what Brexit means for the increasingly fragile union between the UK’s four countries will now start to become clearer.</p> <a href="https://www.theguardian.com/politics/2021/jan/01/fear-mistrust-and-hope-britains-long-walk-away-from-the-eu">Continue reading...</a>

## Removed London bike lane blocked by parked cars most of the time – study
 - [https://www.theguardian.com/uk-news/2021/jan/01/removed-london-bike-lane-blocked-by-parked-cars-most-of-the-time-study-kensington-and-chelsea-council](https://www.theguardian.com/uk-news/2021/jan/01/removed-london-bike-lane-blocked-by-parked-cars-most-of-the-time-study-kensington-and-chelsea-council)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 07:00:03+00:00

<p>Analysis shows average car journey times have also increased after Kensington and Chelsea council took out lane</p><p>A much-used cycle lane in London that was removed because the local council said it was impeding the flow of motor vehicles has since been blocked by parked cars up to 80% of the time, a study by a campaign group has found.</p><p>Computer analysis of traffic cameras on Kensington High Street have also shown that average car journey times appear to have increased since officials took out the bike lane just seven weeks after it was installed.</p> <a href="https://www.theguardian.com/uk-news/2021/jan/01/removed-london-bike-lane-blocked-by-parked-cars-most-of-the-time-study-kensington-and-chelsea-council">Continue reading...</a>

## The one good thing to come out of Brexit: a bonfire of national illusions | David Edgerton
 - [https://www.theguardian.com/commentisfree/2021/jan/01/brexit-bonfire-national-illusions-labour-alternative-future](https://www.theguardian.com/commentisfree/2021/jan/01/brexit-bonfire-national-illusions-labour-alternative-future)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 07:00:02+00:00

<p>Labour must wake up and offer an alternative vision for Britain’s future – not just more competence<br /></p><p>They have done it. The right wing of the Conservative party has won a historic victory. The UK will be a sovereign “third country”, with a <a href="https://www.theguardian.com/politics/live/2020/dec/30/brexit-deal-bill-coronavirus-boris-johnson-covid-live-news-updates">limited trade deal with the EU</a>. The UK, rightwingers believe, has been reconciled to its true history as a nation of offshore islanders.</p><p>But they have also failed, according to their own terms. Theresa May’s “<a href="https://www.theguardian.com/politics/2016/dec/06/theresa-may-calls-for-red-white-and-blue-brexit">red, white and blue</a>” Brexit is long dead, and a bad deal turned out to be better than no deal. The EU will not be supplanted by a great new Europe where British trade flows unimpeded; there are now frictions and barriers, not least in services. Any serious deregulatory move by the UK will be met with EU retaliation.</p> <a href="https://www.theguardian.com/commentisfree/2021/jan/01/brexit-bonfire-national-illusions-labour-alternative-future">Continue reading...</a>

## First lorries cross into France as Britain and Europe wake to new Brexit reality
 - [https://www.theguardian.com/politics/2021/jan/01/first-lorries-cross-into-france-as-britain-and-europe-wake-to-new-brexit-reality](https://www.theguardian.com/politics/2021/jan/01/first-lorries-cross-into-france-as-britain-and-europe-wake-to-new-brexit-reality)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 06:05:49+00:00

<p>No early signs of chaos as trucks haul goods across the new customs border</p><p>Moments after the UK left the EU with an 11th-hour deal, the first trucks hauling goods across the new customs border presented their clearance documents to French agents before loading on to a train to pass through the Eurotunnel.</p><p>With Britain having finally <a href="https://www.theguardian.com/politics/2020/dec/31/brexit-uk-makes-low-key-eu-departure-more-than-four-years-after-referendum">quit the EU single market and customs union</a>, there were <a href="https://www.theguardian.com/politics/2020/dec/31/exit-epilogue-eerily-quiet-dover-meets-brexit-deadline">no early signs of feared chaos at the border</a> in the first hours of 1 January 2021.</p> <a href="https://www.theguardian.com/politics/2021/jan/01/first-lorries-cross-into-france-as-britain-and-europe-wake-to-new-brexit-reality">Continue reading...</a>

## Facts won't fix this: experts on how to fight America's disinformation crisis
 - [https://www.theguardian.com/us-news/2021/jan/01/disinformation-us-election-covid-pandemic-trump-biden](https://www.theguardian.com/us-news/2021/jan/01/disinformation-us-election-covid-pandemic-trump-biden)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 06:00:03+00:00

<p>Trump’s false claims about the election and coronavirus are taking a dangerous toll. Can the divide be healed?</p><p>At the beginning of 2021,<strong> </strong>millions of Americans appear to disagree about one of the most basic facts of their democracy: that Joe Biden won the 2020 presidential election.</p><p>The consequences of Donald Trump’s repeated, baseless claims<strong> </strong>of voter fraud will come in several waves, researchers who study disinformation say<strong>, </strong>even if Trump ultimately hands over power and leaves the White House. And there is no quick or easy way to fix this crisis<strong>,</strong> they warn. Because when it comes to dealing with disinformation, simply repeating the facts doesn’t do much to change anyone’s mind.</p> <a href="https://www.theguardian.com/us-news/2021/jan/01/disinformation-us-election-covid-pandemic-trump-biden">Continue reading...</a>

## 'We feel in a bit of a no man’s land': Brexit brings mixed feelings in Trowbridge
 - [https://www.theguardian.com/politics/2021/jan/01/we-feel-in-a-bit-of-a-no-mans-land-brexit-brings-mixed-feelings-in-trowbridge](https://www.theguardian.com/politics/2021/jan/01/we-feel-in-a-bit-of-a-no-mans-land-brexit-brings-mixed-feelings-in-trowbridge)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 06:00:02+00:00

<p>Wiltshire voted to leave the EU but jubilation is in short supply as the UK finally exits </p><p>As the UK’s departure from the EU loomed, Alex Joll, who runs the Free Range Cafe in Trowbridge’s grand old town hall, thought he had better stockpile one of his key products.</p><p>“It’s quite random,” he said. “Our coffee comes from Peru, but is stored in a huge warehouse in Germany before coming to the UK, where it is roasted. I thought I’d better stock up just in case. I got in an extra month’s worth a little while ago to tide us over just in case.”</p> <a href="https://www.theguardian.com/politics/2021/jan/01/we-feel-in-a-bit-of-a-no-mans-land-brexit-brings-mixed-feelings-in-trowbridge">Continue reading...</a>

## Ghanaian pop star Amaarae: 'I'm presenting black women as deities'
 - [https://www.theguardian.com/music/2021/jan/01/ghanaian-pop-star-amaarae-im-presenting-black-women-as-deities](https://www.theguardian.com/music/2021/jan/01/ghanaian-pop-star-amaarae-im-presenting-black-women-as-deities)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 06:00:02+00:00

<p>Raised between Accra and Atlanta, the genre-rejecting singer draws from her cosmopolitan upbringing – and a love of Kelis – to confront narrow definitions of womanhood</p><ul><li><a href="https://www.theguardian.com/music/2021/jan/01/irish-drill-jazz-violin-and-supermarket-musicals-30-new-artists-for-2021">Irish drill, jazz violin and supermarket musicals: 30 new artists for 2021</a></li></ul><p>“You can’t box anyone in any more,” Amaarae says from her bedroom in Accra, Ghana. “As older cultures die out, things inevitably change.”</p><p>The 26-year-old is describing the shift underway in West Africa embodied by alté, the eccentric musical style that has expanded into a non-conformist cultural movement. Amaarae is one of its pioneers, and her debut album The Angel You Don’t Know an instant classic in its canon. Euphoric in its risk-taking, it leaves no genre, sound or cadence off limits: Amaarae’s whispering vocals hopscotch between the Southern hip-hop rhythms on Celine and dance over the lilting soundscape created by Rvdical the Kid in 3AM.</p> <a href="https://www.theguardian.com/music/2021/jan/01/ghanaian-pop-star-amaarae-im-presenting-black-women-as-deities">Continue reading...</a>

## UN to bring in monitors to observe Libya's widely flouted ceasefire
 - [https://www.theguardian.com/world/2021/jan/01/un-to-bring-in-monitors-to-observe-libya-flouted-ceasefire-national-unity-government](https://www.theguardian.com/world/2021/jan/01/un-to-bring-in-monitors-to-observe-libya-flouted-ceasefire-national-unity-government)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 05:00:00+00:00

<p>Move part of diplomatic reboot of efforts to cajole opposing sides into forming national unity government</p><p>The United Nations will try to reboot its push towards national unity in Libya by bringing in monitors to oversee a widely flouted ceasefire and by forcing the country’s riven political leadership to find a mechanism for electing a prime minister.</p><p>UN officials said Libya was locked in a race against time to make tangible progress towards forming a national unity government and avoid the possible collapse of a three-month ceasefire.</p> <a href="https://www.theguardian.com/world/2021/jan/01/un-to-bring-in-monitors-to-observe-libya-flouted-ceasefire-national-unity-government">Continue reading...</a>

## Revisited: the clitoris coverup – why do we know so little?
 - [https://www.theguardian.com/news/audio/2021/jan/01/today-in-focus-revisited-the-clitoris-coverup-why-do-we-know-so-little-podcast](https://www.theguardian.com/news/audio/2021/jan/01/today-in-focus-revisited-the-clitoris-coverup-why-do-we-know-so-little-podcast)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 03:00:04+00:00

<p>Medical textbooks are full of anatomical pictures of the penis, but the clitoris barely rates a mention and many medical professionals are uncomfortable even talking about it. Reporter <strong>Calla Wahlquist</strong> and associate news editor <strong>Gabrielle Jackson</strong> explain the history and science of the clitoris, and speak to the scientists and artists dedicated to demystifying it</p><p><em>This week we are revisiting some of our favourite episodes from 2020. This episode was first broadcast on The Full Story by Guardian Australia on 8 November 2020</em></p><p>You can read Calla Wahlquist’s piece on <a href="https://www.theguardian.com/lifeandstyle/2020/nov/01/the-sole-function-of-the-clitoris-is-female-orgasm-is-that-why-its-ignored-by-medical-science">why the clitoris is ignored by medical science </a>here. You can also read an edited extract of Gabrielle Jackson’s book <a href="https://www.theguardian.com/lifeandstyle/2019/nov/13/the-female-problem-male-bias-in-medical-trials">Pain and Prejudice here.</a></p> <a href="https://www.theguardian.com/news/audio/2021/jan/01/today-in-focus-revisited-the-clitoris-coverup-why-do-we-know-so-little-podcast">Continue reading...</a>

## Pat McGrath becomes first makeup artist to receive damehood from the Queen
 - [https://www.theguardian.com/fashion/2021/jan/01/pat-mcgrath-becomes-first-makeup-artist-to-receive-damehood-from-the-queen](https://www.theguardian.com/fashion/2021/jan/01/pat-mcgrath-becomes-first-makeup-artist-to-receive-damehood-from-the-queen)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 00:18:58+00:00

<p>The groundbreaking British artist honoured for services to fashion, beauty and diversity</p><p>British makeup artist Pat McGrath has been awarded a damehood in the Queen’s New Year 2021 honours list, becoming the first makeup artist ever to do so.</p><p> <span>Related: </span><a href="https://www.theguardian.com/fashion/2017/aug/06/beauty-queen-how-pat-mcgrath-revolutionised-makeup">Beauty queen: how Pat McGrath revolutionised makeup</a> </p> <a href="https://www.theguardian.com/fashion/2021/jan/01/pat-mcgrath-becomes-first-makeup-artist-to-receive-damehood-from-the-queen">Continue reading...</a>

## UK high street lost 177,000 jobs in 2020, study finds
 - [https://www.theguardian.com/business/2021/jan/01/uk-high-street-lost-177000-jobs-2020](https://www.theguardian.com/business/2021/jan/01/uk-high-street-lost-177000-jobs-2020)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-01-01 00:01:00+00:00

<p>Job losses expected to continue in new year with further 200,000 cuts</p><p>The high street shed 177,000 jobs in 2020 according to a study that predicts an even more devastating toll on retail jobs this year, with a further 200,000 expected to be lost.</p><p>The job losses in what is the UK’s biggest private employment sector – with particular importance for women – illustrate the dramatic and permanent impact the pandemic will have on the shopping landscape.</p> <a href="https://www.theguardian.com/business/2021/jan/01/uk-high-street-lost-177000-jobs-2020">Continue reading...</a>

