# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## "We Didn't Stop The Virus" - 2020: The Musical
 - [https://www.youtube.com/watch?v=DE00AYkkYhc](https://www.youtube.com/watch?v=DE00AYkkYhc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2021-01-02 00:00:00+00:00

Hey, I uploaded! Weird! Happy New Year, everyone!

Last year sucked. Popular opinion, I know, but that's because it's true. We're all getting older, the world's getting more and more unpredictable, and Snapple refused to admit that glass bottles taste better. But at least we have each other to guide us through the harrowing darkness. So let's take a look back at 2020, the good, the bad, and ugly. My first musical was to the tune of "We Didn't Start The Fire," but I genuinely can't think of a year more deserving of a version of it's own. 

Hope you enjoy! I'll be making more of these this year. Stay tuned, babycakes. That's your nickname now, babycakes. Why are you still reading this? I'm not some novelist here to wax your cerebrum with whimsical words and rambunctious tales of a yesteryear long since past. Get some help, creep. 

SHIRTS ► https://teespring.com/stores/chris-ray-gun
TWITTER ► https://twitter.com/ChrisRGun
FACEBOOK ► http://on.fb.me/15OyE7z
TWITCH ► http://www.twitch.tv/chrisraygun
PATREON ► https://www.patreon.com/ChrisRay
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/
SACRED SYMBOLS  ► https://apple.co/2Rqmklc
SECOND CHANNEL ► https://www.youtube.com/channel/UCiNediqB-JC_TjbsB4hJuHA

