# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 List do Koryntian || Rozdział 7
 - [https://www.youtube.com/watch?v=AYtZoxV11Jw](https://www.youtube.com/watch?v=AYtZoxV11Jw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-02 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#215] O Bogu najniższym, który ma namiot!
 - [https://www.youtube.com/watch?v=rpt7Ev7zip0](https://www.youtube.com/watch?v=rpt7Ev7zip0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-02 00:00:00+00:00

@Langustanapalmie ​  #cnn #dobrewiadomości

II Niedziela po Narodzeniu Pańskim, Rok B

1. czytanie (Syr 24, 1-2. 8-12)

Mądrość wychwala sama siebie, chlubi się pośród swego ludu. Otwiera usta na zgromadzeniu Najwyższego i chlubi się przed Jego potęgą.
Wtedy przykazał mi Stwórca wszystkiego, Ten, co mnie stworzył, wyznaczył mi mieszkanie i rzekł: «W Jakubie rozbij namiot i w Izraelu obejmij dziedzictwo!»
Przed wiekami, na samym początku mnie stworzył i już nigdy istnieć nie przestanę.
W świętym przybytku, w Jego obecności, zaczęłam pełnić służbę i przez to na Syjonie mocno stanęłam. Podobnie w mieście umiłowanym dał mi odpoczynek, w Jeruzalem jest moja władza.
Zapuściłam korzenie w sławnym narodzie, w posiadłości Pana, w Jego dziedzictwie.

2. czytanie (Ef 1, 3-6. 15-18)

Niech będzie błogosławiony Bóg i O jciec Pana naszego, Jezusa Chrystusa; On napełnił nas wszelkim błogosławieństwem duchowym na wyżynach niebieskich – w Chrystusie. W Nim bowiem wybrał nas przed założeniem świata, abyśmy byli święci i nieskalani przed Jego obliczem. Z miłości przeznaczył nas dla siebie jako przybranych synów poprzez Jezusa Chrystusa, według postanowienia swej woli, ku chwale majestatu swej łaski, którą obdarzył nas w Umiłowanym.
Przeto i ja, usłyszawszy o waszej wierze w Pana Jezusa i o miłości względem wszystkich świętych, nie zaprzestaję dziękczynienia, wspominając was w moich modlitwach. Proszę w nich, aby Bóg Pana naszego, Jezusa Chrystusa, Ojciec chwały, dał wam ducha mądrości i objawienia w głębszym poznawaniu Jego samego. Niech da wam światłe oczy serca, byście wiedzieli, czym jest nadzieja, do której On wzywa, czym bogactwo chwały Jego dziedzictwa wśród świętych.

Ewangelia (J 1, 1-18)
Na początku było Słowo, a Słowo było u Boga, i Bogiem było Słowo. Ono było na początku u Boga. Wszystko przez Nie się stało, a bez Niego nic się nie stało, z tego, co się stało.
W Nim było życie, a życie było światłością ludzi, a światłość w ciemności świeci i ciemność jej nie ogarnęła. Pojawił się człowiek posłany przez Boga – Jan mu było na imię. Przyszedł on na świadectwo, aby zaświadczyć o światłości, by wszyscy uwierzyli przez niego. Nie był on światłością, lecz został posłany, aby zaświadczyć o światłości. Była światłość prawdziwa, która oświeca każdego człowieka, gdy na świat przychodzi. Na świecie było Słowo, a świat stał się przez Nie, lecz świat Go nie poznał. Przyszło do swojej własności, a swoi Go nie przyjęli. Wszystkim tym jednak, którzy Je przyjęli, dało moc, aby się stali dziećmi Bożymi, tym, którzy wierzą w imię Jego – którzy ani z krwi, ani z żądzy ciała, ani z woli męża, ale z Boga się narodzili.
A Słowo stało się ciałem i zamieszkało wśród nas. I oglądaliśmy Jego chwałę, chwałę, jaką Jednorodzony otrzymuje od Ojca, pełen łaski i prawdy. Jan daje o Nim świadectwo i głośno woła w słowach: «Ten był, o którym powiedziałem: Ten, który po mnie idzie, przewyższył mnie godnością, gdyż był wcześniej ode mnie». Z Jego pełności wszyscy otrzymaliśmy – łaskę po łasce. Podczas gdy Prawo zostało dane za pośrednictwem Mojżesza, łaska i prawda przyszły przez Jezusa Chrystusa. Boga nikt nigdy nie widział; ten Jednorodzony Bóg, który jest w łonie Ojca, o Nim pouczył.
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 1 List do Koryntian || Rozdział 6
 - [https://www.youtube.com/watch?v=pQl2xjro4gc](https://www.youtube.com/watch?v=pQl2xjro4gc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-01 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

