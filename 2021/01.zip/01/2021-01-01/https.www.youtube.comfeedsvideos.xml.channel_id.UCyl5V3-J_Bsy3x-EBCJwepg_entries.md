# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Babylon Bee New Year's Special 2021
 - [https://www.youtube.com/watch?v=8Yz4A9eD7lM](https://www.youtube.com/watch?v=8Yz4A9eD7lM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-01 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan do a rundown on 2020’s biggest and best Babylon Bee stories that gave the world fake news they could trust. They talk about all the big changes at The Babylon Bee and give a behind-the-scenes look into the creative process behind the top ten Bee articles of the year. Even though the year was a crazy one, Kyle and Ethan want to end 2020 with a little Chestertonian awe, wonder, and gratitude.

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

