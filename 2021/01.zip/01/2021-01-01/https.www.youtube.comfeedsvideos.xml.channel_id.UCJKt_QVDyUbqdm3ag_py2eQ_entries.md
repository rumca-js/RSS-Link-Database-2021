# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Jeroen Tel - Golden Axe title & ingame (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=C6SZ_FHu-3g](https://www.youtube.com/watch?v=C6SZ_FHu-3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-01-02 00:00:00+00:00

"Golden Axe" (C64, 1988) themes by Jeroen Tel. Art is using Christopherjam palette for more saturated colors. Headphones recommended as always.

00:00 Title
04:15 Ingame

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

My 2012 upload, software emulated pure mono Dolbyfied:
https://www.youtube.com/watch?v=stiO52JWM7o

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

