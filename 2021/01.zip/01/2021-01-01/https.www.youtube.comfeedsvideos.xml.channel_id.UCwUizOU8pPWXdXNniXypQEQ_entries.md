# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Facts About The Fact Checkers
 - [https://www.youtube.com/watch?v=mjZR6Htma18](https://www.youtube.com/watch?v=mjZR6Htma18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-01-02 00:00:00+00:00

Grab your Supernatural Starter Set Here! -  https://supernatural.com/jp

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here are some facts about the fact checkers you may not know. Having everything you post fact checked is important to protect you from free thinking. But who are the all knowing fact checkers who have never been wrong?

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

