# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Manchester United draw level with Liverpool as Fernandes penalty sees off Villa
 - [https://www.cnn.com/2021/01/01/football/premier-league-manchester-utd-aston-villa-covid-spt-intl/index.html](https://www.cnn.com/2021/01/01/football/premier-league-manchester-utd-aston-villa-covid-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 23:07:17+00:00

Manchester United drew level with archrival Liverpool on points at the top of the English Premier League as a sweetly struck Bruno Fernandes penalty secured a 2-1 victory over Aston Villa at Old Trafford.

## Former GOP strategist Rick Wilson has advice for Biden
 - [https://www.cnn.com/videos/politics/2020/12/31/sasse-gop-election-certification-objections-government-wilson-bts-nr-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/31/sasse-gop-election-certification-objections-government-wilson-bts-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 22:36:17+00:00

Sen. Ben Sasse (R-NE) wrote on Facebook that he has been urging his Republican colleagues to "reject" objecting the certification process of the Electoral College and President-elect Joe Biden's victory, adding that talk of objecting the process is a "dangerous ploy." CNN's John Avlon discusses with former Republican strategist Rick Wilson and FixUS Founder Maya MacGuineas.

## Crowds fill streets in pandemic-hit Wuhan to celebrate New Year
 - [https://www.cnn.com/2020/12/31/asia/crowds-wuhan-new-year-intl-hnk-scli/index.html](https://www.cnn.com/2020/12/31/asia/crowds-wuhan-new-year-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 21:42:54+00:00

Large crowds took to the streets at midnight on Friday in the central Chinese city of Wuhan, celebrating the arrival of 2021 after a year marred by a deadly pandemic that killed thousands there and required the city to be locked down between the end of January and early April.

## Here's what happened at New Year's Eve party after Trump bailed on it
 - [https://www.cnn.com/2021/01/01/politics/mar-a-lago-new-years-eve/index.html](https://www.cnn.com/2021/01/01/politics/mar-a-lago-new-years-eve/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 20:32:22+00:00



## Hear what happened at NYE party after Trump bailed on it
 - [https://www.cnn.com/videos/politics/2021/01/01/trump-no-show-new-years-eve-bash-bennett-sot-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/01/trump-no-show-new-years-eve-bash-bennett-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 20:30:13+00:00

Some Mar-a-Lago guests paid over a thousand dollars to attend Trump's annual New Year's Eve party, but Trump was a no show. CNN's Kate Bennett explains what happened next.

## Biographer: Pence torn between serving Trump and country
 - [https://www.cnn.com/videos/politics/2021/01/01/mike-pence-louie-gohmert-ignore-certify-election-results-dantonio-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/01/mike-pence-louie-gohmert-ignore-certify-election-results-dantonio-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 20:19:02+00:00

Vice President Mike Pence's lawyers asked a federal judge to reject a request from Rep. Louie Gohmert (R-TX) that attempts to force Pence to ignore electoral votes of several key states when Congress meets to certify the 2020 presidential election. Biographer and CNN contributor Michael D'Antonio breaks down the tough spot in which this places the Vice President.

## Andy Cohen and Snoop Dogg discuss places he has been high
 - [https://www.cnn.com/videos/us/2021/01/01/anderson-cooper-andy-cohen-snoop-dogg-high-game-vpx.cnn](https://www.cnn.com/videos/us/2021/01/01/anderson-cooper-andy-cohen-snoop-dogg-high-game-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 19:58:52+00:00

Snoop Dogg plays a game with Anderson Cooper and Andy Cohen to tell them some of the places he has smoked marijuana.

## These five tips will help you sleep better
 - [https://www.cnn.com/videos/health/2020/04/10/five-tips-to-sleep-better-wellness-orig.cnn](https://www.cnn.com/videos/health/2020/04/10/five-tips-to-sleep-better-wellness-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 19:53:14+00:00

Whether you're dealing with anxiety, fighting an illness, or want to feel your best, a good night's sleep is extremely important.  Here are some tips to help you sleep better.

## US Senate votes to override Trump's veto on defense bill
 - [https://www.cnn.com/2021/01/01/politics/senate-votes-to-override-trump-veto-ndaa/index.html](https://www.cnn.com/2021/01/01/politics/senate-votes-to-override-trump-veto-ndaa/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 19:42:10+00:00

The Senate voted on Friday to override President Donald Trump's veto of the sweeping defense bill known as the National Defense Authorization Act, delivering a bipartisan rebuke to the President in his final days in office.

## US surpasses 20 million coronavirus cases
 - [https://www.cnn.com/collections/intl-us-coronavirus-0101/](https://www.cnn.com/collections/intl-us-coronavirus-0101/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 18:00:43+00:00



## 21 places to go in 2021
 - [https://www.cnn.com/travel/article/places-to-visit-2021/index.html](https://www.cnn.com/travel/article/places-to-visit-2021/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 17:57:18+00:00

From the gloomy depths of a Northern Hemisphere winter like no other, it can seem futile thinking about vacation plans for the year ahead.

## MF Doom, influential rapper, died in October at 49
 - [https://www.cnn.com/2021/01/01/entertainment/mf-doom-obit/index.html](https://www.cnn.com/2021/01/01/entertainment/mf-doom-obit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 17:05:53+00:00

MF Doom, a masked rapper who was much respected in the industry, died in October, his wife and record label shared on social media Thursday.

## 2020 was a terrible year for Europe. 2021 won't be much better
 - [https://www.cnn.com/2020/12/31/europe/eu-bad-2020-2021-analysis-intl/index.html](https://www.cnn.com/2020/12/31/europe/eu-bad-2020-2021-analysis-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 16:20:30+00:00

• Neither human rights concerns nor US disapproval could stop EU-China investment deal

## Travel in and out of Britain won't be the same again. Here's what you need to know
 - [https://www.cnn.com/travel/article/brexit-travel-changes/index.html](https://www.cnn.com/travel/article/brexit-travel-changes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 16:14:59+00:00

• A look back at Boris Johnson's tumultuous 2020
• The UK finally cuts ties with the European Union

## 'Queer Eye' star Jonathan Van Ness reveals he got married
 - [https://www.cnn.com/2021/01/01/entertainment/jonathan-van-ness-married/index.html](https://www.cnn.com/2021/01/01/entertainment/jonathan-van-ness-married/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 15:11:31+00:00

Jonathan Van Ness revealed he had some personal good news in 2020.

## Doctors question UK medical chiefs' decision to spread out vaccine doses
 - [https://www.cnn.com/2021/01/01/health/uk-vaccine-doses-chief-medical-officers-intl/index.html](https://www.cnn.com/2021/01/01/health/uk-vaccine-doses-chief-medical-officers-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 14:24:53+00:00

The UK's chief medical officers have defended a decision to delay second doses of the Pfizer/BioNTech vaccine in order to prioritize first doses, saying it will protect as many vulnerable people as possible while the coronavirus is running rampant.

## Chrissy Teigen celebrates sober New Year's Eve
 - [https://www.cnn.com/2021/01/01/entertainment/chrissy-teigen-sober-new-year/index.html](https://www.cnn.com/2021/01/01/entertainment/chrissy-teigen-sober-new-year/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 14:22:32+00:00

It looks like Chrissy Teigen enjoyed her New Year's Eve.

## These kids are creating epic sci-fi short films using their phones, and Hollywood is paying attention
 - [https://www.cnn.com/2021/01/01/africa/critics-company-young-filmmakers-nigeria-spc-intl/index.html](https://www.cnn.com/2021/01/01/africa/critics-company-young-filmmakers-nigeria-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 13:56:46+00:00

Across a rocky landscape, two young girls find themselves running for cover as spaceships fire laser guns into the field.

## The US President has brought his drama show back to Washington early
 - [https://www.cnn.com/2021/01/01/politics/new-year-2021-donald-trump-joe-biden/index.html](https://www.cnn.com/2021/01/01/politics/new-year-2021-donald-trump-joe-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 13:02:06+00:00

It is officially, finally 2021. But while everyone on Earth has had enough of the year that was, Americans need to gird themselves for a bit more 2020, at least to start, as a large portion of Republican lawmakers put their names next to President Donald Trump's effort to overturn the election.

## How Biden defied history at every turn to win
 - [https://www.cnn.com/2021/01/01/politics/biden-history-analysis/index.html](https://www.cnn.com/2021/01/01/politics/biden-history-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 13:00:29+00:00

President-elect Joe Biden proved a lot of detractors wrong by winning the 2020 presidential election. It wasn't easy for Biden, as he took an unusual path to the White House.

## The science of how to stick to New Year's resolutions and truly change your habits
 - [https://www.cnn.com/2021/01/01/health/new-years-resolutions-wellness/index.html](https://www.cnn.com/2021/01/01/health/new-years-resolutions-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 11:48:44+00:00

Next year will be a crucial year for Erika Kirgios as she works to complete her doctorate, publish academic papers and try to land a faculty job at a university.

## The best places to travel in 2021
 - [https://www.cnn.com/videos/travel/2021/01/01/best-places-to-travel-2021.cnn](https://www.cnn.com/videos/travel/2021/01/01/best-places-to-travel-2021.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 10:32:52+00:00

We wait, we hope, we plan. When it's safe again, CNN Travel's editors picked 21 places they would love to go to in 2021.

## WHO approves Pfizer/BioNTech vaccine in breakthrough for developing nations
 - [https://www.cnn.com/2021/01/01/world/who-pfizer-biontech-vaccine-approved-intl/index.html](https://www.cnn.com/2021/01/01/world/who-pfizer-biontech-vaccine-approved-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 10:00:40+00:00

The World Health Organization has approved the Pfizer/BioNTech vaccine for emergency use, paving the way for lower and middle-income countries to begin immunizing their populations against Covid-19.

## Australia has changed its national anthem in a bid to reflect 60,000 years of Indigenous history
 - [https://www.cnn.com/2021/01/01/australia/australia-anthem-indigenous-intl-hnk-scli/index.html](https://www.cnn.com/2021/01/01/australia/australia-anthem-indigenous-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 07:04:30+00:00

Australia woke up to a new year on Friday -- and a slightly different national anthem.

## New Year's celebrations around the world
 - [https://www.cnn.com/2020/12/31/world/gallery/2021-new-year-celebrations/index.html](https://www.cnn.com/2020/12/31/world/gallery/2021-new-year-celebrations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 06:03:52+00:00

We can finally say goodbye to 2020, a messy, tragic year.

## 8 buildings that will shape architecture in 2021
 - [https://www.cnn.com/style/article/anticipated-architecture-2021/index.html](https://www.cnn.com/style/article/anticipated-architecture-2021/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 05:58:18+00:00

The pandemic may have brought work to a halt on projects around the world, but next year is nonetheless set to welcome an exciting array of new buildings.

## Watch the world saying goodbye to 2020
 - [https://www.cnn.com/videos/world/2020/12/31/2021-new-year-celebrations-around-the-world-orig-jm.cnn](https://www.cnn.com/videos/world/2020/12/31/2021-new-year-celebrations-around-the-world-orig-jm.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 05:55:21+00:00

From New Zealand to Moscow, see how cities around the world are ringing in 2021.

## Mariah Carey shares her personal highlight from 2020
 - [https://www.cnn.com/videos/us/2021/01/01/anderson-cooper-andy-cohen-nye-special-mariah-carey-vpx.cnn](https://www.cnn.com/videos/us/2021/01/01/anderson-cooper-andy-cohen-nye-special-mariah-carey-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 05:30:05+00:00

CNN's New Year's Eve Live co-hosts Anderson Cooper and Andy Cohen ring in 2021 from Times Square. They were joined by singer Mariah Carey who shared her highlight from 2020.

## Anderson Cooper's heartwarming message to those grieving loved ones
 - [https://www.cnn.com/videos/us/2021/01/01/anderson-cooper-andy-cohen-nye-special-ac-message-lost-loved-ones-vpx.cnn](https://www.cnn.com/videos/us/2021/01/01/anderson-cooper-andy-cohen-nye-special-ac-message-lost-loved-ones-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 05:10:39+00:00

CNN's Anderson Cooper takes a moment during the New Year's Eve Live special to talk about losing his father as a young boy, empathizing with those that lost loved ones in 2020.

## US defense officials divided over potential for Iranian attack on eve of grim anniversary
 - [https://www.cnn.com/2020/12/30/politics/defense-officials-divided-potential-iran-attack/index.html](https://www.cnn.com/2020/12/30/politics/defense-officials-divided-potential-iran-attack/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 04:32:23+00:00

The US flew nuclear-capable B-52 bombers to the Middle East Wednesday in the latest show of force meant to deter Iran, as defense officials remain divided over the risk posed by the regime and the Iraq-based militias it supports.

## Thailand bans food, drink, newspapers and magazines on domestic flights
 - [https://www.cnn.com/travel/article/thailand-airplane-food-drink-ban-intl-hnk/index.html](https://www.cnn.com/travel/article/thailand-airplane-food-drink-ban-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 04:31:36+00:00

In an effort to stem the tide of the coronavirus, Thailand has banned food, drink and any printed materials other than safety information cards on board domestic flights. The airlines will have to follow the regulations or could face possible penalty from their regulator, Civil Aviation Authority of Thailand.

## California hospitals stressed to the 'brink of catastrophe' by the coronavirus surge
 - [https://www.cnn.com/2020/12/31/health/california-covid-hospitals-catastrophe/index.html](https://www.cnn.com/2020/12/31/health/california-covid-hospitals-catastrophe/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 04:20:47+00:00

Overflowing hospital morgues, increased 911 wait times, beds only opening when patients die. Hospitals in California, where almost all of the state's 40 million residents are living under stay-at-home orders, are seeing historic stress points.

## Andre Hill's friend told police he was just dropping off 'Christmas money' when he was shot, new body camera footage shows
 - [https://www.cnn.com/2020/12/31/us/andre-hill-shooting-columbus-mayor/index.html](https://www.cnn.com/2020/12/31/us/andre-hill-shooting-columbus-mayor/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 03:11:55+00:00

New body camera footage released by Columbus, Ohio, police Thursday shows the moments after Andre Hill was shot by a police officer -- including Hill's body being handcuffed as he lay on the ground and a woman telling police he was there to bring her Christmas money and "didn't do anything."

## Carole Baskin shares biggest 'Tiger King' misconception
 - [https://www.cnn.com/videos/entertainment/2020/12/31/anderson-cooper-andy-cohen-nye-special-carole-baskin-tiger-king-vpx.cnn](https://www.cnn.com/videos/entertainment/2020/12/31/anderson-cooper-andy-cohen-nye-special-carole-baskin-tiger-king-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 02:58:53+00:00

CNN's New Year's Eve Live co-hosts Anderson Cooper and Andy Cohen ring in 2021 from Times Square. They were joined by "Tiger King's" Carole and Howard Baskin, who dressed up for the occasion.

## 21 things to look forward to in 2021 ... if everything works out
 - [https://www.cnn.com/2020/12/31/us/2021-look-forward-things-to-look-forward-future-events-trnd/index.html](https://www.cnn.com/2020/12/31/us/2021-look-forward-things-to-look-forward-future-events-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 02:26:24+00:00

Yes, it may be tempting fate. Yes, the 2020 version of this story now reads like a depressing farce.

## She's back... 'SNL' alum returns with hilarious impression
 - [https://www.cnn.com/videos/media/2021/01/01/anderson-cooper-andy-cohen-nye-special-cheri-oteri-barbara-walters-vpx.cnn](https://www.cnn.com/videos/media/2021/01/01/anderson-cooper-andy-cohen-nye-special-cheri-oteri-barbara-walters-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 02:21:44+00:00

CNN's New Year's Eve Live co-hosts Anderson Cooper and Andy Cohen ring in 2021 from Times Square with 'SNL' alum Cheri Oteri.

## People we've lost in 2020
 - [https://www.cnn.com/2020/01/10/entertainment/gallery/people-we-lost-2020/index.html](https://www.cnn.com/2020/01/10/entertainment/gallery/people-we-lost-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 01:21:37+00:00

In a year that will be remembered for loss, we look back at some of the most famous people who died in 2020.

## McConnell called Hawley out over objecting to Electoral College vote during conference call Hawley wasn't on
 - [https://www.cnn.com/2020/12/31/politics/mcconnell-hawley-electoral-college-vote/index.html](https://www.cnn.com/2020/12/31/politics/mcconnell-hawley-electoral-college-vote/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 00:46:00+00:00

Senate Majority Leader Mitch McConnell on Thursday held a conference call with the Senate GOP caucus in which he questioned Missouri Sen. Josh Hawley over his plans to object to the Electoral College vote, according to a source directly familiar with the call.

## Former CIA director 'awards' Hawley as the 'most corrupt senator'
 - [https://www.cnn.com/videos/politics/2020/12/31/john-brennan-josh-hawley-acosta-intv-sitroom-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/31/john-brennan-josh-hawley-acosta-intv-sitroom-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 00:39:38+00:00

Former CIA Director John Brennan explains why he named Sen. Josh Hawley (R-MO) the "Most Craven, Unprincipled, & Corrupt Senator" after he announced plans to object to the Electoral College vote on January 6.

## Trump extends immigration restrictions
 - [https://www.cnn.com/2020/12/31/politics/trump-immigration-restrictions-pandemic/index.html](https://www.cnn.com/2020/12/31/politics/trump-immigration-restrictions-pandemic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 00:38:08+00:00

President Donald Trump extended certain restrictions on legal immigration and on visas that allow immigrants to temporarily work in the United States on Thursday, just hours before those restrictions were set to lapse. Trump extended the restrictions through March 31, two months after he will leave office.

## Ex-GOP senator slams Republicans: May be time for new party
 - [https://www.cnn.com/videos/politics/2020/12/31/william-cohen-may-be-time-for-new-republican-party-sot-tsr-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/31/william-cohen-may-be-time-for-new-republican-party-sot-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-01 00:21:35+00:00

Former Republican Senator and Defense Secretary William Cohen criticized members of his own party who are signing on to President Donald Trump's election challenge, comparing them to circus animals under Trump's control.

