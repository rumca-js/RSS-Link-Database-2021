# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 BEST PC Graphics of 2020 [4K ULTRA SETTINGS]
 - [https://www.youtube.com/watch?v=P3tdW-LRUZs](https://www.youtube.com/watch?v=P3tdW-LRUZs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-02 00:00:00+00:00

2020 was a benchmark year in PC game graphics. Gamers saw a generational leap in visuals and ray tracing is here to stay. Here's the most impressive, realistic graphics we've seen this past year on Steam, Epic, and beyond!
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10. Call of Duty: Black Ops Cold War

Release Date : November 13, 2020

Platform : PC PS4 PS5 XBOX ONE XSX



9. Assassin's Creed: Valhalla

Release Date : PC PS4 XBOX ONE XSX STADIA November 10, 2020

Platform : PS5 November 12, 2020



8. Doom Eternal

Release Date : PC PS4 XBOX ONE STADIA March 20, 2020

Platform : Switch December 8, 2020



7. Watch Dogs: Legion 

Release Date : PC PS4 XBOX ONE STADIA 29 October 2020

Platform :  XSX Amazon Luna 10 November 2020

Platform : PS5 12 November 2020



6. Microsoft Flight Simulator

Release Date :  August 18, 2020 

Platform : PC XBOX ONE



5. Amnesia: Rebirth

Release Date : October 20, 2020

Platform : PC PS4 Linux



4. Ghostrunner

Release Date : PC PS4 XBOX ONE October 27, 2020

Platform : Switch November 10, 2020



3. Star Wars: Squadron

Release Date :October 2, 2020

Platform : PC PS4 XBOX ONE 



2. Death Stranding

Release Date : July 14, 2020

Platform : PC



1. Cyberpunk 2077 

Release Date : 10 December 2020

Platform : PC PS4 XBOX ONE STADIA

## BIGGEST GAMING STORIES OF 2020
 - [https://www.youtube.com/watch?v=64-_jKryRlA](https://www.youtube.com/watch?v=64-_jKryRlA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-01 00:00:00+00:00

2020 had a ton of surprising news stories from the gaming industry world. Here are some of the biggest/most interesting stories. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Instagram: https://goo.gl/HH6mTW

Twitter: https://bit.ly/3deMHW7

