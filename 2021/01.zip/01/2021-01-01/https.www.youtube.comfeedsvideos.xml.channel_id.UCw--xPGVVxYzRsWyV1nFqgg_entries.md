# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Dark Lord Training - Henchmen
 - [https://www.youtube.com/watch?v=xH_e4_4S63w](https://www.youtube.com/watch?v=xH_e4_4S63w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-02 00:00:00+00:00

Here is how YOU as a dark lord should go about hiring your henchmen! 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Cyberpunk 2077 - Book Nerd Review
 - [https://www.youtube.com/watch?v=LHutQ_yXkcw](https://www.youtube.com/watch?v=LHutQ_yXkcw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-01 00:00:00+00:00

My review of Cyberpunk 2077. The latest cyberpunk game from CD Projekt Red. Lets talk Cyberpunk 2077. 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

