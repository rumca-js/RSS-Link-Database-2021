# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The CHEAPEST Legit Gaming Laptop - Gateway Performance Notebook
 - [https://www.youtube.com/watch?v=kRAGtV-WpIg](https://www.youtube.com/watch?v=kRAGtV-WpIg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-02 00:00:00+00:00

Get $25 off each pair with offer code LinusTechTips at https://www.vessifootwear.com/linustechtips

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

With an RTX 2060 for just $700 the Gateway Performance Notebook 15.6" sounds like an incredible deal... if Gateway haven't cut too many corners.

Buy Gateway Performance Notebook 15.6"
On Walmart (PAID LINK): https://geni.us/DkZT9kV
(Deal Pricing should be back soon™ so keep your eyes peeled)

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1288847-the-cheapest-legit-gaming-laptop/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Foldable iPhone.. YES!! - WAN Show January 1, 2021
 - [https://www.youtube.com/watch?v=nT0M2lv2QVM](https://www.youtube.com/watch?v=nT0M2lv2QVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-01 00:00:00+00:00

Buy LTT water bottles on Amazon: http://lmg.gg/lttbottleamzn

Check out Seasonic's PRIME 850 W Titanium on Amazon at https://lmg.gg/seasonicprime

Start your build today at https://www.buildredux.com/linus

Learn more and try KernelCare+ for 7 days on all your servers at https://hubs.ly/H0BNgfv0

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Foldable-iPhone---YES-----WAN-Show-January-1--2021-eohu37

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Pizza Thyme Pizza FanClub)
0:00 Start
0:24 Linus And Luke's New Years experience.
1:42 Topics to be covered
3:09 Intro
3:52 Linus forgot something
4:30 Foldable iPhones and Apple's whole product ecosystem
 4:40 Two different hinge designs
 5:20 Apple has been introducing more SKUs of the iPhone since original launch
 7:39 Apple is likely to make folding phones as a parallel product line 
 9:53 Nintendo is similar to Apple with killing popular products and reimagining it.
 13:24 Future iPhone lineup predictions
 14:33 iFold as a new device?
 17:14 iPod's Reason for Existence
 20:02 Airpod versus Beats
 22:23 Beats May Have Been Bought to be Killed
 24:35 Details on Foldable iPhone Prototypes
27:15 The Artificial Sun Rises in the East (Fusion Reactor)
 27:22 Superconducting Fusion Tokamak Reactor Operates for 20 seconds
 28:37 Current issues with fusion reactors
29:39 Tyler update
33:17 Hedge Fund Advices Intel to Outsource CPU Manufacturing
 33:26 Just because you give someone funding does not mean you know how to use it.
 35:18 Hedge fund demands intel shed CPU manufacturing.
 37:03 Gamers Nexus Disappointment 2020 Build.
 38:22 Hedge fund manager victim of Dunning-Kruger effect.
 39:38 Linus's Speculation on TSMC Intel Collaboration
 42:58 How Intel Differs From The Competition
45:06 Sponsor Spots ft Incorrect Banners
 45:30 Redux
 46:25 Seasonic
 47:52 KernalCare
49:01 LMG hiring interview with Madison tomorrow
51:47 Linus selling water bottles on Amazon.
54:00 Apple knew about child labor for years.
55:50 Shroud
 56:24 Shocker Linus knows what happens in videos and acts first reactions sometimes.
 58:48 Linus Reacts to Shroud Reacts to Linus Tech Tips
1:02:00 Superchats
 1:02:03 Hello from Texas
 1:02:17 What will happen to old LTT servers?
 1:02:56 Apple Child Labor Hypocrisy
 1:05:00 Northern Lights Deskpad
 1:05:38 Dell Update
 1:05:56 Linus workstation stream
 1:06:32 Underwear in stock when?
1:10:18 Outro

