# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## 18 YR OLD LIFECOACH CHANGED MY MIND
 - [https://www.youtube.com/watch?v=gD_Ol8L2y9c](https://www.youtube.com/watch?v=gD_Ol8L2y9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-02 00:00:00+00:00

Truly the greatest meme opportunity of our era: https://www.reddit.com/r/Coffeezilla_gg/

twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Daily uploads in 2021, but there's a catch...
 - [https://www.youtube.com/watch?v=9jp2cTYOywM](https://www.youtube.com/watch?v=9jp2cTYOywM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-01 00:00:00+00:00

BALD THINGS ARE COMING IN 2021! Let's make this the best year ever!
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

