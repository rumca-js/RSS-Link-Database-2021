# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Samsung Galaxy S21 Impressions: New Year, New Price!
 - [https://www.youtube.com/watch?v=wUBy2W1iKpo](https://www.youtube.com/watch?v=wUBy2W1iKpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-01-14 00:00:00+00:00

Galaxy S21 entire lineup drops in price, starting at $799! Here's my hands-on.

Galaxy S21 Ultra Impressions: https://youtu.be/lvV3jSLYK8A

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## Samsung Galaxy S21 Ultra Impressions: Redemption Time!
 - [https://www.youtube.com/watch?v=lvV3jSLYK8A](https://www.youtube.com/watch?v=lvV3jSLYK8A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-01-14 00:00:00+00:00

Galaxy S21 Ultra makes some tweaks and drops the price! Here'a first look.

S21/S21+ Impressions: https://youtu.be/wUBy2W1iKpo

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Filet Mignon by Alltta
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

