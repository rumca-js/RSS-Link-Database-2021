# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Amazon's Lord of the Rings VS Amazon's Wheel of Time!
 - [https://www.youtube.com/watch?v=Y_B3Dz7eYHU](https://www.youtube.com/watch?v=Y_B3Dz7eYHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-14 00:00:00+00:00

Well amazon is bringing up two of the most anticipated shows the fantasy genre has ever seen. The Wheel of Time and the Lord of the Rings will be on the small screen. Lets talk about those two shows possible success! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## BOOK UPDATE! (TITLE, COVER ARTIST, NARRATOR)
 - [https://www.youtube.com/watch?v=S3cXWwpQHlk](https://www.youtube.com/watch?v=S3cXWwpQHlk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-13 00:00:00+00:00

Well it is done being written. Now the hard part begins! 
Checkout Campfire here today: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q1_21
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

For Publication Help: https://www.youtube.com/c/iWriterly/videos 
Cover Artist: https://www.artstation.com/felixortiz 
Michael & Kate website: https://www.katereadingaudiobooks.com/

