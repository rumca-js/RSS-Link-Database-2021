# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## How an ancient tattoo art became an Instagram sensation
 - [https://www.cnn.com/style/article/azra-khamissa-modern-henna-hnk-spc-intl/index.html](https://www.cnn.com/style/article/azra-khamissa-modern-henna-hnk-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-13 03:32:47+00:00

With a history spanning millennia across the Middle East, North Africa, and South Asia, henna is steeped in tradition and cultural rituals. The natural dye is typically used to create temporary, intricate body art for religious festivals and celebrations, such as weddings.

