# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Hitman 3: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=rWd4NgcRpQw](https://www.youtube.com/watch?v=rWd4NgcRpQw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-14 00:00:00+00:00

Hitman 3 (PC, PS5, Series X, Xbox One, PS4, Stadia) is releasing soon, so here's everything you need to know before picking it up.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

https://www.gameinformer.com/2020/12/24/5-things-you-should-know-about-hitman-3

https://www.polygon.com/2021/1/8/22219289/hitman-3-preview-dubai-dartmoor-pc-ps5-ps4-xbox-one-series-x

## Top 10 NEW RPGs of 2021
 - [https://www.youtube.com/watch?v=o5xVTNj4b08](https://www.youtube.com/watch?v=o5xVTNj4b08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-14 00:00:00+00:00

In 2021 we'll see tons of RPGS, from action-oriented to Japanese style and everything in between. Here's what we're looking forward to the most.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10 Dark Alliance
Platform: PC, consoles
Release Date: 2021

9 Biomutant
Platform: PC, PS4, Xbox One
Release Date: 2021

8 Gotham Knights
Platform: PC, PS4, PS5, Xbox One, XSX
Release Date: 2021

7 Outriders
Platform: PC, PS4, PS5, XONE, XSX/S April 1, 2021 
Release Date: Stadia 2021

6 ELDEN RING
Platform: PC, PS4, PS5, Xbox One, XSX
Release Date: 2021

5 Monster Hunter Rise
Platform: Switch
Release Date:  March 26, 2021

4 Starfield
Platform: TBA
Release Date: TBA

3 Dying Light 2
Platform: PC, PS4, PS5, Xbox One, XSX
Release Date:  2021

2 Horizon Forbidden West
Platform: PS4, PS5
Release Date: Q3/Q4 2021

1 Vampire: The Masquerade – Bloodlines 2
Platform: PC, PS4, XBOX One, PS5, XSX
Release Date: 2021

BONUS
Nier: Replicant ver. 1.22474487139...
Platform: PS3, Xbox 360 April 27, 2010
Release Date: PC, PS4, Xbox One April 23, 2021

Bravely Default 2
Platform: Switch
Release Date:  February 26, 2021

## 10 Mind Blowing In-Game Moments in Recent Games
 - [https://www.youtube.com/watch?v=NoZZTuoKfi0](https://www.youtube.com/watch?v=NoZZTuoKfi0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-13 00:00:00+00:00

2020 video games had some mind-blowing twists, turns, and shocking surprises. Here are some of our favorite big video game moments. SPOILER ALERT.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

