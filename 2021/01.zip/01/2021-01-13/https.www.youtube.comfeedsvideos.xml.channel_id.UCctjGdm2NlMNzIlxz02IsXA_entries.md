# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## CAPITOL HELL! - Ray Gun Recap
 - [https://www.youtube.com/watch?v=ou70sJflYvA](https://www.youtube.com/watch?v=ou70sJflYvA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2021-01-14 00:00:00+00:00

Thanks to Dollar Shave Club for sponsoring! Go to http://DollarShaveClub.com/RayGun to get your starter set for $5. After that, the restock box ships full- sized products at regular price. 

Like the Barenaked Ladies prophecized, it's been one week. 2021 is a fascinating one already. 

Paul ► The Act Man - https://www.youtube.com/channel/UC7WDD6yHgzdqijHluCi1z-Q

SHIRTS ► https://teespring.com/stores/chris-ray-gun
TWITTER ► https://twitter.com/ChrisRGun
FACEBOOK ► http://on.fb.me/15OyE7z
TWITCH ► http://www.twitch.tv/chrisraygun
PATREON ► https://www.patreon.com/ChrisRay
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/
SACRED SYMBOLS  ► https://apple.co/2Rqmklc
SECOND CHANNEL ► bit.ly/snarktank

