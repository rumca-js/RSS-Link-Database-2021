# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Impossible New Year's Resolution
 - [https://www.youtube.com/watch?v=jJMySBlarrA](https://www.youtube.com/watch?v=jJMySBlarrA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-01-14 00:00:00+00:00

I just wanted to live in the moment is that so hard?! The first 1000 people to use this link will get a free trial of Skillshare Premium Membership: https://skl.sh/julienolke01211

Thank you for liking and subscribing! 
Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke

