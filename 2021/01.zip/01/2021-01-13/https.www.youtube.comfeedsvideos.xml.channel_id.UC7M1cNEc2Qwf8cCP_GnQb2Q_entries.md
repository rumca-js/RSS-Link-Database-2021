## PROF - Squad Goals (Official Music Video)
 - [https://www.youtube.com/watch?v=iDaUy4T7rVI](https://www.youtube.com/watch?v=iDaUy4T7rVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7M1cNEc2Qwf8cCP_GnQb2Q
 - date published: 2021-01-13 00:00:00+00:00

PROF - Squad Goals (Official Music Video)

PROF hops into the role he was born to play to celebrate the first single off his 2020 album 'Powderhorn Suites'

STREAM/BUY POWDERHORN SUITES: https://ffm.to/powderhornsuites
BUY POWDERHORN SUITES CD, VINYL, & MERCH: http://bit.ly/PowderhornSuitesShop
SUBSCRIBE FOR MORE PROF: https://www.youtube.com/c/PROFGAMPO/

FOLLOW PROF –
https://www.stophousegroup.com
https://www.facebook.com/profgampo
https://www.twitter.com/profgampo
https://www.instagram.com/profgampo 

VIDEO CREDITS –
Director / DP / Editor - Tomas Aksamit
Executive Producer - Mike Campbell
Producers - Cody Otte, Mike Campbell, Tomas Aksamit, & Jacob Anderson
Production Designer + Stylist - Jen Sonibare
Gaffer - Jacob Velander
Key Grip - Andrew Dammer
Grip - Colton Fossen
HMU + Stylist Assistant - Romeny Chan
Set Carpenters - Sam Aksamit & Braden Berman
PAs - Cody Otte, Mike Campbell, Josh Mattson, Sam Koshiol, Josh Murray, & Kevin Albertson
Talent - Extra love to our amazing group of talent on this video: Yutshua Lee, Eric McKnight, James Prioleau, Eric Hubere, Katherine Haupt, Kally Hilton, Madisen Tuhy, Mini Preston, Ava Wagner, Carter Wilburn, Miles Wilburn, Elsa Sibell, Connor Sibell, Bo Jorgensen, Hazel Jorgensen, Penelope Jorgensen, Amelia Parker, Audrey Parker, Julian Smythe, Tierius Chum, Jacob Anderson, Willie Clay, Dillon Parker, Zeke Uriah Salo-Salaam, Albert Nix, Scotchie, Ashely Neverman
Thanks - A very special thanks to Minneapolis Telecommunications Network, Tasty Lighting, Kristie Elfering, and Elfering & Associates!
https://www.mtn.org/ 
http://www.tastylighting.com/ 

SONG CREDITS –
Written and Performed by: Prof
Beat by: Jordy Bangs

LYRICS – 
(Chorus 1)
I got guns, hoes, money, dro
Cars, boats, you should know
Dogs, bros, squad goals
Hold up, whoa
You name it
Guns, hoes, money, dro
Cars, boats, you should know
Dogs, bros, squad goals
Hold up, whoa
You name it
I’m throwing money off balcony into the crowd because I want to
 
(Verse 1) 
God damn I feel good
Sure that you already know
One things understood,
Ain’t nothin that can stop my glow
Mmmm dog gonit
Can’t I just take my time?
All these clout chasing motherfuckers rushin all around me I’m like,
Bitch hold your horses
(Prof you’re the best)
I’m like true I am,
Rosario Dawson know who I am
If it’s cool with you, girl I could move right in
You do not understand just how cool I am
Like see, look at me, look at me
I’m on a beach
Don’t try to holler cause I’m out of reach
I got no service, I’m out on the keys
A couple woman,
My dollars and me
Bout to go swimming, 
Thank god I’m a G
One shot for me
Un bebidas para ti
Let’s skinny dip in the sea
(You know what I’m saying,
I’d rather do things we remember later,
You know what I mean?)
 
(Chrous 2)
I got guns, hoes, money, dro
Cars, boats, you should know
Dogs, bros, squad goals
Hold up, whoa
You name it
Guns, hoes, money, dro
Cars, boats, you should know
Dogs, bros, squad goals
Hold up, whoa
You name it
I’m throwing money off balcony into the crowd because I want to
 
(Verse 2)
Oooh, seriously, look at myself
Condom model over here
Oooh, seriously, look at my flow
Colder than a polar bear
Oooh, straight up I’m an awesome person
Oooh, you ain’t ready for this sauce I’m serving
Oooh, straight up, I’m an awesome person
Oooh, you ain’t ready for the sauuuce
Young Pookie, your highness
Gone find the finest vaginas
From China to Thailand
Got ‘em whinin
Why not combine ‘em?
Pardon me let me chime in
But theres science behind my conniving
I’m refined and violent
Throw the lime in, fine dine the hyman
Swag
Swag
(aaaaaahh)
 
(Chorus 3)
I got guns, hoes, money, dro
Cars, boats, you should know
Dogs, bros, squad goals
Hold up, whoa
You name it
Guns, hoes, money, dro
Cars, boats, you should know
Dogs, bros, squad goals
Hold up, whoa
You name it
I’m throwing money off balcony into the crowd because I want to
 
(Verse 3)
(Hey)
Fuck it up, fuck it up, fuck it up (x2)
(Hey)
Swear to god, if you could throw it at me that I’ll grab it and fuck it up
(Hey)
Fuck it up, fuck it up, fuck it up (x2)
(Hey)
Swear to god, if you could throw it at me that I’ll grab it and fuck it up
Oooh, how bout that drink,
You gonna finish that?
If your bro talking shit I’m gon’ get his ass
I got two hands that gon’ fit his ass
Knock him out cold, he gon’ shit his ass
Talk on the phones up in Trinidad
Bout to make films up on SkinaMax
Oh you just jealous because my bedroom sounds like
It’s a fucking womens tennis match
(aaaaahh)
I feel good
(oooohh-ahhhh)
I feel good
(Yeah)
I feel good
(oooohh-ahhhh)
I feel good
(Alright, yeah, alright)
(I feel good)
 
(Chorus 4)
I got guns, hoes, money, dro
(Feel good)
Cars, boats, (ooooh I feel good) you should know
Dogs, bros, squad goals
Hold up, whoa (heyyy)


#SquadGoals #PowderhornSuites #Prof

