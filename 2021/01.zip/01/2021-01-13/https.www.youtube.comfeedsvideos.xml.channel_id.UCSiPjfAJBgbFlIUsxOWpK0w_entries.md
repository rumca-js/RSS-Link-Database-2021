# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Laisse béton // Renaud // POMPLAMOOSE ft. Erik Miron
 - [https://www.youtube.com/watch?v=sEVRwGr8KzE](https://www.youtube.com/watch?v=sEVRwGr8KzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-01-14 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Here's our Spaghetti Western rendition of "Laisse béton" by Renaud...just in case Tarantino needs something for any upcoming films.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Trumpet, Guitar, Whistle: Erik Miron
Lead Vocals: Nataly Dawn
Background Vocals: Sarah Dugas
Accordion: Jack Conte
Banjo, Hi Strung Guitar, Baritone Guitar: John Schroeder  
Upright Bass: Eliana Athayde
Drums: Ben Rose
Saxophone: John Tegmeyer
Bass and Diatonic Harmonica: Ross Garren

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Branko Presley
Mixing/Mastering: Caleb Parker
Producer: John Schroeder

VIDEO CREDITS
Director: George Sloan
DP: Ricky Chavez
Camera Operators: Merlin Showalter, Sammy Rothman, Dijon Herron, Charlene Gibbs
Art Design: George Sloan, Susannah Honey
Video Editor: Dominic Mercurio

Recorded at The Village in Los Angeles.

LYRICS

J'étais tranquille j'étais peinard
Accoudé au flipper
Le type est entré dans le bar
A commandé un jambon beurre
Puis y s'est approché de moi
Et y m'a regardé comme ça
T'as des bottes, mon pote
Elles me bottent
Je parie que c'est des santiags
Viens faire un tour dans le terrain vague
Je vais t'apprendre un jeu rigolo
A grands coups de chaînes de vélo
Je te fais tes bottes à la baston
Moi je lui dis, laisse béton

Y m'a filé une beigne
Je lui ai filé une torgnole
Y m'a filé une châtaigne
Je lui ai filé mes grolles

J'étais tranquille j'étais pénard
Accoudé au comptoir
Le type est entré dans le bar
A commandé un café noir
Pis y m'a tapé sur l'épaule
Et m'a regardé d'un air drôle
T'as un blouson, mecton
L'est pas bidon
Moi je me les gèle sur mon scooter
Avec ça je serai un vrai rocker
Viens faire un tour dans la ruelle
Je te montrerai mon Opinel
Et je te chouraverai ton blouson
Moi je lui dis, laisse béton

Y m'a filé une beigne
Je lui ai filé un marron
Y m'a filé une châtaigne
Je lui ai filé mon blouson

La morale de c'te pauvre histoire
C'est que quand t'es tranquille et peinard
Faut pas trop traîner dans les bars
A moins d'être fringuer en costard
Quand à la fin d'une chanson
Tu te retrouve à poil sans tes bottes
Faut avoir de l'imagination
Pour trouver une chute rigolote

