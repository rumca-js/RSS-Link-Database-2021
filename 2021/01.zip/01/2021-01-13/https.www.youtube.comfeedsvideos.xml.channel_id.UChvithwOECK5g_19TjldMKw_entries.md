# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## The Truth About China's "Re-Education Camps"
 - [https://www.youtube.com/watch?v=alMhCPjsxlE](https://www.youtube.com/watch?v=alMhCPjsxlE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2021-01-13 00:00:00+00:00

Xinjiang is a western province in China, home to the Uyghur people. They are an ethnic minority in China, and there is a lot of discussion about the re-education camps that China is setting up, and I decided to interview a Uyghur person about this. 

Arslan's Facebook Group - https://www.facebook.com/TalkEastTurkestan/
Arlsan's Twitter - https://twitter.com/arslan_hidayat?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor

What happens in China's camps:
https://www.bbc.com/news/world-asia-china-50511063
https://www.pbs.org/newshour/features/uighurs/
https://www.vox.com/2020/7/28/21333345/uighurs-china-internment-camps-forced-labor-xinjiang
https://apnews.com/article/4ab0b341a4ec4e648423f2ec47ea5c47
https://www.bbc.co.uk/news/resources/idt-sh/China_hidden_camps
https://www.theguardian.com/world/2020/sep/24/china-has-built-380-internment-camps-in-xinjiang-study-finds

Mihrigul Tursun:
https://edition.cnn.com/2019/01/18/asia/uyghur-china-detention-center-intl/index.html
https://hongkongfp.com/2018/12/08/video-full-ex-xinjiang-detainee-mihrigul-tursuns-full-testimony-us-congressional-hearing/

Halal organ Harvesting:
https://extranewsfeed.com/muslims-are-being-slaughtered-on-demand-for-their-organs-in-china-b502133c725?gi=5a1c748bcf76
https://bylinetimes.com/2020/01/24/chinas-harvesting-of-uyghur-organs-gets-darker/
https://www.businessinsider.com/china-harvesting-organs-of-uighur-muslims-china-tribunal-tells-un-2019-9
https://menafn.com/1099610928/Is-China-Harvesting-Muslim-Prisoners-Halal-Organs-for-Rich-Saudis

Crematory next to camps:
https://www.rfa.org/english/news/uyghur/crematorium-11132020144027.html
https://www.rfa.org/english/news/uyghur/trade-11182020153703.html

Uyghur Hair:
https://www.theguardian.com/world/2020/jul/01/china-muslim-labor-camps-uighur-hair-products
https://edition.cnn.com/2020/07/02/us/china-hair-uyghur-cpb-trnd/index.html
https://www.bbc.com/news/world-asia-china-53259557

China's war on Islam:
https://www.nytimes.com/interactive/2020/09/25/world/asia/xinjiang-china-religious-site.html
https://www.npr.org/2020/11/21/932169863/china-targets-muslim-scholars-and-writers-with-increasingly-harsh-restrictions
https://www.wsj.com/articles/china-razed-thousands-of-xinjiang-mosques-in-assimilation-push-report-says-11601049531

Uyghurs being deported
https://www.middleeasteye.net/news/uighurs-china-turkey-accused-deporting-third-countries
https://www.middleeasteye.net/news/china-uighur-saudi-arabia-scholar-arrested-risk-deportation
https://www.hrw.org/news/2017/07/08/egypt-dont-deport-uyghurs-china

Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Or, if you prefer, Subscribestar - https://www.subscribestar.com/laowhy86


Car channel - https://www.youtube.com/worthlesswhips
ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts


◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun


◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor


◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina


◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina


◘ Discount code for both shows: laowinning


◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86


Be a Laowinner!
Like comment subscribe!


◘ Facebook:
http://www.facebook.com/laowhy86


◘ Instagram: 
http://instagram.com/laowhy86


◘ Music: The Muse Maker - 
https://soundcloud.com/themusemaker

