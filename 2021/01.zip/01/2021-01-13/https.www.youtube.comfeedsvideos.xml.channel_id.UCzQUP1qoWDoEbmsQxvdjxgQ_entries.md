# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Is There a Relationship Between Schizophrenia and Drug Use?
 - [https://www.youtube.com/watch?v=qlSfIrbu6OM](https://www.youtube.com/watch?v=qlSfIrbu6OM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-13 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1593 with Dr. Carl Hart. https://open.spotify.com/episode/4xMbq7gLEjFioOQ5gpSw2l?si=u9G2UCcAQa61M612MFlnqg

## Parler Being Shutdown Due to Capitol Storming
 - [https://www.youtube.com/watch?v=7M6qHqlI_Gc](https://www.youtube.com/watch?v=7M6qHqlI_Gc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-13 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1594 with Yannis Pappas. https://open.spotify.com/episode/1au5C4Mj2Gh9RzRD2c92kV?si=XLSq5rJpT3ivyMvXG502Tw

## The Crazy Life of Jack Johnson
 - [https://www.youtube.com/watch?v=ImKgje5XT0A](https://www.youtube.com/watch?v=ImKgje5XT0A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-13 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1594 with Yannis Pappas. https://open.spotify.com/episode/1au5C4Mj2Gh9RzRD2c92kV?si=XLSq5rJpT3ivyMvXG502Tw

## The History of Cocaine and Why It's Illegal with Dr. Carl Hart
 - [https://www.youtube.com/watch?v=0omEQq3N96M](https://www.youtube.com/watch?v=0omEQq3N96M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-13 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1593 with Dr. Carl Hart. https://open.spotify.com/episode/4xMbq7gLEjFioOQ5gpSw2l?si=u9G2UCcAQa61M612MFlnqg

## The Mental Toughness of Wrestlers
 - [https://www.youtube.com/watch?v=Jm2qK7fiNR8](https://www.youtube.com/watch?v=Jm2qK7fiNR8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-13 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1594 with Yannis Pappas. https://open.spotify.com/episode/1au5C4Mj2Gh9RzRD2c92kV?si=XLSq5rJpT3ivyMvXG502Tw

## What Will Happen to Trump After The Storming of the Capitol?
 - [https://www.youtube.com/watch?v=ufnTXNoXAqw](https://www.youtube.com/watch?v=ufnTXNoXAqw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-13 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1593 with Dr. Carl Hart. https://open.spotify.com/episode/4xMbq7gLEjFioOQ5gpSw2l?si=u9G2UCcAQa61M612MFlnqg

