# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Ash live from White Desert | Cercle Stories
 - [https://www.youtube.com/watch?v=TneiCUskt_I](https://www.youtube.com/watch?v=TneiCUskt_I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2021-01-14 00:00:00+00:00

Ash for a Cercle Stories live from the White Desert, in Egypt.  
Cercle Stories is our new short video concept, it's a one track live session for our Cercle Records releases. 

Ash - White Desert : The track is part of the limited edition vinyl compilation OUT NOW! 
More info here: https://Cercle.lnk.to/vinyls

☞ Cercle Records: 
Ash - White Desert : 
https://backl.ink/143249762

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ Ash
Instagram: https://bit.ly/AshOnInstagram
Facebook: https://bit.ly/AshOnFacebook
Spotify: https://bit.ly/AshOnSpotify
Youtube: https://bit.ly/AshOnYoutube
Apple Music: https://music.apple.com/fr/artist/ash/960043037

Video credits:

Artist: Ash
Location: White Desert, in Egypt
Producer: Derek Barbolla
Artistic director: Philippe Tuchmann
Director: Pol Souchier
DOP, Editing & Post-production: Mathieu Glissant (Saison Unique Production)
Cameraman: Mickaël Fidjili
Drone pilot: Jérémie Tridard
Production team: Anaïs de Framond, Dan Aufseesser, Armand Prouhèze
Technical Manager: Aurélien Moisan
Communication: Anaëlle Rouquette


--
Special thanks to:
Bas Enab, Mahmoud Zidan & Misty Moustafa Sheta from Playground. 
Galerie Joseph 

And to Saharina. 

And finally, special thanks to Ahmed Youssef, chairman of Egypt's Tourism Promotion Authority from the Ministry of Tourism.  


______

Follow us on http://www.cercle.io

