# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## WhatsApp Forces Users to Share Personal Data with Facebook
 - [https://www.youtube.com/watch?v=vODvwrexgGk](https://www.youtube.com/watch?v=vODvwrexgGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-01-13 00:00:00+00:00

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.forbes.com/sites/carlypage/2021/01/08/whatsapp-tells-users-share-your-data-with-facebook-or-well-deactivate-your-account/?sh=4228e5f02d46

https://www.canberratimes.com.au/story/7079741/rivals-surge-as-whatsapp-alters-data-terms/?cs=14329

https://arstechnica.com/information-technology/2014/11/whatsapp-brings-strong-end-to-end-crypto-to-the-masses/

https://arstechnica.com/tech-policy/2021/01/whatsapp-users-must-share-their-data-with-facebook-or-stop-using-the-app/

https://www.wired.com/story/whatsapp-facebook-data-share-notification/amp


//Soundtrack//

**rest coming soon**

Last Song available below.

» Music I produce | Burnwater on Spotify
  http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

