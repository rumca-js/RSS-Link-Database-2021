# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy morsowanie coś daje?
 - [https://www.youtube.com/watch?v=V2C8YlKkC00](https://www.youtube.com/watch?v=V2C8YlKkC00)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-01-14 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
👕 Nasze koszulki ► https://naukowybelkot.shoplo.com/
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Morsowałem?

🎞 Film o hipotermii:
https://www.youtube.com/watch?v=EFmHoGag5nk

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 Wstęp
1:44 Kiedy morsowanie się liczy?
5:26 Nie każdy powinien być morsem
8:47 Co to z nami robi?
11:57 Korzyści morsa

===
Źródła (wybrane):

M. J. Tipton i in. - Cold water immersion: kill or cure?
T. M. Koletsi i in. - Winter swimming: healthy or hazardous?: Evidence and hypotheses
P. Huttunen i in. - Effect of regular winter swimming on the activity of the sympathoadrenal system before and after a single cold water immersion
A. Lubkowska i in. - Winter-swimming as a building-up body resistance factor inducing adaptive changes in the oxidant/antioxidant status
A. S. Manolis i in. - Winter Swimming: Body Hardening and Cardiorespiratory Protection Via Sustainable Acclimation
https://www.sciencefocus.com/the-human-body/cold-water-swimming-why-an-icy-dip-is-good-for-your-mental-and-physical-health/

