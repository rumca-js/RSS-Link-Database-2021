# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Abigail Shrier Looks At The Science of Gender Dysphoria
 - [https://www.youtube.com/watch?v=tsMW02FHxTQ](https://www.youtube.com/watch?v=tsMW02FHxTQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-14 00:00:00+00:00

On The Babylon Bee Podcast, Abigail Shrier talks about the lack of science coming from transgender advocates regarding the transitioning of teenage girls. She talks to Kyle and Ethan questioning the wisdom of putting hormones into pre-pubescent teenagers. 

See the full show here:
https://youtu.be/_C6YTHGg0fA

Subscribe to The Babylon Bee to help us continue spreading the truth no one wants to hear.

Hit the bell to get your daily dose of fake news that you can trust.

## How Social Media Is Encouraging Kids To Become Trans
 - [https://www.youtube.com/watch?v=6ef0QCH7jVk](https://www.youtube.com/watch?v=6ef0QCH7jVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-14 00:00:00+00:00

On The Babylon Bee Podcast, Abigail Shrier shares how teenage girls are being told by trans activists on social media that becoming trans could be the cure to their anxiety and lack of friends. Kyle and Ethan get an insight into how transitioning is being celebrated to the point that it's attracting anyone craving social status.

See the full show here:
https://youtu.be/_C6YTHGg0fA

Subscribe to The Babylon Bee to help spread wholesome family content to the internet. 

Hit the bell to get your daily dose of fake news that you can trust.

