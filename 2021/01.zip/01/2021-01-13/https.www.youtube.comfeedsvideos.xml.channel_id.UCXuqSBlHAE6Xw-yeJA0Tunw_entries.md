# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The CLEANEST AMD Gaming PC Build
 - [https://www.youtube.com/watch?v=-tPwmK5CZUg](https://www.youtube.com/watch?v=-tPwmK5CZUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-14 00:00:00+00:00

Thanks to Seasonic for sponsoring this build! Check out the Seasonic Syncro DPC 850 PSU at https://lmg.gg/SeasonicDPC850

Check out the Seasonic Syncro Q7 Case at https://lmg.gg/SeasonicQ7

Buy ASUS ROG STRIX B550-E Gaming (PAID LINK): https://geni.us/NCoOtH

Buy AMD RYZEN 7 5900X CPU (PAID LINK): https://geni.us/Bx90

Buy Crucial Ballistix RGB 32GB DDR4 RAM (PAID LINK): https://geni.us/K4607y

Buy AMD Radeon RX 6800 XT 16GB GPU (PAID LINK): https://geni.us/hxmt

Buy Noctua NH-D15 chromax.Black CPU Cooler (PAID LINK): https://geni.us/BNBFiB

Buy Corsair Force MP600 1TB NVMe SSD (PAID LINK): https://geni.us/jZ1kL

Buy Crucial P5 2TB NVMe SSD (PAID LINK): https://geni.us/mNWLEAH

## What is 2nd Gen OLED??
 - [https://www.youtube.com/watch?v=I5xqAZn2rX0](https://www.youtube.com/watch?v=I5xqAZn2rX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-13 00:00:00+00:00

Thanks to LG for sponsoring this video! Check out the new OLED LG 77G1 and their CES experience at http://lgoledtv.co/LTT_CES

We're here at CES 2021 taking a closer look at what LG's "2nd Generation" OLED technology looks like.

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1293469-what-is-2nd-gen-oled/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

