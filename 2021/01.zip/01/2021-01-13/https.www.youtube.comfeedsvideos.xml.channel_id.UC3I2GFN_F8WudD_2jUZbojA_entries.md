# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Julien Baker - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Lccb28Inryk](https://www.youtube.com/watch?v=Lccb28Inryk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-01-14 00:00:00+00:00

http://KEXP.ORG presents Julien Baker performing a live set recorded exclusively for KEXP.

Songs:
Faith Healer
Song in E
Hardline
Fell on Black Days

Julien Baker - vocals / guitar / keys
Calvin Lauber - bass
Mariah Schneider - guitar / bg vocals
Matt Gilliam - drums
Noah Forbes - keys (overdubbed)
Becca Mancari - guest bg vocals

Session recorded at Third Man Records in Nashville, TN
Engineered / Mixed: Joshua Smith
Monitor Mix: Charlton Combs

https://julienbaker.com
http://kexp.org

## Julien Baker - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=HS2TxfBSmjs](https://www.youtube.com/watch?v=HS2TxfBSmjs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-01-13 00:00:00+00:00

http://KEXP.ORG presents Julien Baker sharing a live performance recorded exclusively for KEXP and talking to Cheryl Waters. Recorded January 6, 2021.

Songs:
Faith Healer
Song in E
Hardline
Fell on Black Days

Julien Baker - vocals / guitar / keys
Calvin Lauber - bass
Mariah Schneider - guitar / bg vocals
Matt Gilliam - drums
Noah Forbes - keys (overdubbed)
Becca Mancari - guest bg vocals

Session recorded at Third Man Records in Nashville, TN
Engineered / Mixed: Joshua Smith
Monitor Mix: Charlton Combs

https://julienbaker.com
http://kexp.org

