# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Chorwacka Istria - dlaczego Polacy jej nie lubią?! 😮 + Plitwice, Krk i dużo sucharów 🍁
 - [https://www.youtube.com/watch?v=SSg4B36h9tk](https://www.youtube.com/watch?v=SSg4B36h9tk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-01-14 00:00:00+00:00

Zachęcam do subskrypcji ►► http://bit.ly/2cmWbSO 
Kurs filmowo-montażowy 🎬 https://www.kursfilmowaniaimontazu.pl/

Dziś drugi odcinek z chorwackiej, jesiennej serii. Ponownie skupimy się na Istrii, ale bardziej przekrojowo. Ostatnio odwiedziliśmy rowerami Parenzanę, a także kawałek środkowej Istrii i do tego odcinka bardzo mocno zapraszam również: https://youtu.be/oawBI6YH6lY  

Natomiast dziś tak bardziej przekrojowo - przyjrzymy się najciekawszym i najładniejszym miejscom na Istrii. Odpowiemy sobie na pytanie co warto na Istrii zobaczyć, a co niekoniecznie? Sporo jeździliśmy po Istrii i niedalekiej okolicy (z jednym dalszym wyjątkiem) i zebrało się właściwie 10 ciekawych miejsc do zobaczenia na Istrii (i okolicy).

W tym odcinku (w kolejności pokazywania) odwiedzimy sobie:
00:00 - 00:28 - Wstęp: Istria, ciekawe miejsca. 
00:29 - 01:07 Parenzana - trasa rowerowa wzdłuż kolei wąskotorowej
01:08 - 02:05 Miasto Buzet i trufle.
02:06 - 03:33 Hum - najmniejsze miasto świata
03:34 - 06:32 Trasa 7 wodospadów
06:33 - 07:29 Pula - najpopularniejsze miasto na Istrii
07:30 - 08:12 Pochodzenie krawatów!
08:13 - 08:52 Rovinj - najładniejsze miasto na Istrii!
08:53 - 09:33 Przylądek Kamenjak
09:34 - 11:10Wyspa Krk - szybka wizyta
11:11 - 13:44  Jeziora Plitwickie Jesienią 
13:45 - 16:29 Parku Narodowym Risnjak. Trekking 

Czyli po naszemu RYŚ, którego oczywiście nie zobaczyliśmy, ale zobaczyliśmy za to sporo fajnych widoków. 

Przypominam, że film ma napisy, także jeśli ktoś niedosłyszy to bardzo proszę sobie kliknąć. Miłego oglądania!

Muzyka: Artlist, Nevaeh.

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

