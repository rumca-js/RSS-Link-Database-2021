# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Why Eyebrows Are More Important Than Eyeballs
 - [https://www.youtube.com/watch?v=RA9nUUEuPJ8](https://www.youtube.com/watch?v=RA9nUUEuPJ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-01-14 00:00:00+00:00

If you had to choose, would you keep your eyeballs or eyebrows? 
The first 1000 people to use this link will get a free trial of Skillshare Premium Membership: https://skl.sh/asapscience12201

Join our mailing list: https://bit.ly/34fWU27

Written by Mitchell Moffit
Editing by Luka Šarlija and Mitchell Moffit

FOLLOW US!
AsapSCIENCE
TikTok: @AsapSCIENCE 
Instagram: https://instagram.com/asapscience
Facebook: https://facebook.com/asapscience
Twitter: https://twitter.com/asapscience

Further Reading/Sources:

(Book) The Body: A Guide for Occupants by Bill Bryson
https://web.mit.edu/sinhalab/Papers/sinha_eyebrows.pdf
https://jov.arvojournals.org/article.aspx?articleid=2135985
https://www.vox.com/science-and-health/2018/4/9/17206448/eyebrows-forehead-science-anthropology-nature-study
https://www.smithsonianmag.com/smart-news/expressive-eyebrows-may-have-given-humans-evolutionary-edge-180968752/
https://www.sciencedaily.com/releases/2017/07/170704093813.htm
https://www.inverse.com/article/56744-dog-eyebrow-expression-evolution

