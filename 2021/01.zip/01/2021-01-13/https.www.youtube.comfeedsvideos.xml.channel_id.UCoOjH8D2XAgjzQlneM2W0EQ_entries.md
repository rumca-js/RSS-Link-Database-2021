# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## The drone industry needs to calm down...
 - [https://www.youtube.com/watch?v=1Mx-H5zmW_M](https://www.youtube.com/watch?v=1Mx-H5zmW_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-01-13 00:00:00+00:00

The first 200 people that go to https://brilliant.org/jaketran will get 20% off the annual Premium subscription!

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🌐 Best affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/39o2JNq

-----------------------
Back in the gold rush days of the mid 1800’s, there was a desperate need to deliver stuff from the East Coast where everything was established, to the new Wild West colonies over in California.

Today, our delivery ecosystem looks a little different. What’s a quantum of delivery that’s smaller than a car and bike, but greater than your feet? And faster and potentially cheaper than both? Drones. Which has led to one of the next great races in engineering. Here’s everything you need to know - and to profit from - the great drone wars.

Imagine a day when with a few taps on your phone, you order a burger. But instead of some pleb delivering it to your door by “car”, the restaurant places your food on a drone where it flies over to you in a relatively straight line (way faster than driving through traffic). That is the dream of delivery drones. Recently with the FAA’s new ruling, starting early 2021, companies will be able to operate their drones around people and at night with some regulations.

If you can be the first company to make a viable drone delivery system, not only are you gonna have the fastest delivery, but your company is going to get the most press, the most word of mouth, the most hype. But perhaps most importantly, the first movers to get this tech working are going to have a massive head start to scoop up market share, and cement their throne at the top of the hill.

Amazon already has their Prime Air program where they’re promising small deliveries in 30 minutes or less via their new drone. UPS partnered with CVS and a hospital to target the healthcare industry and have the drone deploy from the top of their delivery trucks to deliver medicine. Alphabet has their own drone startup called Wing. Wing offers them a way to deliver small goods to their local customers exactly when they need it within 6 miles in 6 minutes. Valqari is offering a solution to the last step in the drone delivery process: where the drone is going to land and take off from, and how to secure the packages for the right person.

Electric airplanes haven’t taken off because of one simple limitation - battery capacity. Drones run into a similar problem but to a lesser degree. 

Now, the naysayers will always mock new ideas like these as “unrealistic” that “this could never happen” that “there are starving children in Africa and you greedy bastards want even faster delivery? Don’t we have a social responsibility to take care of the needy first?” Time will tell. 

-----------------------

L'Indécis, sadtoi - Les Mouvements d'Hiver https://chll.to/285a3974 
Sugi.wa - After Dark https://chll.to/40402d37 
Leavv - Aqueduct https://chll.to/b6aa49a2 

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in.

