# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Fixing Social Media for Good.
 - [https://www.youtube.com/watch?v=oOiCACmjKBM](https://www.youtube.com/watch?v=oOiCACmjKBM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-01-13 00:00:00+00:00

If you want to start your own Fediverse server:
Get a Domain name: https://www.epik.com/?affid=we2ro7sa6
Get a VPS to host it on: https://www.vultr.com/?ref=8384069-6G

Pleroma (Twitter equivalent) Instances:
List (slow-loading): https://the-federation.info/pleroma
https://neckbeard.xyz
https://kawen.space
https://shitposter.club
https://pleroma.soykaf.com
https://kiwifarms.cc
https://stereophonic.space
many, many more

Pleroma Site:
https://pleroma.social/
Install Pleroma on a server:
https://docs-develop.pleroma.social/backend/installation/otp_en/

PeerTube instances:
https://instances.joinpeertube.org/instances
PeerTube site:
https://joinpeertube.org/
Install PeerTube on your own server:
https://docs.joinpeertube.org/install-unofficial

Pixelfed (Instagram/Snapchat equivalent):
https://pixelfed.org/
Instances: https://beta.joinpixelfed.org/
Or install your own: https://docs.pixelfed.org/running-pixelfed/

WriteFreely (Blog software):
https://writefreely.org/

Friendica (Facebook equivalent):
http://friendi.ca/
Instances:
https://dir.friendica.social/servers

Mastodon (also Twitter-like):
https://joinmastodon.org/
Install: https://docs.joinmastodon.org/user/run-your-own/
Instances: https://instances.social/list#lang=&allowed=&prohibited=nudity_nocw,nudity_all,pornography_nocw,pornography_all&min-users=&max-users=


OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

