# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The Dark Truth about Fake Gurus - The Thing I Never Talk About...
 - [https://www.youtube.com/watch?v=U4nzvSsBKnk](https://www.youtube.com/watch?v=U4nzvSsBKnk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-14 00:00:00+00:00

Throwback Thursdays are about studying the psychology and history of fraudsters. Today we talk about one of the most uncomfortable truths about con-men. They're likable.
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## I Learned The "Death Touch" From The Guy Who Killed Bruce Lee
 - [https://www.youtube.com/watch?v=ISj6s5a7kM8](https://www.youtube.com/watch?v=ISj6s5a7kM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-13 00:00:00+00:00

SECRET DEATH TOUCHES ARE WILD
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

