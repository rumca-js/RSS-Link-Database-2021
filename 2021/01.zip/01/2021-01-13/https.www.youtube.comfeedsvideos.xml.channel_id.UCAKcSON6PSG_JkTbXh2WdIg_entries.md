# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Actual Wolf - three songs at The Current (2014; 2017)
 - [https://www.youtube.com/watch?v=DlS0ZCxrRNU](https://www.youtube.com/watch?v=DlS0ZCxrRNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-14 00:00:00+00:00

Watch three performances by Actual Wolf, aka Eric Pollard, recorded in The Current studio in 2014 and 2017.

SONGS PERFORMED
0:00 "Thinking of You" (2014)
3:13 "Victims and Things" (2014)
6:23 "Faded Days" (2017)

PERSONNEL
Eric Pollard – vocals, guitar
Steve Garrington – bass
Jake Hanson – guitar
Jeremy Hanson – drums (2014)
Erik Koskinen – guitar (2014)
Al Church – guitar, keys, backing vocals (2017)
Kyle Capistra – drums (2017)

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark; Riley Bruestle
Production: Derrick Stevens

FIND MORE:
2012 studio session: https://www.thecurrent.org/feature/2012/08/06/actualwolf-live
2013 set at the Minnesota State Fair:
https://www.thecurrent.org/feature/2013/08/29/acutal-wolf-mn-state-fair
2014 studio session: https://www.thecurrent.org/feature/2014/02/03/actual-wolf-live
2017 studio session:
https://www.thecurrent.org/feature/2017/09/19/actual-wolf-performs-in-the-currents-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#actualwolf

## Ryan Mach on 'Icehouse Live Series: Volume I'
 - [https://www.youtube.com/watch?v=5ERXrXdDkf0](https://www.youtube.com/watch?v=5ERXrXdDkf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-14 00:00:00+00:00

Ryan Mach, a musician and sound engineer, curated a new compilation of live recordings from the Minneapolis venue Icehouse. In these excerpts from his conversation with The Current's Jay Gabler, he talks about what makes Icehouse special, and what moments he looked for when selecting tracks for "Icehouse Live Series: Volume I."

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Howler - two songs at The Current (2012)
 - [https://www.youtube.com/watch?v=tNuG3uJI_Ew](https://www.youtube.com/watch?v=tNuG3uJI_Ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-13 00:00:00+00:00

Nine years ago this week, Minneapolis band Howler performed a session in our studio. Later that summer, they would play at Rock the Garden. Here's a look at two songs performed by Howler in our studio in January 2012.

SONGS PERFORMED
0:00 "Back of Your Neck"
3:23 "I Told You Once"

PERSONNEL
Jordan Gatesmith – vocals, guitar
Ian Nygaard – guitar 
Max Petrek – keys
France Camp – bass
Brent Mayes – drums

CREDITS
Video & Photo: Trent Waterman; Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2011 studio session:
https://www.thecurrent.org/feature/2011/07/06/howler
2012 studio session: https://www.thecurrent.org/feature/2012/01/12/howler-live
2014 studio session:
https://www.thecurrent.org/feature/2014/03/20/howler-perform-in-the-currents-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#howlerband

## Listen to Looch: 'Pretend It's a City'
 - [https://www.youtube.com/watch?v=VEdjtbV8Kt8](https://www.youtube.com/watch?v=VEdjtbV8Kt8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-13 00:00:00+00:00

Mary Lucia talks about a brand-new series from Netflix, directed by Martin Scorsese, that captures the observations and wit of New York City writer and humorist Fran Lebowitz.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#pretenditsacity #netflixseries #marylucia

