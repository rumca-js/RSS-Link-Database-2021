# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Trump impeached and banned! The end OR fuel to the flames?
 - [https://www.youtube.com/watch?v=WcryxrBpzNA](https://www.youtube.com/watch?v=WcryxrBpzNA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-14 00:00:00+00:00

Donald Trump has become the first president in US history to be impeached twice, and banned from all social media. What do these decisions tell us about the divisive nature of American politics currently, and about where true power lies? 

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

## Kim & Kanye – Celebrity in the age of despair
 - [https://www.youtube.com/watch?v=KyICc7gdN-A](https://www.youtube.com/watch?v=KyICc7gdN-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-13 00:00:00+00:00

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

In this video: 
Kim Kardashian and Kanye West are reportedly divorcing, but what is the function of celebrity in a pandemic and is our attitude towards it changing? 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

