# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## We interviewed the director of The Social Dilemma
 - [https://www.youtube.com/watch?v=jkpJzWy4mR0](https://www.youtube.com/watch?v=jkpJzWy4mR0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-01-11 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Jack and I sat down to interview our friend Jeff Orlowski about his documentary, “The Social Dilemma.”  thesocialdilemma.com

At the time, it felt relevant, but in the last week it’s become a more urgent topic of discussion - especially around how to regulate it and stop the spread of misinformation. More than anything, I hope this conversation will inspire YOU to have conversations with your friends about the role of social media in our lives.

01:33 - Background to the issue
06:46 - The dilemmas we are facing
12:59 - Who should regulate?
18:16 - Mental health consequences
23:49 - What can we do to change?

Edited by Nataly Dawn
Edit assisted by Athena Wheaton

