# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Abigail Shrier Interview: The Truth Behind Trans Children
 - [https://www.youtube.com/watch?v=_C6YTHGg0fA](https://www.youtube.com/watch?v=_C6YTHGg0fA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-12 00:00:00+00:00

This is the Babylon Bee Interview Show.

In this episode of The Babylon Bee Podcast, Kyle and Ethan talk to Abigail Shrier, a writer for the Wall Street Journal, The Federalist and author of new book Irreversible Damage. In the book she explores the “transgender craze,” where in the last few years, there has been an explosion in people identifying as transgender -- especially among biological females now identifying as male. The book was recently banned from Target -- though later reinstated -- after one transgender individual complained on Twitter. Topics include the Transgenderism craze, big tech, and making women a victim class.
 
Buy her book here: Irreversible Damage: The Transgender Craze Seducing Our Daughters

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Who Was Really Behind The Attack On The Capitol?
 - [https://www.youtube.com/watch?v=6glA2QJEozc](https://www.youtube.com/watch?v=6glA2QJEozc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-12 00:00:00+00:00

Who is really behind Proud Boy violence? AntiFa? What about Black Lives Matter? Is it secretly the cops? Or is it something even deeper?

See more The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation

## Abigail Shrier on The Babylon Bee Podcast | Preview
 - [https://www.youtube.com/watch?v=HTmLocSG0Eg](https://www.youtube.com/watch?v=HTmLocSG0Eg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-11 00:00:00+00:00

🎙 Tomorrow, author of “IRREVERSIBLE DAMAGE: The Transgender Craze Seducing Our Daughters”, Abigail Shrier joins Kyle and Ethan on The Babylon Bee podcast.

SUBSCRIBE TODAY! ▶️ http://bit.ly/TheBeeYouTube

## The Absolute Best Way to Propose to Your Christian Girlfriend
 - [https://www.youtube.com/watch?v=P5QHbQBsHyE](https://www.youtube.com/watch?v=P5QHbQBsHyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-11 00:00:00+00:00

The Babylon Bee made history by participating in its first wedding proposal hidden in a satire article! Kyle and Ethan were bribed by a Babylon Bee subscriber into writing an article about the 10 best ways to propose to your Christian girlfriend. It ends with a serious marriage proposal written in the most loving way. Watch to find out if she said yes!

See the full show here:
https://youtu.be/bqXUTUKZZqI

Subscribe to The Babylon Bee to help us make more happy marriages.

Hit the bell to get your daily dose of fake news that you can trust.

