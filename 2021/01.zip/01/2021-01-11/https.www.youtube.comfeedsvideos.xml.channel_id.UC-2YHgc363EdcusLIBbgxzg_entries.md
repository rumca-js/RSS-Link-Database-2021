# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Megaprojects: Terraforming The Sahara | Answers With Joe
 - [https://www.youtube.com/watch?v=2hmAeLYMrQg](https://www.youtube.com/watch?v=2hmAeLYMrQg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-01-11 00:00:00+00:00

The first 1000 people to use the link will get a free trial of Skillshare Premium Membership: https://skl.sh/joescott012111
A team of researchers have figured out how to turn the Sahara desert into lush, green farmland. It could save the world... But it is insane.

By the way, if you want to learn more and support the Africa Great Green Wall project, you go do so here: https://www.greatgreenwall.org

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:
https://www.greatgreenwall.org

Perseverance landing animation: https://youtu.be/rzmd7RouGrM 

https://en.wikipedia.org/wiki/Saharan_rock_art

https://www.travel-tour-guide.com/sahara-desert-trip/03-rock-art-and-petroglyphs.htm

https://www.world-archaeology.com/features/the-power-of-saharan-rock-art/

https://www.metmuseum.org/toah/hd/tass/hd_tass.htm

https://www.usgs.gov/faqs/what-carbon-sequestration?qt-news_science_products=0#qt-news_science_products

https://www.iea.org/articles/global-co2-emissions-in-2019

https://www.britannica.com/place/Sahara-desert-Africa

https://www.nationalgeographic.org/encyclopedia/africa-physical-geography/print/

https://www.britannica.com/place/Amazon-Rainforest

https://youtu.be/ZQP-7BPvvq0 - PBS Eons on Green Sahara

https://www.smithsonianmag.com/science-nature/great-green-wall-stop-desertification-not-so-much-180960171/

https://science.sciencemag.org/content/361/6406/1019
https://environment-review.yale.edu/green-energy-combats-climate-change-and-brings-life-desert
https://www.sciencedaily.com/releases/2018/09/180906141611.htm

