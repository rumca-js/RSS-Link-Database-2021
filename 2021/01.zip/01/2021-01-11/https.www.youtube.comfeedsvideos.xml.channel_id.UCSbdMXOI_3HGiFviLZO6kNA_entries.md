# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## CES 2021 brings INSANE new VR Technology
 - [https://www.youtube.com/watch?v=PIIXyfuxOcU](https://www.youtube.com/watch?v=PIIXyfuxOcU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-01-12 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. This is a special week as its the start of CES or the consumer electronic show that is being held digitally. I have attended most of the events and so far I have been extremely excited about many of the new technologies for VR that have been announced. New headsets, new headset technologies, haptip force feedback gloves and more. That and so much more this week, so I hope you enjoy!

My links-
2nd Channel:
https://youtu.be/Xp-p5RGoGpM
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Music-
Protostar -https://open.spotify.com/track/6kjl9utzXBGxYGP6FuBDPn?si=iK-OGnqMTkaJHw8XnwIPog

Sources-
https://www.roadtovr.com/pavlov-vr-tanks-ww2-update/
https://www.roadtovr.com/lenovo-thinkreality-a3-ar-smart-glasses/
https://www.roadtovr.com/difference-between-smartglasses-and-augmented-reality-glasses-why-everyone-is-confused/
https://www.roadtovr.com/creal-light-field-ar-vr-headset-prototype/#1610356990004-59843e40-72b1
https://www.roadtovr.com/mechanical-display-shifting-sde-reduction-facebook-reality-labs-research/
https://www.roadtovr.com/medal-of-honor-update-patch-1-19/
https://www.roadtovr.com/oculus-quest-2-monthly-active-users/
https://vrscout.com/news/defunctland-vr-disney-ride-back-to-life/
https://vrscout.com/news/defunctland-vr-disney-ride-back-to-life/
https://uploadvr.com/carmack-facebook-login/

