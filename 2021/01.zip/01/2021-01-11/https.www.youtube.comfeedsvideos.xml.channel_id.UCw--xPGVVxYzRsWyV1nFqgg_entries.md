# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Dragonlance LEAK📖 Malazan Sneak Peak🗡️ Deadpool in MCU🦸 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=p6MBnYkf83A](https://www.youtube.com/watch?v=p6MBnYkf83A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-12 00:00:00+00:00

Lets talk about the FANTASY NEWS!
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

00:00 intro
00:09 Shadow of the God Cover Reveal: https://www.youtube.com/watch?v=fpngiv-xG9s&feature=youtu.be&ab_channel=PetrikLeo 
02:04 Dresden Cover: https://t.co/bDRikyz9Hr
02:37 Dragonlance Leak: https://www.sageadvice.eu/2021/01/10/leaked-dragonlance-paperback-29-july-2021/ 
03:33 Stabby Winners: https://www.reddit.com/r/Fantasy/comments/krw2as/best_of_rfantasy_2020_the_stabby_awards_winners/?ref=share&ref_source=link 
04:30 Malazan Sneak Peak: https://www.torforgeblog.com/2021/01/09/excerpt-the-fiends-of-nightmaria-by-steven-erikson/
05:00 Off The Beaten Path: https://us02web.zoom.us/webinar/register/WN_tJLjnepeTO-h_HpzGhTh0A 
05:57 Free Horror Classics: https://bloody-disgusting.com/movie/3647422/universal-putting-classic-monster-movies-including-dracula-frankenstein-free-youtube-streaming/  
06:09 Earwig and the Witch: https://tinyurl.com/y692f8sw
07:06 Attack on Titan’s End: https://www.animenewsnetwork.com/news/2021-01-04/attack-on-titan-manga-ends-on-april-9-after-11-years/.168113 
07:26 Wanda Vision Prerelease Hype: https://www.comicbookmovie.com/tv/marvel/wandavision/wandavision-social-media-reactions-praise-marvel-studios-most-unique-exciting-project-to-date-a181472#gs.prsolt 
08:59 Super Nintendo World: https://super-nintendo-world.usj.co.jp/en/us/home 
10:06 Deadpool in MCU R Rated: https://comicbook.com/movies/news/deadpool-3-rated-4-mcu-confirmed-kevin-feige/

