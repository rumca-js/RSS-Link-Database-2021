## Władzę nad światem przejmuje Big Tech. Czy to już koniec wolności słowa?
 - [https://geekweek.interia.pl/styl-zycia/news-wladze-nad-swiatem-przejmuje-big-tech-czy-to-juz-koniec-woln,nId,5547055](https://geekweek.interia.pl/styl-zycia/news-wladze-nad-swiatem-przejmuje-big-tech-czy-to-juz-koniec-woln,nId,5547055)
 - RSS feed: https://geekweek.interia.pl
 - date published: 2021-01-11 13:17:34+00:00

Władzę nad światem przejmuje Big Tech. Czy to już koniec wolności słowa?

