# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Sharon Van Etten - three songs for The Current (2011; 2012; 2019)
 - [https://www.youtube.com/watch?v=89a1N6NEces](https://www.youtube.com/watch?v=89a1N6NEces)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-12 00:00:00+00:00

Two years ago, Sharon Van Etten's "Remind Me Tomorrow" was our Album of the Week. We've enjoyed a number of performances by Sharon Van Etten at The Current. Here are three, stretching back to 2011. 

SONGS PERFORMED
0:00 "Save Yourself" (2011)
4:18 "Give Out" (2012)
8:47 "Comeback Kid" (2019)

CREDITS
Video & Photo: Dan Huiting; Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens; David Safar

FIND MORE:
2011 studio session: https://www.thecurrent.org/feature/2011/04/06/sharon-van-etten-live
2012 studio session: https://www.thecurrent.org/feature/2012/02/19/sharonvanetten-live
2014 studio session:
https://www.thecurrent.org/feature/2014/07/18/sharon-van-etten-performs-live-in-the-current-studio
2019 MicroShow:
https://www.thecurrent.org/feature/2019/03/18/sharon-van-etten-performs-a-microshow-at-the-warming-house-in-minneapolis

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#sharonvanetten

