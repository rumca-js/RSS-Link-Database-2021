# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## What Happened to OnePlus?
 - [https://www.youtube.com/watch?v=9EOAEWC9hJ4](https://www.youtube.com/watch?v=9EOAEWC9hJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-01-12 00:00:00+00:00

It is possible to outgrow your original intentions.
OnePlus and enthusiast brands vs their inevitable change...
You either die a hero or live long enough to see yourself become the villain
TechAltar video: https://youtu.be/FJgTKx-rg18

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Slow Down, Start Over
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

