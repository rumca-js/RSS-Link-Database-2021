# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## METZ - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Gh8eadbpgJg](https://www.youtube.com/watch?v=Gh8eadbpgJg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-01-11 00:00:00+00:00

http://KEXP.ORG presents METZ performing a special live set recorded exclusively for KEXP.

Songs:
Blind Youth Industrial Park 
No Ceiling 
Hail Taxi
Framed By The Comets Tail 
A Boat To Drown In 

Recorded December 14, 2020, at Palace Sound Toronto, Canada. 
Recorded and Mixed by Graham Walsh
Filmed by Adam Seward
Edited by Alex Edkins

https://www.metzztem.com
http://kexp.org

