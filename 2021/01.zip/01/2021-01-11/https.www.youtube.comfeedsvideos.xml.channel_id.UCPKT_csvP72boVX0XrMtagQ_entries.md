# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## The story behind | Sébastien Léger live at the Great Pyramids of Giza, in Egypt for Cercle
 - [https://www.youtube.com/watch?v=VSjdEI2Q5p8](https://www.youtube.com/watch?v=VSjdEI2Q5p8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2021-01-11 00:00:00+00:00

The story behind Sébastien Léger's exclusive live set from the Great Pyramids of Giza, in Egypt for Cercle.

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ Cercle Records
Sébastien Léger - Giza
https://Cercle.lnk.to/Gizasebastienleger

The track is part of the limited edition vinyl compilation 0.0.2.0 | COTON. 
More info here: https://Cercle.lnk.to/vinyls

☞ Sébastien Léger
https://www.facebook.com/sebastienleger
https://www.instagram.com/sebastien_leger/
https://open.spotify.com/artist/17j0kFtqn9Fss3D916jSlp

☞ The Cercle show
https://youtu.be/SD6GDiyHmbE

29°58'33.8"N 31°07'39.6"E

Video credits:

Artists: Sébastien Léger
Venue: The Great Pyramids of Giza, Egypt
Produced by Cercle
Making of: Mickaël Fidjili 
Motion design: Jeremie Tridard

--
Special thanks to:
Bas Enab, Mahmoud Zidan & Misty Moustafa Sheta from Playground. 
Donal Mccarthy, Cian Toner & James Pidgeon from Sébastien Léger's management. 
Eric Caucheteur from Paris Webcube. 
Galerie Joseph.

Also, special thanks to Freedom Music. 

And finally, special thanks to Ahmed Youssef, chairman of Egypt's Tourism Promotion Authority from the Ministry of Tourism.  



______

This artistic performance has been recorded live. 

______

Follow us on http://www.cercle.io

