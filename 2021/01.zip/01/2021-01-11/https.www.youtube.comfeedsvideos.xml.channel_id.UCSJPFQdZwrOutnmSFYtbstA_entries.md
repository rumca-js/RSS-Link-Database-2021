# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Recommends... The Expanse
 - [https://www.youtube.com/watch?v=RWtbI4t7cOc](https://www.youtube.com/watch?v=RWtbI4t7cOc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-01-12 00:00:00+00:00

It turns out The Expanse is absolutely fantastic, so what else can I do except give it a Drinker Recommends?

