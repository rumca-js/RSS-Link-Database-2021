# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Amazon's Lord of the Rings Synopsis Breakdown | #LOTRonPrime Livestream
 - [https://www.youtube.com/watch?v=aY7Bl2A-Bzg](https://www.youtube.com/watch?v=aY7Bl2A-Bzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-01-12 00:00:00+00:00

We have our first development in a LONG time regarding #LOTRonPrime!  In this short-notice stream, we'll breakdown some of the clues in the synopsis and make some educated guesses on what we will see in the show!

Amazon Studios’ forthcoming series brings to screens for the very first time the heroic legends of the fabled Second Age of Middle-earth’s history. This epic drama is set thousands of years before the events of J.R.R. Tolkien’s The Hobbit and The Lord of the Rings, and will take viewers back to an era in which great powers were forged, kingdoms rose to glory and fell to ruin, unlikely heroes were tested, hope hung by the finest of threads, and the greatest villain that ever flowed from Tolkien’s pen threatened to cover all the world in darkness. Beginning in a time of relative peace, the series follows an ensemble cast of characters, both familiar and new, as they confront the long-feared re-emergence of evil to Middle-earth. From the darkest depths of the Misty Mountains, to the majestic forests of the elf-capital of Lindon, to the breathtaking island kingdom of Númenor, to the furthest reaches of the map, these kingdoms and characters will carve out legacies that live on long after they are gone.

#LOTRonPrime #LOTR #Tolkien

