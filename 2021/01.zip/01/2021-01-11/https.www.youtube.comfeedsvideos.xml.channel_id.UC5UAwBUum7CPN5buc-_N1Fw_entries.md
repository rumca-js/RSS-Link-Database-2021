# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Get 10% MORE FPS in Linux games with GAMEMODE!
 - [https://www.youtube.com/watch?v=sZb1v4EM-2U](https://www.youtube.com/watch?v=sZb1v4EM-2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2021-01-11 00:00:00+00:00

Visit http://linode.com/linuxexperiment for a 100$ credit on your new Linode account!

Linux gaming has really become a thing in the recent years. 80% of the reported games on ProtonDB are marked as working on Linux, thanks to Proton, wine, and a host of other libraries like DXVK. Even with all of that progress, there can still be a performance gap between Windows and Linux on some games. Fortunately, there is a way to reduce that gap, and that's Gamemode.

Join this channel to get access to a monthly patroncast and vote on the next topics I'll cover:
https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Support the channel on Patreon: 
https://www.patreon.com/thelinuxexperiment

Follow me on Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

Follow me on LBRY: https://lbry.tv/@TheLinuxExperiment:e

The Linux Experiment merch: get your goodies there! https://teespring.com/en-GB/stores/the-linux-experiment


00:00 Intro
01:41 What is Gamemode
02:52 Benchmarks
06:25 Install Gamemode
07:21 Use Gamemode

Gamemode is a little program, developed by Feral Interactive, which you might know as the company that tends to port games to Linux, such as Total War Warhammer 2, or the Tomb Raider games.

What it does is try to optimize your system to give as much performance to the game you're running, and return to normal once the game is closed. It can do quite a bit, including giving more CPU priority to the game, more disk priority, inhibiting the screensaver while the game is running,  using the GPU performance modes for AMD and Nvidia, when available, and even using overclocking on NVidia GPUs if it can.

Gamemode has been around for a while now, but it's still something that is rarely included by default, and needs to be installed separately.

The end result of running a game with Gamemode? You'll get more out of your hardware, and get better performance. The improvements will vary from game to game, but in general, the more a game is taxing for your hardware, the more gamemode will make a difference. 

Gamemode doesn't come preinstalled on many distros, but it's pretty easy to install anyways. Gamemode is available in the repos for Ubuntu, Debian, Solus, Arch, Gentoo, Fedora, OpenSUSE, Mageia, so you can just install it through your regular package manager, for example a quick
"sudo apt install gamemode" on Ubuntu.

If Gamemode isn't available on your distro of choice? If you're on an older version of Ubuntu, like 18.04 LTS, there is a PPA, you'll find the command to add it here:

sudo add-apt-repository ppa:samoilov-lex/gamemode

If that doesn't suit your needs, you can always compile Gamemode from source, you can find the instructions in the github page of the project, I'll leave a link to it in the description.

Once you've got gamemode installed, how do you make sure your games are actually using it? Let's see.

## Use Gamemode on Steam
On steam, it's super simple. Whether your game is running natively, or through proton, all you have to do is add a little launch option. Just righ click your game's name in your library, select "Properties", and in the window that appears, you'll find a "launch options" line.

In there, enter gamemoderun %command%

That's it. You can close the little window, and run your game as usual. If you were already using other command lines, you can just add that one at the end, and it will work fine.

## Use Gamemode on lutris

If your game isn't on Steam, but you're using Lutris, it's even easier. On Lutris, you get the option to enable gamemode with a single switch, if it's installed.

Just right click your game in Lutris's main window, select "Configure", and go to the last tab.
Here, you'll find a "Enable Feral Gamemode" option. Turn it on if that's not the case, and you're good to go.

You can also auto enable it for all games, just by going to the Lutris settings, in the "System option" tab, and enabling Gamemode there. All games will now make use of it.

If you're playing games on another platform, you should have a menu item to run them, in your distribution's menu. You'll have to edit that menu entry using any program of your choice. I use appEdit on elementary OS, but there are others for other distros.

In that menu entry, you'll need to add "gamemoderun" before the actual command line that starts the game. For example, if you have something like /usr/share/supertuxcart, just type gamemoderun before all of that.

I'd still advise you add these games to Lutris if at all possible, it makes it a lot easier to handle all of that.

If you're unsure if gamemode is correctly starting, open a terminal, and type gamemoded -s.
It will tell you if gamemode is active or not.

And that's about it. Since it's so easy to install and use, there is no real reason not to use it, and get a nice 5 to 10% boost in terms of FPS in all your games.

