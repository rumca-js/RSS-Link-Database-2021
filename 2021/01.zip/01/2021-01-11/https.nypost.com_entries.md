## Biden receives second dose of COVID-19 vaccine
 - [https://nypost.com/2021/01/11/biden-receives-second-dose-of-covid-19-vaccine/](https://nypost.com/2021/01/11/biden-receives-second-dose-of-covid-19-vaccine/)
 - RSS feed: https://nypost.com
 - date published: 2021-01-11 20:52:16+00:00

Biden receives second dose of COVID-19 vaccine

