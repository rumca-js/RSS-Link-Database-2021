# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How Filmmaker Bryan Fogel Uncovered Russia's Doping Program
 - [https://www.youtube.com/watch?v=bv-vUPxXDA8](https://www.youtube.com/watch?v=bv-vUPxXDA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1592 with Bryan Fogel. https://open.spotify.com/episode/15p3DpjZeaXCwcXyGTytMj?si=fKvvPb9aTSu6iGWWVImbyg

## Icarus Filmmaker Bryan Fogel Gives Update on Whistleblower Grigory Rodchenkov
 - [https://www.youtube.com/watch?v=b9dX7jduFrQ](https://www.youtube.com/watch?v=b9dX7jduFrQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1592 with Bryan Fogel. https://open.spotify.com/episode/15p3DpjZeaXCwcXyGTytMj?si=fKvvPb9aTSu6iGWWVImbyg

## The Mystery Behind the Death of Jamal Khashoggi
 - [https://www.youtube.com/watch?v=m5thgQeXCLo](https://www.youtube.com/watch?v=m5thgQeXCLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1592 with Bryan Fogel. https://open.spotify.com/episode/15p3DpjZeaXCwcXyGTytMj?si=fKvvPb9aTSu6iGWWVImbyg

