# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## My 10 Anticipated Movies of 2021
 - [https://www.youtube.com/watch?v=hiARFFG0rz0](https://www.youtube.com/watch?v=hiARFFG0rz0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-01-11 00:00:00+00:00

With a new year, we get to look at the movies rolling out in the course of 2021. Here is a look at 10 movies that caught my eye.

#AnticipatedMovies2021

