# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Big Tech Cleans House! - Everything We Want You To Think
 - [https://www.youtube.com/watch?v=mZGayFkjku8](https://www.youtube.com/watch?v=mZGayFkjku8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-01-12 00:00:00+00:00

Get your Cacao Bliss Here - https://earthechofoods.com/jpsears
Discount code for 15% off  - JP 

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Are you interested in becoming a sponsor with your product or service? Are you also aligned with our mission of freedom from fear? If so, please email me at: sponsorship@awakenwithjp.com

Big tech cleans house! Here’s everything we want you to think. Twitter and Facebook permanently banned Trump. Apple, Google, and Amazon, team up to take down Parler. Freedom of speech has never been better protected, because the assault on it has never been more intense.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

