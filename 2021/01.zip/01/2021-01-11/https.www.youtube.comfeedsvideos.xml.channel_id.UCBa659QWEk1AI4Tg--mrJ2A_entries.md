# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Australia's Bushfire-Hunting Satellites
 - [https://www.youtube.com/watch?v=99_Abbuf3cQ](https://www.youtube.com/watch?v=99_Abbuf3cQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-01-11 00:00:00+00:00

Check out Atomic Frontier! https://youtube.com/atomicfrontier - start with the video on a country-sized telescope https://www.youtube.com/watch?v=sZVcWJ0pFTc or the world's deepest scuba dive https://www.youtube.com/watch?v=s65T7ZHZp14 • Turns out that trying to precisely detect fire from space is more difficult than "point a camera at it".

