# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best Open World Games of 2020
 - [https://www.youtube.com/watch?v=PaJ4_Xu_jAc](https://www.youtube.com/watch?v=PaJ4_Xu_jAc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-12 00:00:00+00:00

2020 saws tons of games featuring explorable open worlds of all different sizes. Here are some of the most popular.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Mafia: Definitive Edition

Platform: PC PS4 Xbox One 

Release Date: September 25, 2020



#9 Mount and Blade 2: Bannerlord

Platform: PC

Release Date : March 30, 2020



#8 Yakuza: Like a Dragon

Platform: PC Xbox One XSX November 10, 2020

Release Date : PS4 November 10, 2020



#7 Immortals Fenyx Rising

Platform: PC PS4 PS5 Xbox One XSX Switch Stadia Amazon Luna

Release Date : December 3, 2020



#6 Watch Dogs Legion

Platform: PC PS4 Xbox One Stadia 29 October 2020

Release Date : XSX  Amazon Luna 10 November 2020

PS5 12 November 2020



#5 Ghost of Tsushima

Platform: PS4

Release Date : July 17, 2020



#4 Cyberpunk 2077

Platform: PC PS4 Xbox One Stadia 

Release Date : 10 December 2020



#3 Spider-Man: Miles Morales

Platform: PS4, PS5

Release Date : November 12, 2020



#2 Assassin's Creed Valhalla

Platform: PC PS4 Xbox One XSX Stadia November 10, 2020

Release Date : PS5 November 12, 2020



#1 Microsoft Flight Simulator

Platform: PC 

Release Date : August 18, 2020





BONUS



Dragon Ballz Kakarot

Platform: PC PS4 Xbox One

Release Date : January 17, 2020 



No man's sky Origins

Platform: PC PS4 Xbox One

Release Date : September 23, 2020



Need for Speed™ Hot Pursuit Remastered

Platform: PC PS4 Xbox One 6 November 2020

Release Date : Switch 13 November 2020



Crysis Remastered

Platform: Switch July 23, 2020

Release Date : PC PS4 Xbox One September 18, 2020



Cloudpunk

Platform: PC April 23, 2020

Release Date : Switch PS4 Xbox One October 15, 2020

## Bethesda's Indiana Jones Game: 5 Things WE WANT
 - [https://www.youtube.com/watch?v=HzbNTIf8Cck](https://www.youtube.com/watch?v=HzbNTIf8Cck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-12 00:00:00+00:00

Indiana Jones is returning to the video game scene thanks to Bethesda, Todd Howard, and the developers behind Wolfenstein. It's still years away, but here's what we'd like to see.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

