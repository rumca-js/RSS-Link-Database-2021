# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Who owns fresh air? Why we can't just go outside
 - [https://www.youtube.com/watch?v=J2qYIkkWETA](https://www.youtube.com/watch?v=J2qYIkkWETA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-12 00:00:00+00:00

This week’s guest is Nick Hayes! Nick is an author, illustrator, print-maker and political cartoonist. His latest book is The Book of Trespass: Crossing the Lines That Divide Us.

You can listen to the rest of his podcast over on Luminary:
http://luminary.link/russell

Join the campaign to open more of England's countryside to public access: www.righttoroam.org.uk

Follow Nick on Instagram @nickhayesillustration & Twitter @nickhayesillus1

Support independent bookshops, by purchasing The Book of Trespass from here: https://labiblioteka.co/item/the-book-of-trespass

http://lawyersfornature.com/

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

