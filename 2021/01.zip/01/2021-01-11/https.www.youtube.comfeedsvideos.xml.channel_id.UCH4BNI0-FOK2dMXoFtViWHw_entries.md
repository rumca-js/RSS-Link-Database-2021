# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Why Do We Lie?
 - [https://www.youtube.com/watch?v=BvLf63krM2g](https://www.youtube.com/watch?v=BvLf63krM2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-01-11 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

Everyone lies. Even you and even me. We lie about small things and we lie about big things. We lie to help ourselves and we lie to protect others. Powerful people lie, all the way down to little kids telling fibs. Why do we do this if we’re supposed to be the most socially developed species on Earth? Why can’t we tell the truth? Are we doomed to lie? Well, maybe. Here’s why.

References: https://sites.google.com/view/whydowelie-references/home

-----------

Special thanks to our Brain Trust Patrons:

Ahmed Elkhanany
Zenimal
Salih Arslan
Baerbel Winkler
Denzel Holmes
Robert Young
Amy Sowada
Benjamin Teinby
Eric Meer
Jay Stephens
Peter Ehrnstrom
Dustin
Marcus Tuepker
Karen Haskell
AlecZero 
Diego Lombeida

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

