## Parler app has now been booted by Amazon, Apple and Google | CNN Business
 - [https://edition.cnn.com/2021/01/09/tech/parler-suspended-apple-app-store/index.html](https://edition.cnn.com/2021/01/09/tech/parler-suspended-apple-app-store/index.html)
 - RSS feed: https://edition.cnn.com
 - date published: 2021-01-11 15:10:39+00:00

Parler app has now been booted by Amazon, Apple and Google | CNN Business

