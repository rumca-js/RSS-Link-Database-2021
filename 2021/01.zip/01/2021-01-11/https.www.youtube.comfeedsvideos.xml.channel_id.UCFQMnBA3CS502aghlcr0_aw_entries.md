# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Real Detective Reacts To Sherlock
 - [https://www.youtube.com/watch?v=RC2r57GE_Sg](https://www.youtube.com/watch?v=RC2r57GE_Sg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-12 00:00:00+00:00

I'm responding to Sherlock and the crazy expectations they've been putting out for the rest of us real detectives. We're tired of the horsesh*t expectations that clients come to us with! I know Sherlock Holmes is a favorite for many (including myself), but it's time you know the truth. 

Follow me!
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## The Marketing GENIUS of Flex Tape
 - [https://www.youtube.com/watch?v=FiDsDNsfrXY](https://www.youtube.com/watch?v=FiDsDNsfrXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-11 00:00:00+00:00

I SAWED THIS BOAT IN HALF! Phil Swift is an icon of the internet, but it wasn't on accident. The man has improved on the great pitchmen before him, like Billy Mays and gone bigger with his stunts and antics. 

Follow me
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/

Video Editor: Jon “Oppai Senpai” Tesoriero - https://twitter.com/MrOppaiSenpai

this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

