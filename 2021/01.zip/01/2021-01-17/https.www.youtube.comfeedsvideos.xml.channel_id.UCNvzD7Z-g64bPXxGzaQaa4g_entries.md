# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Horror Games of 2021
 - [https://www.youtube.com/watch?v=4tbA-l_tfY8](https://www.youtube.com/watch?v=4tbA-l_tfY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-18 00:00:00+00:00

2021 will bring us tons of new horror games of PC, PS5, Series X, Xbox One, Nintendo Switch, and more. From goofy to serious to sci fi, here are the horror games we're looking forward to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Returnal

Platform: PS5

Release Date: March 19, 2021 



#9 The Medium

Platform: PC XSX/S

Release Date: January 28, 2021



#8 Sons of the Forest

Platform: TBA

Release Date: TBA



#7 System Shock Remake

Platform: PC PS4 Xbox One

Release Date: TBA



#6 Scorn

Platform: PC XSX/S

Release Date: 2021



#5 Unholy

Platform: PC

Release Date: 2021



#4 GhostWire: Tokyo

Platform: PC PS5

Release Date: October 2021



#3 Little Nightmares 2

Platform: PC PS4 PS5 Xbox One XSX Switch

Release Date: February 11, 2021



#2 The Outlast Trials

Platform: TBA

Release Date: 2021



#1 Resident Evil Village

Platform: PC PS5 XSX

Release Date:  2021 



Bonus:-

Evil Dead: The Game

Platform: PS5 PS4 Xbox One XSX/S Switch

Release Date:  TBA 2021



The Dark Pictures Anthology: House of Ashes

Platform: PC PS4 PS5 Xbox One XSX/S

Release Date:  TBA 2021


Vampire: The Masquerade – Bloodlines 2

Platform: PC PS4 PS5 Xbox One XSX/S

Release Date:  TBA 2021


Back 4 Blood

Platform: PC PS4 PS5 Xbox One XSX/S

Release Date:  June 22, 2021

## Top 20 NEW MMORPGs of 2021
 - [https://www.youtube.com/watch?v=cKX1kLlTZhY](https://www.youtube.com/watch?v=cKX1kLlTZhY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-17 00:00:00+00:00

MMORPGs are still going strong. Here's some cool worlds and game upgrades to look forward to in 2021 for PC, PS5, PS4, Xbox, mobile, and more.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#20 Odin Valhalla Rising

Platform: PC, iOS, Android

Release Date: 2021


#19 Final Fantasy 11 New Expansions

Platform: PC

Release Date: TBA 2021





#18 Phantasy Star Online 2: New Genesis

Platform: Xbox Series X|S, PC, Xbox One

Release Date: 2021


#17 Project TL

Platform: PC, iOS, Android

Release Date:  TBA





#16 Ember sword

Platform: PC

Release Date: 2021


#15 Corepunk

Platform: PC

Release Date: TBA 2021





#14 Mad World

Platform: PC

Release Date: TBA 2021


#13 Project BBQ

Platform: PC

Release Date: TBA 2021





#12 Ashes of Creation

Platform: PC

Release Date: TBA


#11 Blue Protocol

Platform: PC

Release Date: TBA


#10 Chrono Odyssey

Platform: PC, PS5, XSX/S, iOS, Android

Release Date: TBA 2021


#9 Wild Terra 2: New Lands

Platform: PC

Release Date: 28 January, 2021


#8 Crowfall

Platform: PC

Release Date: TBA


#7 Elyon

Platform: PC

Release Date: TBA


#6 Lost Ark

Platform: PC

Release Date: TBA


#5 Magic Legends

Platform: PC, PS4, Xbox One

Release Date: Q2 2021


#4 Hytale 

Platform: PC, macOS

Release Date: 2021 


#3 Pantheon: Rise of the Fallen

Platform: PC

Release Date: TBA 2021


#2 Crimson Desert

Platform: PC, PS5 XSX/S

Release Date: Q4 2021


#1 New World 

Platform: PC 

Release Date: Early 2021

