# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Avi Loeb on How the Scientific Community Isn't Open Minded
 - [https://www.youtube.com/watch?v=HbJpP_6pOww](https://www.youtube.com/watch?v=HbJpP_6pOww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-18 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1596 with Avi Loeb. https://open.spotify.com/episode/0y7Vfzeua0TyLSAq3CUktH?si=tL50RjRATGqoBkxY42MmFQ

## Conflict Might Be Preventing the Discovery of Alien Life
 - [https://www.youtube.com/watch?v=Fafk-6i37jI](https://www.youtube.com/watch?v=Fafk-6i37jI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-18 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1596 with Avi Loeb. https://open.spotify.com/episode/0y7Vfzeua0TyLSAq3CUktH?si=tL50RjRATGqoBkxY42MmFQ

## Scientist Thinks Mysterious Interstellar Object is Extraterrestrial
 - [https://www.youtube.com/watch?v=G5gJBZ-3OlY](https://www.youtube.com/watch?v=G5gJBZ-3OlY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-18 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1596 with Avi Loeb. https://open.spotify.com/episode/0y7Vfzeua0TyLSAq3CUktH?si=tL50RjRATGqoBkxY42MmFQ

