# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Confessions of the #1 Bitconnect Promoter - Trevon James
 - [https://www.youtube.com/watch?v=uIcE5cfFA_4](https://www.youtube.com/watch?v=uIcE5cfFA_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-17 00:00:00+00:00

Trevon James is a crypto Youtuber most (in)famous for his promotion of Bitconnect, a now defunct ponzi scheme. In this interview we talk about his story, changes, other crypto Youtubers and his promotion in Hex. 
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.
0:00 INTRO
0:18 WARNING
2:54 INTERVIEW STARTS
6:24 Trevon's Introduction to Crypto
11:15 is Bitconnect a Ponzi Scheme?
24:27 The Reason Trevon Came On the Show
35:11 why is everyone so hard on me?
38:00 FBI / SEC Story
45:12 Confronting Trevon on HEX Promotion
1:03:21 Trevon's Warning

