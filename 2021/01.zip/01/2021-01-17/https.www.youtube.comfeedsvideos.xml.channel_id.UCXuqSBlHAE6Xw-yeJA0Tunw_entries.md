# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Dennis WASTED His Money - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=2X-ZayiWAKo](https://www.youtube.com/watch?v=2X-ZayiWAKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-18 00:00:00+00:00

Thanks again to Intel for continuing to sponsor this series! Buy an Intel Core i7-10700 CPU
On Amazon (PAID LINK): https://geni.us/xs3pY
On Best Buy (PAID LINK): https://geni.us/YW6aO9w
On Newegg (PAID LINK): https://geni.us/ZwxC

Grab a LIMITED EDITION Live Laugh Liao shirt: http://lttstore.com/products/liao

We're back with another Intel Extreme Home Upgrade where one lucky LMG'er gets $5,000 of Intel's money to do whatever they want. And what Dennis wants...is pretty weird. 

Buy Autonomous SmartDesk 2 & use code LINUSTECHTIPS to get 8% off at https://bit.ly/3aAP485

Buy MSI MPG Z490M Gaming Edge WiFi
On Amazon (PAID LINK): https://geni.us/qsNK90
On Best Buy (PAID LINK): https://geni.us/ijxAxa
On Newegg (PAID LINK): https://geni.us/ohRQ

Buy TEAMGROUP T-Force Delta RGB DDR4 32GB RAM - White
On Amazon (PAID LINK): https://geni.us/9gEW
On Newegg (PAID LINK): https://geni.us/wYjQ9

Buy Sabrent Rocket Q 1TB NVMe SSD
On Amazon (PAID LINK): https://geni.us/ToSu
On B&H (PAID LINK): https://geni.us/JSRSU
On Newegg (PAID LINK): https://geni.us/FWds1

Buy Gigabyte RTX 3080 VISION OC - White
On Best Buy (PAID LINK): https://geni.us/ISfCJsP
On Newegg (PAID LINK): https://geni.us/sDf5R

Buy Lian Li PC-O11 Dynamic - White
On B&H (PAID LINK): https://geni.us/T7eVtw
On Newegg (PAID LINK): https://geni.us/6dBUa1

Buy Corsair RM850x PSU - White
On Amazon (PAID LINK): https://geni.us/syuUAA
On Newegg (PAID LINK): https://geni.us/kLI0A
On Best Buy (PAID LINK): https://geni.us/XAZzbh

Buy Kanto YU2 Speakers
On Kanto: https://geni.us/2w0kdgB
On Amazon (PAID LINK): https://geni.us/yl5IHP

Buy DeepCool GAMMAXX 400 - White
On Amazon (PAID LINK): https://geni.us/Mu0zSki
On Newegg (PAID LINK): https://geni.us/V30x0K2

Buy upHere 120mm ARGB Case Fan - White
On Amazon (PAID LINK): https://geni.us/g9wkC

Buy ASUS ProArt Display PA278QV
On Amazon (PAID LINK): https://geni.us/EZomnz
On Best Buy (PAID LINK): https://geni.us/kBYf
On Newegg (PAID LINK): https://geni.us/bu9u

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1295437-dennis-wasted-his-money-intel-5000-extreme-tech-upgrade/

Intro by https://www.instagram.com/mbarek_abdel/?hl=en

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## This is FINALLY Possible! - Triple 4K high refresh gaming (LG Ultragear 27GN950-B)
 - [https://www.youtube.com/watch?v=7kSQTJJN0Uo](https://www.youtube.com/watch?v=7kSQTJJN0Uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-17 00:00:00+00:00

Thanks to LG for sponsoring this video! Check out the LG Ultragear 4K Gaming Monitor at https://bit.ly/2LREAqD

LG's Ultragear 27GN950-B gaming monitor has ultra-fast refresh rates for an almost lag-free gaming experience, color accuracy with its IPS panel, and of course, amazing details with its 4K resolution. So we set up a killer gaming station with THREE of them. Check out other LG gaming monitors here: https://bit.ly/2LCG5cb.

Buy AMD Ryzen 9 5900X CPU (PAID LINK): https://geni.us/YYc2

Buy ASUS ROG Strix OC RTX 3090 (PAID LINK): https://geni.us/fsdgUn

Buy G.Skill Trident Z Neo 32GB RAM (PAID LINK): https://geni.us/oKCqc

Buy ASUS Prime X570-Pro (PAID LINK): https://geni.us/6lBe

Buy Lian Li O11 Dynamic Mini Case (PAID LINK): https://geni.us/xALue4

Buy Noctua NH-D15S chromax.Black CPU Cooler (PAID LINK): https://geni.us/Rg2z

Buy Silverstone SX800 PSU (PAID LINK): https://geni.us/vv6JJ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1295045-this-is-finally-possible/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

