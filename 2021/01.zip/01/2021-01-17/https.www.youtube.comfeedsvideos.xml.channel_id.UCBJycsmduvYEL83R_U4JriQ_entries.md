# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Huge Apple 2021 Rumor Reactions!
 - [https://www.youtube.com/watch?v=1l0aosZHSDA](https://www.youtube.com/watch?v=1l0aosZHSDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-01-17 00:00:00+00:00

Folding iPhones? The Return of Magsafe? Mac Pros with Apple Silicon? There's a lot to unpack!

Mark Gurman:
https://www.bloomberg.com/news/articles/2021-01-15/apple-macbook-pros-with-magsafe-return-in-the-works
https://www.bloomberg.com/news/articles/2021-01-15/apple-plans-redesigned-imac-new-mac-pro-smaller-mac-pro-cheaper-monitor?sref=9hGJlFio
https://www.bloomberg.com/news/articles/2021-01-15/apple-considers-foldable-iphone-minor-changes-planned-for-2021-models

Matte black aluminum MacBooks: https://www.macrumors.com/2020/12/04/apple-researching-matte-black-finish/

On the Portless iPhone 13: https://youtu.be/Qfmeb2e_kb4

0:00 Intro
1:14 14/16" MacBook Pro
2:24 MiniLED
3:36 MagSafe's Return
4:42 RIP Touchbar
5:57 iMac Redesign
7:42 New (Smaller) Mac Pro
9:02 A new Desktop Display
10:20 Minor iPhone upgrades
11:37 A Foldable iPhone
12:23 Extra Bits

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/Alltta
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

