# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## What's Happening (And Not Happening) With Hyperloop | Answers With Joe
 - [https://www.youtube.com/watch?v=23n94m96flc](https://www.youtube.com/watch?v=23n94m96flc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-01-18 00:00:00+00:00

Get 15% off of Raycon earbuds when you go to http://www.buyraycon.com/joescott
People have been talking about Hyperloop for years now, but what's actually happening with this proposed 5th form of transportation? Turns out there's a lot. And... not much. I'll explain.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:
http://www.trainhistory.net/railway-history/atmospheric-railway/

https://www.energy.gov/articles/how-maglev-works

https://hyperloopconnected.org/2019/07/hyperloop-propulsion-methods/

Hyperloop Transportation Technologies: https://www.hyperlooptt.com/

https://cheddar.com/media/hyperloop-feasibility-study-reveals-model-is-profitable-makes-economic-sense

Transpod: https://www.transpod.com/fullscreen/company/

Hardt: https://hardt.global/

Zeleros: https://zeleros.com/

https://intheloop.news/first-european-hyperloop-collaboration/

