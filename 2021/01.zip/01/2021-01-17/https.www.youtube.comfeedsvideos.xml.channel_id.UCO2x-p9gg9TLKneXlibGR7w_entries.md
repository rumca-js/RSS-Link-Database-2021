# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Apple is making a car and it might be... GOOD?!
 - [https://www.youtube.com/watch?v=NptFzmFs01M](https://www.youtube.com/watch?v=NptFzmFs01M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2021-01-17 00:00:00+00:00

It’s happening. Apple is making a car. The question is: what kind of car? And in what market would it actually make sense? Today, Snazzy Labs talks about auto manufacturing, software, autonomy, and more. It’s not as simple as it seems to just “make a car.”

Check out my Waymo video from last year - https://youtu.be/G25YWnl7cn8
Check out my most recent Tesla Autopilot update video - https://youtu.be/JFpGWJspy9o
Check out my Tesla Model 3 review - https://youtu.be/ErE-UnQO-DE

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

WIRED Tesla Model S Factory Tour - https://www.youtube.com/watch?v=8_lfxPI5ObM
YOUCAR Hyundai Factory Tour - https://www.youtube.com/watch?v=8gxq42yDCYs

Apple is making a car. Or partnering with another automaker that can make a car for them. Or maybe they’re just selling software? Autonomous software or just infotainment? Oh, boy, it gets complicated. Today, we talk about Project Titan and the latest leaks that Hyundai and Apple are working together to make an Apple Car or iCar. What will this vehicle entail? When will it come to market? And what can Apple bring that traditional automakers really neat? Let’s chat.

