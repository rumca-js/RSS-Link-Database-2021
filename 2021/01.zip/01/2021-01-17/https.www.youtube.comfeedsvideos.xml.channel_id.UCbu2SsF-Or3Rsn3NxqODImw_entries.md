# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## The Cyberpunk And Witcher Quirk That You Probably Missed
 - [https://www.youtube.com/watch?v=8bdqgEXbf4o](https://www.youtube.com/watch?v=8bdqgEXbf4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-18 00:00:00+00:00

How would you describe the dialogue in Cyberpunk 2077? You might say that it sounds mostly natural... unless you noticed a particular quirk with the way nearly every character speaks. As it turns out, most characters in Cyberpunk 2077 chop off the subject at the beginning of their sentences, something they have in common with CD Projekt Red's own Geralt of Rivia in The Witcher 3. 

In this video, Jake Dekker breaks down the possible reason why CDPR's characters talk this way. Both Cyberpunk 2077 and The Witcher 3 were written in Polish and translated into English, and in Polish, it's actually very common to drop the subject of a sentence because they're often unnecessary. There's a brief but (hopefully) simple explanation of how this works if you don't speak any languages that do this, so buckle up and be ready to learn. 

If you didn't notice this before, you probably won't be able to un-hear it after this video. Let us know in the comments if you noticed this about Cyberpunk 2077 and what you think of this dialogue style.

## 21 Games With Huge Anniversaries In 2021
 - [https://www.youtube.com/watch?v=7tvEFXsvqYQ](https://www.youtube.com/watch?v=7tvEFXsvqYQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-17 00:00:00+00:00

2021 marks the anniversary of a few of our favorite games and series'. Join Persia as she takes a look at 21 of the biggest anniversaries of 2021 spanning the course of 40 years. 

Game List:

Marvel Vs Capcom 3
Arkham City
Skyrim
Dark Souls
Gears Of War
Kingdom Hearts II
Dead Rising
Halo
Devil May Cry
Super Smash Bros Melee
Resident Evil
Crash Bandicoot
Tomb Raider
Quake
Sonic The Hedgehog
Street Fighter II
Pokemon Red and Blue
The Legend Of Zelda
Metroid
Donkey Kong
Frogger

