# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Requiem For A Dream - Movie Review
 - [https://www.youtube.com/watch?v=eJf8-g26pFc](https://www.youtube.com/watch?v=eJf8-g26pFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-01-18 00:00:00+00:00

See the sale and save on your favorite classic Star Wars games here: https://bit.ly/2XAGxKH
Thanks Aspyr Media for sponsoring!

OK! Here's a video I've wanted to make for awhile....Let's review REQUIEM FOR A DREAM!

#RequiemForADream

