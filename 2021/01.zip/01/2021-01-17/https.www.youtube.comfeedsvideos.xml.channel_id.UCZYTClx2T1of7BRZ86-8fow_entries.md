# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Here's What Kevlar and Your Smartphone Have in Common
 - [https://www.youtube.com/watch?v=BC60BA8OZLA](https://www.youtube.com/watch?v=BC60BA8OZLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-01-18 00:00:00+00:00

You might not believe it, but the same chemistry that brought us bulletproof vests and modern sailing sails also gave us the technology to build your smart phone. But that doesn’t mean these chemists were thinking about these applications when they made their breakthroughs.



Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.nauticexpo.com/boat-manufacturer/kevlar-sail-36624.html
https://midbellmusic.com/products/remo-ks061400-14-black-max-kevlar-snare-drum-head
https://www.ncjrs.gov/App/Publications/abstract.aspx?ID=76896 
https://invention.si.edu/innovative-lives-stephanie-kwolek-and-kevlar-wonder-fiber
https://invention.si.edu/node/445/p/435-discovery
https://polymerdatabase.com/Fibers/Aramid.html
https://www.sciencedirect.com/topics/materials-science/aramid-fiber
https://digital.sciencehistory.org/works/vh53ww75r#ohDownloads
https://www.dupont.com/content/dam/dupont/amer/us/en/safety/public/documents/en/Kevlar_Technical_Guide_0319.pdf 
https://www.vice.com/en/article/ezpvb4/this-is-what-happens-when-you-shoot-a-kevlar-vest-at-point-blank-range 
https://www.bodyarmornews.com/how-does-kevlar-work/
https://www.nytimes.com/1974/05/13/archives/kevlar-enters-spotlight-as-new-miracle-fiber-resistance-to-stretch.html 
https://web.media.mit.edu/~stefan/liquid-crystals/node3.html 
https://spie.org/samples/TT100.pdf 
https://www.youtube.com/watch?v=EFHk28WqXm8 
https://ieeexplore.ieee.org/document/6487587?reload=true 

Image Sources:
https://www.istockphoto.com/photo/smartphone-mockup-with-blank-white-screen-on-a-yellow-background-gm1257716991-368683678
https://www.istockphoto.com/photo/colorful-wavy-object-gm1198272365-342402674

https://www.istockphoto.com/photo/molecular-structure-gm174289788-24964413
https://commons.wikimedia.org/wiki/File:Stephanie_Kwolek_at_Spinning_Elements_by_Harry_Kalish.TIF (https://creativecommons.org/licenses/by-sa/3.0/deed.en)
https://www.istockphoto.com/photo/clean-new-steel-rope-sling-drum-gm595100944-102021345
https://en.wikipedia.org/wiki/Aramid#/media/File:Kevlar_chemical_structure_H-bonds.svg
https://www.istockphoto.com/photo/cosmetic-beauty-care-cream-gel-serum-background-gm1180254134-330582310
https://www.istockphoto.com/photo/gold-glitter-texture-background-sparkling-shiny-wrapping-paper-for-christmas-holiday-gm1180882747-330976753
https://www.istockphoto.com/photo/oil-with-air-bubbles-at-the-white-gm508342206-85211505
https://www.istockphoto.com/photo/aqua-waterscape-gm92376580-1369033
https://www.istockphoto.com/photo/texture-of-silver-carbon-fiber-gm508076943-45362792
https://commons.wikimedia.org/wiki/File:Aramid_fiber2.jpg (https://creativecommons.org/licenses/by-sa/3.0/deed.en)
https://www.istockphoto.com/photo/material-of-composite-product-dark-carbon-fiber-gm1035716588-277269210
https://www.istockphoto.com/photo/three-pads-cevlar-gm1208829728-349562185
https://www.istockphoto.com/vector/flexed-bicep-glyph-icon-gm1187826990-335706466
https://www.storyblocks.com/video/stock/soccer-goal-scored-champion-success-sport-nv9pq7r
https://www.istockphoto.com/photo/car-wheel-gm95757577-4521153
https://www.istockphoto.com/photo/snare-drum-on-black-background-gm619631790-108081491
https://www.istockphoto.com/photo/toy-boat-with-a-large-brown-sail-gm172402185-4759229
https://www.istockphoto.com/photo/water-line-gm646843796-117308813
https://www.istockphoto.com/photo/crystal-refractions-background-gm864426064-143347925
https://www.istockphoto.com/photo/laptop-computer-gm184084320-1747232
https://www.istockphoto.com/photo/macro-of-dots-on-a-ctr-monitor-gm1286297244-382843931
https://www.istockphoto.com/photo/mature-latin-american-businesswoman-working-from-home-gm1207315436-348543210

## Sneaky Ways Chemists Are Making Our World Safer
 - [https://www.youtube.com/watch?v=yOoAwfxeEJM](https://www.youtube.com/watch?v=yOoAwfxeEJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-01-17 00:00:00+00:00

The path that products take to get onto store shelves doesn’t always leave the best impact on the environment. But with green chemistry, chemists have found ways to make the production of some items safer for both people and the planet.

Hosted by: Michael Aranda

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.acs.org/content/acs/en/greenchemistry/principles/12-principles-of-green-chemistry.html
https://www.scientificamerican.com/article/green-chemistry-benign-by-design/
https://pubs.acs.org/doi/pdf/10.1021/bk-1994-0577.ch001
https://hero.epa.gov/hero/index.cfm/reference/details/reference_id/1227401
https://www.atsdr.cdc.gov/MMG/MMG.asp?id=230&amp;tid=42
https://www.chemengonline.com/supercritical-co2-a-green-solvent/?printmode=1
https://www.scientificamerican.com/article/how-is-caffeine-removed-t/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4168859/
https://www.aidic.it/cet/17/57/284.pdf
https://hightechextracts.com/supercritical-co2s-extraction-efficiency/
https://www.ncbi.nlm.nih.gov/books/NBK9921/
https://cordis.europa.eu/article/id/169909-biocatalysts-for-more-ecofriendly-chemicals
https://pubs.rsc.org/en/content/articlelanding/2020/sc/c9sc05746c#!divAbstract
https://www.britannica.com/science/transaminase
https://www.frontiersin.org/articles/10.3389/fcell.2019.00147/full
https://application.wiley-vch.de/books/sample/352730715X_c01.pdf
https://www.genome.gov/about-genomics/fact-sheets/Polymerase-Chain-Reaction-Fact-Sheet
http://www.jofamericanscience.org/journals/am-sci/0204/12-0205-mahongbao-am.pdf
https://link.springer.com/chapter/10.1007/978-1-4020-6241-4_6
https://www.sciencedirect.com/science/article/pii/S2211558716300231
http://www.inchem.org/documents/ukpids/ukpids/ukpid86.htm
https://www.epa.gov/sites/production/files/2016-10/documents/award_recipients_1996_2016.pdf
https://www.fs.fed.us/t-d/pubs/pdf/hi_res/93511208hi.pdf
https://www.sciencedirect.com/science/article/pii/S0959652619301799
https://www.foodpackagingforum.org/fpf-2016/wp-content/uploads/2016/07/FPF_Dossier10_PFASs.pdf
https://www.usfa.fema.gov/training/coffee_break/021120.html
https://www.solbergfoam.com/getattachment/678ee341-8f4c-4a2f-b527-993568c6b606/Firefighting-Foam-and-the-Environment.aspx

Image Sources: 
https://www.istockphoto.com/photo/coffee-gm1214079846-353085751
https://www.istockphoto.com/photo/green-coffee-beans-background-gm1215781496-354250215
https://www.istockphoto.com/photo/coal-powder-gm1204898982-346881112
https://commons.wikimedia.org/wiki/File:Essigs%C3%A4ureethylester.svg
https://commons.wikimedia.org/wiki/File:CriticalPointMeasurementEthane.jpg
https://www.istockphoto.com/photo/organic-green-coffee-grains-gm1129778511-298568628
https://www.istockphoto.com/photo/pharmaceutical-industry-medicine-pills-are-filling-in-the-plastic-bottle-on-gm859050944-141890781
https://www.istockphoto.com/photo/type-2-diabetes-treatment-gm972354458-264709840
https://commons.wikimedia.org/wiki/File:Aspartate_transaminase.png
https://www.istockphoto.com/photo/simvastatin-molecular-structure-isolated-on-black-gm490076222-75021073
https://commons.wikimedia.org/wiki/File:Glasbottles_containing_Butyllithium,_Buli.jpg
https://www.istockphoto.com/photo/person-pouring-detergent-in-lid-gm949218796-259124422
https://www.istockphoto.com/photo/liquid-green-gm157526113-11403329
https://www.istockphoto.com/photo/firefighters-extinguish-a-fire-fire-foam-and-fire-gm1255150745-367100689
https://commons.wikimedia.org/wiki/File:Cellulose-Ibeta-from-xtal-2002-3D-balls.png
https://www.istockphoto.com/photo/scientist-with-dna-copying-real-time-cycler-wide-gm177381768-20558086
https://www.istockphoto.com/vector/seamless-dna-pattern-gm472387273-36972074
https://www.istockphoto.com/vector/smartphone-mobile-phone-on-blue-background-long-shadow-flat-design-gm618979678-107868073
https://www.istockphoto.com/vector/collection-of-birds-robin-red-cardinal-tits-sparrow-bullfinches-waxwing-isolated-on-gm1176245279-327866244
https://www.istockphoto.com/photo/fireman-extinguishing-a-burning-car-with-foam-gm1056471698-282342925
https://bit.ly/2LHRJSU
https://bit.ly/38Gmp04

#SciShow

