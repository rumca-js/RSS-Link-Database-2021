# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Prodigy - Funkadelic (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=Q3BOxgvom74](https://www.youtube.com/watch?v=Q3BOxgvom74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-01-17 00:00:00+00:00

"Funkadelic" by Prodigy/Oops (Emiel Leenders), 2nd at Astrosyn 1997. Art "Sheepy" (1995) by Jason/Razor 1911 (unsure). Headphones recommended.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 4 channel ProTracker module
- 14-bit calibrated Paula output
- Infinite oversampling with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled

Visit my channel for more Amiga music.

