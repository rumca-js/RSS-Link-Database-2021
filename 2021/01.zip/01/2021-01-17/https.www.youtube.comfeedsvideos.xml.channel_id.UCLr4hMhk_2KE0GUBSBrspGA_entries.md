# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: CES 2021, moja najlepsza relacja z targów! MacBook 2021, dron Sony, okulary TCL
 - [https://www.youtube.com/watch?v=BxmlsKbMk3Q](https://www.youtube.com/watch?v=BxmlsKbMk3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-01-17 00:00:00+00:00

Naprawdę. Ta relacja jest lepsza niż targi!

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

moje najlepsze źródła:
Maska Razer: https://bit.ly/3in3iv4
Rozwijany smartfon LG: https://bit.ly/35L0jr1
Krzesło gamingowe Razer: http://cnet.co/3nO4qJn
Zwijany smartfon LG trafi do sprzedaży: http://bit.ly/38U0KS9
Czytnik linii papilarnych w ekranie iPhone'a 13: http://bit.ly/35PZVHT
Składany iPhone przyszłości: http://bit.ly/3oWEJra
MacBooki 2021: http://bit.ly/38Sq8Yw
Uderzył dronem w helikopter: http://bit.ly/3bHwZpo
Okulary TCL: http://bit.ly/39JbstA
Robot Samsunga: http://bit.ly/2LWtgt9
Dron Sony: https://bit.ly/3qyonpj
Asus gamingowy, ale dla dorosłych: http://cnet.co/39J7T6X
Asus projektor: http://bit.ly/2LWfVRC
CESowe latadła: http://cnet.co/39I2xbR
Przezroczysty telewizor LG: http://bit.ly/35ObX4O
Telewizor TCL: http://bit.ly/2LZirGU
Maszyna do lodów: https://bit.ly/38U1yq9
Innowacyjna szminka: http://cnet.co/2LZVH9u
Słuchawki Anker Liberty Air 2 Pro: http://cnet.co/3qwHK1I

