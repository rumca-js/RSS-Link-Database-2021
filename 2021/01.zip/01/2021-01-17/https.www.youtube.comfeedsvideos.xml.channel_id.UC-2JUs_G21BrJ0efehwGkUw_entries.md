# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Purple Rain | Prince | funk cover ft. Mario Jose
 - [https://www.youtube.com/watch?v=Fy0KojvHOZs](https://www.youtube.com/watch?v=Fy0KojvHOZs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-01-18 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A cover of "Purple Rain" by Scary Pockets.

MUSICIAN CREDITS
Lead vocal: Mario Jose
Drums: Rob Humphreys
Bass: Joe Ayoub
Keys: Jack Conte
Guitar: Ryan Lerman
Keys, Guitar, Percussion, BGV's: Louis Cato

AUDIO CREDITS
Recording Engineer: Chris Sorem & Caleb Parker
Mixing/Mastering: Craig Polasko
Producer: Louis Cato

VIDEO CREDITS
Cinematography: Merlin Showalter
Editor: Adam Kritzberg
Producer: Mark Golembeski
Director: Mike Dempsey

Recorded Live at Nest Recorders in Los Angeles, CA.

Watch more videos! 
Scary Pockets: https://youtube.com/playlist?list=PLL3xcB0B80KV06T2lqZhG5zUZuwojwuex&playnext=1 
90s Hits Funkified: https://youtube.com/playlist?list=PLL3xcB0B80KX25RsNBxJeuiO0YuJNWH46&playnext=1 
Scary Goldings: https://youtube.com/playlist?list=PLL3xcB0B80KWCRIVdgwL5ayqAczyccWNW&playnext=1 
Most Popular: https://youtube.com/playlist?list=PLL3xcB0B80KWzWR4-NxRrmRDwAnZfEXXr&playnext=1 

About Scary Pockets 
We are Scary Pockets, a funk band that releases weekly music videos, in pursuit of the funk. Scary Pockets is Ryan Lerman and Jack Conte, with the help and support from a rotating roster of the best session musicians in the LA area. Make sure to subscribe and enable ALL notifications! 

#ScaryPockets #Funk #Prince #PurpleRain #MarioJose

