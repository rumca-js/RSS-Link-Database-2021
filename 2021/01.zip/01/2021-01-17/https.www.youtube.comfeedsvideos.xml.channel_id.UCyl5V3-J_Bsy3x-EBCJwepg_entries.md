# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Comedian Dustin Nickerson on The Babylon Bee Podcast | Preview
 - [https://www.youtube.com/watch?v=s3mYeENZDTk](https://www.youtube.com/watch?v=s3mYeENZDTk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-18 00:00:00+00:00

🎙 Tomorrow, comedian Dustin Nickerson joins Kyle and Ethan on The Babylon Bee podcast.

SUBSCRIBE TODAY! ▶️ http://bit.ly/TheBeeYouTube

## Angry Fan Calls Out The Babylon Bee
 - [https://www.youtube.com/watch?v=NHbpel7BMhM](https://www.youtube.com/watch?v=NHbpel7BMhM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-17 00:00:00+00:00

Kyle and Ethan read more hate mail from a “fan” who thinks The Babylon Bee has been making Christianity look bad.

See the full show here:
https://youtu.be/SfaNhY-Wddk

Subscribe to The Babylon Bee today!

Hit the bell to get your daily dose of fake news that you can trust.

