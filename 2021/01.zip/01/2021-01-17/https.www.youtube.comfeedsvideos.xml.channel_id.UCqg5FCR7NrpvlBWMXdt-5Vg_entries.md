# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## How Gears 5: Hivebusters Might Hint at An Exciting Future For Xbox IP
 - [https://www.youtube.com/watch?v=1DcQEfcTBzw](https://www.youtube.com/watch?v=1DcQEfcTBzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-01-17 00:00:00+00:00

This week on The Escapist Show, Jack plays more Dark Souls and previews Loop Hero, while Nick is daydreaming about the future of established Xbox IP thanks to Game Pass.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---

Timestamps
0:00 - 8:27 - The Games We've Been Playing
8:28 - 14:30 - Loop Hero Preview
14:31 - 30:24 - Gears 5: Hivebusters and Xbox Experiments

---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

