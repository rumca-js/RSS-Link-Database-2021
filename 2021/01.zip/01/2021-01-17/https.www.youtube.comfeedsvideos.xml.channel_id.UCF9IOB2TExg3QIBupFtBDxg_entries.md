# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Mr David Davis MP and Vitamin D
 - [https://www.youtube.com/watch?v=bQyhjQUjHjU](https://www.youtube.com/watch?v=bQyhjQUjHjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-01-18 00:00:00+00:00

Thank you for a fascinating and important interview Mr. Davis.

Parliamentary statement, https://www.youtube.com/watch?v=Gog5mgBv0hM&feature=youtu.be

## Difficult COVID month ahead
 - [https://www.youtube.com/watch?v=4GQfPgaE4sA](https://www.youtube.com/watch?v=4GQfPgaE4sA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-01-17 00:00:00+00:00

United States

100 million shots in 100 days

Current supply issues

Using the defence production act

Federal Emergency Management Agency and National Guard to build sites

Federal mask mandate

https:/covid.cdc.gov/covid-data-tracker/#trends_dailytrendscases
 
https://covidtracking.com/data(The Atlantic)

https://www.washingtonpost.com/graphics/2020/national/coronavirus-us-cases-deaths/?itid=lk_inline_manual_5

Cases, + 215,449 = 23,715,000 

Down 8.1% in past 7 days

National positivity rate, 11.1%

Hospitalizations, 126,139 (23,524) (7,755)

Down 3.5% in past 7 days

Deaths, 386,825

Up 6.4% in past 7 days

US, Vaccinations

Distributed, 31,161,075

First dose, 10,595,866

Second dose, 1,610,524


UK

Sir Simon Stevens, Head of NHS England

https://www.bbc.co.uk/news/live/world-55694385

Hospitals, extreme pressure

London and South East, East of England, Midlands, North West

Transfers

https://covid.joinzoe.com/data#levels-over-time

https://coronavirus.data.gov.uk

Estimated R number 

1.2 – 1.3 (15th January)

Daily infection growth rate range, of + 2% to + 5% (15th January 2021)

Cases, + 41,346 = 3,375,361

Cases, last 7 days, down 18.6%

Hospitalised, + 4,532 = 37,475 (3,789)

Last 7 days, up 19.7%

Deaths, + 7,722 (7 days) = 88,590

Last 7 days, up 23.5%

UK death certificate deaths, 93,030

Vaccinated, first dose, 3,559,179 (Jan 15th)

Second dose, 447,261

Vaccinations, next step

End of June, all over 18 vaccinated, (54 million)

Four to five million people a week within months.

Moderna (17m)

Johnson & Johnson (30m)

Nadhim Zahawi, new vaccines for variants, 30-40 days after first identified

Hospitalisations and deaths down early March

UK Super-factory (158m)

End of 2021

Vaccinate everyone against VOCs within 4 months

Opens later this year

Vaccines Manufacturing Innovation Centre (VMIC)

Harwell Science & Innovation Campus in Oxfordshire, not-for-profit company

Capable of producing 70m doses in four to five months

Much of the Pfizer and Oxford vaccine made in Belgium and Netherlands

Equipped to produce mRNA vaccines and adenovirus-based


Mr David Davis, MP

https://www.youtube.com/watch?v=Gog5mgBv0hM&feature=youtu.be

Andalusia

8 million people

Death rate cut by two thirds

50 -70 per day down to 5 -15 per day

Calcifediol to high-risk groups

Madrid is reviewing

India

https://www.washingtonpost.com/world/asia_pacific/india-coronavirus-vaccinations/2021/01/15/342a7282-55c9-11eb-acc5-92d2819a1ccb_story.html

Emergency approval to two vaccines

First 300 million

3,000 vaccination centres

Oxford-AstraZeneca

Covaxin, Bharat Biotech

Both fridge temperatures

Both cost $2.75 per dose

Pfizer is $19.50

Indian regulators, Bharat Biotech vaccine, used in clinical trial mode

Serum Institute, Covax project





Israel

Rate in community transmission remains high after 20% vaccinated

 

https://www.telegraph.co.uk/news/2021/01/13/early-data-israeli-vaccine-programme-suggests-infection-rates/

Pfizer-BioNTech, reduce chances of catching coronavirus by 33 - 60 % after 14 days

Looking like vaccine prevents recipients transmitting coronavirus

N = 200,000 (vaccinated)

N = 200,000 (unvaccinated)
No behaviour change 

Full 95 per cent protection comes after two shots

Now inviting over 50s

Zimbabwe

https://www.chronicle.co.zw/covid-19-government-to-ascertain-safety-of-vaccines-first/

Government will first ascertain that Covid-19 vaccines are safe before administering them on volunteers.

Following other States, with keen interest

Zimbabwe adopted a measured approach

Further, in the unlikely scenario that cases spiral out of control, all hospitals in the country may be turned into Covid-19 centres.


Australia

https://www.bbc.co.uk/news/world-australia-55693223

Several players have expressed frustration

At least three female players said they might not have gone

At least 47 players are now in isolation in Melbourne

Two flights with positive cases

Emma Cassar, Quarantine Commissioner, Victoria

People in the hotels were breaching lockdown rules by opening their doors to communicate with others on their floor

It is really low-level but really dangerous acts which we just can't tolerate

