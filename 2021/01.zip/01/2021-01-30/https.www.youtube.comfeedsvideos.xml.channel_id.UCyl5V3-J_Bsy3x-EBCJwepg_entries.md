# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Gavin Newsom Joyfully Invites California to Reopen
 - [https://www.youtube.com/watch?v=AVUnszmEHiw](https://www.youtube.com/watch?v=AVUnszmEHiw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-30 00:00:00+00:00

Governor Newsom ends COVID lockdowns by joyfully shouting reopen to rows of abandoned, dilapidated buildings throughout California.

## The Bee Reads LOTR Episode 5: A Short Cut To Mushrooms
 - [https://www.youtube.com/watch?v=VmlWADUlvI0](https://www.youtube.com/watch?v=VmlWADUlvI0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-30 00:00:00+00:00

Frodo, Sam, and Pippin continue trekking through the Shire in this week’s The Babylon Bee Reads The Lord Of The Rings with Kyle and Dan joined by Jonathan Watson from TheOneRing.Com, an online fellowship as well as a place for cool Middle-Earth maps and articles. We discover Farmer Maggot, some black riders, and the shortcut to mushrooms. 

Note: We had to salvage the audio on this episode after running into several issues, but we hope you still enjoy the discussion.

