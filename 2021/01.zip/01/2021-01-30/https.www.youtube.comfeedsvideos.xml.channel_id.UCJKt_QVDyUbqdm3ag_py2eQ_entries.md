# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does S3M: Alexander Brandon - Jazz Jackrabbit 2 intro & menu (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=F5rCRNo89_k](https://www.youtube.com/watch?v=F5rCRNo89_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-01-31 00:00:00+00:00

Jazz Jackrabbit 2 (PC, 1998) intro and menu themes by Alexander Brandon.

00:00 intro
00:32 menu

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Modules report 16 channels for intro and 10 for menu
- 100% flawless playback not guaranteed (the S3M replayer might not be perfect). The files used were the MIRSOFT DeeDyner rips.

Visit my channel for more Amiga music.

