# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Naprawdę bezprzewodowe ładowanie, walka o Gamestop i nowa Tesla za grosze
 - [https://www.youtube.com/watch?v=CsKTqVIDQoY](https://www.youtube.com/watch?v=CsKTqVIDQoY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-01-31 00:00:00+00:00

Oraz mnóstwo innych tematów, które mam nadzieję nie pozostawią Was obojętnymi :)

W odcinku:
00:00 Wstęp
00:34 Dobry wieczór!
00:38 Bezprzewodowe ładowanie – Formuła E
02:33 Kolejny etap ładowania bezprzewodowego – Solid State Tech
03:16 Bezprzewodowe ładowanie według Xiaomi – Mi Air Charge
04:38 Testy na covid od tyłu
06:01 Jak działa giełda
08:21 GameStop i WallStreetBets
11:15 Google usuwa negatywne oceny Robinhooda
12:05 Akcje i fundusze CD Projekt
13:03 Siła tradycyjnych mediów a siła Internetu
13:53 Nowa Tesla S
15:10 Sony A1 z 8K
15:29 Sony Xperia Pro
15:49 Carl Pe startuje z Nothing
16:07 Projekt nowych przepisów dotyczących hulajnóg elektrycznych i UTO
17:22 Adobe Flash zatrzymał chińską kolej
18:24 Pożegnanie
18:37 Znośnego tygodnia!
 
Źródła:
Ładowanie bezprzewodowe (Solid State Tech): https://youtu.be/NPBZgzbhLk4
Ładowanie MiAirCharge Xiaomi: https://youtu.be/xsFHKCcV2rg
Niestety to prototyp: http://bit.ly/2YykjJu
Chińczycy będą robić testy od tyłu: http://bit.ly/3j3TrdP
WallStreetBets: http://bit.ly/3j2hLNn
Google usuwa negatywne oceny Robinhooda: http://bit.ly/3copfsJ
Sytuacja z akcjami CDProjekt: http://bit.ly/3ctK99Q
Fundusze "wyciśnięte" z CDProjektu: http://bit.ly/3tlkG8L
Nowa Tesla: http://bit.ly/2Yxx3A8
Próbka 8K z Sony A1: https://youtu.be/-ucUFBTUYLI
Xperia Pro: http://bit.ly/3r985mS
Carl Pei startuje z niczym: http://bit.ly/2MiFI6Y
Nowe przepisy dotyczące hulajnóg: http://bit.ly/36tGBR2
Flash zatrzymał Chińską kolej: http://bit.ly/3ctL36e

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

