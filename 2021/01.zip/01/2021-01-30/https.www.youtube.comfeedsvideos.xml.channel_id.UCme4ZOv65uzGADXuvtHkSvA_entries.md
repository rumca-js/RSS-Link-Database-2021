# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Kobieta i ksiądz [04] Zakochałam się w księdzu
 - [https://www.youtube.com/watch?v=btrte9T_pcw](https://www.youtube.com/watch?v=btrte9T_pcw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-31 00:00:00+00:00

#kobiety #kobietaiksiądz @Langustanapalmie 

Zapraszamy na nową serię na languście, czyli rozmowy kobiety i księdza, czyli Agata Rujner i Adam Szustak OP. O różnych płaszczyznach relacji kobiet z Kościołem i na odwrót. 

zdjęcia: Marcin Jończyk
montaż: Marcin Jończyk, Agnieszka Nowak
dźwięk: Krzysztof Irisik
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## List do Efezjan || Rozdział 01
 - [https://www.youtube.com/watch?v=_uLEFhjVDeI](https://www.youtube.com/watch?v=_uLEFhjVDeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-31 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#219] Katolickie trąby
 - [https://www.youtube.com/watch?v=lhxRnoC6ai8](https://www.youtube.com/watch?v=lhxRnoC6ai8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-30 00:00:00+00:00

@Langustanapalmie  #cnn

IV Niedziela zwykła, Rok B

1. czytanie (Pwt 18, 15-20)

Mojżesz tak przemówił do ludu:
„Pan Bóg twój wzbudzi ci proroka spośród braci twoich, podobnego do mnie. Jego będziesz słuchał. Właśnie o to prosiłeś Pana Boga swego na Horebie, w dniu zgromadzenia: «Niech więcej nie słucham głosu Pana Boga mojego i niech już nie widzę tego wielkiego ognia, abym nie umarł»”.
I odrzekł mi Pan: „Dobrze powiedzieli. Wzbudzę im proroka spośród ich braci, takiego jak ty, i włożę w jego usta moje słowa, będzie im mówił wszystko, co rozkażę.
Jeśli ktoś nie będzie chciał słuchać moich słów wypowiedzianych w moim imieniu, Ja od niego zażądam zdania sprawy. Lecz jeśli który prorok odważy się mówić w moim imieniu to, czego mu nie rozkazałem, albo wystąpi w imieniu bogów obcych, taki prorok musi ponieść śmierć”.

2. czytanie (1 Kor 7, 32-35)

Bracia: Chciałbym, żebyście byli wolni od utrapień. Człowiek bezżenny troszczy się o sprawy Pana, o to, jak by się przypodobać Panu. Ten zaś, kto wstąpił w związek małżeński, zabiega o sprawy świata, o to, jak by się przypodobać żonie. I doznaje rozterki.
Podobnie i kobieta: niezamężna i dziewica troszczy się o sprawy Pana, o to, by była święta i ciałem, i duchem. Ta zaś, która wyszła za mąż, zabiega o sprawy świata, o to, jak by się przypodobać mężowi. Mówię to dla waszego pożytku, nie zaś, by zastawiać na was pułapkę; ale po to, byście godnie i z upodobaniem trwali przy Panu.

Ewangelia (Mk 1, 21-28)

W Kafarnaum Jezus w szabat wszedł do synagogi i nauczał. Zdumiewali się Jego nauką: uczył ich bowiem jak ten, który ma władzę, a nie jak uczeni w Piśmie. Był właśnie w ich synagodze człowiek opętany przez ducha nieczystego. Zaczął on wołać: «Czego chcesz od nas, Jezusie Nazarejczyku? Przyszedłeś nas zgubić. Wiem, kto jesteś: Święty Boga». Lecz Jezus rozkazał mu surowo: «Milcz i wyjdź z niego! » Wtedy duch nieczysty zaczął nim miotać i z głośnym krzykiem wyszedł z niego.
A wszyscy się zdumieli, tak że jeden drugiego pytał: «Co to jest? Nowa jakaś nauka z mocą. Nawet duchom nieczystym rozkazuje i są Mu posłuszne». I wnet rozeszła się wieść o Nim wszędzie po całej okolicznej krainie galilejskiej.

________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## List do Galatów || Rozdział 06
 - [https://www.youtube.com/watch?v=H4nSbYwSpLo](https://www.youtube.com/watch?v=H4nSbYwSpLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-30 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#698] Sekrety
 - [https://www.youtube.com/watch?v=_S3z1_--zf0](https://www.youtube.com/watch?v=_S3z1_--zf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-01-30 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

