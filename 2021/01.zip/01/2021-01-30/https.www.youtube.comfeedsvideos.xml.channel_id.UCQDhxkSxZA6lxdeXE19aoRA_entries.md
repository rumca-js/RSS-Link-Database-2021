# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## iPhone 12's Latest Approach at Deterring 3rd Party Repair
 - [https://www.youtube.com/watch?v=8-FxNKEH_qc](https://www.youtube.com/watch?v=8-FxNKEH_qc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-01-30 00:00:00+00:00

Time for an update with the repair issues facing the iPhone 12 phones.
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
Camera Article: https://support.apple.com/en-us/HT212002
Display Article:  https://support.apple.com/en-us/HT210321
Battery Article:  https://support.apple.com/en-au/HT210323
Orignal iPhone 12 Teardown: https://youtu.be/FY7DtKMBxBw

Get parts, tools, and thousands of free repair guides from iFixit at: 
    https://iFixit.com/hughjeffreys
Australia Store: https://ifix.gd/2FPxhKy
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

