# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Poorly written Bloomberg blog has no idea what is fueling "gambling" behavior 🤔
 - [https://www.youtube.com/watch?v=vVH8gHe6S-U](https://www.youtube.com/watch?v=vVH8gHe6S-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-01-31 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
To be clear I am not saying that they don't make good points about it being a bad idea to YOLO all of your money into an actual meme stock. I am just tired of the one dimensional, cookie cutter blogger style reporting that is becoming so much more pervasive even on paid outlets. For $40/mo, I demand better. My videos suck but at least they're free!

👉 https://www.bloomberg.com/news/articles/2021-01-30/-like-a-drug-redditors-stock-mania-fueled-by-gambling-high?srnd=premium&sref=lagJc1td

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

We are not financial services or investment professionals and this is not investment advice. Do your own Research
Our content is intended to be used and must be used for entertainment purposes only. It is very important to do your own analysis before making any investment based on your own personal circumstances. You should take independent financial advice from a professional in connection with, or independently research and verify, any information that you find in these videos and wish to rely upon, whether for the purpose of making an investment decision or otherwise.

No Investment Advice
Our Youtube channel is an opinion/podcast platform. We are not a broker/dealer, we are not an investment advisor, we have no access to non-public information about publicly traded companies, and this is not a place for the giving or receiving of financial advice, advice concerning investment decisions or tax or legal advice. We are not regulated by the Financial Services Authority.

The value of shares and investments and the income derived from them can go down as well as up;
Investors may not get back the amount they invested - losing one's shirt is a real risk;
Past performance is not a guide to future performance.

I own some $BB, $ICLN, $GME, $AG, and $SLV at the time of making this video.

## Zuckerberg MAD that Apple is protecting its customers privacy, Facebook is a joke
 - [https://www.youtube.com/watch?v=cMZrufbykiA](https://www.youtube.com/watch?v=cMZrufbykiA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-01-31 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 https://mazech.com/2021/01/facebook-accuses-apple-of-interfering-with-its-business-and-engaging-in-anticompetitive-behavior/
👉 https://www.youtube.com/watch?v=OYYZGEfsj4M&feature=youtu.be

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

We are not financial services or investment professionals and this is not investment advice. Do your own Research
Our content is intended to be used and must be used for entertainment purposes only. It is very important to do your own analysis before making any investment based on your own personal circumstances. You should take independent financial advice from a professional in connection with, or independently research and verify, any information that you find in these videos and wish to rely upon, whether for the purpose of making an investment decision or otherwise.

No Investment Advice
Our Youtube channel is an opinion/podcast platform. We are not a broker/dealer, we are not an investment advisor, we have no access to non-public information about publicly traded companies, and this is not a place for the giving or receiving of financial advice, advice concerning investment decisions or tax or legal advice. We are not regulated by the Financial Services Authority.

The value of shares and investments and the income derived from them can go down as well as up;
Investors may not get back the amount they invested - losing one's shirt is a real risk;
Past performance is not a guide to future performance.

## 🔴 Ultimate wallstreetbets, Gamestop, Robinhood summary & update 1/30/2021 (START HERE) 🚀🚀
 - [https://www.youtube.com/watch?v=jQDHWu32W7o](https://www.youtube.com/watch?v=jQDHWu32W7o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-01-31 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
8:04 - after recap
18:30 - best part
31:31 - Apology for any incorrect information prior to this video
CITATIONS: 
👉 https://economictimes.indiatimes.com/markets/stocks/news/gamestop-shares-surge-140-as-short-sellers-start-to-surrender/articleshow/80484458.cms

👉 https://www.forbes.com/sites/joanverdon/2021/01/11/can-ryan-cohen-work-his-chewy-magic-at-gamestop-heres-a-possible-game-plan/?sh=14cd423c472a
👉 https://www.wsj.com/articles/citadel-point72-to-invest-2-75-billion-into-melvin-capital-management-11611604340
👉 https://www.washingtonpost.com/business/2021/01/29/robinhood-citadel-gamestop-reddit/
👉 https://www.bloomberg.com/news/articles/2021-01-28/wallstreetbets-group-is-back-on-discord-service-after-brief-ban
👉 https://www.youtube.com/watch?v=k_oNLeMuxvg
👉 https://www.youtube.com/watch?v=D-U2rOHIv94
👉 https://www.youtube.com/watch?v=XX6-jPy98YA
👉 https://www.bloomberg.com/news/articles/2021-01-27/melvin-capital-closes-out-its-gamestop-position-cnbc-reports
👉 https://www.bloomberg.com/news/articles/2021-01-29/clearing-firms-prevent-cascading-failures-q-a-with-larry-tabb
👉 https://i.redd.it/8vxraurkcce61.png
👉 https://www.cnbc.com/2021/01/28/robinhood-interactive-brokers-restrict-trading-in-gamestop-s.html
👉 https://www.reddit.com/r/wallstreetbets/comments/l7duqp/bb_now_you_see_why_wall_street_wants_to_keep_this/
👉 https://worldnewsera.com/news/entrepreneurs/robinhood-and-citadels-relationship-comes-into-focus-as-washington-vows-to-examine-stock-market-moves/
👉 https://www.washingtonpost.com/business/2021/01/29/robinhood-citadel-gamestop-reddit/
👉 https://www.worldnpost.com/the-relationship-between-robinhood-and-citadel-comes-into-play-when-washington-promises-to-investigate-stock-market-movements/
👉 https://www.rt.com/usa/513968-robinhood-gamestop-force-sale/
👉 https://twitter.com/themaxburns/status/1354876195163287554?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1354876195163287554%7Ctwgr%5E%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fwww.rt.com%2Fusa%2F513968-robinhood-gamestop-force-sale%2F  
👉 https://robinhood.com/us/en/support/articles/changes-due-to-recent-market-volatility/
👉 https://soundcloud.com/aroundthecoin/dustin-kirkland-cpo-of-apex-clearing
👉 https://www.youtube.com/watch?t=171&v=cuCcchMOsKE
👉 https://www.youtube.com/watch?v=tyKBr1w4HLQ
👉 https://www.nytimes.com/2021/01/29/technology/robinhood-fundraising.html

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

We are not financial services or investment professionals and this is not investment advice. Do your own Research. This content is purely the opinion, and unprofessional speculation, of Louis Rossmann. I own shares of GME, ICLN, BB, AG, and SLV at this time.

Our content is intended to be used and must be used for entertainment purposes only. It is very important to do your own analysis before making any investment based on your own personal circumstances. You should take independent financial advice from a professional in connection with, or independently research and verify, any information that you find in these videos and wish to rely upon, whether for the purpose of making an investment decision or otherwise.

No Investment Advice: Our Youtube channel is an opinion/podcast platform. We are not a broker/dealer, we are not an investment advisor, we have no access to non-public information about publicly traded companies, and this is not a place for the giving or receiving of financial advice, advice concerning investment decisions or tax or legal advice. We are not regulated by the Financial Services Authority.

The value of shares and investments and the income derived from them can go down as well as up;
Investors may not get back the amount they invested - losing one's shirt is a real risk
Past performance is not a guide to future performance.

## How PR failings lead people to assume the worst: Robinhood's screwup encouraged a populist revolt
 - [https://www.youtube.com/watch?v=tyKBr1w4HLQ](https://www.youtube.com/watch?v=tyKBr1w4HLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-01-30 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
When you give people every reason to assume the worst.... they assume the worst. 
👉 https://www.bloomberg.com/news/articles/2021-01-29/clearing-firms-prevent-cascading-failures-q-a-with-larry-tabb?sref=lagJc1td
👉 https://news.ycombinator.com/item?id=25951475
👉 https://www.reddit.com/r/todayilearned/comments/egy250/til_in_2016_apple_released_software_that_would/fccombw/?utm_source=share&utm_medium=web2x&context=3  
👉 https://blog.robinhood.com/news/2021/1/28/keeping-customers-informed-through-market-volatility
👉 https://robinhood.com/us/en/support/articles/changes-due-to-recent-market-volatility/
 
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

We are not financial services or investment professionals and this is not investment advice. Do your own Research
Our content is intended to be used and must be used for entertainment purposes only. It is very important to do your own analysis before making any investment based on your own personal circumstances. You should take independent financial advice from a professional in connection with, or independently research and verify, any information that you find in these videos and wish to rely upon, whether for the purpose of making an investment decision or otherwise.

No Investment Advice
Our Youtube channel is an opinion/podcast platform. We are not a broker/dealer, we are not an investment advisor, we have no access to non-public information about publicly traded companies, and this is not a place for the giving or receiving of financial advice, advice concerning investment decisions or tax or legal advice. We are not regulated by the Financial Services Authority.

The value of shares and investments and the income derived from them can go down as well as up;
Investors may not get back the amount they invested - losing one's shirt is a real risk;
Past performance is not a guide to future performance.

