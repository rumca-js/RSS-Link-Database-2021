# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'Humanity at its worst' - Man Utd's Rashford racially abused on social media
 - [https://www.bbc.co.uk/sport/football/55872681](https://www.bbc.co.uk/sport/football/55872681)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 23:50:50+00:00

Manchester United forward Marcus Rashford says he was subjected to "humanity and social media at its worst" after receiving racist abuse on Saturday night.

## 'They're coming for us' - right-wing media on Biden's week
 - [https://www.bbc.co.uk/news/world-us-canada-55845763](https://www.bbc.co.uk/news/world-us-canada-55845763)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 22:33:27+00:00

After four years of cheerleading, right-wing pundits have switched tack with Biden in their sights.

## UK wants to join the club - but what is the CPTPP?
 - [https://www.bbc.co.uk/news/explainers-55858490](https://www.bbc.co.uk/news/explainers-55858490)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 22:31:02+00:00

It may sound like an official has lent on their keyboard - but it's an acronym we'll hear more often.

## 'Daddy, look at this': Girl's dinosaur footprint discovery on Barry beach
 - [https://www.bbc.co.uk/news/uk-55873900](https://www.bbc.co.uk/news/uk-55873900)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 19:50:03+00:00

Lily, four, spotted the 220 million-year-old print at Bendricks Bay in Wales during a walk with her dad.

## In Case 'Ewe' Missed It: The sheep, the steep and the ski city
 - [https://www.bbc.co.uk/news/world-55832173](https://www.bbc.co.uk/news/world-55832173)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 17:00:17+00:00

Why did 3,000 sheep cross the road? That and more in our weekly video round-up: In Case "Ewe" Missed It.

## TikTok singer Amy Hawkins, 110, becomes viral sensation
 - [https://www.bbc.co.uk/news/uk-wales-55871140](https://www.bbc.co.uk/news/uk-wales-55871140)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 14:41:49+00:00

Almost 100,000 people have seen Amy Hawkins sing World War One song It's A Long Way to Tipperary.

## Six events at one venue in a pandemic - tennis warms up for opening Grand Slam of the year
 - [https://www.bbc.co.uk/sport/tennis/55812368](https://www.bbc.co.uk/sport/tennis/55812368)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 09:01:51+00:00

The world's top tennis players come out of quarantine to warm up for the Australian Open as Melbourne Park hosts six simultaneous events.

## EU vaccine export row: Bloc backtracks on controls for NI
 - [https://www.bbc.co.uk/news/uk-55865539](https://www.bbc.co.uk/news/uk-55865539)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 08:54:25+00:00

The reversal came after widespread condemnation of the EU's plan to override the Brexit deal.

## 'Harsh writing advice' memes take off on Twitter
 - [https://www.bbc.co.uk/news/world-55869394](https://www.bbc.co.uk/news/world-55869394)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 08:52:58+00:00

Twitter users take time off their busy writing schedules to give each other helpful - or unhelpful - advice.

## EU had 'no choice but to act' on vaccine exports
 - [https://www.bbc.co.uk/news/world-europe-55860540](https://www.bbc.co.uk/news/world-europe-55860540)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 08:42:43+00:00

"Vaccine nationalism" risks causing a "protracted recovery", the organisation's chief warns.

## Covid: Boris Johnson 'in awe' of pandemic parents
 - [https://www.bbc.co.uk/news/uk-55869647](https://www.bbc.co.uk/news/uk-55869647)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 08:25:16+00:00

The prime minister says parents and guardians have risen to the "unique challenges" of coronavirus.

## Covid-19: EU backtracks on NI vaccine controls, and Australian Open to allow up to 30,000 fans
 - [https://www.bbc.co.uk/news/uk-55868574](https://www.bbc.co.uk/news/uk-55868574)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 07:59:23+00:00

Five things you need to know about the coronavirus pandemic on Saturday.

## From hanging out with footballers to working in a call centre, meet GB's world champion breaker
 - [https://www.bbc.co.uk/sport/olympics/55819260](https://www.bbc.co.uk/sport/olympics/55819260)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 07:25:44+00:00

Breaking star and Generation Next athlete Karam Singh aims to inspire more British Asians to take up elite sport.

## Copa Libertadores final - the 'new Ronaldo' & the wonderkid linked with Man Utd
 - [https://www.bbc.co.uk/sport/av/football/55859325](https://www.bbc.co.uk/sport/av/football/55859325)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 06:55:46+00:00

BBC Sport looks at Brazilian wonderkids Kaio Jorge from Santos and Palmeiras' Gabriel Veron, with their clubs set to meet in the Copa Libertadores final.

## HS2: Could the pandemic kill off the rail project?
 - [https://www.bbc.co.uk/news/uk-politics-55862648](https://www.bbc.co.uk/news/uk-politics-55862648)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 06:29:23+00:00

Covid-19 has intensified the debate among environmental groups about the benefits of the project.

## The Papers: 'EU vaccine war explodes', and Oxford jab 'attack'
 - [https://www.bbc.co.uk/news/blogs-the-papers-55866263](https://www.bbc.co.uk/news/blogs-the-papers-55866263)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 06:22:43+00:00

The EU's attempt to add controls on the export of jabs to the UK dominates the front pages.

## Covid: Families could be asked to pay funeral fines
 - [https://www.bbc.co.uk/news/uk-55866781](https://www.bbc.co.uk/news/uk-55866781)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 04:01:52+00:00

Concern from undertakers comes after a firm was fined £10,000 when 150 people attended a service.

## Covid-19: Your vaccine questions answered
 - [https://www.bbc.co.uk/news/newsbeat-55859245](https://www.bbc.co.uk/news/newsbeat-55859245)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 01:09:26+00:00

From infertility to travel, we look at some of the key Covid vaccine talking points.

## Lobotomy: The brain op described as ‘easier than curing a toothache’
 - [https://www.bbc.co.uk/news/stories-55854145](https://www.bbc.co.uk/news/stories-55854145)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:49:10+00:00

Tens of thousands of lobotomies were carried out in the UK and US in the 1940s and 50s. Should we condemn the surgeons?

## Coronavirus: What's behind Latin America's oxygen shortages?
 - [https://www.bbc.co.uk/news/world-latin-america-55829424](https://www.bbc.co.uk/news/world-latin-america-55829424)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:38:12+00:00

Some Latin American countries struggle with insufficient oxygen as Covid-19 continues to spread.

## Amsterdam drugs: Tourists face ban from cannabis cafes
 - [https://www.bbc.co.uk/news/world-europe-55765554](https://www.bbc.co.uk/news/world-europe-55765554)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:31:37+00:00

The mayor of Amsterdam has angered coffee shop owners, who fear that drug gangsters could step in.

## Week in pictures: 23-29 January 2021
 - [https://www.bbc.co.uk/news/in-pictures-55846176](https://www.bbc.co.uk/news/in-pictures-55846176)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:27:58+00:00

A selection of striking images taken around the world this week.

## Australian Open to allow up to 30,000 fans a day
 - [https://www.bbc.co.uk/sport/tennis/55866539](https://www.bbc.co.uk/sport/tennis/55866539)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:10:21+00:00

Up to 30,000 fans a day will be allowed to attend the Australian Open, Victoria's minister for sport has announced.

## The exiles: Hong Kong at a crossroads
 - [https://www.bbc.co.uk/news/world-asia-55861946](https://www.bbc.co.uk/news/world-asia-55861946)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:08:29+00:00

Pro-democracy protesters face a tough decision over continuing to fight or fleeing to the UK.

## Surfing duck: Pet becomes local celebrity at Australian beach
 - [https://www.bbc.co.uk/news/world-australia-55836596](https://www.bbc.co.uk/news/world-australia-55836596)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:07:51+00:00

The duck - called Duck - has become renowned locally for his daily forays into the sea.

## Push to ensure pupils are 'politically literate'
 - [https://www.bbc.co.uk/news/uk-politics-55862548](https://www.bbc.co.uk/news/uk-politics-55862548)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:05:12+00:00

A new parliamentary group wants to help young people engage with politics by improving civics education.

## Video calls and bookshelves dressed to impress
 - [https://www.bbc.co.uk/news/entertainment-arts-55861947](https://www.bbc.co.uk/news/entertainment-arts-55861947)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:04:07+00:00

Video calls have given us all an insight into people's homes – and one firm an unexpected boost.

## Pregnancy during lockdown: Advice from one mum to another
 - [https://www.bbc.co.uk/news/uk-55849697](https://www.bbc.co.uk/news/uk-55849697)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:03:54+00:00

Jacqui, who gave birth last year, gives advice to expectant mother Gemma.

## Reece James: Chelsea 'disgusted' after right-back is racially abused on social media
 - [https://www.bbc.co.uk/sport/football/55866503](https://www.bbc.co.uk/sport/football/55866503)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-01-30 00:02:55+00:00

Chelsea say they are "disgusted" after right-back Reece James was racially abused on social media.

