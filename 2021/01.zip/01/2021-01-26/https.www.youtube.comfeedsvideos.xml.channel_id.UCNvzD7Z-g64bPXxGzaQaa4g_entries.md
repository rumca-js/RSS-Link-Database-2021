# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Is TENCENT Preparing Hostile Takeover of EA or Take-Two?
 - [https://www.youtube.com/watch?v=XKo4_98e864](https://www.youtube.com/watch?v=XKo4_98e864)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-27 00:00:00+00:00

A hot new rumor suggest one of the world's biggest corporations is hoping to buy one of the larger video game publishers. Let's take a deeper look.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

SOURCES & REFERENCES

https://www.tweaktown.com/news/77498/report-tencent-raising-billions-to-buy-ea-take-two-or-others/index.html

https://www.reddit.com/r/pcgaming/comments/l4ka5r/rumor_tencent_raising_billions_to_buy_ea_taketwo/gkpr1w6/

https://www.reddit.com/r/pcgaming/comments/l4ka5r/rumor_tencent_raising_billions_to_buy_ea_taketwo/

## Top 7 NEW Games of February 2021
 - [https://www.youtube.com/watch?v=lE4n4qp2e_4](https://www.youtube.com/watch?v=lE4n4qp2e_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-26 00:00:00+00:00

Looking for something new to play on PC, PS5, PS4, Xbox, or Nintendo Switch in February 2021? Here are the notable video game releases.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Werewolf: The Apocalypse - Earthblood 

Platform: PC, PS5, XSX, PS4, Xbox One

Release Date: February 4, 2021



Super Mario 3D World + Bowser's Fury 

Platform:  Switch

Release Date: February 12, 2021



Persona 5 Strikers 

Platform: PC, PS4, Switch

Release Date: February 23, 2021



Century: Age of Ashes 

Platform: PC

Release Date: February TBC



Little Nightmares 2 

Platform: PC, PS4, XBO, Switch

Release Date: February 11, 2021



Bravely Default 2 

Platform: Switch

Release Date: February 26, 2021



Destruction AllStars 

Platform: PS5

Release Date: February TBC



BONUS

Control Ultimate Edition 

Platform: PS5, XSX

Release Date: February 2, 2021



Nioh 2 - The Complete Edition 

Platform: PC, PS4

Release Date: February 5, 2021



The Nioh Collection 

Platform: PS5

Release Date: February 5, 2021

