# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Thinks Daniel Craig is the Best James Bond
 - [https://www.youtube.com/watch?v=z1kM19Kils8](https://www.youtube.com/watch?v=z1kM19Kils8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-26 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1601 with Brian Redban. https://open.spotify.com/episode/6JIy9Ml1zHUwXuCi4KJsos?si=YrcRr9QARluMYOSlJJ9YAA

## Trump Should Have Pardoned Snowden & Assange
 - [https://www.youtube.com/watch?v=gpHtmO6gjIA](https://www.youtube.com/watch?v=gpHtmO6gjIA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-26 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1601 with Brian Redban. https://open.spotify.com/episode/6JIy9Ml1zHUwXuCi4KJsos?si=YrcRr9QARluMYOSlJJ9YAA

## Wuhan is Completely Reopened After Coronavirus
 - [https://www.youtube.com/watch?v=vwCeBWbZvrE](https://www.youtube.com/watch?v=vwCeBWbZvrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-26 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1601 with Brian Redban. https://open.spotify.com/episode/6JIy9Ml1zHUwXuCi4KJsos?si=YrcRr9QARluMYOSlJJ9YAA

