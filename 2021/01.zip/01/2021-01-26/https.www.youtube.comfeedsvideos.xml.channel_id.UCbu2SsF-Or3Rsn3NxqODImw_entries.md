# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Super Mario 3D World: Switch vs. Wii U Comparison
 - [https://www.youtube.com/watch?v=V2H511E96Eg](https://www.youtube.com/watch?v=V2H511E96Eg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-27 00:00:00+00:00

With Super Mario 3D World headed to Nintendo Switch, we put it head-to-head with the original Wii U version to see the differences.

Super Mario 3D World + Bowser’s Fury continues Nintendo’s trend of taking some of the biggest and best games from the Wii U generation and bringing it back to the much more popular Switch platform. But while this is a re-release of an eight-year-old game, it’s not without some neat quality-of-life improvements, which we showcase in this video. 

The most obvious change when viewing the games side-by-side is that character speeds have been greatly increased, both in the overworld map and inside stages themselves. You could always hold Y to dash, but now all the characters move significantly faster. This has the added effect of making Toad a much more tricky risk-reward character, since his dash was always significantly faster than other characters, and now he’s just blazing-fast. It also makes moving around the map to choose your next stage move at a speedier clip. 

The Switch version is also just more visually attractive. While the fidelity and textures look very similar, the icons have been shrunk to take less screen real estate, and the text boxes have been lightened to let you see the game world more clearly. 

And, of course, the strange microphone-blowing mechanic to move platforms has been changed so that platforms now move automatically. That odd holdover just doesn’t belong on the Switch version.

But while the game packs plenty of changes, it’s still the core game at heart. Super Mario 3D World is a rousing platforming adventure with co-op featuring four characters with relatively different power sets. Mario is the all-arounder, Luigi has his fluttery high-jump, Peach can float, and as mentioned, Toad is a little speedster. Finding your rhythm through this series of platforming stages as one of the characters is as engaging as it ever was, and now you can do it via online co-op play.

While Super Mario 3D World is the major re-release, it’s also only half of the package. The other part, Bowser’s Fury, is its own distinct game that marries parts of Super Mario Odyssey’s open-world design with power-ups and elements from 3D World. Rather than complete a series of distinct stages, you’ll be collecting new “Cat Shines” in a vast island environment and intermittently escaping the rage of Fury Bowser. Or even growing huge to battle him face-to-face. This new game is unlike either Mario Odyssey or 3D World. We’ll be showing and talking more about it and the package as a whole in the coming days with our review and launch coverage.

## The Medium Review
 - [https://www.youtube.com/watch?v=NuxMRbSWwAg](https://www.youtube.com/watch?v=NuxMRbSWwAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-27 00:00:00+00:00

The Medium is a terrifying but compelling exploration of duality, one that uses the horror of personal trauma to craft a memorable tale.

## This Cyberpunk 2077 Mod Adds Free Respecs and New Game Plus
 - [https://www.youtube.com/watch?v=HmD4Rg_akcs](https://www.youtube.com/watch?v=HmD4Rg_akcs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-27 00:00:00+00:00

The Respector mod lets you reset your attributes and perk points in CD Projekt Red's latest RPG.

The Cyberpunk 2077 community is quickly developing new content and handy tweaks for all sorts of things in the game, adding fresh elements to the game, changing the look of Night City, and introducing some useful quality-of-life adjustments. In the video above, we look at a mod that does the latter, offering you the opportunity to painlessly change the stats and specs of your version of protagonist V.

The Respector mod lets you adjust your character attributes and restore all your Perk points after you've spent them, allowing you to choose different distributions and try out various character builds. You can also create builds, share them with other players, and switch between them on the fly as you play. Respector also lets you transfer your character and equipment between playthroughs with its New Game Plus option, so you can try different life paths while maintaining the experience and gear you earned from other playthroughs. Check out the video above to see it all in action.

Respector: 
https://www.nexusmods.com/cyberpunk2077/mods/1263
Cyber Engine Tweaks: https://www.nexusmods.com/cyberpunk2077/mods/107

## Apex Legends Season 8 – Mayhem Gameplay Trailer
 - [https://www.youtube.com/watch?v=RPgFhhh3o38](https://www.youtube.com/watch?v=RPgFhhh3o38)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-26 00:00:00+00:00

Check out the all new Mayhem Gameplay Trailer for Apex Legends Season 8 coming this February, 2021!

## Cyberpunk 2077 SPOILER Chat - Cyberpunk Update
 - [https://www.youtube.com/watch?v=MRsmvhpsZto](https://www.youtube.com/watch?v=MRsmvhpsZto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-26 00:00:00+00:00

The GameSpot staff shares their unfiltered thoughts on CD Projekt Red's latest RPG, Cyberpunk 2077.

Now that Cyberpunk 2077 has been out in the wild for a few months, the GameSpot team is ready to dig in and give our full impressions of everything the game has to offer. Cyberpunk represents a huge world that changes somewhat based on your path through it, and Kallie, Jake, and Lucy come together on this Spoilercast to discuss how they went through the game, what they found, and what their impressions were as they got lost in the world of Night City.

Check out the video above for the full discussion, but be warned that nothing is off-limits--including side-missions and endings. Kallie, Jake, and Lucy go through their favorite moments in the game, what they liked and disliked about the characters, and how each of the endings struck them based on the story they uncovered. They also talk about the ways their lifepath choices impacted the game--or didn't.

