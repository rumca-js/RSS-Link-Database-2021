# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## The Swedish Strategy - Not Just a Failure
 - [https://www.youtube.com/watch?v=1WAwXed88sE](https://www.youtube.com/watch?v=1WAwXed88sE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-01-26 00:00:00+00:00

Life in Sweden is closer to being 'normal' than in most other countries. Calling it a success or failure at this stage, however, is premature.
Join my channel and become a member to enjoy perks https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz


Sources
The new Swedish law on pandemic measures: https://www.nytimes.com/2021/01/09/world/europe/sweden-coronavirus-restrictions.html
https://au.news.yahoo.com/lockdown-shy-sweden-passes-pandemic-105304024.html
https://www.euronews.com/2021/01/08/sweden-s-parliament-approves-law-to-allow-government-to-introduce-covid-19-measures

Sweden's strategy developing
https://www.wsj.com/articles/sweden-tries-to-isolate-covid-19-cases-without-a-lockdown-as-infections-surge-11602004646?mod=article_inline
European CDC on mask wearing
https://www.ecdc.europa.eu/en/publications-data/using-face-masks-community-reducing-covid-19-transmission 

Stanford study on lockdowns https://onlinelibrary.wiley.com/doi/10.1111/eci.13484

Sweden's response in spring
https://www.nytimes.com/2020/04/28/world/europe/sweden-coronavirus-herd-immunity.html
https://www.theguardian.com/world/commentisfree/2020/apr/21/sweden-covid-19-policy-trust-citizens-state
https://www.bloomberg.com/news/articles/2020-04-19/sweden-says-controversial-covid-19-strategy-is-proving-effective

World Health Organization on lockdowns:
https://www.who.int/news-room/q-a-detail/herd-immunity-lockdowns-and-covid-19

Critique of the Sweden's strategy:
https://time.com/5899432/sweden-coronovirus-disaster/
https://www.wsj.com/articles/long-a-holdout-from-covid-19-restrictions-sweden-ends-its-pandemic-experiment-11607261658
https://www.wsj.com/articles/scientist-behind-swedens-no-lockdown-policy-says-it-wasnt-strict-enough-11591196353?mod=article_inline

Stockholm's population: https://www.scb.se/en/finding-statistics/statistics-by-subject-area/population/population-composition/population-statistics/pong/tables-and-graphs/yearly-statistics--municipalities-counties-and-the-whole-country/population-in-the-country-counties-and-municipalities-on-31-december-2019-and-population-change-in-2019/ 

Credits:
Music by CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were used for news, critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

