# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Dictator Newsom Ends California Lockdown!?! What You Need To Know
 - [https://www.youtube.com/watch?v=WZzufBXVa-0](https://www.youtube.com/watch?v=WZzufBXVa-0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-01-27 00:00:00+00:00

Check out BLUblox, my favorite evidence based blue light glasses: https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

California dictator Gavin Newsom in California lockdowns! What do you need to know about the great governor’s decision to end the lockdowns? Obviously it’s 100% in the peoples best interest and nothing to do with his political game. You can trust us on that.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## When Cancel Culture Cancels Everything
 - [https://www.youtube.com/watch?v=_sKX2Gk7eFY](https://www.youtube.com/watch?v=_sKX2Gk7eFY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-01-26 00:00:00+00:00

Grab your Sleep Remedy Here - https://docparsley.com/jp

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here’s what it will be like when cancel culture cancels everything! Society will be better when everything is canceled by cancel culture, including culture. 

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

