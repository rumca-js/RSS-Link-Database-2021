# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Let's Build a Bang-for-the-Buck AMD Gaming PC!!
 - [https://www.youtube.com/watch?v=emlRd643NVI](https://www.youtube.com/watch?v=emlRd643NVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-27 00:00:00+00:00

Get a Free 32GB Flash Drive and 32GB Micro SD Card at Micro Center: https://rebrand.ly/v54ch

Get the best prices and best selection on PC hardware at Micro Center: https://rebrand.ly/4jjez

Check out the Micro Center Custom PC Builder (This PC): https://rebrand.ly/kk65g

Micro Center Custom Builds Service: https://micro.center/706bb

Build Parts:

AMD Ryzen 3 3100: https://rebrand.ly/bjmg8

Gigabyte A520M DS3H AMD AM4 mATX Motherboard: https://rebrand.ly/m4tjh

MSI Radeon RX 5700 XT Gaming X: https://rebrand.ly/5dzrm

Alternative GPU Options: https://rebrand.ly/ev7l5

G.Skill Trident Z RGB 16GB (2 x 8GB) DDR4-3200: https://rebrand.ly/u0erd

Inland Platinum 1TB SSD: https://rebrand.ly/b3pmf

NZXT C750 80 Plus Gold ATX Fully Modular Power Supply: https://rebrand.ly/ywyfz

NZXT H510 Tempered Glass Mid-Tower Computer Case: https://rebrand.ly/16djs

## RTX 3080 Mobile is… Complicated
 - [https://www.youtube.com/watch?v=z9fk9d6pry4](https://www.youtube.com/watch?v=z9fk9d6pry4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-26 00:00:00+00:00

Thanks to Gigabyte for sponsoring this video!
Check out the AERO 15 OLED XC at: https://www.newegg.com/product/34-233-374

Check out the AORUS 15G YC at: https://www.newegg.com/product/34-725-124

Nvidia's new RTX 3080 mobile GPU is the fastest you can get in a laptop, but Nvidia's marketing team hasn't made it easy for consumers to tell how fast each laptop will actually be.

Discuss on the forum: https://linustechtips.com/topic/1298608-rtx-3080-mobile-is%E2%80%A6-complicated/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

