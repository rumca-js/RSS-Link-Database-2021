# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## “The real pandemic” - who benefits from our breakdown?
 - [https://www.youtube.com/watch?v=f-ZaBPnGJVY](https://www.youtube.com/watch?v=f-ZaBPnGJVY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-27 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

The Coronavirus crisis poses the greatest threat to mental health since the second world war. But whilst mental health trusts continue to receive funding cuts, billionaires - who benefit from government wealth-friendly tax laws and loopholes - have enjoyed record profits. 

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

## Releasing Pain from the Body...
 - [https://www.youtube.com/watch?v=h3REs7M7PuY](https://www.youtube.com/watch?v=h3REs7M7PuY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-26 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

A clip from my Under The Skin podcast with Nick Ortner.
Nick is CEO of The Tapping Solution and creator of the Tapping Solution app, books and events. Tapping is a natural healing method also known as Emotional Freedom Techniques. It is a healing modality that combines ancient Chinese acupressure and modern psychology

You can listen to the rest of this podcast and all of my podcasts on Luminary:
http://luminary.link/russell

You can download the Tapping Solution app for free in the app store or Google Play - Nick has offered Under The Skin listeners 50% off the premium version - go to thetappingsolution.com/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

