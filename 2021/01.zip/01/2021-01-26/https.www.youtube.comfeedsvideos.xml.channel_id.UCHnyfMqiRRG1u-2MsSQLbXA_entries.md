# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## These Pools Help Support Half The People On Earth
 - [https://www.youtube.com/watch?v=YMDJA4UvXLA](https://www.youtube.com/watch?v=YMDJA4UvXLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-01-27 00:00:00+00:00

What are these electric blue ponds in the middle of the Utah desert? And why do they keep changing color?

Join Derek Muller (Veritasium) as he looks into the weird, bizarre, and seemingly inexplicable images found on Google Earth to discover what on Earth they actually are. It’s a travel vlog, documentary, and science show wrapped into one. It’s Pindrop.

0:00 Intro
0:29 Electric Blue Ponds
2:13 Finding The Truth
5:47 Importance Of Potash
8:41 Potash From Rocks
14:04 Safer Ways To Mine
15:02 Droning
17:28 Potash The Savior

