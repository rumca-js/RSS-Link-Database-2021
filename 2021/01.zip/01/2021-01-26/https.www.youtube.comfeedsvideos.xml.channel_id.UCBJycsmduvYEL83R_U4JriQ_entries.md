# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Only REAL "Pro" Smartphone?!
 - [https://www.youtube.com/watch?v=vLm68qbNjkU](https://www.youtube.com/watch?v=vLm68qbNjkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-01-27 00:00:00+00:00

Sony Xperia Pro is the only phone that truly deserves the "Pro" name... which is why you don't need it.

Why Don't People Buy Sony Smartphones? https://youtu.be/j7QwJ-M_GAI

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Rough by Jordyn Edmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Sony for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

