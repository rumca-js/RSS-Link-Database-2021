# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Dune (1984) - A Cinematic Fever Dream
 - [https://www.youtube.com/watch?v=gfNjFTSl7Nk](https://www.youtube.com/watch?v=gfNjFTSl7Nk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-27 00:00:00+00:00

Well, I did it. I watched the 1984 movie adaptation of Dune. It was... an experience. Let's talk about this vision of Frank Herbert's DUNE! 
The first 1000 people to use the link will get a free trial of Skillshare Premium Membership: https://skl.sh/danielgreene01212

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## HBO Harry Potter Show RUMOR!🪄 NEW Old Republic Game?🛰️ SAGA Returns💦-FANTASY NEWS
 - [https://www.youtube.com/watch?v=CmtoB3KmYfo](https://www.youtube.com/watch?v=CmtoB3KmYfo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-26 00:00:00+00:00

Let's do the fantasy news my dudes! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/


NEWS: 

00:00 Spider King: https://www.tor.com/2021/01/22/serial-box-will-publish-justin-c-keys-spider-king-miniseries/ 

00:47 New Dragonlance confirmed: https://m.facebook.com/photo.php?fbid=10159161859886369&id=503181368&set=a.73143126368&source=48&ref=m_notif&notif_t=group_highlights 

01:06 First Law Rumor Squashing: https://twitter.com/LordGrimdark/status/1352203812946239488?s=19 

02:21 The Combat Code Cover: https://www.reddit.com/r/Fantasy/comments/l4ot4d/the_combat_codes_new_cover_reveal_book_one_in_my/ 

03:03 Empire of the Vampire: https://twitter.com/misterkristoff/status/1352195488313868289 

03:33 Truth Of The Devine: https://www.themarysue.com/exclusive-cover-reveal-lindsay-elliss-truth-of-the-divine-pulls-us-in-with-a-supernova/ 

03:56 Embers of War: https://www.tor.com/2021/01/22/expanse-director-set-to-adapt-gareth-powells-embers-of-war/ 

04:53 Harry Potter Show Rumor: https://www.hollywoodreporter.com/live-feed/harry-potter-live-action-tv-series-in-early-development-at-hbo-max-exclusive 

05:46 SAGA Return: https://comicbook.com/comics/news/saga-comic-return-brian-k-vaughan-confirms/ 

06:11 Three Body Murder: https://variety.com/2021/biz/asia/three-body-problem-netflix-murder-suspect-rehearsed-1234887700/  

07:26 Kong VS Godzilla: https://www.youtube.com/watch?v=odM92ap8_c0 

08:20 Invincible Premier date: https://deadline.com/2021/01/robert-kirkmans-animated-series-invincible-premiere-date-amazon-clip-watch-1234678592/ 

09:07 Diablo Remake: https://screenrant.com/diablo-2-remake-blizzard-vicarious-visions-activision-develop/ 

09:14 Star Wars Old republic Game: https://thedirect.com/gaming/star-wars-knights-of-the-old-republic-new-video-game-studio

