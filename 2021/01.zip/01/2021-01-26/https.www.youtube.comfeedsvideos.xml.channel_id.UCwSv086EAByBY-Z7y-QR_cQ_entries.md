# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Mateusz Morawiecki zapowiada „Nowy Polski Ład”. Czego politycy nam nie powiedzą?
 - [https://www.youtube.com/watch?v=g54DfI1gAPE](https://www.youtube.com/watch?v=g54DfI1gAPE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-01-27 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
weforum.org - https://bit.ly/32t8u9N
gov.pl - http://bit.ly/2lVWjQr
---------------------------------------------------------------
✅źródła:
http://bit.ly/3a9dAv5
http://bit.ly/3chWZaY
http://bit.ly/3qS4rh2
https://bit.ly/36eHIE8
-------------------------------------------------------------
💡 Tagi: #Morawiecki #NowyPolskiŁad #ekologia
--------------------------------------------------------------

## Onet opublikował analizę wad karabinka Grot. W tle przetarg na karabinki dla ukraińskiej armii
 - [https://www.youtube.com/watch?v=h3ryi_SeZlI](https://www.youtube.com/watch?v=h3ryi_SeZlI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-01-27 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - do kolażu wykorzystano grafikę ze stron: 
terytorialsi.wp.mil.pl - http://bit.ly/3oq5CCJ
---------------------------------------------------------------
✅źródła:
https://bit.ly/39WJ3QW
http://bit.ly/3iNIvRw
http://bit.ly/3t1tFeQ
http://bit.ly/39lt285
http://bit.ly/3qMGCaC
---------------------------------------------------------------
💡 Tagi: #WOT #polityka #Grot
--------------------------------------------------------------

## Nadchodzą czasy oceniania naszych zachowań i nawyków. Czy będziemy przykładnymi obywatelami?
 - [https://www.youtube.com/watch?v=Oh9ycd1MFTY](https://www.youtube.com/watch?v=Oh9ycd1MFTY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-01-26 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
✅źródła:
http://bit.ly/2YcAE6t
https://bit.ly/2M9C7HV
http://bit.ly/3qS9uhO
http://bit.ly/2NvNtGV
https://bit.ly/39YHeDc
https://bit.ly/3b1Hnb8
https://bit.ly/3bApqRo
https://bit.ly/3i842Ek
https://bit.ly/34fvtGv
http://bit.ly/2M7xpLb
https://bit.ly/3btHDQv
---------------------------------------------------------------
💡 Tagi: #Ekologia #ZrównoważonyRozwój #WEF
--------------------------------------------------------------

