# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Godzilla vs Kong Trailer - Hilarious Insanity
 - [https://www.youtube.com/watch?v=jil_yrUC22I](https://www.youtube.com/watch?v=jil_yrUC22I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-01-27 00:00:00+00:00

With the release of the first trailer for Godzilla vs Kong, it's time to venture into the Monsterverse and break down this madness.

