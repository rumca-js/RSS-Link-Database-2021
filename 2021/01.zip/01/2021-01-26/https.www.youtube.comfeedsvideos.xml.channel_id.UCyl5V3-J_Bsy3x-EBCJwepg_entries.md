# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Apologetics, Debating Atheists, and Church History | Dr. James White Interview
 - [https://www.youtube.com/watch?v=S48hk3qaOo8](https://www.youtube.com/watch?v=S48hk3qaOo8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-26 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to James White, best known for debating Atheists, Catholics, and Muslims. He is the host of The Dividing Line Webcast, and Director of Alpha and Omega Ministries. He is the author of more than twenty books and an accomplished debater on subjects ranging from the King James Only controversy, Roman Catholicism, Islam, Calvinism and Mormonism.

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

