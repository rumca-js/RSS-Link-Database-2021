# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Valve's next VR projects are SCARILY similar to Sword Art Online
 - [https://www.youtube.com/watch?v=veVx0AuhHFw](https://www.youtube.com/watch?v=veVx0AuhHFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-01-27 00:00:00+00:00

Hello and welcome to Tuesday Newsday! Your number one resource for the entire weeks worth of VR news. Today is actually a CRAZY week for VR news. Between Valve announcing a partnership with a BCI company, new haptic gloves, Quest 2 news, and Doom Eternal maybe coming to VR... I hope you enjoy! 


My links-
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill


Sources-
https://www.roadtovr.com/bethesda-vr-pc-2021-project/
https://www.classification.gov.au/titles/project-2021a
https://www.roadtovr.com/valve-openbci-immersive-vr-games/
https://www.roadtovr.com/gabe-newell-brain-computer-interfaces-way-closer-matrix-people-realize/
https://www.tvnz.co.nz/one-news/new-zealand/gabe-newell-says-brain-computer-interface-tech-allow-video-games-far-beyond-human-meat-peripherals-can-comprehend
https://www.roadtovr.com/bethesda-vr-pc-2021-project/
https://vrscout.com/news/haptx-true-contact-haptic-gloves-vr/
https://vrscout.com/news/haptx-true-contact-haptic-gloves-vr/
https://haptx.com/virtual-reality/

