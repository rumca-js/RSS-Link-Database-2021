# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does IT: Alexander Brandon - Go Down (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=2EqeHzNKekU](https://www.youtube.com/watch?v=2EqeHzNKekU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-01-27 00:00:00+00:00

"Go Down" by Alexander Brandon for Unreal Tournament.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 19 channels
- 100% flawless playback not guaranteed (the IT replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does IT: Michiel van den Bos - The Course (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=ZE_Ed1jc3Ew](https://www.youtube.com/watch?v=ZE_Ed1jc3Ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-01-27 00:00:00+00:00

"The Course" by Michiel van den Bos for Unreal Tournament.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 18 channels
- 100% flawless playback not guaranteed (the IT replayer is not perfect)

Visit my channel for more Amiga music.

