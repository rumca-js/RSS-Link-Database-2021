# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## GameStonk - Power To The Gamblers (ft. Elon Musk & r/wallstreetbets)
 - [https://www.youtube.com/watch?v=H-Iky-tF9go](https://www.youtube.com/watch?v=H-Iky-tF9go)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-27 00:00:00+00:00

*HUGE DISCLAIMER* I do NOT own any gamestop stock (although I wish I had bought in early), but I DO NOT advise it now or ever. This is a meme tribute to all the idiots over at r/wallstreetbets. I REPEAT, do NOT buy GameStop unless you are prepared to lose 100% of the money. It’s straight up gambling at this point.
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.
#gamestop #elonmusk #coffeezilla

## I Bought Dan Lok's House and I'm Never Selling It - Earth 2.0
 - [https://www.youtube.com/watch?v=ZaijNcRuzsQ](https://www.youtube.com/watch?v=ZaijNcRuzsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-27 00:00:00+00:00

I"M NEVER SELLING. DAN LOK'S HOUSE IS MINE AND I'M KEEPING IT! DAN LOK literally could offer me millions of $$$ and I would refuse. 

A REVIEW OF EARTH 2
VERDICT ON Earth2.io 
This is NOT an investment. MOST people will NOT make their money back and you should look at it as an investment into an extremely RISKY idea with no alpha and a young development team. 

twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Brian Rose Was 'Arrested' and Is LYING About What Happened
 - [https://www.youtube.com/watch?v=dD_RraEimH8](https://www.youtube.com/watch?v=dD_RraEimH8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-26 00:00:00+00:00

Brian Rose Is the King of the 🤡🤡🤡's
But  now he's using this "arrest" (it was just a fine) to try to stir up sympathy. He's lying about why though.. it wasn't for campaigning, it was for legitimately being irresponsible. 

Articles about brian: 
https://www.bbc.co.uk/news/uk-england-london-55796176
https://www.dailymail.co.uk/news/article-9184367/London-mayor-candidate-Brian-Rose-fined-200-breaking-lockdown-rules.html 

Follow me
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

