# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Joensuu 1685 - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=iFC7_Q9n2UU](https://www.youtube.com/watch?v=iFC7_Q9n2UU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-01-27 00:00:00+00:00

http://KEXP.ORG presents Joensuu 1685 sharing a performance recorded exclusively for KEXP and talking to Kevin Cole. Recorded January 19, 2021.

Songs:
Nothingness
Light in The heart of our Town
Sweet savior
All around you
The Most Luckiest Man

Session recorded at G Livelab in Helsinki
Producer: Tero Ahonen, Jonas Verwijnen
DOP & Design: Tero Ahonen 
Cameras: Aapo Niininen, Mikko Mällinen
Live Video Mixing: Oskari Halsti
Lights: Anna-Mari Nousiainen
Video Editing: Jim Beckmann (KEXP)
Audio Recording: Sami Ahonen, Kimmo Antikainen
Audio Mixing: Kevin Suggs (KEXP) 

Band:
Vocals / Guitar: Mikko Joensuu
Bass: Risto Joensuu
Drums: Markus Joensuu
Backing Vocals / Keyboards: Tapio Viitasaari

https://joensuu1685.bandcamp.com
https://www.glivelab.fi
http://kexp.org

## Liraz - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=pBq1g-aw5iU](https://www.youtube.com/watch?v=pBq1g-aw5iU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-01-26 00:00:00+00:00

http://KEXP.ORG presents Liraz performing live at Anova Studios in Tel Aviv, recorded exclusively for KEXP.

Songs:
Bia Bia 
Zan Bezan 
Mastam
Injah
Time (You and I) (Khruangbin cover)
 
Performance Recorded at Anova Studios in Tel Aviv
Directed & Edited by Ben Kirschenbaum
Filmed by Daniel Vogman, Ben Kirschenbaum
Recording engineer and mixing - Yaron Sarel
Assistant recording engineer - Ran Yeshurun
 
Guitar - Uri Brauner Kinrot
Bass - Amir Sadot
Keyboard - Yael Selinger
Violin - Lia Sherman
Drums - Roy Chen
 
Production - Dan Basman, Bar Zavada
Artistic consultant - Jonatan Sharoni
Styling / Art by Corine Swed and Gaya Kesten

http://instagram.com/liraz_naz
http://kexp.org

