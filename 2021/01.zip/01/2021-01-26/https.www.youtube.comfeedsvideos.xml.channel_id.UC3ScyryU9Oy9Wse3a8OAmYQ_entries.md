# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## How Charlottesville Led to the Capitol Attack | "Trump's American Carnage" | FRONTLINE
 - [https://www.youtube.com/watch?v=Vy4F0VSbBkQ](https://www.youtube.com/watch?v=Vy4F0VSbBkQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2021-01-26 00:00:00+00:00

A scene from the FRONTLINE documentary "Trump’s American Carnage" shows how the 2017 Unite the Right rally and President Trump’s response foreshadowed Jan. 6, 2021.

Subscribe on YouTube: http://bit.ly/1BycsJW

Watch "Trump's American Carnage" in full starting Jan. 26, 2021. From veteran FRONTLINE filmmaker Michael Kirk and his team, the documentary tells the inside story of how Trump’s presidency laid the groundwork for bitter division, violence and insurrection: https://to.pbs.org/2MuZITB

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: http://to.pbs.org/hxRvQP 

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation; Park Foundation; the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation; and Koo and Patricia Yuen.

