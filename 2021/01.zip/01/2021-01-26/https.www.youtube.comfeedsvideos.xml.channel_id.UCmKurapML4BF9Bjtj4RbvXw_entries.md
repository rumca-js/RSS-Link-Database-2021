# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Better Days - The Piano Guys (Lyric Video)
 - [https://www.youtube.com/watch?v=Te-nyCZoLRM](https://www.youtube.com/watch?v=Te-nyCZoLRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2021-01-26 00:00:00+00:00

► STREAM on all platforms: http://thepianoguys.lnk.to/tpg10
► TPG SHEET MUSIC https://smarturl.it/TPG10_SheetMusic
► BUY our ALBUM "10" here: https://smarturl.it/TPG-Album-10
► Get ALL our ALBUMS here: https://thepianoguys.com/collections/albums
► Learn about our beliefs here: https://smarturl.it/TPG_Beliefs

[Al van der Beek here] This song came to me as an answer to a prayer. A few months ago my family and I were going through some very emotional trials and even though I knew they would eventually pass it was difficult for me to see beyond our current circumstances. One morning as I was sitting in the studio feeling the weight of everything that was going on I felt prompted to get on my knees and pray. I didn’t want to pray, but the feeling that I should pray was very insistent. After several strong impressions, that I tried my best to ignore, the following quote came to mind: “If you don't feel like praying, pray until you do!”. I definitely didn’t feel like praying but I reluctantly gave in and got on my knees and started to pray out loud. I started to pour out all the desires and emotions of my heart to God. I didn’t ask Him to take away my trials, but I pleaded with Him to reassure me in that very moment that I would see things as He sees them and that I could have sufficient faith and trust that we would get through this as a family. After my prayer I sat there in tears..waiting..listening.. pondering and feeling overwhelmed with gratitude and love. 

I was then prompted to watch a video, titled “Good Things to Come” — You can watch it here https://youtu.be/8nczw6xHJ0I - I have watched and shared this video many times, but this time I watched it with a fresh pair of eyes and an entirely new perspective and understanding. Immediately my mind was flooded with ideas and inspiration and I started to write them all down.

Believe in good things to come
There will be better days
Don’t you quit
Keep walking
When you’re drowning, keep swimming
When you’re losing keep winning  
Keep trying
Help and happiness ahead
Some blessings come soon, some come late, and some come in heaven
Do you believe in good things to come?
Don’t chase the storms
Follow the sun
Follow the Son. 

I stopped thinking and I started writing. The lyrics and the music just came to me and two days later the entire song was finished. I knew that this was God’s way of letting me know that He was listening and that He cared and understood what my family and I were going through. It wasn’t a life or death situation, but the amazing thing was that it mattered to Him. His answer to my prayer was so specific and personal there is no way I can take credit for writing this on my own. I hope this will encourage and uplift anyone who is going through a difficult time right now. Even amidst the most challenging of times we can all have the reassurance and confidence that there will always be good things to come and “Better Days”. 

Lyric video created by https://lyricvids.com

Credits:
Written by Al van der Beek & Steven Sharp Nelson
Al van der Beek, vocals
Steven Sharp Nelson, cello
All other instruments produced and performed by Al van der Beek
Recorded, mixed & mastered by Al van der Beek at TPG Studio in Utah

Who are The Piano Guys?
https://thepianoguys.com/pages/about

