# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: 4-Mat - Limitations (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=hsVvxyMLGsU](https://www.youtube.com/watch?v=hsVvxyMLGsU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-01-19 00:00:00+00:00

"Limitations" by 4-Mat (Matthew Simmonds). Art "Amiga in Stereo" (1988, unsure) by Jaffe. Headphones recommended.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 4 channel ProTracker module
- 14-bit calibrated Paula output
- Infinite oversampling with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled

Visit my channel for more Amiga music.

