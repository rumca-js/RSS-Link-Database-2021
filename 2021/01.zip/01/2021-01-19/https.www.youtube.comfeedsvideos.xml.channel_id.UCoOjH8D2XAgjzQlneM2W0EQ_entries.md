# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Why do Chinese Billionaires Keep Disappearing?
 - [https://www.youtube.com/watch?v=qyMsrgI7-_s](https://www.youtube.com/watch?v=qyMsrgI7-_s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-01-20 00:00:00+00:00

Healthy cereal that tastes too good to be true: Get $5 OFF with code JAKETRAN at https://magicspoon.com/jaketran 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Check out @GeneralSpalding’s book, Stealth War: How China Took Over While America's Elite Slept: https://jake.yt/stealthwar 

And check out his YouTube channel here: https://jake.yt/spalding 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG: @jaketran.io // http://bit.ly/jt-ig
👨‍👦‍👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🌐 Best affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/38TTLZf

-----------------------
Only two things happen to chinese billionaires: jail or... December 10th 2015 - Guo Guangchang, AKA as the Warren Buffet of China, disappears. Guo founded the Fosun Group, a mega conglomerate and investment company with over $100 billion in assets. He is the 17th richest man in China in 2015. And yet, on December 10th, 2015, Fosun executives reported that they lost contact with their boss.

January 7th, 2016, almost a month after Guo’s disappearance sent shockwaves through the Chinese business community - Zhou Chengjian, billionaire fashion entrepreneur also disappears. Zhou founded one of China’s best known fashion brands, Meters/bonwe making him the 62nd richest man in China in 2015. And yet, on January 7th, 2016, the company said that they were unable to reach him or the secretary of the board.

January, 2017 - billionaire financier, Xiao Jianhua, who has ties to the Xi Jingping family, gets rolled away in a wheelchair with his head covered by “Chinese public security agents - he was not known to use a wheelchair. Xiao controls the Tomorrow Group, a holdings company with interests in insurance companies, banks, and real estate developers. At the time, he had a net worth of $6b. Later, Xiao called his family to tell them he was taken to the Mainland but that he was fine.

March, 2020 - real estate mogul, Ren Zhiqiang [chi chiang] posted a brutal essay online hating on the great leader and the Chinese Communist Party’s handling of the virus. So starting on March 12th, Ren was understandably never heard from again. And his Weibo account, which had 37 million followers - is now deleted.

October 24th, 2020 - Jack Ma delivers a speech at the Bund Finance Summit in Shanghai. Since then, he’s nowhere to be found. With the only clue to his whereabouts being a three paragraph article from CNBC stating that “the billionaire is not missing. Instead, Ma has been lying low for the time being”

So the question remains - why do Chinese billionaires keep disappearing?

If you’re an aspiring entrepreneur in China, why would you want to start a business if you know that they can take away everything in a moment's notice, and make you disappear? What is the motivation?

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Transcend Visuals, LLC. All rights reserved.

Blue Wednesday, Shopan - Murmuration https://chll.to/3b6babb6 

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in.

