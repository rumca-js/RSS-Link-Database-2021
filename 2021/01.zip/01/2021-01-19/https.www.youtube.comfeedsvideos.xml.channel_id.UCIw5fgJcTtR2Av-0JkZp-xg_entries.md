# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "You Sonofa..." (Instrumental Mix)
 - [https://www.youtube.com/watch?v=XBh-GHWDWzU](https://www.youtube.com/watch?v=XBh-GHWDWzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-01-20 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Making of: https://youtu.be/OVehmlO-Kw8
Visuals by Christopher Huppertz: https://www.youtube.com/user/HuhnKunst

## Dillon You Sonofa... (Full Song)
 - [https://www.youtube.com/watch?v=RiPhTsGTqwY](https://www.youtube.com/watch?v=RiPhTsGTqwY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-01-20 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong 
Watch the making-of: https://youtu.be/OVehmlO-Kw8

Dutch gives a solid manshake to Dillon in Predator (Remixed)

