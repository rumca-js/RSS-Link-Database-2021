# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## If Canadian Winter Had A Video Game
 - [https://www.youtube.com/watch?v=PUOF0LMYkdk](https://www.youtube.com/watch?v=PUOF0LMYkdk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-01-19 00:00:00+00:00

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

