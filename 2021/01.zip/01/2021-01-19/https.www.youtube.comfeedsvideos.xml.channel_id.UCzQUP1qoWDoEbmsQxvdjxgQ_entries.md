# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Travis Walton Remembers Encounter with Aliens
 - [https://www.youtube.com/watch?v=QwfJIFH3WMY](https://www.youtube.com/watch?v=QwfJIFH3WMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-19 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1597 with Travis Walton. https://open.spotify.com/episode/0mCfpeY0Ga4meTanFzOkkL?si=hs2f4lNLRsel88qTYTGbyQ

## Travis Walton Tells His Story of Alien Abduction
 - [https://www.youtube.com/watch?v=DsiKEBAFmm4](https://www.youtube.com/watch?v=DsiKEBAFmm4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-19 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1597 with Travis Walton. https://open.spotify.com/episode/0mCfpeY0Ga4meTanFzOkkL?si=hs2f4lNLRsel88qTYTGbyQ

## Travis Walton's Problem with "Theories" on Aliens
 - [https://www.youtube.com/watch?v=C66l3u7PhwQ](https://www.youtube.com/watch?v=C66l3u7PhwQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-19 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1597 with Travis Walton. https://open.spotify.com/episode/0mCfpeY0Ga4meTanFzOkkL?si=hs2f4lNLRsel88qTYTGbyQ

