# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Comedian Dustin Nickerson On Why We Need To Make Fun Of Both Sides
 - [https://www.youtube.com/watch?v=5zIRwH7x6zE](https://www.youtube.com/watch?v=5zIRwH7x6zE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-20 00:00:00+00:00

On The Babylon Bee Podcast, Comedian Dustin Nickerson speaks on performing stand up comedy during the Trump era and why we need to be making fun of both sides of the political spectrum. 

See the full show here: https://youtu.be/j_6-hG-qvPg

Subscribe to The Babylon Bee to support the politically homeless. 

Hit the bell to get your daily dose of fake news that you can trust.

## A PSA To Rioters From The Babylon Bee
 - [https://www.youtube.com/watch?v=sKsL86miWdg](https://www.youtube.com/watch?v=sKsL86miWdg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-19 00:00:00+00:00

A PSA To Rioters From The Babylon Bee

## Dustin Nickerson Interview: Former Youth Pastor/Current Stand Up Comic
 - [https://www.youtube.com/watch?v=j_6-hG-qvPg](https://www.youtube.com/watch?v=j_6-hG-qvPg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-19 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to comedian Dustin Nickerson who hails from Seattle, but suffers in Southern California. Dustin was married at 19 and 15 years later has 3 kids, so he has plenty of insight on parenting, marriage, and being generally annoyed by people. Dustin has a new special on Amazon called OVERWHELMED. Topics covered are Dustin’s start in stand up, new lockdowns, and working as a youth pastor. 

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

