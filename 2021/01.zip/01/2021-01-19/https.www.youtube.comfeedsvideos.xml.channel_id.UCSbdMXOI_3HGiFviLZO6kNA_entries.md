# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The Oculus Quest 2 gets a HUGE Update for QoL
 - [https://www.youtube.com/watch?v=EzHjucDrNsY](https://www.youtube.com/watch?v=EzHjucDrNsY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-01-19 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. Lots to cover this week from some awesome experimental VR displays from Facebook,  a little more from CES, Viveport, and of course, a huge Oculus Quest and Quest 2 update that will make your life using those devices WAY better. 

That and so much more I hope you enjoy this weeks video!
Sorry for any mistakes, this video was actually really hard to edit, I have been quite sick lately with a bad ear infection, so If there are weird audio issues or problems, I likely literally couldn't hear them lol.

My links-
2nd Channel:
https://youtu.be/-ub19xtY3AI
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill


sources-
https://www.theringer.com/2021/1/12/22226387/virtual-reality-playstation-xbox-oculus
https://www.geekwire.com/2021/valve-recaps-record-2020-steam-looks-ahead-china-launch-year/
https://uploadvr.com/ces-2021-vr-announcements/
https://www.roadtovr.com/viveport-developers-revenue-share-increase-2021/
https://www.roadtovr.com/multi-user-app-sharing-oculus-quest-2/
https://www.roadtovr.com/valve-steam-vr-2020-new-users-revenue/
https://www.roadtovr.com/mechanical-display-shifting-sde-reduction-facebook-reality-labs-research/
https://vrscout.com/news/panasonic-automotive-ar-hud-windshield/
https://na.panasonic.com/explore/product-service/in-car-experience

