# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Charizard
 - [https://www.youtube.com/watch?v=66FxaglBIJo](https://www.youtube.com/watch?v=66FxaglBIJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-01-20 00:00:00+00:00

Install Raid for Free IOS/ANDROID/PC: https://pl.go-ga.me/jo7ycver and get a special starter pack. Available only for the next 30 days

Patreon ►
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Charizard toon:

Additional Animation ► 
Arislaretis
Ollie Kremer

BGs ► 
Zeedox

Sound ►
Justin Greger

Music ►
Tom Ryan

VO ► 
Maxmoefoe - Charizard
Meatcanyon - Enemy Trainer
Tom - Ash

Raid Ad:

Additional Animation ► 
Blair Lawrence

Doom Tower 3D Work ►
Taterman

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/b5ekXbK

