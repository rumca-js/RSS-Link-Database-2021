# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Isolated Tracks Episode 5: Ángel de los Muertos by The Dip
 - [https://www.youtube.com/watch?v=Eua6XyI-tmc](https://www.youtube.com/watch?v=Eua6XyI-tmc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-01-19 00:00:00+00:00

In this episode of Isolated Tracks we talk to Jacob Lundgren from Seattle band, The Dip. KEXP Audio Producer Julian Martlew dissects the sounds that make up the song "Ángel de los Muertos" from the album "The Dip Plays It Cool"  

To watch the video and hear the full song: https://www.youtube.com/watch?v=8fM2H1mraE0
  @TheDipMusic  

http://kexp.org

