# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## People Who Are Into Fasting
 - [https://www.youtube.com/watch?v=8GW7H5angeY](https://www.youtube.com/watch?v=8GW7H5angeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-01-19 00:00:00+00:00

Grab your copy of Dave's new book at https://fastthisway.com/

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

What people who are into fasting are like. Ever wonder how to go on a fast and find the right amount of balance by being as extreme as possible? This video will teach you everything you need to know about fasting.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

