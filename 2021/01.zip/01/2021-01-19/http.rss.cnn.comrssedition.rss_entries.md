# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Watch Biden's remarks at Covid-19 memorial
 - [https://www.cnn.com/videos/politics/2021/01/19/biden-remarks-covid-national-memorial-tapper-phillip-bts-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/biden-remarks-covid-national-memorial-tapper-phillip-bts-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 23:37:29+00:00

President-elect Joe Biden and Vice President-elect Kamala Harris honored the 400,000 people who have lost their lives to the Covid-19 pandemic with a national Covid-19 memorial. CNN's Jake Tapper and Abby Phillip discuss the significance of this over a year into the pandemic, and one day ahead of Biden's inauguration.

## Bitter Trump skips chance to say splashy, high-profile farewell
 - [https://www.cnn.com/collections/intl-trump-biden-0118/](https://www.cnn.com/collections/intl-trump-biden-0118/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 22:39:45+00:00



## Trump administration leaves Biden with 'confusing' Covid-19 vaccine numbers
 - [https://www.cnn.com/2021/01/19/health/trump-biden-covid-19-vaccine-numbers-bn/index.html](https://www.cnn.com/2021/01/19/health/trump-biden-covid-19-vaccine-numbers-bn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 22:39:21+00:00



## Wow! She actually said that': Cooper reacts to Fox Business host's false riot claim
 - [https://www.cnn.com/videos/business/2021/01/19/maria-bartiromo-fox-news-capitol-riot-max-boot-cooper-vpx.cnn](https://www.cnn.com/videos/business/2021/01/19/maria-bartiromo-fox-news-capitol-riot-max-boot-cooper-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 22:07:48+00:00

On her Fox Business show, Maria Bartiromo falsely claimed that the mob that stormed the US Capitol was "infiltrated" by Democrats who dressed in MAGA clothes. CNN's Anderson Cooper and global affairs analyst Max Boot discuss.

## CNBC host reveals why he left Fox News
 - [https://www.cnn.com/videos/media/2021/01/19/shepard-smith-fox-news-amanpour-vpx.cnn](https://www.cnn.com/videos/media/2021/01/19/shepard-smith-fox-news-amanpour-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 22:07:29+00:00

Former Fox News host Shepard Smith discusses his time at the network and why he eventually left.

## CNN explains why Biden's flight to DC is so unusual
 - [https://www.cnn.com/videos/politics/2021/01/19/biden-lands-washington-joint-base-andrews-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/biden-lands-washington-joint-base-andrews-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 21:40:28+00:00

President-elect Joe Biden arrives at Joint Base Andrews in a private plane ahead of Inauguration Day.

## Pompeo uses taxpayer-funded Twitter account to attack multiculturalism
 - [https://www.cnn.com/2021/01/19/politics/pompeo-multiculturalism-tweet/index.html](https://www.cnn.com/2021/01/19/politics/pompeo-multiculturalism-tweet/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 21:39:25+00:00

With one day left in his tenure, Secretary of State Mike Pompeo took to his taxpayer-funded Twitter account and denounced multiculturalism, saying it is "not who America is."

## Keilar rolls the tape on the survivors of Trump's administration
 - [https://www.cnn.com/videos/politics/2021/01/19/survivors-of-trump-administration-keilar-roll-the-tape-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/survivors-of-trump-administration-keilar-roll-the-tape-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 20:52:46+00:00

CNN's Brianna Keilar rolls the tape on officials who have survived the past four years with the Trump administration and other officials who did not make it to the finish line.

## Biden gives emotional speech before departing for Washington
 - [https://www.cnn.com/videos/politics/2021/01/19/biden-emotional-speech-delaware-full-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/biden-emotional-speech-delaware-full-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 19:29:16+00:00

President-elect Joe Biden gave an emotional speech in Delaware before he departs for Washington ahead of his inauguration tomorrow.

## Chef arrested after images of sexually suggestive cakes at exclusive Egyptian club go viral
 - [https://www.cnn.com/2021/01/19/africa/egypt-arrest-cakes-scli-intl/index.html](https://www.cnn.com/2021/01/19/africa/egypt-arrest-cakes-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 18:31:26+00:00

Egyptian authorities have arrested a pastry chef for baking cakes with genital-shaped toppings after images of them went viral on social media.

## McConnell says Capitol rioters were fed lies
 - [https://www.cnn.com/videos/politics/2021/01/19/mitch-mcconnell-rioters-fed-lies-provoked-by-president-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/mitch-mcconnell-rioters-fed-lies-provoked-by-president-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 18:01:31+00:00

Sen. Mitch McConnell (R-KY) spoke on the floor of the Senate for the first time since a deadly riot at the US capitol and said that the mob who invaded the building were "fed lies and provoked by the President."

## Without Australia, China's economic recovery could grind to a halt
 - [https://www.cnn.com/2021/01/19/economy/china-australia-iron-ore-intl-hnk/index.html](https://www.cnn.com/2021/01/19/economy/china-australia-iron-ore-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 17:45:29+00:00

China and Australia spent much of last year in a tense standoff on trade. But as the recovery of the world's second largest economy gathers pace, China needs more iron ore and Australia is still its main supplier.

## Harry Brant, model and son of Stephanie Seymour and Peter Brant, has died
 - [https://www.cnn.com/2021/01/19/entertainment/harry-brant-dead/index.html](https://www.cnn.com/2021/01/19/entertainment/harry-brant-dead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 17:43:46+00:00

Harry Brant, a model and entrepreneur, has died, his parents said in a statement obtained by CNN.

## Teen jailed for breaking Covid-19 quarantine speaks out
 - [https://www.cnn.com/videos/us/2021/01/19/skylar-mack-gma-interview-ga-teen-cayman-islands-jailed-covid-quarantine-orig-mg.cnn](https://www.cnn.com/videos/us/2021/01/19/skylar-mack-gma-interview-ga-teen-cayman-islands-jailed-covid-quarantine-orig-mg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 17:40:22+00:00

US college student Skylar Mack spoke to Good Morning America after spending more than a month in jail for breaking Covid-19 quarantine rules in the Cayman Islands.

## New York Mets fire general manager after he reportedly sent explicit pictures to female reporter
 - [https://www.cnn.com/2021/01/19/sport/jared-porter-new-york-mets-firing-spt-intl/index.html](https://www.cnn.com/2021/01/19/sport/jared-porter-new-york-mets-firing-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 17:29:45+00:00

The New York Mets have fired general manager Jared Porter after he reportedly sent explicit pictures to a female reporter in 2016.

## Two Spirit Airlines agents injured, one hospitalized following carry-on dispute with passengers
 - [https://www.cnn.com/travel/article/spirit-airlines-dispute-trnd/index.html](https://www.cnn.com/travel/article/spirit-airlines-dispute-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 16:52:47+00:00

Two Spirit Airlines agents were injured and one was hospitalized after a dispute over carry-on bags with three passengers turned violent on Sunday, according to a Spirit Airlines spokesman.

## See Putin take part in traditional icy Epiphany dip
 - [https://www.cnn.com/videos/world/2021/01/19/putin-russia-icy-epiphany-dip-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/01/19/putin-russia-icy-epiphany-dip-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 16:46:11+00:00

Russian President Vladimir Putin took a bracing dip at his suburban estate Novo-Ogaryovo on January 19 for an Orthodox Christian ritual which marks the feast of the Epiphany.

## India achieves stunning Test victory over Australia with record-breaking run chase
 - [https://www.cnn.com/2021/01/19/sport/india-australia-test-cricket-spt-intl/index.html](https://www.cnn.com/2021/01/19/sport/india-australia-test-cricket-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 14:46:08+00:00

A record-breaking run chase at the Gabba saw India topple Australia to take an unlikely 2-1 series victory.

## Seychelles opens to Covid-vaccinated travelers
 - [https://www.cnn.com/travel/article/seychelles-opens-vaccinated-travelers/index.html](https://www.cnn.com/travel/article/seychelles-opens-vaccinated-travelers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 14:45:33+00:00

The Seychelles has reopened its borders and dropped quarantine requirements to all travelers who've been vaccinated against Covid-19.

## Country that refused to lock down learns a hard lesson
 - [https://www.cnn.com/videos/world/2021/01/19/sweden-backtracks-covid-19-approach-coronavirus-foster-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/01/19/sweden-backtracks-covid-19-approach-coronavirus-foster-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 13:05:50+00:00

What's now mundane for much of the world is remarkable for Sweden: government-issued mandates on limited store capacity. Once lionized by anti-lockdown advocates, Sweden now has a new law granting the government power to do things the country previously refused to do. CNN's Max Foster reports.

## A seesaw for kids on the US-Mexico border wins Beazley Design of the Year
 - [https://www.cnn.com/style/article/beazley-design-2020-winners/index.html](https://www.cnn.com/style/article/beazley-design-2020-winners/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 11:27:42+00:00

"Teeter-Totter Wall," a temporary interactive installation designed by California-based architects Ronald Rael and Virigina San Fratello, has won the 2020 Beazley Design of the Year, an annual award and exhibition run by London's Design Museum.

## Scottish fishermen say 'Brexit carnage' threatens to kill their business
 - [https://www.cnn.com/2021/01/18/business/scotland-fishermen-downing-street-brexit/index.html](https://www.cnn.com/2021/01/18/business/scotland-fishermen-downing-street-brexit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 09:57:20+00:00

Scottish fishermen parked their trucks near UK Prime Minister Boris Johnson's office at 10 Downing Street on Monday to protest post-Brexit red tape they say has made it almost impossible to sell British seafood to the European Union.

## California becomes first US state to surpass 3M Covid-19 cases
 - [https://www.cnn.com/world/live-news/coronavirus-pandemic-vaccine-updates-01-19-21/index.html](https://www.cnn.com/world/live-news/coronavirus-pandemic-vaccine-updates-01-19-21/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 09:29:54+00:00



## Jailed for life over plot to behead police officer, Britain's youngest convicted terrorist is now 'suitable for release'
 - [https://www.cnn.com/2021/01/19/uk/rxg-anzac-day-parole-release-intl-hnk/index.html](https://www.cnn.com/2021/01/19/uk/rxg-anzac-day-parole-release-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 09:20:28+00:00

Britain's youngest convicted terrorist, who was sentenced to life in prison for masterminding a plot to behead an Australian police officer in broad daylight in 2015, can now be set free, a parole board ruled on Monday.

## 6.4 quake strikes Argentina's San Juan province, no tsunami warning issued
 - [https://www.cnn.com/2021/01/18/americas/argentina-san-juan-earthquake-intl-hnk/index.html](https://www.cnn.com/2021/01/18/americas/argentina-san-juan-earthquake-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 08:57:15+00:00

A magnitude 6.4 earthquake has struck Argentina's west-central province of San Juan on Monday night, according to a preliminary report from the United States Geological Survey.

## Police recover 500-year-old stolen copy of Leonardo da Vinci's 'Salvator Mundi'
 - [https://www.cnn.com/style/article/salvator-mundi-leonardo-da-vinci-copy-found/index.html](https://www.cnn.com/style/article/salvator-mundi-leonardo-da-vinci-copy-found/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 08:40:01+00:00

A 16th-century copy of Leonardo da Vinci's "Salvator Mundi," the world's most expensive painting, has been recovered by police after it was stolen from a museum in Naples.

## How Trump allies stoked the flames ahead of Capitol riot
 - [https://www.cnn.com/collections/intl-capitol-riots-0118/](https://www.cnn.com/collections/intl-capitol-riots-0118/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 08:24:21+00:00



## Rand Paul's dire prediction for the GOP
 - [https://www.cnn.com/2021/01/18/politics/rand-paul-senate-conviction-trump-gop/index.html](https://www.cnn.com/2021/01/18/politics/rand-paul-senate-conviction-trump-gop/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 08:14:37+00:00

Sometime shortly after President-elect Joe Biden is sworn in as the 46th President of the United States on Wednesday, the Senate will likely begin the impeachment trial of soon-to-be-former President Donald Trump.

## More than 60% of all US Covid-19 cases were reported since Election Day. Now experts warn a variant could further fuel spread
 - [https://www.cnn.com/2021/01/19/health/us-coronavirus-tuesday/index.html](https://www.cnn.com/2021/01/19/health/us-coronavirus-tuesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 08:09:30+00:00

The US has just surpassed 24 million Covid-19 cases -- and more than 60% of them have been reported since Election Day.

## Navalny urges supporters to 'take to the streets' as he's detained for a month
 - [https://www.cnn.com/collections/navalny-return-intl/](https://www.cnn.com/collections/navalny-return-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 07:53:39+00:00



## Opinion: Why Putin wants to keep Navalny locked up
 - [https://www.cnn.com/2021/01/19/opinions/navalny-putin-russia-arrest-bociurkiw/index.html](https://www.cnn.com/2021/01/19/opinions/navalny-putin-russia-arrest-bociurkiw/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 07:45:39+00:00

With Alexei Navalny back in Russia five months after surviving a poisoning with the nerve agent Novichok, his courageous return presented Russian President Vladimir Putin -- who Navalny believes ordered his killing -- with two choices: allow the high-profile activist to continue to be a thorn in his side or lock him up in the hopes that he fades into obscurity.

## China is hitting back at criticism of its vaccines with a dangerous disinformation campaign
 - [https://www.cnn.com/collections/intl-covid-0118/](https://www.cnn.com/collections/intl-covid-0118/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 07:15:57+00:00



## Singapore Airlines hopes to be world's first fully-vaccinated airline
 - [https://www.cnn.com/travel/article/singapore-airlines-covid-vaccination-wellness-intl-hnk/index.html](https://www.cnn.com/travel/article/singapore-airlines-covid-vaccination-wellness-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 06:14:44+00:00

Singapore's national carrier is hoping to become the world's first airline to get all of its crew members vaccinated against Covid-19.

## Analysis: Trump leaves America at its most divided since the Civil War
 - [https://www.cnn.com/2021/01/19/politics/trump-divided-america-civil-war/index.html](https://www.cnn.com/2021/01/19/politics/trump-divided-america-civil-war/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 05:49:24+00:00

Donald Trump ends his tumultuous presidency with the nation confronting the greatest strain to its fundamental cohesion since the Civil War.

## Trump is handing Biden a more dangerous world. There's only so much the new president can undo
 - [https://www.cnn.com/2021/01/19/world/donald-trump-biden-danger-intl/index.html](https://www.cnn.com/2021/01/19/world/donald-trump-biden-danger-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 05:03:16+00:00

The recent attack on the US Capitol served as a sobering wake-up call: Not only have the Trump years left America deeply divided, they've also transformed it into a theater of political violence.

## Analysis: Trump's legacy will take years to purge from the American psyche
 - [https://www.cnn.com/2021/01/19/politics/donald-trump-presidency/index.html](https://www.cnn.com/2021/01/19/politics/donald-trump-presidency/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 05:00:21+00:00

After four exhausting years of raging tweets, lies, "fire and fury" rants and orders for far-right extremists to "stand back and stand by," it's almost over.

## A missing teen snowmobiler built a snow cave to survive until rescuers arrived
 - [https://www.cnn.com/2021/01/18/us/snowmobile-missing-south-cariboo-trnd/index.html](https://www.cnn.com/2021/01/18/us/snowmobile-missing-south-cariboo-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 04:31:21+00:00

After going missing while on a snowmobile, a Canadian teenager managed to survive by building a snow cave to stay in until he was found.

## China and WHO acted too slowly to contain Covid-19, says independent panel
 - [https://www.cnn.com/2021/01/18/asia/who-covid-review-panel-china-intl-hnk/index.html](https://www.cnn.com/2021/01/18/asia/who-covid-review-panel-china-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 04:20:28+00:00

China and the World Health Organization (WHO) could have acted quicker and more forcefully to contain the start of the Covid-19 outbreak, an independent review panel said on Monday.

## Don Lemon announces new book 'This is the Fire'
 - [https://www.cnn.com/videos/us/2021/01/19/don-lemon-cuomo-handoff-book-this-is-the-fire-vpx.cnn](https://www.cnn.com/videos/us/2021/01/19/don-lemon-cuomo-handoff-book-this-is-the-fire-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 03:46:29+00:00

CNN's Don Lemon and Chris Cuomo discuss Don's new book "This is the Fire" and what inspired him to write it.

## Why Kim Jong Un is sticking to his guns
 - [https://www.cnn.com/2021/01/18/asia/north-korea-covid-sanctions-dst-intl-hnk/index.html](https://www.cnn.com/2021/01/18/asia/north-korea-covid-sanctions-dst-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 03:31:31+00:00

After arguably the most challenging year of his near-decade rule of North Korea, Kim Jong Un is sticking to his guns.

## The US President might want Trump World, but he needs a real library
 - [https://www.cnn.com/2021/01/18/politics/what-matters-january-18/index.html](https://www.cnn.com/2021/01/18/politics/what-matters-january-18/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 03:02:50+00:00

For anyone at all disturbed by the alternate universe President Donald Trump has pushed as reality over the past four years, a nagging aggravation may be that one day this man will have a presidential library, just like the 13 most recent presidents to come before him.

## President Trump's opponents celebrate as he moves out of White House
 - [https://www.cnn.com/videos/politics/2021/01/19/trump-moving-days-moos-pkg-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/trump-moving-days-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 02:56:06+00:00

Watching Trump move, Twitter is moved to cheers. CNN's Jeanne Moos reports.

## National Guardsman holds music classes from the back of a Humvee while protecting the US Capitol
 - [https://www.cnn.com/2021/01/18/us/national-guardsman-teaches-band-in-back-of-humvee-trnd/index.html](https://www.cnn.com/2021/01/18/us/national-guardsman-teaches-band-in-back-of-humvee-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 02:54:53+00:00

DC National Guardsman, Sgt. Jacob Kohut, spends his days fulfilling two duties: serving to protect the Capitol building and holding band class online as a commitment to his students' education.

## CNN anchor: Sen. Graham became 'sycophant in chief' under Trump
 - [https://www.cnn.com/videos/politics/2021/01/19/lindsey-graham-sycophant-in-chief-burnett-ebof-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/lindsey-graham-sycophant-in-chief-burnett-ebof-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 02:10:33+00:00

CNN's Erin Burnett looks back at some of Sen. Lindsey Graham's (R-SC) comments over the last four years after Graham said on Fox News that President-elect Joe Biden would be seen as "incredibly weak" if he didn't oppose the second impeachment of President Trump.

## Five dishes that define India's diverse cuisine -- and the chefs taking them global
 - [https://www.cnn.com/travel/article/indian-food-global-chefs-hnk-spc-intl/index.html](https://www.cnn.com/travel/article/indian-food-global-chefs-hnk-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 02:06:09+00:00

The term "Indian cuisine" covers a lot of ground. From the Himalayan peaks in the northern state of Uttarakhand, to the tropical southwestern coast of Kerala, each landscape comes with its own climate, history, trade links and religious customs. And each has a unique food culture.

## 'Far too close:' Army secretary reveals sobering details on riot
 - [https://www.cnn.com/videos/politics/2021/01/19/mccarthy-capitol-riot-close-call-starr-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/19/mccarthy-capitol-riot-close-call-starr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 01:32:45+00:00

US Secretary of the Army Ryan McCarthy opens up to CNN's Barbara Starr about how close the Capitol riot came to a "disaster."

## Trump to lift Covid-related travel restrictions before he leaves office, official says
 - [https://www.cnn.com/2021/01/18/politics/trump-covid-travel-restrictions/index.html](https://www.cnn.com/2021/01/18/politics/trump-covid-travel-restrictions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 01:27:00+00:00

President Donald Trump is expected to lift coronavirus-related travel restrictions starting on January 26, nearly a week after he leaves office, a White House official said Monday.

## Biden administration braces for new wave of migrants as it rolls out new immigration plans
 - [https://www.cnn.com/2021/01/18/politics/biden-border-immigration-migrants/index.html](https://www.cnn.com/2021/01/18/politics/biden-border-immigration-migrants/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 00:37:20+00:00

President-elect Joe Biden plans to immediately begin the rollout of his immigration agenda upon taking office Wednesday, but the new administration will also have to contend with migrants already on the US-Mexico border, as well as those on their way.

## Who are some of Anderson's favorite comedians?
 - [https://www.cnn.com/videos/us/2021/01/18/favorite-comedians-andy-cohen-book-on-fatherhood-acfc-ask-anderson-vpx.cnn](https://www.cnn.com/videos/us/2021/01/18/favorite-comedians-andy-cohen-book-on-fatherhood-acfc-ask-anderson-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-19 00:10:41+00:00

CNN's Anderson Cooper reveals some of his favorite comedians. Anderson Cooper Full Circle airs Monday, Thursday and Friday this week at 6p E.T.

