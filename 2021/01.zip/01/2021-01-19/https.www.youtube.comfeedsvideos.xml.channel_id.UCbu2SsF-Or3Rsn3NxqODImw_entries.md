# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Hitman 3 Review
 - [https://www.youtube.com/watch?v=AcQZrmpR89g](https://www.youtube.com/watch?v=AcQZrmpR89g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-01-19 00:00:00+00:00

Hitman 3 doesn't make changes to the the franchise's core formula--instead, it refines it through excellent level design.

IO Interactive's stealth game Hitman 3 is available on PlayStation 4, PlayStation 5, Nintendo Switch, Xbox One, Xbox Series X/S, PC, and Stadia.

