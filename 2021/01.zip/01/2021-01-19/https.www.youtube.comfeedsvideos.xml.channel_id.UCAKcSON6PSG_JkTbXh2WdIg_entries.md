# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Ondara - three songs at The Current (2019)
 - [https://www.youtube.com/watch?v=UD4zGLuKEpE](https://www.youtube.com/watch?v=UD4zGLuKEpE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-20 00:00:00+00:00

Two years ago today — on Jan. 19, 2019 — Ondara performed on night two of The Current's 14th birthday party shows, held at First Avenue in Minneapolis. A few weeks later, Ondara visited our studio to perform these songs from his debut full-length album, "Tales of America." 

SONGS PERFORMED
0:00 "Saying Goodbye"
4:39 "Torch Song"
9:00 "Days of Insanity"

CREDITS
Video & Photo: Nate Ryan
Audio: John Miller
Production: Jesse Wiza

FIND MORE:
2016 studio session: 
https://www.thecurrent.org/feature/2016/10/24/jay-smart-performs-in-the-current-studio
2019 studio session:
https://www.thecurrent.org/feature/2019/02/26/js-ondara-performs-in-the-current-studio-tales-of-america
2020 virtual session:
https://www.thecurrent.org/feature/2020/10/05/ondara-virtual-session

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#ondara #jsondara

## Listen to Looch: How are you?
 - [https://www.youtube.com/watch?v=Sy0VDpRPSK0](https://www.youtube.com/watch?v=Sy0VDpRPSK0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-19 00:00:00+00:00

"I had planned to have a really fantastic documentary that I was going to recommend for you today, for this week, but I got way, way, way too caught up in all of the news," Mary Lucia says. 
 
"I'm feeling really anxious about this week, about life," Mary continues. "Just wanted to check in with how you're doing because I know I'm not alone."

Watch more of what Mary has to say in the video above. And importantly: How are you doing?

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

