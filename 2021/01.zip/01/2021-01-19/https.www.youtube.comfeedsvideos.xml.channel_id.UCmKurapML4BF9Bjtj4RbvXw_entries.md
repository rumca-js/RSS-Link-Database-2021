# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## The Piano Guys - Celebrating Every Video We've Ever Done!
 - [https://www.youtube.com/watch?v=8_aeZJpNNYs](https://www.youtube.com/watch?v=8_aeZJpNNYs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2021-01-19 00:00:00+00:00

► Listen and save on SPOTIFY: https://smarturl.it/StreamTPGMusic
► TPG SHEET MUSIC https://thepianoguys.com/collections/sheet-music
► Get our NEWEST ALBUM "10" here: https://smarturl.it/TPG-Album-10
► Get ALL our ALBUMS here: https://thepianoguys.com/collections/albums

The journey these last 10 years has been inTENse -- with extreme highs and lows. MANY times we’ve felt like giving up. Just quitting. To surmount this recurring struggle, we strive to remember WHY we do what we do and what we hope to become. We fall back on our core beliefs and values. We strive to trust. And, at times, when our faith is too fragile to trust, we hope.
Please visit the “beliefs” page here: https://smarturl.it/TPG_Beliefs

0:00  Michael Meets Mozart https://youtu.be/rR94NDIfGmA 
0:10  Bittersweet https://youtu.be/dfBwCjDadaY 
0:19  The Cello Song https://youtu.be/Ry4BzonlVlw 
0:29  Desert Symphony https://youtu.be/RQ5ljyGg-ig 
0:34  Moonlight https://youtu.be/DRVvFYppU0w 
0:42  Rock Meets Rachmaninoff https://youtu.be/oqeoKrKDffc 
0:46  Bring Him Home https://youtu.be/5mJ08-pyDLg 
0:53 Twinkle Little Star https://youtu.be/aDHxhhB8710 
1:00 Charlie Brown Medley https://youtu.be/tyPDQpel8bI 
1:07 Rolling in the Deep https://youtu.be/lUjWJSnGVB0 
1:16 Nearer My God to Thee https://youtu.be/gosY-UrpHcA 
1:25 All of Me https://youtu.be/9fAZIQ-vpdw 
1:33 More Than Words https://youtu.be/tDsm_O9i88Q 
1:37 Without You https://youtu.be/dfRtPbBFoGg 
1:44 Cello Wars https://youtu.be/BgAlQuqzl8o 
1:50 Where Are You Christmas https://youtu.be/GRqjFcP_aw0 
1:57 Carol of The Bells https://youtu.be/e9GtPX6c_kg 
2:07 Peponi https://youtu.be/Cgovv8jWETM 
2:13 Just The Way You Are https://youtu.be/rIBRcQdzWQs 
2:21 Beethoven's 5 Secrets https://youtu.be/mJ_fkw5j-t0 
2:29 O Fortuna  ???
2:47 Over The Rainbow https://youtu.be/jzF_y039slk 
2:58 Can't Help Falling in Love https://youtu.be/RZQNe8IMLtQ 
3:07 Happy Together https://youtu.be/DKC-lRhvdNY 
3:17 Codename Vivaldi https://youtu.be/09RUuTAM2H0 
3:31 A Thousand Years https://youtu.be/QgaTQ5-XfMM 
3:40 Rockelbel's Canon https://youtu.be/LV5_xj_yuhs 
3:47 Waterfall https://youtu.be/8P9hAN-teOU 
3:57 What Makes You Beautiful https://youtu.be/0VqTwnAuHws 
4:13 Titanium https://youtu.be/fz4MzJTeL0c 
4:21 O Come Emmanuel https://youtu.be/iO7ySn-Swwc 
4:35 We Three Kings https://youtu.be/qu5RY94ldDc 
4:47 Rudolph https://youtu.be/JkTd4pJlT-E 
4:53 Mission Impossible https://youtu.be/9p0BqUcQ7i0 
5:02 Begin Again https://youtu.be/P94DusN4LsY 
5:20 Berlin https://youtu.be/VcnzqKpFZ0I 
5:29 Home https://youtu.be/aF-Z1A0ujlg 
5:43 Don't You Worry Child https://youtu.be/1gCulUDvALM 
5:55 Kung Fu Piano https://youtu.be/NCaH-qqTWpk 
6:09 Arwen's Vigil https://youtu.be/p0tBS_IAX-M 
6:20 Angels We Have Heard On High https://youtu.be/n543eKIdbUI 
6:30 Let It Go https://youtu.be/6Dakd7EIgBE 
6:39 How Great Thou Art https://youtu.be/CHV6BjuQOZQ 
6:54 Story Of My Life https://youtu.be/yET4p-r2TI8 
7:07 Batman Evolution  https://thepianoguys.com/pages/batman-evolution-the-piano-guys
7:25 Ants Marching https://youtu.be/17GLE-16_3g 
7:35 Angels From The Realms Of Glory https://youtu.be/PrLoWt2tfqg 
7:51 I Want You Bach https://youtu.be/JZPSV78iQxg 
8:01 What Are Words https://youtu.be/X_J9UqYHcS4 
8:09 Jurassic Park https://youtu.be/7pvci1hwAx8 
8:23 Sky Full Of Stars https://youtu.be/qrHFg47Mopk 
8:30 Fight Song https://youtu.be/mOO5qRjVFLw 
8:41 Silent Night https://youtu.be/sMvURdq8V6U 
8:52 Hello https://youtu.be/WZjFMj7OHTw 
8:59 The Jungle Book https://youtu.be/O3cBZ5X-eGw 
9:18 It's Gonna Be Okay https://youtu.be/5pBjopDymts 
9:30 Can't Stop This Feeling https://youtu.be/0tMJPTQ7R0Y 
9:40 Indiana Jones https://youtu.be/u2Yk1CEgc4g 
9:48 Celloopa https://youtu.be/PtPPfLtJ8es 
9:59 Perfect https://youtu.be/KLeiK0whCdY 
10:07 Flicker https://youtu.be/SEmCu2eXrTc 
10:21 Ode To Joy https://youtu.be/JyVEKsNFDjw 
10:30 O Holy Night https://youtu.be/WGHUmpUu7Gw 
10:41 Light The World Christmas Concert https://youtu.be/7XnKGlt21Yc 
11:09 I Saw Three Ships https://youtu.be/D2IBGlDJ3lg 
11:21 The Sweetest Gift https://youtu.be/0yFXfAGl17M 
11:45 Rewrite The Stars https://youtu.be/5cINJwaAn4Y 
11:59 A Million Dreams https://youtu.be/xeQnXe6DLtM 
12:13 BTS Epiphany https://youtu.be/ts0Ir2hXXaw 
12:27 Avatar https://youtu.be/VIba88zHxRA 
12:57 Someone You Loved https://youtu.be/qMG1BXo8Asg 
13:19 Something Just Like Listz https://youtu.be/mZd1GsRHVts 
13:41 Avengers https://youtu.be/YHKa83UZbgU 
13:49 All I Want For Christmas https://youtu.be/c16dH9QezyE 
14:10 Let It Snow https://youtu.be/7N_NPUDUiQc 
14:17 Bless The Broken Road https://youtu.be/2ZQK5NmVG1g 
14:25 Pictures At An Exhibition https://youtu.be/i3Z9oJBuetI 
14:33 You Say https://youtu.be/n_lqtqsXzkM 
14:49 What Child Is This https://youtu.be/lJ_o85Byb-g 
15:01 Fur Elise Jam https://youtu.be/8trFmTnDR74 
15:15 Someone To You https://youtu.be/cIBbMUgn6FY

