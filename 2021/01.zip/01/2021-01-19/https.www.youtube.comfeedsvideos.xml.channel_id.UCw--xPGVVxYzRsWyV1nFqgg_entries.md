# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Writing Morality - The Setup is EVERYTHING
 - [https://www.youtube.com/watch?v=96UjnBi4400](https://www.youtube.com/watch?v=96UjnBi4400)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-20 00:00:00+00:00

Let's talk about wiring morality in science fiction and fantasy! 
Check Out Curiosity Stream Today: https://curiositystream.com/Greene
Use Code: Greene

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## ATLA Cast AGAINST Live Action Show🍃 New Neil Gaiman Covers📚Last Of Us Director🎥 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=rKd63Hr7n_Y](https://www.youtube.com/watch?v=rKd63Hr7n_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-19 00:00:00+00:00

We got some nice bite-sized Fantasy news coming in! Everything from Avatar the Last Airbender to a powder mage show! Could we ask for more? yes... yes we could. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

NEWS:

00:00 Intro

00:23 LeGuin Stamp: https://twitter.com/ursulakleguin/status/1350166884705062912/photo/1 

00:53 Nothing But Blackened Teeth: https://tornightfire.com/catalog/nothing-but-blackened-teeth-cassandra-khaw/ 

01:58 New Neil Gaiman cover: https://twitter.com/neilhimself/status/1351129709531197440 

02:39 Powder Mage Adaptation: https://twitter.com/DEADLINE/status/1349630868248260609 

03:12 Troll Bridge Short: https://www.youtube.com/watch?v=V7v_TdLviUE 

03:58 Amazon Lawsuit: https://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/85318-amazon-hit-with-e-book-price-fixing-suit.html 

04:46 WoT Concept Art: https://twitter.com/WOTonPrime/status/1350140700105400321 

06:03 Sandman Casting: https://twitter.com/DiscussingFilm/status/1350115924620283906?s=20 

06:11 Avatar Redundant: https://winteriscoming.net/2021/01/12/avatar-the-last-airbender-cast-talks-netflix-live-action-remake-reunion-redundant/ 

08:47 EA Star Wars Break: https://www.wired.com/story/lucasfilm-games-star-wars-ubisoft-indiana-jones-bethesda/ 

10:00 Chris Evans Lie: https://deadline.com/2021/01/captain-america-eyes-return-to-the-mcu-as-chris-evans-nears-deal-to-reprise-role-in-future-marvel-project-1234672430/ 

10:43 Cyborg controversy: https://screenrant.com/ray-fisher-cyborg-removed-flash-movie/ 

11:44 Mortal combat First Look: https://ew.com/movies/mortal-kombat-first-look-lewis-tan-joe-taslim-hiroyuki-sanada/ 

11:61 Last of Us Director: https://www.hollywoodreporter.com/heat-vision/last-of-us-hbo-series-finds-its-director-with-beanpole-filmmaker-exclusive?utm_source=twitter&utm_medium=social

