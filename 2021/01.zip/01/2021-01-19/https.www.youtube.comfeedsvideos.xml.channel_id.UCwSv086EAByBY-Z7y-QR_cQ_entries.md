# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Ida Auken tłumaczy na czym będzie polegał świat bez własności prywatnej. Analiza
 - [https://www.youtube.com/watch?v=P3EmMnU1R_g](https://www.youtube.com/watch?v=P3EmMnU1R_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-01-19 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
wikipedia.org / Johannes Jansson CC BY 2.5
http://bit.ly/3nZh8ov
---------------------------------------------------------------
✅źródła:
https://bit.ly/2M9C7HV
http://bit.ly/2XTy3OX
-------------------------------------------------------------
💡 Tagi: #Ekologia #ZrównoważonyRozwój #WEF
--------------------------------------------------------------

## Samorządy wyprzedają miejską infrastrukturę! Kulisy prywatyzacji SPEC Warszawa
 - [https://www.youtube.com/watch?v=gCRDpF6UwsM](https://www.youtube.com/watch?v=gCRDpF6UwsM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-01-19 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
Adrian Grycuk / wikipedia.org / CC BY-SA 3.0 pl 
http://bit.ly/2GVG5kn
---------------------------------------------------------------
✅źródła:
http://bit.ly/3oWiJgl
https://bit.ly/3p3ffsw
https://bit.ly/3is6GEM
http://bit.ly/2XP9DWN
https://bit.ly/2M0vo35
http://bit.ly/3oYNXTM
http://bit.ly/3bRzs0o
https://reut.rs/3nXpQDM
-------------------------------------------------------------
💡 Tagi: #Warszawa #Trzaskowski
--------------------------------------------------------------

