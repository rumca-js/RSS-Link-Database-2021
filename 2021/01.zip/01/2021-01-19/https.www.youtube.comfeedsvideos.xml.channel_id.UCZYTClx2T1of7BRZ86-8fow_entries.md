# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## When Algae Learned to Hunt
 - [https://www.youtube.com/watch?v=L1vTL0m5LGM](https://www.youtube.com/watch?v=L1vTL0m5LGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-01-19 00:00:00+00:00

You probably don't consider algae to be super aggressive, but 66 million years ago had to turn to murder in order to survive.

SciShow is supported by Brilliant.org. Go to https://Brilliant.org/SciShow to get 20% off of an annual Premium subscription. 

Hosted by: Michael Aranda

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org

----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://cicoes.uw.edu/internships/interns/cassondra-defoor/
https://biologydictionary.net/heterotroph/
https://earthsky.org/earth/dino-killing-asteroid-2-years-darkness-ncar-study
https://www.sciencedaily.com/releases/2020/10/201030142129.htm
https://advances.sciencemag.org/content/6/44/eabc9123 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6281475/
https://bio.biologists.org/content/8/2/bio036590
https://microbiologysociety.org/publication/past-issues/oceans/article/comment-mixotrophic-plankton-the-perfect-beasts-of-our-oceans.html
https://www.annualreviews.org/doi/abs/10.1146/annurev-marine-010816-060617

Image Sources:
https://commons.wikimedia.org/wiki/File:Gephyrocapsa_oceanica.jpg
https://commons.wikimedia.org/wiki/File:Haptophyta_cell_scheme.svg
https://commons.wikimedia.org/wiki/File:Flagellum_(PSF).png
https://commons.wikimedia.org/wiki/File:Phytoplankton_types.jpg

