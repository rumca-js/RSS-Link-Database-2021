# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Goodbye Trump, or is it au revoir…?
 - [https://www.youtube.com/watch?v=PY5nBlCDT3s](https://www.youtube.com/watch?v=PY5nBlCDT3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-20 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here http://russellbrand.com/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca


Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/contact/  and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

President Donald Trump has made his farewell address before leaving office, but what will his legacy be? 

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

## Holocaust Survivor - Is History Repeating Itself?
 - [https://www.youtube.com/watch?v=SRa6niMqZCY](https://www.youtube.com/watch?v=SRa6niMqZCY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-19 00:00:00+00:00

A clip from my Under The Skin podcast with Dr. Edith Eger. Edith - a Holocaust survivor and a specialist in the treatment of post-traumatic stress disorder. Her latest book The Gift - 12 Lessons To Save Your Life, shows us how to stop destructive patterns and imprisoning thoughts in order to find freedom and enjoy life. It is available now.

I think it is important at this time of crisis, chaos and conflict to hear a voice from someone who survived the most extreme situation in recent history, The Holocaust. At a time of much division and hateful rhetoric, confusion from all sides, here is a voice that can be truly unifying.

You can listen to all my Under The Skin podcasts on Luminary - there is a new podcast out every Saturday:
http://luminary.link/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

