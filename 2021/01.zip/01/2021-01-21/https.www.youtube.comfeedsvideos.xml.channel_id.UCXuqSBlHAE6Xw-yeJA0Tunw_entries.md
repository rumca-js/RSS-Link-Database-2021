# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Intel is Staging a BIG Comeback! - WAN Show January 22, 2021
 - [https://www.youtube.com/watch?v=-_YBydPNp70](https://www.youtube.com/watch?v=-_YBydPNp70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-22 00:00:00+00:00

Try KernelCare Enterprise for free at https://hubs.ly/H0BNgj60

Remotely monitor and manage your server or PC at https://lmg.gg/pulsewayteams and get 20% off Pulseway's Teams plan when you sign up.

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/wan

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Intel-is-Staging-a-BIG-Comeback----WAN-Show-January-22--2021-epes7q

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of MattDog_222):
0:15 Topic Preview
1:27 Intro
2:07 Intel beats Q4 targets with records
 3:11 Intel's Numbers were leaked "hacked" and officially released early
 3:50 Glenn Hinton returns to Intel
 5:15 Nehalem
 7:53 Hinton's words on returning
 9:17 Super smart people think of super smart things (LTTStore.com)
 11:08 What Ian Cutress from Tech Tech Potato suspects
 11:53 Luke interjects about business leadership
 14:18 Linus/LMG's leadership perspective
 16:28 Do Luke's paychecks clear?
 17:30 Recognizing the people behind a company + Competition
 20:07 You have to look at the motivation
 21:28 Is this the first major move to combat AMD?
 22:49 Key talent attracts key talent
24:23 Google threatens to pull out of Australia over new link tax laws
 25:05 Explanation of the 'link tax' law
 26:40 Google is fearful of precedents set
 27:11 Google tests value of Australian news
 27:45 James' take + James 
 28:21 James currently banned on Twitter
 28:54 James reaching out to Twitter (x2)
 30:27 Argument about being paid for something
 32:00 Concluding Google topic
32:18 Sponsors
 32:20 KernelCare Enterprise
 33:25 FreshBooks
 34:25 Pulseway
35:19 LTT Store: Underwear in stock
36:50 LTT Store: Special Edition Holofoil Shirt
37:25 NVIDIA Max-Q changes 
 38:45 NVIDIA's Statement about the changes
 40:38 Max-P isn't an official term
42:57 Raspberry Pi Launches $4 Pi Pico
 43:40 Pi Pico's Specs
 45:51 Luke's next famous quote + Min-maxing Hardware
 48:05 Explaining to the YouTube audience what a stream is
49:00 LMG: Job Positions/Openings + Descriptions
51:02 VIK-on YouTube mods RTX2070 to 16GB VRAM
53:18 Twitter accused of profiting from CP + Trafficking 
56:11 Some LMG job links are bugged
56:47 Superchats
 56:55 Kirk or Picard (Star Trek) discussion
 59:58 Luke's VR Setup & old living space revealed
1:07:11 Conclusion + LTT Store reminder and Floatplane solving Luke's old videos
1:09:00 Outro + Outro 2

## We just leveled up HARDCORE - Fibre Adventure
 - [https://www.youtube.com/watch?v=EdR2cujwke4](https://www.youtube.com/watch?v=EdR2cujwke4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-01-21 00:00:00+00:00

Squarespace: Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off
3DEXPERIENCE World 2021: http://solidworks.com/TW-Linus-21 
Use promo code 3DX21LINUS for FREE VIP access!

Over the years we've upgraded our networking many times, but we've always neglected one upgrade - fibre optics. Today that changes.

Buy 25G Fibre Transceivers:
From FS.com (Dell): https://rb.gy/obqekd
From FS.com (Mellanox): https://rb.gy/jb2upm

Buy Direct Attach 100G Cabling:
From FS.com: https://rb.gy/vym8b5

Buy Fibre Optic Cabling:
From Infinite Cables: https://lmg.gg/fibre

Check out Fibre Testing Equipment:
From Fluke: https://lmg.gg/flukefibre

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1296683-we-just-leveled-up-hardcore-fibre-networking-adventure/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

