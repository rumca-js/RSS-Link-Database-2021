# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Xiaomi Mi11 vs Samsung S21 Ultra
 - [https://www.youtube.com/watch?v=7mNGCflN2lc](https://www.youtube.com/watch?v=7mNGCflN2lc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-01-21 00:00:00+00:00

Dziś porównanie najbardziej topowego Samsunga z prawie najbardziej topowym Xiaomi. Różnica cenowa jest prawie dwukrotna, pozostałe różnice... oceńcie sami.
Xiaomi Mi 11 - http://bit.ly/39PvHpL (TradingShenzhen)
Samsung S21 Ultra 5G - http://bit.ly/3qxUPYS (ceneo) 
Karta ZEN - https://bit.ly/3kWMWc7 (kod przedłużający darmowy okres próbny: klawykod)

W odcinku:
00:00 Procesory: Xiaomi Mi11 vs Samsung S21 Ultra
00:57 Zdjęcia: ZOOM
02:12 Rozdzielczość zdjęć: Xiaomi Mi11 vs Samsung S21 Ultra
02:38 Filmy w 8K i 4K
03:48 Dodatkowe funkcje foto i video
04:09 Przednia kamera i mikrofony
04:24 Dedykowane słuchawki Samsung Galaxy Buds Pro
07:15 Głośniki: Xiaomi Mi11 vs Samsung S21 Ultra
08:04 Filmy i zdjęcia nocne: Xiaomi Mi11 vs Samsung S21 Ultra
09:04 Wyświetlacze
09:31 Ładowanie
10:20 Wygląd
10:43 Reklamy
12:02 Przerwa reklamowa: Zen MasterCard
12:30 Wnioski
13:39 Do zobaczenia!

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

