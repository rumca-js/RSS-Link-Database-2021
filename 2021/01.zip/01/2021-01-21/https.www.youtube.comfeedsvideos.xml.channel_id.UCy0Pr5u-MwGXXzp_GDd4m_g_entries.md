# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Villains in 2021 be like:
 - [https://www.youtube.com/watch?v=OLWMbG8qC80](https://www.youtube.com/watch?v=OLWMbG8qC80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-01-21 00:00:00+00:00

You think waterboarding is bad just you wait. Get Surfshark VPN at https://surfshark.deals/nolke - Enter promo code NOLKE for 83% off and 3 extra months for FREE!

