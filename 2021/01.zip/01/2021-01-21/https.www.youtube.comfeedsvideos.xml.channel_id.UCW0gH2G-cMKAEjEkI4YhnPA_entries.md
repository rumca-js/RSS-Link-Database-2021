# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Jed Brophy, actor, The Lord of the Rings & The Hobbit - Interview
 - [https://www.youtube.com/watch?v=WhLLxR5BMSg](https://www.youtube.com/watch?v=WhLLxR5BMSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-01-22 00:00:00+00:00

Jed Brophy has played Nori the dwarf, a Ringwraith, an elf, a Rider of Rohan, and two of the most memorable orcs in the Middle-earth films.  Join us for what is sure to be a fun conversation about Jed's time in Middle-earth!

