# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## WandaVision - Episode 3 (My Thoughts)
 - [https://www.youtube.com/watch?v=KYNs7Rer8gI](https://www.youtube.com/watch?v=KYNs7Rer8gI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-01-22 00:00:00+00:00

Wanda goes into labor, and the questions about what's going on stack. Here are my thought on WANDACISION - EPISODE 3!

#WandaVision

