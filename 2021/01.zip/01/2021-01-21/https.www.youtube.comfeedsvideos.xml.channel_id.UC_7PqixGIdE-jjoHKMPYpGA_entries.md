# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy babcie mają sens?
 - [https://www.youtube.com/watch?v=0EGCOTGK4y4](https://www.youtube.com/watch?v=0EGCOTGK4y4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-01-21 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Wszystkiego najlepszego dla wszystkich babć. Nie wiem czy wiecie, że ewolucyjnie mogłyście spełnić niebagatelną rolę i to dzięki Wam gatunek homo sapiens wygląda tak jak wygląda!

🎞 Film o golcach:
https://youtu.be/ZMsCir-fOwc

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 Jeden dzień, który dużo zmienia
2:50 Jak brzmi pytanie?
4:55 Ewolucyjny sens babci
8:55 Dowody i problemy
13:00 Babcia babci nierówna
15:33 Ważne uwagi
17:20 Obejrzyjcie - proszę!

===
Źródła (wybrane):

M. Blell - Grandmother Hypothesis, GrandmotherEffect, and Residence Patterns
S. N. Chapman i in. - Limits to Fitness Benefits of Prolonged Post-reproductive Lifespan in Women
K. Hawkes i in. - Evaluating Grandmother Effects
K. Hawkes - The grandmother effect
K. Hawkes - Grandmothers and the evolution of human longevity
S. Nattrass - Postreproductive killer whale grandmothers improve the survival of their grandoffspring
K. Hawkes i in. - Grandmothers and the evolution of human longevity: a review of findings and future directions

https://www.sciencedaily.com/releases/2019/02/190207142230.htm
https://www.fightaging.org/archives/2012/10/simulating-the-grandmother-effect/
https://www.smithsonianmag.com/science-nature/how-much-did-grandmothers-influence-human-evolution-180976665/
https://www.sciencedaily.com/releases/2019/02/190207142230.htm
https://www.nature.com/news/2010/100824/full/news.2010.430.html
https://www.npr.org/sections/goatsandsoda/2019/02/07/692088371/living-near-your-grandmother-has-evolutionary-benefits?t=1610965753457

