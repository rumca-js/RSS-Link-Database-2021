# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Samsung Galaxy S21 Ultra Review: Problems Solved!
 - [https://www.youtube.com/watch?v=tn2AgrwXpNQ](https://www.youtube.com/watch?v=tn2AgrwXpNQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-01-21 00:00:00+00:00

Galaxy S21 Ultra: All the right tweaks in all the right places.

ICONS is back!! https://dbrand.com/ICONS

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Samsung for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

