# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Dlaczego rząd zamknął restauracje i bary? Teorie i fakty!
 - [https://www.youtube.com/watch?v=Ny2KZUzDgtk](https://www.youtube.com/watch?v=Ny2KZUzDgtk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-01-21 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - do kolażu wykorzystano grafikę ze stron: 
gov.pl - http://bit.ly/2lVWjQr
collina.pl - http://bit.ly/3978joG (foto poglądowe)
---------------------------------------------------------------
✅źródła:
http://bit.ly/3o9Z23g
http://bit.ly/2YeZ3bT
http://bit.ly/3bZUbzf
http://bit.ly/391AQfc
https://bit.ly/39WJ3QW
-------------------------------------------------------------
💡 Tagi: #lockdown #gospodarka #restauracje
--------------------------------------------------------------

## Prof. Horban podsumował walkę rządu z Covid-19. Co poszło nie tak?
 - [https://www.youtube.com/watch?v=TIAcuejyVLc](https://www.youtube.com/watch?v=TIAcuejyVLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-01-21 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
youtube.com / Kancelaria Premiera
https://bit.ly/2XY4T11
---
kok.koscian.pl
http://bit.ly/2XWkhL9
---------------------------------------------------------------
✅źródła:
https://bit.ly/3bZ7QGW
http://bit.ly/35Z4G1S
http://bit.ly/3qvTyl4
https://bit.ly/3o4U3Rr
http://bit.ly/3fFrTJ8
-------------------------------------------------------------
💡 Tagi: #PiS #gospodarka #covid19
--------------------------------------------------------------

