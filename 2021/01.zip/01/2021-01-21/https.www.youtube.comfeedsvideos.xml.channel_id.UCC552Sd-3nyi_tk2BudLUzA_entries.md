# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Debunking Our Own Video
 - [https://www.youtube.com/watch?v=tPBlEjZomfE](https://www.youtube.com/watch?v=tPBlEjZomfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-01-21 00:00:00+00:00

Today we're debunking, our own video debunking other videos about DEBUNKING! 
Follow LabMuffin here: https://www.youtube.com/LabMuffinBeautyScience
Join our mailing list: https://bit.ly/34fWU27

While everyone was watching the inauguration we were getting DEBUNKED! We made a video about the science of skincare, retinol and vitamin C. LabMuffin aka Michelle Wong stepped in to let us know some of the nuances we got wrong, and to ignite a brilliant discussion about the science of skincare, how products are sold to us, lol at the new Jennifer Lopez skin care line logline, and how you can best choose your skincare products based on SCIENCE. We also talked about skincare myths, battled it out about bad skincare studies and learned that with skincare we need to be less picky about our science research.

Written by Greg Brown and Michelle Wong
Edited by Luka Šarlija and Greg Brown

FOLLOW US!
AsapSCIENCE
TikTok: @AsapSCIENCE 
Instagram: https://instagram.com/asapscience
Facebook: https://facebook.com/asapscience
Twitter: https://twitter.com/asapscience

Further Reading/Sources:
Vitamin C collagen studies: https://doi.org/10.1046/j.1524-4725.2...
Japanese quasi-drugs: https://www.ncbi.nlm.nih.gov/pmc/arti...
Powered By Chemicals Mugs: https://labmuffin.com/shop/
The Remarkable Life of the Skin by Monty Lyman

