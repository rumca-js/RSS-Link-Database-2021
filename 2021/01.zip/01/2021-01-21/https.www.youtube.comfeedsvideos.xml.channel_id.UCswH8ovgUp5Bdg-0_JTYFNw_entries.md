# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Will A New President REALLY Change Anything?
 - [https://www.youtube.com/watch?v=8KS2h5u3GZ4](https://www.youtube.com/watch?v=8KS2h5u3GZ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-22 00:00:00+00:00

What can the history of presidential inaugurations tell us about what they represent and whether real change is possible? 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

## Kundalini Immune Booster | Russell Brand
 - [https://www.youtube.com/watch?v=GfKnFcRvoSM](https://www.youtube.com/watch?v=GfKnFcRvoSM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-01-21 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Kundalini to boost the immune system! Try this 3 minute exercise. Do you enjoy these meditations? How did you feel before & after?

Please note: I am not a qualified Kundalini teacher and this exercise should not be used to replace other practices to boost the immune system.

-------------------------------------------------------------------------------------------------------------------------

GUIDELINES

Posture: Sit in Easy Pose.

Mudra: Bend the left arm and raise the hand up to shoulder level. The palm faces forward. The forearm is perpendicular to the ground. Make Surya Mudra with the left hand (touch the tip of the ring finger to the tip of the thumb). The mudra of the left hand may slip during practice; keep it steady. Make a fist of the right hand, pressing the tips of the fingers into the pads at the base of the fingers; extend the index finger. With the extended index finger, gently close off the right nostril.

Focus: Concentrate at the Brow Point.

Breath: Begin a steady, powerful Breath of Fire. Emphasise the beat at the navel; the navel must move.

Time: Continue for 3 minutes.

To End: Inhale deeply and hold the breath. As the breath is held, interlace all the fingers (beginning with the right thumb uppermost) and put the palms in front at a level just below the throat (in front of the thymus), and about 14 inches (35 cm) away from the body. Try to pull the fingers apart with all force. Resist and create a great tension. When you must, exhale. Repeat this sequence 3 more times. On the last exhale, discharge the breath by blowing through your upturned lips, with the tongue curled back on the roof of the mouth. This will seal the upper palate upward. Then relax.

-------------------------------------------------------------------------------------------------------------------------

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

