# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Why Chinese Choose Insane English Names
 - [https://www.youtube.com/watch?v=RUWFrdB2hTo](https://www.youtube.com/watch?v=RUWFrdB2hTo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2021-01-21 00:00:00+00:00

When you go to China, you will run into some hilarious English names. I wanted to make a video to talk about why this happens, as well as how names in China work from a cultural perspective. 

Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Or, if you prefer, Subscribestar - https://www.subscribestar.com/laowhy86


Car channel - https://www.youtube.com/worthlesswhips
ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Thanks to ZackP for the snowboard/ski footage from China!
https://www.youtube.com/user/xxxhungari

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun


◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor


◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina


◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina


◘ Discount code for both shows: laowinning


◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86


Be a Laowinner!
Like comment subscribe!


◘ Facebook:
http://www.facebook.com/laowhy86


◘ Instagram: 
http://instagram.com/laowhy86


◘ Music: BigBadBeats - Chill R&B X lofi Guitar Type Beat ''Lolly" - Kota the Friend Instrumental
https://youtu.be/JwAHoKPkbv0

