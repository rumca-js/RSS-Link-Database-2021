# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Batwoman Season 2 Episode 1 - Hilariously Awful
 - [https://www.youtube.com/watch?v=BFo2ClmiCtk](https://www.youtube.com/watch?v=BFo2ClmiCtk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-01-21 00:00:00+00:00

Well, it finally happened. Batwoman Season 2 is upon us, and it's just as hilariously bad as you'd expect.

