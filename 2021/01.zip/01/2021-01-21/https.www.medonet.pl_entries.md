## Szpitale tymczasowe kosztowały ponad 500 mln zł. Dlaczego stoją puste?
 - [https://www.medonet.pl/koronawirus/koronawirus-w-polsce,szpitale-tymczasowe-kosztowaly-ponad-500-mln-zlotych--dlaczego-stoja-puste-,artykul,98771495.html](https://www.medonet.pl/koronawirus/koronawirus-w-polsce,szpitale-tymczasowe-kosztowaly-ponad-500-mln-zlotych--dlaczego-stoja-puste-,artykul,98771495.html)
 - RSS feed: https://www.medonet.pl
 - date published: 2021-01-21 11:18:28+00:00

Szpitale tymczasowe kosztowały ponad 500 mln zł. Dlaczego stoją puste?

