# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How Do You Address Homeless Problem & Lockdowns?
 - [https://www.youtube.com/watch?v=D-1EWojozc8](https://www.youtube.com/watch?v=D-1EWojozc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-22 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1600 with Lex Fridman. https://open.spotify.com/episode/3UmMhM0poOl6thtYzUCtJt?si=7t9r3vATSky29nVUENvEGQ

## Jeffrey Epstein's Ties to the Scientific Community
 - [https://www.youtube.com/watch?v=ysuqhQErnp4](https://www.youtube.com/watch?v=ysuqhQErnp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-22 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1600 with Lex Fridman. https://open.spotify.com/episode/3UmMhM0poOl6thtYzUCtJt?si=7t9r3vATSky29nVUENvEGQ

## Joe Rogan - Fame is an Empty Pursuit
 - [https://www.youtube.com/watch?v=tslyBqpClEI](https://www.youtube.com/watch?v=tslyBqpClEI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-22 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1600 with Lex Fridman. https://open.spotify.com/episode/3UmMhM0poOl6thtYzUCtJt?si=7t9r3vATSky29nVUENvEGQ

## The Inspiring Story of How The Undertaker Started Wrestling
 - [https://www.youtube.com/watch?v=EbJE0v4M7ow](https://www.youtube.com/watch?v=EbJE0v4M7ow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-21 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1598 with Mark "The Undertaker" Calaway. https://open.spotify.com/episode/7LK9ihWzlu0iK8ZrehU7bH?si=LJAiSjfKQKSUap1esAmHlA

## The Origins of The Undertaker Character
 - [https://www.youtube.com/watch?v=pzseicO0FQQ](https://www.youtube.com/watch?v=pzseicO0FQQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-21 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1598 with Mark "The Undertaker" Calaway. https://open.spotify.com/episode/7LK9ihWzlu0iK8ZrehU7bH?si=LJAiSjfKQKSUap1esAmHlA

## The Undertaker on Finally Retiring
 - [https://www.youtube.com/watch?v=DL-v8BukD3U](https://www.youtube.com/watch?v=DL-v8BukD3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-21 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1598 with Mark "The Undertaker" Calaway. https://open.spotify.com/episode/7LK9ihWzlu0iK8ZrehU7bH?si=LJAiSjfKQKSUap1esAmHlA

## Tulsi Gabbard on How Congress is Like High School
 - [https://www.youtube.com/watch?v=ROd2JuDM8lc](https://www.youtube.com/watch?v=ROd2JuDM8lc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-21 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1598 with Tulsi Gabbard. https://open.spotify.com/episode/07juCiH3Wrv7AKilHwVWvf?si=h6AXuLF4QcmlAgzwCxutsQ

## Vaccine Rollout - Should The Elderly or Essential Workers be the First Recipients?
 - [https://www.youtube.com/watch?v=yoJGvC_ze64](https://www.youtube.com/watch?v=yoJGvC_ze64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-21 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1598 with Tulsi Gabbard. https://open.spotify.com/episode/07juCiH3Wrv7AKilHwVWvf?si=h6AXuLF4QcmlAgzwCxutsQ

## What Happens Post-Trump?
 - [https://www.youtube.com/watch?v=TYAzyDHCJUc](https://www.youtube.com/watch?v=TYAzyDHCJUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-01-21 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1598 with Tulsi Gabbard. https://open.spotify.com/episode/07juCiH3Wrv7AKilHwVWvf?si=h6AXuLF4QcmlAgzwCxutsQ

