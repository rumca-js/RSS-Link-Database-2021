# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## GTA 6 NEW NPC TECH PATENTED? XBOX LIVE PRICE HIKE RAGE, & MORE
 - [https://www.youtube.com/watch?v=pi7g8Skzgxo](https://www.youtube.com/watch?v=pi7g8Skzgxo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-22 00:00:00+00:00

A possible next-gen GTA technological development, Resident Evil Village gets a demo and new gameplay details, Xbox Live Gold prices set to rise, and more in a week FULL of gaming news.
Subscribe for more: https://www.youtube.com/gameranxTV?su...

**Jake's other channel
https://youtu.be/YLwC8kLpNqQ


Follow:
 Instagram: https://goo.gl/HH6mTW

Twitter: https://bit.ly/3deMHW7


 ~~~~STORIES~~~~

New GTA tech:
https://www.ign.com/articles/rockstar-patent-npc-virtual-navigation-gta-6?amp=1


Resident Evil newsnew RE8 trailer: https://youtu.be/btFclZUXpzA
some gameplay: https://youtu.be/Lr1h2DxwVos
PS5 demo ‘Maiden’
RE:Verse: https://youtu.be/vsi5TwZ5snA

Valve making games again
https://www.pcgamer.com/gabe-newell-says-valve-has-games-in-development-that-were-going-to-be-announcing/

Xbox Live Gold
https://www.windowscentral.com/xbox-live-gold-price-hike-where-you-can-still-buy-12-months-60

Cyberpunk fake demo response
https://www.earlygame.com/more/cyberpunk-2077s-e3-2018-demo-not-fake/


Fortnite: https://youtu.be/SpnpXPIVr1Q

Destruction AllStars: https://www.youtube.com/watch?v=B0kIMyL96ss&feature=emb_title

New Highlight Reel: https://youtu.be/n00vhvUHyp0

Everspace 2 early access release trailer: https://youtu.be/fuygGFteHpY
Hitman 3 launch trailer: https://youtu.be/1a2SBO_q66o
Atomic Heart: https://youtu.be/FndjDVw72sg

## 10 Easter Eggs That Took YEARS To Discover [Part 2]
 - [https://www.youtube.com/watch?v=Wk1YyCHVols](https://www.youtube.com/watch?v=Wk1YyCHVols)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-01-21 00:00:00+00:00

Here's a follow-up video with even more secrets and Easter eggs in games that were hidden for YEARS.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Part 1 - https://www.youtube.com/watch?v=WinE0RkoCTA&t=3s

Sources:

https://twitter.com/AnthonyCaliber?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1348122552972021760%7Ctwgr%5E%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fwww.gamesradar.com%2Fthe-last-of-us-prologue-has-an-easter-egg-thats-been-hiding-for-seven-years%2F

https://www.pcgamer.com/heres-whats-happening-inside-fallout-3s-metro-train/

https://screenrant.com/red-dead-redemption-2-hidden-cutscene-rdr2-trelawny/

https://www.reddit.com/r/reddeadredemption/comments/jj0gqm/another_hidden_cutscene/

https://twitter.com/manfightdragon?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1345615588106780672%7Ctwgr%5E%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fkotaku.com%2Fajax%2Finset%2Fiframe%3Fid%3Dtwitter-1345615588106780672autosize%3D1

https://www.zeldix.net/t1831-street-fighter-alpha-2

https://twitter.com/ShaneMarchis/status/1025138749749919744?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1025138749749919744%7Ctwgr%5E%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fcdn.embedly.com%2Fwidgets%2Fmedia.html%3Ftype%3Dtext2Fhtmlkey%3Da19fcc184b9711e1b4764040d3dc5c07schema%3Dtwitterurl%3Dhttps3A%2F%2Ftwitter.com%2Fshanemarchis%2Fstatus%2F1025138749749919744image%3Dhttps3A%2F%2Fi.embed.ly%2F1%2Fimage3Furl3Dhttps253A252F252Fpbs.twimg.com252Fmedia252FDjoGQoaU0AA2QS_.jpg253Alarge26key3Da19fcc184b9711e1b4764040d3dc5c07


https://www.youtube.com/watch?v=5GuXAwq_300&feature=emb_title&ab_channel=TelltaleGamesVideos

https://kotaku.com/14-years-later-zelda-fans-discover-new-way-to-kill-win-1787459259

