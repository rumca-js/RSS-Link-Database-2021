# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Laraaji - Interview & Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=4VIe2EKSPxc](https://www.youtube.com/watch?v=4VIe2EKSPxc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-01-22 00:00:00+00:00

http://KEXP.ORG presents Laraaji sharing an exclusive live performance recorded at home and talking to the Afternoon Show's Larry Mizell, Jr.. Recorded January 14, 2021.

1-OPEN with Tibetan TING SHA CYMBAL TONES
2-Electric Zither Ebow & Loop improvisation “GENTLE MEDITATION”
3-Electric Zither & Raked electric alto Kalimba (African Thumb Piano) & loop improvisation “LOVE IS”
4-Electric Zither up tempo brush & mallet percussion improvisation  “Zither Funk Jam”
5-Soft peaceful Electric Zither wash & strum improvisation with raked Alto Kalimba (African Thumb Piano) “Waves upon Waves”
6-Closing brief TIBETAN METAL BOWL & Ting SHA tones 
7- Voice & Head shot on camera “0m Shantih” bowing brief

Instrumentation
Open tuned Electric zither
Alto Kalimba (African Thumb Piano)
Tibetan metal tone bowl
Continuous plucked Zither loop

http://laraaji.blogspot.com
https://laraajimusic.bandcamp.com
http://kexp.org

