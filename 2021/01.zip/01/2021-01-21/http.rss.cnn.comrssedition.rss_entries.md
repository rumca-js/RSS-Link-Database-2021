# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Biden removes Churchill bust from office
 - [https://www.cnn.com/2021/01/21/politics/winston-churchill-bust-oval-office/index.html](https://www.cnn.com/2021/01/21/politics/winston-churchill-bust-oval-office/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 21:21:07+00:00

• Analysis: 1 photo that shows how much history was made on Inauguration Day
• Video: Late-night TV on Biden's first day

## Late-night hosts poke fun as Biden completes his first full day
 - [https://www.cnn.com/videos/politics/2021/01/21/kevin-mccarthy-donald-trump-capitol-riot-role-sot-vpx-nr.cnn](https://www.cnn.com/videos/politics/2021/01/21/kevin-mccarthy-donald-trump-capitol-riot-role-sot-vpx-nr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 19:59:09+00:00

House Minority Leader Kevin McCarthy said that former President Donald Trump did not incite the riot at the Capitol earlier this month, contradicting previous comments he made that the President did bear some responsibility for the assault.

## Here's how Biden's Oval Office compares to Trump's
 - [https://www.cnn.com/videos/politics/2021/01/21/keilar-biden-trump-oval-office-comparison-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/21/keilar-biden-trump-oval-office-comparison-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 19:27:57+00:00

CNN's Brianna Keilar looks at how the decor President Biden chose for the Oval Office differs from Trump's.

## Former UK ambassador to US says this will be Biden's biggest foreign policy challenge
 - [https://www.cnn.com/videos/tv/2021/01/21/amanpour-kori-schake-peter-westmacott.cnn](https://www.cnn.com/videos/tv/2021/01/21/amanpour-kori-schake-peter-westmacott.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 18:05:28+00:00

Former State Department official Kori Schake and former UK Ambassador to the US Peter Westmacott discuss the foreign policy challenges facing President Biden.

## How Kamala Harris redefined 'girl power'
 - [https://www.cnn.com/videos/politics/2021/01/21/vice-president-harris-inauguration-oath-girls-reactions-bu-orig.cnn](https://www.cnn.com/videos/politics/2021/01/21/vice-president-harris-inauguration-oath-girls-reactions-bu-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 14:40:15+00:00

Young girls from around America explain why Vice President Kamala Harris taking the oath of office inspired them.

## He didn't believe Biden would be inaugurated. See what he said after inauguration
 - [https://www.cnn.com/videos/business/2021/01/21/conspiracy-theories-qanon-inauguration-trump-biden-orig.cnn-business](https://www.cnn.com/videos/business/2021/01/21/conspiracy-theories-qanon-inauguration-trump-biden-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 13:39:42+00:00

The moment of reckoning promised by the QAnon conspiracy theory never came. Now, many believers feel confused, duped, and uncertain of what comes next.

## Biden's first full day in office
 - [https://www.cnn.com/politics/live-news/president-joe-biden-news-01-21-20/index.html](https://www.cnn.com/politics/live-news/president-joe-biden-news-01-21-20/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 13:37:52+00:00



## Glastonbury music festival canceled for second year amid ongoing pandemic
 - [https://www.cnn.com/2021/01/21/uk/glastonbury-festival-2021-canceled-scli-gbr-intl/index.html](https://www.cnn.com/2021/01/21/uk/glastonbury-festival-2021-canceled-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 13:31:37+00:00

The organizers of Glastonbury have announced that Britain's famous music festival will be canceled for a second consecutive year amid the coronavirus pandemic -- an ominous move for live music promoters and artists ahead of an uncertain summer.

## QAnon believers are in disarray after Biden is inaugurated
 - [https://www.cnn.com/2021/01/20/tech/qanon-believers-inauguration-reaction/index.html](https://www.cnn.com/2021/01/20/tech/qanon-believers-inauguration-reaction/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 13:26:54+00:00

For years, believers of the QAnon conspiracy theory had been waiting for the moment when a grand plan would be put into action and secret members of a supposed Satanic pedophilia ring at the highest ranks of government and Hollywood would suddenly be exposed, rounded up and possibly even publicly executed. They were nearly always sure it was right around the corner, but "The Storm" never came — and the moment of Joe Biden's inauguration was the last possible opportunity for President Donald Trump to put the plan in motion.

## At least 13 killed as twin suicide bombings rock Baghdad
 - [https://www.cnn.com/2021/01/21/middleeast/iraq-baghdad-explosion-intl/index.html](https://www.cnn.com/2021/01/21/middleeast/iraq-baghdad-explosion-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 13:14:24+00:00

Twin suicide bombs rocked a busy market in central Baghdad on Thursday morning, killing at least 13 people, a security official told CNN.

## Golden State Warriors pay tribute to Kamala Harris in 'great day' for Oakland
 - [https://www.cnn.com/2021/01/21/sport/golden-state-warriors-kamala-harris-spt-intl/index.html](https://www.cnn.com/2021/01/21/sport/golden-state-warriors-kamala-harris-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 13:01:25+00:00

Golden State Warriors head coach Steve Kerr called it a "great day" for Oakland after Kamala Harris, a native of the city, was sworn in as Vice President of the United States.

## Evidence shows Capitol rioters brutally attacked police with flagpoles, fire extinguishers and fists
 - [https://www.cnn.com/2021/01/21/politics/capitol-rioters-attacking-police/index.html](https://www.cnn.com/2021/01/21/politics/capitol-rioters-attacking-police/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 12:45:30+00:00

The unprecedented images spoke for themselves, but as prosecutors start filing criminal charges against pro-Trump rioters who attacked the US Capitol, new evidence is emerging of the horrifying scenes police officers faced while fighting for their lives that day.

## Jill Biden's fashion choices were subtle but purposeful on Inauguration Day
 - [https://www.cnn.com/style/article/jill-biden-inauguration-fashion/index.html](https://www.cnn.com/style/article/jill-biden-inauguration-fashion/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 12:44:34+00:00

There was no shortage of striking fashion moments on Inauguration Day this year, from the shoulder smattering of crystals on Ella Emhoff's Miu Miu coat to Amanda Gordon's sunny Prada ensemble, each outfit choice told a story and added to the cautious celebratory spirit of the day.

## Newspapers around the world react to Biden's inauguration
 - [https://www.cnn.com/2021/01/21/media/biden-inauguration-global-front-pages-scli-intl/index.html](https://www.cnn.com/2021/01/21/media/biden-inauguration-global-front-pages-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 12:39:08+00:00

The culmination of Joe Biden's journey to the Oval Office was seen far beyond Washington DC on Thursday, with images of his inauguration splashed across the front pages of newspapers around the world.

## Biden brings a dose of normal to a beleaguered nation
 - [https://www.cnn.com/2021/01/21/politics/biden-trump-normal/index.html](https://www.cnn.com/2021/01/21/politics/biden-trump-normal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 12:34:30+00:00

When President Joe Biden walked into the White House on Wednesday holding hands with his wife, it all seemed so normal.

## Why does it matter what Kamala Harris wears as VP?
 - [https://www.cnn.com/videos/fashion/2021/01/21/kamala-harris-fashion-choices-ts-orig.cnn](https://www.cnn.com/videos/fashion/2021/01/21/kamala-harris-fashion-choices-ts-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 12:30:06+00:00

As the first female and first Black and South Asian Vice President, Kamala Harris' style will come under scrutiny. Fashion critic Robin Givhan explains why Harris' clothes have meaning to those who see themselves in her and why we shouldn't compare her style to a First Lady.

## Biden showed his vast potential to change the national course. But he saw many reminders of the tough US reality.
 - [https://www.cnn.com/2021/01/21/politics/joe-biden-president-america-change/index.html](https://www.cnn.com/2021/01/21/politics/joe-biden-president-america-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 12:26:15+00:00



## Trump left Biden a 'very generous letter' before departing White House
 - [https://www.cnn.com/2021/01/20/politics/trump-letter-to-biden/index.html](https://www.cnn.com/2021/01/20/politics/trump-letter-to-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 12:04:39+00:00

President Joe Biden said Wednesday that former President Donald Trump left him a "very generous letter" before departing the White House.

## Former Presidents Obama, Bush and Clinton honor Biden as America's new leader in joint video
 - [https://www.cnn.com/2021/01/20/politics/obama-bush-clinton-video-biden-inauguration/index.html](https://www.cnn.com/2021/01/20/politics/obama-bush-clinton-video-biden-inauguration/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 11:53:52+00:00

Former Presidents Barack Obama, George W. Bush and Bill Clinton honored President Joe Biden Wednesday evening as America's new leader in a joint message that emphasized the new President's call for national unity.

## China says it is a 'victim' after Twitter locks embassy account
 - [https://www.cnn.com/2021/01/21/tech/twitter-china-embassy-us-uyghur-intl-hnk/index.html](https://www.cnn.com/2021/01/21/tech/twitter-china-embassy-us-uyghur-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 11:42:01+00:00

China says that it is a "victim" of misinformation after Twitter restricted the account of the Chinese embassy in the United States.

## No beaches or booze: What South Africa's top tourist spot looks like during Covid
 - [https://www.cnn.com/travel/article/cape-town-tourist-covid/index.html](https://www.cnn.com/travel/article/cape-town-tourist-covid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 11:38:49+00:00

With its vast mountain ranges, sandy beaches and towering forests, Cape Town is a place where the natural world dominates, imploring visitors to stop and soak it all in.

## This is the foreign policy legacy Biden inherits from Trump
 - [https://www.cnn.com/videos/world/2021/01/18/biden-foreign-policy-headaches-lon-orig-mkd.cnn](https://www.cnn.com/videos/world/2021/01/18/biden-foreign-policy-headaches-lon-orig-mkd.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 11:20:50+00:00

CNN's international correspondents unpack the foreign policy challenges President-elect Joe Biden will face in the White House.

## 'Significant' cannabis factory found near the Bank of England
 - [https://www.cnn.com/2021/01/21/uk/london-cannabis-factory-scli-intl-gbr/index.html](https://www.cnn.com/2021/01/21/uk/london-cannabis-factory-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 10:59:00+00:00

City of London Police have discovered and destroyed a "significant" cannabis factory in the heart of London following reports about the strong smell of the plant.

## Conor McGregor is back, again
 - [https://www.cnn.com/2021/01/21/sport/dustin-poirier-vs-conor-mcgregor-spt-intl/index.html](https://www.cnn.com/2021/01/21/sport/dustin-poirier-vs-conor-mcgregor-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 10:34:24+00:00

Conor McGregor is back, again.

## Ronaldo becomes the highest goalscorer of all time. Or does he?
 - [https://www.cnn.com/2021/01/21/football/cristiano-ronaldo-breaks-all-time-goal-record-spt-intl/index.html](https://www.cnn.com/2021/01/21/football/cristiano-ronaldo-breaks-all-time-goal-record-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 10:33:45+00:00

Cristiano Ronaldo's goal in Juventus' Italian Super Cup win over Napoli on Wednesday took his career scoring tally to 760, making him the highest goalscorer of all time -- or is he?

## Europe's Star Cities, marvels of Renaissance engineering
 - [https://www.cnn.com/travel/article/star-cities-europe-architecture/index.html](https://www.cnn.com/travel/article/star-cities-europe-architecture/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 10:07:43+00:00

Built in the 16th and 17th centuries, Europe's geometrically perfect "star cities" were engineered by some of the most brilliant minds of their time, but their wonders can only be truly appreciated from the air

## The China trade war is one thing Joe Biden won't be rushing to fix
 - [https://www.cnn.com/2021/01/21/economy/china-trade-tech-war-biden-intl-hnk/index.html](https://www.cnn.com/2021/01/21/economy/china-trade-tech-war-biden-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 09:50:39+00:00

US President Joe Biden is inheriting a tense and messy relationship with China from his predecessor.

## Hear from young poet who stole the show at inauguration
 - [https://www.cnn.com/videos/style/2021/01/21/amanda-gorman-poet-laureate-interview-inauguration-vpx.cnn](https://www.cnn.com/videos/style/2021/01/21/amanda-gorman-poet-laureate-interview-inauguration-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 09:42:09+00:00

CNN's Anderson Cooper speaks with Amanda Gorman, the nation's first-ever youth poet laureate, after she delivered a poem at the inauguration of President Joe Biden.

## Beijing sanctions high-ranking Trump administration officials after Biden takes office
 - [https://www.cnn.com/2021/01/20/asia/china-trump-us-official-sanctions-intl-hnk/index.html](https://www.cnn.com/2021/01/20/asia/china-trump-us-official-sanctions-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 09:14:59+00:00

The Chinese government has announced sanctions against outgoing secretary of state Mike Pompeo and 27 other high-ranking officials under former United States President Donald Trump, accusing them of "prejudice and hatred against China."

## Harris' Indian uncle reacts to her historic moment
 - [https://www.cnn.com/videos/world/2021/01/21/kamala-harris-indian-uncle-reaction-inauguration-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/01/21/kamala-harris-indian-uncle-reaction-inauguration-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 08:56:47+00:00

CNN's Vedika Sud reports from New Delhi on the pride and celebrations in India for Kamala Harris' inauguration as the first female, first Black and first South Asian Vice President of the United States.

## Australian Open tennis stars urged not to feed mice in hotel rooms
 - [https://www.cnn.com/2021/01/20/tennis/yulia-putintseva-mice-australian-open-quarantine-spt-intl/index.html](https://www.cnn.com/2021/01/20/tennis/yulia-putintseva-mice-australian-open-quarantine-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 08:33:22+00:00

"Wee, sleekit, cowrin, tim'rous beastie," wrote renowned Sottish poet Robert Burns in his poem "To a Mouse."

## Katy Perry lights up inauguration TV special in all-white Thom Browne outfit
 - [https://www.cnn.com/style/article/katy-perry-outfit-inauguration-firework/index.html](https://www.cnn.com/style/article/katy-perry-outfit-inauguration-firework/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 08:08:11+00:00

Katy Perry capped off President Joe Biden's inauguration in style, belting out "Firework" in a collection of chic separates by New York designer Thom Browne.

## Highlights from the star-packed inauguration concert
 - [https://www.cnn.com/videos/politics/2021/01/21/joe-biden-inauguration-concert-performances-eg-orig.cnn](https://www.cnn.com/videos/politics/2021/01/21/joe-biden-inauguration-concert-performances-eg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 07:33:43+00:00

Big names like Bruce Springsteen, Justin Timberlake and Katy Perry were just a few of the famous artists singing songs dedicated to Americans during the inaugural special for President Joe Biden.

## Inside Joe Biden's newly decorated Oval Office
 - [https://www.cnn.com/2021/01/20/politics/inside-joe-biden-oval-office/index.html](https://www.cnn.com/2021/01/20/politics/inside-joe-biden-oval-office/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 06:27:25+00:00

The press got its first glimpse of President Joe Biden's Oval Office on Wednesday, showing how in a matter of hours the office has visibly transformed in both dramatic and subtle ways to reflect the taste and politics of the officeholder.

## 'This moment belongs to all of us:' Black women exult as Kamala Harris walks into history
 - [https://www.cnn.com/2021/01/20/politics/black-women-celebrate-kamala-harris/index.html](https://www.cnn.com/2021/01/20/politics/black-women-celebrate-kamala-harris/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 06:20:52+00:00

Human rights lawyer Tara Murray had hopes of somehow witnessing Kamala Harris' vice-presidential oath in person.

## Fox News host Judge Jeanine lobbied Trump during his last few hours in office to pardon her ex-husband. It worked.
 - [https://www.cnn.com/2021/01/20/politics/judge-jeanine-lobbied-trump-pardon-ex-husband/index.html](https://www.cnn.com/2021/01/20/politics/judge-jeanine-lobbied-trump-pardon-ex-husband/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 06:19:54+00:00

Fox News host Judge Jeanine successfully lobbied former President Donald Trump in an eleventh-hour effort to pardon her ex-husband in the final hours of Trump's presidency, CNN has learned.

## Biden changes America in an instant -- but tougher challenges loom
 - [https://www.cnn.com/collections/biden-day-one-presidency-intl/](https://www.cnn.com/collections/biden-day-one-presidency-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 05:51:32+00:00



## Young poet calls on Americans to 'leave behind a country better than the one we were left'
 - [https://www.cnn.com/2021/01/20/politics/amanda-gorman-inauguration-poem-trnd/index.html](https://www.cnn.com/2021/01/20/politics/amanda-gorman-inauguration-poem-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 04:34:35+00:00

Amanda Gorman, the nation's first-ever youth poet laureate, challenged Americans Wednesday to unify and "leave behind a country better than the one we were left" as she delivered a stirring inauguration poem.

## Indian state renames dragon fruit to avoid association with China
 - [https://www.cnn.com/2021/01/20/asia/india-dragonfruit-name-intl-hnk-scli/index.html](https://www.cnn.com/2021/01/20/asia/india-dragonfruit-name-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 04:13:21+00:00

The Indian state of Gujarat has decided to change the name of dragon fruit, claiming that the original name was associated with China, which drew derision from the country's opposition on Wednesday.

## Biden and first lady watch fireworks display from White House
 - [https://www.cnn.com/videos/politics/2021/01/21/joe-jill-biden-fireworks-celebration-inauguration-vpx.cnn](https://www.cnn.com/videos/politics/2021/01/21/joe-jill-biden-fireworks-celebration-inauguration-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 03:48:32+00:00

President Joe Biden and first lady Jill Biden were seen on the Blue Room balcony above the White House South Lawn watching the fireworks that closed out the Inauguration Day events.

## White House press secretary vows transparency and honesty on first day
 - [https://www.cnn.com/videos/media/2021/01/20/white-house-press-briefing-biden-presidency-jen-psaki-inauguration-vpx.cnn](https://www.cnn.com/videos/media/2021/01/20/white-house-press-briefing-biden-presidency-jen-psaki-inauguration-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 03:00:38+00:00

White House press secretary Jen Psaki holds the first press briefing of Joe Biden's presidency vowing transparency and honesty.

## Biden starts fast on immigration by halting wall and travel ban
 - [https://www.cnn.com/2021/01/20/politics/immigration-daca-border-wall-biden-agenda/index.html](https://www.cnn.com/2021/01/20/politics/immigration-daca-border-wall-biden-agenda/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 02:39:05+00:00

President Joe Biden kicked off his term by signing out a series of immigration executive actions, moving swiftly to undo many Trump administration policies and ending the national emergency that diverted millions of dollars to the border wall.

## CNN's Kaitlan Collins cracks up over CNN throwback video
 - [https://www.cnn.com/videos/media/2021/01/21/kaitlan-collins-wolf-blitzer-john-king-throwback-vpx.cnn](https://www.cnn.com/videos/media/2021/01/21/kaitlan-collins-wolf-blitzer-john-king-throwback-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 02:21:07+00:00

CNN's Wolf Blitzer and John King share advice and a '90s throwback after Kaitlan Collins' promotion to chief White House correspondent.

## Proud Boys leader Joseph Biggs arrested in Florida in connection with the Capitol riot
 - [https://www.cnn.com/2021/01/20/us/proud-boys-joseph-biggs-federal-charges/index.html](https://www.cnn.com/2021/01/20/us/proud-boys-joseph-biggs-federal-charges/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 01:53:13+00:00

A leader of the Proud Boys, an extremist group that took part in the US Capitol insurrection, was taken into custody and is facing charges, federal officials said.

## For one year, this man is eating only what's grown at Dubai's Sustainable City
 - [https://www.cnn.com/2021/01/20/middleeast/dubai-sustainable-city-food-experiment-spc-intl/index.html](https://www.cnn.com/2021/01/20/middleeast/dubai-sustainable-city-food-experiment-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 01:45:06+00:00

Landscape architect Phil Dunn has taken on an ambitious challenge. For one year, he is basing his diet on food grown in his local community, in an effort to highlight the issues of food sustainability and food waste.

## Owner of Ben and Jerry's: We'll ensure every worker in our supply chain gets a living wage
 - [https://www.cnn.com/2021/01/20/business/unilever-living-wage/index.html](https://www.cnn.com/2021/01/20/business/unilever-living-wage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 00:28:39+00:00

Unilever has promised that every worker who provides it with goods and services will earn a living wage by 2030 even if it costs the company more.

## North Korea's 'dark' fishing fleet went quiet in 2020, likely pressuring the country's imperiled food supply
 - [https://www.cnn.com/2021/01/20/asia/north-korea-squid-fishing-intl-hnk/index.html](https://www.cnn.com/2021/01/20/asia/north-korea-squid-fishing-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-01-21 00:08:00+00:00

The number of North Korean ships in the country's "dark fleet" fishing for squid plummeted in 2020, new data shows, depriving the impoverished country of a popular staple during a year when food supply was already dangerously low.

