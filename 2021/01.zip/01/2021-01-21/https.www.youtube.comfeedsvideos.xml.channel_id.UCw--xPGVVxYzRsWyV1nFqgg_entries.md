# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Author Drama (often) Is Not Real
 - [https://www.youtube.com/watch?v=mUgnlXhooHo](https://www.youtube.com/watch?v=mUgnlXhooHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-22 00:00:00+00:00

We're all pretty chill actually! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Light of the Jedi/Sufficiently Advanced Magic-REVIEW
 - [https://www.youtube.com/watch?v=kCXzb1BGRrs](https://www.youtube.com/watch?v=kCXzb1BGRrs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-01-21 00:00:00+00:00

My review of two fantasy novels coming at ya. We have Light of the Jedi, and Sufficiently Advanced Magic. One from the High Republic, the other from the Arcane Ascension. Lets talk review!

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

