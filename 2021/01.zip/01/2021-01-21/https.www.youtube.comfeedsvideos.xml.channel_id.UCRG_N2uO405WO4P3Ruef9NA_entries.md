# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## This is the end for LG phones?
 - [https://www.youtube.com/watch?v=_fMGJXa2qhE](https://www.youtube.com/watch?v=_fMGJXa2qhE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-01-22 00:00:00+00:00

This week LG was rumored to exit its phone business, 3 new mobile chips were launched (the Snapdragon 870 + Dimensity 1200 + Dimensity 1100) and there was yet another Huawei ban.

The Friday Checkout - Episode 32

Mentioned in the video: Snapdragon 888 overheating - https://youtu.be/cfjsx3pso6k

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄

Our Weekly Tech Knowledge Quiz is available:

In the Crrowd app: https://play.google.com/store/apps/details?id=com.crrowd
On the web: https://crrowd.com/quiz

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions ◄◄◄

Music by Edemski: https://soundcloud.com/edemski

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Time stamps ◄◄◄

0:00 Intro
0:33 LG might exit phones
3:53 3 new mobile chips
5:42 Yet another Huawei ban

