# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## The Time America Almost Stopped Climate Change | Climate Town
 - [https://www.youtube.com/watch?v=MondapIjAAM](https://www.youtube.com/watch?v=MondapIjAAM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2021-01-21 00:00:00+00:00

We've totally beefed it on climate policy for 30 years, let's try a new approach. 
sUbScRiBe FoR mOrE ViDes: https://www.youtube.com/c/climatetown?sub_confirmation=1
PATREON PAGE: https://www.patreon.com/ClimateTown

First and foremost, thank you so much for taking that little trip down memory lane with me. It's easy to forget that there was a time when the greenhouse effect wasn't politically controversial, and Exxon was the world leader in climate science. There's probably a good utopian novel about what would have happened if a few things had gone differently. Oh well.

THREE ORGANIZATIONS YOU SHOULD JOIN RIGHT NOW:
Sunrise Movement: https://www.sunrisemovement.org/volunteer/
Extinction Rebellion: https://extinctionrebellion.us/get-involved
Climate Action Network: http://www.climatenetwork.org/

SOURCES:
https://docs.google.com/document/d/10X4uouJLQQ-vEop35Vpstb1SZK6USm5bUYCsGTiSVl0/edit?usp=sharing


Follow Climate Town on Instagram: https://www.instagram.com/climatetown 
if you wanna see ... I dunno, mostly memes and some lukewarm takes about climate change I guess?

Also, join our ... jesus christ, how many things am I asking you to JOIN?
Mailing list: https://www.climatetownproductions.com/

Also, subscribe to @Climemechange on Instagram: https://www.instagram.com/climemechange
They're the best in the game.

Some reading to do:

The Merchants of Doubt: https://www.merchantsofdoubt.org/
All We Can Save: https://www.allwecansave.earth/
The Uninhabitable Earth: https://www.penguinrandomhouse.com/books/586541/the-uninhabitable-earth-by-david-wallace-wells/
This Changes Everything: Capitalism vs. The Climate: https://thischangeseverything.org/book/

