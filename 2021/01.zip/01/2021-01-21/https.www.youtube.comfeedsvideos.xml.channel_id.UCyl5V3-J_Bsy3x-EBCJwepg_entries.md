# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Not My President And Skynet Can Do Whatever It Wants
 - [https://www.youtube.com/watch?v=_b7D7odPQds](https://www.youtube.com/watch?v=_b7D7odPQds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-22 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk about the week’s biggest stories like Skynet being a private company so their Terminator robots can do whatever they want to you, Democratic states are suddenly following the science on lockdowns, and how the right is learning from the left’s past four years on how to cope when they feel like the president is not their president. There’s weird news, glorious hate mail, and Kyle can’t say the word “dang.”

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Is Biden Really Going To Distribute Federal Aid Based On Skin Color?
 - [https://www.youtube.com/watch?v=PORN6bsGR6M](https://www.youtube.com/watch?v=PORN6bsGR6M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-01-21 00:00:00+00:00

The Babylon Bee discusses Biden's new government initiatives for distributing federal aid, including Biden's innovative new skin color chart he will use to determine who gets helped first.

See the full show here:
https://youtu.be/SfaNhY-Wddk

Subscribe to The Babylon Bee to keep informed on all the wonderful things Biden will bring to us. 

Hit the bell to get your daily dose of fake news that you can trust.

