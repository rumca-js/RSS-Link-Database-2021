# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Bernie's Big Bluff - How the Largest Ponzi Scheme Went Undetected for DECADES
 - [https://www.youtube.com/watch?v=GHno799VaZw](https://www.youtube.com/watch?v=GHno799VaZw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-22 00:00:00+00:00

Bernard "Bernie" L. Madoff was a market maker, wall street icon and convicted fraudster. He ran a Ponzi Scheme amounting to $64.8 Billion when all was said an done. Today we answer a key question surrounding Bernie that has plagued the SEC for years. 

Why was he never caught?

Sources
OIG Report on the SEC https://www.sec.gov/spotlight/secpostmadoffreforms/oig-509-exec-summary.pdf?bcsi_scan_447638299E31E942=CRVCo2TKAfVdMG8paJbsFAwAAABs0YIO&bcsi_scan_filename=oig-509-exec-summary.pdf
SEC Secondary Report https://www.sec.gov/news/studies/2009/oig-509/exhibit-0281.pdf 
Coldfusion - https://www.youtube.com/watch?v=gDqGSmTPtOQ&t=278s
Bernie Doc https://www.youtube.com/watch?v=AO4CIPuaTJ4&t=1888s
Financial Times https://www.ft.com/content/823958ba-97fa-11de-8d3d-00144feabdc0
Ponzi SuperNova - An Audible Podcast


twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## OnlyFans Fake Gurus Are Here
 - [https://www.youtube.com/watch?v=RhmJ6xPil5o](https://www.youtube.com/watch?v=RhmJ6xPil5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-01-22 00:00:00+00:00

I'm changing careers guys...
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

