## Facebook Gives FBI Private Messages of Capitol Hill Protesters
 - [https://www.breitbart.com/tech/2021/01/21/facebook-gives-fbi-private-messages-of-capitol-hill-protesters/](https://www.breitbart.com/tech/2021/01/21/facebook-gives-fbi-private-messages-of-capitol-hill-protesters/)
 - RSS feed: www.breitbart.com
 - date published: 2021-01-21 12:26:49+00:00



