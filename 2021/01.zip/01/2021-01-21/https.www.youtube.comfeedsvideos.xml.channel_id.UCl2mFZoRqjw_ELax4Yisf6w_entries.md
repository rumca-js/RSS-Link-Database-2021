# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Manhattan retail rents PLUMMETING? No Bloomberg.. no they are not.
 - [https://www.youtube.com/watch?v=GaK5MyNp_Bo](https://www.youtube.com/watch?v=GaK5MyNp_Bo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-01-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 https://www.bloomberg.com/news/articles/2021-01-19/manhattan-retail-rents-plummet-as-pandemic-s-pounding-lingers?sref=lagJc1td
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## New iPhones FATAL to pacemaker users?
 - [https://www.youtube.com/watch?v=WH2oAX-8hpM](https://www.youtube.com/watch?v=WH2oAX-8hpM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-01-21 00:00:00+00:00

https://discord.gg/rossmanngroup
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 https://bhrs.com/important-life-saving-therapy-inhibition-by-phones-containing-magnets/
👉 https://www.hexus.net/mobile/news/accessories/147250-british-heart-rhythm-society-warns-apple-iphone-12/
👉 IRP program, why it's bad: https://www.reddit.com/r/RealTesla/comments/ith4va/tesla_detects_unauthorized_modifications_after/g5g3vip/?utm_source=share&utm_medium=web2x&context=3
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## WallStreetBets vs. 💩Citron Research.
 - [https://www.youtube.com/watch?v=pgF29sgkUbg](https://www.youtube.com/watch?v=pgF29sgkUbg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-01-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.reddit.com/r/wallstreetbets/comments/l1ca4x/shitron_just_rememebered_that_the_inauguration_is/

IT IS MY OPINION THAT WASTING YOUR HARD EARNED MONEY INVESTING IN MEME STOCKS IS A HORRIBLE WAY TO SPEND YOUR MONEY, FFS, DO NOT DO IT!

The Content is for informational purposes only, you should not construe any such information or other material as legal, tax, investment, financial, or other advice. Nothing contained on our Site constitutes a solicitation, recommendation, endorsement, or offer by HII or any third party service provider to buy or sell any securities or other financial instruments in this or in in any other jurisdiction in which such solicitation or offer would be unlawful under the securities laws of such jurisdiction. My only two holdings at this point in time of making this video are some shares in ICLN & BB, and that's all.

