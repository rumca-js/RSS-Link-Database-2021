# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Cat Power - three live performances (2018)
 - [https://www.youtube.com/watch?v=hu3Vku8SfAg](https://www.youtube.com/watch?v=hu3Vku8SfAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-22 00:00:00+00:00

Happy birthday to Cat Power! Chan Marshall – aka Cat Power – was born on January 21 in Atlanta. In honor of Marshall's birthday, here are three performances by Cat Power from a December 2018 episode of Live From Here, recorded at the Town Hall in New York. The set includes two songs from Cat Power's 2018 album, "Wanderer," and one from her 1998 release, "Moon Pix."

SONGS PERFORMED
0:00 "He Turns Down"
3:40 "Robbin Hood"
6:17 "In Your Face/Bad Religion"

PERSONNEL
Chan Marshall – vocals
Erik Paparozzi – piano
Adeline Jasso – guitar
Alianna Kalaba – drums

CREDITS
Video & Photo: Ben Miller; American Public Media
Audio: Sam Hudson
Production: Tom Campbell; Jeffy Hnilicka

FIND MORE:
2018 Cat Power interview: https://www.thecurrent.org/feature/2018/10/05/cat-power-interview

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#catpower #catpowermusic

## Margaret Glaspy - two songs at The Current (2018)
 - [https://www.youtube.com/watch?v=CYA-M8woSfk](https://www.youtube.com/watch?v=CYA-M8woSfk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-01-21 00:00:00+00:00

On January 20, 2017, Margaret Glaspy visited The Current studio for the first time, performing songs from her debut album, "Emotions and Math." A little more than a year later, Glaspy returned to The Current to play songs from her follow-up EP, "Born Yesterday." Watch Glaspy and Julian Lage perform two songs from that session.

SONGS PERFORMED
0:00 "Before We Were Together"
3:53 "I Love You, Goodnight"

PERSONNEL
Margaret Glaspy – vocals, guitar
Julian Lage – guitar

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: David Safar, Derrick Stevens

FIND MORE:
2017 studio session: https://www.thecurrent.org/feature/2017/01/20/margaret-glaspy-performs-in-the-current-studio
2017 Rock the Garden set:
https://www.thecurrent.org/feature/2017/08/06/listen-to-margaret-glaspy-kick-off-rock-the-garden-2017
2018 studio session: https://www.thecurrent.org/feature/2018/04/06/margaret-glaspy-performs-born-yesterday-songs-in-the-current-studio
2020 virtual session:
https://www.thecurrent.org/feature/2020/04/21/watch-margaret-glaspy-perform-two-songs-from-devotion

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#margaretglaspy

