# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - IMPERIAL ASSASSINS - THE EVERSOR HORROR & RECRUITMENT | Warhammer 40,000 Lore/History
 - [https://www.youtube.com/watch?v=_JGCMAl8jwc](https://www.youtube.com/watch?v=_JGCMAl8jwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2021-01-22 00:00:00+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Siege Studios: https://siegestudios.co.uk/
► Patreon: https://www.patreon.com/Luetin 
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Premium Storage Solutions: https://www.crystal-fortress.com/
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

0:00 Intro
2:26 Death Incarnate
8:38 Trial by Pain
18:25 Body Horror
23:47 The Living Death
28:11 Wargear
34:29 Fear the Imperium
36:49 Retaliation

Retaliation is an excerpt from the publicly released short stories as part of GW's Psychic Awakening series this one authored by Dirk Wehner - https://www.warhammer-community.com/2020/04/27/psychic-awakening-retaliation/

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

