# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## 99 Red Balloons + Take On Me Mashup // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=s4KWQWkJeK8](https://www.youtube.com/watch?v=s4KWQWkJeK8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-01-21 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 IT'S 80's MASHUP TIME!!!!!! 99 Red Balloons + Take On Me = NENA + a-ha = NENA-HA! Wow. That was just too easy.

Become a patron by Feb. 1 to get a "Worst of 2020" CD and VOTE what songs go on it: http://patreon.com/pomplamoose

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic

A mashup of NENA's "99 Red Balloons" and A-ha's "Take On Me" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar: Ryan Lerman
Bass: Nick Campbell
Drums: Tamir Barzilay
Additional Percussion: Ben Rose
Background Vocals: Loren Battley

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Tyler Karmen
Mixing/Mastering: Yianni AP
Producer: Ben Rose
Mashup Arrangement: Brian Green & Erin Bentlage

VIDEO CREDITS
Director: George Sloan
DP: Ricky Chavez
Camera Operators: Ricky Chavez, Merlin Showalter, Sammy Rothman, Dijon Herron
Video Editor: Athena Wheaton

Recorded at 64 Sound in Los Angeles.

LYRICS
You and I in a little toy shop
Buy a bag of balloons with the money we've got
Set them free at the break of dawn
'Til one by one they were gone
Back at base bugs in the software
Flash the message: "something's out there!"
Floating in the summer sky
Ninety-nine red balloons go by

Ninety-nine red balloons
Floating in the summer sky
Panic bells, it's red alert
There's something here from somewhere else
The war machine it springs to life
Opens up one eager eye
Focusing it on the sky
Where ninety-nine red balloons go by

Take on me (take on me)
Take me on (take on me)
I'll be gone
In a day or two

Oh, the things that you say. Yeah.
Is it life or just to play my worries away?
You're all the things I've got to remember
You're shying away
I'll be coming for you anyway

Take on me (take on me)
Take me on (take on me)
I'll be gone
In a day or two

This is what we've waited for
This is it, boys, this is war
The president is on the line
As ninety-nine red balloons go by

Take on me (take on me)
Take me on (take on me)
I'll be gone
(In a day or two)

Take on me (take on me)
Take me on (take on me)
I'll be gone
(In a day or two)

#Pomplamoose #Mashup #99RedBalloons #TakeOnMe #80sMusic

