# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## The War on Drugs - three songs from a MicroShow (2017)
 - [https://www.youtube.com/watch?v=d7iN4AKb0oU](https://www.youtube.com/watch?v=d7iN4AKb0oU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-30 00:00:00+00:00

On Friday, The Current's Mac Wilson spoke to Adam Granduciel of The War on Drugs about that band's new album, "I Don't Live Here Anymore," which was released today (Oct. 29, 2021). In the course of their conversation, Wilson and Granduciel reflected on a MicroShow that The War on Drugs recorded for The Current back in 2017. "Legendary show for us within the group," Granduciel said. "It was amazing. … We still talk about that show."
Here are three performances by The War on Drugs from that 2017 MicroShow, recorded at The Turf Club in St. Paul. 

SONGS PERFORMED
00:00 "Holding On"
04:38 "In Reverse"
10:31 "You Don't Have To Go"

PERSONNEL
Adam Granduciel – vocals, guitars, harmonica
David Hartley – bass guitar
Robbie Bennett – keyboards
Charlie Hall – drums
Jon Natchez – keyboards 
Anthony LaMarca – guitar, keyboards 

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2014 studio session: https://www.thecurrent.org/feature/2014/09/24/the-war-on-drugs-perform-live-in-the-current-studio
2017 MicroShow: https://www.thecurrent.org/feature/2017/08/28/the-war-on-drugs-share-old-and-new-songs-at-the-turf-club
2021 Adam Granduciel interview:
https://www.thecurrent.org/feature/2021/10/29/the-war-on-drugs-adam-granduciel-on-i-dont-live-here-anymore

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#thewarondrugs #thewarondrugsband

## Spoon - three songs for The Current (2007, 2010, 2014)
 - [https://www.youtube.com/watch?v=ecyw51gtEVk](https://www.youtube.com/watch?v=ecyw51gtEVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-29 00:00:00+00:00

Earlier today, Spoon announced a brand-new album, "Lucifer on the Couch," and released the single, "The Hardest Cut." In honor of that, we looked back at some great performances Spoon have done for The Current. Enjoy these performances from 2007, 2010 and 2014. 

SONGS PERFORMED
0:00 "Don't You Evah" (2007)
3:15 "Written in Reverse" (2010)
7:22 "Rent I Pay" (2014)

CREDITS
Video & Photo: Bo Hakala; Laura Gill; Erik Sudheimer; Nate Ryan; Eric Schleicher; Dan Bruns; Donnie Koshiol; Greg Beckel; Andy Underwood-Bultmann
Audio: Michael DeMark; Rob Byers; Cameron Wiley; Zach Rose; Johnny Vince Evans
Production: Derrick Stevens; Brett Baldwin

FIND MORE:
2017 studio session: https://www.thecurrent.org/feature/2017/09/16/spoon-in-studio-hot-thoughts-britt-daniel
2010 studio session: https://www.thecurrent.org/feature/2010/04/02/spoon-live
2007 studio session:
https://www.thecurrent.org/feature/2007/10/11/spoon

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#spoon #spoontheband

## The War on Drugs' Adam Granduciel on "I Don't Live Here Anymore" (Interview with The Current)
 - [https://www.youtube.com/watch?v=3bjxIbwa_6Y](https://www.youtube.com/watch?v=3bjxIbwa_6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-29 00:00:00+00:00

Adam Granduciel of The War on Drugs joins The Current's Mac Wilson to discuss the band's fifth studio record, "I Don't Live Here Anymore". Granduciel talks about getting the band back together after 20 months apart, their 2020 live album "Live Drugs," and how fatherhood has affected his creative process.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits:
Host - Mac Wilson
Guest - Adam Granduciel
Technical Director - Peter Ecklund
Producers - Jesse Wiza, Derrick Stevens
Performance Director/Editor - Ray Lynch
Performance Audio Mixer - Austin Asvanonda 

Band:
Adam Granduciel - vocals, guitar
Dave Hartley - bass, backing vocals
Robbie Bennett - keys
Charlie Hall - drums
Jon Natchez - keys, horns
Anthony LaMarca - guitar, backing vocals

