# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Paw Patrol To Face Their Greatest Foe Yet: Dr. Fauci
 - [https://www.youtube.com/watch?v=I0ktCwOY_Aw](https://www.youtube.com/watch?v=I0ktCwOY_Aw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-29 00:00:00+00:00

Dr. Anthony Fauci will guest star in an upcoming episode of Paw Patrol! Will the pups survive his sandfly torture? Chase is on the case!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## THE BEE WEEKLY: A G.K. Chesterton Special With Dale Ahlquist and Cheese
 - [https://www.youtube.com/watch?v=lmekyic4pmo](https://www.youtube.com/watch?v=lmekyic4pmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-29 00:00:00+00:00

It's Chestermania 2021 at The Babylon Bee and Kyle and Ethan are joined by the President of the Society of G.K. Chesterton, Dale Ahlquist. Dale has been called the greatest living authority on the life and work of G.K. Chesterton and has authored five books on Chesterton, including Common Sense 101: Lessons from Chesterton and G.K. Chesterton: Apostle of Common Sense. Why should people start reading Chesterton and where should they begin? What are some of Chesterton's big concepts that help to unlock an understanding of his writings? What would Chesterton say about Cheetos?

Be sure to check out The Society of Gilbert Keith Chesterton at: https://www.chesterton.org/

Kyle, Ethan, and Dale, accompanied by Adam Yenser, play a special edition of Real or Fake where the headlines are all supposedly weird news headlines from a hundred years ago. They discuss how prophetic Chesterton was and talk about his prominent books and essays that you must read to not waste your life. Then in the subscriber portion, they discuss cheese and Chesterton’s big concepts that he returned to again and again throughout his life’s work. Dale answers subscriber-submitted G.K. Questertons and is subjected to The Ten Questions! Click Join on YouTube to watch the whole episode!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

