# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The 2021 MacBook Pros are Insane
 - [https://www.youtube.com/watch?v=Qh1ElqW5dEY](https://www.youtube.com/watch?v=Qh1ElqW5dEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2021-10-29 00:00:00+00:00

The 2021 MacBook Pro gets torn town, benchmarked, analyzed, and notched. Is the hype justified? I submit that it certainly... might be.

Buy base 14" 8/14 M1 Pro for $50 off - https://amzn.to/3Gx6bVP
Buy 14" 10/16 M1 Pro for $50 off - https://amzn.to/3bkDJIa
Buy 16" 10/16 M1 Pro for $50 off - https://amzn.to/2ZxUCgA
Buy 16" 10/24 M1 Max for $50 off - https://amzn.to/3CuUgW3
Buy the good 'ol M1 MacBook Air for $50 off - https://amzn.to/3Gx6bVP

Chapters:
0:00 - Introduction
0:38 - Teardown
5:58 - Thunderbolt Buses
6:55 - MAXIMUM CHARGE!
8:09 - High Impedance Headphones
10:55 - MagSafe 3 vs 2008 MagSafe
12:31 - Magnets, B*tch
13:21 - Insertion Test
14:31 - Notch Things...
15:24 - Rounded Corners vs Square Corners
16:11 - Breaking EVERYTHING
17:31 - snazzybrokey.exe
18:49 - Fullscreen Mode
20:02 - Microphone Oddities
21:04 - "Studio Quality Microphones"
21:22 - keyboard feel, keyboard feel, keyboa
22:47 - But how fast is it?

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

The M1 MacBook Pro with M1 Pro and M1 Max has just released to much fanfare. These devices have a ton of interest from the general public after the addition of HDMI, and SD card slot, a high-impedance headphone jack, improved cooling, and more—even if that means it has to have a notch.

Thumbnail by Shahrukh Ali - https://twitter.com/Shahrukh__Ali

