# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete History of the Easterlings | Tolkien Explained
 - [https://www.youtube.com/watch?v=GUxo-rYa7XU](https://www.youtube.com/watch?v=GUxo-rYa7XU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-10-30 00:00:00+00:00

The Easterlings are among the fiercest enemies of Gondor in the Third Age, but how did this come to be? And were all Easterlings truly evil?  We answer these questions and more by covering the complete history of the Easterlings.  We track their migration to Beleriand in the First Age, their influence under Morgoth, and their battles with Gondor - and each other!  We also look at the clues we have regarding the Blue Wizards, and how they may have been involved with the Easterlings!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark

Warriors of the East - Alvaro Calvo Escudero
Khamul the Easterling - Sam Lamont
Recurved Bow - Martin de Diego
Easterling Lancers - Luke Martins
Wainrider Captain - David Home
First Sunrise in Hildorien - Sarka Skorpikova
Arien - Lady Elleth
Vessels - Sarka Skorpikova
Orome Discovers the Elves - Kip Rasmussen
The Edain - Wouter Florusse
Beleriand Map - Lamaarcana
Bor with his sons - Helena Stepanova
Maedhros meets Bor the Faithful close up - Erranruin
Gwindor's Charge - Peet
Dagor Nirnaeth Arnoediad - John Howe
For Maglor slew Uldor the Accursed - Jenny Dolfen
Silmarillion 8 - Fumeres Art
Easterling Warrior - One Two Three Kaboom
Maedhros - Lomacchi
Ulfang with sons seeking audience with Caranthir - Helena Stepanova
Orcs - Gellihana Art
Tuor Escapes the Easterlings - Peet
Turin and Brodda - Denis Gordeev
Turin - Kenneth Sofia
Hall of Brodda Burning - Alan Lee
Turin Turambar - A Shipwright
Easterling - John Howe
Hurin and Morgoth - Denis Gordeev
Nienor finds Turin - Kenneth Sofia
Hurin finds Morwen - Ted Nasmith
Melkor and Hurin - Edarlein
Khand Warriors - Turner Mohan
Hurin at Nargothrond - Pete Amachree
Easterlings - Merlkir
Khamul the Easterling - Peterlof
Easterling Ringwraith - Olivier Dafarrer
The Blue Wizards Journeying East - Ted Nasmith
Easterling Tents - Merlkir
Nazgul - Jules Thavenet
Wainriders - Stefano Baldo
Veteran Wainrider - Herckeim
Chariot Driver - Herckeim
The fall of King Ondoher - Jack Dullahan
Earnil ii, King of Gondor - Yoritomodaishogun
Minas Tirith - Ludovic Bourgeois
The Red Arrow - Paula DiSante
Easterling Retreat - Aleksander Karcz
Sauron - Johnny Slowhand
Warrior of Rhun - ebaz1204
Rhun Lancer - Jan Pospisil
Rohan at Pelennor Fields - Cristian Otazu
Dale unites vs Rhun - Jan Pospisil
King Brand and King Dain Ironfoot - Steamey
At the Cracks of Doom - Ted Nasmith
Battle of the Dale - Joona Kujanen
Eomer and Aragorn Ride to the Lands of the East - Kip Rasmussen
Sauron - Spartank42
Easterling Guard - Alvaro Calvo Escudero
Morano Horsemen - Starfall
Easterling - Olanda Fong-Surdenas
The Last Easterling - Sanders Creative
Alatar and Pallando - Ralph Damiani
The Blue WIzards - Turner Mohan
Easterling - Turner Mohan
Sauron - Jerry Vanderstelt
Easterling Pursuit - Herckeim
Sauron - Jean Pascal Leclerc
Armenelos - Nemanja Bubalo
The Drowning of Numenor - John Howe
Wainriders - Stefano Baldo
Easterling Pursuer - Herckeim
Easterling Skirmisher - Martin de Diego
Blue wizard Pallando - Jack Dullahan
Easterling Tent Inside - Grzegorz Mrozek

#easterlings #tolkien #lordoftherings

