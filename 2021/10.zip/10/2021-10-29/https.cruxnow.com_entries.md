## Italy’s disputed homophobia bill defeated in Senate
 - [https://cruxnow.com/church-in-europe/2021/10/italys-disputed-homophobia-bill-defeated-in-senate](https://cruxnow.com/church-in-europe/2021/10/italys-disputed-homophobia-bill-defeated-in-senate)
 - RSS feed: https://cruxnow.com
 - date published: 2021-10-29 22:00:47+00:00

Italy’s disputed homophobia bill defeated in Senate

