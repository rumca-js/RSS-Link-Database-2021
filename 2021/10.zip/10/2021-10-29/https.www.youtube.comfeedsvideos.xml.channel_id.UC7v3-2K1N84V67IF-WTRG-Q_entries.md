# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Last Night In Soho - Movie Review
 - [https://www.youtube.com/watch?v=szka3Va0saY](https://www.youtube.com/watch?v=szka3Va0saY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-10-29 00:00:00+00:00

Edgar Wright brings us a mystery/thriller with a splash of horror in LAST NIGHT IN SOHO. Here's my review!

