# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Geese - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=L9UsOajfuf4](https://www.youtube.com/watch?v=L9UsOajfuf4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-30 00:00:00+00:00

http://KEXP.ORG presents Geese performing live, recorded exclusively for KEXP.

Songs:
Disco
Low Era
Exploding House
Everybody's Got Something To Hide Except Me And My Monkey (Beatles cover)
untitled

Cameras: Luke Ackermann
Sound Engineer: Gus Green

Cameron Winter - vocals
Gus Green - guitar 
Foster Hudson - guitar
Dom DiGesu - bass
Max Bassin - drums

https://geeseband.com
http://kexp.org

## Geese - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=z-hHbQtYOHc](https://www.youtube.com/watch?v=z-hHbQtYOHc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-29 00:00:00+00:00

http://KEXP.ORG presents Geese sharing a live performance recorded exclusively for KEXP and talking to Cheryl Waters. Recorded October 12, 2021.

Songs:
Disco
Low Era
Exploding House
Everybody's Got Something To Hide Except Me And My Monkey (Beatles cover)
untitled

Cameras: Luke Ackermann
Sound Engineer: Gus Green

Cameron Winter - vocals
Gus Green - guitar 
Foster Hudson - guitar
Dom DiGesu - bass
Max Bassin - drums

https://geeseband.com
http://kexp.org

