# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Zzzax works revisited (A500r6a🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=rIfKMQJPLgk](https://www.youtube.com/watch?v=rIfKMQJPLgk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-10-29 00:00:00+00:00

Collection of Soundmon works from Zzzax/The Time Circle (Sebastiaan Lentfert). More info below.

From actual demos or musicdisks using A500 r6a (so no DeliTracker playback here). Spacy from Orchestral Delight (1991, Taipan^The Time Circle), the rest from Expressions (1989, The Time Circle). We lose some clarity against A1200, but we gain playback accuracy. A1200 had problems with Visor at least (drum part at the end plays wrong, don't ask why), which means i couldn't trust it with any Zzzax Soundmon playback. And looks like these are from about 1989, which means A500 is the more period accurate machine for these anyways. I prefer these to any of my earlier uploads from Zzzax for sure.

00:00 Spacy
04:04 Voyage
07:19 Expressions (original 1985 "Le Parc (L.A. - Streethawk)" by Tangerine Dream)
09:45 Selector
10:09 No Mercy
14:01 New Dimension
18:19 Pulstarmix (original 1976 "Pulstar" by Vangelis)
20:51 Synthdrum
24:05 Visor

Visit my channel for more Amiga music.

