# Source:FoldingIdeas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ, language:en-US

## Jamie Oliver's War on Nuggets
 - [https://www.youtube.com/watch?v=V-a9VDIbZCU](https://www.youtube.com/watch?v=V-a9VDIbZCU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ
 - date published: 2021-10-29 16:51:16+00:00

Clickbait Title: Chefs Hate Him!

Big thanks to Hot Dad for letting me use his absolute banger, you can put the whole song in your ear holes here: https://www.youtube.com/watch?v=qr-sDJX72WY

I wanted to make this because I see this clip make the rounds again and again and every time I'm like "of all the arguments you could make, that's the worst one." So I decided to make a whole video around "of all the arguments you could make, that's the worst one." Jamie Oliver in particular seems to have that effect on people, he gets into this kinda crap all the time, and I think it has a lot to do with the sheer audacity of his lies or near-lies that make even people otherwise sympathetic to his goals wish that he'd just go away. The willingness to just brazenly misrepresent how and why things are the way they are demonstrates a fundamental disrespect for the intelligence of the viewer.

Written and performed by Dan Olson

Crowdfunding: https://www.patreon.com/foldablehuman
Twitter: https://twitter.com/FoldableHuman

