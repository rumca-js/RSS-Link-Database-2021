# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## The big Android 12L update - explained!
 - [https://www.youtube.com/watch?v=lW-87Pu9kj0](https://www.youtube.com/watch?v=lW-87Pu9kj0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-10-29 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc

Technorama Episode 2: https://nebula.app/videos/technorama-the-politics-tech-that-inspired-killer-scifi-robots

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week Android 12L was announced for foldables, tablets, Chromebooks and more, Intel's 12th generation processors called Alder Lake brought some major improvements and Facebook became Meta, a metaverse company.

Episode 69 (nice)


This video on Nebula: https://nebula.app/videos/the-friday-checkout-android-12l-explained-coming-to-foldables-tablets

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 

Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:31 Release Monitor
1:39 Android 12L
4:13 Intel Alder Lake
6:04 Facebook Metaverse

