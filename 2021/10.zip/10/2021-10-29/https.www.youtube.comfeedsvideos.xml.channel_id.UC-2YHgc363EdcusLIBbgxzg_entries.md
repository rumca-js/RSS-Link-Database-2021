# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## "Aurora" Live Script Reading!
 - [https://www.youtube.com/watch?v=hIHjoLY_w7k](https://www.youtube.com/watch?v=hIHjoLY_w7k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-10-30 00:00:00+00:00

Join me and my cast of talented friends as we perform a live reading of my feature screenplay, "Aurora".
It's based on the true story of a UFO crash that occurred in the small Texas town of Aurora in 1897. Come join us, it'll be fun!

Superchat revenue will be donated to #TeamSeas, who are raising money to remove 30 million pounds of plastic from the ocean. You can add your support here:  http://www.teamseas.org

Check out the Aurora playlist on Spotify, featuring songs that helped inspire elements of the movie:
https://open.spotify.com/playlist/5E63QWeXULkEqZFqQZ0jnv?si=dfd96eeb261a403f

=========

Get cool nerdy t-shirts at
http://www.answerswithjoe.com/shirts

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Become a channel member and get access to exclusive livestreams and content here:
https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

