# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## How the USA is more Socialist than China
 - [https://www.youtube.com/watch?v=C9bAk_mhPIo](https://www.youtube.com/watch?v=C9bAk_mhPIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2021-10-29 00:00:00+00:00

Go to https://noom.com/laowhy and take your free 30-second quiz! Thank you #noom for sponsoring today’s video!

I break down what things people expect from their countries, and show how China is not really socialist at all. In fact, it's quite the opposite.

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats

Citations for the video - 

https://worldpopulationreview.com/country-rankings/median-income-by-country
https://www.cafonline.org/about-us/publications/2021-publications/caf-world-giving-index-2021
https://www.cfr.org/legal-barriers/country-rankings/chn/
http://www.ibe.unesco.org/en/resources?search_api_views_fulltext=%22WDE%202006%20index
https://www.who.int/healthinfo/paper30.pdf
https://worldpopulationreview.com/country-rankings/freedom-index-by-country
https://freedomhouse.org/country/china/freedom-world/2021
https://www.asherfergusson.com/lgbtq-travel-safety/

