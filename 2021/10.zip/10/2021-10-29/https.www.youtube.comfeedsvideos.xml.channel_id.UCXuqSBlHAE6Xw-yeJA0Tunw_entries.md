# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This could cost me $10,000...
 - [https://www.youtube.com/watch?v=ya3hZQgwHds](https://www.youtube.com/watch?v=ya3hZQgwHds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-30 00:00:00+00:00

Thanks to Intel for sponsoring PC or no PC! Check out their 11th Gen CPU's
On Amazon (PAID LINK): https://geni.us/f51j
On Newegg (PAID LINK): https://geni.us/BzVVmAF
Or learn more about their upcoming 12th Gen CPU's: https://lmg.gg/0OS7K

Get your limited edition PC or no PC shirt today at https://www.lttstore.com/products/limited-edition-pc-or-no-pc-t-shirt

Thank you to Digital Storm for sending over their awesome Velox gaming PC, check it out at https://lmg.gg/velox

Thank you to 45Drives for sending us a kitted out Storinator Q30, check it out at https://lmg.gg/q30

Buy VIZIO 75" Class P-Series Quantum TV
On Best Buy (PAID LINK): https://geni.us/Bp7k
On VIZIO.com: https://lmg.gg/vizio

Buy Secretlab TITAN Stealth
On Secret Lab (Affiliate): https://geni.us/V0f5yU 

Buy CORSAIR ONE a200 PC
On Amazon (PAID LINK): https://geni.us/7V2R
On Corsair.com: https://lmg.gg/MjYRt

Buy Playstation 5
On Amazon (PAID LINK): https://geni.us/kPih4
On Best Buy (PAID LINK): https://geni.us/lpjHBOX
On Newegg (PAID LINK): https://geni.us/Wc5V

Buy HTC Vive Cosmos
On Newegg (PAID LINK): https://geni.us/G0rCFW

Buy GPD Win 3
On Amazon (PAID LINK): https://geni.us/bwcqAD
On Newegg (PAID LINK): https://geni.us/wh2NG8

Buy Logitech G PRO X SUPERLIGHT Wireless Gaming Mouse
On Amazon (PAID LINK): https://geni.us/S00eb
On Best Buy (PAID LINK): https://geni.us/dTAxi1l
On Newegg (PAID LINK): https://geni.us/A8jsYA

Buy Logitech G Pro X Mechanical Gaming Keyboard
On Amazon (PAID LINK): https://geni.us/tAlA
On Best Buy (PAID LINK): https://geni.us/Wa8oIwn
On Newegg (PAID LINK): https://geni.us/kk7u20

Buy Logitech G733 LIGHTSPEED Wireless Headset
On Amazon (PAID LINK): https://geni.us/CY89A
On Best Buy (PAID LINK): https://geni.us/ZHlJ
On Newegg (PAID LINK): https://geni.us/2Gq7y

Buy Logitech G840 Mouse Pad
On Amazon (PAID LINK): https://geni.us/C7NXg
On Newegg (PAID LINK): https://geni.us/83Iv
On B&H (PAID LINK): https://geni.us/0nMl

Buy ASUS ROG Swift PG259QN Monitor
On Amazon (PAID LINK): https://geni.us/mfYJII
On Best Buy (PAID LINK): https://geni.us/L0bG4a
On Newegg (PAID LINK): https://geni.us/Nj1D28v

Buy Apple MacBook Pro M1
On Amazon (PAID LINK): https://geni.us/NGZ1Gqf
On Best Buy (PAID LINK): https://geni.us/lZI4U
On Newegg (PAID LINK): https://geni.us/msoYbW

Thanks to Retro Fighters for sending over some controllers, check them out at https://lmg.gg/8ixnE

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1384844-the-10000-pc-game-show-pc-or-no-pc-episode-1/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro

## We're Changing Our Name - WAN Show October 29, 2021
 - [https://www.youtube.com/watch?v=5MAlgKdsdvg](https://www.youtube.com/watch?v=5MAlgKdsdvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-29 00:00:00+00:00

Check out Secret Lab at https://lmg.gg/SecretLabWAN

Save 10% at Ridge Wallet with offer code WAN at https://www.ridge.com/WAN

Try Pulseway for free and start remotely monitoring and managing your server or PC at https://lmg.gg/Ktd7Z

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Were-Changing-Our-Name---WAN-Show-October-29--2021-e19k96q

Check out our other Podcasts:
They're Just Movies Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (courtesy of NoKi1119):
[0:00] Chapters
[1:33] Intro
[2:02] Topic #1: Meta is the NEW Facebook
    4:31 Meta rebranding, Zuckerberg's statement
    7:54 "Project Cambria" VR headset and Meta Quest
    13:22 Thoughts on the change
[18:08] Topic #2: Intel's "Alder Lake"
    18:48 "TDP" renewal
    21:15 Competitive charts not accurate
    24:52 Are faster CPUs needed for gaming?
[26:52] LTTstore purchase banners & message
[30:20] Topic #3: Linux challenge update
    37:49 Linus's & Luke's experience
    43:35 Streaming, Dolphin & Linux issues
    52:00 Linus's take on GUIs
    56:22 Linux's impact on socializing
    59:42 Good & bad package managers
[1:04:10] Sponsors
    1:04:18 Secretlab chairs
    1:05:06 Ridge Wallet
    1:05:40 PulseWay Remote Monitoring
[1:06:37] Topic #4: Nintendo's N64 subscription
[1:12:13] Topic #5: YT demonitizes bad kid content
[1:14:26] Team Seas
[1:16:11] Topic #6: USCO and right to repair
[1:19:58] LTTStore merch messages
[1:51:05] Screwdriver, newsletter
[1:57:20] Outro

