# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 13 Games That Defined Horror
 - [https://www.youtube.com/watch?v=Bcm6jvWP438](https://www.youtube.com/watch?v=Bcm6jvWP438)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-10-30 00:00:00+00:00

From Resident Evil and Silent Hill to Amnesia and PT, these games stand out as genre defining. While the horror genre was one of the earlier game genres, it has evolved over the years with new ideas and ways to spook players. These are the 13 games that defined horror.

Dave takes a look at a horror timeline, from the origins of horror with Mystery House to how Sweet Home and Alone in the Dark would inspire Resident Evil. Whether it be The 7th Guest inspiring the likes of D and Phantasmagoria or how Amnesia would inspire games like SOMA, Outlast, and Layers of Fear.

## Firearms Expert Reacts To Back 4 Blood’s Guns
 - [https://www.youtube.com/watch?v=6C2NSRtvkm8](https://www.youtube.com/watch?v=6C2NSRtvkm8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-10-30 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the weaponry of Back 4 Blood, including the M14, the Super 90 shotgun assault rifle, and a zombie slaying Desert Eagle.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down the guns of Back 4 Blood and compares them to their real-life counterparts.

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can either purchase Jonathan's book here. - https://www.headstamppublishing.com/bullpup-rifle-book

Or at the Royal Armouries shop here. - https://shop.royalarmouries.org/collections/thorneycroft-to-sa80-british-bullpup-firearms-1901-2020

## Call of Duty: Warzone And Vanguard - Everything We Know So Far
 - [https://www.youtube.com/watch?v=i8SlW_sTKCE](https://www.youtube.com/watch?v=i8SlW_sTKCE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-10-29 00:00:00+00:00

Call of Duty: Warzone's new Pacific map has a release date and a few surprises like a dogfighting mode! Here are the event dates and times to play.

Call of Duty: Vanguard is making it's way to consoles and PC on November 5th. In the meantime, Activision shared a massive blog post surrounding the events at launch, pre-season, as well as news on the all-new pacific map. In this video, Richie Bracamonte breaks down the blog post to give you all the dates, event info and more.

Warzone's new Vanguard pacific map arrives on December 2nd. Players who already own Vanguard will have 24 hours of early access. As we part ways with Verdansk for the last time, Call of Duty announced a few events leading to the map's sendoff. They also hinted that we'll probably leave Verdansk amid another doomsday scenario saying, "Bombs away – see what happens to Verdansk before Warzone goes dark to prepare for Caldera and Season One."

Several other updates were revealed surrounding season one of Vanguard. This includes the full list of multiplayer maps, modes and more. 12 operators are confirmed, all with customizable skins that can be acquired via in-game challenges or by unlocking them in the season 1 battle pass. Long time fans of the franchise will also see the return of "Shipment"- a map that dates back all the way to Call of Duty 4: Modern Warfare. 

Stay tuned to GameSpot for our upcoming review of Call of Duty: Vanguard, as well as continued coverage with gameplay, livestreams and more.   

#COD #CoDVanguard

## How To Play New Warzone Map Early | GameSpot News
 - [https://www.youtube.com/watch?v=jmS6SGSfZiU](https://www.youtube.com/watch?v=jmS6SGSfZiU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-10-29 00:00:00+00:00

In this episode of GameSpot News, we talk about how you can play the Warzone Pacific map early, a mobile game being accused of copying Modern Warfare 2019, and physical GTA on Switch requiring a download.

In this video, Persia talks about the Call of Duty: Vanguard's integration with Warzone on December 2, 2021.Warzone Pacific will also bring the arrival of the recently revealed RICOCHET Anti-Cheat System to hopefully help cut back on Warzone's ongoing cheating problem on the same day it launches. 

Persia also talks about a mobile game called Combat Master being accused of copying Modern Warfare 2019's gameplay and UI. As of October 28, Combat Master Online FPS is still available to download and play, but it is uncertain how long Activision will let this apparent clone slide by without any legal action. 

Later in the video, the physical version of the GTA Trilogy on Switch will reportedly still require a download. On the eShop, The Definitive Edition appears as a bundle containing the three GTA games as separate products, each with a "not available to purchase" alone notice. However, it seems that Grand Theft Auto: Vice City will need a separate download, both when bought physically and digitally.

## November’s Free Games For PS Plus And Xbox Games With Gold | GameSpot News
 - [https://www.youtube.com/watch?v=bQeFipoptE0](https://www.youtube.com/watch?v=bQeFipoptE0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-10-29 00:00:00+00:00

In today’s GameSpot News, Persia goes over all of November’s free games for PlayStation Plus and Xbox Games With Gold, Oculus Quest being renamed to Meta Quest, and the two Tomb Raider games coming to Nintendo Switch in 2022.

The free games that you can redeem this November for PlayStation Plus are Knockout City, First Class Trouble, Kingdoms of Amalur: Re-Reckoning, The Persistence, The Walking Dead: Saints and Sinners, and Until You Fall.

If you have Xbox Games with Gold, you’ll be able to claim four titles throughout November. These free games are Moving Out, Lego Batman 2 DC Super Heroes, Rocket Knight, and Kingdom Two Crowns.

The Oculus Quest is getting a new name to be more in line with Facebook’s rebranding. The Oculus Quest will now be known as the Meta Quest. In other Oculus news, users will no longer be required to sign in the Facebook for use and new login options are coming in 2022.

The Tomb Raider series will make its debut on Nintendo Switch in 2022, Crystal Dynamics has announced as part of the franchise's 25th-anniversary celebration. Lara Croft and the Guardian of Light and Lara Croft and the Temple of Osiris will be released on Switch beginning in 2022.

