# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Anonymous Agony: An Extra Edgy Adventure Game
 - [https://www.youtube.com/watch?v=qn1rsvwkQLc](https://www.youtube.com/watch?v=qn1rsvwkQLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2021-10-29 12:41:18+00:00

Whatever you think Anonymous Agony is, it's likely to be even worse than that. It's the definition of an ancient evil and I'm sorry. 
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/mandaloregaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
Intro animation by @Extellus with sound design by @PleaseStopTalkingPodcast, which is @SirMeowMusic. Psychoanalysis lines were provided by @kizzume.

00:00 - Intro
1:35 - Prologue (FILE #0)
12:55 - The Scene
13:47 - Haze Revelations
17:26 - It Begins (FILE #1)
31:55 - Gameplay?
44:22 - This Scene is Embarrassing Enough to Warrant a Chapter
46:44 - Night 1
47:47 - Day/Night 2
54:14 - Day 3
58:32 - Night 3
01:00:47 - Day 4
01:02:07 - Smoothie Time
01:02:09 - Day 4
01:04:39 - Night 4
01:10:25 - The Final Showdown
01:15:13 - The End
01:17:58 - Credits
01:20:47 - Shiba


#AnonymousAgony #AnonymousAgonyGame #AnonymousAgonyPC #Yeyeye #AnonymousAgonyHaze #Haze

