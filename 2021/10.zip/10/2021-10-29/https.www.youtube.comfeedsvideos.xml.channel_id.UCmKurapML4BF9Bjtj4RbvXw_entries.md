# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## The Piano Guys - LULLABY (Full Album)
 - [https://www.youtube.com/watch?v=RENllbnjbTI](https://www.youtube.com/watch?v=RENllbnjbTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2021-10-29 00:00:00+00:00

Stream LULLABY, BUY the Album, Get Sheet Music! https://smarturl.it/lullabyyoutube
WE’RE ON TOUR: https://smarturl.it/the10tour | Subscribe: https://bit.ly/2XH4GCF 
Our NEWEST videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&playnext=1&index=2

Track Listing:
1. Eye of the Tiger - 00:00
2. Clair de Lune - 04:02
3. Chopsticks Lullaby - 07:15
4. All Good - 11:01
5. Every Breath You Take - 13:26
6. You'll Be in My Heart - 17:57
7. River Flows in You - 22:03
8. Nessun Dorma - 25:13
9. Jesu Joy - 27:41
10. Harmonious Blacksmith - 30:57
11. Lullabye (Goodnight, My Angel) - 33:30
12. Ode to Joy - 36:43
13. Row Your Boat - 38:30

Learn about our beliefs here: https://smarturl.it/TPG_Beliefs 

The Story: 
It’s been said that a journey of a thousand miles begins with a single step. This album’s journey of a thousand notes began with a single notion.

What if “Eye of the Tiger” was a lullaby?

We often hear from beautiful people such as yourself that much of our music can be used as a sleep aid --  a symphonic prescription for insomnia.

In fact, one of our favorite emails of all time was from a brave Navy man who served on a submarine. In his letter he talked about his struggle with claustrophobia. Can you imagine? He couldn’t get to sleep at night in his shoebox-sized space. Until, he said, he found our music. Every night he’d don his headphones, hit play and then close his eyes. He said our music would transport him to a place where there was plenty of room for peace of mind. He could finally fall asleep.

Stories like this made us want to compose a whole album full of musical melatonin. But not just any old lullabies -- with cliché melodies and toy box sounds. We wanted to go all out (as we like to do). We wanted to rewrite household “hits” with a thoughtful lullaby filter to see if they could stand up to helping people like you lie down...

Read More: https://smarturl.it/lullabyyoutube

Follow The Piano Guys:
Instagram: https://instagram.com/thepianoguys
Facebook: https://facebook.com/ThePianoGuys
TikTok: https://tiktok.com/@thepianoguys 
Twitter: https://twitter.com/thepianoguys

Watch More of The Piano Guys: 
Covers: https://youtube.com/playlist?list=PL7j5iXGSdMwc7n8Tsjl-I8zEOEZsjWydx&playnext=1&index=2 
Official Music Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwfDukj_bIIB_1JhbYtaWRYg&playnext=1&index=2 
Newest Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&playnext=1&index=2
Most Popular: https://youtube.com/playlist?list=PL7j5iXGSdMweXm56WEjskhCT5oAeEZJQF&playnext=1 

Listen to The Piano Guys: 
Spotify: https://open.spotify.com/artist/0jW6R8CVyVohuUJVcuweDI?si=8GgyFRhiTz6POs8b0ir2IA&dl_branch=1 
Apple Music: https://music.apple.com/us/artist/the-piano-guys/498030399 
Amazon Music: https://amazon.com/The-Piano-Guys/e/B00BXLTTI4 

About The Piano Guys:
Paul, a Yamaha dealer who dabbled in videography, Jon, a professional pianist, Al, a music producer and studio engineer, and Steve, a cellist with a creative superpower called ADHD, all serendipitously joined forces to create the most successful YouTube instrumental music group in history. The Piano Guys’ mission is to inspire and spread hope through incomparably imaginative piano music videos filmed all over the world. On this channel you can regularly find piano covers of music from genres like top 40, pop, classic rock, R&B, hiphop, country, and more. Make sure to subscribe and enable all post notifications. For instant updates, check out The Piano Guys via their social media accounts linked above.

#NewMusic #FullAlbum #ThePianoGuys

