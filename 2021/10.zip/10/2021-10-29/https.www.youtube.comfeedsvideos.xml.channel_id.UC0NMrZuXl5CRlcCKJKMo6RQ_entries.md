## MEP's stand up for our right to freedom after imposing Digital Green Certificate to enter Parliament
 - [https://www.youtube.com/watch?v=lEkvD5To02U](https://www.youtube.com/watch?v=lEkvD5To02U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC0NMrZuXl5CRlcCKJKMo6RQ
 - date published: 2021-10-29 07:44:54+00:00

MEP's stand up for our right to freedom after imposing Digital Green Certificate to enter Parliament

