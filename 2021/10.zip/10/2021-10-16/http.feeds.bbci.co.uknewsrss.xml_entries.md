# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Chinese film beating Bond and Marvel at the box office
 - [https://www.bbc.co.uk/news/world-asia-china-58868854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-58868854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 23:47:41+00:00

The success of The Battle at Lake Changjin is bad news for Hollywood which wants to grow in China.

## Robert Durst: US millionaire hospitalised with Covid after life sentence
 - [https://www.bbc.co.uk/news/world-us-canada-58943246?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-58943246?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 23:28:34+00:00

Robert Durst was on Thursday convicted of murder and is a suspect in two other deaths.

## How a massacre of Algerians in Paris was covered up
 - [https://www.bbc.co.uk/news/world-africa-58927939?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-58927939?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 23:08:56+00:00

French police killed up to 300 people in 1961, throwing some of them into the River Seine to drown them.

## Joy Crookes, her cats, and an album of soulful wisdom
 - [https://www.bbc.co.uk/news/entertainment-arts-58925891?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58925891?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 23:07:13+00:00

The Brit Award-nominee discusses the making of her soul-searching debut album, Skin.

## Baby Loss Awareness Week: Two families’ stories
 - [https://www.bbc.co.uk/news/uk-england-london-58928796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-58928796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 23:05:45+00:00

Steve and Laura Hughes open up about the pain of losing their son Jesse, who died in pregnancy.

## Prof Sarah Gilbert, Covid vaccine creator: Now let’s take on 12 more diseases
 - [https://www.bbc.co.uk/news/health-58898085?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-58898085?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 23:04:16+00:00

Prof Dame Sarah Gilbert says medical science has transformed ambitions for new vaccines.

## Pigs at Amsterdam's Schiphol Airport help to keep skies safe
 - [https://www.bbc.co.uk/news/world-europe-58928677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58928677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 23:02:11+00:00

A team of 20 at Amsterdam's Schiphol Airport is part of a range of measures being used to reduce bird-strikes.

## Sir David Amess killing: Security for politicians is a global dilemma
 - [https://www.bbc.co.uk/news/world-58937581?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-58937581?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 19:20:46+00:00

Why the need to be a people's representative and the need for personal safety are in constant conflict.

## Dormice favoured by Italian mafia seized in drugs raid
 - [https://www.bbc.co.uk/news/world-europe-58938494?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58938494?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 14:11:45+00:00

Italian police search a cannabis farm and seize a stash of 235 frozen dormice - a mafia delicacy.

## Former homeless couple can buy Wednesfield home for £1
 - [https://www.bbc.co.uk/news/uk-england-birmingham-58933011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-58933011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 13:51:53+00:00

The opportunity comes under a scheme aimed at helping key workers and others on to the property ladder.

## Sir David Amess killing: Should MPs still be able to meet the public?
 - [https://www.bbc.co.uk/news/uk-58931348?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58931348?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 13:42:40+00:00

The home secretary is reviewing MPs' security but says they must remain accessible to voters.

## Sir David Amess killing casts shadow over Leigh-on-Sea constituency
 - [https://www.bbc.co.uk/news/uk-england-essex-58938850?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-58938850?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 13:37:40+00:00

Constituents in Leigh-on-Sea mourn Sir David Amess as they try to make sense of what happened.

## Sir David Amess: Boris Johnson leads tributes to much-loved MP
 - [https://www.bbc.co.uk/news/uk-politics-58933569?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-58933569?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 12:01:31+00:00

Friends and colleagues remember Essex MP David Amess's "wonderful smile" and "photographic memory".

## Soldier dies in Salisbury Plain training exercise
 - [https://www.bbc.co.uk/news/uk-england-wiltshire-58938012?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-wiltshire-58938012?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 11:49:07+00:00

Wiltshire Police is investigating the death, the Ministry of Defence says.

## Sir David Amess killing was terrorism, police say
 - [https://www.bbc.co.uk/news/uk-58935372?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58935372?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 11:40:36+00:00

The fatal stabbing of Tory MP Sir David Amess has a potential link to Islamist extremism, say detectives.

## New database launched to counter extremism
 - [https://www.bbc.co.uk/news/uk-58939815?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58939815?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 11:19:57+00:00

The Extremist Monitoring Analysis Network aims to "combat hate speech and extremist ideologies".

## Willie Kirk: Everton manager sacked after poor start to WSL season
 - [https://www.bbc.co.uk/sport/football/58939031?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58939031?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 10:27:50+00:00

Everton manager Willie Kirk has left the club after a disappointing start to the Women's Super League season.

## Man Utd defend decision to fly 100 miles to Leicester for Premier League game
 - [https://www.bbc.co.uk/sport/football/58938198?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58938198?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 10:03:55+00:00

Manchester United defend their commitment to clean energy despite deciding to fly to their Premier League game at Leicester.

## Squid Game: The rise of Korean drama addiction
 - [https://www.bbc.co.uk/news/entertainment-arts-58896247?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58896247?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 09:53:53+00:00

Finished Squid Game? Here's a quick lowdown on other K-dramas for new converts.

## Pregnancy: Some women in Wales to get pre-eclampsia test
 - [https://www.bbc.co.uk/news/uk-wales-58886350?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-58886350?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 09:48:08+00:00

Paige Thomas lost her baby to pre-eclampsia and wants tests rolled out for all women.

## Twickenham stabbing: Boy charged with playing field murder
 - [https://www.bbc.co.uk/news/uk-england-london-58938821?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-58938821?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 09:11:31+00:00

Hazrat Wali was found with knife injuries and died a short time later.

## Man charged with Crawley kidnap and police impersonation
 - [https://www.bbc.co.uk/news/uk-england-sussex-58938469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-sussex-58938469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 09:00:16+00:00

A 14-year-old girl was stopped and searched by a stranger while on her way to school on Wednesday.

## Sir David Amess: How a tragic day unfolded
 - [https://www.bbc.co.uk/news/uk-58932139?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58932139?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 07:38:45+00:00

How constituents and authorities reacted to the tragic killing of Sir David Amess.

## Cardigan Bay dolphins may have high-pitch Welsh accent
 - [https://www.bbc.co.uk/news/uk-wales-58925848?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-58925848?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 07:29:27+00:00

The dolphins have been recorded making ultra-high pitch whistles off Cardigan Bay.

## Minicab drought: 'Rotten' rates biting into Uber drivers' wages
 - [https://www.bbc.co.uk/news/uk-england-london-58903138?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-58903138?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 06:54:28+00:00

"Rotten" rates of pay are being blamed for a minicab drought that has been afflicting passengers.

## The Papers: MP safety review and terror cops probe death
 - [https://www.bbc.co.uk/news/blogs-the-papers-58934895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-58934895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 05:33:28+00:00

The killing of Tory MP Sir David Amess, stabbed at his constituency surgery, leads the front pages.

## 'I'd pick Lawrence first in the draft again' - Bell backs Jaguars rookie to shine in London
 - [https://www.bbc.co.uk/sport/american-football/58918038?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/american-football/58918038?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 05:09:40+00:00

Jason Bell and Osi Umenyiora explain all you need to know heading into the second and last of this year's London games.

## Savannah Marshall says she kept WBO belt 'under bed' and had planned to retire by 30
 - [https://www.bbc.co.uk/sport/boxing/58926190?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/58926190?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 04:59:09+00:00

Savannah Marshall says becoming a world champion has not changed her and explains why her WBO belt was stowed under her bed.

## Afghanistan: US offers to pay relatives of Kabul drone attack victims
 - [https://www.bbc.co.uk/news/world-us-canada-58935260?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-58935260?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 04:31:12+00:00

Ten people were mistakenly killed by the US military in a drone strike on the Afghan capital.

## Cardiac arrest survivor urges people to learn CPR
 - [https://www.bbc.co.uk/news/uk-england-leeds-58931748?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-58931748?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 01:57:17+00:00

A cardiac arrest survivor tells of his battle to live - and why learning CPR is so important.

## Shipping disruption: Why are so many queuing to get to the US?
 - [https://www.bbc.co.uk/news/58926842?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/58926842?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 01:14:39+00:00

A surge in demand for toys and sports equipment has contributed to logjams at US ports.

## Channel smugglers step up risks to outfox France and UK
 - [https://www.bbc.co.uk/news/world-europe-58894877?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58894877?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 01:09:45+00:00

The number of migrants crossing has doubled in a year, so why is it proving so hard to stop their smugglers?

## Afghanistan: Suicide attack hits Kandahar mosque during prayers
 - [https://www.bbc.co.uk/news/world-asia-58925863?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-58925863?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-16 00:22:56+00:00

Explosions at a Shia mosque in Kandahar kill more than 40 people during Friday worship.

