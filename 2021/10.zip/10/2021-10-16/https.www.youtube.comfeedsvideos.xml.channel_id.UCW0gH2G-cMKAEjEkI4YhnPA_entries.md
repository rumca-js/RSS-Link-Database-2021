# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Origin of Hobbits: Harfoots, Fallohides, and Stoors | Tolkien Explained
 - [https://www.youtube.com/watch?v=M53RNYc2FWA](https://www.youtube.com/watch?v=M53RNYc2FWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-10-16 00:00:00+00:00

Hobbits make their mysterious appearance in the early portion of the Third Age, but not in the land we know as the Shire.  In this video, we will track their origins and travels from the Vales of Anduin, while covering the three branches of the hobbits: the Harfoots, Fallohides, and Stoors.  We will highlight their distinctives and how their unique characteristics lived on to their descendants like Bilbo, Merry, and Pippin!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark

Smaug the Dragon - Evolvana
At the Cracks of Doom - Ted Nasmith
A View of Hobbiton From The Hill - Ted Nasmith
Hobbit or There and Back Again - Andrei Pervukhin
A Conspiracy Unmasked - Abe Papakhian
Nine Walkers - Abe Papakhian
Hobbits Comparison - Lidia Postma
Hobbit - Davide Lazzoni
Gladden Fields - Lida Holubova
Entering Mirkwood - Venishi
Pippin and Merry in Fangorn Forest - Anke Eissmann
Merry - Return to the Shire - Tobjorn Kallstrom
Frodo's Farewell Feast - Matej Cadil
Cooking Rabbit - Jenny Dolfen
Three is Company - Peter Xavier Price
Hobbit - Andrei Pervukhin
Bilbo on Pony - Jemima Catlin
Merry and Pippin in Fangorn Forest - Donato Giancola
Three is Company - Anna Kulisz
Gandalf in the Libraries of Minas Tirith - Donato Giancola
Ori - Pinkhavok
Bilbo at Rivendell - The Brothers Hildebrandt
Merry and Theoden - Francesco Amadio
Eowyn and Merry - Matthew Stewart
Merry and Theoden - Arati Subramanyam
Dol Guldur - John Hodgson
Far Over the Misty Mountains Cold - Justin Oaksford
At Last - Anna Kulisz
Across Middle-earth, The Great River - Ralph Damiani
Smeagol and Deagol - Kerfisbilun
Shire Map - Maxime Plasse
Michel Delving - Matej Cadil
Will Whitfoot - Storn Cook
Three is Company - Jenny Dolfen
Pippin - JB Casacop
Fatty Bolger - Giacobino
Merry, Return to the Shire - Tobjorn Kallstrom
Merry & Pippin - Bogdan Dumitriu
Hobbit House - Sufi2605
Hobbits on a Hay Bail - Kryzsztof Porchowski Jr
Bilbo and Lindir - Merlkir
Frodo encounters the Sheriff at Frogmorton - Paula DiSante
Snowfall in the Shire - Joe Gilronan
Winter in the Shire - Mintdr
Shire in Winter - Kubra Adyazdigm
Hobbit and Wolf - Frank Frazetta
Three is Company - Angotir
Sam and Rose - Ted Nasmith
The Sleeping Dragon - Shimhaq
The Scouring of the Shire - The Brothers Hildebrandt
Bilbo at Rivendell - Alan Lee
Bilbo's Eleventy-First Birthday - Paul Raymond Gregory

#hobbits #tolkien #lotronprime

