# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## Thanks for making this happen, everybody.
 - [https://www.youtube.com/watch?v=lzZ2nCPD238](https://www.youtube.com/watch?v=lzZ2nCPD238)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2021-10-16 19:45:42+00:00



