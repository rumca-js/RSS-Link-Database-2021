## Valve bans blockchain games and NFTs on Steam, Epic will try to make it work - The Verge
 - [https://www.theverge.com/2021/10/15/22728425/valve-steam-blockchain-nft-crypto-ban-games-age-of-rust](https://www.theverge.com/2021/10/15/22728425/valve-steam-blockchain-nft-crypto-ban-games-age-of-rust)
 - RSS feed: https://www.theverge.com
 - date published: 2021-10-16 10:35:21.578316+00:00

Press (N)F(T) to pay respects.

