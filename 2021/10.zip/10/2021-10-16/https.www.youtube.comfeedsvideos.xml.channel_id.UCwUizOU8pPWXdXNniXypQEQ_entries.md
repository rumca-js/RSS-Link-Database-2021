# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What Southwest DOESN’T Want You to Know…
 - [https://www.youtube.com/watch?v=eUsF8FKB25U](https://www.youtube.com/watch?v=eUsF8FKB25U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-10-16 00:00:00+00:00

Grab your Remedy Sleep Mask at https://blublox.com/jp
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

What Southwest DOESN’T want you to know…
Southwest airlines has canceled thousands of flights. Their pilots seem to be stricken with the freedom flu. What is Southwest Airlines trying to cover up about their pilots and mandates?

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

