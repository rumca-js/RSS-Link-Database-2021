# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Emeraude Toubia: Una Conversación Con Alt.Latino
 - [https://www.youtube.com/watch?v=zci87SxHC1A](https://www.youtube.com/watch?v=zci87SxHC1A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-10-17 00:00:00+00:00

Alt.Latino host Felix Contreras talks with actress Emeraude Toubia about life as a Latina in film -- from telenovelas to Hollywood -- and discuss some exciting projects in the works.⁠

#eltiny #emeraudetoubia #altlatino

