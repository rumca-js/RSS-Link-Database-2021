# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Jak się robi dinozaury?
 - [https://www.youtube.com/watch?v=MbTx08Zry_8](https://www.youtube.com/watch?v=MbTx08Zry_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-10-17 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

W ramach odpoczynku postanowiłem wrzucić taki, trochę inny niż zwykle, film. Film opowiadający historię, która w żądnym wypadku nie powinna pozostać nieoopowiedziana.

===
Rozkład jazdy:

0:00 Kontekst
2:07 Nasz Matka Smoków

