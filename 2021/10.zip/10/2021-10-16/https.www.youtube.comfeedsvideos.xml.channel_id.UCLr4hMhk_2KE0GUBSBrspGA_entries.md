# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Pies robot najlepszym przyjacielem człowieka? Tech Week. Ghost Robotics, Pixel 6, lodówka Xbox
 - [https://www.youtube.com/watch?v=6R971QEJ5NQ](https://www.youtube.com/watch?v=6R971QEJ5NQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-10-17 00:00:00+00:00

Dziś jak zawsze radośnie czyli o śmierci. Ale również o raku, więc już bez przesady, że tak zupełnie na smutno.
 
Nowe znośne rzeczy: http://znosne.pl/
Spotkanie w Krakowie: https://fb.me/e/2JILsHSsL (dla tych bez FB): Sobota, godz.: 18:00 Kraków, Kamienna 12, studio Vintage. Wejście za free. https://goo.gl/maps/9uKg96SHpih9HGbC9

Spis treści:
00:00 W dzisiejszym odcinku
00:18 Dobry wieczór
00:22 Test szczepionki na raka
01:04 Pies robot z karabinem
02:51 Drony zabiły cywili w Kabulu
04:02 Pies robot patrolujący ulice
04:33 Norweg, który zabił 5 osób z łuku
04:47 Własny język botów Facebooka
05:26 Amazon kopiuje produkty swoich klientów
06:29 Amerykanie czy Chińczycy? Kto czyimi ścieżkami kroczy?
06:42 Praktyczny przykład chińskich innowacji
08:36 Kapitan Kirk poleciał w kosmos
09:00 Robin Hood – Bezos
09:18 Event Apple’a w poniedziałek
09:54 Premiera Pixeli
10:12 Premiera lodówki Xboxa
10:35 Samsung i druga część eventu Unpacked
11:22 AppStore w Chinach blokuje aplikacje z Koranem i Biblią
11:33 LinkedIn wychodzi z Chin
11:41 Nowa kolekcja i przypinki - cegiełki już na Znosne.pl
12:08 Wernisaż KLAWIATUR ART w Krakowie
12:19 Pożegnanie
12:25 Znośnego tygodnia

Źródła:
Pies robot z karabinem: https://bit.ly/3FXHHEG
Testy szczepionki na raka: https://bit.ly/2YUFZUd
Drony zabiły cywili w Kabulu: https://bbc.in/3n0W2YD
Norweg, który zabił 5 osób z łuku: https://nyti.ms/3viIMlT
Boty fb wymyśliły własny język: https://bit.ly/3n3E2MZ
Amazon kopiował produkty swoich klientów i sprzedawał jako własne: https://reut.rs/3vo8xkO
Kopia torby Peak Design: https://youtu.be/HbxWGjQ2szQ
Kapitan Kirk w kosmosie: https://youtu.be/lliRCiyk_0A
Event Apple w poniedziałek: https://thenextweb.com/news/apple-october-18-2021-event
Wtorkowy event Pixeli: https://bit.ly/3DPKspT
Lodówka Xbox: https://bit.ly/30BjMLl
Aplikacje z Koranem i Biblią usunięte z AppStore w Chinach: https://bit.ly/3lMxtz0
LinkedIn wychodzi z Chin: https://bit.ly/3n0WZ39

