## Female Spanish thriller writer Carmen Mola revealed to be three men
 - [https://www.theguardian.com/books/2021/oct/16/female-spanish-thriller-writer-carmen-mola-revealed-to-be-three-men](https://www.theguardian.com/books/2021/oct/16/female-spanish-thriller-writer-carmen-mola-revealed-to-be-three-men)
 - RSS feed: https://www.theguardian.com
 - date published: 2021-10-16 20:30:23+00:00

Female Spanish thriller writer Carmen Mola revealed to be three men

