# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Bieszczady Jesienią! Samotnie przez BIESZCZADZKIE POŁONINY. Silent Hiking 🚶‍♂️ 100% klimat Bieszczad
 - [https://www.youtube.com/watch?v=oGcV0a1f_-0](https://www.youtube.com/watch?v=oGcV0a1f_-0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-10-17 00:00:00+00:00

Kurs filmowo-montażowy 🎬 https://www.kursfilmowaniaimontazu.pl/
Dodatek Podróżniczy 🎬 http://filmypodroznicze.pl/

Bieszczady, oh Bieszczady! Ale dawno się nie widzieliśmy. Będzie już chyba z 4 lata jak ostatnio byłem w tych pięknych górach. Spędziłem na potrzeby tego filmu w Bieszczadach 6 dni i nie ukrywam, że głównym powodem mojej obecności była właśnie kultowa, bieszczadzka jesień. Pięknie było! Baza kolorów została zaktualizowana :D

Udało mi się w tym czasie wejść na Połoninę Wetlińską, Połoninę Caryńską, Tarnicę, Bukowe Berdo, przejechać rowerem doliny Sanu a także odwiedzić jeszcze kilka innych miejsc w Bieszczadach. Piękna była to wycieczka, bardzo polecam. Choć uprzedzić muszę, że jesień w Bieszczadach, zwłaszcza w weekend daleka jest od ciszy i spokoju. Ludzi i samochodów więcej niż w Zakopanym w szczycie sezonu zimowego. Ale w ciągu tygodnia? Bywało, że na połoninach, o zachodzie słońca byłem prawie sam. Coś pięknego :)

Muzyka - Artlist

Dla wnikliwych - tak, było pozwolenie na latanie dronem w PN.

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

