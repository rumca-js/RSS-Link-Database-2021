# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Google Pixel 4 Restoration
 - [https://www.youtube.com/watch?v=3HTeJAgBl3g](https://www.youtube.com/watch?v=3HTeJAgBl3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-10-16 00:00:00+00:00

Pixels where acting up, time for new screen.
Skip the upgrade and take 20% off Apple Fix Kits with code SKIP20. If you already have iFixit tools, you can use the code for the part only option too! https://ifix.gd/hg-fixkits  
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Get parts, tools and repair guides at iFixit:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau

Tools I Use: https://www.hughjeffreys.com/tools
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

