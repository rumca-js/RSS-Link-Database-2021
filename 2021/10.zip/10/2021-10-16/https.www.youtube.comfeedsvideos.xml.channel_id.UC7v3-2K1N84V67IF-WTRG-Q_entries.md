# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Batman - Trailer 2 (My Thoughts)
 - [https://www.youtube.com/watch?v=mYDD_FgBrLE](https://www.youtube.com/watch?v=mYDD_FgBrLE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-10-17 00:00:00+00:00

DC Fandome dropped some nice glimpses today, including a new trailer for THE BATMAN. Here are my thoughts!

Watch the trailer here: https://www.youtube.com/watch?v=mqqft2x_Aa4&t=58s&ab_channel=WarnerBros.Pictures

#TheBatman

