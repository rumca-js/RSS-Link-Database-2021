# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I shouldn't have built this.- Hasanabi 'Leftist PC'
 - [https://www.youtube.com/watch?v=coVxNAYPzWo](https://www.youtube.com/watch?v=coVxNAYPzWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-17 00:00:00+00:00

Check out the $14.99 Minnow set and the $19.99 Moray set at: https://www.ifixit.com/LTT

This PC gets top Marx for being one of our most.. controversial builds. We're making a PC for Twitch streamer Hasanabi!


Buy AMD Ryzen 5950X CPU
  Amazon: https://geni.us/MSDqyy
  Best Buy: https://geni.us/ZnUZt7K
  Newegg: https://geni.us/LhZCa

Buy Noctua NH-D15 chromax.black CPU Cooler
  Amazon: https://geni.us/UqzzxI
  Newegg: https://geni.us/gR4bxrl

Buy Noctua NA-HC4 chromax.Black Heatsink Cover - Red
  Amazon: https://geni.us/HL3X

Buy ASUS ROG Crosshair VIII Extreme
  Amazon: https://geni.us/BFIMXQG
  B&H: https://geni.us/yEquRRs

Buy MSI Radeon RX 6900 XT GAMING X TRIO GPU
  Amazon: https://geni.us/aJfM
  Newegg: https://geni.us/ADB2xJp
  B&H: https://geni.us/ZVuGks

Buy Crucial Ballistix 16GB (8GBx2) 3600MHz DDR4 RAM Kit
  Amazon: https://geni.us/46PH0
  Newegg: https://geni.us/nud9
  B&H: https://geni.us/pDs4e

Buy SAMSUNG 870 EVO 1TB SATA SSD
  Amazon: https://geni.us/w3c8jyh
  Best Buy: https://geni.us/Os7Rp
  Newegg: https://geni.us/1EKhs2p

Buy WD 4TB Red Pro NAS HDD
  Amazon: https://geni.us/O04u
  Best Buy: https://geni.us/QKO5qeG
  Newegg: https://geni.us/gYi3Ixn

Buy Elgato HD60 Pro Capture Card
  Amazon: https://geni.us/F29IujL
  Best Buy: https://geni.us/MX4CZn
  Newegg: https://geni.us/qJWcvAh

Buy NZXT H710 Case - Red/Black
  Amazon: https://geni.us/WZm5
  Best Buy: https://geni.us/YlNY
  Newegg: https://geni.us/fBE4w

Buy ASUS ROG THOR 1200W PSU
  Amazon: https://geni.us/alMzAjY
  Newegg: https://geni.us/F8dRLJ
  B&H: https://geni.us/qreqB

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1381796-i-shouldnt-have-built-this-computer-hasanabi-pc-build/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:20 Who is Hasan?
1:58 Hardware
3:45 Memeing intensifies
5:03 Just YOLO that motherboard in there
7:00 GPU
8:46 Glamtage 
10:06 Join FAH Team 223518!

## Our Editor Has NEVER Owned a PC!! - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=K2Y0gwEsw3E](https://www.youtube.com/watch?v=K2Y0gwEsw3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-16 00:00:00+00:00

Thanks to Intel for continuing to sponsor this series! Buy Intel Core i7-11700K CPU's
On Amazon (PAID LINK): https://geni.us/710v44
On Best Buy (PAID LINK): https://geni.us/ucoLYHo
On Newegg (PAID LINK): https://geni.us/qw95

Check out the LG 55" CX OLED TV: https://bit.ly/Linus_LGOLEDTV_M

Buy Noctua NH-D15 chromax.Black CPU Cooler
On Amazon (PAID LINK): https://geni.us/gLww
On Newegg (PAID LINK): https://geni.us/tsBsH

Buy EVGA GeForce RTX 3080 XC3 GAMING GPU
On Amazon (PAID LINK): https://geni.us/iQQfc
On Best Buy (PAID LINK): https://geni.us/9d9OySE
On Newegg (PAID LINK): https://geni.us/UqLBgAc

Buy Sabrent 1TB Rocket NVMe SSD
On Amazon (PAID LINK): https://geni.us/S1Lpw
On B&H (PAID LINK): https://geni.us/ajQpx
On Newegg (PAID LINK): https://geni.us/aO9n7xd

Buy Lian Li UNI Fan AL120 RGB Fans
On Amazon (PAID LINK): https://geni.us/XtNvN
On B&H (PAID LINK): https://geni.us/H0T27
On Newegg (PAID LINK): https://geni.us/i6pk1oM

Buy MSI MEG Z590 ACE
On Amazon (PAID LINK): https://geni.us/cw7w
On B&H (PAID LINK): https://geni.us/voxd
On Newegg (PAID LINK): https://geni.us/d5ID

Buy ASUS ROG Strix 850W Gold PSU
On Amazon (PAID LINK): https://geni.us/F1QT4rZ
On B&H (PAID LINK): https://geni.us/FG8G
On Newegg (PAID LINK): https://geni.us/oME9cFo

Buy Sonos Arc Soundbar
On Amazon (PAID LINK): https://geni.us/ubAy3Hv
On Best Buy (PAID LINK): https://geni.us/UwL3ie
On B&H (PAID LINK): https://geni.us/obMZWru

Check out CableMod's RT Series at https://lmg.gg/pTzdx

Purchases made through some store links may provide some compensation to Linus Media Group.

Special Intro by MBarek Abdelwassaa
https://www.instagram.com/mbarek_abdel/

Discuss on the forum: https://linustechtips.com/topic/1381563-building-his-first-pc-intel-5000-extreme-tech-upgrade/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:47 Hi, Mark
1:45 TV
3:10 Server
4:20 Macbook
5:50 The Upgrade
7:04 Building the PC
9:51 It Lives
10:35 Hanging the TV

