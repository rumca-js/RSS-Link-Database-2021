# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Ruszam w świat - ostatni vlog z Filipin
 - [https://www.youtube.com/watch?v=_wlnDX-vYDo](https://www.youtube.com/watch?v=_wlnDX-vYDo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2021-10-17 00:00:00+00:00

Wsparcie dla zwierząt z Filipin:
http://zrzutka.pl/pomocnalapka2

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Sklep: bezplanu.com
Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv

Czas akcji: październik 2021r.

