# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Viral origins, last chance saloon
 - [https://www.youtube.com/watch?v=zHazL7-EyDA](https://www.youtube.com/watch?v=zHazL7-EyDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-10-17 00:00:00+00:00

WHO and viral origins, Link to featured video
https://www.youtube.com/watch?v=E18Jbmz6D1I&t=308s

Link to Wefwafwa’s channel
https://www.youtube.com/channel/UCzsLklGgOttU3Se-WGLp7ow
(he needs more suscribers)

Link to Patrion to support Wefwafwa’s work in Africa
patreon:https://www.patreon.com/awmedicalvideos

https://www.reuters.com/business/healthcare-pharmaceuticals/who-says-it-may-be-last-chance-find-covid-origins-2021-10-13/

Newly formed advisory group on dangerous pathogens

Mike Ryan

This is our best chance, and it may be our last chance to understand the origins of this virus

take a step back, create an environment where we can again look at the scientific issues

Urged China to provide data from early cases

China, no more visits are needed

Previous WHO team spent four weeks in and around Wuhan

Dr Peter Daszak, recused himself from The Lancet's inquiry commission

https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)30418-9/fulltext

We stand together to strongly condemn conspiracy theories suggesting that COVID-19 does not have a natural origin. 

Dr. Tedros Adhanom Ghebreyesus

Investigation was hampered by a dearth of raw data pertaining to the first days of the outbreak

Has called for lab audits

New, 26 members, Scientific Advisory Group on the Origins of 

Novel Pathogens (SAGO)

Maria van Kerkhove, WHO technical lead on COVID-19

Hopes there would be further WHO-led international missions to China,

which would engage the country's cooperation

more than three dozen recommended studies required to determine how the virus crossed from the animal species to humans

Reported Chinese testing for antibodies in Wuhan residents in 2019 will be absolutely critical

Including analyses of stored blood samples from 2019 in Wuhan

and retrospective searches of hospital and mortality data for earlier cases.

Chen Xu, China's ambassador to the UN

Conclusions of the joint study were quite clear

As international teams had been sent to China twice already, it 

is time to send teams to other places

## Important scientific information with Dr. Pieter Gaillard and John
 - [https://www.youtube.com/watch?v=hbjuWs99CrE](https://www.youtube.com/watch?v=hbjuWs99CrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-10-16 00:00:00+00:00

Direct link to Pieter’s article with references
https://www.linkedin.com/pulse/astrazeneca-vaccine-pull-back-push-through-pieter-j-gaillard/?trk=pulse-article_more-articles_related-content-card
Link to Pieter's brain vasculature video from his picture I the background, amazing
https://www.youtube.com/watch?v=9y3AXr8EyG8
Video on Pieter's scientific work
https://www.youtube.com/watch?v=k0o-b5JK9bA

