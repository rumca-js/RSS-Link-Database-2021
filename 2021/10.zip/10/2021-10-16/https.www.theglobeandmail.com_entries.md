## Most Canadians believe Facebook harms their mental health, survey suggests - The Globe and Mail
 - [https://www.theglobeandmail.com/canada/article-most-canadians-believe-facebook-harms-their-mental-health-survey-2/](https://www.theglobeandmail.com/canada/article-most-canadians-believe-facebook-harms-their-mental-health-survey-2/)
 - RSS feed: https://www.theglobeandmail.com
 - date published: 2021-10-16 10:31:22.507536+00:00

Forty per cent of those who responded to an online survey by Leger and the Association for Canadian Studies said they had a negative opinion of Facebook

