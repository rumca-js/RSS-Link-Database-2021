# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW WAR GAMES of 2021
 - [https://www.youtube.com/watch?v=vORQBy_1vnA](https://www.youtube.com/watch?v=vORQBy_1vnA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-17 00:00:00+00:00

War in video games is a common theme, but only a select few make it their entire focus. Here are some war games to look forward to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sprocket 
Platform : PC 
Release Date : August 27, 2021 

Sniper Ghost Warrior Contracts 2 
Platform : PC PS4 Xbox One XSX|S 4 June 2021 
Release Date : PS5  24 August 2021 

Medic: Pacific War 
Platform : PC 
Release Date : 2021 

War on the Sea 
Platform : PC 
Release Date : February 3, 2021 

Iron Conflict 
Platform : PC 
Release Date : 8 January, 2021

Enlisted 
Platform : PC PS4 PS5 XBOX ONE XSX|S 
Release Date : March 2, 2021 

Hell Let Loose 
Platform : PC July 27, 2021 
Release Date : PS5 XSX|S October 5, 2021 

Halo Infinite 
Platform : PC XBOX ONE XSX|S 
Release Date : December 8, 2021 

Call of Duty: Vanguard 
Platform : PC PS4 PS5 XBOX ONE XSX|S 
Release Date : November 5, 2021 

Battlefield 2042 
Platform : PC PS4 XBOX ONE PS4 XSX|S  
Release Date : November 19, 2021 

BONUS
HUMANKIND 
Platform : PC Stadia 
Release Date : 17 August 2021

## 10 Most DISAPPOINTING FINAL Bosses in Video Games
 - [https://www.youtube.com/watch?v=yFJUHV7_eyY](https://www.youtube.com/watch?v=yFJUHV7_eyY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-16 00:00:00+00:00

Final bosses are intended to be the climax of an intense game. These examples are a bit more disappointing.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

