# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Stéphane Picq & Alexandre Ekian - Dune OST (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=md_sVFvgS1c](https://www.youtube.com/watch?v=md_sVFvgS1c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-10-17 00:00:00+00:00

Dune (Amiga, 1991) soundtrack by Stéphane Picq & Alexandre Ekian. 

00:00 Wormsign
03:32 Ecolove
06:56 Fremens

Made using real A1200 Rev. 1D.4 audio. StarTrekker v1.3 used for playback.

Visit my channel for more Amiga music.

