# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## A Robot That Walks, Flies, Skateboards, Slacklines
 - [https://www.youtube.com/watch?v=H1_OpWiyijU](https://www.youtube.com/watch?v=H1_OpWiyijU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-10-16 00:00:00+00:00

This is a #robot that walks, flies, #skateboards, #slacklines, and might do much more one day. A portion of this video was sponsored by Bluehost. Start building a website with Bluehost today. Use my link to receive more than 65% off: https://bluehost.com/track/veritasium #Bluehost #BHcreator

Thanks to Prof. Soon-Jo Chung and everyone at the Aerospace Robotics and Control Lab at Caltech for the tour!
https://aerospacerobotics.caltech.edu/

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
References:
Kim, K., Spieler, P., Lupu, S., Ramezani, A., Chung, S. (2021). A bipedal walking robot that can fly, slackline, and skateboard. Science Robotics. — https://www.science.org/doi/10.1126/scirobotics.abf8136

 ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Special thanks to Patreon supporters: S S,  Andrew, Benedikt Heinen, Diffbot, Micah Mangione, MJP, Gnare, Dave Kircher, Edward Larsen, Burt Humburg, Blake Byers, Dumky, Evgeny Skvortsov, Meekay, Bill Linder, Paul Peijzel, Mac Malkawi, Michael Schneider, Big Badaboom, Ludovic Robillard, jim buckmaster, Juan Benet, Ruslan Khroma, Robert Blum, Richard Sundvall, Lee Redden, Vincent, Marinus Kuivenhoven, Alfred Wallace, Clayton Greenwell, Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Written by Derek Muller
Filmed by Derek Muller, Trenton Oliver, and Emily Zhang
Edited by Trenton Oliver
Produced by Derek Muller, Petr Lebedev, and Emily Zhang

