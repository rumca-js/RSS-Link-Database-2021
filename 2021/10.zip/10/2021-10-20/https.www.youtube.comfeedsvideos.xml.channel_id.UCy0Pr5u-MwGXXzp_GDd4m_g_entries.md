# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Classic Cobb Salad - Part 2
 - [https://www.youtube.com/watch?v=EVELLMdGsII](https://www.youtube.com/watch?v=EVELLMdGsII)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-10-21 00:00:00+00:00

Please enjoy the second instalment of Classic Cobb Salad. In this sketch comedy series we explore the deep dark underbelly of the Classic Cobb. Watch as heroes fall from grace, relationships are tested and tables are turned. At the end of the day, the Classic Cobb reveals all. 
Watch Part 1 here: https://youtu.be/ZVPF7VSrNEY

Actors:  @Christian & Nat  Rodrigo Fernandez-Stoll and Julie Nolke
Writer: Julie Nolke
Camera: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Also, join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

