# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Lorry driver shortages: 'Driving lorries is a bit like riding horses'
 - [https://www.bbc.co.uk/news/uk-england-suffolk-58967292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-58967292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 23:50:55+00:00

What is it like to be a new lorry driver in an industry experiencing severe shortages?

## 'We didn't call ourselves mum and dad for 10 months'
 - [https://www.bbc.co.uk/news/stories-58975681?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-58975681?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 23:49:56+00:00

Nina and Steven fostered a baby hoping in vain to adopt her. With a second baby they finally became parents.

## Unboxed: Oil rig in lido to form part of UK-wide arts event
 - [https://www.bbc.co.uk/news/entertainment-arts-58980615?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58980615?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 23:42:16+00:00

The decommissioned North Sea platform will relocate to Weston-super-Mare as part of 2022's Unboxed.

## China: The patriotic 'ziganwu' bloggers who attack the West
 - [https://www.bbc.co.uk/news/world-asia-china-58922011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-58922011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 23:14:20+00:00

Their scathing posts have shot them to fame amid rising nationalist fervour - but they toe a fine line.

## Cladding: 'We're paying to live in a dark, dull box'
 - [https://www.bbc.co.uk/news/business-58986304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-58986304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 23:13:01+00:00

A Birmingham tower block resident, where combustible cladding is being removed, explains his plight.

## The four-year-old footballer scouted by Arsenal while still at nursery
 - [https://www.bbc.co.uk/news/uk-58988254?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58988254?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 23:12:55+00:00

Zayn Ali Salman is the youngest-ever recruit to Arsenal's pre-academy.

## The remote British island that's still Covid-free
 - [https://www.bbc.co.uk/news/business-58966376?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-58966376?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 23:07:38+00:00

The territory of St Helena, which has remained coronavirus-free, wants a big rise in tourists.

## Russian inmate who leaked torture videos alleges death threats
 - [https://www.bbc.co.uk/news/world-europe-58978613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58978613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 16:46:42+00:00

Sergey Savelyev is seeking asylum in France after he leaked videos showing abuse in Russian prisons.

## Queen cancels Northern Ireland visit on medical advice
 - [https://www.bbc.co.uk/news/uk-58979992?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58979992?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 13:14:15+00:00

Buckingham Palace says she has "reluctantly accepted medical advice to rest for the next few days".

## Calls for nightclub searches after Nottingham needle spiking reports
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-58977839?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-58977839?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 13:03:44+00:00

A student who believes she was jabbed in a club says she has been left feeling "violated".

## COP26: Russia's Vladimir Putin will not attend climate summit
 - [https://www.bbc.co.uk/news/world-europe-58977993?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58977993?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 12:59:24+00:00

No reason was given for the Russian leader's decision not to attend the conference in Glasgow.

## Manager Bruce leaves Newcastle after takeover
 - [https://www.bbc.co.uk/sport/football/58775879?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58775879?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 12:57:46+00:00

Manager Steve Bruce leaves Newcastle United by mutual consent just 13 days after the Saudi Arabia-backed £305m takeover of the Premier League side was completed.

## Covid: Bring back rules amid rising cases, urge NHS chiefs
 - [https://www.bbc.co.uk/news/uk-58976577?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58976577?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 12:49:39+00:00

But the business secretary says it is not time for "Plan B" and he wants to avoid further lockdowns.

## Syria war: Deadly bomb blasts hit military bus in Damascus
 - [https://www.bbc.co.uk/news/world-middle-east-58930309?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-58930309?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 12:23:41+00:00

At least 14 people are reported to have died in the bloodiest attack in the Syrian capital in years.

## 12 uncapped players in Scotland squad for autumn Tests
 - [https://www.bbc.co.uk/sport/rugby-union/58970055?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/58970055?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 12:02:17+00:00

Scotland include 12 uncapped players in their 42-man squad for the Autumn Nations Series.

## Women's safety: Police video calls to verify Met officers
 - [https://www.bbc.co.uk/news/uk-england-london-58978455?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-58978455?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 11:59:41+00:00

Dame Cressida Dick announces a new system for the Met after the kidnap and murder of Sarah Everard.

## Five arrested after Man City fan attacked in Belgium
 - [https://www.bbc.co.uk/sport/football/58977693?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58977693?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 11:54:42+00:00

Five people are arrested after a Manchester City fan was attacked following Tuesday's Champions League game at Club Bruges.

## Facebook and Instagram remove 'magician' who incited murder
 - [https://www.bbc.co.uk/news/health-58981009?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-58981009?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 11:52:30+00:00

A BBC investigation had previously exposed the occultist's influence on the killer of two sisters.

## Lekki toll gate shootings: Nigeria's 'massacre without blood or bodies'
 - [https://www.bbc.co.uk/news/world-africa-58975493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-58975493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 11:48:00+00:00

The BBC investigates what happened on the night 20 October 2020, when the Nigerian army opened fire on peaceful protesters in Lagos.

## Willy Wonka songwriter Leslie Bricusse dies aged 90
 - [https://www.bbc.co.uk/news/entertainment-arts-58970326?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58970326?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 11:13:25+00:00

The British songwriter was also behind hits such as Feeling Good, Talk to the Animals and Candyman.

## Facebook fined a record £50m by UK competition watchdog
 - [https://www.bbc.co.uk/news/technology-58980442?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-58980442?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 11:02:38+00:00

The CMA says the social media giant, which also may be changing its name, deliberately broke rules.

## Tips on how to save energy at home and help the planet
 - [https://www.bbc.co.uk/news/uk-58967580?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58967580?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 10:58:26+00:00

What can homeowners do to reduce their energy consumption?

## People won't have to pay more to go green, says Kwarteng
 - [https://www.bbc.co.uk/news/business-58978775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-58978775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 10:38:15+00:00

The business secretary denies that individuals will have to pay more to have a greener lifestyle.

## NBA: 'One-man wrecking crew' Giannis Antetokounmpo stars as Bucks beat Nets
 - [https://www.bbc.co.uk/sport/av/basketball/58981180?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/basketball/58981180?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 10:02:50+00:00

Watch some of his best moments as "one-man wrecking crew" Giannis Antetokounmpo stars for the Milwaukee Bucks during their victory over the Brooklyn Nets on the opening night of the NBA season.

## Is the UK's green plan enough to halt climate change?
 - [https://www.bbc.co.uk/news/science-environment-58973826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-58973826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 09:10:54+00:00

Support for roads, aviation and fossil fuel drilling could undermine UK's green credentials at COP26.

## Kevin Sinfield: Rugby legend to undertake new Motor Neurone Disease charity run
 - [https://www.bbc.co.uk/sport/rugby-league/58978435?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/58978435?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 08:05:36+00:00

Kevin Sinfield is to undertake another run for Motor Neurone Disease research after raising over £2.7m by completing seven marathons in 2020.

## 'I had to change that talk in my head' - how Thompson-Herah made history in Tokyo
 - [https://www.bbc.co.uk/sport/athletics/58920272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/58920272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 05:13:13+00:00

Elaine Thompson-Herah on how prayer, music and a list on her phone helped tame the demons to help her claim a historic sprint double in Tokyo.

## Climate change: Fossil fuel production set to soar over next decade
 - [https://www.bbc.co.uk/news/science-environment-58971131?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-58971131?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 04:08:20+00:00

Government plans to extract coal, oil and gas are incompatible with safe temperatures, says the UN.

## The world's most famous basketball court gets a facelift
 - [https://www.bbc.co.uk/news/world-us-canada-58972262?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-58972262?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 02:05:16+00:00

Harlem's legendary Rucker Park basketball court receives a major makeover.

## Noisy: Rock band recovered their stolen kit after spotting it online
 - [https://www.bbc.co.uk/news/entertainment-arts-58912590?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58912590?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-20 00:38:00+00:00

Rock group Noisy had around £25,000 of musical equipment stolen from their van in Walthamstow.

