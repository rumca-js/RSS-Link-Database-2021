# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Most LEGENDARY Video Game Weapons of All Time
 - [https://www.youtube.com/watch?v=XirBKGEXTuA](https://www.youtube.com/watch?v=XirBKGEXTuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-21 00:00:00+00:00

There are so many awesome and downright LEGENDARY weapons in video games and it was tough to narrow it down to 10. Consider this a part one.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 20 Most HATED Water Levels in Video Games
 - [https://www.youtube.com/watch?v=PfyJM-fc6S8](https://www.youtube.com/watch?v=PfyJM-fc6S8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-20 00:00:00+00:00

Water levels in games are notorious for being just the worst. Here are our least favorite examples through gaming history.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

