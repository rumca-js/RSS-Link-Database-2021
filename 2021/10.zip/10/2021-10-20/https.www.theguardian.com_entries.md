## Leave no trace: how a teenage hacker lost himself online | Hacking | The Guardian
 - [https://www.theguardian.com/technology/2021/oct/14/leave-no-trace-how-a-teenage-hacker-lost-himself-online](https://www.theguardian.com/technology/2021/oct/14/leave-no-trace-how-a-teenage-hacker-lost-himself-online)
 - RSS feed: https://www.theguardian.com
 - date published: 2021-10-20 22:39:49.099132+00:00

The long read: Edwin Robbe had a troubled life, but found excitement and purpose by joining an audacious community of hackers. Then the real world caught up with his online activities

