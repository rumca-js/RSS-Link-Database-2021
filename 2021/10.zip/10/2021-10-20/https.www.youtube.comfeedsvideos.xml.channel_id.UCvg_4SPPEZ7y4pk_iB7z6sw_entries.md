# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Slightly Obscure Games: Cyber Hook
 - [https://www.youtube.com/watch?v=MDydXjGd5gI](https://www.youtube.com/watch?v=MDydXjGd5gI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-10-20 00:00:00+00:00

Cyber Hook is under appreciated. Many great indie games are. Well, today, I probably won't change that, but I will talk about this game I've enjoyed for a good while now.

None of this is sponsored btw. I just really like this game, and figured to give this video a try

If it does well, expect more. If it doesn't do well, expect...slightly less more.

Twitter: https://twitter.com/WhimsuHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpe...

End song is somewhere on my Soundcloud. Think of finding it as a game in itself.


Additional Footage Credits:
MorninAfterKill
John GodGames
Gamingskrubs

