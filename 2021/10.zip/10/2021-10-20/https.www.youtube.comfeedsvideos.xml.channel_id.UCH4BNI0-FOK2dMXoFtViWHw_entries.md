# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Sand Dunes Shouldn’t Exist (Here’s Why They Do)
 - [https://www.youtube.com/watch?v=L6Now-gHtx0](https://www.youtube.com/watch?v=L6Now-gHtx0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-10-20 00:00:00+00:00

Check out Overview on @pbsterra  ►► https://youtu.be/WWrb1iyCLlI 
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

How can sand, blown by the wind, form such intricate and beautiful patterns as ripples and dunes? The answer is a surprising secret of self-organization. In this video, we travel to Great Sand Dunes National Park in Colorado to climb the largest sand dunes in North America and bring you the science of how wind and sand combine to create ordered landforms out of chaos. The science must flow.

References: https://sites.google.com/view/sanddunesreferences/home 

Thank you to Dr. Mathieu Lapôtre (Stanford) and Dr. Orencio Duran Vinent (Texas A&M) for helpful discussions while researching this epsiode.

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

-----------

Special thanks to our Brain Trust Patrons:

Ronnie Adams
Barbora Bei
Ken Board
T Clinger
Attila Pix
Burt Humburg
DeliciousKashmiri
Brian Chang
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Marcus Tuepker
Karen Haskell
AlecZero

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

