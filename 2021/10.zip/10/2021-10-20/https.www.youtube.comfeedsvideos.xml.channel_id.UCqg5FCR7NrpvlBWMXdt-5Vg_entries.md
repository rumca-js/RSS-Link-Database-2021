# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Keep, Trying | Adventure is Nigh - The Jade Homunculus | EP 2
 - [https://www.youtube.com/watch?v=YEQevXEXxP0](https://www.youtube.com/watch?v=YEQevXEXxP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-21 00:00:00+00:00

Welcome to Adventure Is Nigh: The Jade Homunculus episode 2, “Keep, Trying.” Join Jack Packard as Dungeon Master for an epic Dungeons & Dragons (D&D) campaign featuring Yahtzee Croshaw as Mortimer, KC Nwosu as Sigmar, Amy Campbell as Dabarella, and Jesse Galena as Grinderbin.

Adventure Is Nigh: The Jade Homunculus episode 2 is sponsored by Fearsome Foes and Where to Fight Them, an advanced monster guide for fifth edition Dungeons & Dragons, which is on Kickstarter now! https://www.kickstarter.com/projects/fearsomefoes/fearsome-foes-and-where-to-fight-them-0/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Resident Evil 4 VR | Today We Play with Nick and Jack #OculusPartner
 - [https://www.youtube.com/watch?v=5pWOXplGQ5Y](https://www.youtube.com/watch?v=5pWOXplGQ5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-21 00:00:00+00:00

Thanks to Oculus for Sponsoring this video! #OculusPartner 
Resident Evil 4: https://ocul.us/EscapistMagazine
Oculus Quest 2: https://ocul.us/EscapistMagazine1

Nick and Jack will be playing Resident Evil 4 VR for Today We Play, sponsored by Oculus. 

This stream is sponsored by Oculus for Resident Evil 4 VR on the Oculus Quest 2. Both Resident Evil 4 VR and a Oculus Quest 2 headset were provided by Oculus for this stream.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5...​

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine​ 
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#OculusPartner

## The Dark Pictures: House of Ashes | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=TVbAgdQ0zl8](https://www.youtube.com/watch?v=TVbAgdQ0zl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-21 00:00:00+00:00

Will Cruz reviews The Dark Pictures: House of Ashes, developed by Supermassive Games.

The Dark Pictures: House of Ashes on Steam: https://store.steampowered.com/app/1281590/The_Dark_Pictures_Anthology_House_of_Ashes/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Marty Play Metroid Dread | Post-ZP Stream
 - [https://www.youtube.com/watch?v=I53DKgwSW-E](https://www.youtube.com/watch?v=I53DKgwSW-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-21 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5...​

Yahtzee plays two hours of Metroid Dread for today's Post-ZP Stream.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


The Escapist Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Far Cry 6 (Zero Punctuation)
 - [https://www.youtube.com/watch?v=JlkUBCXA9nk](https://www.youtube.com/watch?v=JlkUBCXA9nk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-20 00:00:00+00:00

This week on Zero Punctuation, Yahtzee reviews Far Cry 6.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation #FarCry6

