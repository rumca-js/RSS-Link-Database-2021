# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## North Korean Squid Game
 - [https://www.youtube.com/watch?v=SSVbO8ZoTDI](https://www.youtube.com/watch?v=SSVbO8ZoTDI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-10-21 00:00:00+00:00

Stickers here! ► https://www.patreon.com/flashgitz 

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

Animation ►
Don Greger
CalebJordann
Holly Gee

Backgrounds ►  
Soured Apple https://www.twitter.com/SouredApple
Naav Draws https://www.instagram.com/naav_draws/

Music ►
Zach Heyde https://youtu.be/9MvTtuFZK-E

Sound ► 
Justin Greger

VO ► 
Tom
 Square staff
 South Korean
Don
 Starving Koreans

Justin Greger
 Starving Korean

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

