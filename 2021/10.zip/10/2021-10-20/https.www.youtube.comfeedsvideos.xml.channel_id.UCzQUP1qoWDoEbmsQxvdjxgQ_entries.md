# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Psychologist Describes the ADD Mind State
 - [https://www.youtube.com/watch?v=qdpsMXLsUZM](https://www.youtube.com/watch?v=qdpsMXLsUZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-21 00:00:00+00:00

Taken from JRE #1723 w/Amishi Jha:
https://open.spotify.com/episode/57hZuU1AVnO78DO3Bjno8c?si=3a9fba1943c84c2b

## Overuse of Monsanto's Roundup Is Creating Herbicide Resistant Weeds
 - [https://www.youtube.com/watch?v=ZmnU-A9gJ2Q](https://www.youtube.com/watch?v=ZmnU-A9gJ2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-20 00:00:00+00:00

Taken from JRE #1722 w/Bartow Elmore:
https://open.spotify.com/episode/0Pf1SrvTTA4Ts94Gs8vbJd?si=4f85e37d01664f9a

## The Strange History of Coca-Cola
 - [https://www.youtube.com/watch?v=rX6d88VD7lw](https://www.youtube.com/watch?v=rX6d88VD7lw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-20 00:00:00+00:00

Taken from JRE #1722 w/Bartow Elmore:
https://open.spotify.com/episode/0Pf1SrvTTA4Ts94Gs8vbJd?si=4f85e37d01664f9a

