# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Why Some People Don't Have A "Mind's Eye" | Random Thursday
 - [https://www.youtube.com/watch?v=Qv8Jq0yL8fM](https://www.youtube.com/watch?v=Qv8Jq0yL8fM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-10-21 00:00:00+00:00

Start building your ideal daily routine! The first 100 people who click on the link will get 25% OFF Fabulous Premium https://thefab.co/joescott
What do you "see" in your mind's eye? Is it as real as looking at a photo? Or do you not see any images at all? It turns out there are 3-5% of the population who don't have the ability to form images in their heads. It's a condition called "Imagination blindness" or Aphantasia, and it was only recently discovered.

Along with Aphantasia is the opposite end of the spectrum, Hyperphantasia, where the mind's eye is so vivid, it's hard to distinguish between what's real and what's imagination.

It opens up a lot of questions about how we see and perceive our world.

Here are links to the tests to determine where you fall on the spectrum:

SUIS:
https://psyarxiv.com/j2h8k/download

OSIQ:
https://www.nmr.mgh.harvard.edu/mkozhevnlab/wp-content/uploads/pdfs/object_spatial2006.pdf

VVIQ:
https://aphantasia.com/vviq/

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://aphantasia.com/what-is-aphantasia/

https://www.nytimes.com/2021/06/08/science/minds-eye-mental-pictures-psychology.html

https://www.bbc.com/news/health-34039054

https://www.sciencefocus.com/the-human-body/aphantasia-life-with-no-minds-eye/

https://www.quora.com/What-are-the-advantages-if-any-to-having-aphantasia

https://talkinghumanities.blogs.sas.ac.uk/2020/11/03/extreme-imagination-what-do-we-see-with-our-minds-eye/

https://aphantasia.com/binocular-rivalry/

https://www.simplypsychology.org/perception-theories.html

https://www.popsci.com/science/article/2013-09/how-imagination-works/

https://elifesciences.org/articles/50232

https://aphantasia.com/shocking-insights-what-electrical-stimulation-tells-us-about-how-we-visualize-imagery/

