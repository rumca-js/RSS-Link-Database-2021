## Pfizer has power to 'silence' governments and 'maximize profits', consumer group alleges
 - [https://www.abc.net.au/news/2021-10-20/pfizer-covid-19-vaccine-contracts/100553958](https://www.abc.net.au/news/2021-10-20/pfizer-covid-19-vaccine-contracts/100553958)
 - RSS feed: www.abc.net.au
 - date published: 2021-10-20 07:43:01+00:00



