# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Interview: Dave Gahan on new album with Soulsavers, "Imposter"
 - [https://www.youtube.com/watch?v=DEuA-E7kDhk](https://www.youtube.com/watch?v=DEuA-E7kDhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-21 00:00:00+00:00

Jill Riley talks to Dave Gahan about his latest collaborative covers album with Soulsavers, "Imposter". Gahan discusses sequencing deliberation, his longtime musical partnership with Soulsavers, and how they approached the recording process.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits:
Host - Jill Riley
Guest - Dave Gahan
Technical Director - Eric Romani
Producers - Jesse Wiza, Christy Taylor

