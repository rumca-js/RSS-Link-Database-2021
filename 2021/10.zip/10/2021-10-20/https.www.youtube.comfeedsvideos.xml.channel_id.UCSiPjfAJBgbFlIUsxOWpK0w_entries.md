# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Dancing in the Moonlight // King Harvest // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=ePw1UA54Tgk](https://www.youtube.com/watch?v=ePw1UA54Tgk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-10-21 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 So we didn’t do a Halloween song this year, but a slightly moodier version of “Dancing in the Moonlight” kinda counts, right?

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of King Harvest's "Dancing in the Moonlight" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte
Bass: Nick Campbell
Drums: Kyle Crane
Background Vocals: Erin Bentlage

AUDIO CREDITS
Engineer: Bill Mims
Mixing/Mastering: Joey Genetti
Producer: Brian Green

VIDEO CREDITS
Director: Dom Fera
DP / A Cam: Ricky Chavez
B Cam: Merlin Showalter
Gaffer / Key Grip: Arjay Ancheta
Production Designer: Genevieve Parkes
Wardrobe: Elle Olsen
Assistant / Wardrobe: Alex Allen
Video Editor: Cleveen Dominguez 
Colorist: Athena Wheaton
PA: Chris Modl

#Pomplamoose #DancingintheMoonlight #IndieRock

LYRICS
We get it almost every night
When that moon gets big and bright
It's a supernatural delight
Everybody was dancing in the moonlight

Everybody here is out of sight
They don't bark and they don't bite
They keep things loose, they keep things light
Everybody was dancing in the moonlight

Dancing in the moonlight
Everybody's feeling warm and right
It's such a fine and natural sight
Everybody was dancing in the moonlight

We like our fun and we never fight
You can't dance and stay uptight
It's a supernatural delight
Everybody was dancing in the moonlight

Dancing in the moonlight
Everybody's feeling warm and right
It's such a fine and natural sight
Everybody’s dancing in the moonlight

Everybody here is out of sight
They don't bark and they don't bite
They keep things loose, they keep things light
Everybody was dancing in the moonlight

Dancing in the moonlight
Everybody's feeling warm and right
It's such a fine and natural sight
Everybody’s dancing in the moonlight

