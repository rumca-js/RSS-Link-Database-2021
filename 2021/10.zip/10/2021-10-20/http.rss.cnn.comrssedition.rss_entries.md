# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Raskin scolds Gaetz after grilling him on Trump's election lies
 - [https://www.cnn.com/videos/politics/2021/10/20/matt-gaetz-jamie-raskin-trump-election-lies-vpx.cnn](https://www.cnn.com/videos/politics/2021/10/20/matt-gaetz-jamie-raskin-trump-election-lies-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 22:35:03+00:00

Rep. Jamie Raskin (D-MD) got into a contentious exchange with Rep. Matt Gaetz (R-FL) over former President Trump's lies about the 2020 election at a rules committee hearing.

## See how China and India are gaining ground in the space race
 - [https://www.cnn.com/videos/business/2021/10/20/china-india-uae-russia-space-race-ctw-pkg-vpx.cnn](https://www.cnn.com/videos/business/2021/10/20/china-india-uae-russia-space-race-ctw-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 19:25:22+00:00

CNN's Isa Soares takes a look at the countries that are expanding their space programs and what future missions to space could mean for the global space race.

## See how these homeowners moved their house across a bay
 - [https://www.cnn.com/videos/world/2021/10/20/floating-house-canada-na-mh-orig.cnn](https://www.cnn.com/videos/world/2021/10/20/floating-house-canada-na-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 17:59:26+00:00

Daniele Penney's dream house was supposed to be torn down by its owners, but she offered to move the house across an inlet to her nearby land.

## See hikers use turbans to save stranded men
 - [https://www.cnn.com/videos/world/2021/10/20/sikh-hikers-turbans-save-hikers-orig-lnl.cnn](https://www.cnn.com/videos/world/2021/10/20/sikh-hikers-turbans-save-hikers-orig-lnl.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 17:48:51+00:00

A group of Sikh friends used their turbans to save hikers on the edge of a fast-moving river in British Columbia.

## Mitch McConnell just sent a very clear message to Trump about 2022
 - [https://www.cnn.com/2021/10/20/politics/mitch-mcconnell-donald-trump-2022-midterms/index.html](https://www.cnn.com/2021/10/20/politics/mitch-mcconnell-donald-trump-2022-midterms/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 15:01:11+00:00

Mitch McConnell's entire being is -- and always has been -- focused on winning elections. Every move he makes and every thing he says is part of a broader effort to ensure that his side winds up with more seats -- and therefore more control -- than the other guys.

## Bitcoin surges to new record above $65,000
 - [https://www.cnn.com/2021/10/20/investing/bitcoin-price-record-high/index.html](https://www.cnn.com/2021/10/20/investing/bitcoin-price-record-high/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 14:58:32+00:00

The bitcoin bull market is showing no signs of slowing down. Bitcoin, the world's most valuable cryptocurrency, hit a new all-time high above $66,000 Wednesday, topping the previous record set in April.

## Nikolas Cruz pleads guilty to murder charges and apologizes for Parkland high school massacre
 - [https://www.cnn.com/2021/10/20/us/nikolas-cruz-parkland-shooting-guilty/index.html](https://www.cnn.com/2021/10/20/us/nikolas-cruz-parkland-shooting-guilty/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 14:46:36+00:00

Nikolas Cruz, the gunman who carried out the massacre of students and faculty members at Marjory Stoneman Douglas High School in February 2018, pleaded guilty in a Florida courtroom Wednesday to 17 counts of murder and 17 counts of attempted murder.

## UK Covid-19 cases are soaring. How did things go so wrong?
 - [https://www.cnn.com/2021/10/20/uk/uk-europe-covid-infections-cmd-gbr-intl/index.html](https://www.cnn.com/2021/10/20/uk/uk-europe-covid-infections-cmd-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 14:24:36+00:00

• Delta descendant rises in UK
• CNN INVESTIGATES: These high-profile doctors are some of the biggest spreaders of baseless claims about Covid vaccines
• White House details plan to roll out Covid-19 vaccines for children ages 5 to 11

## Facebook fined $70 million for 'deliberate' failure to comply with UK regulator
 - [https://www.cnn.com/2021/10/20/tech/facebook-fined-uk-regulator-cma/index.html](https://www.cnn.com/2021/10/20/tech/facebook-fined-uk-regulator-cma/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 14:24:33+00:00

The UK competition regulator has slapped Facebook with a $70 million fine for repeatedly ignoring warnings and deliberately breaking its rules.

## Netflix co-CEO on Dave Chappelle fallout: I screwed up
 - [https://www.cnn.com/2021/10/20/media/netflix-dave-chappelle-ceo-reaction/index.html](https://www.cnn.com/2021/10/20/media/netflix-dave-chappelle-ceo-reaction/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 14:23:46+00:00

Netflix co-CEO Ted Sarandos has some regrets about how he handled Dave Chappelle's stand-up special, even though he still stands by Netflix's decision to stream the controversial act.

## Liz Cheney: Bannon refusal to cooperate suggests Trump was 'personally involved' in planning riot
 - [https://www.cnn.com/collections/intl-jan-6-2010/](https://www.cnn.com/collections/intl-jan-6-2010/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 14:22:16+00:00



## Ahmaud Arbery's father calls death of his son a 'lynching'
 - [https://www.cnn.com/videos/us/2021/10/20/ahmaud-arbery-trial-georgia-marcus-arbery-father-newday-vpx.cnn](https://www.cnn.com/videos/us/2021/10/20/ahmaud-arbery-trial-georgia-marcus-arbery-father-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 14:18:18+00:00

CNN's Brianna Keilar speaks with Marcus Arbery about the murder trial for the killing of his son Ahmaud Arbery in Georgia and what it's like to be in the courtroom with his alleged killers. Gregory McMichael, his son Travis McMichael and their neighbor William "Roddie" Bryan Jr. face charges including malice and felony murder and have pleaded not guilty.

## Police fire tear gas in Lagos as protesters honoring victims of Lekki toll gate shooting spill on to streets
 - [https://www.cnn.com/2021/10/20/africa/nigeria-lekki-toll-gate-anniversary-protests-intl/index.html](https://www.cnn.com/2021/10/20/africa/nigeria-lekki-toll-gate-anniversary-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 13:51:12+00:00

Police in Lagos fired tear gas Wednesday as hundreds of demonstrators turned up at the Lekki toll gate in a memorial car procession to honor those who died during protests last year in Nigeria's economic hub.

## 21 survived a fiery plane crash in Texas. Officials are calling it a miracle
 - [https://www.cnn.com/videos/us/2021/10/19/houston-texas-plane-crash-passengers-survive-newsroom-vpx.cnn](https://www.cnn.com/videos/us/2021/10/19/houston-texas-plane-crash-passengers-survive-newsroom-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 13:46:13+00:00

All 21 passengers on board a plane headed for Boston survived after it crashed after takeoff in Waller County, Texas. CNN's Rosa Flores reports.

## Facebook is planning to change its name, report says
 - [https://www.cnn.com/2021/10/20/tech/facebook-name-change/index.html](https://www.cnn.com/2021/10/20/tech/facebook-name-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 13:25:52+00:00

Facebook is planning to rebrand itself with a new name focused on the metaverse, the Verge reported on Tuesday, as the tech giant comes under fire from regulators around the world over its business practices.

## CNN anchor discloses his MS diagnosis in remarkable conversation
 - [https://www.cnn.com/videos/media/2021/10/20/john-king-multiple-sclerosis-diagnosis-newday-sot-vpx.cnn](https://www.cnn.com/videos/media/2021/10/20/john-king-multiple-sclerosis-diagnosis-newday-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 13:23:51+00:00

CNN's John King joins John Berman to discuss why he decided to share his multiple sclerosis diagnosis live on air.

## John Avlon: This is how Democrats can win over swing states
 - [https://www.cnn.com/videos/politics/2021/10/20/democrat-midterm-election-swing-seats-newday-avlon-vpx.cnn](https://www.cnn.com/videos/politics/2021/10/20/democrat-midterm-election-swing-seats-newday-avlon-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 13:08:42+00:00

CNN's John Avlon discusses the importance of the midterm elections for Democrats and how they can win over swing states by paying more attention to middle class and rural America.

## New Zealand police respond to 4-year-old's adorable emergency call
 - [https://www.cnn.com/2021/10/20/asia/police-new-zealand-toys-int-scli/index.html](https://www.cnn.com/2021/10/20/asia/police-new-zealand-toys-int-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 13:08:03+00:00

Police in New Zealand leapt into action to attend the house of a 4-year-old boy -- to check if his toys were as cool as he said they were.

## A glorious way of eating in Greece
 - [https://www.cnn.com/travel/article/greek-food-mediterranean-diet-travel-wellness/index.html](https://www.cnn.com/travel/article/greek-food-mediterranean-diet-travel-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 12:43:31+00:00

The Greek islands! It was a bucket list trip, made even more precious as a getaway after the long pandemic travel drought. I'd been to Athens before, so this trip was all about the islands, including a visit to the beautiful cliff homes on Santorini.

## Deadly and 'very agitated' snake found in English shipping container
 - [https://www.cnn.com/2021/10/20/uk/viper-essex-intl-scli-gbr/index.html](https://www.cnn.com/2021/10/20/uk/viper-essex-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 12:43:16+00:00

Staff at an English animal hospital were in for a shock when they responded to a call about an unusual creature -- which turned out to be an aggressive and deadly snake.

## Queen Elizabeth II cancels planned trip, advised to rest for a few days
 - [https://www.cnn.com/2021/10/20/uk/queen-elizabeth-rest-intl-gbr/index.html](https://www.cnn.com/2021/10/20/uk/queen-elizabeth-rest-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 12:26:12+00:00

Queen Elizabeth II has canceled a trip to Northern Ireland today and has "reluctantly accepted medical advice to rest for the next few days", Buckingham Palace said, Britain's PA Media news agency reported Wednesday.

## How CJ McCollum is using his love of wine to become a different type of trailblazer
 - [https://www.cnn.com/2021/10/20/sport/cj-mccollum-wine-enthusiast-portland-trail-blazers-nba-spt-intl/index.html](https://www.cnn.com/2021/10/20/sport/cj-mccollum-wine-enthusiast-portland-trail-blazers-nba-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 12:25:11+00:00

It's not often an NBA star can quietly make his way through a crowd unnoticed. But with celebrities like William H. Macy, Martha Stewart, and Guy Fieri roaming the grounds of the Food & Wine Classic in Aspen, Colorado last month, Portland Trail Blazers guard CJ McCollum figured he had a decent chance to quietly taste wines, meet vineyard owners and avoid attention.

## Trump's best shot at blocking release of Jan 6 docs
 - [https://www.cnn.com/2021/10/20/politics/trump-national-archives-lawsuit-strategy/index.html](https://www.cnn.com/2021/10/20/politics/trump-national-archives-lawsuit-strategy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 12:23:22+00:00



## Miss France pageant faces lawsuit for requiring all contestants to be at least 5-foot-5, unmarried and child-free
 - [https://www.cnn.com/style/article/miss-france-lawsuit/index.html](https://www.cnn.com/style/article/miss-france-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 12:02:28+00:00

Miss France, the country's 101-year-old beauty pageant, is being sued by a feminist activist group over alleged discriminatory entry requirements.

## This is the secret to dealing with inflation
 - [https://www.cnn.com/2021/10/20/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/10/20/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 11:45:30+00:00

Procter & Gamble, the consumer goods giant that makes Pampers diapers, Crest toothpaste and Tide detergent, says that running its business is far from simple right now.

## Lionel Messi gives up chance to score first hat-trick for Paris Saint-Germain
 - [https://www.cnn.com/2021/10/20/football/lionel-messi-psg-champions-league-hattrick-spt-intl/index.html](https://www.cnn.com/2021/10/20/football/lionel-messi-psg-champions-league-hattrick-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 11:39:23+00:00

Lionel Messi inspired Paris-Saint Germain to a thrilling 3-2 victory against RB Leipzig in the Champions League on Tuesday but the night also revealed the Argentine's magnanimity.

## US surgeons successfully test pig kidney transplant in human patient
 - [https://www.cnn.com/2021/10/20/health/human-pig-kidney-transplant-scli-intl-scn/index.html](https://www.cnn.com/2021/10/20/health/human-pig-kidney-transplant-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 11:33:20+00:00

For the first time, a pig kidney has been transplanted into a human without triggering immediate rejection by the recipient's immune system, a potentially major advance that could eventually help alleviate a dire shortage of human organs for transplant.

## Manager Steve Bruce leaves Newcastle United by mutual consent after Saudi-backed takeover
 - [https://www.cnn.com/2021/10/20/football/steve-bruce-newcastle-leaves-spt-intl/index.html](https://www.cnn.com/2021/10/20/football/steve-bruce-newcastle-leaves-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 10:35:20+00:00

Manager Steve Bruce has left Newcastle United by mutual consent just 13 days after the Saudi Arabia-backed takeover of the Premier League club.

## Djokovic given a vaccination ultimatum
 - [https://www.cnn.com/2021/10/20/tennis/novak-djokovic-vaccinated-australian-open-spt-intl/index.html](https://www.cnn.com/2021/10/20/tennis/novak-djokovic-vaccinated-australian-open-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 10:15:17+00:00

Novak Djokovic will not be able to enter Australia to defend his Australian Open title unless he is fully vaccinated for Covid-19, the country's immigration minister said on Wednesday, putting the Serb's grand slam record bid in doubt.

## The app letting people take 3D videos on an iPhone
 - [https://www.cnn.com/2021/10/20/tech/volograms-volu-app-ireland-spc-intl/index.html](https://www.cnn.com/2021/10/20/tech/volograms-volu-app-ireland-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 10:14:27+00:00

When you see a 3D image of a real person in a video game or as a visual effect in a movie, that virtual human has usually been constructed through an intricate process known as "volumetric capture."

## Ex-German soldiers arrested for trying to create paramilitary unit to fight in Yemen
 - [https://www.cnn.com/2021/10/20/europe/german-soldiers-arrested-terrorism-intl/index.html](https://www.cnn.com/2021/10/20/europe/german-soldiers-arrested-terrorism-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 10:10:53+00:00

Two former German soldiers have been arrested on suspicion of attempting to create a paramilitary unit to fight in Yemen's civil war, prosecutors said Wednesday.

## Bomb attack on Syrian military bus in Damascus kills 14
 - [https://www.cnn.com/2021/10/20/middleeast/syria-military-bus-attack-intl/index.html](https://www.cnn.com/2021/10/20/middleeast/syria-military-bus-attack-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 10:10:02+00:00

At least 14 people have been killed and three others injured after a Syrian military bus was targeted with two explosive devices in the capital Damascus on Wednesday, the SANA state news agency reported.

## Expert explains why the UK might be seeing rising Covid cases
 - [https://www.cnn.com/videos/world/2021/10/20/uk-covid-rise-expert-ovn-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/10/20/uk-covid-rise-expert-ovn-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 09:34:00+00:00

The UK is seeing a rise in coronavirus cases months after having lifted all restrictions earlier this year. Dr. Eric Topol, Professor of Molecular Medicine at Scripps Research explains to CNN's John Vause why that might be.

## Former NWSL player Kaiya McCullough calls for accountability after widespread women's football abuse scandal
 - [https://www.cnn.com/2021/10/20/football/kaiya-mccullough-womens-football-abuse-spt-intl/index.html](https://www.cnn.com/2021/10/20/football/kaiya-mccullough-womens-football-abuse-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 09:31:10+00:00

Former Washington Spirit player Kaiya McCullough has told CNN that the abuse she faced at the hands of former coach Richie Burke left her "dreading having to go on the field" and "hoping I would get hurt at practice."

## The world is banking on giant carbon-sucking fans to clean our climate mess
 - [https://www.cnn.com/2021/10/20/world/carbon-capture-storage-climate-iceland-intl-cmd/index.html](https://www.cnn.com/2021/10/20/world/carbon-capture-storage-climate-iceland-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 09:14:45+00:00

The windswept valleys surrounding the Hengill volcano in southwestern Iceland are dotted with hot springs and steam vents. Hikers from all over the world come here to witness its breath-taking scenery. Even the sheep are photogenic in the soft Nordic light.

## 'Give me my family back:' Man who lost family to Covid snubs compensation
 - [https://www.cnn.com/videos/world/2021/10/20/india-covid-19-compensation-sud-pkg-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/10/20/india-covid-19-compensation-sud-pkg-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 09:07:26+00:00

India's top court has approved a compensation program where over $300 million will be disbursed to the  families of Covid-19 victims. While the government has promised no families will be denied compensation, experts say hundreds of thousands could lose out on the aid. CNN's Vedika Sud explains why.

## How to stock your kitchen with Mediterranean grocery staples
 - [https://www.cnn.com/2021/09/03/health/mediterranean-diet-shopping-list-printable-wellness/index.html](https://www.cnn.com/2021/09/03/health/mediterranean-diet-shopping-list-printable-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 08:49:35+00:00

Starting or staying on the gold medal-winning Mediterranean diet? Then you'll need a shopping resource you can use to stock your pantry with Mediterranean meal essentials -- and continue to use on a weekly basis to restock and purchase fresh, frozen and canned vegetables, fruits, and more.

## Milwaukee Bucks debut championship rings, destroy Brooklyn Nets while Steph Curry cooks LeBron James
 - [https://www.cnn.com/2021/10/20/sport/nba-milwaukee-bucks-brooklyn-nets-curry-lebron-spt-intl/index.html](https://www.cnn.com/2021/10/20/sport/nba-milwaukee-bucks-brooklyn-nets-curry-lebron-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 08:42:35+00:00

On what was a momentous day for the Milwaukee Bucks, it couldn't have gone any better for the now defending NBA champions.

## China tells mines to produce 'as much coal as possible'
 - [https://www.cnn.com/2021/10/20/business/china-coal-production-intl-hnk/index.html](https://www.cnn.com/2021/10/20/business/china-coal-production-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 08:19:27+00:00

The Chinese government has ordered the country's coal mines to "produce as much coal as possible" as it tries to increase production as winter approaches, and ease an ongoing energy crunch.

## First he fled North Korea. Now he's escaped from a Chinese prison
 - [https://www.cnn.com/2021/10/20/china/jilin-prison-break-intl-hnk/index.html](https://www.cnn.com/2021/10/20/china/jilin-prison-break-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 07:34:34+00:00

Chinese authorities have offered a bounty equivalent to more than $23,000 for the capture of a North Korean defector who broke out of prison in the northeastern city of Jilin on Monday.

## A ​blackmail ​allegation and a sex tape -- two French footballers face off in court
 - [https://www.cnn.com/2021/10/20/football/karim-benzema-mathieu-valbuena-trial-spt-intl/index.html](https://www.cnn.com/2021/10/20/football/karim-benzema-mathieu-valbuena-trial-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 07:16:14+00:00

A sex-tape, alleged blackmail and two French soccer stars: as the trial of French striker Karim Benzema kicks off today, it was always going to draw attention.

## China's real estate crisis could kill growth into 2022. Beijing's undeterred
 - [https://www.cnn.com/2021/10/20/economy/china-gdp-real-estate-mic-intl-hnk/index.html](https://www.cnn.com/2021/10/20/economy/china-gdp-real-estate-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 06:27:51+00:00

China's growth is seriously slowing down as the country lurches from one economic threat to another. And while some of the biggest pain points appear to be easing, an unfolding crisis in real estate is emerging as one of Beijing's toughest challenges in the coming year.

## Daring drone rescue planned for 3 dogs stranded on La Palma
 - [https://www.cnn.com/videos/world/2021/10/20/la-palma-dogs-rescue-attempt-intl-ovn-vpx.cnn](https://www.cnn.com/videos/world/2021/10/20/la-palma-dogs-rescue-attempt-intl-ovn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 05:44:55+00:00

A Spanish drone operator has received permission to rescue three emaciated dogs trapped near a volcano in the Canary Islands by catching them with a remote-controlled net and flying them out over a stream of lava. The dogs have been stranded for weeks in an abandoned yard covered with volcanic ash on the island of La Palma.

## Africa's breathtaking scenes disappearing as climate crisis deepens
 - [https://www.cnn.com/videos/world/2021/10/20/africa-climate-change-glacier-giokos-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/10/20/africa-climate-change-glacier-giokos-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 05:32:59+00:00

A new report finds climate change could have dire impacts for Africa if mitigation efforts aren't put in place. The continent only generates 4% of global greenhouse gasses, but its people, economy and even its glaciers will suffer greatly if climate change worsens. CNN's Eleni Giokos reports

## Reporter's turkey trick on live TV stuns anchor
 - [https://www.cnn.com/videos/business/2021/10/20/uk-labor-shortage-christmas-turkey-stewart-fm-intl-hnk-vpx.cnn](https://www.cnn.com/videos/business/2021/10/20/uk-labor-shortage-christmas-turkey-stewart-fm-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 04:22:52+00:00

Amid the global supply chain disruptions, the labor shortages in the UK could put Christmas turkey deliveries at risk. CNN's Anna Stewart reports from a turkey farm in Essex in Southern England.

## The world plans to produce far more fossil fuel than it should to stay under dangerous climate limits, UN says
 - [https://www.cnn.com/2021/10/20/business/fossil-fuel-production-gap-climate/index.html](https://www.cnn.com/2021/10/20/business/fossil-fuel-production-gap-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 04:08:02+00:00

Ahead of a critical global climate conference in November, a UN report released Wednesday shows that many of the world's largest fossil fuel producers are still planning to ramp up production in the coming years, and will be burning far more fossil fuels in 2030 than what is consistent with global climate pledges.

## Why CNN reporter told this doctor, 'I think you're crazy'
 - [https://www.cnn.com/videos/health/2021/10/20/doctor-rashid-buttar-covid-disinformation-griffin-pkg-ac360-vpx.cnn](https://www.cnn.com/videos/health/2021/10/20/doctor-rashid-buttar-covid-disinformation-griffin-pkg-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-20 01:41:51+00:00

High-profile doctors spreading Covid-19 disinformation collectively reach millions of Americans, and a dangerous number of people believe their falsehoods. CNN speaks to one of these doctors and counters each incorrect statement with the truth. CNN's Drew Griffin reports.

