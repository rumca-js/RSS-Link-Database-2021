# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Yo! Roland TR-6S (and TR-8S) Editor!
 - [https://www.youtube.com/watch?v=5oNFASVNH9Q](https://www.youtube.com/watch?v=5oNFASVNH9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-10-20 00:00:00+00:00

The small but mighty TR-6S and the large and mighty TR-8S from Roland got a software editor. Let's check it out, using the TR-6S as our subject! Grab it for yourself here: https://www.roland.com/global/products/rc_tr-editor/
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

