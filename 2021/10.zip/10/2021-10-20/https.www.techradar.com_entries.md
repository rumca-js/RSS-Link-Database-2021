## Free Chinese VPN exposed data from over a million users
 - [https://www.techradar.com/news/free-chinese-vpn-exposed-data-from-a-million-users](https://www.techradar.com/news/free-chinese-vpn-exposed-data-from-a-million-users)
 - RSS feed: https://www.techradar.com
 - date published: 2021-10-20 20:09:10+00:00

Free Chinese VPN exposed data from over a million users

