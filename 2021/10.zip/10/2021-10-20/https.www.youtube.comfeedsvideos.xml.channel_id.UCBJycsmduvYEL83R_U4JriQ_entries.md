# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Surface Duo 2: Can This Be Saved?
 - [https://www.youtube.com/watch?v=y72bAm4SvkE](https://www.youtube.com/watch?v=y72bAm4SvkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-10-21 00:00:00+00:00

Microsoft Surface Duo 2 is both better... and worse? Does this dual screen passport fold have a future?

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Microsoft for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

