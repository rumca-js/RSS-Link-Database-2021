# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Kyle's vaccine complication
 - [https://www.youtube.com/watch?v=H7inaTiDKaU](https://www.youtube.com/watch?v=H7inaTiDKaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-10-21 00:00:00+00:00

Pericarditis after vaccination, possible inadvertent intravenous administration.
Useful links as discussed in this video,
https://www.react19.org/

https://www.youtube.com/watch?v=aebtcTi7EaA

https://www.youtube.com/channel/UC4eegkSVzV56kTrSpvL6BKQ

Rally in DC next month 

https://www.realnotrare.com

Messages from Kyle

Also a lot of people have been asking about my supplements and Ivermectin. Here are some good studies on the benefits.

Ivermectin - https://pubmed.ncbi.nlm.nih.gov/32871846/

Star Anise / Flavonoids - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8271800/

## Delta Plus, cause for concern?
 - [https://www.youtube.com/watch?v=g-AqBrboooI](https://www.youtube.com/watch?v=g-AqBrboooI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-10-20 00:00:00+00:00

New descendant of the Delta variant,  Delta, predominant, 99.8% of sequenced cases in England
As of 11 October 2021

Delta, predominant variant, 99.8% of sequenced cases in England 

Delta sublineage newly designated as AY.4.2

There are also small numbers of new cases of Delta with E484K and Delta with E484Q 

https://www.gov.uk/government/publications/investigation-of-sars-cov-2-variants-technical-briefings

https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/1025827/Technical_Briefing_25.pdf

https://www.theguardian.com/world/2021/oct/19/fears-grow-in-england-over-rise-of-new-covid-delta-variant

https://www.thesun.co.uk/health/16463658/new-delta-subvariant-uk-more-infectious/

https://www.italy24news.com/News/164491.html

https://www.msn.com/en-us/health/medical/delta-ay-sub-variant-which-requires-urgent-research-found-in-these-us-states/ar-AAPFk3S

https://www.bbc.co.uk/news/health-58965650

UK genetic sequencing, 6%, now 8% or more

UK, over a million sequences performed so far

On an increasing trajectory

US, Denmark, Canada

US, 3 cases sequenced, no clusters reported

North Carolina, California, DC

10 cases in Israel, all from US

UK, 14,247 sequenced as of Monday, October 18th 

AY.4.2, Delta Plus, Spike protein change

(AY means it is a delta subtype)

(AY.4 is already 80% in the UK)

Mutations - Y145H and A222V

Found in various lineages since the beginning of the pandemic

Will this give the virus additional powers?

Vaccine escape?

Slight effect on the binding between antibodies and the virus

Not yet a variant of concern or variant under investigation 

WHO, next few days, nu variant

Original Delta, classified as VOC, UK May 2021 

July 2021 experts identified AY.4.2.

Sublineage of Delta, increasing slowly since then

Prof Francois Balloux, University College London, Genetics Institute

It is potentially a marginally more infectious strain.

It's nothing compared with what we saw with Alpha and Delta, which were something like 50 to 60 percent more transmissible. 

So we are talking about something quite subtle here and that is currently under investigation.
 
At this stage I would say wait and see, don't panic. 

it is not something absolutely disastrous like we saw previously

Dr Jeffrey Barrett, Covid-19 Genomics Initiative, Wellcome Sanger Institute, Cambridge, and Prof Francois Balloux

AY.4.2 could be 10-15% more transmissible than the original Delta variant.

Unlikely to be fuelling current UK increases

(That’s mostly school age and to their parents)

