# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## BOOZE🍺& BOMBS💣 -PDGDBAB ( ft. Maddy )
 - [https://www.youtube.com/watch?v=wBxtL3Pi1-A](https://www.youtube.com/watch?v=wBxtL3Pi1-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-10-21 00:00:00+00:00

THERE WAS SOMETHING WORSE THAN A BOMB! 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Maddy Links: 
Twitter: https://twitter.com/misszaddy
Insta: https://www.instagram.com/maddyspearz/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://t.co/sEHQP0VEJe?amp=1

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## One Piece Problems
 - [https://www.youtube.com/watch?v=45LEPjNl4GE](https://www.youtube.com/watch?v=45LEPjNl4GE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-10-20 00:00:00+00:00

My thoughts on the weaknesses of One Piece so far! Be gentle.
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://t.co/sEHQP0VEJe?amp=1

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

New P.O. Box: PO Box 7874 Henrico, VA 23231

