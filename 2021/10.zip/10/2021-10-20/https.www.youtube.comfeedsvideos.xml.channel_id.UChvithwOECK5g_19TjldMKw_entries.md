# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Is China's Social Credit System Real? - I Found Out
 - [https://www.youtube.com/watch?v=s22tMR4YoN0](https://www.youtube.com/watch?v=s22tMR4YoN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2021-10-21 00:00:00+00:00

Go to https://NordVPN.com/LAOWHY to get a huge discount on a 2-year plan plus 4 additional free months. It’s risk free with Nord’s 30 day money-back guarantee!



Learn how a VPN works: https://www.youtube.com/watch?v=yCWNRzoQGis

John Cena, social credit system, China, these are all buzzwords right now, but is any of it actually real? I asked Chinese people, and found out for myself. 

Watch the original video - How Does China's Social Credit System Work?
https://youtu.be/PVkWokLqPOg


◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
The Muse Maker 
https://soundcloud.com/themusemaker
Big Bad Beats
https://www.youtube.com/c/bigbadbeats

