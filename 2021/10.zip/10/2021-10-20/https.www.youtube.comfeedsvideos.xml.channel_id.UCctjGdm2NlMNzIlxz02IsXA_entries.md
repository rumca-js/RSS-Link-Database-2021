# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## HALO NERD vs HALO INFINITE - Was It Good?
 - [https://www.youtube.com/watch?v=8k7W0fZY5Y8](https://www.youtube.com/watch?v=8k7W0fZY5Y8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2021-10-21 00:00:00+00:00

Find out how you can get 3 months of ExpressVPN for free by visiting http://www.expressvpn.com/Raygun

___TIME STAMPS___
00:00 - Number One Halo Advisor
01:34 - Paying The Bills
02:50 - Introduction 
04:23 - General Thoughts (That Old, Familiar Feeling)
06:46 - Sandbox (Infinite Devil Machine)
14:38 -  Maps (Authorized Personnel Only)
19:38 - Customization / Progression (Ladies Like Armor Plating)
22:29 - The Little Problems (Judgement)
26:09 - Chris Ray Gun Presents

I played 40+ hours of Halo Infinite and yeah, I’m late. Fashionably late. The technical preview has come and gone and even though everybody and their dementia riddled grandparents have already given their takes on it, I have yet to do so. According to high profile people in the games industry and games media, I am the Number One Halo Advisor so my takes instantly matter more than everyone else's. I don’t make the rules, sorry.

Some footage from:
Late Night Gaming ► https://www.youtube.com/c/LateNightGamingHaloNewsEntertainment
Mint Blitz ► https://www.youtube.com/c/MintBlitz
Arrrash ► https://www.youtube.com/c/Arrrash

Ft. Friends 
Act Man ► https://www.youtube.com/c/TheActMan
Alanah Pearce ► https://www.youtube.com/c/CharAlanahZard
Adam Cole ► https://www.twitch.tv/thechugs
Eddy Burback ►  https://www.youtube.com/c/EddyBurback
Tony Burback ► https://www.youtube.com/channel/UCJHM5IJ44__fkOxkD4vxoBw
Bruce Greene ► https://www.twitch.tv/brucegreene  
Tom Sweeny ► https://www.twitch.tv/tomsweeny1278
And iBlind

SOCIALS + MERCH 
SHIRTS ► https://teespring.com/stores/chris-ray-gun
TWITTER ► https://twitter.com/ChrisRGun
FACEBOOK ► http://on.fb.me/15OyE7z
TWITCH ► http://www.twitch.tv/chrisraygun
PATREON ► https://www.patreon.com/ChrisRay
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/
SACRED SYMBOLS  ► https://apple.co/2Rqmklc
SECOND CHANNEL ► https://www.youtube.com/c/TheSnarkTank

