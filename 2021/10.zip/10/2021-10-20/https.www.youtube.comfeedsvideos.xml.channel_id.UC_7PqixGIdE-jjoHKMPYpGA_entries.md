# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Powstał naukowybelkot.pl!
 - [https://www.youtube.com/watch?v=FSQ2hv_8nOU](https://www.youtube.com/watch?v=FSQ2hv_8nOU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-10-21 00:00:00+00:00

👉 https://naukowybelkot.pl
👉 http://ratstudios.pl/

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook

Autorką ilustracji miodożera jest Karolina Mądro-Jabłońska (https://www.instagram.com/oh.carol.illu)

Zdjęcia produktowe Malwina Majer (https://www.instagram.com/malwina.majer)

Niedoskonałości serwisu: majster@naukowybelkot.pl

