# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Supersport! - Barn dagsins (Live on KEXP)
 - [https://www.youtube.com/watch?v=q3tUjmz9tAI](https://www.youtube.com/watch?v=q3tUjmz9tAI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-20 00:00:00+00:00

http://KEXP.ORG presents Supersport! performing "Barn dagsins (Baby of the day)
" live at Kex Hostel in Reykjavik. Recorded as part of Reykjavik Calling, a celebration of Icelandic music and culture, in 2020.



Bjarni Daníel - guitar, vocals
Dagur Reykdal Halldórsson - drums, vocals
Hugi Kjartansson  - guitar, keys, vocals
Þóra Birgit Bernódusdóttir - bass, vocals


Audio and Video recorded by Sahara
Audio mixed and mastered by Kevin Suggs (KEXP)
Video edited by Justin Wilmore (KEXP)


https://www.sahara.is
https://www.kexhostel.is
https://www.inspiredbyiceland.com
https://www.facebook.com/ssuper.ssport.official.account
http://kexp.org

## Supersport! - En sama hvað (Live on KEXP)
 - [https://www.youtube.com/watch?v=d3XM2xQP8Dc](https://www.youtube.com/watch?v=d3XM2xQP8Dc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-20 00:00:00+00:00

http://KEXP.ORG presents Supersport! performing "En sama hvað... (No matter what...)" live at Kex Hostel in Reykjavik. Recorded as part of Reykjavik Calling, a celebration of Icelandic music and culture, in 2020.

Bjarni Daníel - guitar, vocals
Dagur Reykdal Halldórsson - drums, vocals
Hugi Kjartansson  - guitar, keys, vocals
Þóra Birgit Bernódusdóttir - bass, vocals

Audio and Video recorded by Sahara
Audio mixed and mastered by Kevin Suggs (KEXP)
Video edited by Justin Wilmore (KEXP)

https://www.sahara.is
https://www.kexhostel.is
https://www.inspiredbyiceland.com
https://www.facebook.com/ssuper.ssport.official.account
http://kexp.org

## Supersport! - Ég smánaði mig (Live on KEXP)
 - [https://www.youtube.com/watch?v=7SKENc9iGKE](https://www.youtube.com/watch?v=7SKENc9iGKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-20 00:00:00+00:00

http://KEXP.ORG presents Supersport! performing "Ég smánaði mig (I've disgraced myself)" live at Kex Hostel in Reykjavik. Recorded as part of Reykjavik Calling, a celebration of Icelandic music and culture, in 2020.

Bjarni Daníel - guitar, vocals
Dagur Reykdal Halldórsson - drums, vocals
Hugi Kjartansson  - guitar, keys, vocals
Þóra Birgit Bernódusdóttir - bass, vocals

Audio and Video recorded by Sahara
Audio mixed and mastered by Kevin Suggs (KEXP)
Video edited by Justin Wilmore (KEXP)

https://www.sahara.is
https://www.kexhostel.is
https://www.inspiredbyiceland.com
https://www.facebook.com/ssuper.ssport.official.account
http://kexp.org

## Supersport! - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=0jUmnnXa9ts](https://www.youtube.com/watch?v=0jUmnnXa9ts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-20 00:00:00+00:00

http://KEXP.ORG presents Supersport! performing live at Kex Hostel in Reykjavik. Recorded as part of Reykjavik Calling, a celebration of Icelandic music and culture, in 2020.

Songs
Barn dagsins (Baby of the day)
Uppí sófa (In sofa)
Ég smánaði mig (I've disgraced myself)
En sama hvað... (No matter what...)
Hring eftir hring... (My watch is a circle)
Svo dó hún, að nóttu, í draumi (Then she died, in the middle of the night, in a dream)

Bjarni Daníel - guitar, vocals
Dagur Reykdal Halldórsson - drums, vocals
Hugi Kjartansson  - guitar, keys, vocals
Þóra Birgit Bernódusdóttir - bass, vocals

Audio and Video recorded by Sahara
Audio mixed and mastered by Kevin Suggs (KEXP)
Video edited by Justin Wilmore (KEXP)

https://www.sahara.is
https://www.kexhostel.is
https://www.inspiredbyiceland.com
https://www.facebook.com/ssuper.ssport.official.account
http://kexp.org

## Supersport! - Hring eftir hring (Live on KEXP)
 - [https://www.youtube.com/watch?v=NrIEwzbrNUY](https://www.youtube.com/watch?v=NrIEwzbrNUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-20 00:00:00+00:00

http://KEXP.ORG presents Supersport! performing "Hring eftir hring (My watch is a circle)" live at Kex Hostel in Reykjavik. Recorded as part of Reykjavik Calling, a celebration of Icelandic music and culture, in 2020.

Bjarni Daníel - guitar, vocals
Dagur Reykdal Halldórsson - drums, vocals
Hugi Kjartansson  - guitar, keys, vocals
Þóra Birgit Bernódusdóttir - bass, vocals

Audio and Video recorded by Sahara
Audio mixed and mastered by Kevin Suggs (KEXP)
Video edited by Justin Wilmore (KEXP)

https://www.sahara.is
https://www.kexhostel.is
https://www.inspiredbyiceland.com
https://www.facebook.com/ssuper.ssport.official.account
http://kexp.org

## Supersport! - Svo dó hún, að nóttu, í draumi (Live on KEXP)
 - [https://www.youtube.com/watch?v=aJJKqB_cxeY](https://www.youtube.com/watch?v=aJJKqB_cxeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-20 00:00:00+00:00

http://KEXP.ORG presents Supersport! performing "Svo dó hún, að nóttu, í draumi (Then she died, in the middle of the night, in a dream)" live at Kex Hostel in Reykjavik. Recorded as part of Reykjavik Calling, a celebration of Icelandic music and culture, in 2020.

Bjarni Daníel - guitar, vocals
Dagur Reykdal Halldórsson - drums, vocals
Hugi Kjartansson  - guitar, keys, vocals
Þóra Birgit Bernódusdóttir - bass, vocals

Audio and Video recorded by Sahara
Audio mixed and mastered by Kevin Suggs (KEXP)
Video edited by Justin Wilmore (KEXP)

https://www.sahara.is
https://www.kexhostel.is
https://www.inspiredbyiceland.com
https://www.facebook.com/ssuper.ssport.official.account
http://kexp.org

## Supersport! - Uppí sófa (Live on KEXP)
 - [https://www.youtube.com/watch?v=WN_1QfM37DE](https://www.youtube.com/watch?v=WN_1QfM37DE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-20 00:00:00+00:00

http://KEXP.ORG presents Supersport! performing "Uppí sófa (In sofa)" live at Kex Hostel in Reykjavik. Recorded as part of Reykjavik Calling, a celebration of Icelandic music and culture, in 2020.

Bjarni Daníel - guitar, vocals
Dagur Reykdal Halldórsson - drums, vocals
Hugi Kjartansson  - guitar, keys, vocals
Þóra Birgit Bernódusdóttir - bass, vocals

Audio and Video recorded by Sahara
Audio mixed and mastered by Kevin Suggs (KEXP)
Video edited by Justin Wilmore (KEXP)

https://www.sahara.is
https://www.kexhostel.is
https://www.inspiredbyiceland.com
https://www.facebook.com/ssuper.ssport.official.account
http://kexp.org

