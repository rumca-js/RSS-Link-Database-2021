## NIH admits Fauci lied about funding Wuhan gain-of-function experiments | Washington Examiner
 - [https://www.washingtonexaminer.com/opinion/nih-admits-fauci-lied-about-funding-wuhan-gain-of-function-experiments](https://www.washingtonexaminer.com/opinion/nih-admits-fauci-lied-about-funding-wuhan-gain-of-function-experiments)
 - RSS feed: https://www.washingtonexaminer.com
 - date published: 2021-10-20 20:23:09+00:00

NIH admits Fauci lied about funding Wuhan gain-of-function experiments | Washington Examiner

