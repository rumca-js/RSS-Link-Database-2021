# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Frédéric Motte - Fury of the Furries title theme (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=tyh_2xxJDLg](https://www.youtube.com/watch?v=tyh_2xxJDLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-10-20 00:00:00+00:00

'Fury of the Furries' (Amiga, 1993) title theme by Frédéric "Moby/elmobo" Motte. Also used in the Lagoon level, but was originally meant for the Forest level by the author.

elmobo on SoundCloud (has Fury of the Furries OST too):
https://soundcloud.com/elmobo

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## Amiga music: Virgill - Nihil Admirari (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=5M72Oyk_6eg](https://www.youtube.com/watch?v=5M72Oyk_6eg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-10-20 00:00:00+00:00

'Nihil Admirari' by Virgill/Maniacs of Noise (Jochen Feldkötter), 1st at Deadline 2021 oldschool music compo. Art "Beauty" (1997) by Visualize/Scoopex^Radio.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

