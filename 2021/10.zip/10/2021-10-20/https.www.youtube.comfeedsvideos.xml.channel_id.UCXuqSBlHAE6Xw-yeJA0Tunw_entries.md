# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## They Obviously Lied - Fake Apple Airpods Max
 - [https://www.youtube.com/watch?v=VGnyrO4RxoA](https://www.youtube.com/watch?v=VGnyrO4RxoA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-21 00:00:00+00:00

Get 10% off all Jackery products with code LinusTechTips at https://www.jackery.com?aff=27

Get 15% off the ModMic Wireless and other ModMic products at https://antlionaudio.com/linustalktips

An Apple counterfeiter sent us a pair of fake AirPods Max to review, claiming they are the best replicas on the market and the best headphones under $200. Let's see if they're up to snuff.


Buy (Real) Airpods Max: https://geni.us/KnYJ0l

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1382816-they-obviously-lied-fake-apple-airpods-max/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:58 Counterfit Apple Products
1:55 The Note
3:29 The Boxes
5:32 Unboxing the "Fake" Headphones
6:13 Realizing They Are Actually the Real Headphones
6:23 Unboxing the Real Fake Headphones
6:43 The Pairing Process
7:10 PlasticGate & the Scale
8:39 Noise Cancellation
11:25 The Insides
11:50 Listening Test
13:42 EQing the Fake Headphones
14:14 Bluetooth Sluething
15:21 Teardown
15:40 Battery Life
17:00 Latency & the Android Experience
17:22 Should You Buy Them? & Outro

## Google's trying to be Apple - Pixel 6 Launch Event
 - [https://www.youtube.com/watch?v=A4LE1WlNy3A](https://www.youtube.com/watch?v=A4LE1WlNy3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-20 00:00:00+00:00

Get $25 off all pairs of Vessi Footwear with offer code LinusTechTips at https://vessi.com/LinusTechTips

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Google finally held the Pixel 6 Launch event, where they made lots of promises about their first custom-designed mobile chip, Tensor. Will it make the Pixel 6 and 6 Pro more interesting than the last few Pixel phones? 

Buy Google Pixel 6
On Amazon (PAID LINK): https://geni.us/wNxOf
On Best Buy (PAID LINK): https://geni.us/BVI1Mj
On B&H (PAID LINK): https://geni.us/xOOe2xW

Buy Google Pixel 6 Pro
On Amazon (PAID LINK): https://geni.us/vp7tuv
On Best Buy (PAID LINK): https://geni.us/Dt86e
On B&H (PAID LINK): https://geni.us/gaaA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1382443-google%E2%80%99s-trying-to-be-apple/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:10 What is a Pixel 'Pro'?
2:27 Google Tensor
3:31 Camera software features
5:18 Other ML-powered stuff
6:20 Conclusion

## I Will GRANT One Wish - ULTIMATE Make A Wish PC
 - [https://www.youtube.com/watch?v=9VPAvBiThMI](https://www.youtube.com/watch?v=9VPAvBiThMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-20 00:00:00+00:00

Thank you to Crucial for sponsoring this video! With over 25 years in the industry, check out Crucial for your memory and storage needs: https://crucial.gg/LinusTechTips

The Make-A-Wish foundation reached out and we answered the call with some help from Crucial to build Grant a PC, meet with Linus, and discuss retro gaming.


Buy ASUS TUF Gaming X570-Pro WiFi: https://geni.us/cpf4

Buy AMD Ryzen 7 5800x CPU: https://geni.us/bP267l

Buy Noctua NH-U12S CPU Cooler: https://geni.us/hqBhQ

Buy Crucial Ballistix RGB 2x16GB 3600MHz CL16 RAM: https://geni.us/2vOLKn

Buy Crucial P5 2TB M.2 NVMe SSD: https://geni.us/v9JtXn

Buy EVGA RTX 3080 Ti GPU: https://geni.us/OukQ

Buy EVGA SuperNOVA 750 G3 PSU: https://geni.us/ABKr

Buy ASUS VG27A Monitor: https://geni.us/hm6EWqf

Buy Logitech G Pro Wireless Keyboard: https://geni.us/CkSAZ

Buy Logitech G Pro X Superlight Gaming Mouse: https://geni.us/LHDTX

Buy Logitech Pro X Wireless Headset: https://geni.us/LrjELTs

Buy Phanteks Eclipse P500A - White: https://geni.us/5rtEr

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1382594-i-will-grant-you-one-wish-sponsored/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:03 CPU
1:55 Motherboard and Memory
2:45 Storage
3:30 CPU Cooler
4:05 The Case
6:00 Power Supply
8:00 The GPU
9:28 Peripherals
10:55 The Panel
12:22 Swag Unboxing
14:24 PC Unboxing
16:00 The Setup
17:05 Meeting Linus
25:04 Conclusion
25:55 Outro

