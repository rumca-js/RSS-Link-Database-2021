# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Is School Slowly Destroying Your Brain?
 - [https://www.youtube.com/watch?v=M4u6oOQ77mg](https://www.youtube.com/watch?v=M4u6oOQ77mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-10-21 00:00:00+00:00

Dear schools: you're hurting your students. Please stop!
Check out http://KiwiCo.com/asap and get your first month free!

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Mitchell Moffit
Edited by: Luka Šarlija

Sources:
"Why We Sleep" by Dr. Matthew Walker

