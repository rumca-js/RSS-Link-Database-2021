## Saudi-Led Group Completes Purchase of Newcastle United - The New York Times
 - [https://www.nytimes.com/2021/10/07/sports/soccer/newcastle-saudi-premier-league.html](https://www.nytimes.com/2021/10/07/sports/soccer/newcastle-saudi-premier-league.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2021-10-07 11:09:33+00:00

Saudi-Led Group Completes Purchase of Newcastle United - The New York Times

