## Australia. Rząd chce zakazać anonimowych komentarzy. Media społecznościowe to "pałac tchórzy"
 - [https://www.polsatnews.pl/wiadomosc/2021-10-07/australia-rzad-chce-zakazac-anonimowych-komentarzy-media-spolecznosciowe-to-palac-tchorzy/](https://www.polsatnews.pl/wiadomosc/2021-10-07/australia-rzad-chce-zakazac-anonimowych-komentarzy-media-spolecznosciowe-to-palac-tchorzy/)
 - RSS feed: https://www.polsatnews.pl
 - date published: 2021-10-07 20:22:14+00:00

Australia. Rząd chce zakazać anonimowych komentarzy. Media społecznościowe to "pałac tchórzy"

