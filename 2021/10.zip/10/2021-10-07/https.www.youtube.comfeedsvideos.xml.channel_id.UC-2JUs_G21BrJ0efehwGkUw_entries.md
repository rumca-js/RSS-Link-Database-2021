# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Scary Goldings IV ft. John Scofield [OFFICIAL TRAILER]
 - [https://www.youtube.com/watch?v=PoqWKmMSt5k](https://www.youtube.com/watch?v=PoqWKmMSt5k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-10-07 00:00:00+00:00

Vinyl presale begins Nov. 1
Patreon: http://modal.scarypocketsfunk.com/patreon
STORE: http://scarypocketsfunk.com
Tip Jar: http://modal.scarypocketsfunk.com/tips

Listen on Spotify: http://modal.scarypocketsfunk.com/spotify
Subscribe: http://modal.scarypocketsfunk.com/subscribe
Facebook: http://modal.scarypocketsfunk.com/facebook
Instagram: http://modal.scarypocketsfunk.com/instagram

Scary Goldings IV

MUSICIAN CREDITS
Organ: Larry Goldings
Guitar: John Scofield
Drums: Louis Cole, Lemar Carter, Tamir Barzilay
Bass: Mononeon
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko 

VIDEO CREDITS
Studio Manager: Joe Smith
Director: Merlin Showalter
DP: Merlin Showalter
Lights: Dijon Herron
Editor: Adam Kritzberg

Recorded at Valentine Studios in Studio City, CA.

#ScaryPockets #Funk #ScaryGoldings

