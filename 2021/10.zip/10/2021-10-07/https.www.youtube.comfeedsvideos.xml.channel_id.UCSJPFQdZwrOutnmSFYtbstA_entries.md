# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Final Fantasy 7 Remake - Worth The Wait
 - [https://www.youtube.com/watch?v=3lHTajebJWo](https://www.youtube.com/watch?v=3lHTajebJWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-10-08 00:00:00+00:00

The remake of Final Fantasy 7 was one of the most anticipated games of all time, but did it live up to the hype? Is it a worthy successor to the original? And where might the series be headed next? Join me as I delve deep into Final Fantasy 7 Remake.

