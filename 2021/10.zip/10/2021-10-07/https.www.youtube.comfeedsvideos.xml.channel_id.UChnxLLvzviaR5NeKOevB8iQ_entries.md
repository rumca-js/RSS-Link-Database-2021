# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## LXR-02 plus Octatrack Doing IDM I Dunno I'm Not a Musicologist
 - [https://www.youtube.com/watch?v=GwhMixIFLLI](https://www.youtube.com/watch?v=GwhMixIFLLI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-10-08 00:00:00+00:00

Do I look like a musicologist? I'm not. Stop judging me.
The LXR-02 sends two stereo outs into two channels on the Octatrack: doing effects and live resampling and resequencing.
LXR-02 at Perfect Circuit : https://bit.ly/3jtS9uZ
Elektron Octatrack: https://bit.ly/361Uu8m
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

