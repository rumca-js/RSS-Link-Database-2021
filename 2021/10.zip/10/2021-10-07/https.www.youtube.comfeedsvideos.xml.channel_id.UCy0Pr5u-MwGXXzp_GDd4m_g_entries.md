# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Classic Cobb Salad - Part 1
 - [https://www.youtube.com/watch?v=ZVPF7VSrNEY](https://www.youtube.com/watch?v=ZVPF7VSrNEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-10-07 00:00:00+00:00

Welcome to my most nonsensical sketch series yet... Get Surfshark VPN at https://surfshark.deals/nolke - Enter promo code NOLKE for 83% off and 3 extra months for FREE! 

Actors: @ChristianNat  & Julie Nolke
Writer: Julie Nolke
Camera: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Also, join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

