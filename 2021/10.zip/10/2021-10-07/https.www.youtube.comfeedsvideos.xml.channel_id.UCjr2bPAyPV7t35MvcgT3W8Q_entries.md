# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Australia Has Turned Into a Dystopian Police State
 - [https://www.youtube.com/watch?v=mAkCAZSq2a0](https://www.youtube.com/watch?v=mAkCAZSq2a0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-10-07 00:00:00+00:00

Australia is lost. It's no longer a liberal democracy with government accountability. It's a surveillance state with unlimited police powers and eradicated civil rights.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

IMPORTANT!!!
Sources wouldn't fit in the description. They are in the pinned comment of the video: https://www.youtube.com/watch?v=mAkCAZSq2a0

This is how Australia, once a much appraised liberal democracy, descended into a full-blown police state. 

Australian intelligence is one of the most powerful entities in the world. Yet it has the least amount of oversight out of all democratic nations. The law doesn’t grant Australian public the right to know about any intelligence operation, current or past ones. 

Disclosing information about operations is done solely at the discretion of Australian intelligence. Any unauthorized disclosure from public servants or intelligence officers, can lead to 10 years of imprisonment.  

No Edward Snowden or Julian Assange could ever come out of Australia, because even reporting journalists would be charged with the same crimes as whistleblowers. All attempts to limit intelligence powers have been quickly shut down before they could even reach parliamentary hearings. During the two years of the pandemic, Australian government expanded its powers to the point it rivals those behind the Great Firewall of China. 

In 2014, Australian parliament passed an amendment to the National Security Legislation with a new wording that allows ASIO to obtain a single warrant to wiretap the entire Internet. 

The amendment intentionally defines a computer such that it includes all computers operating in a network of a target. Any target person using the Internet is using a network of computers. Which makes the whole Internet the target of intelligence operations. 

Australian spies can now legally access, modify and delete files, install malware, gain higher privileges and monitor or impersonate people on any device connected to the Internet anywhere in the world. 

Since 2015, a new amendment now mandates data retention for telecommunication and Internet service providers. All of your browsing history, phone calls, text and email metadata have to be stored in Australia for two years. 

But all of that is nothing compared to what came next. Dubbed as the “anti-encryption law”, a new act now enables any law enforcement or intelligence agency in Australia to request data collection from companies under threat of hefty fines or imprisonment. 

A technical assistance notice can mandate a company to give access to customer data they already hold. This means any company can be required to secretly log data on any user without a warrant.

If a government agency needs additional data a specific company cannot provide yet, a technical capability notice will mandate them to build new surveillance tools to collect that data. 

The technical assistance request is the only voluntary form of cooperation on the bill. This one, however, means companies can willingly provide special access to their customer data in absolute secrecy. It would never be a matter of any record. No systemic weakness limits apply to these requests.



Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

