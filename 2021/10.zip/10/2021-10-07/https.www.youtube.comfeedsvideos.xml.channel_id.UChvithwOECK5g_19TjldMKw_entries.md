# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## China’s Nightmarish New Bio Weapon Targets Race and Ethnicity
 - [https://www.youtube.com/watch?v=biNxl7tiVSY](https://www.youtube.com/watch?v=biNxl7tiVSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2021-10-08 00:00:00+00:00

China building Bio Weapon that can target people based on race. China has been amassing a disturbing amount of genetic data from the rest of the world, and it's been doing it for something nightmarish.

◘ Rob Reid - Why the Future is the Good Kind of Scary
https://www.jordanharbinger.com/rob-reid-why-the-future-is-a-good-kind-of-scary/
◘ Subscribe to Jordan Harbinger Podcast 
https://www.jordanharbinger.com/subscribe-to-the-podcast/

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
The Muse Maker 
https://soundcloud.com/themusemaker

Sources:
https://www.reuters.com/investigates/special-report/health-china-bgi-dna/
https://www.defenseone.com/ideas/2019/08/its-high-time-germany-fund-and-fix-its-military/159149/
https://www.armyupress.army.mil/Journals/Military-Review/Directors-Select-Articles/Nanatechnology/
https://nonproliferation.org/wp-content/uploads/2021/09/scientific_risk_assessment_genetic_weapon_systems06_cover.pdf

