# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## No, Windows 11 Does NOT Ruin Gaming Performance (Don't Disable VBS)
 - [https://www.youtube.com/watch?v=12tL3znmoXU](https://www.youtube.com/watch?v=12tL3znmoXU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-10-08 00:00:00+00:00

Don't believe the clickbait...
⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

Tom's Hardware Benchmarks: https://www.tomshardware.com/news/windows-11-security-gaming-application-performance-benchmarks
ComputerBase Benchmarks: https://www.computerbase.de/2021-09/windows-11-ul-benchmarks-weist-auf-leistungsverlust-durch-vbs-hin/
Device Guard Explained: https://techcommunity.microsoft.com/t5/iis-support-blog/windows-10-device-guard-and-credential-guard-demystified/ba-p/376419

▼ Time Stamps: ▼
0:00 - What's the Problem?
3:41 - Common Mistake to Watch For
4:07 - VBS Crash Course
6:31 - Articles With Good Benchmarks
7:53 - My Test Computer
9:25 - Benchmark Procedure
10:26 - Benchmark Results
15:06 - Conclusions

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

