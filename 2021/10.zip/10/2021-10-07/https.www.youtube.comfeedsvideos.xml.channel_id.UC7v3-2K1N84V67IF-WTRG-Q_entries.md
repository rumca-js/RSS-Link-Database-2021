# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Marvel's What If...? - Season 1 (My Thoughts)
 - [https://www.youtube.com/watch?v=lTme2pzmOGU](https://www.youtube.com/watch?v=lTme2pzmOGU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-10-07 00:00:00+00:00

Thank you Squarespace for sponsoring this video. Head to https://squarespace.com/jeremyjahns to save 10% off your first purchase of a website or domain using code JAHNS

Marvel's WHAT IF...? Season 1 has finished, so let's talk about these hypothetical/not so hypothetical because they're alternate reality stories!

