## 'X' gender markers in passports would be 'extremely difficult', government argues in UK's top court
 - [https://www.pinknews.co.uk/2021/07/13/x-passports-supreme-court-day-2/](https://www.pinknews.co.uk/2021/07/13/x-passports-supreme-court-day-2/)
 - RSS feed: https://www.pinknews.co.uk
 - date published: 2021-10-07 05:51:28.844135+00:00

Introducing ‘X’ gender markers on British passports is a “sensitive and extremely difficult moral, ethical and legal issue”, the Supreme Court heard Tuesday (13 July). The government does not want to bring in ‘X’ gender markers in passports because it would be a “major change” with “some significant [financial] cost and the number of people … Continued

