# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Have MORE to Say About Steam Deck - WAN Show October 8, 2021
 - [https://www.youtube.com/watch?v=mvk5tVMZQ_U](https://www.youtube.com/watch?v=mvk5tVMZQ_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-08 00:00:00+00:00

Honey automatically applies the best coupon codes to save you money at 
different online checkouts, try it now at https://www.joinhoney.com/linus

Buy a Seasonic Ultra Titanium PSU
On Amazon: https://geni.us/q4lnefC
On NewEgg: https://lmg.gg/8KV3S

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/I-Have-MORE-to-Say-About-Steam-Deck---WAN-Show-October-8--2021-e18l9q7

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of NoKi1119)
[0:00] Chapters.
[2:02] Intro.
[2:46] Topic #1: Valve's Steam Deck teardown.
    4:18 Linus called out in the reaction video.
    9:12 Thoughts on what Valve can do better.
    11:31 Right to repair, battery challenges.
    19:23 Valve does not recommend SSD swapping.
[20:47] Topic #2: Linux challenge update.
    22:27 Linux dictionary is overwhelming.
    27:37 Rules of the challenge.
    31:50 Gaming, driver & hardware issues.
    37:53 Steam's Big Picture experience.
    40:02 Linus predicts hate comments for his video.
    44:04 The good & the bad, compared to other OSs.
    52:56 File extension & oddity with Github & Linux guides.
    1:00:12 Gen Z does not know where to find files.
[1:04:43] Sponsors.
    1:05:04 Honey Promo Codes.
[1:05:37] Linus rants about haters, devs & right to repair.
[--] Sponsors Cont.
    1:12:16 Seasonic's Ultra Titanium PSUs.
    1:12:54 Squarespace website builder.
[1:13:51] Topic #3: Microsoft agrees to study for right to repair.
    1:19:21 Corporates versus right to repair.
[1:21:06] LTTStore new merch.
[1:22:55] Topic #4: Twitch data leaked.
    1:27:46 Twitch's "Vapor" game streaming service.
[1:38:56] Topic #5: Facebook, Insta, WhatsApp down for 6 hours.
[1:39:49] Topic #6: Nintendo's Switch OLED Model.
[1:44:11] Topic #7: Feud with TeamViewer.
    1:50:50 TeamViewer Support's response.
[1:56:07] Superchats.
[2:05:38] Nick calling about LTT-sponsored UFD Tech stream.
[2:13:43] Outro.

## What Was Valve Hiding? - Steam Deck Teardown Reaction
 - [https://www.youtube.com/watch?v=nnyqww4-76A](https://www.youtube.com/watch?v=nnyqww4-76A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-07 00:00:00+00:00

Repower your devices with iFixit at https://iFixit.com/LTT

We finally got our first look inside the Valve Steam Deck, here's our reaction.

Buy Handheld Consoles
On Amazon (PAID LINK): https://geni.us/twnir
On Best Buy (PAID LINK): https://geni.us/oNO2eQ
On Newegg (PAID LINK): https://geni.us/j51hUL

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1379237-what-was-valve-hiding-steam-deck-teardown-reaction/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

