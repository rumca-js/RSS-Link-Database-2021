# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Arooj Aftab - Baghon Main (Live on KEXP)
 - [https://www.youtube.com/watch?v=U1wK0KwACVg](https://www.youtube.com/watch?v=U1wK0KwACVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-08 00:00:00+00:00

http://KEXP.ORG presents Arooj Aftab performing "Baghon Main" live in the KEXP gathering space. Recorded  September 24, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://www.aroojaftabmusic.com
http://kexp.org

## Arooj Aftab - Diya Hai (Live on KEXP)
 - [https://www.youtube.com/watch?v=lY9czKBv_II](https://www.youtube.com/watch?v=lY9czKBv_II)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-08 00:00:00+00:00

http://KEXP.ORG presents Arooj Aftab performing "Diya Hai" live in the KEXP gathering space. Recorded  September 24, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://www.aroojaftabmusic.com
http://kexp.org

## Arooj Aftab - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=fPX8mGSaLhU](https://www.youtube.com/watch?v=fPX8mGSaLhU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-08 00:00:00+00:00

http://KEXP.ORG presents Arooj Aftab performing live in the KEXP gathering space. Recorded  September 24, 2021.

Songs:
Baghon Main
Suroor
Diya Hai
Mohabbat

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://www.aroojaftabmusic.com
http://kexp.org

## Arooj Aftab - Mohabbat (Live on KEXP)
 - [https://www.youtube.com/watch?v=U89BGcn_AOs](https://www.youtube.com/watch?v=U89BGcn_AOs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-08 00:00:00+00:00

http://KEXP.ORG presents Arooj Aftab performing "Mohabbat" live in the KEXP gathering space. Recorded  September 24, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://www.aroojaftabmusic.com
http://kexp.org

## Arooj Aftab - Suroor (Live on KEXP)
 - [https://www.youtube.com/watch?v=ofrh_v5IfmY](https://www.youtube.com/watch?v=ofrh_v5IfmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-08 00:00:00+00:00

http://KEXP.ORG presents Arooj Aftab performing "Suroor" live in the KEXP gathering space. Recorded  September 24, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://www.aroojaftabmusic.com
http://kexp.org

## Generación Suicida - Balas, Siempre Balas (Live on KEXP)
 - [https://www.youtube.com/watch?v=6feAE_b1dlQ](https://www.youtube.com/watch?v=6feAE_b1dlQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-07 00:00:00+00:00

http://KEXP.ORG presents Generación Suicida performing "Balas, Siempre Balas" live in the KEXP gathering space. Recorded September 23, 2021.

Host: Jenn
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://generacionsuicida.bandcamp.com
http://kexp.org

## Generación Suicida - Desaparecer (Live on KEXP)
 - [https://www.youtube.com/watch?v=MEI4dka_TFg](https://www.youtube.com/watch?v=MEI4dka_TFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-07 00:00:00+00:00

http://KEXP.ORG presents Generación Suicida performing "Desaparecer" live in the KEXP gathering space. Recorded September 23, 2021.

Host: Jenn
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://generacionsuicida.bandcamp.com
http://kexp.org

## Generación Suicida - Fuego (Live on KEXP)
 - [https://www.youtube.com/watch?v=zp7X21l2uc4](https://www.youtube.com/watch?v=zp7X21l2uc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-07 00:00:00+00:00

http://KEXP.ORG presents Generación Suicida performing "Fuego" live in the KEXP gathering space. Recorded September 23, 2021.

Host: Jenn
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://generacionsuicida.bandcamp.com
http://kexp.org

## Generación Suicida - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=8WB5OPFkFAs](https://www.youtube.com/watch?v=8WB5OPFkFAs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-07 00:00:00+00:00

http://KEXP.ORG presents Generación Suicida performing live in the KEXP gathering space. Recorded September 23, 2021.

Songs:
Balas, Siempre Balas
Fuego
Desaparecer
Violencia

Host: Jenn
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://generacionsuicida.bandcamp.com
http://kexp.org

## Generación Suicida - Violencia (Live on KEXP)
 - [https://www.youtube.com/watch?v=ErDhmiBJ22A](https://www.youtube.com/watch?v=ErDhmiBJ22A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-07 00:00:00+00:00

http://KEXP.ORG presents Generación Suicida performing "Violencia" live in the KEXP gathering space. Recorded September 23, 2021.

Host: Jenn
Audio Engineers: Julian Martlew & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://generacionsuicida.bandcamp.com
http://kexp.org

