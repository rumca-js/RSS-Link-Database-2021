# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Startup scams are getting out of hand...
 - [https://www.youtube.com/watch?v=FoAJKeus16M](https://www.youtube.com/watch?v=FoAJKeus16M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-10-07 00:00:00+00:00

Find out how Upstart can lower your monthly payments today at https://www.upstart.com/jaketran 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Disclaimer: I do NOT we have any long or short positions against Nikola Motors

This video is based off of the Hindenburg Research report on Nikola Motors, among other sources, linked below. The views and opinions expressed in this video are based on those sources and do not necessarily reflect or represent the views and opinions held by Transcend Visuals, LLC. or its affiliates. 
Founder & CEO of Nikola Motors, Trevor Milton has been charged with two counts of securities fraud and wire fraud but has NOT been proven guilty yet. All claims made in this video are mere allegations based on the sources provided. Don’t sue me bro.

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✨ Follow us on TikTok: https://jake.yt/tiktok
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
💬 Join the community Discord: http://discord.gg/BmK8EnQ

💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎵 Get unlimited royalty-free music for your videos with Epidemic Sound! ➡️ https://share.epidemicsound.com/jaketran 

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/3uFwtQk

-----------------------
What you’re watching right now is the world’s first ever hydrogen fuel-cell semi truck on the road, thanks to a company called Nikola Motors. The only problem is - this video is fake. It was a fraud designed to swindle investors into dumping more money into this “tesla killer” - allegedly.

These regular car companies were under huge pressure from analysts and shareholders to electrify so their stock could see similar gains. GM entered into a strategic manufacturing partnership with Nikola Motors. But as GM would soon find out - Nikola Motors was far from the saving grace they hoped for. 

“I never deceived anyone!” - Nikola Executive Chairman, Trevor Milton. Trevor Milton, the man behind Nikola Motors, has had a sketchy track record to say the least. Tech founders are often criticized for being too ambitious or too optimistic, but according to Hindenburg Research, Trevor took this way too literally.

After Trevor sold his very first business, a security and alarm business, Trevor started a used car sales website that ultimately failed, but it got him into the world of EVs. After dHybrid’s launch, Trevor became the CEO of Swift Transportation. But Trevor abandoned ship and decided to start a new, but not very different, company with his dad, called dHybrid Systems LLC. Two years after starting dHybrid Systems, he sold it to Worthington Industries for $15.9m, giving them almost 80% of the company. 

Nikola Motors started a lot like how all of his other business ideas ended, with a lot of stretching of the truth. They started to duct tape together third-party truck parts in an effort to build their first truck.

-----------------------

No Spirit - Morning In The Cafe https://chll.to/0a89612d 

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

