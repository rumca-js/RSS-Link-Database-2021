# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Leaked Documents Expose Facebook
 - [https://www.youtube.com/watch?v=_Dzb1Yl413Q](https://www.youtube.com/watch?v=_Dzb1Yl413Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-10-08 00:00:00+00:00

Previous Facebook Documentary: https://www.youtube.com/watch?v=m6JTaRNTN0c

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Discord:  https://discord.gg/coldfusion

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.privacyaffairs.com/facebook-data-sold-on-hacker-forum/

https://www.theguardian.com/technology/2021/oct/05/facebook-harms-children-damaging-democracy-claims-whistleblower

https://www.theguardian.com/technology/2021/oct/06/mark-zuckerberg-hits-back-at-facebook-whistleblower-frances-haugen-claims

https://www.tweaktown.com/news/81974/over-1-5-billion-facebook-users-private-info-sold-on-hacker-forum/index.html

My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Hiatus - Cloud City

Gigi Masin & Alessandro Monti - Stella Maris

Rynn- Blindspot

House of Hum - Blink

Hiatus – Nimbus

Andre Sobota - Concluded (Original Mix)

Deccies – Subtle

Burn Water – It Get’s Easier


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

