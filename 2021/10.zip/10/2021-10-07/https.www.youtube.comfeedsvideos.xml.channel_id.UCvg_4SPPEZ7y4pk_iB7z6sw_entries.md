# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## The Lawnmower Man: A Film That Exists
 - [https://www.youtube.com/watch?v=Q7QPnFPzNgQ](https://www.youtube.com/watch?v=Q7QPnFPzNgQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-10-08 00:00:00+00:00

So yeah. It’s The Lawnmower Man. It’s….self explanatory. He just mows the lawns. A whole movie just about that. Ya get to learn about all the kinds of grass seed and turf and care. Don’t over water, be careful with all treatment options. 

Otherwise your lawn won’t look so good anymore.

Twitter: https://twitter.com/WhimsuHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpe...


Originally this was gonna be a KnowledgeHub vid, but I decided, eh, might as well try it here. So, yup. That’s, about all I can say for the description. I’m pretty sure they want these to be fairly long, so, guess I’ll keep typing. Just a bit more. Okay. One more sentence. And. Thats……it. Yup. I’m done typing the description. Guess I’ll go on and stop pressing buttons on the keyboard. Right………now

