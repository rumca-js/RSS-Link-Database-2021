# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Bee Outtakes, Weight Loss Cult, and Homicidal Whales
 - [https://www.youtube.com/watch?v=SFnzCfO7a3U](https://www.youtube.com/watch?v=SFnzCfO7a3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-08 00:00:00+00:00

Kyle, Ethan, and Adam talk about their favorite hilarious Babylon Bee Outtakes that didn’t make the final cut of Babylon Bee sketches, the new HBO Max documentary on Gwen Shamblin Lara and her weight loss cult as another Hero of the Faith, and Homicide Whales now being a thing. The Bee guys go through weird news of the week and salty hate mail too.

You can now Join the Launch Team for The Babylon Bee Guide to Wokeness: https://bit.ly/BabylonBeeLaunchTeam

Check out Adam Yenser’s YouTube channel and stand-up comedy schedule (http://adamyenser.com/).

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Woke Zone Trilogy
 - [https://www.youtube.com/watch?v=a31ifa6dkmg](https://www.youtube.com/watch?v=a31ifa6dkmg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-08 00:00:00+00:00

You are now entering a dimension of riots, militant political correctness, and creepy CRT dolls. Watch all three episodes of the Woke Zone trilogy here!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Ten Greatest Countries On Earth
 - [https://www.youtube.com/watch?v=6ll_IogUhwI](https://www.youtube.com/watch?v=6ll_IogUhwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-07 00:00:00+00:00

Here are the authoritative greatest countries on Earth. Did your favorite make the list? Watch and find out!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

