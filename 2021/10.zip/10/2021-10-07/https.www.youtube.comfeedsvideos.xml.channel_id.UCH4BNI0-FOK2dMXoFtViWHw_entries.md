# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## I Can't Believe We're Making Another COVID Video
 - [https://www.youtube.com/watch?v=8d8qrDCOnCA](https://www.youtube.com/watch?v=8d8qrDCOnCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-10-08 00:00:00+00:00

Check out PBS Vitals ►► https://youtu.be/xus08qnUxPE
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

I guess we’re still doing this. 

References: https://docs.google.com/document/d/1-xoLMZfumSmb1v7B3QmFD5pTC87GYeGEnlSXKg0bCk0/edit 

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

-----------

Special thanks to our Brain Trust Patrons:

Joseph Spencer
Barbora Bei
Ken Board
Clinger-Hamilton Family
Attila Pix
Burt Humburg
DeliciousKashmiri
Brian Chang
Roy Lasris
Javier Soto
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Marcus Tuepker
Karen Haskell
AlecZero

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

