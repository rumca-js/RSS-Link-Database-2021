# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## A Constipation Drug Could Improve Memory | SciShow News
 - [https://www.youtube.com/watch?v=GoWqMS2BJdk](https://www.youtube.com/watch?v=GoWqMS2BJdk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-10-08 00:00:00+00:00

This episode is sponsored by Endel, an app that creates personalized soundscapes to help you focus, relax and sleep.The first 100 people to sign up here get a one week free trial:  https://app.adjust.com/b8wxub6?campaign=scishow_october&adgroup=youtube

Could you enter a flow state with the people around you? Also we've found a promising drug for treating mental illness, and it might not come from where you expect.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bryan Cloer, Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, charles george, Christoph Schwanke, Ash, Silas Emrys, Eric Jensen, Adam Brainard, Piya Shedden, Alex Hackman, James Knight, GrowingViolet, Sam Lutfi, Alisa Sherbow, Jason A Saslow, Dr. Melvin Sanicas, Melida Williams, Tom Mosner

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:

https://dx.doi.org/10.1523/ENEURO.0133-21.2021
https://www.eurekalert.org/news-releases/929809?

https://dx.doi.org/10.1038/s41398-021-01568-4
https://www.eurekalert.org/news-releases/930043

IMAGES

https://www.istockphoto.com/photo/focused-african-student-looking-at-laptop-holding-book-doing-research-gm1144287280-307571999
https://www.istockphoto.com/photo/team-of-four-professional-cybersport-gamers-wearing-headphones-participating-in-gm1282170527-379983601
https://www.istockphoto.com/photo/hands-typing-on-laptop-gm828176736-134723351
https://www.istockphoto.com/photo/headphones-on-wooden-floor-gm639838630-115555857
https://commons.wikimedia.org/wiki/File:Middle_Temporal_-_DK_ATLAS.png
https://www.eurekalert.org/multimedia/801560
https://www.istockphoto.com/photo/animal-experiments-with-mice-model-gm1079422378-289256549
https://www.istockphoto.com/photo/planet-earth-gm474218822-64507413
https://www.eurekalert.org/multimedia/801899

## Hilde Mangold and the Organizer of Life | Great Minds
 - [https://www.youtube.com/watch?v=00L05Aqh7_0](https://www.youtube.com/watch?v=00L05Aqh7_0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-10-07 00:00:00+00:00

Thanks to Unbounce for sponsoring today's video. Go to https://thld.co/unbounce_scishow and use the promo code SCISHOW at checkout to get 20% off your first 3 months.

Experiments conducted by Hilde Mangold and Hans Spemann taught us how an animal develops from a small ball of cells into an organism with distinct, functioning parts. The work was a foundational contribution to the field of developmental biology.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bryan Cloer, Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, charles george, Christoph Schwanke, Ash, Silas Emrys, Eric Jensen, Adam Brainard, Piya Shedden, Alex Hackman, James Knight, GrowingViolet, Sam Lutfi, Alisa Sherbow, Jason A Saslow, Dr. Melvin Sanicas, Melida Williams, Tom Mosner

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
http://www.ijdb.ehu.es/web/paper.php?doi=11291841
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2464568/
https://www.jstor.org/stable/4330877?seq=1#page_scan_tab_contents

https://www.ncbi.nlm.nih.gov/books/NBK10101/
https://opentextbc.ca/biology/chapter/24-6-fertilization-and-early-embryonic-development/
https://www.nobelprize.org/prizes/medicine/1935/spemann/lecture/
https://www.dictionary.com/browse/developmental-biology

Images:
https://commons.wikimedia.org/wiki/File:Hilde_Mangold.jpg
https://commons.wikimedia.org/wiki/File:Zygote1.jpg
https://www.istockphoto.com/vector/development-of-the-human-embryo-gm509962405-46482592
https://www.istockphoto.com/vector/pink-human-skin-cell-vector-seamless-pattern-gm1076612692-288319198
https://www.istockphoto.com/vector/cell-division-background-gm500374547-42835662
https://www.istockphoto.com/photo/frog-spawn-gm1002876014-270985943
https://commons.wikimedia.org/wiki/File:TriturusCristatusYoungLarva.JPG
https://www.istockphoto.com/photo/young-businessman-getting-tired-and-depressed-working-hard-in-the-office-gm683118450-125353095
https://www.istockphoto.com/vector/phone-tablet-icon-with-tile-user-interface-on-screen-flat-style-vector-illustration-gm942687596-257620352
https://commons.wikimedia.org/wiki/File:Hans_Spemann_nobel.jpg

