## Here’s exactly how social media algorithms can manipulate you - Big Think
 - [https://bigthink.com/the-present/social-media-algorithms-manipulate-you/](https://bigthink.com/the-present/social-media-algorithms-manipulate-you/)
 - RSS feed: https://bigthink.com
 - date published: 2021-10-07 15:57:13+00:00

Here’s exactly how social media algorithms can manipulate you - Big Think

