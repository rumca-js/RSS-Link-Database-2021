# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Samsung has higher margins than Apple?
 - [https://www.youtube.com/watch?v=or5A798APfc](https://www.youtube.com/watch?v=or5A798APfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-10-08 00:00:00+00:00

Sponsored by Morning Brew. Sign up for free today: https://bit.ly/mbfridaycheckout3

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week Twitch got hacked with leaked salaries and source code, AMD was rumored to make an ARM chip for Windows and Samsung had higher margins than Apple I a new BOM cost analysis.

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 

Quiz: https://link.crrowd.com/quiz

Episode 66

This video on Nebula: https://nebula.app/videos/the-friday-checkout-samsung-has-higher-margins-than-apple

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:31 Release Monitor
1:47 Twitch leaks & salaries
5:23 An ARM chip from AMD?
6:26 Samsung vs Apple profits

