# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How Much Freedom Do You Allow Your Kids to Have?
 - [https://www.youtube.com/watch?v=_6WvpDEV-nM](https://www.youtube.com/watch?v=_6WvpDEV-nM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-07 00:00:00+00:00

Taken from JRE #1716 w/Steve Rinella:
https://open.spotify.com/episode/6KqPYNM4FsXG800XnRfpti?si=K4uNWyGOQ-mKEnw-oDXLHw&dl_branch=1

