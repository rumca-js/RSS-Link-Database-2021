# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## ROCKSTAR GAMES' OPEN WORLD SPY GAME DUMPED, ELDEN RING DIFFICULTY EXPLAINED, & MORE
 - [https://www.youtube.com/watch?v=heGh8lpPhsI](https://www.youtube.com/watch?v=heGh8lpPhsI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-08 00:00:00+00:00

Thanks to Raycon for sponsoring this video. Go to https://buyraycon.com/gameranx for 15% off your order! Brought to you by Raycon.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

The GTA Trilogy Definitive Edition is revealed by Rockstar games, PlayStation head Jim Ryan talks expanding their audience, and MORE in a week chock full of gaming news.


 ~~~~STORIES~~~~




RIP Rockstar’s Agent
https://screenrant.com/rockstar-games-agent-ps3-game-canceled-possibly-confirmed/

New Elden Ring details
https://www.dualshockers.com/elden-ring-difficulty-gameplay-details-revealed-at-tgs-2021/


PlayStation interview
https://youtu.be/UvVo0kl0SAY

Gearbox changes
https://www.ign.com/articles/gearbox-software-new-president-steve-jones-randy-pitchford?utm_source=twitter





Steam Deck teardown
https://youtu.be/UahXjChuiPI
https://www.theverge.com/2021/10/5/22709918/valve-steam-deck-supported-games-anti-cheat-proton-eac-battleye-epic


DeLorean in Forza
https://youtu.be/aOsczqWxvpg

Resident Evil movie trailer 
https://youtu.be/PSgAc6sHNO4

Nick All Star Brawl is out
https://youtu.be/AA39bbw3j78

Far Cry 6 Before You Buy
https://youtu.be/RMEFwqCQSrU


Haunted Train game
https://youtu.be/4jOvGjxM1xg


Ghost Recon battle Royale
https://youtu.be/o_k6k8JZ9Gc


Sora Smash (Oct 18)
https://youtu.be/L-q6Gz_4Yqc

## Far Cry 6 - 10 Things The Game DOESN'T TELL YOU
 - [https://www.youtube.com/watch?v=BFrTJSXxzEM](https://www.youtube.com/watch?v=BFrTJSXxzEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-07 00:00:00+00:00

Far Cry 6 (PC, PS5, PS4, Xbox Series X/S/One) is here and it is as massive as you'd expect. Here are some good tips before jumping in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#FarCry6

## Far Cry 6 - Before You Buy [4K]
 - [https://www.youtube.com/watch?v=RMEFwqCQSrU](https://www.youtube.com/watch?v=RMEFwqCQSrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-07 00:00:00+00:00

Far Cry 6 (PC PS5, PS4, Xbox Series X/S/One) is here and it's filled with evil characters, wild action, and some stuff you've already seen. Let's dive in.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Far Cry 6: https://amzn.to/3DmO02M

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#FarCry6

