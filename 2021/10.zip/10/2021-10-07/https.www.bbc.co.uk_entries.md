## Whistleblower breaks Facebook secrecy wall, MP says - BBC News
 - [https://www.bbc.co.uk/news/technology-58816118](https://www.bbc.co.uk/news/technology-58816118)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-10-07 07:29:17.637307+00:00

Facebook whistleblower Frances Haugen will soon give evidence to a parliamentary committee.

