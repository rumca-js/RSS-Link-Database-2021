# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Follow You - Imagine Dragons (Piano & Cello Cover) The Piano Guys
 - [https://www.youtube.com/watch?v=jSf8xliUcDc](https://www.youtube.com/watch?v=jSf8xliUcDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2021-10-08 00:00:00+00:00

GET OUR LATEST ALBUM: https://smarturl.it/TPG_LATEST_ALBUM 
“Follow You” by Imagine Dragons piano & cello cover from The Piano Guys.
STREAM THIS SONG: https://smarturl.it/followyou_Landing 
WE’RE ON TOUR: https://smarturl.it/the10tour
SUBSCRIBE: https://bit.ly/subTPG
NEWEST videos: https://youtube.com/watch?v=IkBGhMUGtuA&list=PL7j5iXGSdMwc6hOknjuRsk6x8UieRRngh&index=2
  
Learn about our beliefs here: https://smarturl.it/TPG_Beliefs

Follow The Piano Guys:
Facebook: https://facebook.com/ThePianoGuys/
Instagram: https://instagram.com/thepianoguys/
Twitter: https://twitter.com/thepianoguys
 
Watch More of The Piano Guys:
Official Music Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwfDukj_bIIB_1JhbYtaWRYg&playnext=1&index=2
Newest Videos: https://youtube.com/playlist?list=PL7j5iXGSdMweO0HJlfOWtI2693vu23r_C&playnext=1&index=2
Most Popular: https://youtube.com/playlist?list=PL7j5iXGSdMwc3F_u0P8QDpINSrsG_a5Tl&playnext=1
 
Listen to The Piano Guys:
Spotify: https://open.spotify.com/artist/0jW6R8CVyVohuUJVcuweDI?si=8GgyFRhiTz6POs8b0ir2IA&dl_branch=1
Apple Music: https://music.apple.com/us/artist/the-piano-guys/498030399
Amazon Music: https://amazon.com/The-Piano-Guys/e/B00BXLTTI4

Credits:
- Cello, Piano, Percussion & Keyboards: Steven Sharp Nelson
- Percussion & Keyboards: Al van der Beek
- Cello Recorded by: Trevor Price at the lounge in SLC and Al van der Beek at TPG Studios
- Mixed & Mastered by: Al van der Beek (TPG Studios, Utah)
 
About The Piano Guys:
Billions of views. Millions of followers. Wonders of the World. Concerts in every corner of the globe. Who knew all this could have started in a little Yamaha Piano Store in a tiny town of Southern Utah? But that’s what happened. Paul, a Yamaha dealer who dabbled in videography, Jon, a professional pianist, Al, a music producer and studio engineer, and Steve, a cellist with a creative superpower called ADHD, all serendipitously joined forces to create the most successful YouTube instrumental music group in history. The Piano Guys are watched and streamed over 3 million times EVERY DAY.
 
They’ve made their mark by taking the piano and cello out of their concert hall context and putting them in places you’d never expect to see them: On a speeding train, a cliff’s edge, a beach, or in front of the Seven Wonders. The Piano Guys’ mission is to inspire and spread hope through incomparably imaginative music videos filmed all over the world.
Learn more online at ThePianoGuys.com
 
#ImagineDragons #PianoCover #CelloCover #Piano #Cello #ThePianoGuys

