## Finland joins Sweden and Denmark in limiting Moderna COVID-19 vaccine
 - [https://www.reuters.com/world/europe/finland-pauses-use-moderna-covid-19-vaccine-young-men-2021-10-07/](https://www.reuters.com/world/europe/finland-pauses-use-moderna-covid-19-vaccine-young-men-2021-10-07/)
 - RSS feed: https://www.reuters.com
 - date published: 2021-10-07 16:31:39+00:00

Finland joins Sweden and Denmark in limiting Moderna COVID-19 vaccine

