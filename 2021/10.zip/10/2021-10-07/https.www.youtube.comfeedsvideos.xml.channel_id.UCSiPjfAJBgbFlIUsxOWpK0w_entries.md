# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Extreme Ways ft. MOBY // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=s0OWyoXNjcw](https://www.youtube.com/watch?v=s0OWyoXNjcw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-10-07 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 There’s nothing quite so surreal as covering a Moby song WITH Moby.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Moby's "Extreme Ways" by Pomplamoose & Moby.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Moby & Jack Conte
Bass: Nick Campbell
Drums: Ben Rose
Background Vocals: Nahneen Kula

AUDIO CREDITS
Engineer: Bill Mims
Mixing/Mastering: Caleb Parker
Producer: Ben Rose

VIDEO CREDITS
Director: Dom Fera
DP / A Cam: Merlin Showalter
Gaffer / Key Grip: Arjay Ancheta
Production Designer: Katie Theel
Hair & Makeup: Christina Vo
Wardrobe: Elle Olsen
PA's: Chris Modl, Alex Allen
Video Editor: Ryan Blewett
Additional Post: Dom Fera
Colorist: Charlene Gibbs

#Pomplamoose #Moby #IndieRock

LYRICS
Extreme ways are back again
Extreme places I didn't know
I broke everything new again
Everything that I'd owned
I threw it out the windows, came along
Extreme ways I know will part
The colors of my sea
Perfect colored me
Extreme ways that help me
They help me out late at night
Extreme places I had been
That never seen any light
Dirty basements, dirty noise
Dirty places coming through
Extreme worlds alone
Did you ever like it then?

I would stand in line for this
There's always room in life for this

Oh baby, oh baby
Then it fell apart, it fell apart
Oh baby, oh baby
Then it fell apart, it fell apart
Oh baby, oh baby
Then it fell apart, it fell apart
Oh baby, oh baby
Like it always does, always does

Extreme sounds that told me
They held me down late at night
I didn't have much to say
I didn't get above the light
I closed myself and closed my eyes
And closed my world and never open up to anything
That could get me along
I had to close down everything
I had to close down my mind
Too many things could cut me
Too much can make me blind
I've seen so much in so many places
So many heartaches, so many faces
So many dirty things
You couldn't even believe

I would stand in line for this
There's always room in life for this

Oh baby, oh baby
Then it fell apart, it fell apart
Oh baby, oh baby
Then it fell apart, it fell apart
Oh baby, oh baby
Then it fell apart, it fell apart
Oh baby, oh baby
Like it always does, always does

