# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How Much Freedom Do You Allow Your Kids to Have?
 - [https://www.youtube.com/watch?v=_6WvpDEV-nM](https://www.youtube.com/watch?v=_6WvpDEV-nM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-07 00:00:00+00:00

Taken from JRE #1716 w/Steve Rinella:
https://open.spotify.com/episode/6KqPYNM4FsXG800XnRfpti?si=K4uNWyGOQ-mKEnw-oDXLHw&dl_branch=1

## Jessica Kirson on Meeting Robert De Niro
 - [https://www.youtube.com/watch?v=Y5kAU1iNVqo](https://www.youtube.com/watch?v=Y5kAU1iNVqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-06 00:00:00+00:00

Taken from JRE #1717 w/Jessica Kirson:
https://open.spotify.com/episode/5scRPtxEuUFXjeRhYHcpFk?si=BlQloyl5QCq5YMye3PAgYQ&dl_branch=1

