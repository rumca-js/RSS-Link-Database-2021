# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## SteveWillDoIt's Dark Secret - ROOBET'S HOUSE OF CARDS EP. 1
 - [https://www.youtube.com/watch?v=EbYLxrM5NdU](https://www.youtube.com/watch?v=EbYLxrM5NdU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-10-06 00:00:00+00:00

WATCH THE FULL SERIES HERE: https://www.youtube.com/watch?v=EbYLxrM5NdU&list=PL4qw3AkxFDSMD7ocgT7wEQq6hHuLAPRTn
PART 2: https://www.youtube.com/watch?v=h58ijoERfgg
PART 3: https://www.youtube.com/watch?v=qASMjT9Kmlw

Lifestyles of the Rich and Shameless --- This is a 6-part investigation with SomeOrdinaryGamers into ROOBET, an online offshore website with games like CRASH, where many people are pushed by online influencers like SteveWillDoit and many others. Where do these people get their money? Who pays them? How much? We're gonna find out. How can you make a video like I Spent $1,000,000 on this Video!

Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryBagg96

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

