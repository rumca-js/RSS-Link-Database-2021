# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## BREACH OF PEACE -SUMMARY
 - [https://www.youtube.com/watch?v=axTAmiGck6M](https://www.youtube.com/watch?v=axTAmiGck6M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-10-07 00:00:00+00:00

The summary of my book, the first in the lawful times series, Breach of Peace! 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3nLIQca 

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

New P.O. Box: PO Box 7874 Henrico, VA 23231

## Punk Hazard's Ups and Downs!
 - [https://www.youtube.com/watch?v=Y3YGky7bckY](https://www.youtube.com/watch?v=Y3YGky7bckY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-10-06 00:00:00+00:00

My thoughts on Punk Hazard, the 20... something ish One Piece arc! Good lord... there have been so many!
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://t.co/sEHQP0VEJe?amp=1

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

New P.O. Box: PO Box 7874 Henrico, VA 23231

