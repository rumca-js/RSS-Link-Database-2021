## More details about the October 4 outage - Facebook Engineering
 - [https://engineering.fb.com/2021/10/05/networking-traffic/outage-details/](https://engineering.fb.com/2021/10/05/networking-traffic/outage-details/)
 - RSS feed: https://engineering.fb.com
 - date published: 2021-10-06 06:09:00.862654+00:00

Now that our platforms are up and running after yesterday’s outage, we are sharing more detail on what happened and what we've learned.

