# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Isildur, Valian Years, and 400k Subscribers!
 - [https://www.youtube.com/watch?v=6uOGodlijHY](https://www.youtube.com/watch?v=6uOGodlijHY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-10-28 00:00:00+00:00

Join us in celebrating the 400,000 subscriber milestone as we chat Lord of the Rings!  Topics will include the Isildur rumor, what the alternate calculation for Valian Years means for some of our favorite characters, and whatever the chat would like to discuss!  Let's have some fun talking Tolkien!

#tolkien #lotronprime #isildur

