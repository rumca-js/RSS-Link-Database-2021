# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Smooth Criminal - Michael Jackson ('Film Noir' Style Cover) ft. Aubrey Logan
 - [https://www.youtube.com/watch?v=cRRJIUI6-tY](https://www.youtube.com/watch?v=cRRJIUI6-tY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2021-10-28 00:00:00+00:00

Postmodern Jukebox Film Noir cover of "Smooth Criminal" by Michael Jackson ft. Aubrey Logan.
Get the song: https://www.pmjlive.com/oldiefans | Subscribe: http://bit.ly/subPMJ
Live Show Tix:  http://www.pmjtour.com | Next, "Where Is My Mind?" (Cover): https://youtu.be/9EQq7ydALuE

"Just the facts, Ma'am." All-around music virtuoso Aubrey Logan returns for her 10th PMJ video to take us back to the 'film noir' crime drama era in this jazz trio retelling of the Michael Jackson classic, "Smooth Criminal."

____________________________________________

Follow The Musicians:
Aubrey Logan (Vocals & Trombone)
YouTube: https://www.youtube.com/channel/UCa66Ws2soOIeLpyjNIJsLcg
Website: https://aubreylogan.com
Facebook: https://www.facebook.com/aubreyloganmusic
Instagram: https://www.instagram.com/aubrey_logan

Adam Kubota (Bass): https://www.instagram.com/adamkubota_bass
Dave Tedeschi (Drums): https://www.instagram.com/davetedeschi

Scott Bradlee (Piano & Arrangement):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

Directed & Produced: Scott Bradlee
Cinematography: Guy Livneh
Audio: Thai Long Ly https://www.instagram.com/tl2bass
____________________________________________
#MichaelJackson #SmoothCriminal #Cover

