# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Amyl and The Sniffers - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=928ViCUbYhs](https://www.youtube.com/watch?v=928ViCUbYhs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-28 00:00:00+00:00

http://KEXP.ORG presents Amyl and The Sniffers performing live, recorded exclusively for KEXP.

Songs:
Some Mutts (Can't Be Muzzled)
Hertz
Guided By Angels
Security
Knifey
Capital
I Don't Need A Cunt (Like You To Love Me)
Maggot

Filmed at Soundpark Studios in Melbourne, Australia
Directed by Mark Bakaitis
Recorded by Andrew 'Idge' Hehir
Mixed by Dan Luscombe

Amy Taylor - vocals
Bryce Wilson - drums
Dec Martens - guitar
Gus Romer - bass

https://www.amylandthesniffers.com
http://kexp.org

## Amyl and The Sniffers - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=hoznYH_MGCo](https://www.youtube.com/watch?v=hoznYH_MGCo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-27 00:00:00+00:00

http://KEXP.ORG presents Amyl and The Sniffers sharing a live performance recorded exclusively for KEXP and talking to Troy Nelson. Recorded October 14, 2021.

Songs:
Some Mutts (Can't Be Muzzled)
Hertz
Guided By Angels
Security
Knifey
Capital
I Don't Need A Cunt (Like You To Love Me)
Maggot

Filmed at Soundpark Studios in Melbourne, Australia
Directed by Mark Bakaitis
Recorded by Andrew 'Idge' Hehir
Mixed by Dan Luscombe

Amy Taylor - vocals
Bryce Wilson - drums
Dec Martens - guitar
Gus Romer - bass

https://www.amylandthesniffers.com
http://kexp.org

