# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Pixel 6/6 Pro Review: Almost Incredible!
 - [https://www.youtube.com/watch?v=9hvjBi4PKWA](https://www.youtube.com/watch?v=9hvjBi4PKWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-10-27 00:00:00+00:00

Finally. A Google flagship. Pixel 6 is the real deal!

ICONS for Pixel 6: https://dbrand.com/shop/ICONS
Android 12 Features: https://youtu.be/FITTkh-kf6g

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Google for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

