# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Fictional Characters Forced To Change Their Identities Support Group
 - [https://www.youtube.com/watch?v=PRu3qS9gKJA](https://www.youtube.com/watch?v=PRu3qS9gKJA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-28 00:00:00+00:00

How would you feel if your sexuality and identities suddenly changed against your will? Well Bisexual Superman is having a rough time with that. This support group will help him.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Babylon Bee Guide To Wokeness Will Radicalize YOU!
 - [https://www.youtube.com/watch?v=gYljLEHOsAg](https://www.youtube.com/watch?v=gYljLEHOsAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-27 00:00:00+00:00

The Babylon Bee Guide To Wokeness will turn you from a MAGA into an SJW! 

Be deplorable no more and order now: https://www.amazon.com/Babylon-Bee-Guide-Wokeness/dp/1684512719/ref=sr_1_1_sspa?dchild=1&gclid=Cj0KCQjw8eOLBhC1ARIsAOzx5cEMzKzsFgB3rN8Jtv1WYraB45bEo3TRda1jJtbJqrO-wArVQzq0M4MaAvkMEALw_wcB&hvadid=540126299025&hvdev=c&hvlocphy=9052218&hvnetw=g&hvqmt=e&hvrand=16776733561140656595&hvtargid=kwd-1409883395264&hydadcr=17811_10949264&keywords=babylon+bee+guide+to+wokeness&qid=1635365052&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEzS1A3SUozR0FBSzFZJmVuY3J5cHRlZElkPUEwOTU3ODE1MThVS1IzRDg1MTRXSSZlbmNyeXB0ZWRBZElkPUEwODIwNzMzMkVDQllENVNJTEVBUyZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU=

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

