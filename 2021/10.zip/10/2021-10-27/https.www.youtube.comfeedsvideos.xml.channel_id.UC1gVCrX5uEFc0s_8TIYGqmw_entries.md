# Source:Olden days, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw, language:en-US

## Elswick - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=sTGhH6AGsM0](https://www.youtube.com/watch?v=sTGhH6AGsM0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:35:05+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Hollinwood - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=fgTFwPsBCaA](https://www.youtube.com/watch?v=fgTFwPsBCaA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:35:02+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Parkgate - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=Dv2BsDnMDJE](https://www.youtube.com/watch?v=Dv2BsDnMDJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:35:00+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## North Sea Fishery - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=K_ILGYvuKK8](https://www.youtube.com/watch?v=K_ILGYvuKK8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:57+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Cunard Vessel - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=nflyIQ20r6I](https://www.youtube.com/watch?v=nflyIQ20r6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:55+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Preston - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=0Z-GROZdV1M](https://www.youtube.com/watch?v=0Z-GROZdV1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:53+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Manchaster Band- [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=HddcX_iL_TQ](https://www.youtube.com/watch?v=HddcX_iL_TQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:47+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Blackpool Pier - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=AXLZ4rKlaGw](https://www.youtube.com/watch?v=AXLZ4rKlaGw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:44+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Leeds Athletic - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=DInNX4k8WJA](https://www.youtube.com/watch?v=DInNX4k8WJA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:41+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Dewsburry - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=V7s_xgrokz8](https://www.youtube.com/watch?v=V7s_xgrokz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:38+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Sedgwick - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=vhkwym6WrOA](https://www.youtube.com/watch?v=vhkwym6WrOA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:35+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Derby - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=hvF7yNWE0EE](https://www.youtube.com/watch?v=hvF7yNWE0EE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:32+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Procession - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=rb2VoFJqwlg](https://www.youtube.com/watch?v=rb2VoFJqwlg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2021-10-27 19:34:30+00:00

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

