# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe on Hafthor Bjornsson Transitioning to Boxing
 - [https://www.youtube.com/watch?v=dgr_LXSEM3s](https://www.youtube.com/watch?v=dgr_LXSEM3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-28 00:00:00+00:00

Taken from JRE #1727 w/Rob Kearney:
https://open.spotify.com/episode/72Q3cyEAHXmGGLefFJ40Hl?si=0135ad7cb8b94ba2

## Rob Kearney Tore His Tricep Attempting Log Press Record
 - [https://www.youtube.com/watch?v=lMhT57Xv8aA](https://www.youtube.com/watch?v=lMhT57Xv8aA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-28 00:00:00+00:00

Taken from JRE #1727 w/Rob Kearney:
https://open.spotify.com/episode/72Q3cyEAHXmGGLefFJ40Hl?si=0135ad7cb8b94ba2

## Chuck Palahniuk Shares the Strange Story of His Father's Murder
 - [https://www.youtube.com/watch?v=cMB46z1Xmuc](https://www.youtube.com/watch?v=cMB46z1Xmuc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-27 00:00:00+00:00

Taken from JRE #1726 w/Chuck Palahniuk:
https://open.spotify.com/episode/6xNtQndjzyvEaoHl6lHT7V?si=c4ebb1a427bb4c34

## Why Chuck Palahniuk Enjoys Making People Uncomfortable
 - [https://www.youtube.com/watch?v=ISksEoh-_9A](https://www.youtube.com/watch?v=ISksEoh-_9A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-10-27 00:00:00+00:00

Taken from JRE #1726 w/Chuck Palahniuk:
https://open.spotify.com/episode/6xNtQndjzyvEaoHl6lHT7V?si=c4ebb1a427bb4c34

