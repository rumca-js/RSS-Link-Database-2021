# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Rekonstrukcja rządu, czyli rotacja miernot
 - [https://www.youtube.com/watch?v=SFaDhLTmhBg](https://www.youtube.com/watch?v=SFaDhLTmhBg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-10-28 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3nGrThg
2. https://bit.ly/3BjDasJ
3. https://bit.ly/3bhJcj6
4. https://bit.ly/3BiNgdy
5. https://bit.ly/3vSNneJ
6. https://bit.ly/2ZEL96T
7. https://bit.ly/3jKIcJ5
8. https://bit.ly/31cGbyQ
9. https://bit.ly/2XSKqy8
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę ze strony: 
gov.pl - http://bit.ly/2lVWjQr
---------------------------------------------------------------
💡 Tagi: #polityka #PiS #rząd
--------------------------------------------------------------

## ID2020: Szczepienia punktem wejścia dla tożsamości cyfrowej!
 - [https://www.youtube.com/watch?v=LgTe8cGO-YE](https://www.youtube.com/watch?v=LgTe8cGO-YE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-10-27 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3CnGeFB
2. https://go.nature.com/3vOh2FK
3. https://bit.ly/3cnWVFd
4. https://bit.ly/3Bl0aI1
5. https://bit.ly/3vOhfsw
6. https://bit.ly/2SFFQRs
7. https://bit.ly/3tOih6N
---------------------------------------------------------------
💡 Tagi: #id2020 #szczepionki
--------------------------------------------------------------

