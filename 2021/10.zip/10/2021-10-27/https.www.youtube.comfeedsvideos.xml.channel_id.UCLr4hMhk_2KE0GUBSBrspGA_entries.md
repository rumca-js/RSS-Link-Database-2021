# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## DJI Action 2 i DJI Mic - Zabawki czy narzędzia?
 - [https://www.youtube.com/watch?v=jkB2BkrjOTc](https://www.youtube.com/watch?v=jkB2BkrjOTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-10-28 00:00:00+00:00

DJI Action 2 -  https://dji-ars.pl/dji-action-2.html
DJI Mic - będzie dostępny od grudnia
GoPro 10 -  https://www.gohero.pl/kamera-gopro-hero-10-black 
Rode Wireless - https://bit.ly/3CqupP9

W odcinku:
00:00 Wstęp
00:14 Masowe kupowanie elektroniki
00:34 Sprzęt elektroniczny- narzędzia, a nie zabawki
00:44 Nowe narzędzia od DJI dla profesjonalistów
01:55 DJI Action 2 – modułowa kamera sportowa
02:06 Moduły kamery
02:46 Możliwości nagrywania
03:12 Opcje noszenia kamery
03:42 Dodatkowa bateria i slot na karty microSD
04:18 Elementy do montażu: przyssawka
05:32 Podsumowanie i opinia
05:44 Matryce kamer sportowych - tajemnica ładnych filmów z GOPro
06:42 DJI Action 2 vs. GoPro
07:17 Czy kamera od DJI to prawdziwy Action Cam?
08:01 Nagrzewanie się kamery
08:26 Rada dla DJI
08:42 Cena
08:59 Mikrofony w smartfonach
10:19 Test: mikrofon kierunkowy vs mikrofon iPhone vs DJI Mic
11:36 Test zasięgu mikrofonu DJI
12:03 DJI Mic vs Inne mikrofony do smartfonów
12:32 Podłączenie mikroportów do aparatu
13:36 Czy i do czego potrzebny jest DJI Mic?
14:52 Opinia i podsumowanie o narzędziach od DJI
15:25 Podsumowanie
15:36 Pożegnanie
16:06 Dopowiedzenie: Czy będzie porównanie DJI Mic do RODE Wireless Go 2?
16:23 Pożegnanie nr 2: Cześć!

## Dla kogo są AirPods 3?
 - [https://www.youtube.com/watch?v=4yAjjtBCNB0](https://www.youtube.com/watch?v=4yAjjtBCNB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-10-27 00:00:00+00:00

Apple wypuściło nowe słuchawki nie pro. Czy są lepsze od starych pro? Nie. Czy są tańsze? Nie. Ale może to się z czasem zmieni ;) Ceny nowych i starych (ceneo): 
AirPods 3 - https://bit.ly/3Cki52I
AirPods Pro - https://bit.ly/3BlEdsm

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Recenzja z Instagrama
00:26 Co kupić? AirPods Pro czy AirPods 3?
00:56 Pytania, na które odpowie recenzja
01:20 Porównanie słuchawek dokanałowych i dousznych: gumki i aktywna redukcja szumu
03:23 Czy brzmią lepiej niż AirPods 2 GEN?
03:41 Mikrofony: AirPods 3 vs AirPods Pro vs AirPods 2 GEN
04:52 Ceny słuchawek
05:08 Wnioski
05:21 Dopasowanie do uszu
05:32 Test Patrycji – wypadanie z uszu
06:09 Zapowiedź filmu z nowymi gadżetami od DJI
06:34 Pożegnanie

