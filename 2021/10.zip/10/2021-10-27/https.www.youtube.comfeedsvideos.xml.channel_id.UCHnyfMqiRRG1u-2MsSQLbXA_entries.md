# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## I Rented A Helicopter To Settle A Physics Debate
 - [https://www.youtube.com/watch?v=q-_7y0WUnW4](https://www.youtube.com/watch?v=q-_7y0WUnW4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-10-27 00:00:00+00:00

The story of a controversial physics question on the qualifying exam for the 2014 US Physics Olympiad team. How does a uniform cable beneath a helicopter hang? Visit https://SimpliSafe.com/veritasium to learn more and to get at least 30% off your SimpliSafe security system! Thanks to SimpliSafe for sponsoring a portion of this video.

Thanks to Scott Smith and the Perris Valley Airport for hosting us. You can follow their social media @skydive_perris and learn more about them at https://skydiveperris.com/
Thanks to Craig Hosking for being our expert helicopter pilot.
Thanks to Professor Paul Stanley for the interview and for writing such an interesting question.

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
References:
The Exam — https://ve42.co/AAPT2014Exam
The Solution — https://ve42.co/AAPT2014Solutions

 ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Special thanks to Patreon supporters: S S, Andrew, Benedikt Heinen, Diffbot, Micah Mangione, MJP, Gnare, Dave Kircher, Edward Larsen, Burt Humburg, Blake Byers, Dumky, Evgeny Skvortsov, Meekay, Bill Linder, Paul Peijzel, Mac Malkawi, Michael Schneider, Big Badaboom, Ludovic Robillard, jim buckmaster, Juan Benet, Ruslan Khroma, Robert Blum, Richard Sundvall, Lee Redden, Vincent, Marinus Kuivenhoven, Alfred Wallace, Clayton Greenwell, Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Written by Derek Muller, Emily Zhang, and Petr Lebedev
Filmed by Derek Muller, Trenton Oliver, and Emily Zhang
Edited by Trenton Oliver
Animation by Mike Radjabov
Music from Epidemic Sounds
Additional video supplied by Getty Images
Produced by Derek Muller, Petr Lebedev, and Emily Zhang

