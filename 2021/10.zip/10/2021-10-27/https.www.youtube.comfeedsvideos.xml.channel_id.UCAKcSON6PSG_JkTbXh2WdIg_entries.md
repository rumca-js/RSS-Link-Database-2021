# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Lala Lala - three songs for The Current (2021)
 - [https://www.youtube.com/watch?v=wnlvgNB6So8](https://www.youtube.com/watch?v=wnlvgNB6So8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-28 00:00:00+00:00

Following the release of 'I Want The Door To Open,' on  @hardlyartrecords  Lillie West, frontperson of Chicago's Lala Lala, performed tracks from the new record. Check out Lala Lala's full session with Zeke here: https://youtu.be/hMg7DPULTeg

Songs Played:
0:01 "Color of the Pool"
2:28 "Prove It"
5:06 "Diver"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits:
Host - Zeke
Guest - Lillie West
Technical Director - Erik Stromstad
Producers - Jesse Wiza, Derrick Stevens
Music Video Director - Max Moore
Director's Assistant -  Christian Heinzel
Music Audio Engineer - Dave Vettraino

## Sylvan Esso - three songs for The Current (2020)
 - [https://www.youtube.com/watch?v=FTYROPxGa2A](https://www.youtube.com/watch?v=FTYROPxGa2A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-27 00:00:00+00:00

On Tuesday and Wednesday, Oct. 26 and 27, 2021, Sylvan Esso are playing two nights in a row at the Palace Theatre in St. Paul. One year ago, it was quite a different story as touring was not possible for musicians. Ever innovative, Sylvan Esso recorded a performance, specially for The Current, right in their home studio in Durham, N.C., in August 2020. The three-song set includes a track from each of Sylvan Esso's albums to date, starting with a track from 2020's "Free Love" before tracks from their 2014 self-titled release and 2017's "What Now." 

SONGS PERFORMED
0:00 "Ferris Wheel"
3:14 "Coffee"
7:39 "Radio"

PERSONNEL
Amelia Meath – vocals
Nick Sanborn – keys, beats

FIND MORE:
2014 studio session: https://www.thecurrent.org/amp/story/2014/07/28/sylvan-esso-perform-in-the-current-studio
2018 concert review: https://www.thecurrent.org/feature/2018/07/review-and-photos-sylvan-esso-spark-a-surly-dance-party-in-minneapolis
2020 virtual session:
https://www.thecurrent.org/feature/2020/08/18/virtual-session-sylvan-esso

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#sylvanesso

