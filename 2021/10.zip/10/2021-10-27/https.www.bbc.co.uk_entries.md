## ‘I left university and adopted my brother and sister’ - BBC News
 - [https://www.bbc.co.uk/news/stories-59009682](https://www.bbc.co.uk/news/stories-59009682)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-10-27 16:45:18.735504+00:00

When Jemma Bere’s family was in crisis, she made a split-second decision that changed the trajectory of her life.

## Tech giants try distancing themselves from Facebook - BBC News
 - [https://www.bbc.co.uk/news/technology-59065666](https://www.bbc.co.uk/news/technology-59065666)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-10-27 16:29:52.803468+00:00

TikTok, Snapchat and YouTube are facing claims they are failing to protect children.

