# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## The Nightmare before Halloween (HOT-TOPIC parody)
 - [https://www.youtube.com/watch?v=K4qOkOxa61g](https://www.youtube.com/watch?v=K4qOkOxa61g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-10-28 00:00:00+00:00

Install Raid for Free ✅ IOS/ANDROID/PC: https://clcr.me/Flashgitz_Raid_Oct and get a special starter pack 💥 Available only for the next 30 days https://clcr.me/Flashgitz_Raid_Oct

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

MudRoom CG Team ►
https://www.youtube.com/c/Mudroom

Jack G - Modeling, Animation, Texturing, Lighting - https://www.youtube.com/c/PotatoManng/

Anthony S - Surfacing - https://www.youtube.com/c/cusey 

Lucas S - Rigging, Animation - https://www.instagram.com/lm.santos/  

Zack M - Modeling, Effects - https://www.instagram.com/mini0h/ 

Ray K - Animation, Layout, Modeling - https://twitter.com/Techno_Tiki

Jacob T - Animation - https://twitter.com/Jazzmasta_J 

Geoff R - Animation - https://twitter.com/houndkidz 

Natalie J - Animation

Gui V - Animation -  https://gui-at.tumblr.com/anim 

Emily G - Animation 

2D Tree Art ►  
Naav Draws https://www.instagram.com/naav_draws/

Music ►
Zach Heyde https://youtu.be/9MvTtuFZK-E

Sound ► 
Justin Greger

VO ► 

Narrator - Ricepirate

Trevor Clark - Cupid

Meatcanyon - 4th of July Rifle

Don - Jack Skellington

Tom - Thanksgiving Turkey

Ad Compositing ► 
Oddest of the Odd

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

