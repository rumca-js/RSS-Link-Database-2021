# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Production Hell - Batwoman
 - [https://www.youtube.com/watch?v=r8wNWO-nBHY](https://www.youtube.com/watch?v=r8wNWO-nBHY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-10-27 00:00:00+00:00

The more we hear about the arguments, clashes, accidents and accusations going on behind the scenes of Batwoman, the more of a disaster this show seems to be. Join me as I delve deep into the murky world of the CW's Batwoman.

