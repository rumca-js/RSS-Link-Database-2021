# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Finding Hidden Startup Programs in Windows: Ultimate Guide
 - [https://www.youtube.com/watch?v=sUXcMaP6wRQ](https://www.youtube.com/watch?v=sUXcMaP6wRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-10-09 00:00:00+00:00

Sponsored: The first 100 people to go to http://blinkist.com/ThioJoe get unlimited access for 1 week to try it out! You’ll also get 25% off if you want the full membership.

Windows Sysinternals: https://docs.microsoft.com/en-us/sysinternals/
The Sysinternals live shortcut:  \\live.sysinternals.com@SSL\DavWWWRoot

▼ Time Stamps: ▼
0:00 - Intro
0:45 - Task Manager
2:26 - Startup Folders
3:48 - Truly Outstanding Message
5:03 - Registry Entries
5:52 - Services
7:35 - Task Scheduler
8:09 - Autoruns: What is it? + WARNING
9:19 - How to Get Autoruns
10:36 - Autoruns: Basics, Logon, Scheduled Tasks
12:44 - Autoruns: Services
15:16 - Autoruns: Drivers, Codecs, Office, IE, Explorer
16:18 - Autoruns: More Features & Usage
17:26 - Autoruns: Scanning with VirusTotal
19:19 - Autoruns: Verified Publishers

