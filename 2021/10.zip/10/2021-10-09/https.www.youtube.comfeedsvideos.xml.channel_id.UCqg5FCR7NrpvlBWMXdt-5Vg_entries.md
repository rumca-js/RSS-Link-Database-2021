# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Far Cry 6 Is Ubisoft's Open World Formula At Its Worst | The Escapist Show
 - [https://www.youtube.com/watch?v=IB9_H0aRbQc](https://www.youtube.com/watch?v=IB9_H0aRbQc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-10 00:00:00+00:00

This week on The Escapist Show, Jack's playing Tails of Iron, Nick's finally tired of Far Cry and, well, that's it.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps
The games we've been playing - 0:00
AAA fatigue - 9:55


---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Nickelodeon All-Star Brawl | Review in 3 Minutes +
 - [https://www.youtube.com/watch?v=Eh_0o0Lyuz4](https://www.youtube.com/watch?v=Eh_0o0Lyuz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-09 00:00:00+00:00

KC Nwosu reviews Nickelodeon All-Star Brawl, developed by Ludosity and Fair Play Labs

Nickelodeon All-Star Brawl on Steam: https://store.steampowered.com/app/1414850/Nickelodeon_AllStar_Brawl/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Last Duel Proves Ridley Scott Is Still Sharp | Review
 - [https://www.youtube.com/watch?v=9mu76qTtYoE](https://www.youtube.com/watch?v=9mu76qTtYoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-09 00:00:00+00:00

Darren Mooney reviews The Last Duel for The Escapist.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

