# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Thriller film sinks teeth into Hungary's opposition
 - [https://www.bbc.co.uk/news/world-europe-58819841?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58819841?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:23:26+00:00

It is a film perfectly timed for Viktor Orban's ruling party that could harm the opposition.

## Should sex offenders' voices ever be heard?
 - [https://www.bbc.co.uk/news/uk-england-bristol-57075844?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-57075844?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:22:16+00:00

Audio clips from child sex offenders are released by police to deter others following in their path.

## Covid-19 vaccines: Has China made more than other countries combined?
 - [https://www.bbc.co.uk/news/58808889?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/58808889?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:20:47+00:00

China says it's provided more than half of all vaccines administered around the world so far.

## Newcastle United takeover: What is PIF, the main owner of the club?
 - [https://www.bbc.co.uk/news/newsbeat-58842557?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-58842557?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:20:05+00:00

Saudi Arabia's Public Investment Fund owns 80% of Newcastle after a high-profile takeover.

## Biodiversity loss risks 'ecological meltdown' - scientists
 - [https://www.bbc.co.uk/news/science-environment-58859105?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-58859105?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:12:51+00:00

The UK has an average of only 53% of its biodiversity left, well below the global average, study shows.

## Your pictures on the theme of 'derelict'
 - [https://www.bbc.co.uk/news/in-pictures-58841907?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-58841907?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:11:30+00:00

A selection of striking images from our readers around the world.

## The 25-year-old who's been a clown for two decades
 - [https://www.bbc.co.uk/news/uk-england-kent-58808579?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-58808579?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:04:29+00:00

Lucien Santus started performing as a clown when he was four years old.

## 'Why drilling holes in fences can save hedgehogs'
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-58664344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-58664344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:03:50+00:00

Jennifer Manning-Ohren is turning her community into a highway to help the endangered creatures.

## Oh Wonder: We spent our honeymoon covered in cockroaches in a burning building
 - [https://www.bbc.co.uk/news/entertainment-arts-58842667?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58842667?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 23:02:37+00:00

The indie-pop duo broke up while recording their fourth album, and things only got weirder after that.

## Nobel Peace Prize 'for Russian journalists who lost their lives'
 - [https://www.bbc.co.uk/news/world-europe-58855706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58855706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 13:58:08+00:00

Dmitry Muratov dedicates the Nobel Peace Prize to Russian journalists killed in the line of duty.

## ICYMI: Pooches, puppets and paintings
 - [https://www.bbc.co.uk/news/world-58849648?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-58849648?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 12:40:08+00:00

Here's a look at some of the stories you may have missed this week.

## Gas prices: Energy price cap call for small and medium firms
 - [https://www.bbc.co.uk/news/business-58852612?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-58852612?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 11:48:30+00:00

Businesses say the UK has reached a crisis point over the price of gas and are calling for support.

## Chris Packham calls on Royal Family to rewild estates
 - [https://www.bbc.co.uk/news/uk-58855168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58855168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 11:33:00+00:00

A petition urges the royals to conserve nature and reintroduce animals on their estates.

## Mary Phillip: First black woman to captain England now a successful men's coach
 - [https://www.bbc.co.uk/sport/av/football/58844993?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/58844993?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 11:17:49+00:00

Mary Phillip - the first black woman to captain England - talks to BBC Sport about being a history-maker as a player and coach.

## James Bond actor Daniel Craig gives £10k to 'Three Dads Walking'
 - [https://www.bbc.co.uk/news/uk-england-cumbria-58829618?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cumbria-58829618?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 10:48:02+00:00

Three fathers doing a charity walk receive a donation from film star Daniel Craig as they set out.

## Sarah Everard: BT 888 phone service floated to protect lone women
 - [https://www.bbc.co.uk/news/uk-58854578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58854578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 10:44:44+00:00

The service would track users and trigger an alert if they did not reach their destination.

## Emma Raducanu: Briton loses first match since US Open win
 - [https://www.bbc.co.uk/sport/av/tennis/58855888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/58855888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 09:42:51+00:00

Emma Raducanu loses her first match since her US Open triumph, losing to Belarus' Aliaksandra Sasnovich in straight sets in the second round at Indian Wells.

## More than 500 Covid cases linked to TRNSMT festival
 - [https://www.bbc.co.uk/news/uk-scotland-58847481?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-58847481?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 08:41:32+00:00

Public Health Scotland says 551 people who tested positive for the virus were at the festival around the time of their illness.

## Luxury student complex in Glasgow 'unfinished and filthy'
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-58849933?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-58849933?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 08:37:24+00:00

Students in Glasgow have complained to the provider about holes in floors, construction dust and flooding.

## Tyson Fury v Deontay Wilder III: 'I'll put him in the infirmary!' - insults fly at weigh-in
 - [https://www.bbc.co.uk/sport/av/boxing/58855152?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/boxing/58855152?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 08:19:31+00:00

Tyson Fury and Deontay Wilder exchange heated words at the weigh-in before their third world heavyweight title fight.

## China-Taiwan tensions: Xi Jinping says 'reunification' must be fulfilled
 - [https://www.bbc.co.uk/news/world-asia-china-58854081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-58854081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 07:53:19+00:00

Taiwan dismisses the Chinese leader's remarks, saying its future lies in the hands of its people.

## Emma Raducanu: US Open champion beaten in first match since Grand Slam win
 - [https://www.bbc.co.uk/sport/tennis/58852217?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/58852217?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 07:30:08+00:00

Britain's Emma Raducanu loses on her return to court for the first time since her US Open triumph.

## Finn's Law: Five years after stabbing, ex-police dog is still campaigning
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-58823324?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-58823324?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 07:14:41+00:00

Five years on from an attack that led to a law change, former police dog Finn is still campaigning.

## How Scotland can beat Israel... by a man who helped do it last time
 - [https://www.bbc.co.uk/sport/football/58821813?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58821813?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 07:03:55+00:00

Former Scotland forward James McFadden details how the current side should approach their crucial World Cup qualifier against Israel.

## Murray - reunited with shoes - into second round at Indian Wells
 - [https://www.bbc.co.uk/sport/tennis/58854297?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/58854297?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 06:51:05+00:00

Andy Murray reached the second round of the Indian Wells Masters with a 6-3 6-2 win over Frenchman Adrian Mannarino.

## Texas abortion: US appeals court reinstates near total ban
 - [https://www.bbc.co.uk/news/world-us-canada-58853859?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-58853859?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 06:38:07+00:00

It comes two days after a lower court blocked the law, which bans abortions at six weeks of pregnancy.

## Covid-19: Europe's Covid hotspot and GP appointments not for all
 - [https://www.bbc.co.uk/news/uk-58852586?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58852586?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 05:47:54+00:00

Five things you need to know about the coronavirus pandemic this Saturday.

## Elise Wortley: 'Anything that makes you feel brave is great'
 - [https://www.bbc.co.uk/news/uk-england-london-58834868?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-58834868?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 05:17:26+00:00

Elise Wortley was inspired by historical female explorers to bring their journeys to life.

## WSL: Manchester derby is 'super special', says Man City's Janine Beckie
 - [https://www.bbc.co.uk/sport/av/football/58834302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/58834302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 04:48:20+00:00

Manchester City's Janine Beckie talks Olympic success, the WSL, and a "super special" Manchester derby.

## The Papers: 'Push to scrap free Covid tests', and months of 'discontent'
 - [https://www.bbc.co.uk/news/blogs-the-papers-58852156?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-58852156?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 04:17:01+00:00

The fuel, gas and supply chain crises continue to feature on several of Saturday's front pages.

## Havana syndrome: Berlin police probe cases at US embassy
 - [https://www.bbc.co.uk/news/world-europe-58852437?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58852437?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 01:14:18+00:00

Police say the investigation into the "alleged sonic weapon attack" began in August.

## Nadhim Zahawi vows to tackle persistent pupil absences 'head on'
 - [https://www.bbc.co.uk/news/education-58851625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-58851625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-10-09 00:19:21+00:00

Disadvantaged children miss out most from not being in school, the education secretary will say.

