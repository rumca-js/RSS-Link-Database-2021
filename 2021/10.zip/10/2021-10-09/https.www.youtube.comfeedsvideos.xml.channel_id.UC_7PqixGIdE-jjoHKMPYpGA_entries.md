# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Śmierć na dnie Bałtyku?
 - [https://www.youtube.com/watch?v=K9U1-_JD9BM](https://www.youtube.com/watch?v=K9U1-_JD9BM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-10-10 00:00:00+00:00

📚 Kup moją najnowszą książkę ► https://siedem.alt.pl
Do 9 listopada darmowa wysyłka na terenie Polski

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
✍ Petycja ► https://www.petycjeonline.com/bron_w_baltyku

📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

3 października 2020 roku udałem się do Trójmiasta, żeby wziąć udział w pokazowym rejsie badawczym organizowanym przez Instytut Oceanologii PAN. Jeżeli mam być szczery - byłem przekonany, że nie dowiem się zbyt wielu rzeczy. Miałem za sobą przecież prawie godzinny film o broni chemicznej. Co nowego mogło dać zobaczenie, jak szuka się broni chemicznej. 12 miesięcy później kończyłem robić ten film. Film, który (mam wrażenie) tylko powierzchownie porusza ten niezmiernie istotny temat.

===
Rozkład jazdy:

0:00 Dużo ton
2:42 Od początku
4:50 Oto "bohater"
7:21 Po pierwszej wielkiej wojnie
9:44 Aliancki incydent
11:33 Po drugiej wielkiej wojnie
18:52 Ocena zagrożenia
26:49 Porozmawiajmy o Bałtyku
43:28 Co można znaleźć?
49:56 Nie tylko śmierć
52:42 Woda na pustyni
59:35 Polski wkład 
1:07:15 Nie tylko chemiczna
1:13:20 Co teraz?
1:24:44 To zależy...
1:37:12 Trochę od nas...

===
Źródła (wybrane):

M. Czub i in. - Deep sea habitats in the chemical warfare dumping areas of the Baltic Sea
M. Reckermann - Human impacts and their interactions in the Baltic Sea region
P. Vanninen i in. - Exposure status of sea-dumped chemical warfare agents in the Baltic Sea
T. Lang i in. - The health status of fish and benthos communities in chemical munitions dumpsites in the Baltic Sea
T. Brzeziński i in. - The effects of chemical warfare agent Clark I on the life histories and stable isotopes composition of Daphnia magna
K. W. Zieliński - Patologia obrażeń i schorzeń wywołanych współczesną bronią w działaniach wojennych i terrorystycznych
J. K. Piotrowski - Podstawy toksykologii
A. Kołodziejczyk - Naturalne związki organiczne
J. Bełdowski i in. - Best practices in monitoring
A. Beck i in. - In Situ Measurements of Explosive Compound Dissolution Fluxes from Exposed Munition Material in the Baltic Sea
M. Czub i in. - Acute aquatic toxicity of sulfur mustard and its degradation products to Daphnia magna
A. Szarejko i in. - The Baltic Sea as a dumping site of chemical munitions and chemical warfare agents
R. Schuster i in. - Exposure to dissolved TNT causes multilevel biological effects in Baltic mussels (Mytilus spp.)
M. Czub i in. - Acute aquatic toxicity of arsenic-based chemical warfare agents to Daphnia magna
https://helcom.fi/media/documents/Dumped-chemical-munitions-in-the-Baltic-Sea.pdf
http://www.coastalwiki.org/wiki/Chemical_and_conventional_ammunition_in_the_Baltic_Sea

