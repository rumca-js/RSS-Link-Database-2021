# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Surface Laptop Studio Review Ended in DISASTER
 - [https://www.youtube.com/watch?v=2Wwbo731jOQ](https://www.youtube.com/watch?v=2Wwbo731jOQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-10 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Get 15% off the ModMic Wireless and other ModMic products at https://antlionaudio.com/linustalktips

The Surface Laptop Studio is a new premium windows machine from Microsoft. Too bad they didn't make it easier to open...

Discuss on the forum: https://linustechtips.com/topic/1379880-i-broke-our-surface-laptop-studio/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:59 Display and design
2:11 Trackpad, keyboard, and I/O
4:55 Performance
7:32 Pencil shavings
8:59 Aesthetics and convertibility
10:38 Speakers and webcam, wherein Linus makes a bad joke
12:16 Pricing tiers
12:45 The Teardown Experience...
14:44 Internals
17:10 Conclusion

## This Product Will Pay For Itself - Streamlocator
 - [https://www.youtube.com/watch?v=hflXH4LPVqM](https://www.youtube.com/watch?v=hflXH4LPVqM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-09 00:00:00+00:00

Win a Jackery by joining their 9th anniversary photo contest: https://www.jackery.com/pages/jackery-9th-anniversary?aff=27

Get 10% off all Jackery products on their website with code LinusTechTips:  https://www.jackery.com?aff=27

Can a Canadian company make a good streaming service product? We checked out the StreamLocator to see if it's any good for unblocking Netflix and giving you cheaper access to your favorite sportsball games, no matter where you might live.

Buy StreamLocator 
On Amazon (PAID LINK): https://geni.us/HzxD
On Newegg (PAID LINK): https://geni.us/K8QD5FC

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1379447-this-product-will-pay-for-itself/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:05 Content Access
2:05 StreamLocator
2:45 How It Works
4:15 It's Not a VPN
6:15 Ease of Use
7:20 Limitations
9:15 Conclusion
10:40 Outro

