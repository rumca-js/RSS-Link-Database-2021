# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Pabllo Vittar: Una Conversación Con Alt.Latino
 - [https://www.youtube.com/watch?v=yFXfP20sf8o](https://www.youtube.com/watch?v=yFXfP20sf8o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-10-10 00:00:00+00:00

Singer-songwriter and drag queen, Pabllo Vittar, is a 26-year-old Latin Grammy nominee, MTV EMA & MIAW Award-winner and a TIME Magazine ‘Next Generation Leader.’ Alt.Latino host Felix Contreras asks Pabllo about music, influences and the impact of being a queer Brazilian superstar.

#eltiny #nprmusic #pabllovittar

