## Why We Need to Upgrade Our Face Masks--and Where to Get Them - Scientific American
 - [https://www.scientificamerican.com/article/why-we-need-to-upgrade-our-face-masks-and-where-to-get-them/](https://www.scientificamerican.com/article/why-we-need-to-upgrade-our-face-masks-and-where-to-get-them/)
 - RSS feed: https://www.scientificamerican.com
 - date published: 2021-10-09 11:25:13.976175+00:00

High-quality respirators such as N95s and K95s are now widely available and provide the best protection against COVID, according to experts. Why aren&rsquo;t more people wearing them?

