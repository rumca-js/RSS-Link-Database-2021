# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Why Elrond is the Perfect Main Character for Rings of Power
 - [https://www.youtube.com/watch?v=E5gsqpOL_4k](https://www.youtube.com/watch?v=E5gsqpOL_4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-10-09 00:00:00+00:00

Making the case for Elrond to be the main character of the upcoming Amazon Lord of the Rings series.  In this video, I lay out five reasons I believe Elrond would be the best choice to lead the new #LOTRonPrime show!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark
Elrond - Magali Villeneuve
The Lord of Rivendell - Peet
And Maglor Took Pity Upon Them - Catherine Karina Chmiel
The Council of Elrond - Alan Lee
Elrond - Paulina Wach
Cavalier Elrond - Mellorianj
Council of War - Mellorianj
Maglor and Elrond - Jenny Dolfen
Fan Art from The Hobbit - Julie Dillon
Legolas - Gellihana Art
Lord of Rivendell - Kinko White
Maglor's Fostering - Turner Mohan
Elrond, Elros, Earendil, and Elwing - Jenny Dolfen
The Oath Has Been Awakened - Jenny Dolfen
Destiny - ilxwing
Twins of Star - Jane Doemmmmm
Elrond and Elros Sketch - Kinko White
Ereinion - Missingmymind
Elrond and Elros Tar-Minyatur - Stardust
White Ships from Valinor - Ted Nasmith
Until the world is broken and remade, Elrond and Elros - Jenny Dolfen
Armenelos - Skullb*st*rd
Numenor - Sarka Skorpikova
Fall of Numenor - Darrell Sweet
Elrond - Magali Villeneuve
Elrond with Narsil - Donato Giancola
Elrond and Gil-galad - Navy Locked
Elrond - Kimberly80
Vilya - Mellorianj
Celebrimbor - Angus McBride
Feanor - Bella Bergolts
Rivendell - Zak Seymour
In the House of Elrond - Abe Papakhian
Elrond - Alystraea
Elrond - Magali Villeneuve
Minas Tirith - Ludovic Bourgeois
Elendil the Faithful - Libra1010
Minas Tirith - Dire Impulse
Elves of the Last Alliance - Tiamat Nightmare
Gil-galad, Sauron, and Elendil - Tom Romain
Elendil and Sons - Abe Papakhian
Isildur Cuts the Ring - Denis Gordeev
One Ring to Rule Them All - Donato Giancola
Elrond and Estel - Kuliszu

#lotronprime #elrond #lordoftherings

