# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## John Prine - four live performances (2018)
 - [https://www.youtube.com/watch?v=-GVrYC_18oo](https://www.youtube.com/watch?v=-GVrYC_18oo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-09 00:00:00+00:00

This coming Sunday, October 10, is the birthdate of the great John Prine, born that date in 1946. In honor of John Prine, here are four performances by Prine that took place three months ahead of the release of his fantastic 2018 album, "The Tree of Forgiveness." These performances were recorded live in New Orleans for an episode of Live From Here in January 2018.

SONGS PERFORMED
00:00 "Humidity Built the Snowman"
02:57 "Summer's End"
06:26 "Speed of the Sound of Loneliness"
10:19 "Lonesome Friends of Science"

PERSONNEL
John Prine – vocals, guitar
Jason Wilber – guitar
Dave Jacques – bass
Chris Thile – mandolin, backing vocals (on "Speed of the Sound of Loneliness")

CREDITS
Video & Photo: Ben Miller; American Public Media
Audio: Sam Hudson; American Public Media
Production: Jeffy Hnilicka; Tom Campbell; American Public Media

FIND MORE:
2020 Radio Heartland tribute to John Prine: https://www.thecurrent.org/feature/2020/04/08/radio-heartlands-tribute-to-john-prine

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#johnprine

