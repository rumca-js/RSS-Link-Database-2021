# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## CNN panel reacts to Bill Maher's bleak 2024 election prediction
 - [https://www.cnn.com/videos/politics/2021/10/09/bill-maher-2024-election-prediction-trump-biden-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/10/09/bill-maher-2024-election-prediction-trump-biden-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-09 19:41:53+00:00

CNN panelists Alice Stewart and April Ryan discuss comedian Bill Maher's provocative election prediction.

## Madonna flashes audience on 'The Tonight Show Starring Jimmy Fallon'
 - [https://www.cnn.com/videos/business-videos/2021/10/09/madonna-flashes-fallon-tonight-show-orig-kj.cnn](https://www.cnn.com/videos/business-videos/2021/10/09/madonna-flashes-fallon-tonight-show-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-09 17:44:01+00:00

The pop icon was on Fallon's show promoting her new documentary "Madame X" when she decided to make some "good trouble."

## River of volcanic lava engulfs home
 - [https://www.cnn.com/videos/world/2021/10/09/la-palma-volcano-lava-homes-sot-nr-vpx.cnn](https://www.cnn.com/videos/world/2021/10/09/la-palma-volcano-lava-homes-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-10-09 16:26:05+00:00

Buildings near the volcano on the Spanish island of La Palma were engulfed by rivers of lava. Reuters captured video of one home surrounded by lava.

