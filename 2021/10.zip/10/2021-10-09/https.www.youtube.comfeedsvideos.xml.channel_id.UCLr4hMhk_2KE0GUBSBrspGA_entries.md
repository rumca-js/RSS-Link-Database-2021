# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Lepsze jutro było wczoraj... Tech Week.
 - [https://www.youtube.com/watch?v=tCcSA2S814I](https://www.youtube.com/watch?v=tCcSA2S814I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-10-10 00:00:00+00:00

Dziś odcinek o tym, że nie ma się za bardzo z czego cieszyć, ale też o leczeniu depresji, więc sam nie wiem, może jednak jest się z czego cieszyć? Sami musicie zdecydować. 
W odcinku jest krótkie lokowanie aplikacji ZEN. Z kodem KlawyZen możecie jej używać przez 4 miesiące za darmo: https://bit.ly/3rklh8W

Tu są moje Twittery i Instagramy:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Przeładowanie informacjami
01:03 Dobry wieczór
01:10 Patelnia na telefon
01:55 Destrukcyjny wpływ Facebooka na użytkowników
03:31 Farmy trolli
04:06 Facebook porzuca działalność na rzecz przeciwdziałania dezinformacji
05:56 Facebook traci wizerunkowo
06:20 Co robili użytkownicy Facebooka i Instagrama podczas ich awarii
06:46 Meta wszechświat Zuckerberga
07:40 Rosyjscy hakerzy atakują użytkowników Gmaila
08:01 Mi Band 6 NFC
08:30 Fragment sponsorowany – ZEN
08:42 Mi Band 6 NFC – cd.
09:00 Google przekazuje dane użytkowników na prośbę organów ścigania w USA
09:51 Google przekazuje dane osób znajdujących się w okolicy zamieszek
10:35 Jak wyleczyć depresję
11:44 Apple zarabia na grach więcej niż firmy produkujące gry
12:10 Twitch wyciekł
12:35 YouTube będzie demonetyzował treści zaprzeczające globalnemu ociepleniu
13:32 500 godzin treści co minutę – YouTube w 2019 roku
14:16 Wystawa KlawiaturART
15:15 Przedsprzedaż nowości na Znośne
15:49 Pożegnanie
15:55 Znośnego tygodnia!

I źródła:
Patelnia na smartfon: https://bit.ly/3Dq3F1e
Frances Haugen przed komisją senacką: https://youtu.be/L3cG3cLXHfk
Frances w programie 60 minut: https://youtu.be/_Lx5VmAdZSI
Fanpage chrześcijańskie prowadzone przez farmy trolli: https://bit.ly/3AxUxpo
Facebook traci wizerunkowo: https://econ.st/3FwCvrf
Gdzie byliśmy gdy nie działał FB: https://bit.ly/3iQi1QJ
Meta wszechświat Zuckerberga: https://bit.ly/3FIUrPI
14 tysięcy kont gmail na celowniku rosyjskich hackerów: https://bit.ly/3v2TFrF
Google przekazuje dane osób, które wpisywały konkretne słowa do wyszukiwarki: https://bit.ly/3p3iyCT
Google przekazuje dane osób, które znajdowały się w okolicy zamieszek: https://bit.ly/2YFZLCs
Jak wyleczyć depresję: https://bit.ly/3uVPXQI
Apple zarobiło na grach więcej niż firmy produkujące gry: https://bit.ly/3BvHExu
Twitch wyciekł: https://bit.ly/2Yz1Ct6
YouTube będzie demonetyzował filmy zaprzeczające zmianom klimatycznym: https://bit.ly/3Ao0ftW
W 2019 na YT pojawiało się 500 godzin treści co minutę: https://bit.ly/3apkJI9
Miejsce wystawy i wernisażu w Krakowie: https://goo.gl/maps/PAoR75RCPFrtFJeBA

