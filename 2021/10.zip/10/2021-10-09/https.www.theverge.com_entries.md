## Apple’s fortress of secrecy is crumbling from the inside - The Verge
 - [https://www.theverge.com/22700898/apple-company-culture-change-secrecy-employee-unrest](https://www.theverge.com/22700898/apple-company-culture-change-secrecy-employee-unrest)
 - RSS feed: https://www.theverge.com
 - date published: 2021-10-09 12:18:38.142678+00:00

Employees want to be heard. Does the company want to listen?

