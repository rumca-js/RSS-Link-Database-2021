# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## I ran across an entire CONTINENT in VR with an Omni-Direction Treadmill
 - [https://www.youtube.com/watch?v=cbZnFILO5es](https://www.youtube.com/watch?v=cbZnFILO5es)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-10-09 00:00:00+00:00

Hello! Today I challenge myself to run across the entire Skyrim map from bottom to top.. entirely in VR with an Omnidirectional Treadmill. Total distance is very approximately calculated to 13 miles, give or take a few, all in one go. This was one of the harder VR challenges I have done, especially because of the nature of a Katwalk C. The real question is, what breaks first? Me or the Omnidirectional treadmill?

My links:
 Discord.gg/Thrill
Twitch.tv/Thrilluwu
Patreon.com/Thrillseeker

