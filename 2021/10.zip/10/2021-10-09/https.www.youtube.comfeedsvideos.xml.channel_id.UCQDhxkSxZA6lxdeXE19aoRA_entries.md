# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Resurrecting This Destroyed Samsung Galaxy Tab A
 - [https://www.youtube.com/watch?v=AJatnHSRej4](https://www.youtube.com/watch?v=AJatnHSRej4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-10-09 00:00:00+00:00

Its time this Tab A3 XL saw a second life.
Skip the upgrade and take 20% off Apple Fix Kits with code SKIP20. If you already have iFixit tools, you can use the code for the part only option too! https://ifix.gd/hg-fixkits  
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Get parts, tools and repair guides at iFixit:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau

Tools I Use: https://www.hughjeffreys.com/tools
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

