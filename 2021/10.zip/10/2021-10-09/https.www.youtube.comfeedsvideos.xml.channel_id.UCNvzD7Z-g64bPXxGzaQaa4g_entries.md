# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 20 AA Games That Blew Us Away
 - [https://www.youtube.com/watch?v=qkKJmG_Tu0M](https://www.youtube.com/watch?v=qkKJmG_Tu0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-10 00:00:00+00:00

Not every good game is made by a massive studio with billions of dollars. Here are some of our favorite not quite indie games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Greedfall

Platform: PC PS4 Xbox One XSX|S PS5



Hellblade: Senua's sacrifice

Platform: PC PS4 Xbox One Switch XSX|S 



Vampyr

Platform: PC PS4 Xbox One Switch 



Mortal Shell

Platform: PC PS4 Xbox One XSX|S PS5 



Firewatch

Platform: PC PS4 Xbox One Switch Linux OS X 



The Wolf Among Us

Platform: PC PS3 PS4 PS Vita Xbox 360 Xbox One OS X 



Stardew Valley

Platform: PC PS4 Xbox One Switch PS Vita Linux 



Undertale

Platform: PC PS4 PS Vita Switch Xbox One Linux OS X



Outerwilds

Platform: PC Xbox One Switch PS4 



What Remains of Edith Finch

Platform: PC PS4 Xbox One Switch 



Soma

Platform: PC PS4 Xbox One Linux OS X 



Pacify

Platform: PC 



Kingdom Come: Deliverance

Platform: PC PS4 Xbox One Switch Amazon Luna 



Divinity: Original Sin 2

Platform: PC PS4 Switch Xbox One 



Cuphead

Platform: PC PS4 Switch Xbox One  



A Plague Tale Innocence

Platform: PC PS4 PS5 Xbox One XSX|S Switch Amazon Luna 



GRAVITY RUSH 2

Platform: PS4 



HOLLOW KNIGHT

Platform: PC PS4 Xbox One Switch Linux 



Hades

Platform: PC PS4 PS5 Xbox One XSX|S Switch 



It Takes Two + A Way Out

Platform: PC PS4 PS5 Xbox One XSX|S + PC PS4 Xbox One 



BONUS

Tormented Souls 

Platform: PS4 PS5 XSX|S Switch PC 



Teardown

Platform: PC 

0:00 INTRO 
0:17 Greedfall
1:27 Hellblade: Senua's sacrifice
2:18 Vampyr 
3:15 Mortal Shell
4:13 Firewatch
5:18 The Wolf Among Us
6:11 Stardew Valley
6:53 Undertale
7:41 Outerwilds
8:22 What Remains of Edith Finch
9:24 Soma
10:22 Pacify
11:33 Kingdom Come: Deliverance
12:14 Divinity: Original Sin 2
12:53 Cuphead
13:40 A Plague Tale Innocence
14:28 GRAVITY RUSH 2
15:13 HOLLOW KNIGHT
15:57 Hades
16:45 It Takes Two + A Way Out
17:28 Bonus

## Metroid Dread - Before You Buy
 - [https://www.youtube.com/watch?v=m7-dGfSNz-c](https://www.youtube.com/watch?v=m7-dGfSNz-c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-09 00:00:00+00:00

Metroid Dread (Nintendo Switch) brings awesome controls, fun encounters, and a lot of challenge to the classic formula. Here's what we think of it. 
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Metroid: https://amzn.to/3BrMf3O

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## Nintendo Switch OLED - Before You Buy
 - [https://www.youtube.com/watch?v=EWdkKY9mdGo](https://www.youtube.com/watch?v=EWdkKY9mdGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-09 00:00:00+00:00

The new Nintendo Switch with an OLED screen is here! We've got some quick first impressions on this slight upgrade.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Switch: https://amzn.to/3iGkSeQ

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#SwitchOLED #Nintendo

