# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Projekt "Rejestr Samolubności" zrodzi świadomość roju!
 - [https://www.youtube.com/watch?v=CrWKCAuJZgA](https://www.youtube.com/watch?v=CrWKCAuJZgA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-10-10 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://politi.co/3vatxeN
2. https://bit.ly/3Bw1l8c
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę ze strony / autorstwa: 
mcptato / deviantart.com
https://bit.ly/3iOsAnh
---------------------------------------------------------------
💡 Tagi: #AI
--------------------------------------------------------------

## Polexit jako oręż polityczny. Porównanie wyroków trybunałów polskiego i niemieckiego.
 - [https://www.youtube.com/watch?v=4bPki3iWOfg](https://www.youtube.com/watch?v=4bPki3iWOfg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-10-09 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://politi.co/3vatxeN
2. https://bit.ly/3Bw1l8c
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę ze strony / autorstwa: 
wikipedia.org / Stanisław Loba 
https://bit.ly/3mDjYkt
---
CC BY-SA 4.0
http://bit.ly/33UhhQU
---------------------------------------------------------------
💡 Tagi: #polexit #UE #polityka
--------------------------------------------------------------

