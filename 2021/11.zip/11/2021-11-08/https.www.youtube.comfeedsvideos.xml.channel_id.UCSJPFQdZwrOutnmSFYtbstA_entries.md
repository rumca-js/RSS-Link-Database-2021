# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Eternals - A Boring, Unfocussed Disaster
 - [https://www.youtube.com/watch?v=oGyVuRhak38](https://www.youtube.com/watch?v=oGyVuRhak38)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-11-08 00:00:00+00:00

The Eternals turned out to be just as bad as everyone predicted, and its easy to see why. Join me as I break down this stinker.

