# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Alexandre Ekian - KGB partial OST (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=U1spp__eC4k](https://www.youtube.com/watch?v=U1spp__eC4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-11-14 00:00:00+00:00

3 tracks from game "KGB" (Amiga, 1992) by Alexandre Ekian. Track "Paradise", which was way too short to bother, was left out.

00:00 Exxolove (main theme)
05:27 Gorbi
11:24 Kursk

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## Amiga music: Mygg times four (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=nlrXiPETWFA](https://www.youtube.com/watch?v=nlrXiPETWFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-11-14 00:00:00+00:00

A collection of 4 tracks from Mygg/Insane (Jonas Sarvik).

00:00 Dalslands Rytmer 3.1 (1st at Compusphere 2016)
03:14 Sound Experiment (3rd at Datastorm 2017 tracked)
06:42 Ain't No Sidechain
10:12 20 Rushed kB (6th at Datastorm 2017 chip)
      
Art in order of appearance:

1. And If I Fail? by Nero/Ethic (1996, X-Files 14 version)
2. ZZ Madman by Fairfax/Andromeda (1st at The Gathering 1994)
3. Skelletons by Ra/Dreamdealers^Sanity (5th at 680xx Convention 1993)
4. Turmoil Dragon by Cougar/Sanity (1991)

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

