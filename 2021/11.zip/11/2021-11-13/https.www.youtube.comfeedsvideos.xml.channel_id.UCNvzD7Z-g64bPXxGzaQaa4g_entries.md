# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Things RPGs NEED TO Stop Doing Immediately
 - [https://www.youtube.com/watch?v=KS0CeNhQ070](https://www.youtube.com/watch?v=KS0CeNhQ070)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-14 00:00:00+00:00

Some RPG creators do things we don't like. Here are some problems we'd prefer our RPGs avoid.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Bright Memory Infinite - Before You Buy
 - [https://www.youtube.com/watch?v=RyttxShAhLo](https://www.youtube.com/watch?v=RyttxShAhLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-13 00:00:00+00:00

Bright Memory Infinite (PC, Xbox Series X/S) is a brief first person shooter experience with crazy visuals and cool gameplay. Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

