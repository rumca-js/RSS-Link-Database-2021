# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Josh Ritter - three songs for The Current (2020)
 - [https://www.youtube.com/watch?v=EJ8oZAYy0U4](https://www.youtube.com/watch?v=EJ8oZAYy0U4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-13 00:00:00+00:00

One year ago, Josh Ritter connected with The Current from his home in Woodstock, N.Y., to play a couple songs from his 2020 EP, "See Here, I Have Built You a Mansion," as well as a cut from his 2006 release, "The Animal Years." Watch the three performances from that session, which was hosted by Jade.

SONGS PERFORMED
0:00 "Miles Away"
3:15 "Time Is Wasting"
5:54 "Girl In The War"

PERSONNEL
Josh Ritter – vocals, guitar

CREDITS
Host: Jade
Producer: Jesse Wiza
Technical Director: Eric Romani

FIND MORE:
2010 studio session: https://www.thecurrent.org/feature/2010/07/21/josh_ritter
2013 studio session:
https://www.thecurrent.org/feature/2013/04/25/josh-ritter
2017 MicroShow:
https://www.thecurrent.org/feature/2017/10/09/microshow-josh-ritter-showcases-songs-from-gathering
2020 virtual session: https://www.thecurrent.org/feature/2020/11/12/josh-ritter-virtual-session

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#joshritter

