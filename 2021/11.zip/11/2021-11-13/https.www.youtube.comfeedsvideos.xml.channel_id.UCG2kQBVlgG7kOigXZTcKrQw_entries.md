# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Sardynia ☀️ Zatoki, groty i te plaże! + start w triathlonie IRONMAN🏊🏻🚴🏿🏃‍♀️
 - [https://www.youtube.com/watch?v=yt6WTR5cjTg](https://www.youtube.com/watch?v=yt6WTR5cjTg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-11-14 00:00:00+00:00

Powrót po latach na Sardynię całkiem udany! Nie był to typowy wyjazd, bo pierwszy raz połączyliśmy podróż z zawodami IronMana. Nie tylko udało się zobaczyć całkiem sporo ciekawych miejsc na Sardynii, nie tylko co nieco pozwiedzać, ale też się zmęczyć w triathlonie. Przynajmniej Marta :) 

Mamy nadzieję, że taki niecodzienny film również Wam przypadnie do gustu.  Dajcie znać czy widzielibyście w przyszłości jeszcze jakieś IronManowe podróże :D

Z ciekawych miejsc na Sardynii, które udało nam się odwiedzić podczas tego tygodniowego wypadu do południe Sardynii, gdzie odbywały się zawody, ale także zachód i przede wszystkim wschód, gdzie wpadliśmy do zatoki Orosei i odwiedziliśmy dwie kultowe plaże jak Cala Luna i Cala Goloritze


Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Muzyka Artlist oraz Nevaeh https://soundcloud.com/nevaxh

Rozdziały:
00:00 Witamy na Sardynii
03:13 plaża Goloritze
04:30 domy po 1 euro
06:06 plaża Cala Luna
09:28 IRONMAN

