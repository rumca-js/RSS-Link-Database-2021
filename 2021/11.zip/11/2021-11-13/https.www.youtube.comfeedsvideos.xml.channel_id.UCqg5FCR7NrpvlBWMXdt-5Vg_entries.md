# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Let's Check Out Elden Ring with Nick and JM8
 - [https://www.youtube.com/watch?v=qe5JkOyih_M](https://www.youtube.com/watch?v=qe5JkOyih_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-11-14 00:00:00+00:00

It's the final day of the Elden Ring closed network test so let's give it a whirl for a couple hours.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Experiencing Resident Evil 4 For the First Time...and in VR
 - [https://www.youtube.com/watch?v=-qFx7lPBjBU](https://www.youtube.com/watch?v=-qFx7lPBjBU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-11-13 00:00:00+00:00

Resident Evil 4 in VR is a great way to experience an all-time classic game, it also shows how older classic games could be remade for VR for a brand new experience.

Thank you to Oculus for sponsoring this video.

Check out Resident Evil 4 here: https://ocul.us/EscapistMagazine
Check out Oculus Quest 2 here: https://ocul.us/EscapistMagazine1

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#Sponsored

