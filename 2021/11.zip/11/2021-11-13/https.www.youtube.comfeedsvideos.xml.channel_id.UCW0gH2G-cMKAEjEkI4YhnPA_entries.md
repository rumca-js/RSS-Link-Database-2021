# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Círdan the Shipwright, The Complete Travels | Tolkien Explained
 - [https://www.youtube.com/watch?v=iXZue8ZeOuI](https://www.youtube.com/watch?v=iXZue8ZeOuI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-11-13 00:00:00+00:00

One of the oldest elves ever to roam Middle-earth, Círdan the Shipwright is also one of the wisest.  Despite his greatest desire to see Valinor, his fate would be to help others make the trip before he would finally sail in the Last Ship himself.

He would see both Morgoth and Sauron rise and fall, and rise again.  His incredible foresight leads him to gift his Ring of Power, Narya, to Gandalf.


Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark
https://www.facebook.com/IllustratorFabioLeone

Cirdan - Steve Airola
Cuivienen - Lida Holubova
Cirdan - Alystraea
Cirdan, not leaving - moumou38
Grey Havens - Alan Lee
Cirdan the Shipwright - ElfinFen
At Lake Cuivienen - Ted Nasmith
Beleriand Map - Lamaarcana
Nan Elmoth - Kimberly80
Valinor Shores - Doga Simsir
Haven of the Eldar - Frederic Bennett
Cirdan - Alchetron
Cirdan - Jef Murray
One of the Teleri - Marya Filatova
Cirdan - sstefiart
Vingilot - Jef Murray
Osse and Teleri - Steamey
Brithombar - Matej Cadil
Thingol - Filat
Mereth Aderthad - Mar Vanwa Tyalieva
Mereth Aderthad - Jenny Dolfen
Melkor - Thomas Rouillard
Alqualonde - Ted Nasmith
The Royal Court of Thingol - Steamey
Noldor Sentinels - Felix Sotomayor
Silmarillion, Cirdan - Ingvildschageart
Nirnaeth Arnoediad - Forever Medhok
Hurin and Morgoth - Ivana Lekseich
Siege Tower - Hildebrandt
Elwing receives the survivors of Gondolin - Alan Lee
Tuor and Voronwe - Anke Eissmann
Nargothrond - Jesse Vandijk
Nargothrond - Jonathan Guzi
The Fall of Gondolin - Mysilvergreen
Earendil the Mariner - Jenny Dolfen
Earendil - Alarie Tano
Earendil's Ship - John Howe
Cirdan - Alchetron
The Oath Has Been Awakened - Jenny Dolfen
Earendil Searches Tirion - Ted Nasmith
Ancalagon vs Earendil - Daniel Pilla
Vingilot - Lida Holubova
Cirdan, Lord of the Falathrim - Peet
Mithlond - Sara M Morello
Sauron and Celebrimbor - Kaprriss
The craftsman of the Gwaith-i-Mirdain - Irsanna
Last Alliance - Abe Papakhian
Elves of the Last Alliance - Tiamat Nightmare
The Last Alliance - Jenny Dolfen
Sauron versus Gil-galad and Elendil - Errricc
Sauron vs Gil-galad on Orodruin - Kip Rasmussen
Isildur cuts the Ring - Denis Gordeev
Isildur and the Ring - Abe Papakhian
The End of the Age - Ted Nasmith
Sauron - Shadow of War
Gandalf receives Narya - Elfofcave
Cirdan and Mithrandir at Grey Havens - Alan Gutierrez
Port on the Isle of Balar - sstefiart
Ship - David Nash
Arvedui - Lida Holubova
The Witch King of Angmar - Vladimir Pyatkov
Cirdan the Shipwright - Cocoz42
The Palantir of Elostirion - Matej Cadil
Council of Elrond - Alan Lee
On the Road to the Grey Havens - Victoria Clare
Grey Havens - Francesco Amadio
The Grey Havens - Al R Young
Grey Havens - Alan Lee
It's Time - moumou38
Cirdan facing the storm - Victoria Clare

#cirdan #tolkien #lordoftherings

