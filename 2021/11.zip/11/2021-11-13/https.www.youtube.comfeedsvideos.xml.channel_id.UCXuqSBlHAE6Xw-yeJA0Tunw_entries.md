# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Check out my HUGE Rack! - New House Network Update
 - [https://www.youtube.com/watch?v=pyZSqfmN_0I](https://www.youtube.com/watch?v=pyZSqfmN_0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-14 00:00:00+00:00

Thanks to VOLTA for sponsoring today’s video! You can check out the VOLTA Spark 60W + 1 Tip and VOLTA Spark 100W + 1 Tip charging cables here: https://geni.us/Jo8c

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Now that Linus' home is sort of smart, it's time to bring in the network rack to house the brains of the operation: Routers, switches, NVRs, UPSes, the whole nine yards! Why is it pink?


Check out RackSolutions' RS148 Data Canter Server Cabinet at https://lmg.gg/cDiVF

Check out the Ubiquiti store: https://lmg.gg/UbiquitiLTT

Buy a Ubiquiti Networks UniFi Dream Machine Pro: https://lmg.gg/KlNKQ

Buy a Ubiquiti Networks Switch Pro 48 PoE: https://lmg.gg/sStI7

Buy a Ubiquiti UniFi Protect Network Video Recorder: https://lmg.gg/FO7b7

Buy a Ubiquiti Networks UniFi SmartPower Redundant Power System: https://lmg.gg/2caLh

Buy an Eaton 9PX Lithium Ion UPS on Newegg: https://geni.us/L9ZA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1388464-check-out-my-huge-new-rack/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:29 Unboxing
3:46 How are we gonna move this thing??
6:23 Linus makes the obvious joke
6:30 It's almost TOO big...
7:48 ... Or is it? Here comes the UPS
10:13 Wire support
12:40 Linus drops his nuts
13:19 Big racks attract lots of cameras
15:18 96 network ports??
16:18 Time to get settled in
19:16 That's a lot of gear Linus can't use right now

## Hate Windows 11? Try these fixes.
 - [https://www.youtube.com/watch?v=GZPRrYLGrhI](https://www.youtube.com/watch?v=GZPRrYLGrhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-13 00:00:00+00:00

Join us in War Thunder for FREE at https://playwt.link/joinltt Get an exclusive bonus using our link - thanks for supporting the channel!

Windows 11 has a reputation for making a lot of changes that makes life more difficult for Windows 10 users. But there has always been a community effort to make tools that ruin Microsoft’s vision…

StartAllBack - https://startallback.com/
Start11 - https://www.stardock.com/products/start11/
Live Tiles Anywhere - https://www.reddit.com/r/Windows11/comments/q18ipe/live_tiles_anywhere_create_custom_live_tiles_for/
RoundedTB - https://github.com/torchgm/RoundedTB
Win11DisableOrRestoreRoundedCorners - https://github.com/valinet/Win11DisableRoundedCorners
(RIP) EdgeDeflector - https://www.ctrl.blog/entry/edgedeflector-default-browser.html
EdgeDeflector alternative: MSEdgeRedirect - https://github.com/rcmaehl/MSEdgeRedirect
AltDrag - https://stefansundin.github.io/altdrag/
Sizer - http://www.brianapps.net/sizer4/
Twinkle Tray - https://twinkletray.com/
Auto Dark Mode - https://github.com/AutoDarkMode/Windows-Auto-Night-Mode
PowerToys - https://docs.microsoft.com/en-us/windows/powertoys/
Winaero Tweaker (registry hacks) - https://winaero.com/winaero-tweaker/

Buy ASUS ROG Swift PG27UQ Monitor
On Amazon (PAID LINK): http://geni.us/d6mJ
On Newegg (PAID LINK): http://geni.us/y2Zg

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1388217-hate-windows-11-try-this/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:44 StartAllBack
2:17 Start11
3:14 Simpler, free tweaks
3:36 RoundedTB and TaskbarX
4:11 Live Tiles Anywhere and un-rounding corners
5:26 EdgeDeflector (RIP - Use MSEdgeRedirect)
6:11 Useful tools that aren't Windows 11 specific
8:18 What are your favourite tools?

