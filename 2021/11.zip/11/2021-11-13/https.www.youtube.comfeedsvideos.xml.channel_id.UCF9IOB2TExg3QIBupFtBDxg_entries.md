# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Autumn predictions and BBC checked
 - [https://www.youtube.com/watch?v=PdgnLxRsxBY](https://www.youtube.com/watch?v=PdgnLxRsxBY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-11-13 00:00:00+00:00

Free download link for John's two text books in PDF, http://159.69.48.3/
These books are now available for free download so students and interested members of the public in poorer areas can read on computers or optional mobile phone friendly format. PDF files may also freely printed out for further free distribution.

US cases and deaths

https://covid.cdc.gov/covid-data-tracker/#trends_dailycases

US hospital patients

https://covid.cdc.gov/covid-data-tracker/#hospitalizations

Covid vaccine booster doses available for all adults 

California, Colorado, New Mexico

Over 18s, six months after second dose

https://www.latimes.com/science/story/2021-11-12/cdc-shifts-pandemic-goals-away-from-reaching-herd-immunity

https://www.cdc.gov/vaccines/acip/meetings/downloads/slides-2021-11-2-3/03-COVID-Jefferson-508.pdf

UK, Zoe graphics link

https://covid.joinzoe.com/post/covid-cases-probably-peaked

Live Zoe data

https://covid.joinzoe.com/data#levels-over-time

UK Official data

https://coronavirus.data.gov.uk

UK, next?

Prof Neil Ferguson, Imperial College London

https://www.theguardian.com/world/live/2021/nov/13/covid-live-news-melbourne-vaccine-mandate-sparks-protest-boris-johnson-warns-of-storm-clouds-in-europe

Catastrophic winter wave unlikely in UK

UK, quite a different situation from other European nations (Germany, Netherlands, France)

High Covid numbers in summer, population immune boost

30,000 to 50,000 a day, for the last four months

I think it is unlikely we will get anything close to what we had last year, that catastrophic winter wave

Several weeks of declining cases, a hint of an uptick in the last few days

Russia 

Cases, + 39,256

Deaths, + 1,241

One week after 80 region, 1 week workplace shutdown

Fact checking the BBC

https://www.bbc.co.uk/news/health-59178291

Covid: Pfizer says antiviral pill 89% effective in high-risk cases

It comes a day after the UK medicines regulator approved a similar treatment from Merck Sharp and Dohme (MSD).

Pfizer says it stopped trials early as the initial results were so positive.

The combination treatment, which is still experimental because trials haven't finished

UK, 250,000 courses of Paxlovid (combo with ritonavir)

480,000 courses of molnupiravir pill

Paxlovid works slightly differently to the Merck pill

which introduces errors into the genetic code of the virus

Full trial data has not yet been published by either company

Pfizer, chairman and chief executive Albert Bourla

the potential to save patients' lives, reduce the severity of Covid-19 infections, and eliminate up to nine out of 10 hospitalisations

There have been successes, notably in HIV, but reports concluded one antiviral for flu ended up being about as effective as paracetamol.

