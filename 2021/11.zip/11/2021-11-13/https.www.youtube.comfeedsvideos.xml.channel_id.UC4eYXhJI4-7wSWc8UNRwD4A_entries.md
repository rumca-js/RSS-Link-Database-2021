# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Rodrigo y Gabriela: : Una Conversación Con Alt.Latino
 - [https://www.youtube.com/watch?v=eTacK5_H660](https://www.youtube.com/watch?v=eTacK5_H660)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-11-14 00:00:00+00:00

Grammy-winning, guitar-wielding Rodrigo y Gabriela swapped stories, talked process, and celebrated the release of "Jazz EP" live on @nprmusic with Alt.Latino host Felix Contreras.

#eltiny #rodrigoygabriela #altlatino

