# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Salwador - życie w strachu
 - [https://www.youtube.com/watch?v=KPxWPX0Rt6E](https://www.youtube.com/watch?v=KPxWPX0Rt6E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2021-11-14 00:00:00+00:00

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Cash:  @Vlog Casha  

Dźwięk: Mateusz Czerniakowski

Wyblurowanie postaci: BigPhilOnline https://www.youtube.com/channel/UCLsTtoLIe6mST4cA5_g0fZg

Thumbnail photo credits:  MARVIN RECINOS/AFP

Czas akcji: listopad 2021r.

