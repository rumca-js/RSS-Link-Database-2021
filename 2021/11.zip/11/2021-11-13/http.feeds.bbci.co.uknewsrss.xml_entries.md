# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Martinez stuns Galahad to take IBF featherweight title
 - [https://www.bbc.co.uk/sport/boxing/59278155?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/59278155?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 23:38:40+00:00

Kid Galahad suffers a devastating defeat in his maiden defence of the IBF world featherweight title, knocked out in the sixth round by Spaniard Kiko Martinez.

## Covid: Dutch accept life within 'lockdown-lite'
 - [https://www.bbc.co.uk/news/world-europe-59274688?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59274688?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 21:35:17+00:00

Most in the Netherlands support a new lockdown-lite, despite anti-lockdown protests making headlines.

## COP26: Alok Sharma fights back tears as Glasgow Climate Pact agreed
 - [https://www.bbc.co.uk/news/world-59276651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-59276651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 20:18:21+00:00

The COP26 president apologised as a late amendment on coal was added to the draft text by India.

## Bottas beats Verstappen to Sao Paulo sprint win as Hamilton fights back
 - [https://www.bbc.co.uk/sport/formula1/59277222?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/59277222?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 20:12:48+00:00

Mercedes driver Valtteri Bottas beats Red Bull's Max Verstappen in sprint qualifying and will start the Sao Paulo Grand Prix from pole position.

## Australia and New Zealand set for unexpected World Cup final
 - [https://www.bbc.co.uk/sport/cricket/59273673?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59273673?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 15:16:01+00:00

Australia and New Zealand meet in an unexpected T20 World Cup final on Sunday, with both chasing their own pieces of history.

## Poland-Belarus border: The BBC reports from the camps within touching distance of the EU
 - [https://www.bbc.co.uk/news/world-europe-59273174?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59273174?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 14:56:02+00:00

Steve Rosenberg reports from the migrant camps within touching distance of the EU.

## Covid: 'No reason' not to give boosters to under-50s
 - [https://www.bbc.co.uk/news/uk-59273273?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59273273?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 12:40:32+00:00

Prof Neil Ferguson says giving booster jabs to younger age groups would drive down transmission levels.

## Sara Duterte: Daughter of Philippines leader runs for vice-president
 - [https://www.bbc.co.uk/news/world-asia-59274204?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59274204?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 12:35:27+00:00

Sara Duterte will run alongside the son of the country's former dictator, Ferdinand Marcos.

## BBC weatherman Owain Wyn Evans' drumathon raises £2m
 - [https://www.bbc.co.uk/news/uk-england-manchester-59273872?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-59273872?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 12:29:44+00:00

Owain Wyn Evans says his "hands held up OK" during his 24-hour challenge for BBC Children in Need.

## Abersoch: Life in a tourist town when the visitors have left
 - [https://www.bbc.co.uk/news/uk-wales-59240522?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59240522?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 11:47:25+00:00

Abersoch sees its population of 600 skyrocket to 30,000 in the summer months.

## Kendal Covid conspiracy brothers jailed for buying pistol
 - [https://www.bbc.co.uk/news/uk-england-cumbria-59274090?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cumbria-59274090?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 11:34:46+00:00

Harry and Ashley Wilson, from Kendal, believe the Covid jab turns people into "unthinking beings".

## Survey criticised for asking children if they are too fat
 - [https://www.bbc.co.uk/news/uk-wales-59264280?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59264280?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 11:22:43+00:00

Holly Rhys-Ellis, who had an eating disorder when she was 11, says such questions are unhelpful.

## England picking Tuilagi on wing 'may make life easier' for Australia - Dawson
 - [https://www.bbc.co.uk/sport/rugby-union/59262340?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/59262340?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 11:21:05+00:00

Eddie Jones may have "made life easier for Australia" by selecting Manu Tuilagi on the wing for Saturday's Twickenham encounter, says Matt Dawson.

## Norwich City: Dean Smith set to be appointed as head coach
 - [https://www.bbc.co.uk/sport/football/59272851?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59272851?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 11:16:15+00:00

Dean Smith is set to become the new Norwich City head coach, with an announcement expected on Sunday or Monday.

## Brentford stabbing: Man killed and elderly woman in critical condition
 - [https://www.bbc.co.uk/news/uk-england-london-59273343?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59273343?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 11:15:06+00:00

A man in his 30s is arrested on suspicion of murder and attempted murder.

## COP26: New draft deal aims to close lingering divisions
 - [https://www.bbc.co.uk/news/science-environment-59269886?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59269886?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 11:10:00+00:00

The new draft is unlikely to heal splits over subsidies for fossil fuels and financial aid.

## Scottish Conservative leader Douglas Ross in job 'sleaze' row
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-59270798?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-59270798?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 10:40:30+00:00

Douglas Ross failed to declare earnings as an MSP and as a football referee for the SFA.

## Edinburgh heritage group worried over outdoor eating areas
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-59264756?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-59264756?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 09:08:12+00:00

The Cockburn Association says it fears temporary structures for outdoor eating in Edinburgh could be made permanent.

## COP26: The story from Glasgow in 15 pictures
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-59176752?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-59176752?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 09:07:51+00:00

The most eye-catching demonstrations and unusual stories during COP26 have unfolded on the streets of Glasgow.

## Brecon Beacons: Why do people navigate perilous caves for fun?
 - [https://www.bbc.co.uk/news/uk-wales-59226313?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59226313?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 08:28:14+00:00

Caving enthusiasts say they experience beauty, friendship and peace while underground.

## Oasis: Liam Gallagher's Wonderwall tambourine sold
 - [https://www.bbc.co.uk/news/uk-wales-59211834?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59211834?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 08:27:53+00:00

The "battered" instrument was saved from the bin by a sound engineer.

## Covid-19: Pandemic purchases and the unlikely faces of America's Covid culture war
 - [https://www.bbc.co.uk/news/uk-59271856?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59271856?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 08:04:07+00:00

Five things you need to know about the coronavirus pandemic this Saturday morning.

## Indian activists who helped change the face of modern Britain
 - [https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-58627849?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-58627849?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 07:46:52+00:00

The friends "oiled the wheels of Indian independence" and challenged discrimination in the UK.

## Cyborg knocks out Kavanagh to retain title - highlights & report
 - [https://www.bbc.co.uk/sport/mixed-martial-arts/59268862?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/mixed-martial-arts/59268862?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 07:37:36+00:00

Reigning featherweight world champion Cris Cyborg claims the 11th first-round knockout of her career as she beats Ireland's Sinead Kavanagh in the main event of Bellator 271.

## Hamilton & Verstappen under investigation after Sao Paulo qualifying
 - [https://www.bbc.co.uk/sport/formula1/59269846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/59269846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 06:52:52+00:00

Title rivals Lewis Hamilton and Max Verstappen are under investigation after Hamilton's car was referred to stewards following Friday's qualifying race at the Sao Paulo Grand Prix.

## Newspaper headlines: Covid 'end' prediction and PM 'pays price at polls'
 - [https://www.bbc.co.uk/news/blogs-the-papers-59270356?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59270356?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 05:28:01+00:00

Saturday's papers are varied, with the i weekend revealing when Whitehall expects the pandemic to end.

## Britney Spears released from 13-year conservatorship
 - [https://www.bbc.co.uk/news/entertainment-arts-59217825?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59217825?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 02:23:38+00:00

An LA judge terminates a legal guardianship set up by the 39-year-old pop star's father in 2008.

## Period packs for footballers: 'Players can't talk to managers'
 - [https://www.bbc.co.uk/news/newsbeat-59235130?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-59235130?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:41:22+00:00

Friends Rachael and Jo have created a care package for people who play football while menstruating.

## Iqaluit: A month without clean water in Canada's north
 - [https://www.bbc.co.uk/news/world-us-canada-59253088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59253088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:10:29+00:00

Frustration is growing in the Canadian city of Iqaluit after fuel contaminated the water supply.

## Belarus border: Scrambling for facts in Europe's new crisis
 - [https://www.bbc.co.uk/news/world-europe-59258414?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59258414?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:09:27+00:00

Journalists and aid workers are kept away from the bleak spectacle of migrants on the Polish border.

## Ship-load of 'toxic' Chinese fertilizer causes diplomatic stink
 - [https://www.bbc.co.uk/news/world-asia-59202309?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59202309?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:07:38+00:00

A ship carrying fertiliser from China to Sri Lanka is at the heart of a dispute between both allies.

## Week in pictures: 6 - 12 November 2021
 - [https://www.bbc.co.uk/news/in-pictures-59260484?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-59260484?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:05:59+00:00

A selection of powerful images from all over the globe, taken this week.

## BBC's Simpson revisits Afghanistan under the Taliban
 - [https://www.bbc.co.uk/news/world-asia-59265609?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59265609?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:05:13+00:00

In 2001, the BBC's World Affairs editor was part of a team which entered the city when the Taliban fell.

## 'I could have been a racist killer'
 - [https://www.bbc.co.uk/news/stories-59171107?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-59171107?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:04:09+00:00

As a teenager, Mike was an armed and angry US Nazi. Looking back, he fears he came close to murder.

## Ros Atkins on... The fight for Nazanin's freedom
 - [https://www.bbc.co.uk/news/uk-politics-59263620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-59263620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:03:24+00:00

Ros Atkins looks at the story behind Nazanin Zaghari-Ratcliffe's detention in Iran.

## Young carers: The children missing from the system
 - [https://www.bbc.co.uk/news/science-environment-59254088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59254088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-13 00:02:49+00:00

Kim and Amy are among thousands of young carers missing out on support.

