# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Spieszmy się kochać licznik łapek w dół! Tech Week
 - [https://www.youtube.com/watch?v=hPjUajKP808](https://www.youtube.com/watch?v=hPjUajKP808)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-11-14 00:00:00+00:00

Spis treści:
00:00 Wstęp
00:15 Dobry wieczór!
00:19 YouTube ukryje łapki w dół
00:57 Badania dotyczące syndromu turbiny
03:05 Wzrost sprzedaży rowerów elektrycznych
03:21 Rower Vanmoof
03:50 Elon Musk pyta co zrobić ze swoimi akcjami
05:33 GiBank na Kickstarterze
08:11 Gucci Box
08:38 iPhone z USB C
09:14 Apple 1 sprzedany za 500 tys. dolarów
09:34 Dlaczego czytnik linii papilarnych w Pixelu działa wolno
10:51 Relacja z wystawy KlawiaturART w Krakowie
11:08 W Portugalii szef nie może wysłać do pracownika SMS-a po godzinach pracy
11:39 Znośnego tygodnia!

Źródła:
Licznik łapek w dół znika: https://bit.ly/3Dvo0mp
Syndrom turbiny: https://bit.ly/3wS3fi3
Badania dot. syndromu turbiny: https://bit.ly/3Hk7wzC
Rowery elektryczne dobrze się sprzedają: https://nyti.ms/3FeBseO
Vanmoof: https://bit.ly/3HkWp9w
Musk pyta na TT czy powinien sprzedać swoje akcje: https://bit.ly/3ounBdj
Choć i tak zdecydował wcześniej: https://bit.ly/3naq0KR
Gibank na Kickstarterze - https://bit.ly/3DinzLN
iPhone z usb-c: https://bit.ly/3Ds25Mw
Jak powstawał iPhone z usb-c: https://youtu.be/FVEQJNRmfDQ
Apple-1 sprzedany za 500 tyś dolarów: https://bit.ly/2YLN7Cf
Dlaczego czytnik linii papilarnych w Pixelu 6 działa wolno: https://bit.ly/3wNeVTq
W Portugalii szef nie może Ci wysłać smsa po pracy: https://bit.ly/3nd3mRZ

