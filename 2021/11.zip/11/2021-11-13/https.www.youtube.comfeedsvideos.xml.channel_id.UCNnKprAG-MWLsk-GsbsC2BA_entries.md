# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Mighty Hasbulla
 - [https://www.youtube.com/watch?v=JFpmnoh0GqU](https://www.youtube.com/watch?v=JFpmnoh0GqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-11-14 00:00:00+00:00

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

Backgrounds ►  
Soured Apple https://www.twitter.com/SouredApple
Naav Draws

Music ►
Zach Heyde https://youtube.com/playlist?list=PLXtP4ANq7nIUYo6VZEEHtd8H3HP_MthUC

Sound ► 
Justin Greger

Music (ad) ►Hall of the Mountain King Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 3.0 License
http://creativecommons.org/licenses/by/3.0/

VO ► 
Hasbullah (Inner) - Ricepirate
Hasbullah (Outer) - Tom and Don
Tamaev - Tom

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

