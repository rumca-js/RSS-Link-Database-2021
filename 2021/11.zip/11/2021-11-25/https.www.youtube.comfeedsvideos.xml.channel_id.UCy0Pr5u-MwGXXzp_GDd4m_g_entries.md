# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## All the STDs in one room
 - [https://www.youtube.com/watch?v=AQifhzfbWa0](https://www.youtube.com/watch?v=AQifhzfbWa0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-11-25 00:00:00+00:00

Herpes, Syphilis, Chlamydia, HPV... the gangs all here. Thank you to LetsGetChecked: Visit https://trylgc.com/nolke and use the code NOLKE to get 30% off your own testing kit!

Writer & Actor: Julie Nolke
Camera: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Also, check out my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

