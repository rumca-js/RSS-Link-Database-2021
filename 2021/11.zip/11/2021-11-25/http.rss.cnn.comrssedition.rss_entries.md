# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## CNN's Richard Quest plays video games with Xbox head
 - [https://www.cnn.com/videos/tech/2021/11/25/xbox-head-phil-spencer-richard-quest-pkg-nr-vpx.cnn](https://www.cnn.com/videos/tech/2021/11/25/xbox-head-phil-spencer-richard-quest-pkg-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 22:23:11+00:00

CNN's Richard Quest plays video games with the head of Xbox Phil Spencer who talks about the future of the company as they celebrate the console's 20th anniversary.

## Weather to watch for post-Thanksgiving travel
 - [https://www.cnn.com/videos/weather/2021/11/25/thanksgiving-travel-weather-forecast.cnn](https://www.cnn.com/videos/weather/2021/11/25/thanksgiving-travel-weather-forecast.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 20:57:22+00:00

A new storm system is expected to bring some rain and snow to the Northeast this weekend as millions travel home from the Thanksgiving holiday. CNN meteorologist Tom Sater has an updated forecast.

## Thanksgiving travelers set pandemic record with more than 2.3 million in the air, TSA says
 - [https://www.cnn.com/travel/article/pandemic-air-travel-record-thanksgiving/index.html](https://www.cnn.com/travel/article/pandemic-air-travel-record-thanksgiving/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 20:10:02+00:00

Thanksgiving travelers have set a new pandemic-era air travel record in the United States.

## 'Release that video call': Amanpour presses IOC official on Peng Shuai
 - [https://www.cnn.com/videos/tv/2021/11/25/amanpour-dick-pound-ioc-peng-shuai-china-olympics.cnn](https://www.cnn.com/videos/tv/2021/11/25/amanpour-dick-pound-ioc-peng-shuai-china-olympics.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 19:15:49+00:00

The International Olympic Committee's Dick Pound tells Christiane Amanpour the IOC is satisfied that Peng Shuai is "alive and healthy and not under coercion"

## Unwrapping seven new Christmas movies
 - [https://www.cnn.com/videos/movies/2021/11/25/unwrapping-seven-new-christmas-movies.cnn](https://www.cnn.com/videos/movies/2021/11/25/unwrapping-seven-new-christmas-movies.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 18:13:07+00:00

Comedies, romances, family films -- Rick Damigella makes our new Christmas movies list and checks it twice.

## Restaurant group shelling out $650,000 to let 250 staff fly to see their families
 - [https://www.cnn.com/travel/article/hong-kong-black-sheep-free-staff-flights-cmd/index.html](https://www.cnn.com/travel/article/hong-kong-black-sheep-free-staff-flights-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 18:06:08+00:00

For Sandeep Arora, home is the ancient city of Jalandhar in India's Punjab region. His wife, son and parents live there, but he hasn't seen them since March 2020.

## Snowboarder Marko Grilc dies in accident
 - [https://www.cnn.com/2021/11/25/sport/snowboarder-marko-grilc-austria-death-spt-intl/index.html](https://www.cnn.com/2021/11/25/sport/snowboarder-marko-grilc-austria-death-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 17:50:33+00:00

Snowboarder Marko Grilc has died following an accident in the Austrian ski resort of Sölden, two of his sponsors have confirmed.

## 'Afghan Girl' from National Geographic magazine cover granted refugee status in Italy
 - [https://www.cnn.com/style/article/afghan-girl-national-geographic-italy-scli-intl/index.html](https://www.cnn.com/style/article/afghan-girl-national-geographic-italy-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 17:43:01+00:00

The "Afghan Girl" made famous after featuring on the cover of National Geographic magazine in 1985 has been granted refugee status by Italy's Prime Minister Mario Draghi, according to an Italian government press office statement.

## British man given 3D printed eye in world first, hospital says
 - [https://www.cnn.com/2021/11/25/health/3d-printed-eye-scli-intl-gbr-scn/index.html](https://www.cnn.com/2021/11/25/health/3d-printed-eye-scli-intl-gbr-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 17:28:03+00:00

A British man has become the first patient in the world to be fitted with a 3D printed eye, according to Moorfields Eye Hospital in London.

## Hear what Dr. Fauci thinks about vaccine boosters for kids
 - [https://www.cnn.com/videos/health/2021/11/25/covid-19-boosters-children-dr-fauci-coronavirus-vaccine-ac360-vpx.cnn](https://www.cnn.com/videos/health/2021/11/25/covid-19-boosters-children-dr-fauci-coronavirus-vaccine-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 17:10:18+00:00

CNN's John Berman asks Dr. Anthony Fauci about Covid-19 vaccine boosters for kids and teenagers six months after their second vaccine shot.

## This is what a boat provided by smugglers to migrants looks like
 - [https://www.cnn.com/videos/world/2021/11/25/english-channel-migrants-boat-capsizing-calais-vanier-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/11/25/english-channel-migrants-boat-capsizing-calais-vanier-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 16:45:55+00:00

CNN's Cyril Vanier reports from a beach near Calais, France, after at least 27 people died when their boat capsized marking one of the largest losses of life in the English Channel in recent years.

## UK Michelin star restaurant burns down
 - [https://www.cnn.com/travel/article/star-at-harome-thatch-roof-fire-scli-intl-gbr/index.html](https://www.cnn.com/travel/article/star-at-harome-thatch-roof-fire-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 16:28:25+00:00

A Michelin-star restaurant in northern England housed in a 14th century building has suffered significant damage after its thatched roof caught fire.

## Why scientists are breeding some of the ocean's top predators
 - [https://www.cnn.com/videos/world/2021/11/25/sunflower-sea-star-kelp-disappearing-oceans-c2e-spc-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/11/25/sunflower-sea-star-kelp-disappearing-oceans-c2e-spc-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 15:39:52+00:00

Numbers of sunflower sea stars have crashed in recent years, but researchers in California are working to restore the species.

## Watch this historic power plant's smokestacks flatten in demolition
 - [https://www.cnn.com/videos/world/2021/11/25/australia-power-plant-demolition-lon-orig-na.cnn](https://www.cnn.com/videos/world/2021/11/25/australia-power-plant-demolition-lon-orig-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 12:56:35+00:00

A more than 60-year-old coal-fired power plant has been partially demolished in New South Wales, Australia, according to CNN-affiliate Nine News.

## 'Largely a dud': Legal analyst reacts to news about Trump Organization
 - [https://www.cnn.com/videos/politics/2021/11/25/trump-organization-matthew-calamari-scannell-honig-newday-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/11/25/trump-organization-matthew-calamari-scannell-honig-newday-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 12:12:29+00:00

CNN's Kara Scannell reports Manhattan prosecutors have informed top Trump Organization executive Matthew Calamari that, for now, they do not intend to charge him with any crimes as part of their wide-ranging investigation into the former president's company. CNN's senior legal analyst Elie Honig says this indicates the tax fraud charge against the organization is likely going nowhere.

## Here's what comes next after jury found 3 men guilty for the murder of Ahmaud Arbery
 - [https://www.cnn.com/collections/intl-arbery-trial-1124/](https://www.cnn.com/collections/intl-arbery-trial-1124/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 12:00:42+00:00



## Eight dead and 13 children injured as bomb explodes near school in Somalia
 - [https://www.cnn.com/2021/11/25/africa/somalia-blast-eight-killed-intl/index.html](https://www.cnn.com/2021/11/25/africa/somalia-blast-eight-killed-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 11:24:46+00:00

At least eight civilians were killed and 17 others injured, including 13 school children, after a suicide car bomb exploded in Somalia's capital Mogadishu Thursday morning, according to state media.

## Guilty verdicts in trial over Ahmaud Arbery's murder were an answer to prayers, family says. Here's what comes next
 - [https://www.cnn.com/2021/11/25/us/ahmaud-arbery-killing-trial-thursday-whats-next/index.html](https://www.cnn.com/2021/11/25/us/ahmaud-arbery-killing-trial-thursday-whats-next/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 09:35:08+00:00



## Dozens dead in Channel tragedy, after inflatable boat sinks off French coast
 - [https://www.cnn.com/2021/11/24/europe/france-channel-migrant-deaths-gbr-intl/index.html](https://www.cnn.com/2021/11/24/europe/france-channel-migrant-deaths-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 08:57:52+00:00

A young girl was among 27 people who drowned in bitterly cold waters off the coast of France on Wednesday, after an inflatable boat carrying migrants bound for Britain capsized, in one of the deadliest incidents in the English Channel in recent years.

## Manchester City defeats Paris Saint-Germain as both teams qualify for Champions League knockout stages
 - [https://www.cnn.com/2021/11/24/football/man-city-psg-champions-league-spt-intl/index.html](https://www.cnn.com/2021/11/24/football/man-city-psg-champions-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 08:52:50+00:00

Manchester City came from behind to defeat Paris Saint-Germain 2-1 on Wednesday as both teams qualified for the knockout stages of the Champions League.

## Violent protests continue in Pacific island nation despite lockdown
 - [https://www.cnn.com/2021/11/24/asia/solomon-islands-protest-lockdown-intl-hnk/index.html](https://www.cnn.com/2021/11/24/asia/solomon-islands-protest-lockdown-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 08:50:43+00:00

The Solomon Islands imposed a 36-hour lockdown in the capital, Honiara, after protesters calling for the Prime Minister to resign looted stores and set fire to buildings, including in the Pacific nation's Parliament.

## Think turkey tryptophan makes you sleepy? Think again
 - [https://www.cnn.com/2021/11/25/health/turkey-tryptophan-effects-wellness-partner/index.html](https://www.cnn.com/2021/11/25/health/turkey-tryptophan-effects-wellness-partner/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 08:40:51+00:00

Every Thanksgiving, myths of the quasi-magical powers of tryptophan rise again.

## This is how astronauts celebrate Thanksgiving in space
 - [https://www.cnn.com/2021/11/25/world/nasa-astronauts-thanksgiving-space-scn/index.html](https://www.cnn.com/2021/11/25/world/nasa-astronauts-thanksgiving-space-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 08:39:49+00:00

The holidays still happen in space, they just look a little bit different. But the sentiments are the same.

## Hawaiian artist's enormous murals are ambitious in scale and message
 - [https://www.cnn.com/style/article/kamea-hadar-mural-art-hawaii-building/index.html](https://www.cnn.com/style/article/kamea-hadar-mural-art-hawaii-building/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 08:28:24+00:00

Honolulu, Hawaii-based artist Kamea Hadar has lost count of how many murals he's painted in his career -- his best guess is at least 50 over the past decade.

## More than a dozen remain hospitalized after deadly Waukesha parade crash
 - [https://www.cnn.com/2021/11/25/us/waukesha-car-parade-thursday/index.html](https://www.cnn.com/2021/11/25/us/waukesha-car-parade-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 07:59:00+00:00

More than a dozen people remain hospitalized after a driver rammed an SUV through a Christmas parade in Waukesha, Wisconsin, over the weekend, killing six people and injuring dozens more.

## Who is Zhang Gaoli? The man at the center of Chinese tennis star Peng Shuai's #MeToo allegation
 - [https://www.cnn.com/2021/11/25/china/who-is-zhang-gaoli-intl-hnk-dst/index.html](https://www.cnn.com/2021/11/25/china/who-is-zhang-gaoli-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 06:52:03+00:00

Before retiring as vice premier, Zhang Gaoli was the face of China's organizing efforts ahead of the 2022 Winter Olympics.

## Leaders react to migrant boat capsizing in English Channel
 - [https://www.cnn.com/videos/world/2021/11/24/boris-johnson-migrant-boat-capsizes-reaction-intl-vpx.cnn](https://www.cnn.com/videos/world/2021/11/24/boris-johnson-migrant-boat-capsizes-reaction-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 06:29:07+00:00

At least 31 migrants died after a trafficking boat capsized in the English Channel. British Prime Minister Boris Johnson and French President Emmanual Macron have condemned the conditions that led to the deaths.

## China steps up censorship in wake of tennis star's allegations
 - [https://www.cnn.com/videos/media/2021/11/25/china-censorship-peng-shuai-ebof-ripley-pkg-vpx.cnn](https://www.cnn.com/videos/media/2021/11/25/china-censorship-peng-shuai-ebof-ripley-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 06:25:53+00:00

CNN's Will Ripley reports on China's ongoing efforts to censor media reports on the sexual assault allegations made by tennis star Peng Shuai against a retired top Communist party official.

## China's Foreign Ministry says the case should not be politicized
 - [https://www.cnn.com/2021/11/23/china/peng-shuai-china-foreign-ministry-int-hnk/index.html](https://www.cnn.com/2021/11/23/china/peng-shuai-china-foreign-ministry-int-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 06:06:53+00:00

China's Ministry of Foreign Affairs said on Tuesday the government hoped "malicious speculation" about tennis star Peng Shuai's well-being and whereabouts would stop, and that her case should not be politicized.

## Ethiopian leader heads to war's front lines as Olympians join the military
 - [https://www.cnn.com/2021/11/24/africa/ethiopia-abiy-olympians-front-lines-intl/index.html](https://www.cnn.com/2021/11/24/africa/ethiopia-abiy-olympians-front-lines-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 05:28:33+00:00

Ethiopia's Prime Minister Abiy Ahmed has gone to direct the war from the front lines, state-affiliated media reported on Wednesday, as two Olympian athletes announced they were enlisting in the military.

## Great Barrier Reef explodes into life in 'magical' spawning event
 - [https://www.cnn.com/travel/article/great-barrier-reef-coral-spawn-scn/index.html](https://www.cnn.com/travel/article/great-barrier-reef-coral-spawn-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 03:36:00+00:00

The Great Barrier Reef has "given birth" in its annual coral spawn, creating a cacophony of color on the Australian landmark.

## 'Badass move': Renowned astrophysicist praises NASA's latest mission
 - [https://www.cnn.com/videos/business/2021/11/25/degrasse-tyson-nasa-asteroid-ac360-berman-intv-vpx.cnn](https://www.cnn.com/videos/business/2021/11/25/degrasse-tyson-nasa-asteroid-ac360-berman-intv-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 03:27:59+00:00

CNN's John Berman speaks with astrophysicist Neil deGrasse Tyson about NASA's DART mission, or the Double Asteroid Redirection Test, which is set to crash into a near-Earth asteroid to try to change its motion in space.

## Myanmar troops arrest 18 medics for treating members of anti-junta groups
 - [https://www.cnn.com/2021/11/24/asia/myanmar-arrest-medics-intl-hnk/index.html](https://www.cnn.com/2021/11/24/asia/myanmar-arrest-medics-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 03:26:38+00:00

Myanmar's military has arrested 18 medics for providing treatment to patients who were members of "terrorist organizations," a state-run newspaper said Wednesday, referring to outlawed anti-junta groups.

## How a love for big cats and the 'myth' of the leopard sparked this wildlife photographer's career
 - [https://www.cnn.com/travel/article/rodney-nombekana-kruger-wildlife-photography-south-africa-spc/index.html](https://www.cnn.com/travel/article/rodney-nombekana-kruger-wildlife-photography-south-africa-spc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 02:47:27+00:00

People travel across oceans and from the other side of the world for a chance to see the wonders of Kruger National Park. The South African game reserve was established more than 120 years ago and ranks among the best national parks in the world. Bucket-list adventurers visit with the hope of encountering the "big five" -- lions, leopards, elephants, rhinos and buffalo -- and, with any luck, capturing a memory-worthy photo in the process.

## Biden had benign but potentially precancerous lesion removed during colonoscopy
 - [https://www.cnn.com/2021/11/24/politics/biden-colonoscopy-lesion-removed/index.html](https://www.cnn.com/2021/11/24/politics/biden-colonoscopy-lesion-removed/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 02:45:51+00:00

President Joe Biden had a single 3-millimeter polyp removed during his routine colonoscopy last week at Walter Reed medical center.

## Red Cross warns of 'serious problems' with remote Bangladesh island housing Rohingya refugees
 - [https://www.cnn.com/2021/11/24/asia/bangladesh-rohingya-red-cross-intl-hnk/index.html](https://www.cnn.com/2021/11/24/asia/bangladesh-rohingya-red-cross-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 02:42:43+00:00

A senior Red Cross official warned that "serious problems" remain with a remote island off southern Bangladesh housing Rohingya refugees, as officials prepared to ship thousands more people there this week.

## Trump reveals Rittenhouse visited him at Mar-a-Lago
 - [https://www.cnn.com/videos/politics/2021/11/25/trump-visit-kyle-rittenhouse-mar-a-lago-todd-dnt-vpx.cnn](https://www.cnn.com/videos/politics/2021/11/25/trump-visit-kyle-rittenhouse-mar-a-lago-todd-dnt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 02:28:59+00:00

Former President Donald Trump said he was recently visited at his Palm Beach, Florida, resort by Kyle Rittenhouse, the teenager who was acquitted last week on all charges after fatally shooting two people and wounding a third during protests in Kenosha, Wisconsin, last summer.

## Waukesha parade crash suspect appeared to have no emotion as officers tried to stop him
 - [https://www.cnn.com/2021/11/24/us/waukesha-car-parade-crowd-wednesday/index.html](https://www.cnn.com/2021/11/24/us/waukesha-car-parade-crowd-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 01:52:13+00:00

Shortly before an SUV barreled into a crowd of parade marchers and pedestrians on Sunday in Waukesha, Wisconsin, at least one officer described the driver as having "no emotion" on his face during attempts to slow him down.

## Court says soccer star Benzema used 'subterfuge and lies' in sex tape case
 - [https://www.cnn.com/2021/11/24/football/karim-benzema-guilty-sex-tape-lies-spt-intl/index.html](https://www.cnn.com/2021/11/24/football/karim-benzema-guilty-sex-tape-lies-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 01:00:27+00:00

It all started with a broken cell phone.

## China's disappearing ships: The latest headache for the global supply chain
 - [https://www.cnn.com/2021/11/24/business/china-shipping-data-mic-intl-hnk/index.html](https://www.cnn.com/2021/11/24/business/china-shipping-data-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 00:56:51+00:00

Ships in Chinese waters are disappearing from global trackers, creating yet another headache for the global supply chain. China's growing isolation from the rest of the world — along with a deepening mistrust of foreign influence — may be to blame.

## Missouri dig site is home to at least 4 rare dinosaurs, and there could be more
 - [https://www.cnn.com/2021/11/24/world/missouri-dinosaur-bones-uncovered-scn/index.html](https://www.cnn.com/2021/11/24/world/missouri-dinosaur-bones-uncovered-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 00:50:06+00:00

The first tracings of dinosaurs in Missouri were found in the 1940s on the Chronister family's property when they were digging a well. In October, nearly 60 years later, another set of fossils from the same species were uncovered about 50 feet (15 meters) away.

## Statue of Thomas Jefferson removed from New York City Hall after 187 years
 - [https://www.cnn.com/2021/11/24/us/thomas-jefferson-statue-removed/index.html](https://www.cnn.com/2021/11/24/us/thomas-jefferson-statue-removed/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-25 00:32:14+00:00

After 187 years, a statue of America's third president, Thomas Jefferson, no longer sits in New York City Hall.

