# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Bloomberg: Wiek nadmiaru się skończył! Musicie konsumować mniej!
 - [https://www.youtube.com/watch?v=skmEC7ebSZI](https://www.youtube.com/watch?v=skmEC7ebSZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-11-26 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3DWJuIN
2. https://bloom.bg/3FQERAJ
3. https://bit.ly/3lcwXJQ
4. https://bit.ly/3nU2i5W
5. https://bit.ly/3lAd946
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
Bloomberg Philanthropies - https://bit.ly/3FP3kpT
---------------------------------------------------------------
💡 Tagi: #Bloomberg #konsumpcja
--------------------------------------------------------------

## Zbliża się koniec papierowych i plastikowych dokumentów! Zapowiedzi i lobbing!
 - [https://www.youtube.com/watch?v=WtEGbHjm6LI](https://www.youtube.com/watch?v=WtEGbHjm6LI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-11-25 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3xlbovL
2. https://bit.ly/3cOZosW
3. https://bit.ly/3iVe1yX
4. https://bit.ly/3zTVTvb
5. https://bit.ly/3izCd9v
6. https://bit.ly/3a9bITQ
---------------------------------------------------------------
💡 Tagi: #aplikacje #TozsamoscCyfrowa #QR
--------------------------------------------------------------

