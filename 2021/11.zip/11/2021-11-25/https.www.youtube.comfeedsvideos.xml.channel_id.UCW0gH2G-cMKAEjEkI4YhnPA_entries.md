# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Best Gift Ideas for Tolkien Fans 2021 - The Lord of the Rings, The Hobbit, and more!
 - [https://www.youtube.com/watch?v=o48wHf4-dpk](https://www.youtube.com/watch?v=o48wHf4-dpk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-11-25 00:00:00+00:00

For TONS of great Tolkien-related gift ideas - including the ones in this video and MANY more, visit my customized Middle-earth lists on Amazon: https://www.amazon.com/shop/nerdoftherings

Check out great Middle-earth Audiobooks
US: https://amzn.to/3oXp0cT
UK: https://amzn.to/30QiyvL

Featured Artists:
The Oath of Finrod and Barahir - Anke Eissmann
The Death of Feanor - Jenny Dolfen
Gandalf and The Balrog - Anato Finnstark
The Music of the Gods - Kip Rasmussen
Flame of Udun - Manuel Castanon
Hurin and Huor Approaching Gondolin - Donato Giancola

Other Featured Products:
WETA Mini Epics
TUBBZ Gollum, Saruman, etc
Lord of Maps (lordofmaps.com)
The Lord of the Rings Build-A-Bear
Mythologie Candles (mythologiecandles.com)
Shadow of War Video Game
LEGO The Hobbit Video Game
The Lord of the Rings Little People
The Lord of the Rings: Journeys in Middle-earth board game
The Lord of the Rings Monopoly
An Unexpected Party Boardgame by WETA (Also available on Amazon)

#tolkien #gifts #lordoftherings

