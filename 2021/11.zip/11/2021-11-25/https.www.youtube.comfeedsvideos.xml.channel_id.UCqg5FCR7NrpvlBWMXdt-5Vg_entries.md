# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## It’s Time to Coin A New Term for Cinematic Linear Adventure Games | Extra Punctuation
 - [https://www.youtube.com/watch?v=OCKZsyz7B5U](https://www.youtube.com/watch?v=OCKZsyz7B5U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-11-25 00:00:00+00:00

The sad thing about mainstream video games these days is that it’s no longer a craftsman’s industry, really. While the technology was still developing everything had to be built from the ground up. Developers usually coded their own engine, created all the art assets and sounds – I can’t find a source right now but I remember reading that the underwater explosion sound in Quake was created by wrapping a condom around a microphone and sticking it in a bath. That’s a fun story. They made the explodey head effect in the movie Scanners by filling a fake head with dogfood and blasting it with a shotgun. That’s a fun story, too. A lot more fun than “we downloaded it from a library” or “we just used CG.”

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Ruined King: A League Of Legends Story | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=XNx7ZGVMUCc](https://www.youtube.com/watch?v=XNx7ZGVMUCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-11-25 00:00:00+00:00

Elise Avery reviews Ruined King: A League of Legends Story developed by Airship Syndicate.

Ruined King on Steam: https://store.steampowered.com/app/1276790/Ruined_King_A_League_of_Legends_Story/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

