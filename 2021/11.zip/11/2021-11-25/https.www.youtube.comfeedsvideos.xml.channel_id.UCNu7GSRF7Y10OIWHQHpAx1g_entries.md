# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Granada - kolonialne miasteczko w Nikaragui
 - [https://www.youtube.com/watch?v=FTk4I_6z8ps](https://www.youtube.com/watch?v=FTk4I_6z8ps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2021-11-26 00:00:00+00:00

Sklep: https://bezplanu.com

Kareline: https://www.instagram.com/kxrelinne/?hl=en
Cash: @vlogcasha 
Polo: @PiotrPoloPrzywarski 
Filip: @BigPhil 

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv

Czas akcji: listopad 2021r.

