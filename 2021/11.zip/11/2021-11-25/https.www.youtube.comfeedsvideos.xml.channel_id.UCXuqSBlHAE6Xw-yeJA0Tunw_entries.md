# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I ACTUALLY Need to Buy Some Stuff - Black Friday Shopping Stream
 - [https://www.youtube.com/watch?v=3a4px8IkSzc](https://www.youtube.com/watch?v=3a4px8IkSzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-26 00:00:00+00:00

Check out Secret Lab at https://lmg.gg/SecretLabWAN
Check out ORIGIN PC BF 2021 Deals at https://bit.ly/3nOcQUb
Check out ORIGIN PC's with Intel 12th Gen Intel® Core™ processors at https://geni.us/yrMo

We're back with our yearly tradition of black Friday deal hunting - but with the ongoing silicon shortages, can we still build a PC?

Buy Xbox Elite Series 2 Controller
On Amazon (PAID LINK): https://geni.us/TGLTE
On Best Buy (PAID LINK): https://geni.us/jWTfTV 

Xbox Controller chargers on Amazon (PAID LINK): https://geni.us/ugVLz3y 

Buy Corsair iCUE 4000X RGB Mid-Tower ATX PC Case - White
On Amazon (PAID LINK): https://geni.us/QrSYGN 
On Best Buy (PAID LINK): https://geni.us/aJXZ 

Buy Super Nintendo Controller for SNES Nintendo Switch Online on Amazon (PAID LINK): https://geni.us/BUKBkQ 

Buy Nintendo Switch OLED
On Amazon (PAID LINK): https://geni.us/8ZAKN4n
On Best Buy (PAID LINK): https://geni.us/36Yfkd 

Buy Mario Party Superstars
On Amazon (PAID LINK): https://geni.us/0OPgP 
On Best Buy (PAID LINK): https://geni.us/fg2WrQ 

Buy The Legend of Zelda: Breath of the Wild
On Amazon (PAID LINK): https://geni.us/FEjGiNA 
On Best Buy (PAID LINK):  https://geni.us/dOC3J7 

Buy Super Mario Party 
On Amazon (PAID LINK): https://geni.us/hnj0t
On Best Buy (PAID LINK): https://geni.us/Q6P8r 

Buy Ring Fit Adventure
On Amazon (PAID LINK): https://geni.us/l0QWSmB 
On Best Buy (PAID LINK): https://geni.us/7Ezn4uk 

Buy Lego on Amazon (PAID LINK): https://geni.us/Wk8Yzl 

Buy Jackery on Amazon (PAID LINK): https://geni.us/CdYV 

Buy Panasonic eneloop pro Rechargeable AAA Batteries (8-pack)
On Amazon (PAID LINK): https://geni.us/taJw 
On Best Buy (PAID LINK): https://geni.us/ZjaBe

Buy Gun Racks on Amazon (PAID LINK): https://geni.us/OLlbHm 

Buy the Nerf Elite Blaster Rack on Amazon (PAID LINK): https://geni.us/g1wtVG 

Bose Noise Cancelling Headphones 700
On Amazon (PAID LINK): https://geni.us/0zsJg 
On Best Buy (PAID LINK): https://geni.us/n3svc1 

ASUS - ROG Flow X13 2-in-1 13.4" 4K Ultra HD Touch-Screen Laptop on Best Buy (PAID LINK): https://geni.us/ITSMMJM 

Buy Anker USB Chargers (PAID LINK): https://geni.us/E9kCbp 

Buy Samsung Galaxy Z Fold 3 256GB On Amazon (PAID LINK): https://geni.us/Az8L17o 
Best Buy (PAID LINK): https://geni.us/5dGB 

Wire Strippers on Amazon (PAID LINK): https://geni.us/fSqQex 

Buy KNIPEX PreciStrip 16 on Amazon (PAID LINK): https://geni.us/smuM

## PC Gaming is Officially the BEST! - WAN Show November 26, 2021
 - [https://www.youtube.com/watch?v=GOEYBx_c0aY](https://www.youtube.com/watch?v=GOEYBx_c0aY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-26 00:00:00+00:00

Start logging everything in your organization with Humio today! Learn more at https://geni.us/iC4n

Check out Secret Lab at https://lmg.gg/SecretLabWAN

Save 10% at Ridge Wallet with offer code WAN at https://www.ridge.com/WAN

Check out the WAN Show & Podcast Gear: https://lmg.gg/podcastgear 
Check out the They're Just Movies Podcast: https://lmg.gg/tjmpodcast

Podcast Download: TBD

Timestamps: (Courtesy of NoKi1119)
[0:00] Chapters.
[1:29] Intro.
[1:59] Topic #1: PC wins Best Gaming Hardware.
    3:32 Comparing PCs with console.
    7:54 Dark Souls wins Ultimate Game of All Time.
    11:55 Other candidates for the award.
    17:06 Linus's & Luke's "best" of genres.
[29:34] Topic #2: Tesla records YOU.
    31:33 Tesla using non validated self-driving.
    34:15 Inaccurate promises by Tesla.
[39:24] LTTStore Black Friday deals.
[40:42] Sponsors ft technical difficulties.
    41:03 Ridge Wallet.
    41:42 Secretlab chairs.
    43:00 Humio dashboard logging.
[48:50] Topic #3: GPU prices increasing again.
    51:00 Samsung's potential 3nm chips.
[53:24] Topic #4: iBuyPower & Gamers Nexus.
    57:26 A terrible deal is NOT a lie.
    58:54 Linus's experience with rebadged GPUs.
[1:03:05] Topic #5: Qualcomm's exclusivity deal ending in 2022.
    1:05:09 Linux topic, Windows is better at gaming than Linux.
    1:10:32 SteamOS 3.0 & arch-based distros.
    1:14:53 The intended point of the series.
    1:19:28 Candy Crush, PUPs in Windows.
[1:20:24] LTTStore leak #1: LTT backpack.
[1:24:46] Ayaneo 2021 Pro.
[1:28:24] Merch Messages.
[1:31:25] LTTStore leak #2: LTT stealth circuit deskpad
[2:01:28] Outro.

## How Much Does Your Motherboard Affect Performance?
 - [https://www.youtube.com/watch?v=GvyQXkFUe3E](https://www.youtube.com/watch?v=GvyQXkFUe3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-25 00:00:00+00:00

Thanks to Micro Center for sponsoring this video!
New Customers Exclusive – Get a Free 240gb SSD at Micro Center: https://micro.center/91be37

How to Choose PC Parts: The Motherboard: https://micro.center/f98bea

We took one 11900K and benchmarked it across TEN different motherboards to see just how much of a difference they can make when it comes to both gaming and CPU-intensive workloads.

The Test Bench on Micro Center’s Custom PC Builder: https://micro.center/26f3e5
Intel Core i9-11900K: https://micro.center/8052fd
MSI GeForce RTX 3080 SUPRIM X Overclocked Graphics Card: https://micro.center/dbb204
G.Skill Ripjaws V 32GB (2 x 16GB) DDR4-3600 PC4-28800 CL16: https://micro.center/71a18b
Crucial P5 Plus 1TB SSD 3D NAND M.2 NVMe: https://micro.center/aa7f1a
Corsair HX1200 80 Plus Platinum Fully Modular Power Supply: https://micro.center/6fc9b2
Noctua NH-D15 Brown CPU Cooler: https://micro.center/445f58
Noctua NT-H1 High-Performance TIM - 3.5g: https://micro.center/ed33ff

MSI Z590 MEG GODLIKE Intel LGA 1200 eATX Motherboard: https://micro.center/b5eb9c
ASRock Z590 PRO4 Intel LGA 1200 ATX Motherboard: https://micro.center/d15f91
MSI B560M MAG MORTAR WIFI Intel LGA 1200 microATX Motherboard: https://micro.center/b3b2ed
MSI Z590-A PRO Intel LGA 1200 ATX Motherboard: https://micro.center/d822e4
ASUS Z590-P Prime Intel LGA 1200 ATX Motherboard: https://micro.center/b58d06
Gigabyte Z590 UD Intel LGA 1200 ATX Motherboard: https://micro.center/92bf25
ASUS B560M-A Prime Intel LGA 1200 microATX Motherboard: https://micro.center/d46105
ASRock B560M PRO4 Intel LGA 1200 microATX Motherboard: https://micro.center/2b5fae
ASRock H510M-HDV/M.2 Intel LGA 1200 microATX Motherboard: https://micro.center/0dc5d5
Gigabyte B560M DS3H Intel LGA 1200 microATX Motherboard: https://micro.center/3d386b

Discuss on the forum: https://linustechtips.com/topic/1391132-does-your-motherboard-affect-performance/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:05 The Process
3:35 Results
4:47 Store Callout
5:01 Outliers
6:44 Losers
8:04 Bottom Boards
10:05 Conclusion
11:01 Outro

