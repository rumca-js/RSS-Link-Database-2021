# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Thank a maintainer, win a Pi!
 - [https://www.youtube.com/watch?v=_tFSkTbjIGk](https://www.youtube.com/watch?v=_tFSkTbjIGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2021-11-26 00:00:00+00:00

👇 ENTRY FORM BELOW 👇

Let's make Open Source maintainers' lives better this year! Here's how:

  1. Donate to any open source project or maintainer, or share your thanks with them (use hashtag #OSSThanks!).
  2. Enter to win one of the Pi prizes (form link is below).

👉 Entry form: https://forms.gle/t9uD88kdPpQm4WfZ7

👉 Sweepstakes rules: https://www.jeffgeerling.com/2021-sweepstakes-rules

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com

Thank the makers! All the items in this giveaway are made by people and companies who love and support open source communities, too:

  - CutiePi: https://cutiepi.io
  - Kubesail PiBox mini 2: http://pibox.io
  - Hardware Laboratory CM4Ext Nano: https://pipci.jeffgeerling.com/boards_cm/harlab-cm4-nano.html
  - Oratek TOFU: https://store.oratek.com
  - Seeed Studios CM4 Routerboard: https://www.seeedstudio.com/Rapberry-Pi-CM4-Dual-GbE-Carrier-Board-p-4874.html
  - DFRobot CM4 Router Board: https://www.dfrobot.com/product-2242.html
  - MirkoPC: https://hackaday.io/project/177626-mirkopc-cm4-carrier-board
  - SourceKit PiTray Mini: https://sourcekit.cc/#/
  - Wiretrustee SATA: https://pipci.jeffgeerling.com/boards_cm/wiretrustee-sata-4x-nas.html
  - Flirc Pi 4 Case: https://flirc.tv/more/raspberry-pi-4-case
  - Raspberry Pi Model A+: https://www.raspberrypi.com/products/raspberry-pi-1-model-a-plus/

#OSSThanks #OSSGiveaway #RaspberryPi

