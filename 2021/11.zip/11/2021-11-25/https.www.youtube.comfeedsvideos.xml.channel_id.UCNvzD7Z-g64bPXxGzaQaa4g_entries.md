# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## HORIZON FORBIDDEN WEST OPEN WORLD EXPLAINED, BATTLEFRONT 3 SHOT DOWN BY EA? & MORE
 - [https://www.youtube.com/watch?v=Sm70BRiHD8o](https://www.youtube.com/watch?v=Sm70BRiHD8o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-26 00:00:00+00:00

Sponsored by Vessi. Click https://vessi.com/gameranx and use my code GAMERANX to get $25 off of your Vessi shoes & up to 30% off select Vessi Vault items! Discount does not apply to already reduced items. Free shipping to CA, US, AUS, NZ, JP, TW, KR, SGP.

Halo Infinite multiplayer questions, EA rumors, updates on Horizon Forbidden West, and more in a week full of gaming news.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​




 ~~~~STORIES~~~~

HORIZON FORBIDDEN WEST OPEN WORLD EXPLAINED
https://blog.playstation.com/2021/11/22/horizon-forbidden-west-an-authentic-world/
+ https://www.reddit.com/r/PS4/comments/qzp4au/horizon_forbidden_west_settlements/

Battlefront 3
https://www.reddit.com/r/Games/comments/qxuw2y/battlefront_3_pitched_to_ea_but_was_shot_down/

Cyberpunk
https://www.videogameschronicle.com/news/cd-projekt-believes-cyberpunk-will-be-considered-a-very-good-game-in-the-long-run/



Harmonix/Epic 
https://www.polygon.com/22798860/epic-games-buys-harmonix-rock-band-fortnite

Halo stuff
https://gamingintel.com/it-costs-over-1000-to-buy-everything-halo-infinite-item-shop/

Hitman 3 update
https://www.ioi.dk/hitman-3-year-2/

The Resident Evil movie (Jake review)
https://youtu.be/HzjS0gPWmu8



Dead Cells
https://www.youtube.com/watch?v=rUb-6F1TV6M&t=34s

## Best BLACK FRIDAY Gaming Deals You SHOULDN'T Miss [2021]
 - [https://www.youtube.com/watch?v=oAb4D6yHhSk](https://www.youtube.com/watch?v=oAb4D6yHhSk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-25 00:00:00+00:00

Black Friday is here. Save big this holiday season with the best sales on accessories and games for Xbox Series X, PS4, PS5, Xbox, and Switch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

***All Black Friday VIDEO Game Deals*** 
https://docs.google.com/document/d/1bgHRWLb-vLm1z5K0iTLlJYQQiQWUwn0vgw9_wVFgBqQ/edit?usp=sharing
[PC, PS4, PS5, Xbox One, Xbox Series X/S, Switch Video Game Deals]

---Console Deals---
Nintendo Switch + Mario Kart 8 Deluxe (Download) + 3month Nintendo Switch Online membership - $300
https://www.bestbuy.com/site/nintendo-switch-neon-blue-neon-red-joy-con-mario-kart-8-deluxe-download-3month-nintendo-switch-online-membership-black-neon-blue-neon-red/6436769.p?skuId=6436769

Nintendo - Switch - Animal Crossing: New Horizons Edition - $300
https://www.bestbuy.com/site/nintendo-switch-animal-crossing-new-horizons-edition-32gb-console-multi/6401728.p?skuId=6401728

Xbox Series S + Fortnite + Rocket League - $300
https://www.gamestop.com/consoles-hardware/xbox-series-x%7Cs/consoles/products/microsoft-xbox-series-s-digital-edition-fortnite-and-rocket-league-system-bundle/317009.html

-------Controller Deals-------
DualSense Wireless Controller W/ NBA 2K21 Jumpstart Bundle $54.99https://direct.playstation.com/en-us/accessories/accessory/dualsense-wireless-controller-nba-2k21-jumpstart-bundle.3006696

Xbox Wireless Controller $49.99
https://www.microsoft.com/en-us/d/xbox-wireless-controller/8xn59crbsqgz

Luna Controller $49.99
https://amzn.to/3HTYQA9

Microsoft Xbox Series X, S, One controller Daystrike Camo $54.99
https://www.bestbuy.com/site/microsoft-controller-for-xbox-series-x-xbox-series-s-and-xbox-one-latest-model-daystrike-camo-special-edition/6456334.p?skuId=6456334

Razer Kishi $59.99
https://www.bestbuy.com/site/razer-kishi-for-android-xbox-gaming-controller-cloud-gaming-ready-compatible-with-most-usb-c-android-phones-black/6426253.p?skuId=6426253

Standard Xbox Series X/S,One $55.99
https://www.bestbuy.com/site/microsoft-controller-for-xbox-series-xs-and-xbox-one-usb-ccable-latest-model-black/6436824.p?skuId=6436824

Mario Kart Racing Wheel Pro Deluxe  $69.99
https://www.bestbuy.com/site/nintendo-switch-mario-kart-racing-wheel-pro-deluxe-by-hori-red/6451074.p?skuId=6451074

PowerA Enhanced Wired Controller Pikachu Grey $13.99
https://www.bestbuy.com/site/powera-enhanced-wired-controller-for-nintendo-switch-pokemon-pikachu-grey/6425379.p?skuId=6425379

PowerA Enhanced Wired Controller Mario White $13.99
https://www.bestbuy.com/site/powera-enhanced-wired-controller-for-nintendo-switch-mario-white/6425373.p?skuId=6425373



PowerA Enhanced Wired Controller Heroic Link $24.99
https://www.bestbuy.com/site/powera-enhanced-wired-controller-for-nintendo-switch-heroic-link/6472008.p?skuId=6472008

PowerA Enhanced Wired Controller Hylian Shield $22.99
https://www.bestbuy.com/site/powera-enhanced-wired-controller-for-nintendo-switch-hylian-shield/6452067.p?skuId=6452067

PowerA Nano Enhanced Wireless Controller $46.99
https://www.bestbuy.com/site/powera-nano-enhanced-wireless-controller-for-nintendo-switch-nano-grey-neon/6437355.p?skuId=6437355

Razer Wolverine Ultimate Xbox One, Series X/S, PC $99.99
https://www.bestbuy.com/site/razer-wolverine-ultimateofficially-licensed-xbox-one-wired-gaming-controllerfor-pc-xbox-one-xbox-series-x-s-black/6428345.p?skuId=6428345

PDP Wired Xbox X/S, One, PC Revenant Blue $27.99
https://www.bestbuy.com/site/pdp-wired-controller-xbox-series-xs-xbox-one-pc-revenant-blue-revenant-blue/6452824.p?skuId=6452824

Razer Wolverine V2 Wired Controller X/S, One, PC $69.99
https://www.bestbuy.com/site/razer-wolverine-v2-wired-gaming-controller-forxbox-series-xs-xbox-one-pc-withremappable-front-facing-buttons-black/6447517.p?skuId=6447517

Xbox One Wireless Controller Elite Series 2 $169.99
https://www.target.com/p/xbox-one-wireless-controller-elite-series-2/-/A-76439797#lnk=sametab

PowerA GameCube Style Wireless Controller $29.99
https://www.walmart.com/ip/PowerA-GameCube-Style-Wireless-Controller-for-Nintendo-Switch-Black/973036609

-------HEADSETS-------

Xbox Stereo Headset  X/S, One, PC Microsoft Official $49.99
https://www.bestbuy.com/site/microsoft-xbox-stereo-headset-for-xbox-series-xs-xbox-one-and-windows-10-11-devices-black/6474763.p?skuId=6474763

Xbox Stereo Headset  X/S, One, PC Microsoft Official $46.99h
ttps://amzn.to/3cPQzPG

SteelSeries Arctis 7 $119.26
https://amzn.to/2ZoLieP

Logitech G Pro X Gaming Headset $94.99
https://amzn.to/3l5X9Gk

Razer Baracudda X $70
https://amzn.to/3xlZiT8

Turtle Beach Recon 200 Gen 2 $44.95
https://amzn.to/3CS0D52

Logitech G Pro X Gaming Headset $94.99
https://amzn.to/3r81Piu

-----------

Newegg
https://www.theblackfriday.com/newegg-blackfriday.shtml
Oculus Quest 2 W/ $50 Promo Gift Card $299
MSI Pulse GL66 15.6″ Gaming Laptop $999
Gigabyte G5 15.6″ Gaming Laptop $999
ABS Master Gaming PC $1,099

