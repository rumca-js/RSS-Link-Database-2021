# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Kyle Rittenhouse's Acquittal
 - [https://www.youtube.com/watch?v=HPodw7efhfc](https://www.youtube.com/watch?v=HPodw7efhfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-26 00:00:00+00:00

Taken from JRE #1740 w/Jocko Willink:
https://open.spotify.com/episode/1utiTB2HB5GGnYGX3gtgTP?si=093a2b42cc054d6e

## Peng Shuai and China's Anti-American Propaganda
 - [https://www.youtube.com/watch?v=tuKZq5LDVP4](https://www.youtube.com/watch?v=tuKZq5LDVP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-26 00:00:00+00:00

Taken from JRE #1740 w/Jocko Willink:
https://open.spotify.com/episode/1utiTB2HB5GGnYGX3gtgTP?si=093a2b42cc054d6e

