# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## The Black Angels - El Jardín (Live on KEXP)
 - [https://www.youtube.com/watch?v=MXxTxomXlZI](https://www.youtube.com/watch?v=MXxTxomXlZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-26 00:00:00+00:00

http://KEXP.ORG presents The Black Angels performing “El Jardín” live in the KEXP studio. Recorded November 7, 2021.

Alex Maas - Vocals / Keyboard / Percussion
Christian Bland - Guitar / Backing Vocals
Jake Garcia - Guitar / Bass / Backing Vocals
Ramiro Verdooren -  Guitar / Bass / Keyboard / Backing Vocals
Stephanie Bailey - Drums

Host: Miss Ashley
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://theblackangels.com
http://kexp.org

## The Black Angels - Firefly (Live on KEXP)
 - [https://www.youtube.com/watch?v=alHnCQXtegI](https://www.youtube.com/watch?v=alHnCQXtegI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-26 00:00:00+00:00

http://KEXP.ORG presents The Black Angels performing “Firefly” live in the KEXP studio. Recorded November 7, 2021.

Alex Maas - Vocals / Keyboard / Percussion
Christian Bland - Guitar / Backing Vocals
Jake Garcia - Guitar / Bass / Backing Vocals
Ramiro Verdooren -  Guitar / Bass / Keyboard / Backing Vocals
Stephanie Bailey - Drums

Host: Miss Ashley
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://theblackangels.com
http://kexp.org

## The Black Angels - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=b9hBd4MwPcA](https://www.youtube.com/watch?v=b9hBd4MwPcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-26 00:00:00+00:00

http://KEXP.ORG presents The Black Angels performing live in the KEXP studio. Recorded November 7, 2021.

Songs:
Manipulation
Firefly
The River 
El Jardín

Alex Maas - Vocals / Keyboard / Percussion
Christian Bland - Guitar / Backing Vocals
Jake Garcia - Guitar / Bass / Backing Vocals
Ramiro Verdooren -  Guitar / Bass / Keyboard / Backing Vocals
Stephanie Bailey - Drums

Host: Miss Ashley
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://theblackangels.com
http://kexp.org

## The Black Angels - Manipulation (Live on KEXP)
 - [https://www.youtube.com/watch?v=x9JOXVwLDkc](https://www.youtube.com/watch?v=x9JOXVwLDkc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-26 00:00:00+00:00

http://KEXP.ORG presents The Black Angels performing “Manipulation” live in the KEXP studio. Recorded November 7, 2021.

Alex Maas - Vocals / Keyboard / Percussion
Christian Bland - Guitar / Backing Vocals
Jake Garcia - Guitar / Bass / Backing Vocals
Ramiro Verdooren -  Guitar / Bass / Keyboard / Backing Vocals
Stephanie Bailey - Drums

Host: Miss Ashley
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://theblackangels.com
http://kexp.org

## The Black Angels - The River (Live on KEXP)
 - [https://www.youtube.com/watch?v=NCx74O8h_X8](https://www.youtube.com/watch?v=NCx74O8h_X8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-26 00:00:00+00:00

http://KEXP.ORG presents The Black Angels performing “The River” live in the KEXP studio. Recorded November 7, 2021.

Alex Maas - Vocals / Keyboard / Percussion
Christian Bland - Guitar / Backing Vocals
Jake Garcia - Guitar / Bass / Backing Vocals
Ramiro Verdooren -  Guitar / Bass / Keyboard / Backing Vocals
Stephanie Bailey - Drums

Host: Miss Ashley
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://theblackangels.com
http://kexp.org

