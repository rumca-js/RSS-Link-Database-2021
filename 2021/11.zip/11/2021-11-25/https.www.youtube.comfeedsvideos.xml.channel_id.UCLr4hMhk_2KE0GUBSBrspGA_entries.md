# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Ile kosztuje złożenie hulajnogi elektrycznej?
 - [https://www.youtube.com/watch?v=0xDvR9bRvTo](https://www.youtube.com/watch?v=0xDvR9bRvTo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-11-25 00:00:00+00:00

Łukasz złożył hulajnogę, która ma 100 km zasięgu i rozpędza się do 55 km/h.
Więcej info na kanale Łukasza: https://bit.ly/311Y8QN

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Test hulajnogi – podjazd pod górę
00:16 Wideo z przejazdu
00:20 Skąd się wziął pomysł na zrobienie hulajnogi?
00:29 Moc hulajnogi – silnik
00:42 Czym ten model różni się od pierwszej hulajnogi?
01:02 Waga i materiały konstrukcji
01:20 Proces projektowania
02:01 Składanie hulajnogi
02:20 Produkcja i składanie ramy
02:42 Zakupione elementy pojazdu i ich cena
03:11 Akumulator i zasięg
03:31 Maksymalne prędkości na 3 trybach jazdy
03:47 Ile kosztuje cała hulajnoga?
04:14 Zasilanie i ładowanie
04:29 Hamulce
04:55 Czy składanie swojej hulajnogi elektrycznej to dobra decyzja?
05:44 Opinia po próbnej jeździe

