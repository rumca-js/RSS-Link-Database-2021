# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Thanksgiving Special 2021
 - [https://www.youtube.com/watch?v=mIvnXOOTSOA](https://www.youtube.com/watch?v=mIvnXOOTSOA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-25 00:00:00+00:00

Kyle and Ethan run down memory lane on this Thanksgiving 2021 special episode of The Bee Weekly. This is your chance to catch up with some of The Bee’s personal favorite moments from the podcast archives. Gratitude is the key to happiness, so give thanks for these hilarious moments.

This episode is brought to you by Faithful Counseling. Go to http://betterhelp.com/babylonbee for 10% off!

