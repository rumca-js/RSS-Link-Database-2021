# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## The War On Drugs - Occasional Rain (live performance for The Current)
 - [https://www.youtube.com/watch?v=aMkUXpc-F6c](https://www.youtube.com/watch?v=aMkUXpc-F6c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-25 00:00:00+00:00

The War on Drugs perform "Occasional Rain" from their 2021 record "I Don't Live Here Anymore" in a virtual session with The Current. 

Don't miss the band's full virtual session, including an interview with frontman Adam Granduciel about getting the band back together after 20 months apart, and how fatherhood has affected his creative process: https://youtu.be/2a9BKt1zbW8

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits:
Director/Editor - Ray Lynch
Audio Mixer - Austin Asvanonda 
Digital Producer, The Current - Jesse Wiza
Technical Director, The Current - Peter Ecklund

Band:
Adam Granduciel - vocals, guitar
Dave Hartley - bass, backing vocals
Robbie Bennett - keys
Charlie Hall - drums
Jon Natchez - keys, horns
Anthony LaMarca - guitar, backing vocals

