## Is my cat Turing-complete? | Belay the C++
 - [https://belaycpp.com/2021/11/24/is-my-cat-turing-complete/](https://belaycpp.com/2021/11/24/is-my-cat-turing-complete/)
 - RSS feed: https://belaycpp.com
 - date published: 2021-11-25 09:07:25.768886+00:00

Author: Chloé LourseyreEditor: Peter Fordham This article is an adaptation of a Lightning Talk I gave at CppCon2021. A link to the video will be given here as soon as it’s available…

