# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## You win this round, Samsung!
 - [https://www.youtube.com/watch?v=S90bf4bovNU](https://www.youtube.com/watch?v=S90bf4bovNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-11-26 00:00:00+00:00

This week Samsung's WearOS watches had great performance, hugely increasing WearOS market share, Samsung announced a huge new chip fab in Texas for $17b and Apple sued the NSO group, makers of the Pegasus malware. - Episode 73

---
CuriosityStream x Nebula bundle: https://curiositystream.com/techaltar 
(CS didn't sponsor this video, but they are a channel sponsor)
---

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

This video on Nebula: https://nebula.app/videos/the-friday-checkout-you-win-this-round-samsung

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:30 Release Highlights
1:21 Samsung x WearOS success
3:14 Samsung's new Texas chip fab
4:55 Apple sues NSO group (Pegasus)

