## The unbearable fussiness of the smart home - Stacey on IoT | Internet of Things news and analysis
 - [https://staceyoniot.com/the-unbearable-fussiness-of-the-smart-home/](https://staceyoniot.com/the-unbearable-fussiness-of-the-smart-home/)
 - RSS feed: https://staceyoniot.com
 - date published: 2021-11-25 06:46:49.075463+00:00

As we head into another gifting season and more and more connected devices make their way onto gift guides, I want to offer a cautionary note. The smart home is like a cat — mostly self-sufficient and nice to have, but also possessing a mind of its own that can lead to frustration and confusion […]

