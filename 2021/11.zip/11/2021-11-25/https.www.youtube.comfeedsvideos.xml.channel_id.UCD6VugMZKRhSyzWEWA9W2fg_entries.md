# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Highfleet Review | Photosensitive™ Seizure™ Edition™
 - [https://www.youtube.com/watch?v=7RUrBmXUGuU](https://www.youtube.com/watch?v=7RUrBmXUGuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2021-11-25 22:13:20+00:00

Stay at home mom DESTROYS 
people who suffer from EPILEPSY
in just 3 easy seconds.
FIND OUT HOW

Buy it on Steam (30% off until December 1st):
https://store.steampowered.com/app/1434950/HighFleet/

Enjoy. Apologies for delays.
-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

