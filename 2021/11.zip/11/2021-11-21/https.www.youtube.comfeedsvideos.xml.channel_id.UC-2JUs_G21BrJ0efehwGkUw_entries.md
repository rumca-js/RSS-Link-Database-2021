# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Permission to Dance | BTS | funk cover ft. Leone
 - [https://www.youtube.com/watch?v=qFSWsuiMCS0](https://www.youtube.com/watch?v=qFSWsuiMCS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-11-22 00:00:00+00:00

Store/Tour Tickets: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of BTS' "Permission to Dance" by Scary Pockets & Leone.

MUSICIAN CREDITS
Lead vocal: Leone
Drums: Rob Humphreys
Bass: Nick Campbell
Keys: Swatkins
Guitar: Ryan Lerman
BGVs: Moorea Masa & Therese Curatolo
Synth/Percussion: Otis McDonald

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker
Producer: Otis McDonald

VIDEO CREDITS
DP: Ricky Chavez
Editor: Adam Kritzberg

#ScaryPockets #Funk #BTS #Leone #PermissionToDance

