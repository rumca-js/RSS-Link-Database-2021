# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Selling a $2100 Sleeper PC for $20
 - [https://www.youtube.com/watch?v=9UKROsvkCGA](https://www.youtube.com/watch?v=9UKROsvkCGA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-22 00:00:00+00:00

Thanks to Micro Center for sponsoring this video!
New Customers Exclusive – Get a Free 240gb SSD at Micro Center: https://micro.center/4f7cfd

Micro Center Custom PC Builder: https://micro.center/d4704b

Micro Center gave us full reign of their store to build the sickest PC we could.. so meet our latest Sleeper PC, Francis

AMD Ryzen 7 5800X: https://micro.center/63dc12
ASRock X570M PRO4 AMD AM4 microATX Motherboard: https://micro.center/b3a298
MSI GeForce RTX 3070 Ventus 2X Graphics Card: https://micro.center/2edc7a
TeamGroup T-Force XTREEM ARGB 32GB (2 x 16GB) DDR4-4000 PC4-3200 CL18: https://micro.center/6e70ff
WD Black SN750 2TB M.2 NVMe SSD: https://micro.center/3536d4
EVGA SuperNOVA 1200P2 80 Plus Platinum ATX Fully Modular Power Supply: https://micro.center/75045
Computer Cases: https://micro.center/d2cf78
NZXT Kraken M22 120mm RGB Water Cooling Kit: https://micro.center/6bd6b7
SilverStone 1 to 2 PWM fan splitter: https://micro.center/b5c4c0

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1390366-selling-a-2100-sleeper-pc-for-20/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 - Intro to Francis
0:28 - LTT Intro
0:36 - What'll fit in Francis?
1:32 - Deciding what'll go in Francis
5:06 - Making Francis Fast
7:55 - Confirming Francis is Fast
9:49 - Setting Francis Free
11:20 - Outro (have a good life Francis)

## My GPU is 1000ft Away!
 - [https://www.youtube.com/watch?v=Iz_MPlRCbCQ](https://www.youtube.com/watch?v=Iz_MPlRCbCQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-21 00:00:00+00:00

Thanks to NZXT for sponsoring this video! Get your own custom made PC with NZXT BLD today at: https://nzxt.co/LTTBLD1121

How far is too far? We're pushing optical Thunderbolt cables to their limit to see how far we could have a PC while still gaming and see what the impacts are. 


Buy a Razer - Thunderbolt™ 4 Dock with Chroma RGB: https://geni.us/Ntxi

Buy a Corning Thunderbolt Optical Cable 10m (33ft): https://geni.us/OB4Irr

Buy a Jackery Power Station: https://geni.us/AOp2XV

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1390125-my-gpu-is-1000ft-away-sponsored/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:02 Baseline Benchmark
1:28 First 50 Meters
4:08 Another 50 Meters
7:30 ANOTHER 50 Meters
10:15 Troubleshooting
13:28 Checking out the new office
14:30 Outro

