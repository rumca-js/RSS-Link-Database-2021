# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Leila Cobo: Una Conversación Con Alt.Latino
 - [https://www.youtube.com/watch?v=tHKvLteaaB0](https://www.youtube.com/watch?v=tHKvLteaaB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-11-21 00:00:00+00:00

On Tuesday, June 15, Felix Contreras hosted a special live conversation with Billboard’s reigning Latin music expert Leila Cobo. Together they discussed what they’re anticipating to be the hottest songs of the summer, alternating playing tracks and talking trends.

