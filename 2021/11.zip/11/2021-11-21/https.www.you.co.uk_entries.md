## Fiona Bruce: ‘Sometimes I struggle not to cry’ - YOU Magazine
 - [https://www.you.co.uk/fiona-bruce-interview-2021/](https://www.you.co.uk/fiona-bruce-interview-2021/)
 - RSS feed: https://www.you.co.uk
 - date published: 2021-11-21 10:44:42.996698+00:00

FIONA BRUCE opens up to Cole Moreton about holding back the tears on live TV and the one thing she refuses to talk about – even to her family. PHOTOGRAPHS: RACHELL SMITH I laughed like a drain,’ says Fiona Bruce, her face lighting up. We don’t often see the presenter like this. We’re more used […]

