# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Pieniądze zarobisz... na Spotify
 - [https://www.youtube.com/watch?v=lhFuddd5EKo](https://www.youtube.com/watch?v=lhFuddd5EKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-11-21 00:00:00+00:00

Wtorkowa konferencja: https://pci.fnib.pl/
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Eksperyment z kciukiem w dół
01:02 Dobry wieczór
01:07 Rower podłączony do prądu
01:25 Usunięcie łapek w dół
02:15 Części zamienne do Apple
03:40 Zniżki na naprawę sprzętu na Znosne
05:05 Przesadna ekologia
05:53 Zapowiedź poradnika świątecznego
06:17 Policaj Kalifornijska szpieguje na Facebooku
06:49 Grzybki do leczenia depresji
07:40 Konferencja Człowiek dla technologii
08:26 Infekcja ucha od słuchawek Samsunga
09:42 Zarabianie na Spotify
12:16 Aplikacje śledzące partnerów
13:10 Pożegnanko
13:12 Znośnego tygodnia!

Źródła:
Sam sobie napraw iPhone'a: https://bit.ly/32nxlyP
Serwisy partnerskie akcji na Znośne: https://www.maclife.pl, https://quickfix.pl
Facebook pisze do policji w Kalifornii: https://bbc.in/3cAgr1M
Grzybki dobre na depresję: https://bit.ly/2Z7o8t6
Słuchawki Samsunga, a stan zapalny uszu: https://bit.ly/3czu80X
Spotify da zarobić podcasterom w Polsce: https://yhoo.it/3FyJTSf
Ludzie, którzy instalują oprogramowanie szpiegujące swoim partnerom: https://cnet.co/3xbicfu

