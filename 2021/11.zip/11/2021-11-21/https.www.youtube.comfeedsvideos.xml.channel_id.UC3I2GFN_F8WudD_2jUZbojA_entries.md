# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Soccer Mommy - Bloodstream (Live on KEXP)
 - [https://www.youtube.com/watch?v=yYCHtk1MftY](https://www.youtube.com/watch?v=yYCHtk1MftY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-22 00:00:00+00:00

http://KEXP.ORG presents Soccer Mommy performing “Bloodstream” live in the KEXP studio. Recorded November 1, 2021.

Sophie Allison - Guitar / Vocals
Jules Powell - Guitar
Rodrigo Avendano - Guitar / Keyboards / Samples
Rollum Haas - Drums / Samples
Nick Wiedener - Bass Guitar

Host: Cheryl Waters
Audio Engineers: Todd Dixon & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://soccermommyband.com
http://kexp.org

## Soccer Mommy - Circle The Drain (Live on KEXP)
 - [https://www.youtube.com/watch?v=dvwo42f8_zA](https://www.youtube.com/watch?v=dvwo42f8_zA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-22 00:00:00+00:00

http://KEXP.ORG presents Soccer Mommy performing “Circle The Drain” live in the KEXP studio. Recorded November 1, 2021.

Sophie Allison - Guitar / Vocals
Jules Powell - Guitar
Rodrigo Avendano - Guitar / Keyboards / Samples
Rollum Haas - Drums / Samples
Nick Wiedener - Bass Guitar

Host: Cheryl Waters
Audio Engineers: Todd Dixon & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://soccermommyband.com
http://kexp.org

## Soccer Mommy - Crawling In My Skin (Live on KEXP)
 - [https://www.youtube.com/watch?v=WS0gznOYZUw](https://www.youtube.com/watch?v=WS0gznOYZUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-22 00:00:00+00:00

http://KEXP.ORG presents Soccer Mommy performing “Crawling In My Skin” live in the KEXP studio. Recorded November 1, 2021.

Sophie Allison - Guitar / Vocals
Jules Powell - Guitar
Rodrigo Avendano - Guitar / Keyboards / Samples
Rollum Haas - Drums / Samples
Nick Wiedener - Bass Guitar

Host: Cheryl Waters
Audio Engineers: Todd Dixon & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://soccermommyband.com
http://kexp.org

## Soccer Mommy - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=aLq2z5CBwFw](https://www.youtube.com/watch?v=aLq2z5CBwFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-22 00:00:00+00:00

http://KEXP.ORG presents Soccer Mommy performing live in the KEXP studio. Recorded November 1, 2021.

Songs:
Bloodstream
Circle The Drain
Royal Screw Up
Crawling In My Skin

Sophie Allison - Guitar / Vocals
Jules Powell - Guitar
Rodrigo Avendano - Guitar / Keyboards / Samples
Rollum Haas - Drums / Samples
Nick Wiedener - Bass Guitar

Host: Cheryl Waters
Audio Engineers: Todd Dixon & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://soccermommyband.com
http://kexp.org

## Soccer Mommy - Royal Screw Up (Live on KEXP)
 - [https://www.youtube.com/watch?v=ztD7rcuZuzQ](https://www.youtube.com/watch?v=ztD7rcuZuzQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-22 00:00:00+00:00

http://KEXP.ORG presents Soccer Mommy performing “Royal Screw Up” live in the KEXP studio. Recorded November 1, 2021.

Sophie Allison - Guitar / Vocals
Jules Powell - Guitar
Rodrigo Avendano - Guitar / Keyboards / Samples
Rollum Haas - Drums / Samples
Nick Wiedener - Bass Guitar

Host: Cheryl Waters
Audio Engineers: Todd Dixon & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://soccermommyband.com
http://kexp.org

