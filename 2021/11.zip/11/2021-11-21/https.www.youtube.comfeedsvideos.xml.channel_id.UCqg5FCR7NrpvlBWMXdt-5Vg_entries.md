# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Elden Ring Feels Like From Software’s Greatest Hits Album | The Takeaway
 - [https://www.youtube.com/watch?v=-zllJKFXOpw](https://www.youtube.com/watch?v=-zllJKFXOpw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-11-22 00:00:00+00:00

You’d be hard-pressed to find a game as unanimously anticipated as Elden Ring. From Software’s first foray into a true open world tantalized with its teaser a few years back, grew in mystique after years of radio silence, and has now utterly enraptured pretty much everybody who had a chance to dabble in its recent limited Network Test, myself included. 

And in my mind, the reason for that is pretty simple -- Elden Ring feels like a Greatest Hits collection of everything that From Soft was done over the past decade, set in a dangerous and alluring open-world, and all while somehow avoiding any of the frustrations that sometimes come with…well…all of those things.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## How Sekiro Perfected Dueling and Tried to Change the Souls Formula
 - [https://www.youtube.com/watch?v=kHAGWu4L8ls](https://www.youtube.com/watch?v=kHAGWu4L8ls)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-11-22 00:00:00+00:00

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

In todays episode J delves into the designs of Sekiro: Shadows Die Twice. its unimaginable heights, tragic lows and how it taught him to overcome his dyslexia.

Timestamps:
Intro - 00:00
Overview - 00:30
How Sekiro Taught Me To Read - 01:10
Trash Tutorials - 06:08
Cunning Combat - 09:05
Stupid Stealth - 12:00
Prayerful Progression - 14:15

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

