# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Reality of Thanksgiving Hate EXPOSED
 - [https://www.youtube.com/watch?v=zso27QjgCKo](https://www.youtube.com/watch?v=zso27QjgCKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-22 00:00:00+00:00

What’s with people who hate the greatest holiday of the year? The real truth of the anti-Thanksgiving movement is revealed in this video.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

