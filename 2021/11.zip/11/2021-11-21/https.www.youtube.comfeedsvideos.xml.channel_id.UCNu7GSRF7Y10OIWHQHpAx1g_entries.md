# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Nie wpuścili Tomka Surdela do Nikaragui - dlaczego?
 - [https://www.youtube.com/watch?v=ijKXfD-hIrs](https://www.youtube.com/watch?v=ijKXfD-hIrs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2021-11-21 00:00:00+00:00

Artykuł Tomka Surdela o Nikaragui: https://wyborcza.pl/7,75399,27772913,w-niedziele-wybory-w-nikaragui-zwyciezca-jest-znany.html

Podcast Działu Zagranicznego o Nikaragui:
https://www.dzialzagraniczny.pl/2020/04/jak-rewolucjonista-zostal-dyktatorem-ktorego-sam-obalil-dzial-zagraniczny-podcast-odcinek-specjalny005/

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Sklep: bezplanu.com
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv

Czas akcji: listopad 2021r.

