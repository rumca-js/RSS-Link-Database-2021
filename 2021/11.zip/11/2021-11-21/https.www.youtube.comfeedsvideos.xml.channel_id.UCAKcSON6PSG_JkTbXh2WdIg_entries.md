# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## The War On Drugs - I Don't Live Here Anymore (live performance for The Current)
 - [https://www.youtube.com/watch?v=71SBkIiPMes](https://www.youtube.com/watch?v=71SBkIiPMes)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-22 00:00:00+00:00

The War on Drugs perform the title track from their 2021 record "I Don't Live Here Anymore" in a virtual session with The Current. 

Don't miss their full virtual session, including an interview with Adam Granduciel of The War on Drugs about getting the band back together after 20 months apart, and how fatherhood has affected his creative process: https://youtu.be/2a9BKt1zbW8

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits:
Director - Cody William Smith
Editor -  Danny Garfield
Audio Mix - Austin Asvanonda 
Camera Operators - Paolo Arriola and Keith Pratt
Gaffer - Christopher Oh
Technical Director for The Current - Peter Ecklund
Producer for The Current - Jesse Wiza

Band:
Adam Granduciel - vocals, guitar
Dave Hartley - bass, backing vocals
Robbie Bennett - keys
Charlie Hall - drums
Jon Natchez - keys, horns
Anthony LaMarca - guitar, backing vocals
Olivia Kaplan - backing vocals
Miya Folick - backing vocals

## The War on Drugs - Change (live performance for The Current)
 - [https://www.youtube.com/watch?v=pyeZ2-JJ_-Y](https://www.youtube.com/watch?v=pyeZ2-JJ_-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-21 00:00:00+00:00

The War on Drugs perform "Change" from their 2021 record "I Don't Live Here Anymore" in a virtual session with The Current. 

Don't miss the band's full virtual session, including an interview with frontman Adam Granduciel about getting the band back together after 20 months apart, and how fatherhood has affected his creative process: https://youtu.be/2a9BKt1zbW8

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits:
Director/Editor - Ray Lynch
Audio Mixer - Austin Asvanonda 
Digital Producer, The Current - Jesse Wiza
Technical Director, The Current - Peter Ecklund

Band:
Adam Granduciel - vocals, guitar
Dave Hartley - bass, backing vocals
Robbie Bennett - keys
Charlie Hall - drums
Jon Natchez - keys, horns
Anthony LaMarca - guitar, backing vocals

