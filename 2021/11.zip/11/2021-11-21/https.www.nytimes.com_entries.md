## Who, and Where, Is Chinese Tennis Star Peng Shuai? - The New York Times
 - [https://www.nytimes.com/2021/11/21/world/asia/where-is-peng-shuai.html](https://www.nytimes.com/2021/11/21/world/asia/where-is-peng-shuai.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2021-11-21 18:40:59.252767+00:00

A blackout within China on discussion of the tennis star’s #MeToo allegations has not been able to silence a global chorus of concern for her safety.

