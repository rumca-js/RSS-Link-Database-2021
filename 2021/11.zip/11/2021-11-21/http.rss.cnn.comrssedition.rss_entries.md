# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Two missionaries released in Haiti after group kidnapping
 - [https://www.cnn.com/2021/11/21/americas/haiti-missionaries-two-released-intl-latam/index.html](https://www.cnn.com/2021/11/21/americas/haiti-missionaries-two-released-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 23:22:42+00:00

Two missionaries kidnapped in Haiti over a month ago have been released, according to a statement by the US-based Christian Aid Ministries. CNN has not been able to independently confirm their release.

## Missing tennis star appears on video call with Olympic and Chinese officials
 - [https://www.cnn.com/collections/china-intl-112121/](https://www.cnn.com/collections/china-intl-112121/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 23:11:02+00:00



## Missing tennis star appears on video call with Olympic and Chinese officials
 - [https://www.cnn.com/2021/11/21/sport/peng-shuai-video-call-thomas-bach-spt-intl/index.html](https://www.cnn.com/2021/11/21/sport/peng-shuai-video-call-thomas-bach-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 21:38:46+00:00

International Olympic Committee (IOC) president Thomas Bach held a video phone call with three-time Olympian Peng Shuai, the Olympics governing body announced on Sunday.

## Residents evacuated from Italian island Vulcano over carbon dioxide levels
 - [https://www.cnn.com/2021/11/21/europe/italy-vulcano-island-residents-evacuated-intl-scli/index.html](https://www.cnn.com/2021/11/21/europe/italy-vulcano-island-residents-evacuated-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 21:33:52+00:00

Most of the 250 permanent residents of a volcanic Italian island have been told to evacuate after levels of carbon dioxide in the air spiked dangerously, causing respiratory problems to people and their pets.

## Justin Bieber called on to cancel Saudi Arabia concert by slain journalist's fiancée
 - [https://www.cnn.com/2021/11/21/business/justin-bieber-saudi-arabia-concert-jamal-khashoggi/index.html](https://www.cnn.com/2021/11/21/business/justin-bieber-saudi-arabia-concert-jamal-khashoggi/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 21:17:13+00:00

The fiancée of murdered journalist Jamal Khashoggi wrote an open letter published by the Washington Post calling for Justin Bieber to cancel his upcoming concert in Saudi Arabia.

## Tiger Woods posts first video taking practice swings since car accident in February
 - [https://www.cnn.com/2021/11/21/golf/tiger-woods-posts-video-taking-golf-shot-spt-intl/index.html](https://www.cnn.com/2021/11/21/golf/tiger-woods-posts-video-taking-golf-shot-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 18:54:57+00:00

Golfing legend Tiger Woods posted a short video of himself taking a practice shot out on a golf course on Sunday.

## Adele wants you to listen to her album in order, and Spotify agrees
 - [https://www.cnn.com/2021/11/21/entertainment/adele-spotify-music-streaming-album-shuffle-scli-intl/index.html](https://www.cnn.com/2021/11/21/entertainment/adele-spotify-music-streaming-album-shuffle-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 17:58:23+00:00

When it comes to her art, Adele has a certain way she likes things to be done. The singer believes the tracks on an album should be listened to in their order of arrangement -- and now she's got streaming giant Spotify onside.

## Sudan's military reinstates prime minister ousted after last month's coup
 - [https://www.cnn.com/2021/11/21/africa/sudan-military-chief-hamdok-deal-intl/index.html](https://www.cnn.com/2021/11/21/africa/sudan-military-chief-hamdok-deal-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 17:22:10+00:00

Sudan's military chief and the prime minister he overthrew last month have reached a deal for the reinstatement of the premier and the release of jailed political detainees, mediators said Sunday.

## Violent clashes erupt during anti-lockdown demonstrations in Europe
 - [https://www.cnn.com/2021/11/21/europe/europe-lockdown-protests-violence-intl/index.html](https://www.cnn.com/2021/11/21/europe/europe-lockdown-protests-violence-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 17:11:49+00:00

Protests in European countries against new Covid-19 restrictions turned violent over the weekend as cases continue to rise in the continent.

## Lewis Hamilton wins Qatar Grand Prix
 - [https://www.cnn.com/2021/11/21/motorsport/lewis-hamilton-wins-qatar-gp-spt-intl/index.html](https://www.cnn.com/2021/11/21/motorsport/lewis-hamilton-wins-qatar-gp-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 16:17:11+00:00

Lewis Hamilton put in a faultless drive to win Sunday's inaugural Qatar Grand Prix and cut Max Verstappen's championship lead to just eight points.

## There's nothing more frightening in America today than an angry White man
 - [https://www.cnn.com/2021/11/20/us/angry-white-men-trials-blake-cec/index.html](https://www.cnn.com/2021/11/20/us/angry-white-men-trials-blake-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 15:14:08+00:00

The Brute. The Buck. And, of course, the Thug.

## 'SNL' has Judge Jeanine go over the Kyle Rittenhouse verdict and a chat with Donald Trump
 - [https://www.cnn.com/2021/11/21/media/snl-judge-jeanine-kyle-rittenhouse/index.html](https://www.cnn.com/2021/11/21/media/snl-judge-jeanine-kyle-rittenhouse/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 15:05:21+00:00

There was a lot of news to cover from this week, and "Saturday Night Live" had its Judge Jeanine take it all on.

## Arsenal boss explains fiery clash with Jurgen Klopp during defeat to Liverpool
 - [https://www.cnn.com/2021/11/21/football/mikel-arteta-jurgen-klopp-touchline-row-spt-intl/index.html](https://www.cnn.com/2021/11/21/football/mikel-arteta-jurgen-klopp-touchline-row-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 14:52:37+00:00

Arsenal boss Mikel Arteta played down his furious touchline row with Liverpool head coach Jurgen Klopp during the Gunners' 4-0 defeat at Anfield on Saturday.

## Manchester United manager out after club suffered humiliating Premier League defeat
 - [https://www.cnn.com/2021/11/21/football/ole-gunnar-solskjaer-manchester-united-departure-spt-intl/index.html](https://www.cnn.com/2021/11/21/football/ole-gunnar-solskjaer-manchester-united-departure-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 12:15:04+00:00

Manchester United have confirmed the departure of manager Ole Gunnar Solskjaer, one day after the club suffered a humiliating 4-1 Premier League defeat at Watford.

## The victims of the Belarus border crisis were obvious. For Poland's government, it was a useful distraction
 - [https://www.cnn.com/2021/11/21/europe/poland-border-crisis-politics-intl-cmd/index.html](https://www.cnn.com/2021/11/21/europe/poland-border-crisis-politics-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 08:51:27+00:00

It was clear who the losers were in the dispute between Poland and Belarus. The thousands of migrants who became stranded on the border in freezing conditions had their dreams of a new future in Europe dashed, and some are now being repatriated to their home countries. But for Poland's government, the crisis helped to divert attention from a series of uncomfortable issues.

## Meet the 70-year-old who is believed to be the oldest woman to climb Yosemite's El Capitan
 - [https://www.cnn.com/2021/11/21/us/70-year-old-woman-oldest-yosemite-el-capitan/index.html](https://www.cnn.com/2021/11/21/us/70-year-old-woman-oldest-yosemite-el-capitan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 06:00:56+00:00

Dierdre Wolownick dreamed of watching the sunset from the top of Yosemite National Park's famous El Capitan rock formation in California.

## She died from a snakebite. But the real killer was her husband
 - [https://www.cnn.com/2021/11/20/india/india-snake-cobra-murder-intl-hnk-dst/index.html](https://www.cnn.com/2021/11/20/india/india-snake-cobra-murder-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-21 01:03:42+00:00

Uthra's mother found her daughter lying motionless in bed at the family home, her left arm dotted with blood.

