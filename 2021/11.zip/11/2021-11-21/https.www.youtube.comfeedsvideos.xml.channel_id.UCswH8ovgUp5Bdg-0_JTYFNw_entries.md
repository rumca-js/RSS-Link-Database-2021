# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## "You Can KEEP Your SH*TTY JOB!!" Millions More QUIT Work
 - [https://www.youtube.com/watch?v=r7PnBcmOaOk](https://www.youtube.com/watch?v=r7PnBcmOaOk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-11-22 00:00:00+00:00

A sign left by Chipotle employees who walked out on their jobs has gone viral. As the Great Resignation continues, what does this mean regarding the power of workers when they come together?
#TheGreatResignation #Chipotle #strikes #quit 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

## “Paid Millions To LIE??” Is THIS Why MSM Is DYING??!
 - [https://www.youtube.com/watch?v=Ca-AjgtkpIs](https://www.youtube.com/watch?v=Ca-AjgtkpIs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-11-21 00:00:00+00:00

As corporate news continues to lose ratings and the trust of the public, what does Brian Williams's exit from MSNBC tell us about the future of mainstream media?
#MainstreamMedia #MSNBC #CNN #Fox #brianwilliams 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

