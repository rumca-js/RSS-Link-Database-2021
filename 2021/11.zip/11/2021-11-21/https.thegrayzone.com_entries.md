## Documents show Bill Gates has given $319 million to media outlets to promote his global agenda
 - [https://thegrayzone.com/2021/11/21/bill-gates-million-media-outlets-global-agenda/](https://thegrayzone.com/2021/11/21/bill-gates-million-media-outlets-global-agenda/)
 - RSS feed: https://thegrayzone.com
 - date published: 2021-11-21 07:30:23+00:00

Documents show Bill Gates has given $319 million to media outlets to promote his global agenda

