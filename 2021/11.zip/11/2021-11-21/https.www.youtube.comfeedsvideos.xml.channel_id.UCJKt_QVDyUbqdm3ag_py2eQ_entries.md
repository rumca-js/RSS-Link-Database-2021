# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: AceMan - Invocation (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=ZBuI-8FdjTY](https://www.youtube.com/watch?v=ZBuI-8FdjTY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-11-21 00:00:00+00:00

"Invocation" by AceMan (Jakub Szelag). Art "Foreign Side" (1993) by Bridgeclaw/Iris.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 26 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: mA2E & AceMan - Joyful Trip (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=V-BcS4nIK1I](https://www.youtube.com/watch?v=V-BcS4nIK1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-11-21 00:00:00+00:00

"Joyful Trip" (2021) by mA2E & AceMan/Resistance (Stian Gudbrandsen & Jakub Szelag). Art "Still Moving" by Lunix/Latex^Planet Jazz, 6th at Gerp 2014.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 8 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

