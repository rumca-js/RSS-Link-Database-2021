## Bill of the Month: Critically ill woman skips ER after spouse's costly stitches : Shots - Health News : NPR
 - [https://www.npr.org/sections/health-shots/2021/11/19/1056866145/expensive-er-stitches-skip-care-bill-of-the-month](https://www.npr.org/sections/health-shots/2021/11/19/1056866145/expensive-er-stitches-skip-care-bill-of-the-month)
 - RSS feed: https://www.npr.org
 - date published: 2021-11-21 09:17:55.518403+00:00

With few options for health care in their rural community, a Tennessee couple's experience with one outrageous bill could have led to a deadly delay when they needed help the most.

