# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Martin Lange - Kłamiesz - live MUZO.FM
 - [https://www.youtube.com/watch?v=KJDCTa2uibk](https://www.youtube.com/watch?v=KJDCTa2uibk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2021-11-22 00:00:00+00:00

Martin Lange na żywo w MUZO.FM. Utwór Kłamiesz zapowiada debiutancki album duetu Martin Lange. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Martin Lange: http://www.facebook.com/martinlangeofficial
Instagram Martin Lange: http://www.instagram.com/martin_lange_official
Instagram: http://www.instagram.com/muzofm 
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

