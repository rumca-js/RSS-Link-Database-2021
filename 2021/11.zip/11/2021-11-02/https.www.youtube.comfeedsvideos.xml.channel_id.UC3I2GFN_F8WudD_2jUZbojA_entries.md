# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ora The Molecule - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=LjzoWzjYPhY](https://www.youtube.com/watch?v=LjzoWzjYPhY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-03 00:00:00+00:00

http://KEXP.ORG presents Ora The Molecule sharing a live performance recorded exclusively for KEXP and talking to DJ Troy Nelson. Recorded October 18, 2021.

Songs:
Creator
Sugar
The Ball
Silence 
Helicopter 

Session recorded at Gamle rådhus in Oslo, Norway
Director: Fredrik Harper
Director of Photography: Sigurd Neby
1st AC: Emilie Solberg
Best Boy / Live Light: Mikkel Foss
Sound Technician: Marius Steinveg
Tech. Assistant: Fredrik Langbraaten
Prod. Assistant: Philip Wergeland Fjeller & Iver Nicolai Haugsvær
Gear: Krypton Film
Production: VERY Agency

Violin 1: Susanne Schjelderup Olsholt 
Violin 2: Lone Meinich
Piano, Clarinet & Keyboard: Lotta Karlsson 
Drums: Anna Bjørk
Saxophone: Mor Efroney 
Vocals & Composition: Nora Schjelderup

With support from Fond For Lyd & Bilde

https://www.orathemolecule.com
http://kexp.org

