# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Why Two Classes of Citizens is a GREAT Idea!
 - [https://www.youtube.com/watch?v=LJOwr7LhSwA](https://www.youtube.com/watch?v=LJOwr7LhSwA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-11-03 00:00:00+00:00

Grab your Magnesium Breakthrough at https://magnesiumbreakthrough.com/jp
Use Code "JP2021" For a Deal

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Why creating two classes of citizens is a GREAT idea! Mandates that create a lower class a citizen helps protect people from others who are worse than them.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

