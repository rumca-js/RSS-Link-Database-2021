# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## I Created an App That DESTROYS Scam Comments (Because YouTube Wouldn't) - OUTDATED, READ DESCRIPTION
 - [https://www.youtube.com/watch?v=-vOakOgYLUI](https://www.youtube.com/watch?v=-vOakOgYLUI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-11-03 00:00:00+00:00

⚠️READ THIS⚠️: This video is very outdated and shows only a very early version of the program. I have added MANY new features, see the more recent demo video here: https://youtu.be/2tRppXW_aKo
The App ⇨ https://github.com/ThioJoe/YouTube-Spammer-Purge

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - The Spammer Problem
1:40 - RANT 😡
4:20 - Quick Intro to the Demo
4:41 - Demo: Important Download Info
5:27 - Demo: Scanning an Entire Channel
8:17 - Demo: Scanning a Single Video
9:07 - Demo: Deleting the Found Comments
10:12 - Demo: Scanning Top Level Comments
11:33 - Required Setup: Getting an API Key
17:33 - Spread the Word

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

