# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## The WORST Fantasy Fans
 - [https://www.youtube.com/watch?v=O8n-wDfzWLg](https://www.youtube.com/watch?v=O8n-wDfzWLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-11-03 00:00:00+00:00

My take on the WORST fantasy fans I come across. 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## Skyrim Anniversary Edition!♻️Witcher Season 2⚔️-FANTASY NEWS
 - [https://www.youtube.com/watch?v=YQsw2TfwQ_k](https://www.youtube.com/watch?v=YQsw2TfwQ_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-11-02 00:00:00+00:00

Let's talk about the fantasy news :) 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Intro

00:33 The Oleander Sword: https://twitter.com/orbitbooks/status/1454093260247519235?t=h44YJyPKTDTouwbnR6-kNg&s=19 

01:14 The Justice of Kings: https://www.instagram.com/p/CVfsi0jt0kd/?utm_medium=copy_link 

01:25 Rebel’s Creed Audiobook

01:38 Attack the Block 2: https://nordic.ign.com/attack-the-block-2/50971/news/attack-the-block-2-planned-to-go-into-production-in-2022 

02:38 Witcher Season 2 Trailer: https://www.youtube.com/watch?v=TJFVV2L8GKs&ab_channel=Netflix 

03:47 Subnautica Bought: https://www.ign.com/articles/pubg-parent-company-buys-subnautica-studio 

04:34 Wheel of Time Leaks

05:02 Wheel of Time Cast Interviews: https://www.youtube.com/watch?v=xcS3_LnkYv4&ab_channel=IGN 

05:29 Prince of Persia delay: https://www.siliconera.com/prince-of-persia-sands-of-time-remake-delayed-again/ 

06:42 Skyrim again: https://www.youtube.com/watch?v=Mc2A6qmvWj8&ab_channel=IGN 

07:46 Netflix Bid: https://www.yahoo.com/entertainment/netflix-bid-fort-monmouth-army-010947420.html 

09:02 HBO Box Office: https://www.hollywoodreporter.com/business/business-news/warnermedias-project-popcorn-box-office-hbo-max-experiment-gets-mixed-results-1235037096/ 

10:07 Monster Hunter VR: https://www.siliconera.com/universal-studios-japan-monster-hunter-attraction-will-let-you-hunt-in-vr/ 

#Witcher
#WheelOfTime
#Skyrim

