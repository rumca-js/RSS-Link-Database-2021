# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Secret Service Agent Spotted Carrying Diaper Bag
 - [https://www.youtube.com/watch?v=tUkUuNxg31s](https://www.youtube.com/watch?v=tUkUuNxg31s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-03 00:00:00+00:00

Did Joe Biden poop his pants? An investigative report.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Two Christian Guys Learn about the Birds and the Bees| The Most Awkward Moments From The Interview
 - [https://www.youtube.com/watch?v=ieNj82L16hg](https://www.youtube.com/watch?v=ieNj82L16hg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-03 00:00:00+00:00

Kyle and Ethan, two Christian guys from The Babylon Bee, talk to sex neuroscientist Debra Soh about the birds and the bees and it's not awkward at all. 

We can't think of a better interviewing team than these two guys, so here are the most awkward moments from our interview with sexpert Debra Soh.

You can view the whole  interview here: https://www.youtube.com/watch?v=YpjINgYWHZ4

## Sexpert Debra Soh Talks To Christian Prudes At The Babylon Bee
 - [https://www.youtube.com/watch?v=YpjINgYWHZ4](https://www.youtube.com/watch?v=YpjINgYWHZ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-02 00:00:00+00:00

Sexpert Debra Soh joins awkward Christian prudes at The Babylon Bee to talk about sex, gender, and wokeness. Dr. Debra Soh is a sex neuroscientist, the author of The End of Gender and the host of The Debra Soh Podcast. She has appeared on The Megyn Kelly Show, Real Time with Bill Maher, the Joe Rogan Experience twice, and recently spoke at the Oxford Union.

Buy our new book here: https://www.amazon.com/Babylon-Bee-Guide-Wokeness/dp/1684512719

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Babylon Bee Live Stream Q & A
 - [https://www.youtube.com/watch?v=wUEOYaCyFx4](https://www.youtube.com/watch?v=wUEOYaCyFx4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-02 00:00:00+00:00

Buy our book here
https://www.amazon.com/Babylon-Bee-Guide-Wokeness/dp/1684512719

