# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## South Africa's Mafia is ridiculous
 - [https://www.youtube.com/watch?v=JsIyEmrc8QI](https://www.youtube.com/watch?v=JsIyEmrc8QI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-11-02 00:00:00+00:00

Healthy cereal that tastes too good to be true: Get $5 OFF with code JAKETRAN at https://magicspoon.com/jaketran 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time. 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
🍔 Subscribe to our other channel @EvilFoodSupply, where we expose all the evils of our modern diet ➡️ https://jake.yt/evilfood
📸 Follow me on IG for a chance to win $1,000: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran
💬 Join the community Discord: http://discord.gg/BmK8EnQ

💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎵 Get unlimited royalty-free music for your videos with Epidemic Sound! ➡️ https://share.epidemicsound.com/jaketran

🍿 OUR MOST VIRAL VIDEOS: 
Nestlé: The Most Evil Business in the World https://youtu.be/rj6JOKrL_vg
BlackRock: The Company that Owns the World https://youtu.be/1n4zkdfKUAE
Recycling is literally a scam https://youtu.be/LELvVUIz5pY
Why do Chinese Billionaires Keep Disappearing? https://youtu.be/qyMsrgI7-_s

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/3nR6n9W

-----------------------

-----------------------
Aviino - I Miss the Magic https://chll.to/1ba5eeed

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

