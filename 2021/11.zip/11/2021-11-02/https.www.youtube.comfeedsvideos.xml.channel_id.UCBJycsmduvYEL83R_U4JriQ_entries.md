# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## AirPods 3 Review: Easy Mode!
 - [https://www.youtube.com/watch?v=LcI6F_GPwfE](https://www.youtube.com/watch?v=LcI6F_GPwfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-11-02 00:00:00+00:00

AirPods 3 are here, but be careful. The walls around the garden are higher than ever.
AirPods Pro: https://amzn.to/3CECtMh
That shirt: Coming soon! http://shop.MKBHD.com
AirPods case: https://dbrand.com/airpods-3

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Headphones provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

