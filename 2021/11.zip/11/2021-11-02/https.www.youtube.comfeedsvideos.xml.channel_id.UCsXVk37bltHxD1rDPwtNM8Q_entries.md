# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## You Are Immune Against Every Disease
 - [https://www.youtube.com/watch?v=LmpuerlbJu0](https://www.youtube.com/watch?v=LmpuerlbJu0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2021-11-02 00:00:00+00:00

Order IMMUNE here: https://kgs.link/ImmuneBook – It’s available in English and German and at online retailers it should be available in pretty much all countries too.

Sources & further reading: https://sites.google.com/view/sources-immune2/

You are not a person, you are a planet, made of roughly 40 trillion cells. There is so much of you, that if your cells were human-sized, you would be as big as  20 Mount Everests. For your creepy-crawly inhabitants, this makes your body an ecosystem, rich in resources and warmth and space. A perfect place to move into and have a family. While some of these guests are welcome, most are not. Your immune system is the guardian of this planet, the force tasked with protecting yourself against the constant danger of invasion.

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ https://kgs.link/shop-153  
Join the Patreon Bird Army 🐧  https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:
Soundcloud: https://bit.ly/3mt6Rn0
Bandcamp: https://bit.ly/317OtYC

If you want to help us caption this video, please send subtitles to subtitle@kurzgesagt.org
You can find info on what subtitle files work on YouTube here:
https://support.google.com/youtube/answer/2734698?hl=en-GB&ref_topic=7296214
Thank you!

🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons (from http://kgs.link/patreon) who support us every month and made this video possible:
Hex5ter 99, Sheeran, Shaun Loh, Umo Jami, Claudio Catarinella, Noah Costello, Dylan West, Kyla de Villa, Alex Graham, Larry Apolonio, The Pixel Life, Douglas Steel, Bernhard Wiedemann, Ryantsang, Michael Enrico, JV, Mark Goldberg, Patryk Borkowski, Pilar Amador Cortés, Rafi Khan, Val, Egidijus Grygolaitis, Kageetai, Yasmin Muryadi, Elyse Endlich, Liam Sheppard, Henrique Borsatto de Campos, Corheu, PicaHud, ATTILA VONDORKOVICS, Jessica Abood, Kim Martin Jensen, Christian Larmann, Gentatsu Sakakibara, Red Ryan, Jazz, Iain Cuthbertson, Ben Price, Kyle T David, Shia Labeouf, Fizzonaut, Leopold Kamp, Vaccineman, Shuder, Chio Verastegui, Buff Skeleton, Steven Drovie, Elric Zhang, Petru Cotarcea, Van Nels Dantas, Marvin Heintze, Dwayne Sinclair, Jesus Torres, ApocryphalDNR, jdf, Lex Lehmann, Peyton Drouhard, Exordin, Eduardo Gonzalez, Energy Transformation with Sierra Reed, Elías Natán Jiménez Alvarado, Alex AM, Erebus GAME, Rahul Chandra, Ass Hat, Chris Lihosit, Hero Luu, Matthew Evans, Isaac Griess, Flynn, Hans, Eduard S, Yorick Terweijden, Alexander Ottinger, Maxley Fraser, Anna Parfenova, Fame and fortune guaranteed in the state of Tintucky, Kevin Meyers, Travis Agaman, Pablo Corredor, Umberto Badalin, Marton Csikos, AquisM

