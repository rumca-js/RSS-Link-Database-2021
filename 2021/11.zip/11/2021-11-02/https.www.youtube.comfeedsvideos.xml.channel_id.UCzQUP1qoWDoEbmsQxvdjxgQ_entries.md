# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Remembers Norm Macdonald
 - [https://www.youtube.com/watch?v=yhs2grce07Y](https://www.youtube.com/watch?v=yhs2grce07Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-03 00:00:00+00:00

Taken from JRE #1728 w/Ari Shaffir, Shane Gillis & Mark Normand:
https://open.spotify.com/episode/033bxIFePCK1JIy3wiBxBL?si=c534a0715ead40b4

## Shane Gillis & Mark Normand Share Louis CK Stories
 - [https://www.youtube.com/watch?v=x0ft032W--4](https://www.youtube.com/watch?v=x0ft032W--4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-03 00:00:00+00:00

Taken from JRE #1728 w/Ari Shaffir, Shane Gillis & Mark Normand:
https://open.spotify.com/episode/033bxIFePCK1JIy3wiBxBL?si=c534a0715ead40b4

