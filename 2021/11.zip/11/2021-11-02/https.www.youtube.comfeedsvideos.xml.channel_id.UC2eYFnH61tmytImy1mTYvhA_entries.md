# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Is "Minimalist" living in a Van a good plan?
 - [https://www.youtube.com/watch?v=rJJH-tQIBn4](https://www.youtube.com/watch?v=rJJH-tQIBn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-11-03 00:00:00+00:00

Millennials be like:
Living in a pod ➡️ Angry Soyjack
Living in a pod with wheels ➡️ Happy Soyjack with gaping mouth

My website: https://lukesmith.xyz
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

## Why Should Bitcoin Be Valuable?
 - [https://www.youtube.com/watch?v=4v67cONO7k4](https://www.youtube.com/watch?v=4v67cONO7k4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-11-02 00:00:00+00:00

Responding to a real life question, why should Bitcoin be valuable at all? Doesn't it "not do anything?"

Here I discuss the ramifications of a digitally-based world financial system and what it means for bitcoin price. Bitcoin can not only be used as a store of value to replace gold, but can be used to write higher-level applications on it to make trustless and peer-to-peer financial derivatives, which could soak up obscene amounts of the financial soystem. The market cap of Bitcoin has astronomical potential, and owning bitcoin means having a permanent share of this system on the ground level.

My website: https://lukesmith.xyz
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

