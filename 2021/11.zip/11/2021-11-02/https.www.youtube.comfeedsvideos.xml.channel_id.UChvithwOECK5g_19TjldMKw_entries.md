# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## China's Missing Tennis Star Scandal Has a Deeper Meaning
 - [https://www.youtube.com/watch?v=zJnnjFitUpA](https://www.youtube.com/watch?v=zJnnjFitUpA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2021-11-03 00:00:00+00:00

China's tennis player Peng Shuai just made a post on Weibo aimed at taking down one of the biggest CCP officials, Zhang Gaoli, with allegations abuse and affairs. This wouldn't be the biggest deal in the world in other countries, but in China, this can change everything. It's making massive waves right now on the ground in China. The CCP is doing everything they can to scramble to cover it up. 

The artist of the paintings - Please follow him on Instagram 
Hans Lundgren https://www.instagram.com/hanslgl 

R*** Ape and the Beach Monkeys (Oil Painting)

https://opensea.io/assets/0x495f947276749ce646f68ac8c248420045cb7b5e/87412129735930572248537187615162728465212161684844466928588130103886191001601

R*** Ape and the Beach Monkeys (Cartoon Sketch)

https://opensea.io/assets/0x495f947276749ce646f68ac8c248420045cb7b5e/87412129735930572248537187615162728465212161684844466928588130104985702629377

Two clips of Chinese government area from China Observer - (Great Channel)
https://www.youtube.com/channel/UCT2kPBcD6tXn8TP_aV7BmgA

Inty tipped me off about this story, his channel is awesome - 
https://www.youtube.com/channel/UC2g9btulOWHQHCev1Q8sA6A/videos


◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats

Citations for the video - 

https://worldpopulationreview.com/country-rankings/median-income-by-country
https://www.cafonline.org/about-us/publications/2021-publications/caf-world-giving-index-2021
https://www.cfr.org/legal-barriers/country-rankings/chn/
http://www.ibe.unesco.org/en/resources?search_api_views_fulltext=%22WDE%202006%20index
https://www.who.int/healthinfo/paper30.pdf
https://worldpopulationreview.com/country-rankings/freedom-index-by-country
https://freedomhouse.org/country/china/freedom-world/2021
https://www.asherfergusson.com/lgbtq-travel-safety/

