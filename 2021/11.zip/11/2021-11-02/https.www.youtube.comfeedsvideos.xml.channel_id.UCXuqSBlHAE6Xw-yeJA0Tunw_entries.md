# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## BLOAT is killing your FPS
 - [https://www.youtube.com/watch?v=yVNkMNVv4Y4](https://www.youtube.com/watch?v=yVNkMNVv4Y4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-02 00:00:00+00:00

Thanks to Seasonic for sponsoring this video! 
Buy Seasonic Prime TX-1000 PSU: https://geni.us/zCAg

Is your PC not like it used to be? Games, apps, and BLOAT could be robbing you of performance, so we’re gonna figure out just how much overhead is used to run all those background apps. 


Buy MSI MPG Z590 Gaming Plus: https://geni.us/BBPsER1

Buy Intel Core i7-11700K: https://geni.us/RhXe8Mw

Buy Crucial P5 Plus 1TB NVMe SSD: https://geni.us/snZ4E

Buy G.Skill Trident Z NEO Series 16GB (2 x 8GB) DDR4 RAM: https://geni.us/S84oloK

Buy MSI Gaming X Trio RTX 3080: https://geni.us/bjQw

Buy Noctua NH-U12S: https://geni.us/beHeQ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1385665-bloat-is-killing-your-fps/

Get WinAero Tweaker here: https://winaero.com/winaero-tweaker/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:58 Test Methodology
3:17 Initial impressions
5:23 tasty SSD test
6:35 Benchmarks 
7:49 Takeaways
8:55 Cleanup

