# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Billionaire investor: Communist China handles economic booms better than capitalist US
 - [https://www.cnn.com/videos/business/2021/11/02/charlie-munger-taxes-china-gr-orig.cnn](https://www.cnn.com/videos/business/2021/11/02/charlie-munger-taxes-china-gr-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 23:06:28+00:00

Billionaire investor Charlie Munger weighs in on Biden's economic plan and what he says communist China gets right.

## Plane diverted mid-flight due to 'unruly' passenger
 - [https://www.cnn.com/videos/us/2021/11/02/delta-flight-passenger-removed-muntean-newsroom-vpx.cnn](https://www.cnn.com/videos/us/2021/11/02/delta-flight-passenger-removed-muntean-newsroom-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 19:39:12+00:00

A "customer disturbance" aboard a Delta Air Lines flight from Atlanta to Los Angeles resulted in the flight being diverted to Dallas, according to Delta. CNN's Pete Muntean has more.

## Rare look inside Alicia Keys and Swizz Beatz's mountainside mansion
 - [https://www.cnn.com/style/article/alicia-keys-swizz-beatz-home-architectural-digest/index.html](https://www.cnn.com/style/article/alicia-keys-swizz-beatz-home-architectural-digest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:51:52+00:00

In the mountains north of San Diego, a modernist mansion made of white concrete and glass rises from the cliffside. The property, nicknamed "Razor House" after the nearby Razor Point Trail, is now home to two famous inhabitants: singer Alicia Keys and her music producer husband Kasseem Dean, better known as Swizz Beatz, alongside their children Genesis and Egypt.

## Satellite images appear to show China is making significant progress developing missile silos that could eventually launch nuclear weapons
 - [https://www.cnn.com/collections/china-intl-110221/](https://www.cnn.com/collections/china-intl-110221/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:33:08+00:00



## Antonio Conte named new Tottenham Hotspur coach
 - [https://www.cnn.com/2021/11/02/football/antonio-conte-tottenham-manager-confirmed-spt-intl/index.html](https://www.cnn.com/2021/11/02/football/antonio-conte-tottenham-manager-confirmed-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:27:44+00:00

Antonio Conte has been named as Tottenham Hotspur's new coach, the North London club announced in a statement on Tuesday.

## Opening statements expected to begin in Kyle Rittenhouse's homicide trial
 - [https://www.cnn.com/2021/11/02/us/kyle-rittenhouse-trial-kenosha/index.html](https://www.cnn.com/2021/11/02/us/kyle-rittenhouse-trial-kenosha/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:26:57+00:00

Opening are statements are expected to begin Tuesday in the homicide trial of Kyle Rittenhouse, the armed Illinois teenager who killed two people and wounded another during unrest in Kenosha, Wisconsin, last summer.

## Pfizer revenue and profits soar on its Covid vaccine business
 - [https://www.cnn.com/2021/11/02/business/pfizer-earnings/index.html](https://www.cnn.com/2021/11/02/business/pfizer-earnings/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:26:56+00:00

Pfizer reported that earnings and sales more than doubled in the past quarter, and it raised its outlook for results the full year, thanks greatly to its Covid-19 vaccine.

## Israel's prime minister threatens no-show if COP26 organizers fail to fix wheelchair access issue
 - [https://www.cnn.com/collections/cop26-110121/](https://www.cnn.com/collections/cop26-110121/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:20:14+00:00



## Two London police officers admit sharing photos of murdered sisters
 - [https://www.cnn.com/2021/11/02/uk/london-police-misconduct-photos-scli-intl-gbr/index.html](https://www.cnn.com/2021/11/02/uk/london-police-misconduct-photos-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:20:09+00:00

Two UK police officers have pleaded guilty to taking and sharing photos of the bodies of two murdered sisters at a crime scene they were assigned to protect, reports the UK's PA Media news agency.

## Cryptocurrencies rally on Facebook's 'Meta' rebrand
 - [https://www.cnn.com/2021/11/02/investing/decentraland-crypto-meta-rally/index.html](https://www.cnn.com/2021/11/02/investing/decentraland-crypto-meta-rally/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:05:25+00:00

Facebook announced its company rebrand just last week, but a little-known cryptocurrency is already rallying in anticipation of an expanding metaverse.

## Satellite images may show China developing missile silos
 - [https://www.cnn.com/2021/11/02/politics/china-suspected-silo-fields-report/index.html](https://www.cnn.com/2021/11/02/politics/china-suspected-silo-fields-report/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:02:42+00:00



## She quit her job as a NYC lawyer to move to Ghana
 - [https://www.cnn.com/travel/article/ghana-diaspora-return-africa-cmd/index.html](https://www.cnn.com/travel/article/ghana-diaspora-return-africa-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 12:02:40+00:00

In 2012, Nana Amoako Anin was working as a prosecutor in New York. Although British of Ghanian descent, she had spent her working life in the United States, studying law and entering the legal profession.

## You broke your bad habit. This is how you build something better in its place
 - [https://www.cnn.com/2021/11/02/health/good-habits-replacement-wellness/index.html](https://www.cnn.com/2021/11/02/health/good-habits-replacement-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 11:40:46+00:00

It took a lot of work, but you finally stopped reaching for the pint of ice cream after a long day or a disagreement with your partner. But now what?

## Meta denies Kazakh claim of exclusive access to Facebook's content reporting system
 - [https://www.cnn.com/2021/11/02/tech/facebook-kazakhstan-content-reporting/index.html](https://www.cnn.com/2021/11/02/tech/facebook-kazakhstan-content-reporting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 11:25:25+00:00

Facebook-owner Meta Platforms on Tuesday denied a claim by the Kazakh government that it had been granted exclusive access to the social network's content reporting system.

## Irish startup's pocket-sized gadget shows you what food is bad for your gut
 - [https://www.cnn.com/2021/11/02/tech/foodmarble-aire-hydrogen-breath-test-spc-intl/index.html](https://www.cnn.com/2021/11/02/tech/foodmarble-aire-hydrogen-breath-test-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 11:11:49+00:00

Indigestion, stomach cramps and constipation are all signs of irritable bowel syndrome (IBS), a digestive condition estimated to affect one in 10 people worldwide.

## Why the world is still arguing over masks, 20 months into the pandemic
 - [https://www.cnn.com/2021/11/02/health/face-mask-debate-covid-19-pandemic-cmd-intl/index.html](https://www.cnn.com/2021/11/02/health/face-mask-debate-covid-19-pandemic-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 11:10:42+00:00

At the start of the pandemic, much of the Western world followed a similar playbook for tackling Covid-19.

## Toronto Raptors beat New York Knicks as the NBA celebrates its 75th anniversary
 - [https://www.cnn.com/2021/11/02/sport/knicks-raptors-nba-75th-anniversary-spt-intl/index.html](https://www.cnn.com/2021/11/02/sport/knicks-raptors-nba-75th-anniversary-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 11:06:30+00:00

The NBA celebrated its 75th anniversary with a match-up between New York and Toronto -- just as it was in the beginning.

## Checking Alec Baldwin's gun was not assistant director's responsibility, attorney says
 - [https://www.cnn.com/2021/11/01/entertainment/rust-shooting-assistant-director-gun/index.html](https://www.cnn.com/2021/11/01/entertainment/rust-shooting-assistant-director-gun/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 11:05:17+00:00

An attorney representing David Halls, an assistant director on the set of the film "Rust," said it was not Halls' responsibility to confirm whether the gun handed to Alec Baldwin was loaded, despite Halls previously acknowledging to investigators that he should have checked all the rounds before declaring the firearm safe.

## Barcelona star Sergio Agüero ruled out for three months following 'cardiological evaluation'
 - [https://www.cnn.com/2021/11/02/football/sergio-aguero-out-three-months-after-cardiac-assessment-spt-intl/index.html](https://www.cnn.com/2021/11/02/football/sergio-aguero-out-three-months-after-cardiac-assessment-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 10:45:14+00:00

Sergio Agüero will be out of action for three months after undergoing a "cardiological evaluation," Barcelona has confirmed.

## Elon Musk keeps fans guessing by tweeting mysterious Chinese poem
 - [https://www.cnn.com/2021/11/02/tech/elon-musk-tweet-chinese-poem-intl-hnk/index.html](https://www.cnn.com/2021/11/02/tech/elon-musk-tweet-chinese-poem-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 10:43:43+00:00

Elon Musk is known for setting the internet ablaze with his cryptic tweets. Now he's doing it in another language.

## Three giraffes died at the Dallas Zoo in less than a month. Experts are looking into whether two of the deaths are connected
 - [https://www.cnn.com/2021/11/02/us/giraffe-deaths-dallas-zoo/index.html](https://www.cnn.com/2021/11/02/us/giraffe-deaths-dallas-zoo/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 10:29:15+00:00

A third giraffe has died at the Dallas Zoo in less than a month, the zoo reported.

## Blasts heard near hospital in Kabul, casualties reported
 - [https://www.cnn.com/2021/11/02/asia/afghanistan-kabul-blast-intl/index.html](https://www.cnn.com/2021/11/02/asia/afghanistan-kabul-blast-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 10:27:54+00:00

Two blasts have been heard near a military hospital in Kabul, an Afghan Interior Ministry spokesman said in a tweet Tuesday.

## Kansas City Chiefs edge past New York Giants but 'everything's not beautiful,' says coach
 - [https://www.cnn.com/2021/11/02/sport/kansas-city-chiefs-ny-giants-patrick-mahomes-mnf-spt-intl/index.html](https://www.cnn.com/2021/11/02/sport/kansas-city-chiefs-ny-giants-patrick-mahomes-mnf-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 10:19:52+00:00

The Kansas City Chiefs dug deep to complete a hard-fought comeback against the New York Giants on Monday, improving to 4-4 this season.

## 'No more blah, blah, blah!' Thunberg joins protesters outside climate summit
 - [https://www.cnn.com/videos/world/2021/11/02/glasgow-greta-thunberg-cop26-climate-protest-sot-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/11/02/glasgow-greta-thunberg-cop26-climate-protest-sot-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 09:58:39+00:00

Outside the COP26 UN climate summit, climate activist Greta Thunberg gathered with crowds of protesters and slammed the world leaders attending the conference for not doing enough to address the climate crisis.

## Fad diets are out. It's your lifestyle habits that matter
 - [https://www.cnn.com/2021/11/02/health/heart-healthy-dietary-guidelines/index.html](https://www.cnn.com/2021/11/02/health/heart-healthy-dietary-guidelines/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 09:02:02+00:00

A full belly makes a happy heart, but your heart will be happier if you focus on sustaining long-term habits.

## Man detained for 9 days in China for sending meme deemed 'insulting' to police
 - [https://www.cnn.com/2021/11/02/china/china-man-detained-meme-intl-hnk-scli/index.html](https://www.cnn.com/2021/11/02/china/china-man-detained-meme-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 08:51:13+00:00

A man in China was reportedly detained for nine days after sending a meme to a group chat that was deemed offensive to police in an incident that has gone viral on Chinese social media.

## Beauty behind bars: Why makeup matters for prisoners
 - [https://www.cnn.com/style/article/prisoners-makeup-pandemic/index.html](https://www.cnn.com/style/article/prisoners-makeup-pandemic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 08:04:36+00:00

Last year was a rough one for Joyce Pequeno, a 28-year-old inmate at Coffee Creek Correctional Facility in Wilsonville, Oregon. Social distancing was rare, she said, and prisoners were dying. Her clemency hearing was postponed. Still, most days she dabbed on foundation, swirled eyeshadow across her lids and outlined her eyes with kohl.

## Judge rules Kobe Bryant's widow, Vanessa Bryant, won't undergo psychiatric evaluation in lawsuit over helicopter crash photos
 - [https://www.cnn.com/2021/11/02/us/kobe-bryant-vanessa-bryant-lawsuit-psychiatric-evaluation-ruling/index.html](https://www.cnn.com/2021/11/02/us/kobe-bryant-vanessa-bryant-lawsuit-psychiatric-evaluation-ruling/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 06:52:59+00:00

Kobe Bryant's widow, Vanessa Bryant, will not have to undergo a psychiatric evaluation in her lawsuit against Los Angeles County over leaked photos of the NBA star's fatal helicopter crash, a judge has ruled.

## A Pacific island nation with only one confirmed Covid case just went into lockdown
 - [https://www.cnn.com/2021/11/02/asia/tonga-lockdown-covid-intl-hnk/index.html](https://www.cnn.com/2021/11/02/asia/tonga-lockdown-covid-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 06:41:21+00:00

The South Pacific island nation of Tonga went into lockdown on Tuesday, following the discovery of the country's first Covid case since the start of the pandemic.

## NYC mayor vows consequences for firefighters if they skipped work to protest vaccine mandate after 2,300 called out sick
 - [https://www.cnn.com/2021/11/02/us/nyc-fdny-firefighters-vaccine-mandate-sick-leave/index.html](https://www.cnn.com/2021/11/02/us/nyc-fdny-firefighters-vaccine-mandate-sick-leave/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 06:31:34+00:00

Any firefighters feigning illness to protest New York City's Covid-19 vaccine mandate are "doing an immense disservice" to the city, Mayor Bill de Blasio said Monday night.

## China and Russia revive push to lift UN sanctions on North Korea
 - [https://www.cnn.com/2021/11/02/asia/china-russia-un-sanctions-north-korea-intl-hnk/index.html](https://www.cnn.com/2021/11/02/asia/china-russia-un-sanctions-north-korea-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 06:12:07+00:00

China and Russia are pushing the United Nations Security Council to ease sanctions on North Korea, reviving a similar previous attempt that had flailed in 2019.

## 'I have no choice': Miner's dire working conditions reveal dark side of world's coal addiction
 - [https://www.cnn.com/videos/world/2021/11/02/south-africa-coal-addiction-mckenzie-pkg-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/11/02/south-africa-coal-addiction-mckenzie-pkg-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 06:06:42+00:00

South Africa is more heavily dependent on coal than perhaps any other country. But for the world to combat a climate catastrophe, countries like South Africa need to move away from coal. CNN's David McKenzie and team head into the claustrophobic depths of a disused mine and explain why the country's withdrawal from its coal addiction is a critical test for the planet.

## Biden administration proposes new rules to limit planet-warming methane emissions
 - [https://www.cnn.com/2021/11/02/politics/epa-methane-regulations/index.html](https://www.cnn.com/2021/11/02/politics/epa-methane-regulations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 05:06:33+00:00

The Biden administration is proposing new rules from a number of federal agencies with the same goal: Slashing planet-warming methane emissions.

## Analysis: Virginia's election has huge implications for Biden
 - [https://www.cnn.com/2021/11/02/politics/virginia-governor-race-nationalization/index.html](https://www.cnn.com/2021/11/02/politics/virginia-governor-race-nationalization/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 04:31:58+00:00

Analysis: Joe Manchin just torpedoed the White House's planned victory lap

## Netflix removes spy drama episodes after Philippines' complaint over China map
 - [https://www.cnn.com/2021/11/01/media/netflix-philippines-pine-gap-intl-hnk/index.html](https://www.cnn.com/2021/11/01/media/netflix-philippines-pine-gap-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 03:51:47+00:00

Netflix Inc has removed two episodes of spy drama "Pine Gap" from its streaming service in the Philippines, after the Southeast Asian country rejected scenes involving a map used by China to assert its claims to the South China Sea.

## 'Dancing With the Stars' says goodbye to another contestant
 - [https://www.cnn.com/videos/media/2021/11/02/dancing-with-the-stars-elimination-november-1-mh-orig.cnn](https://www.cnn.com/videos/media/2021/11/02/dancing-with-the-stars-elimination-november-1-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 03:13:18+00:00

A WWE wrestler and his partner were eliminated after the judges voted to save another duo.

## Inside the court: Three hours that could decide the future of abortion rights
 - [https://www.cnn.com/2021/11/01/politics/supreme-court-texas-abortion-kagan-analysis/index.html](https://www.cnn.com/2021/11/01/politics/supreme-court-texas-abortion-kagan-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 01:36:55+00:00

The Supreme Court was more than two hours into arguments over a Texas abortion law when Justice Elena Kagan ignited the tension that had been slowly building in the courtroom.

## Republican denounces concept of toxic masculinity, urges return to 'traditional' roles
 - [https://www.cnn.com/videos/politics/2021/11/01/josh-hawley-toxic-masculinity-mh-orig.cnn](https://www.cnn.com/videos/politics/2021/11/01/josh-hawley-toxic-masculinity-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 00:58:00+00:00

Missouri Sen. Josh Hawley denounced toxic masculinity and called for a return to traditional masculine roles at the National Conservatism Conference.

## One day Parwana was playing with friends. The next she was sold to a stranger so her family could eat
 - [https://www.cnn.com/2021/11/01/asia/afghanistan-child-marriage-crisis-taliban-intl-hnk-dst/index.html](https://www.cnn.com/2021/11/01/asia/afghanistan-child-marriage-crisis-taliban-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-02 00:08:15+00:00

Parwana Malik, a 9-year-old girl with dark eyes and rosy cheeks, giggles with her friends as they play jump rope in a dusty clearing.

