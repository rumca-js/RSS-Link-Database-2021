## Revealed: Ursula von der Leyen used private jet to travel just 31 miles
 - [https://www.telegraph.co.uk/world-news/2021/11/02/revealed-air-miles-ursula-used-private-jet-travel-just-31-miles/](https://www.telegraph.co.uk/world-news/2021/11/02/revealed-air-miles-ursula-used-private-jet-travel-just-31-miles/)
 - RSS feed: https://www.telegraph.co.uk
 - date published: 2021-11-02 12:18:42+00:00

Revealed: Ursula von der Leyen used private jet to travel just 31 miles

