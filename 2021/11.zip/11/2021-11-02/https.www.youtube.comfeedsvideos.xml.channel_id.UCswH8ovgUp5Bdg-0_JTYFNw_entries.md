# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is This A JOKE?? "Let's Go Brandon!" Now BANNED?!
 - [https://www.youtube.com/watch?v=XkL-KzaYxuw](https://www.youtube.com/watch?v=XkL-KzaYxuw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-11-03 00:00:00+00:00

As Southwest Airlines announces an investigation after a pilot reportedly told passengers “Let’s go Brandon”, why has the meme faced such a backlash? 
#LetsGoBrandon #JoeBiden #CNN #DonaldTrump #pilot #southwest

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## Hold On...These Are Actually Really Good Ideas!!
 - [https://www.youtube.com/watch?v=VoGJ-Ni7D-g](https://www.youtube.com/watch?v=VoGJ-Ni7D-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-11-02 00:00:00+00:00

I spoke to Sebastian Junger on my Under the Skin podcast. Sebastian  is an American journalist, author and filmmaker. He is known for his books “The Perfect Storm: A True Story of Men Against the Sea”, “War” and “Tribe”. His latest book is called Freedom and is out now!
In this this discussion we talk solutions to the relentless fraught nature of politics and how to avoid the fearful route of authoritarianism.

You can listen to the rest of my discussion with Sebastian over on Luminary, it's episode 209: http://luminary.link/russell

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

#RussellBrand #Politics

## Think We're Heading To Dystopia? WATCH THIS!!!
 - [https://www.youtube.com/watch?v=SDD7M1OWBDg](https://www.youtube.com/watch?v=SDD7M1OWBDg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-11-02 00:00:00+00:00

A robotics firm has unveiled its latest invention: Grace, a humanoid robot nurse that is designed to "revolutionize healthcare". 
#robot #nurse #AI #healthcare 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

