# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Sleigh Bells - And Saints (Live on KEXP)
 - [https://www.youtube.com/watch?v=PD4i2HWzGrQ](https://www.youtube.com/watch?v=PD4i2HWzGrQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-17 00:00:00+00:00

http://KEXP.ORG presents Sleigh Bells performing “And Saints” live in the KEXP studio. Recorded October 27, 2021.

Alexis Krauss - Vocals
Derek Miller - Guitar
Kate Steinberg - Keyboards & Backing Vocals
Chris Maggio - Drums

Host: Cheryl Waters
Audio Engineers: Patrick Scott & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://tornclean.com
http://kexp.org

## Sleigh Bells - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=fWFe51ARsWA](https://www.youtube.com/watch?v=fWFe51ARsWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-17 00:00:00+00:00

http://KEXP.ORG presents Sleigh Bells performing live in the KEXP studio. Recorded October 27, 2021.

Songs:
Sweet 75
I’m Not Down
And Saints

Alexis Krauss - Vocals
Derek Miller - Guitar
Kate Steinberg - Keyboards & Backing Vocals
Chris Maggio - Drums

Host: Cheryl Waters
Audio Engineers: Patrick Scott & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://tornclean.com
http://kexp.org

## Sleigh Bells - I'm Not Down (Live on KEXP)
 - [https://www.youtube.com/watch?v=l8j7OSSC6vA](https://www.youtube.com/watch?v=l8j7OSSC6vA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-17 00:00:00+00:00

http://KEXP.ORG presents Sleigh Bells performing “I'm Not Down” live in the KEXP studio. Recorded October 27, 2021.

Alexis Krauss - Vocals
Derek Miller - Guitar
Kate Steinberg - Keyboards & Backing Vocals
Chris Maggio - Drums

Host: Cheryl Waters
Audio Engineers: Patrick Scott & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://tornclean.com
http://kexp.org

## Sleigh Bells - Sweet 75 (Live on KEXP)
 - [https://www.youtube.com/watch?v=bZjZc6ZeI_8](https://www.youtube.com/watch?v=bZjZc6ZeI_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-17 00:00:00+00:00

http://KEXP.ORG presents Sleigh Bells performing “Sweet 75” live in the KEXP studio. Recorded October 27, 2021.

Alexis Krauss - Vocals
Derek Miller - Guitar
Kate Steinberg - Keyboards & Backing Vocals
Chris Maggio - Drums

Host: Cheryl Waters
Audio Engineers: Patrick Scott & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://tornclean.com
http://kexp.org

