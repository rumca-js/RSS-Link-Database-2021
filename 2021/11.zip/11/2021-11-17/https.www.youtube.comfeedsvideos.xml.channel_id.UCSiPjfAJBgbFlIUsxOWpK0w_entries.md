# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Life Goes On // Oliver Tree // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=OTky0w9-uY4](https://www.youtube.com/watch?v=OTky0w9-uY4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-11-18 00:00:00+00:00

The groove on this song is just NASTY. Didn’t know who Oliver Tree was a month ago, and now this is the only song on my mind. So dang catchy!

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Oliver Tree's "Life Goes On" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte & Rai Thistlethwayte
Bass: Nick Campbell
Drums: Ben Rose
Background Vocals: Nahneen Kula (left), Sarah Dugas (right)

AUDIO CREDITS
Engineer: Bill Mims
Assistant Engineer: Jack Corbett
Mixing/Mastering: Yianni AP
Producer: Ben Rose

VIDEO CREDITS
Director: Dom Fera
DP: Christian Colwell
Camera Operators: Christopher Li, Austin Hughes
Gaffer: Nash White 
Production Designer: Katie Theel
Wardrobe: Alex Allen
Video Editor/Colorist: Athena Wheaton

#Pomplamoose #OliverTree #LifeGoesOn #IndieRock

LYRICS
Babe, you're too controlling
I’ma feed you to the wolves
When you get nasty, back at me
But, baby, don't distract me
I'm a goner, I lost her
Like why the hell you wanna
Play me that way? You’re bad, babe
You double-faced entendre

Life goes on and on and on and on and on and
On and on and on
On and on and on and on and on and
On and on and on
On and on and on and on and on and
On and on and on
On and on and on and on and on and
On and on and on

Babe, you best believe it
I'ma rip you up to pieces
I'm a lover, not a fighter
But I'll light this place on fire
I want it, I'm on it
But, babe, at least I'm honest
I get tired of explaining
As these seasons keep on changing

Life goes on and on and on and on and on and
On and on and on (Yeah, yeah, yeah)
On and on and on and on and on and
On and on and on (Yeah, yeah, yeah)
On and on and on and on and on and
On and on and on (Yeah, yeah, yeah)
On and on and on and on and on and
On and on and on (Yeah, yeah, yeah)

Work all day and then I wake up
Work all day and then I wake up
Work all day and then I wake up
Work all day (Yeah, yeah, yeah)
Work all day and then I wake up
Work all day and then I wake up
Work all day and then I wake up
Work all day

