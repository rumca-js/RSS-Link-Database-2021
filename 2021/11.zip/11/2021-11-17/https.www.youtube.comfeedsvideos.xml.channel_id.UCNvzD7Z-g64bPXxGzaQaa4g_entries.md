# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Video Game Enemies That Annoyed the SH*T Out Of You
 - [https://www.youtube.com/watch?v=Z79DyR8wmSY](https://www.youtube.com/watch?v=Z79DyR8wmSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-18 00:00:00+00:00

These infamous game enemies aren't always challenging, but they're always annoying jerks.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


0:00 Intro
0:31 Madron the Assassin - Dark Souls 2
1:47 Carcass - Doom Eternal 
2:48 The Boost Guardian - Metroid Prime 2: Echoes
3:42 Undead Giant (Chains Version) - Bloodborne
5:09 Matador - Shin Megami Tensei 3: Nocturne
6:06 Controller - Stalker: Call of Pripyat
7:08 Old King Allant - Demon's Souls
8:00 Moldorm - Legend of Zelda: A link to the Past
8:58 Malboro - Final Fantasy Series
10:12 Mr. Shakedown - Yakuza Zero

## Battlefield 2042 - Before You Buy
 - [https://www.youtube.com/watch?v=mMXorc6XWUM](https://www.youtube.com/watch?v=mMXorc6XWUM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-17 00:00:00+00:00

Battlefield 2042 (PC, PS5, PS4, Xbox Series X/S/One) is the latest large-scale multiplayer shooter in the long running series. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy BF 2042: https://amzn.to/3nqj50b

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#BF2042 #Battlefield

