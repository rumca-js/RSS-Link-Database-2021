## Biden nominates Ghislaine Maxwell's judge, Memphis litigator to appeals courts | Reuters
 - [https://www.reuters.com/legal/government/biden-nominates-ghislaine-maxwells-judge-memphis-litigator-appeals-courts-2021-11-17/](https://www.reuters.com/legal/government/biden-nominates-ghislaine-maxwells-judge-memphis-litigator-appeals-courts-2021-11-17/)
 - RSS feed: https://www.reuters.com
 - date published: 2021-11-17 21:11:58+00:00

Biden nominates Ghislaine Maxwell's judge, Memphis litigator to appeals courts | Reuters

