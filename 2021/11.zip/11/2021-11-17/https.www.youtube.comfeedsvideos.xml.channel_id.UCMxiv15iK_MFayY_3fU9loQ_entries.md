## Freddie Sayers investigates Austria's lockdown of the unvaccinated
 - [https://www.youtube.com/watch?v=y9io1MZz_7E](https://www.youtube.com/watch?v=y9io1MZz_7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCMxiv15iK_MFayY_3fU9loQ
 - date published: 2021-11-17 08:22:45+00:00

Freddie Sayers investigates Austria's lockdown of the unvaccinated

