# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Courtney Barnett - If I Don't Hear From You Tonight (live performance for The Current)
 - [https://www.youtube.com/watch?v=y6zfkLXDgGw](https://www.youtube.com/watch?v=y6zfkLXDgGw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-18 00:00:00+00:00

Australian musician Courtney Barnett joins The Current for a virtual session, and plays "If I Don't Hear From You Tonight" from her 2021 record "Things Take Time, Take Time". 

Don't miss our full session with Barnett, who spoke with Jill Riley about collaborating with Warpaint's Stella Mozgawa on the new record, balancing humor and earnesty in her writing, and her love for Joshua Tree, California: https://youtu.be/S_07OE40REc

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Lala Lala - Color of the Pool (live performance for The Current)
 - [https://www.youtube.com/watch?v=mGnm8sBZ2yw](https://www.youtube.com/watch?v=mGnm8sBZ2yw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-18 00:00:00+00:00

Following the release of their third album 'I Want The Door To Open,' Lala Lala joined The Current to play "Color of the Pool" from the 2021 release.   

Don't miss our full session with Chicago's Lala Lala, including a conversation with frontperson Lillie West about the 1-833-LALA-NOW voicemail, their dream collaborations, and what the band learned on tour opening for Death Cab For Cutie: https://youtu.be/hMg7DPULTeg

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits:
Technical Director - Erik Stromstad
Music Video Director - Max Moore
Director's Assistant -  Christian Heinzel
Music Audio Engineer - Dave Vettraino

## Courtney Barnett - Rae Street (live performance for The Current)
 - [https://www.youtube.com/watch?v=ObDbot4kD50](https://www.youtube.com/watch?v=ObDbot4kD50)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-17 00:00:00+00:00

Australian musician Courtney Barnett joins The Current for a virtual session, and plays "Rae Street" from her 2021 record "Things Take Time, Take Time". 

Don't miss our full session with Barnett, who spoke with Jill Riley about collaborating with Warpaint's Stella Mozgawa on the new record, balancing humor and earnesty in her writing, and her love for Joshua Tree, California: https://youtu.be/S_07OE40REc

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Courtney Barnett - Write A List of Things To Look Forward To (live performance for The Current)
 - [https://www.youtube.com/watch?v=K3ClA0zkeW4](https://www.youtube.com/watch?v=K3ClA0zkeW4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-17 00:00:00+00:00

Courtney Barnett joins The Current for a virtual session, and plays "Write A List of Things To Look Forward To" from her 2021 record "Things Take Time, Take Time". 

Watch our full session with the Australian musician, who spoke with Jill Riley about collaborating with Warpaint's Stella Mozgawa on the new record, balancing humor and earnesty in her writing, and her love for Joshua Tree, California: https://youtu.be/S_07OE40REc

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Courtney Barnett performs songs from 'Things Take Time, Take Time' (live for The Current)
 - [https://www.youtube.com/watch?v=FsifLFoi9RU](https://www.youtube.com/watch?v=FsifLFoi9RU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-17 00:00:00+00:00

Courtney Barnett joins The Current for a virtual session, and plays songs from her 2021 record "Things Take Time, Take Time". 

Watch our full session with the Australian musician, who spoke with Jill Riley about collaborating with Warpaint's Stella Mozgawa on the new record, balancing humor and earnesty in her writing, and her love for Joshua Tree, California: https://youtu.be/S_07OE40REc

Songs Played: 
00:01 Write A List of Things To Look Forward To
03:03 If I Don't Hear From You Tonight
07:24 Rae Street
11:39 Before You Gotta Go

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Interview: Mason Jennings on his 2022 album "Real Heart", and new project Painted Shield
 - [https://www.youtube.com/watch?v=t-BOaZsW8Wc](https://www.youtube.com/watch?v=t-BOaZsW8Wc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-17 00:00:00+00:00

@MasonJenningsMusic connects with The Current's Local Show host Diane about his 2022 record "Real Heart," and @PaintedShield—his new project with Pearl Jam's Stone Gossard. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits
Host - Diane
Guest - Mason Jennings
Technical Director - Eric Romani
Producer - Jesse Wiza

