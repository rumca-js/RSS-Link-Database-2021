# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## John Rhys-Davies Talks Gimli, The Lord of the Rings, Indiana Jones, and more!
 - [https://www.youtube.com/watch?v=qNnPE0Hpry8](https://www.youtube.com/watch?v=qNnPE0Hpry8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-11-18 00:00:00+00:00

I had the pleasure of speaking with John Rhys-Davies about Gimli, The Lord of the Rings, Indiana Jones, books, and more.  John even does an in-character reading as Gimli from the books from a fan-favorite moment - the description of the Glittering Caves!

This interview was made possible through the fundraiser "It's Time to Shout James", made for a young man from New Zealand, James Depree, currently battling Stage 4 Hodgkins Lymphoma.  You can donate to help James - and have a chance to win a 1-on-1 virtual chat with John Rhys-Davies by going to the link here: https://app.galabid.com/itstimetoshoutjames/items/420d7dec-081a-43b0-b7ff-1b06bda85d01?backPath=%2Fitstimetoshoutjames%2Fitems

Donations from the following period will be included in the draw
06:00 NZDT 11 November 2021 - 12 Noon NZDT 24 November 2021
17:00 GMT 10 November 2021 - 23:00 GMT 23 November 2021
12:00 EST 10 November 2021 - 18:00 EST 23 November 2021
09:00 PST 10 November 2021 - 15:00 PST 23 November 2021

*Ignore the "Auction closed box", as it is a remainder from their previous fundraiser.*
Winner announced on the the Nerd of the Rings live stream on Wednesday 24 November 2021

#gimli #lordoftherings #johnrhysdavies

