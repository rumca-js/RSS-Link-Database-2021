# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Kolory - Odpowiedzi - live MUZO.FM
 - [https://www.youtube.com/watch?v=sO28P1BWuso](https://www.youtube.com/watch?v=sO28P1BWuso)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2021-11-18 00:00:00+00:00

Kolory na żywo w MUZO.FM. Utwór Odpowiedzi pochodzi z debiutanckiej płyty Kolorów - Chcieliśmy tylko coś poczuć. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Kolory: http://www.facebook.com/koloryband
Instagram Kolory: http://www.instagram.com/koloryband
Instagram: http://www.instagram.com/muzofm 
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

