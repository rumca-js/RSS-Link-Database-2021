# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## The Chinese Government Just Tried to Hire Me
 - [https://www.youtube.com/watch?v=kOIrsmjRFxU](https://www.youtube.com/watch?v=kOIrsmjRFxU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2021-11-17 00:00:00+00:00

Download Cultivate for free! 

Chrome: https://www.wecultivate.us/get/extension/chrome?campaignId=adv
Firefox: https://www.wecultivate.us/get/extension/firefox?campaignId=adv
Safari: https://www.wecultivate.us/get/extension/safari?campaignId=adv

So SerpentZA and me (Laowhy86) got some emails from agents working for CCP clients to try and get us to spread Chinese propaganda. This led us to catching out some more people on YouTube who, unlike us, took the money to do so. They probably should've done some more research before trying to hire us. 

Winston (SerpentZA) did a video in more detail as well about this - 
https://youtu.be/djXYBU1T-Ek

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats

