# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Macbeth Alternate Ending
 - [https://www.youtube.com/watch?v=NkBtEevJFgs](https://www.youtube.com/watch?v=NkBtEevJFgs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-11-18 00:00:00+00:00

Sorry Shakespeare, the first one was good and all... but this one's way better. Thank you to BetterHelp for sponsoring today's video. Get 10% off you first month here: https://BetterHelp.com/nolke

Writer: Julie Nolke
Actors: Julie Nolke 
Camera: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Also, join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke !

