# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Cornish Hen (ft. John Scofield & MonoNeon) | Scary Goldings
 - [https://www.youtube.com/watch?v=WvBrm3IqlG4](https://www.youtube.com/watch?v=WvBrm3IqlG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-11-18 00:00:00+00:00

The Scary Goldings crew are BACK with an insane lineup featuring JOHN SCOFIELD and MONONEON

Sign up to the Vinyl Club tier by November 30 to be the FIRST to get your copy of "IV' by Scary Goldings" on Vinyl: https://www.patreon.com/scarypockets 

Your limited edition vinyl will: 
- be signed by Jack, Ryan, & Larry
- have YOUR NAME on the sleeve inside
(Must stay in the tier for at least 3 months to qualify.)

Store: https://www.scarypocketsfunk.com
Listen on Spotify: https://tinyurl.com/yxk72gn4

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

Cornish Hen is an original song by Scary Goldings ft. John Scofield.

MUSICIAN CREDITS
Guitar: John Scofield
Drums: Lemar Carter
Bass: MonoNeon
Organ: Larry Goldings
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Franky Fox
Mix: Craig Polasko
Master: Eric Boulanger

VIDEO CREDITS
DP: Merlin Showalter
Editor: Adam Kritzberg

Recorded Live at Valentine Studios in Los Angeles, CA.

#ScaryGoldings #Funk #JohnScofield #MonoNeon #CornishHen #ScaryGoldingsIV

