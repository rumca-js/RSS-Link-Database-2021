# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Meta's VR Gloves are actually INSANE
 - [https://www.youtube.com/watch?v=MY9EdNo3gVA](https://www.youtube.com/watch?v=MY9EdNo3gVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-11-17 00:00:00+00:00

Hello and welcome to, TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news! Today we have some really cool information on Meta's prototype VR gloves, another company's gloves you can get right now, more info on the Half Dive VR headset from Diver X and so much more. Hope you enjoy!

My links: 
Discord.gg/Thrill
Twitch.tv/Thrilluwu
Patreon.com/Thrillseeker

Sources: 
SOOOON TO BE ADDED!

TIMESTAMPS:
SOON TO BE ADDED!

