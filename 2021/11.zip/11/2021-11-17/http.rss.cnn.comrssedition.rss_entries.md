# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Ocasio-Cortez rips GOP as congressman censured over video depicting her killing
 - [https://www.cnn.com/2021/11/17/politics/house-vote-censure-gosar-aoc-video/index.html](https://www.cnn.com/2021/11/17/politics/house-vote-censure-gosar-aoc-video/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 23:58:40+00:00

The House of Representatives voted Wednesday to approve a resolution that censures Rep. Paul Gosar and strips him of his two committee assignments, the first time a sitting House member has been censured in more than 10 years.

## Watch the stand up comedy routine that's polarized India
 - [https://www.cnn.com/videos/india/2021/11/17/india-comedian-vir-das-criticism-orig-na-jk.cnn](https://www.cnn.com/videos/india/2021/11/17/india-comedian-vir-das-criticism-orig-na-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 22:22:36+00:00

Vir Das, a stand-up comedian from India, shared his thoughts on the nation's social issues in a monologue called "Two Indias" while performing in Washington, DC.

## Fasting 2 days a week can help obese people keep off the weight with modest results, study finds
 - [https://www.cnn.com/2021/11/17/health/diet-52-intermittent-fasting-study-wellness/index.html](https://www.cnn.com/2021/11/17/health/diet-52-intermittent-fasting-study-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 19:36:44+00:00

The 5:2 diet, a type of intermittent fasting, is no more effective than traditional approaches to weight loss, according to what researchers said was the first study of the regimen in a "real-life setting."

## Irish Deputy PM says the 5% of the nation's unvaccinated population is causing a problem
 - [https://www.cnn.com/videos/world/2021/11/17/ireland-covid-19-cases-rise-new-curfew-leo-varadkar-ctw-intl-vpx.cnn](https://www.cnn.com/videos/world/2021/11/17/ireland-covid-19-cases-rise-new-curfew-leo-varadkar-ctw-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 18:42:36+00:00

Ireland will impose a midnight curfew on bars, restaurants and nightclubs from November 18 as the country sees a new surge in Covid-19 cases, despite having one of the highest vaccination rates in the world. CNN's Becky Anderson sits down with Leo Varadkar, Ireland's Deputy Prime Minister, to discuss.

## Defense to begin after prosecution rests in the trial over Ahmaud Arbery's killing
 - [https://www.cnn.com/2021/11/17/us/ahmaud-arbery-killing-trial-day-9-wednesday/index.html](https://www.cnn.com/2021/11/17/us/ahmaud-arbery-killing-trial-day-9-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 14:23:46+00:00

Following testimony from investigators and experts over the course of more than a week, the prosecution in the Ahmaud Arbery killing trial rested Tuesday, turning over court proceedings to the defense.

## Nation with one of Europe's highest vaccination rates imposes curfew on pubs and clubs as cases rise
 - [https://www.cnn.com/collections/intl-covid-1117/](https://www.cnn.com/collections/intl-covid-1117/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 14:22:12+00:00



## The Queen holds first engagement since missing Remembrance Sunday Service
 - [https://www.cnn.com/2021/11/17/uk/queen-first-engagement-intl-gbr/index.html](https://www.cnn.com/2021/11/17/uk/queen-first-engagement-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 14:19:47+00:00

Britain's Queen Elizabeth has undertaken her first engagements since being forced to miss the Remembrance Sunday service over the weekend after spraining her back.

## Apple will let iPhone users repair their own devices
 - [https://www.cnn.com/2021/11/17/tech/apple-iphone-right-to-repair/index.html](https://www.cnn.com/2021/11/17/tech/apple-iphone-right-to-repair/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 14:02:18+00:00

Apple plans to give customers the ability to repair their own devices amid growing pressure from regulators and consumers around the world for manufacturers to ease restrictions on fixing products.

## 'Euphoria' makeup artist reveals change lies ahead for characters next season
 - [https://www.cnn.com/style/article/euphoria-season-two-makeup/index.html](https://www.cnn.com/style/article/euphoria-season-two-makeup/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:53:53+00:00

In most industries, getting your work noticed is the first step towards success. But for screen makeup artist Doniella Davy -- who goes by Donni for short -- the goal was for her hand to remain hidden.

## Trump's revenge tour on infrastructure vote splits Republicans in West Virginia House race
 - [https://www.cnn.com/2021/11/17/politics/west-virginia-house-race-mooney-mckinley-trump-infrastructure/index.html](https://www.cnn.com/2021/11/17/politics/west-virginia-house-race-mooney-mckinley-trump-infrastructure/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:35:27+00:00

Donald Trump has been on a retribution campaign against the House Republicans who voted to impeach him. Now the former President is expanding his revenge tour to include a new crop of members: GOP lawmakers who backed the bipartisan infrastructure law.

## International Olympic Committee announces new framework on transgender athletes
 - [https://www.cnn.com/2021/11/17/sport/ioc-announces-new-transgender-athletes-framework-spt-intl/index.html](https://www.cnn.com/2021/11/17/sport/ioc-announces-new-transgender-athletes-framework-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:35:20+00:00

The International Olympic Committee (IOC) has announced new framework on transgender athletes, saying that no athlete should be excluded from competition on the assumption of an advantage due to their gender.

## What a staggering gun cache discovered in one suspected neo-Nazi's house says about far-right extremism in Europe
 - [https://www.cnn.com/2021/11/17/europe/austria-far-right-extremism-intl/index.html](https://www.cnn.com/2021/11/17/europe/austria-far-right-extremism-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:32:35+00:00

Last month, Austrian police made a remarkable discovery. In a raid on a house in the town of Baden, they found an arsenal of weapons and 1,200 kilograms of ammunition -- as well as Nazi paraphernalia and a large amount of gunpowder.

## Marjorie Taylor Greene reveals how much she's accrued in fines over masks
 - [https://www.cnn.com/videos/politics/2021/11/17/marjorie-taylor-greene-unvaccinated-fine-mask-newday-berman-vpx.cnn](https://www.cnn.com/videos/politics/2021/11/17/marjorie-taylor-greene-unvaccinated-fine-mask-newday-berman-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:17:50+00:00

Rep. Marjorie Taylor Greene (R-GA), who has publicly cast doubt on and spread misinformation about the efficacy of Covid-19 vaccines, revealed during an interview with Newsmax that she has not received the Covid-19 vaccine. She is now being fined over $60,000 for refusing to wear a mask on the senate floor.

## 'You guys saved my life,' Britney Spears tells #FreeBritney movement
 - [https://www.cnn.com/2021/11/17/entertainment/britney-spears-conservatorship-freebritney-instagram-scli-intl/index.html](https://www.cnn.com/2021/11/17/entertainment/britney-spears-conservatorship-freebritney-instagram-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:17:24+00:00

Britney Spears has said the #FreeBritney movement saved her life, four days after her conservatorship finally came to an end.

## Decathlon tries to stop migrants using its kayaks to cross the Channel
 - [https://www.cnn.com/2021/11/17/business/decathlon-kayak-sales-france-migrants-intl/index.html](https://www.cnn.com/2021/11/17/business/decathlon-kayak-sales-france-migrants-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:06:38+00:00

Decathlon says it will stop selling kayaks in some stores in northern France in a bid to prevent migrants using them to make the dangerous sea crossing to England.

## Nation with one of Europe's highest vaccination rates imposes curfew on pubs and clubs as cases rise
 - [https://www.cnn.com/2021/11/17/europe/ireland-covid-curfew-intl/index.html](https://www.cnn.com/2021/11/17/europe/ireland-covid-curfew-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 13:00:58+00:00

• The definition of 'fully vaccinated' is changing to three Covid-19 doses
• Covid spreads in animals. Scientists worry about what that means for people

## It could be a very festive season for big stores and the wealthy
 - [https://www.cnn.com/2021/11/17/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/11/17/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 12:55:31+00:00

Heading into the all-important holiday shopping season, investors have been nursing a big concern: Will supply chain issues lead to empty shelves, making it impossible for retailers to take advantage of huge demand for toys, appliances and other items as the economy recovers from the pandemic?

## Charlie Sifford Award created for honoring 'spirit in advancing diversity in golf'
 - [https://www.cnn.com/2021/11/17/golf/charlie-sifford-award-hall-of-fame-spt-intl/index.html](https://www.cnn.com/2021/11/17/golf/charlie-sifford-award-hall-of-fame-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 12:52:53+00:00

The World Golf Hall of Fame has created the Charlie Sifford Award which will be presented to individuals for "their spirit in advancing diversity in golf."

## The Moneymaker Effect: Meet the man who helped change the fortunes of poker overnight
 - [https://www.cnn.com/2021/11/17/sport/chris-moneymaker-wsop-poker-espn-fortunes-spt-intl/index.html](https://www.cnn.com/2021/11/17/sport/chris-moneymaker-wsop-poker-espn-fortunes-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 12:46:37+00:00

When the cards were dealt, Chris Moneymaker could hardly have been happy.

## Biden-Xi meeting yielded no major breakthroughs. But Beijing has already claimed victory
 - [https://www.cnn.com/collections/xi-biden-summit-intl-111521/](https://www.cnn.com/collections/xi-biden-summit-intl-111521/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 12:44:24+00:00



## Family of a 21-year-old who died at the Astroworld Festival among 125 plaintiffs who filed a lawsuit over the deadly concert
 - [https://www.cnn.com/2021/11/17/us/astroworld-victim-axel-acosta-avila-lawsuit/index.html](https://www.cnn.com/2021/11/17/us/astroworld-victim-axel-acosta-avila-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 12:31:59+00:00

The family of Axel Acosta Avila, one of 10 people who died in the chaotic crowd surge during the Astroworld Festival in Houston this month, is among 125 plaintiffs who brought a lawsuit Tuesday against the event's organizers and others.

## The inevitability of a new, extreme GOP
 - [https://www.cnn.com/2021/11/17/politics/republican-party-paul-gosar-donald-trump-democrats-midterms/index.html](https://www.cnn.com/2021/11/17/politics/republican-party-paul-gosar-donald-trump-democrats-midterms/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 11:52:03+00:00

If House Republicans win in the midterm elections, it's already clear their new majority will be a constant churn of self-radicalization and an extremist political weapon for Donald Trump.

## How to end the tech tug-of-war with teens before the holidays
 - [https://www.cnn.com/2021/11/17/health/teen-social-media-tech-use-wellness/index.html](https://www.cnn.com/2021/11/17/health/teen-social-media-tech-use-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 11:51:26+00:00

The holiday season is right around the corner, and for many that means more time spent with family across generations. Before you demand that your children drop their smartphone to talk meaningfully about gratitude at the Thanksgiving dinner table, take a moment to consider what you're asking.

## Reporter shows inside processing center holding migrants on Poland-Belarus border
 - [https://www.cnn.com/videos/world/2021/11/17/belarus-migrants-processing-center-matthew-chance-es-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/11/17/belarus-migrants-processing-center-matthew-chance-es-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 10:54:22+00:00

CNN's Matthew Chance reports from a processing center in Belarus where some migrants are being held. On Tuesday, violence broke out on the country's border with Poland as thousands tried to cross into the European Union.

## Canada in wintery wonderland after beating Mexico in men's World Cup qualifier
 - [https://www.cnn.com/2021/11/17/football/canada-mexico-world-cup-win-snow-spt-intl/index.html](https://www.cnn.com/2021/11/17/football/canada-mexico-world-cup-win-snow-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 10:12:43+00:00

Canada took another step towards booking its place at the 2022 World Cup after beating Mexico 2-1 in near freezing conditions.

## UK inflation at 10-year high sets stage for interest rate rise within weeks
 - [https://www.cnn.com/2021/11/17/economy/uk-inflation-interest-rates/index.html](https://www.cnn.com/2021/11/17/economy/uk-inflation-interest-rates/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 10:12:40+00:00

Britain looks set to become the first major economy to hike interest rates since the Covid-19 pandemic began after inflation data showed prices rising at the fastest rate in a decade.

## RIBA International Prize 2021: World's best new buildings revealed
 - [https://www.cnn.com/style/article/riba-international-prize-architecture-2021/index.html](https://www.cnn.com/style/article/riba-international-prize-architecture-2021/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 10:07:11+00:00

A German art gallery, a vehicle-free bridge in Denmark and a remote hospital in Bangladesh have been shortlisted for a prestigious award recognizing the world's best new architecture.

## Illinois students rally to defend LGBTQ book as school board hears objections over its content
 - [https://www.cnn.com/2021/11/17/us/illinois-lgbtq-book-protests/index.html](https://www.cnn.com/2021/11/17/us/illinois-lgbtq-book-protests/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 09:47:55+00:00

The increasingly heated debate over the presence of certain books in school libraries was aired at an Illinois school board meeting this week.

## Islamic State claims responsibility for Uganda bombings
 - [https://www.cnn.com/2021/11/17/africa/uganda-islamic-state-bombing-intl-hnk/index.html](https://www.cnn.com/2021/11/17/africa/uganda-islamic-state-bombing-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 09:40:32+00:00

The Islamic State has claimed responsibility for two separate suicide attacks that killed three people and injured 33 in the Ugandan capital, Kampala, on Tuesday.

## The coffin designed to eat the human body
 - [https://www.cnn.com/2021/11/17/europe/loop-mycelium-mushroom-coffin-eco-funeral-spc-intl/index.html](https://www.cnn.com/2021/11/17/europe/loop-mycelium-mushroom-coffin-eco-funeral-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 08:36:19+00:00

Fungi are not fussy diners. Cardboard, plastic, jet fuel and asbestos -- fungi will devour them all. In 2007, scientists studying Chernobyl's blighted landscape discovered a fungus capable of "eating" radiation. It almost goes without saying, then, that fungi have little trouble decomposing us.

## Indian comedian Vir Das sparks explosive online debate with controversial tale of 'two Indias'
 - [https://www.cnn.com/2021/11/17/india/india-comedian-vir-das-criticism-intl-hnk/index.html](https://www.cnn.com/2021/11/17/india/india-comedian-vir-das-criticism-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 08:14:19+00:00

A comedian's powerful monologue addressing some of India's most sensitive issues including rape and farmers' protests has split opinion in the country, with right-wing activists calling for his arrest while supporters rally to his defense.

## Evergrande chief sold $1.1 billion of personal assets to prop up company: reports
 - [https://www.cnn.com/2021/11/17/investing/evergrande-debt-chairman-sells-assets-intl-hnk/index.html](https://www.cnn.com/2021/11/17/investing/evergrande-debt-chairman-sells-assets-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 07:21:46+00:00

Evergrande chairman Xu Jiayin has sold more than 7 billion yuan ($1.1 billion) worth of personal assets to prop up his embattled company, Chinese state media reported this week.

## Expert: China will need 20 to 30 years to pose credible threat to US Navy
 - [https://www.cnn.com/videos/world/2021/11/17/china-asia-growing-arms-race-ripley-intl-ovn-vpx.cnn](https://www.cnn.com/videos/world/2021/11/17/china-asia-growing-arms-race-ripley-intl-ovn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 06:24:20+00:00

While China is building nuclear-capable missile silos, enlarging their navy and flying warplanes, countries like Taiwan, Japan, North and South Korea and Australia are ramping up their military forces in an effort to counter China's growing threat. Through an analysis of satellite images and speaking with experts, CNN's Will Ripley breaks down the growing arms race in Asia that could threaten the US and the rest of the world.

## Jurors to begin second day of deliberations in Kyle Rittenhouse's homicide trial
 - [https://www.cnn.com/2021/11/17/us/kyle-rittenhouse-trial-wednesday/index.html](https://www.cnn.com/2021/11/17/us/kyle-rittenhouse-trial-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 06:20:26+00:00

A jury of 12 people will begin a second day of deliberations Wednesday morning in Kyle Rittenhouse's homicide trial for the fatal shooting of two people and wounding of another during last year's unrest in Kenosha, Wisconsin.

## Harry Styles launches range of gender-neutral nail polishes
 - [https://www.cnn.com/style/article/harry-styles-beauty-brand-pleasing/index.html](https://www.cnn.com/style/article/harry-styles-beauty-brand-pleasing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 05:25:59+00:00

Singer Harry Styles, who is known for his gender-fluid wardrobe and love of nail polish, has launched his own beauty brand, Pleasing.

## Why overturning Roe v. Wade would be a disaster for conservatives
 - [https://www.cnn.com/2021/11/16/opinions/roe-v-wade-overturn-conservatives-filipovic/index.html](https://www.cnn.com/2021/11/16/opinions/roe-v-wade-overturn-conservatives-filipovic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 04:28:26+00:00

Here's the best-kept secret about the so-called abortion "debate" in the United States: It's actually not that much of a debate at all. A majority of Americans believe that the decision to end or continue a pregnancy should be left to a woman and her doctor, not the state. Most Americans oppose laws that make it more difficult for reproductive health clinics to operate. The Supreme Court is scheduled to hear arguments next month challenging Roe v. Wade, the 1973 decision that legalized abortion nationwide, but fewer than a third of Americans want Roe to be overturned.

## Vials labeled 'smallpox' found at vaccine research facility in Pennsylvania, CDC says
 - [https://www.cnn.com/2021/11/16/health/smallpox-vials-found/index.html](https://www.cnn.com/2021/11/16/health/smallpox-vials-found/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 04:23:08+00:00

Several vials labeled "smallpox" have been found at a vaccine research facility in Pennsylvania, the US Centers for Disease Control and Prevention said Tuesday.

## Armenia and Azerbaijan agree ceasefire after border clash, Armenian Defense Ministry says
 - [https://www.cnn.com/2021/11/16/europe/armenia-azerbaijan-ceasefire-intl-hnk/index.html](https://www.cnn.com/2021/11/16/europe/armenia-azerbaijan-ceasefire-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 03:25:46+00:00

Armenia and Azerbaijan agreed on Tuesday to a ceasefire at their border, the Armenian Defense Ministry said, after Russia urged them to step back from confrontation following the deadliest clash since a war last year.

## Frida Kahlo painting sets new auction record
 - [https://www.cnn.com/style/article/frida-kahlo-self-portrait-auction-intl-scli/index.html](https://www.cnn.com/style/article/frida-kahlo-self-portrait-auction-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 02:52:03+00:00

A self-portrait by Frida Kahlo has become the most expensive work by a Latin American artist ever to sell at auction, fetching $34.9 million in New York on Tuesday.

## CNN anchor 'disapparates' at end of segment
 - [https://www.cnn.com/videos/entertainment/2021/11/17/harry-potter-reunion-hbo-max-tgb-intl-vpx.cnn](https://www.cnn.com/videos/entertainment/2021/11/17/harry-potter-reunion-hbo-max-tgb-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 02:26:03+00:00

The cast of "Harry Potter" is coming together for a new special, set to premiere on HBO Max on January 1. Daniel Radcliffe, Rupert Grint and Emma Watson are expected to take part in "Harry Potter 20th Anniversary: Return to Hogwarts." CNN's Bianca Nobilo has more.

## Skin lightening is an $8.6 billion industry. This woman is trying to stop it
 - [https://www.cnn.com/videos/world/2021/11/11/ending-skin-lightening-beautywell-orig-ts-mss.cnn](https://www.cnn.com/videos/world/2021/11/11/ending-skin-lightening-beautywell-orig-ts-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 02:18:35+00:00

For over a decade, Amira Adawe has devoted her life to putting an end to the skin lightening industry, particularly the use of creams that contain toxic levels of mercury. Here's how she's doing it.

## 6 amazing train journeys for food, scenery and culture
 - [https://www.cnn.com/travel/article/asia-best-train-journeys-cmd/index.html](https://www.cnn.com/travel/article/asia-best-train-journeys-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 01:53:16+00:00

The Covid-19 pandemic has derailed many family reunions, destination weddings and long-awaited trips. And while some would-be globetrotters miss the hyper pace of travel circa 2019, others plan to adjust their travel style completely.

## Trump-backed candidate has history of homophobic and hateful speech
 - [https://www.cnn.com/videos/politics/2021/11/17/kristina-karamo-secretary-of-state-candidate-michigan-election-lies-murray-dnt-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2021/11/17/kristina-karamo-secretary-of-state-candidate-michigan-election-lies-murray-dnt-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 01:13:07+00:00

Kristina Karamo, the candidate Donald Trump is backing to be Michigan's next secretary of state, has falsely claimed the former President was the true victor in Michigan in 2020 and has spread the conspiracy theory that left-wing anarchists were behind the January 6 attack on the Capitol.

## Oprah's lyrical fail at Adele concert goes wild on internet
 - [https://www.cnn.com/videos/entertainment/2021/11/17/oprah-adele-lyrics-concert-jeanne-moos-vpx.cnn](https://www.cnn.com/videos/entertainment/2021/11/17/oprah-adele-lyrics-concert-jeanne-moos-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-17 00:31:53+00:00

Oprah enthusiastically flubs lyrics while singing during Adele concert. CNN's Jeanne Moos reports it's not Oprah's first lyric fail.

