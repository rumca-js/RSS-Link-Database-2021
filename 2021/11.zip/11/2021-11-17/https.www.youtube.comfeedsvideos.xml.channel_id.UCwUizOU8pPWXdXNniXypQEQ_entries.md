# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Australian TOTALITARIAN Tourism Commercial – 14 Reasons to Visit!
 - [https://www.youtube.com/watch?v=mJqyKEWg6cg](https://www.youtube.com/watch?v=mJqyKEWg6cg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-11-17 00:00:00+00:00

Grab your Blue Light Blocking Glasses at https://blublox.com/jp
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Australian totalitarian tourism board - 14 reasons to visit! You’ll love what’s changed about Australia since it was a free country!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

