# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This is NOT a Soundbar - Sony HT-A9 Home Theater System
 - [https://www.youtube.com/watch?v=BPcrpFjw4X8](https://www.youtube.com/watch?v=BPcrpFjw4X8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-18 00:00:00+00:00

Thanks to Sony for sponsoring this video! Check out the HT-A9 sound system at https://lmg.gg/HAbjH

Sony has been well known for its home entertainment products; Playstation, TVs, and home theatre sounds systems. The HT-A9 is a reasonably robust system that doesn't replace a full-fledged speaker setup, but when you need something simple, easy, and performs almost as well, you should check this out!

Buy Sony A90J TV
On Amazon (PAID LINK): https://geni.us/0GQ4B
On Best Buy (PAID LINK): https://geni.us/AHiAj
On Newegg (PAID LINK): https://geni.us/fEUE

Buy Sony SA-SW5 Wireless Subwoofer
On Amazon (PAID LINK): https://geni.us/g2BJ
On B&H (PAID LINK): https://geni.us/Q0wvDk

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1389433-the-invisible-soundbar-sponsored/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:05 HT-A9 Unboxing and overview
4:40 Furniture setup
7:00 Sony A90J TV setup
9:05 Setting up the speakers
13:20 Trying the speakers
14:07 Initial impressions
15:08 Further test
15:38 Movie test
16:40 Closing thoughts

## LTT is About to Change.
 - [https://www.youtube.com/watch?v=pt3-6BsWlPk](https://www.youtube.com/watch?v=pt3-6BsWlPk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-17 00:00:00+00:00

Get 10% off all Jackery products with code LinusTechTips at https://www.jackery.com?aff=27

Get your custom pre-built PC with NZXT BLD: https://nzxt.co/LinusBLDNov21

In this video, Linus outlines his plan to increase LMG's testing capabilities with new tools, a new space, and new people. That's right: WE'RE HIRING.

Check out the available positions at https://lmg.gg/lmgjobs

Buy Xbox Series X
On Amazon (PAID LINK): https://geni.us/yjCi
On Best Buy (PAID LINK): https://geni.us/4XMo
On Newegg (PAID LINK): https://geni.us/BAobwq9

Buy NVIDIA SHIELD Pro
On Amazon (PAID LINK): https://geni.us/XaFV
On Best Buy (PAID LINK): https://geni.us/AQlAGm
On Newegg (PAID LINK): https://geni.us/tYRQlI

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1389194-ltt-is-about-to-change/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:51 The Vision
2:15  Floatplane Hiring
3:22 Potential Equipment
6:16 More Nerd Stuff
8:06 Phone Testing
8:53 Display Testing
9:37 LTTstore.com
10:56 Who should apply?
12:08 Outro

