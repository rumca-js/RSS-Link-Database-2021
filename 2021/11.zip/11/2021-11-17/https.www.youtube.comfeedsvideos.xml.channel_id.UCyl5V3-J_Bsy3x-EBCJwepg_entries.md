# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Leftist Memes DESTROYED in 5 Minutes
 - [https://www.youtube.com/watch?v=PcwbTQ5AznI](https://www.youtube.com/watch?v=PcwbTQ5AznI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-18 00:00:00+00:00

Kyle, Ethan, and Zo examine terrible leftist memes.

Watch the full show: https://youtu.be/Yc4QW5WTin8

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Husband Fights Patriarchy By Letting Wife Change Car Tire
 - [https://www.youtube.com/watch?v=j3jGG32ekdk](https://www.youtube.com/watch?v=j3jGG32ekdk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-17 00:00:00+00:00

If you are male, you are toxic. So fight the patriarchy! Watch and learn how to get rid of your toxic masculinity from this feminist husband.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

