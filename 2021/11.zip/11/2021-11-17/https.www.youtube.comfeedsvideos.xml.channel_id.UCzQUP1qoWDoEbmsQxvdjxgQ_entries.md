# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Social Dilemma's Tristan Harris on Technology Moving Faster Than Regulation
 - [https://www.youtube.com/watch?v=eq_gaazINkA](https://www.youtube.com/watch?v=eq_gaazINkA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-18 00:00:00+00:00

Taken from JRE #1736 w/Tristan Harris & Daniel Schmachtenberger:
https://open.spotify.com/episode/2LNwwgJqOMKHOqdvwmLxqd?si=07cb424d340243eb

## What China's Crackdown on Algorithm's Means for the US
 - [https://www.youtube.com/watch?v=im4O2sW3FiY](https://www.youtube.com/watch?v=im4O2sW3FiY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-18 00:00:00+00:00

Taken from JRE #1736 w/Tristan Harris & Daniel Schmachtenberger:
https://open.spotify.com/episode/2LNwwgJqOMKHOqdvwmLxqd?si=07cb424d340243eb

## Peter Attia Almost Worked for Theranos
 - [https://www.youtube.com/watch?v=OMzjWh96wro](https://www.youtube.com/watch?v=OMzjWh96wro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-17 00:00:00+00:00

Taken from JRE #1737 w/Peter Attia:
https://open.spotify.com/episode/5DuxGhOJSa7X0AKvJGwwta?si=d6658ed796c14ce0

## Peter Attia on The Best Exercises for Longevity
 - [https://www.youtube.com/watch?v=92kYDVjX0G0](https://www.youtube.com/watch?v=92kYDVjX0G0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-17 00:00:00+00:00

Taken from JRE #1737 w/Peter Attia:
https://open.spotify.com/episode/5DuxGhOJSa7X0AKvJGwwta?si=d6658ed796c14ce0

