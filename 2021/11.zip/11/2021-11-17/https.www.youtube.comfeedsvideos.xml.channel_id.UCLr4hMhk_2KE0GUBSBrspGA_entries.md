# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Pixel 6 - Co myślę?
 - [https://www.youtube.com/watch?v=y5v2pLee5sY](https://www.youtube.com/watch?v=y5v2pLee5sY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-11-18 00:00:00+00:00

NIe tylko o Pixelu zresztą. Wpadłem na pomysł podzielenia się z Wami również innymi myślami, które prawdopodobnie w ogóle Was nie interesują, więc zapraszam!
Odcinek zawiera lokowanie aplikacji ZEN. Z kodem "KlawyZen" możecie jej używać przez 4 miesiące za darmo: https://bit.ly/3rklh8W
EDIT z dnia 29.09.2022 - w związku ze zmianą planów taryfowych ZEN, uległa zmianie również liczba dni darmowej subskrypcji kodów dedykowanych. Od teraz są to 2 miesiące zamiast 4.

Film Becci (Pixel vs iPhone): https://youtu.be/eAxbBbi_Mmw
Porównanie foto video Pixeli: https://youtu.be/xLyjICSEkDc

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku: 
00:00 Oczekiwania
00:39 Skórzany portfel od Apple
00:52 Pixel 6 Pro i Pixel 6: wideo w 4K i Full HD - porównanie
01:28 Portfel z MagSafe do iPhone’a – test przyczepności
02:37 O byciu odpowiedzialnym w kwestii dawania prezentów
03:07 O ekonomii
03:45 Fragment sponsorowany – lokowanie ZEN
04:27 Pixel 6 x Pixel 6 Pro – wygląd
04:54 Bateria
05:01 Czytnik linii papilarnych
05:33 Funkcja: magiczna gumka
05:56 Równowaga i oczywiste oczywistości
06:25 Nowe procesory
07:41 Co ma znaczenie? Hardware czy software?
08:07 Aparaty: foto i wideo (Pixel 6 Pro vs. iPhone 13 Pro)
08:50 Pixel 6 Pro vs, Samsung S21 Ultra 5G – foto wideo
09:30 Porównanie iPhone’a i Pixela
10:02 Przemyślenia o lotach samolotem i porównanie zdjęć
10:43 Podsumowanie możliwości aparatów iPhone’a, Samsunga i Pixela
11:33 Komentarze pod filmami innych twórców
11:50 Książka „YouTube Formula”
13:12 Rozmiary smartfonów - zestawienie
13:32 Ekrany
13:38 Odesłanie do filmu z porównaniem nagrań i zdjęć z Pixela 6 i Pixela 6 Pro
14:24 Nagrywanie dźwięku
14:41 Różnice między Pixelami
14:55 Bateria c.d.
15:24 Osiągi
15:38 Gdzie można kupić Pixela i za ile?
16:12 5G i VoLTE niedostępne w Polsce
16:54 Temat youtuberów
17:13 Do zobaczenia

