# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Ostatnie dni w Nikaragui i wylot na Kubę
 - [https://www.youtube.com/watch?v=OGI_MJhJdwA](https://www.youtube.com/watch?v=OGI_MJhJdwA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2021-11-29 00:00:00+00:00

Zrzutka dla zwierząt z Filipin: https://zrzutka.pl/pomocnalapka2

Sklep: bezplanu.com

Karelinne: https://www.instagram.com/kxrelinne/?hl=en
Cash: @vlogcasha 

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Wsparcie na Patronite: http://bit.ly/2KsFTZk 

Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv

Czas akcji: listopad 2021r.

