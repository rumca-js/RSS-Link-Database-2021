# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Sealed for 15 Years! - iPod nano Historical Unboxing
 - [https://www.youtube.com/watch?v=ePBuR80UTzo](https://www.youtube.com/watch?v=ePBuR80UTzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2021-11-30 00:00:00+00:00

Quinn from Snazzy Labs opens a first-generation iPod nano—one of Apple's most important products ever.
Check out Canva today! https://canva.me/snazzylabs

Shop Apple for the holidays and support Snazzy Labs! - https://amzn.to/3xFKvTj

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

This is a sealed in-box, never-opened first generation iPod nano—a device that I consider one of Apple’s most important products ever—and it’s one with a fascinating history. But before we get to this, we gotta rewind a bit because there's a lot of history from Apple's near-bankruptcy in the 90s to where they are today.

