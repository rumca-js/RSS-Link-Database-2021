# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Masters Of The Universe Part 2 - This Time It's Farcical
 - [https://www.youtube.com/watch?v=u9lXAt8gyJk](https://www.youtube.com/watch?v=u9lXAt8gyJk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-11-30 00:00:00+00:00

If you thought it was bad first time around, you ain't seen nothing yet. Will Prince Adam pull through? Will Skeletor rule Eternia forever? Does anyone even care? Grab your protein shakes and join me as I review Masters of the Universe Revelation Part 2.

