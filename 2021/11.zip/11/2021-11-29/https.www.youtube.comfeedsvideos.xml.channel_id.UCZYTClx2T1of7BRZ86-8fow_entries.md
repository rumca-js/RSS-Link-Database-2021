# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## These Ancient Footprints Changed History as We Know It
 - [https://www.youtube.com/watch?v=y9yD9ru0Jrk](https://www.youtube.com/watch?v=y9yD9ru0Jrk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-11-29 00:00:00+00:00

Our friends at MinuteEarth just released a new book! To check out “How Did Whales Get So Big?” head to: https://www.minuteearth.com/books/

By studying the footprints of ancient humans, we can help uncover how and when our ancestors migrated across the world.  Join SciShow & Stefan Chin for an amazing journey back in time to the very early history of the human species. 

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Alisa Sherbow, Silas Emrys, Chris Peters, Adam Brainard, Dr. Melvin Sanicas, Melida Williams, Jeremy Mysliwiec, charles george, Tom Mosner, Christopher R Boucher, Alex Hackman, Piya Shedden, GrowingViolet, Nazara, Matt Curls, Ash, Eric Jensen, Jason A Saslow, Kevin Bealer, Sam Lutfi, James Knight, Christoph Schwanke, Bryan Cloer, Jeffrey Mckishen

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
http://www.antarcticglaciers.org/2017/06/global-last-glacial-maximum/
https://www.science.org/content/article/human-footprints-near-ice-age-lake-suggest-surprisingly-early-arrival-americas
https://www.science.org/content/article/most-archaeologists-think-first-americans-arrived-boat-now-they-re-beginning-prove-it
https://www.science.org/news/2016/05/ancient-stone-tools-are-best-evidence-yet-early-peopling-americas
https://www.science.org/doi/full/10.1126/science.abg7586?casa_token=zVUJjobz88MAAAAA:epNP7Xdlp16QLtm1emBSIWWYI7UbOMAwoO1fOHAMTXwxDziLOksMNG4ZcPyI4q3OfPDXrxf5rf_2XQ
https://www.science.org/content/article/were-humans-living-mexican-cave-during-last-ice-age
https://www.livescience.com/51793-extinct-ice-age-megafauna.html
https://www.science.org/doi/10.1126/sciadv.aar5040?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed
http://palaeos.com/time/cosmic_calendar.html

Images:
https://www.istockphoto.com/photo/roman-forum-at-sunrise-from-left-to-right-temple-of-vespasian-and-titus-church-of-gm675049578-123868323
https://commons.wikimedia.org/wiki/File:Spreading_homo_sapiens.svg
https://commons.wikimedia.org/wiki/File:IceAgeEarth.jpg
https://www.istockphoto.com/photo/alaska-and-bering-sea-gm181061119-25566850
https://commons.wikimedia.org/wiki/File:Peopling_of_America_through_Beringia.png
https://commons.wikimedia.org/wiki/File:Assumed_path_of_Beringian_wolves_from_Beringia_to_Wyoming.png
https://www.istockphoto.com/photo/archaeological-excavations-archaeologists-work-dig-up-an-ancient-clay-artifact-with-gm1307568921-397797184
https://www.istockphoto.com/vector/antique-illustration-of-prehistoric-flint-weapons-gm508450646-85266447
https://commons.wikimedia.org/wiki/File:Aerial_view_of_dunefield,_White_Sands_National_Park,_New_Mexico,_United_States.png
https://www.flickr.com/photos/travelwayoflife/6164348161/in/photostream/
https://commons.wikimedia.org/wiki/File:Pleistocene_SA.jpg
https://www.eurekalert.org/multimedia/804404
https://www.istockphoto.com/photo/people-of-the-ice-age-gm537816437-58008984

