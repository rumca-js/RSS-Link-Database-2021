# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## LAST CHANCE!!! Only a few boxes left...
 - [https://www.youtube.com/watch?v=VjQMk-orXps](https://www.youtube.com/watch?v=VjQMk-orXps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-11-30 00:00:00+00:00

It’s Giving Tuesday, and we’re almost out of Pompla-MOOSE ornaments! Go to https://pomplamoose.com to support Save the Children, and we’ll send you a Holiday Box with one adorable moose ornament and two albums!

