# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Labour shortage: Is Santa Claus coming to town this year?
 - [https://www.bbc.co.uk/news/world-us-canada-59466832?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59466832?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 23:39:23+00:00

With fewer Santas donning their suits and more demand for holiday cheer, Santa will be in short supply.

## Video appears to show UK F-35 fighter crash after take-off
 - [https://www.bbc.co.uk/news/uk-59470276?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59470276?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 22:30:55+00:00

Dramatic footage of what appears to be a jet crashing off the aircraft carrier HMS Queen Elizabeth was posted on Twitter.

## Ballon d'Or 2021: Watch Lionel Messi win record seventh trophy
 - [https://www.bbc.co.uk/sport/av/football/59470734?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/59470734?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 21:50:14+00:00

Watch the moment Paris St-Germain and Argentina forward Lionel Messi wins a record seventh Ballon d'Or, beating Robert Lewandowski and Jorginho.

## Signs life is returning to normal at I’m A Celeb
 - [https://www.bbc.co.uk/news/uk-wales-59468768?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59468768?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 20:24:03+00:00

Live episodes are set to return on Tuesday after damage was caused to the set by Storm Arwen.

## Nicola Sturgeon: The first minister's conference speech fact-checked
 - [https://www.bbc.co.uk/news/59464428?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59464428?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 17:18:22+00:00

Scotland's first minister delivered her keynote address at the SNP party conference.

## Paralysed Tylicki sues fellow jockey Gibbons for £6m over fall
 - [https://www.bbc.co.uk/sport/horse-racing/59460182?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/horse-racing/59460182?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 16:47:55+00:00

Former Flat jockey Freddy Tylicki's £6m negligence claim against fellow rider Graham Gibbons begins in the High Court.

## Virgil Abloh: How he 'helped black people dream in fashion'
 - [https://www.bbc.co.uk/news/newsbeat-59414088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-59414088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 16:05:36+00:00

Radio 1 Newsbeat has been speaking to people about the legacy Virgil Abloh leaves behind.

## Matiu Ratana: Memorial held for Met Police sergeant shot dead
 - [https://www.bbc.co.uk/news/uk-england-london-59461149?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59461149?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:27:24+00:00

A memorial service to Sgt Matiu Ratana, delayed for a year by the pandemic, is held in Westminster.

## Covid in Scotland: 'Test much more' plea after Omicron cases found
 - [https://www.bbc.co.uk/news/uk-scotland-59457332?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-59457332?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:26:09+00:00

First Minister Nicola Sturgeon calls for increased compliance with measures to stop the spread of the virus.

## SNP conference: Scottish child payment to double to £20 from April
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-59453494?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-59453494?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:18:04+00:00

Nicola Sturgeon tells the SNP conference that eradicating child poverty is "essential" to Scotland's future.

## Magdalena Andersson: Sweden's first female PM returns after resignation
 - [https://www.bbc.co.uk/news/world-europe-59459733?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59459733?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:17:12+00:00

Magdalena Andersson is backed by MPs again, despite standing down last week hours into the job.

## Covid: JCVI scientists to announce decision on booster rollout
 - [https://www.bbc.co.uk/news/uk-59455914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59455914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:12:23+00:00

A reduction in time between doses and extending the scheme to younger age groups could be approved.

## Storm Arwen: Third night of no power for thousands
 - [https://www.bbc.co.uk/news/uk-scotland-59457045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-59457045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:10:56+00:00

Energy firms say the storm caused "catastrophic damage" three times greater than that caused by the Beast from the East.

## Sir Keir Starmer begins reshuffle of Labour shadow cabinet
 - [https://www.bbc.co.uk/news/uk-politics-59461674?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-59461674?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:10:16+00:00

Deputy Angela Rayner says she doesn't "know the details", as the Labour leader reorganises his frontbench.

## Khan and Brook to fight in February
 - [https://www.bbc.co.uk/sport/boxing/59443132?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/59443132?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 13:00:24+00:00

Amir Khan will take on fellow former world champion Kell Brook in Manchester on 19 February.

## Manchester United appoint Ralf Rangnick as interim manager
 - [https://www.bbc.co.uk/sport/football/59439956?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59439956?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 12:46:17+00:00

Manchester United announce the appointment of Ralf Rangnick as their interim manager until the end of the season, subject to work visa requirements.

## Covid: Omicron variant causes passengers to scramble for flights
 - [https://www.bbc.co.uk/news/business-59461318?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59461318?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 12:43:10+00:00

One traveller told the BBC he had found an alternative flight home, but he faces extra costs of £4,000.

## Odell Beckham, Fournette, & Jared Cook in NFL plays of the week
 - [https://www.bbc.co.uk/sport/av/american-football/59461831?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/59461831?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 12:08:25+00:00

Odell Beckham Jr scores his first touchdown for the LA Rams and there are pick sixes galore in week 12's NFL plays of the week.

## Storm Arwen: Trapped Tan Hill Inn guests leave
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-59459150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-59459150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 11:52:53+00:00

The Tan Hill Inn manager says the experience and their guests were "wonderful".

## Last-wicket pair deny India as New Zealand secure thrilling draw
 - [https://www.bbc.co.uk/sport/cricket/59460060?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59460060?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 11:36:23+00:00

New Zealand bat out the whole of day five to dramatically survive with a draw in the first Test against India.

## Ava White: Boy, 14, in court accused of girl's murder in Liverpool
 - [https://www.bbc.co.uk/news/uk-england-merseyside-59456938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-59456938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 11:11:14+00:00

The teenager is charged with murdering 12-year-old Ava White, who was stabbed in Liverpool.

## Radio 4's Today programme temporarily drops off air
 - [https://www.bbc.co.uk/news/entertainment-arts-59457543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59457543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 09:05:11+00:00

The BBC show went silent on Monday morning when a fire alarm told people to leave the building.

## Queen of Barbados - but just for one last day
 - [https://www.bbc.co.uk/news/uk-59458431?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59458431?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 09:02:46+00:00

The island nation will remove Queen Elizabeth as head of state and swear in its first Barbadian president.

## Williams falls asleep during UK Championship defeat
 - [https://www.bbc.co.uk/sport/snooker/59457433?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/59457433?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 07:31:19+00:00

Three-time world champion Mark Williams falls asleep in his chair during a surprise second-round defeat by Anthony Hamilton in the UK Championship.

## The 'map nerds' who are building a national archive
 - [https://www.bbc.co.uk/news/uk-scotland-59374045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-59374045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 06:36:47+00:00

Thousands of volunteers capture images across Britain and Ireland as part of a project called Geograph.

## Does Nicola Sturgeon's legacy rely on indyref2?
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-59453148?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-59453148?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 06:25:24+00:00

Nicola Sturgeon still aims to deliver independence - but is her legacy as first minister secure even without it?

## Matiu Ratana: Colleagues pay tribute to 'inspiring' officer
 - [https://www.bbc.co.uk/news/uk-england-london-59419923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59419923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 05:34:09+00:00

The memorial service for an officer murdered in the line of duty in Croydon took place on Monday.

## The Papers: Boosters 'for all adults' amid 'fight to save Xmas'
 - [https://www.bbc.co.uk/news/blogs-the-papers-59455545?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59455545?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 05:33:12+00:00

Monday's front pages are dominated by the latest developments surrounding the Omicron variant.

## Barbados prepares to cut ties with the Queen
 - [https://www.bbc.co.uk/news/world-latin-america-59438437?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-59438437?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 05:01:20+00:00

Watch as we travel to the island to find out what Barbadians make of the move.

## Madhya Pradesh: Man builds Taj Mahal replica home for wife
 - [https://www.bbc.co.uk/news/world-asia-india-59383558?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-59383558?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 04:12:46+00:00

The 52-year-old said he constructed the scaled-down four-bedroom house as a “monument of love”.

## Ghislaine Maxwell's sex-trafficking trial to begin in New York City
 - [https://www.bbc.co.uk/news/world-us-canada-59455605?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59455605?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 04:09:34+00:00

The UK socialite denies grooming girls for convicted paedophile Jeffrey Epstein to sexually abuse.

## Omicron: Is India ready for a third wave?
 - [https://www.bbc.co.uk/news/world-asia-india-59344605?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-59344605?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 03:32:01+00:00

Experts say the government needs to first fulfil its promises to boost the public health system.

## The underwater 'kites' generating electricity as they move
 - [https://www.bbc.co.uk/news/business-59401199?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59401199?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 00:19:23+00:00

Tidal power generators that look like aircraft are being tested in the sea off the Faroe Islands.

## Joseph Kabila and DR Congo's missing millions
 - [https://www.bbc.co.uk/news/world-africa-59436588?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-59436588?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 00:16:40+00:00

Millions of dollars of public funds went through bank accounts of ex-President Joseph Kabila's allies, BBC Africa Eye reveals.

## Venezuelan migrants seeking a new home in Chile
 - [https://www.bbc.co.uk/news/world-latin-america-59438026?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-59438026?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 00:04:34+00:00

Tens of thousands of Venezuelans escaping poverty and violence at home are risking their lives to travel south to Chile.

## Gay and Muslim: Family wanted to 'make me better'
 - [https://www.bbc.co.uk/news/newsbeat-59320090?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-59320090?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 00:02:33+00:00

Asad struggled with his mental health and suicidal thoughts when he came out to his religious family.

## Emma Day murder: Sister of mother killed by ex calls for changes
 - [https://www.bbc.co.uk/news/uk-england-london-59405075?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59405075?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 00:02:23+00:00

The Met and the Child Maintenance Service admitted faults were made in the handling of Emma Day's case.

## How Britain protects its nuclear material
 - [https://www.bbc.co.uk/news/uk-59434555?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59434555?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-29 00:02:01+00:00

This highly specialised team guards Britain's radioactive stockpiles.

