# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Crazy Little Thing Called Love | Queen | funk cover ft. Casey Abrams
 - [https://www.youtube.com/watch?v=lCnZCGl9qjw](https://www.youtube.com/watch?v=lCnZCGl9qjw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-11-29 00:00:00+00:00

1 DAY LEFT to reserve your limited edition "Scary Goldings IV" vinyl! Join our Vinyl Club tier on Patreon: http://patreon.com/scarypockets

Store/Tour Tickets: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Queen's "Crazy Little Thing Called Love" by Scary Pockets & Casey Abrams.

MUSICIAN CREDITS
Lead vocal: Casey Abrams
Drums: Darren King
Bass: Joe Ayoub
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Alejandro Echevarria
Editor: Adam Kritzberg

Recorded Live at Sunset Sound in Los Angeles, CA.

#ScaryPockets #Funk #Queen #CrazyLittleThingCalledLove #CaseyAbrams

