# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Ted Nugent Defends Helicopter Pig Hunting
 - [https://www.youtube.com/watch?v=EvhkIS_-K-w](https://www.youtube.com/watch?v=EvhkIS_-K-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-30 00:00:00+00:00

Taken from JRE #1741 w/Ted Nugent:
https://open.spotify.com/episode/5qMXaILeyvp5ze7K2TwkP7?si=19e5d8bfe65743e5

## Ted Nugent on the Origins of Stranglehold
 - [https://www.youtube.com/watch?v=lcNblBw9O84](https://www.youtube.com/watch?v=lcNblBw9O84)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-11-30 00:00:00+00:00

Taken from JRE #1741 w/Ted Nugent:
https://open.spotify.com/episode/5qMXaILeyvp5ze7K2TwkP7?si=19e5d8bfe65743e5

