# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## JD McPherson - two songs for The Current (2012)
 - [https://www.youtube.com/watch?v=yud37RTMEZY](https://www.youtube.com/watch?v=yud37RTMEZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-30 00:00:00+00:00

Nine years ago today — on Nov. 29, 2012 — JD McPherson visited The Current studio; it was his third session for The Current that year! JD McPherson and his band will be back in the Twin Cities on Dec. 14, 2021, to play at the Cedar Cultural Center in Minneapolis as part of this year's "SOCKS: A Rock N’ Roll Christmas Tour."
Watch two songs JD McPherson recorded for The Current in 2012.

SONGS PERFORMED
0:00 "Fire Bug"
2:31 "North Side Gal"

PERSONNEL
JD McPherson – vocals, guitar
Doug Corcoran – saxophone, guitar, xylophone, backing vocals
Ray Jacildo – piano, organ, backing vocals
Jason Smay – drums 
Jimmy Sutton – bass, backing vocals

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark; Erik Stromstad
Production: Derrick Stevens

FIND MORE:
2012 July studio session: https://www.thecurrent.org/feature/2012/07/06/jd-mcpherson-performs-in-the-current-studios
2012 November studio session:
https://www.thecurrent.org/feature/2012/11/29/jd-mcpherson-live
2014 studio session: https://www.thecurrent.org/feature/2014/09/14/jd-mcpherson-performs-in-the-current-studio
2015 studio session:
https://www.thecurrent.org/feature/2015/02/14/jd-mcpherson-performs-in-the-current-studio
2015 Rock the Garden set:
https://www.thecurrent.org/feature/2015/07/01/jd-mcpherson-live-at-rock-the-garden-2015
2018 studio session:
https://www.thecurrent.org/feature/2018/12/04/jd-mcpherson-and-band-pull-up-their-socks-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#jdmcpherson

## Interview: Kacey Musgraves talks Star-Crossed, and blending genres
 - [https://www.youtube.com/watch?v=ztQJ7JfcKuc](https://www.youtube.com/watch?v=ztQJ7JfcKuc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-11-29 00:00:00+00:00

Following the releases of her 2021 record "Star-Crossed," Kacey Musgraves joins The Current's Jill Riley in conversation about pulling from multiple genres in her sound, the nonlinear stages of grief that followed her divorce and how they came through on the record, and her upcoming appearance on Sesame Street.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits
Host - Jill Riley
Guest - Kacey Musgraves
Producers - Jesse Wiza, Anna Weggel
Technical Director - Eric Romani

