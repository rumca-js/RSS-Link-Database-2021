# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Halo Infinite Multiplayer - Before You Buy
 - [https://www.youtube.com/watch?v=zlHRWtc3XEM](https://www.youtube.com/watch?v=zlHRWtc3XEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-30 00:00:00+00:00

Halo Infinite's multiplayer (PC, Xbox Series X/S/One) is here and available to download for free. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#Halo #HaloInfinite

## 10 WEIRD Gaming Stories of November 2021
 - [https://www.youtube.com/watch?v=n_AFMTEBS-I](https://www.youtube.com/watch?v=n_AFMTEBS-I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-29 00:00:00+00:00

November 2021 had plenty of weird and strange news stories in the gaming world. Here are some of our favorites, from God of War rip-offs to Battlefield 2042 glitches.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

SOURCES:

BF2042 grappling hook:
https://www.reddit.com/r/battlefield2042/comments/r2ke16/yes_you_can_grapple_onto_smoke/
https://youtu.be/ulllqO6j7-s

https://www.theverge.com/2021/11/6/22767046/someone-stole-shipment-evga-rtx-graphics-cards

https://www.reddit.com/r/gaming/comments/r19g6d/this_mobile_game_company_is_shameless_about_their/

https://www.forbes.com/sites/paultassi/2021/11/20/battlefield-2042-has-entered-steams-10-worst-reviewed-games-of-all-time-list/?sh=6dddc4a1110f

https://www.engadget.com/sony-may-be-cutting-play-station-5-production-even-more-than-it-forecast-085009885.html

https://www.youtube.com/watch?v=y0wjaeEiin8&t=17s&ab_channel=ViktorT%C3%B3th

https://screenrant.com/battlefield-2042-grapple-gun-smoke-tornadoes/

https://www.pcgamer.com/new-world-rolls-back-eu-server-after-accidentally-showering-players-with-gold/

https://kotaku.com/fans-are-bringing-playstation-home-back-to-life-1848129254

https://mp1st.com/news/someone-has-computed-how-much-it-costs-to-buy-all-the-marvels-avengers-cosmetic-items

https://kotaku.com/microsoft-publishes-1999-letter-from-failed-attempt-to-1848113468

