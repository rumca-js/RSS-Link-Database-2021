## Welcome to Fleet! | JetBrains News
 - [https://blog.jetbrains.com/blog/2021/11/29/welcome-to-fleet/](https://blog.jetbrains.com/blog/2021/11/29/welcome-to-fleet/)
 - RSS feed: https://blog.jetbrains.com
 - date published: 2021-11-29 16:47:39.791578+00:00

For years folks have been asking us, 

