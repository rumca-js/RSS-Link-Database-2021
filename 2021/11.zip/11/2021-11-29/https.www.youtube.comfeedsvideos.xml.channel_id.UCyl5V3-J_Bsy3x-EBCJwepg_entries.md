# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Comedian Explains the Challenges of Christian Entertainment | A Bee Interview with Thor Ramsey
 - [https://www.youtube.com/watch?v=p4vqQrQ14p8](https://www.youtube.com/watch?v=p4vqQrQ14p8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-30 00:00:00+00:00

On The Babylon Bee Interview Show, Christian comedian, Thor Ramsey, talks to Kyle and Ethan about becoming a Christian stand-up comedian, making the Church People Movie, and doing a political comedy show. Thor Ramsey recently wrote the book, The Most Encouraging Book on Hell Ever, where he tackles the question by probing deeper. Thor starred in Church People, as a Pastor trying to find his passion again inside the mega church marketing machine. The political climate has motivated Thor to start a new web series, The Protest Show.

This episode is brought to you by Faithful Counseling. Go to http://betterhelp.com/babylonbee for 10% off!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Strange But True Bible Facts
 - [https://www.youtube.com/watch?v=dUmou6GBToA](https://www.youtube.com/watch?v=dUmou6GBToA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-11-29 00:00:00+00:00

Want to win Youth Group Bible Trivia Night? Then watch this video for some truly strange facts.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

