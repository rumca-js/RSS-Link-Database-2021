# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Amazon Basics Has a TV Now. Seriously. - Amazon Fire TV
 - [https://www.youtube.com/watch?v=gGHwYMwXX88](https://www.youtube.com/watch?v=gGHwYMwXX88)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-30 00:00:00+00:00

Go to https://privacy.com/linus ​to get $5 off your first purchase!

Get $25 in Ting Mobile credit when you visit https://Linus.Ting.com

Amazon seems to be making their own products for just about every category under the sun, but are they any good? Come find out if their new Fire TV Omni Series is worth your hard-earned cash when looking for your next home theater upgrade.


Buy Amazon Fire TV Omni Series 75": https://geni.us/Jgbr5A

Buy SpectraCal C6 Colorimeter: https://geni.us/Q6AVj

Buy a TCL 75-inch 5-Series 4K TV: https://geni.us/GIqGI

Buy a VIZIO 75-Inch M6 Series Premium 4K TV: https://geni.us/rqCJvpW

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1392420-amazon-basics-has-a-tv-now-seriously/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:05 Fire TV 75" Omni
3:45 Color Accuracy
5:25 FALD
6:12 Linus Watches TV
7:57 Gaming
10:40 Should You Buy It?
12:37 Outro

## Steam Deck was delayed, so I got this - GPD XP
 - [https://www.youtube.com/watch?v=lR0b8fROHNk](https://www.youtube.com/watch?v=lR0b8fROHNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-29 00:00:00+00:00

New Customers Exclusive – Get a Free 240gb SSD at Micro Center: https://micro.center/a439e5
Micro Center Business Solutions: https://micro.center/431a42
Check out the new Supermicro PC Builder: https://micro.center/8e318b

Get your custom pre-built PC with NZXT BLD: https://nzxt.co/LinusBLDNov21

Steam Deck has been making waves, but now that it’s delayed, could the Android-powered GPD XP be the best gaming handheld to hold you over through the holidays?

Buy GPD XP
On Amazon (PAID LINK): https://geni.us/vfF15W
On Newegg (PAID LINK): https://geni.us/lAUPvy

Discuss on the forum: https://linustechtips.com/topic/1392150-steam-deck-was-delayed-so-i-got-this/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:53 What ARE you?
2:05 Tech specs
3:23 Expansion and non-gaming features
4:40 Disassembly
5:13 Gaming experience
6:38 The controls and some annoyances
8:28 Conclusion

