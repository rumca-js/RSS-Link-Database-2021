# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Co kupić na święta gadżeciarzom?
 - [https://www.youtube.com/watch?v=c3woiGgST3E](https://www.youtube.com/watch?v=c3woiGgST3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2021-11-29 00:00:00+00:00

Po filmie w którym opisywałem jak wygląda moje stanowisko pracy, w komentarzach posypało się sporo pytań o przedmioty które opisywałem. Postanowiłem zebrać to w całość oraz dorzucić kilka innych rzeczy. Powstała lista "co kupić na święta?", czy pod choinkę 🎄 dla takiego nerda jak ja i mi podobnych. 🤓

Poniżej wklejam linki do przedmiotów o których opowiadam w dwóch formach - afiliacyjnej💸 i nie-afiliacyjnej🏦. Jeśli chcesz mnie wesprzeć robiąc zakupy, wybierz link afiliacyjny. Jeśli nie masz na to ochoty wybierz ten bez afiliacji. Z góry dziękuję Wam za wsparcie. ❤️

Rozdziały:
0:00 Intro
0:47 Piłka do masażu/rolowania
1:20 Kable magnetyczne Baseus
2:00 Hamak na szyję
2:35 Klucz sprzętowy YubiCo
4:09 Lampka Xiaomi Mi LED Desk Lamp
4:47 Kostka Timeular
5:20 Raspberry Pi 4B
6:11 Podsumowanie

8:32 Podziękowania ❤️

Linki:
🎾 Piłka do masażu/rollowania
💸  Link afiliacyjny: 
https://allegro.pl/oferta/4fizjo-roller-pilka-do-masazu-lacrosse-masazer-6692364641?utm_medium=afiliacja&utm_source=ctr&utm_campaign=e75d9cb2-1a95-4411-98a4-ee8b1371e1a4
🏦 Link bez afiliacji: https://bit.ly/316MjsJ

🔌 Kabel Baseus z magnetycznymi końcówkami a’la Magsafe USB-C/Lightning
💸  Link afiliacyjny: 
https://allegro.pl/oferta/baseus-magnetyczny-kabel-lightning-type-c-usb-c-10586650800?utm_medium=afiliacja&utm_source=ctr&utm_campaign=8abc16f6-1ce1-4d57-be67-435da22e0397
🏦 Link bez afiliacji: https://bit.ly/3xuRw9D

🛏️ Hamak na szyję
💸  Link afiliacyjny: 
https://allegro.pl/oferta/hamak-do-masazu-glowy-i-szyi-11212062015?utm_medium=afiliacja&utm_source=ctr&utm_campaign=7a321f00-466c-4802-83d0-e81d3c3ad9e7
🏦 Link bez afiliacji: https://bit.ly/3peBBIS

🔐 Klucze sprzętowe Yubico YubiKey
🏦 Link bez afiliacji. Serio takie rzeczy tylko od producenta: https://bit.ly/3G0N9WV

💡Lampka Mi LED Desk Lamp 1S MJTD01SYL
💸  Link afiliacyjny: 
https://allegro.pl/oferta/lampka-biurkowa-xiaomi-mi-led-desk-lamp-1s-8928159787?utm_medium=afiliacja&utm_source=ctr&utm_campaign=02493338-ff6c-47d2-8b0c-4110d7928c34
🏦 Link bez afiliacji: https://bit.ly/32wnnLu

🎲 Kostka timeular 
💸  Link afiliacyjny: 
https://timeular.com/ref/mateuszchrobok/ 
🏦 Link bez afiliacji: https://timeular.com

🤖 Raspberry Pi 4B z 8GB RAM
🏦 Link bez afiliacji: https://botland.store/1020-raspberry-pi-4b-modules-and-kits

🏃Bieżnia Xiaomi Walkingpad R1 PRO
💸  Link afiliacyjny: 
https://allegro.pl/oferta/bieznia-elektryczna-xiaomi-walking-pad-r1-pro-10002118790?utm_medium=afiliacja&utm_source=ctr&utm_campaign=28932e07-941a-4298-9721-4b0188e20196
🏦 Link bez afiliacji: https://bit.ly/3CWycD3

🗜️Stelaż do biurka Ergosolid SR21B
💸  Link afiliacyjny: 
https://allegro.pl/oferta/stelaz-biurka-z-elektryczna-regulacja-wysokosci-8896646986?utm_medium=afiliacja&utm_source=ctr&utm_campaign=e4981ff8-aeed-45a2-9841-d42bf88add91
🏦 Link bez afiliacji: https://bit.ly/319rTiD

🎅🏻 Jednak prezentem o który pytacie najczęściej w komentarzach jest czapka z filmu. Swoją kupiłem w Action (to nie jest reklama) ale jeśli nie chcecie marznąć w drodze do sklepu, znalazłem ją też w internecie.
💸  Link afiliacyjny: 
https://allegro.pl/oferta/czapka-mikolaja-tanczaca-grajaca-swieta-prezent-11364939324?utm_medium=afiliacja&utm_source=ctr&utm_campaign=525eaec5-746e-46e9-a660-c6c1f1296949
🏦 Link bez afiliacji: https://bit.ly/3D9QroX

****** Nie biorę odpowiedzialności za używanie zalinkowanych produktów. ****** 

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Podcasty na Anchor https://anchor.fm/mateusz-chrobok
Podcasty na Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Podcast na  Apple Podcasts https://podcasts.apple.com/us/podcast/mateusz-chrobok-bezpiecze%C5%84stwo-startupy-i-sztuczna-inteligencja/id1617335932 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok

