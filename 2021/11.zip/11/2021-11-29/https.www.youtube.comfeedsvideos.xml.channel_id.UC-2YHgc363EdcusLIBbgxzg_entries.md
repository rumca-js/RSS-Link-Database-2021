# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Isdal Woman: Europe's Most Famous Unidentified Person | Answers With Joe
 - [https://www.youtube.com/watch?v=lA-5OJ8Yj7g](https://www.youtube.com/watch?v=lA-5OJ8Yj7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-11-29 00:00:00+00:00

Get 20% of a premium subscription to Brilliant when you're one of the first 200 people to sign up at http://www.brilliant.org/answerswithjoe
On November 29, 1970, a body was found on the side of a mountain near Bergen, Norway. She has never been identified. Known only as The Isdal Woman, the trail she left behind and weird clues to her life have left investigators and the public searching for answers for 50 years. Who was this enigmatic woman, and what led to her bizarre death?

Check out the Death In Ice Valley podcast here: 
https://www.bbc.co.uk/programmes/p060ms2h/episodes/downloads

David Morgan's book:
https://www.amazon.com/Isdal-Woman-Perspective-David-Morgan-ebook/dp/B08XZQCT1G

And you can watch this video ad-free on Nebula: https://nebula.tv/videos/joe-scott-the-mystery-of-the-isdal-woman

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.mentalfloss.com/article/501142/new-evidence-emerges-isdal-woman-case-norway%E2%80%99s-most-famous-unsolved-murder-mystery

https://en.wikipedia.org/wiki/Isdal_Woman

http://www.westcoastpeaks.com/Peaks/ulriken.html

https://www.bbc.com/news/world-europe-39369429

https://www.norwegianamerican.com/bergens-cold-case-isdal-woman/

