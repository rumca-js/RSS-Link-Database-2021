## Why Paper Jams Persist | The New Yorker
 - [https://www.newyorker.com/magazine/2018/02/12/why-paper-jams-persist](https://www.newyorker.com/magazine/2018/02/12/why-paper-jams-persist)
 - RSS feed: https://www.newyorker.com
 - date published: 2021-11-29 18:08:28.241142+00:00

A trivial problem reveals the limits of technology.

