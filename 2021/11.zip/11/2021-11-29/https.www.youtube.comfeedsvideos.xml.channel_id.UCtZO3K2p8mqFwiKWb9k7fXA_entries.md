# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## How Qualcomm plans to take over
 - [https://www.youtube.com/watch?v=lFPnY39Ob_c](https://www.youtube.com/watch?v=lFPnY39Ob_c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2021-11-30 00:00:00+00:00

The Nebula / CuriosityStream bundle is no longer active. Instead, you can sign up for Nebula directly with my discount now for about $2.5 a month with a yearly plan, which includes Nebula Originals AND the whole Nebula Classes platform, too, including my own class. Sign up here: https://go.nebula.tv/techaltar

Technorama: https://nebula.app/technorama 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

You probably know Qualcomm for their Snapdragon chips in Android phones, but there is a lot more to the company. In this video, let’s explore how they got so dominant and what they have planned next.

The Story Behind - ep. 81

This episode on Nebula: https://nebula.app/videos/techaltar-how-qualcomm-plans-to-take-over

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  

Music by Edemski: https://soundcloud.com/edemski

