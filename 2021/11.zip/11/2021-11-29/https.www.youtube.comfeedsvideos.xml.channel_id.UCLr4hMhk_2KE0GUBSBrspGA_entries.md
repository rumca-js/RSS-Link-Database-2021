# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Xbox lodówka
 - [https://www.youtube.com/watch?v=jJR4NPOiJYA](https://www.youtube.com/watch?v=jJR4NPOiJYA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-11-30 00:00:00+00:00

Xbox Mini Fridge w sklepie oficjalnego dystrybutora na PL: https://bit.ly/3I8vyhB

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 W poszukiwaniu zaginionego…
00:08 Mankamenty estetyczne tworzywa lodówki
00:20 Głośność chłodzenia
00:56 Reklama vs rzeczywisty wygląd lodówki
02:45 Otwieranie
03:15 Pomiar temperatury wnętrza
04:35 Instrukcje i ostrzeżenia producenta
06:04 Wielkość i wnętrze
06:33 Demontaż półek, „montaż” Xboxa
06:58 Cena
07:51 Podsumowanie

