# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The town where holding fireworks over your head is a tradition
 - [https://www.youtube.com/watch?v=xym2R6_Qd7c](https://www.youtube.com/watch?v=xym2R6_Qd7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-11-29 00:00:00+00:00

Bridgwater Carnival, in Somerset, has a long tradition of squibbing: a huge procession of people holding fireworks right above their heads. This year, I got the chance to be one of the squibbers. Thanks to all the Bridgwater Carnival team: their site is https://www.bridgwatercarnival.org.uk/

Camera: Dave Mackie and Nyles Hollister
Edited by Michelle Martin: https://twitter.com/mrsmmartin

(Thanks to the person who first emailed me about this: the reply-to address on your email is broken, so I've never been able to get in touch to say thanks, and don't want to name you here without permission. It was a great idea!)

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

