# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## Is Meat Really that Bad?
 - [https://www.youtube.com/watch?v=F1Hq8eVOMHs](https://www.youtube.com/watch?v=F1Hq8eVOMHs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2021-11-30 00:00:00+00:00

Getting something from the kurzgesagt shop is the best way to support us and to keep our videos free for everyone. 
►► https://kgs.link/shop-154
(Worldwide Shipping Available)


Sources & further reading:
https://sites.google.com/view/sources-climate-meat/

Food is arguably the best thing about being alive. No other bodily pleasure is enjoyed multiple times every day and never gets old. It is an expression of culture, our parents' love and a means of celebration or comfort. That’s why it hits a special nerve when we are told we should change what and how we eat to fight rapid climate change. One of the most delicious foods, meat, gets the worst press. It doesn’t help that the topic is really hard to properly research yourself and debates get emotional quickly. But clearly science can give us an answer! 

The reality is, well, it’s complicated. Let’s take a look at three climate arguments against meat that are used a lot and see what happens.


OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ https://kgs.link/shop-154  
Join the Patreon Bird Army 🐧  https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:
Soundcloud: https://bit.ly/3CZ7Bpb
Bandcamp: https://bit.ly/318Zt8b

If you want to help us caption this video, please send subtitles to subtitle@kurzgesagt.org
You can find info on what subtitle files work on YouTube here:
https://support.google.com/youtube/answer/2734698?hl=en-GB&ref_topic=7296214
Thank you!

🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons (from http://kgs.link/patreon) who support us every month and made this video possible:
Lockhart Easton, Andrew Morgan, Denisa, Hulki Haluk Gulerman, Meg, sallysue, Gregory Paxton, Felipe, Fixitfast, Dan Breakiron, Milan Benko, Jennifer Chasse, Edward Shand, Fishy Muffinz, Jim Szymanski, Day, Alex Dumitrescu, Denyse Hannon, Leonardo Molina, Beto Cols, Diana, ThePhilCraft, Simon LE GRIFFON, Rudy Yazdi, Sergiy Payu, Crystal Hoon, Spenser Boyd, Fateme Vojdani, Claude Fang, John, Max Harlynking, B Ilieva, Валентин Канунников, Gamejunkey, Leo Banks, bogdan mhl, Brocalyps, Anhänger der Pestilenz, Micael Batista, Leon Hirt, Damian Edison, Cameron Butler, Tomasz Wiszkowski, Serotonin_, Baran Turan, Juan Emilio Cuevas Cuevas, David, Mitchel Arene, Atoxiv, Rik Lamers, DELTA_Illusion, Lolophi Lophi, Eliot Rauk, Marc Raftesath, Brayden Lee, Andrew Jordan, Cho Cho, Joshua S, Riley, Jeremy Soller, Alex Wasserman, VuzDoctor

