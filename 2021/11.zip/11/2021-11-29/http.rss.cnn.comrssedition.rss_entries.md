# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Parents who are upset over mask mandates attack school board chair's child online
 - [https://www.cnn.com/videos/us/2021/11/29/minnesota-school-board-transgender-mcmorris-pkg-vpx-lead.cnn](https://www.cnn.com/videos/us/2021/11/29/minnesota-school-board-transgender-mcmorris-pkg-vpx-lead.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 23:28:02+00:00

Chris and Kelsey Waits describe the the ugliness that followed Kelsey's unsuccessful race to be re-elected as chair of her school board in Hastings, Minnesota.

## Retailers want you to shop in stores this year (and they have a point)
 - [https://www.cnn.com/videos/business/2021/11/23/holiday-shopping-in-store-pickup-sb-orig.cnn-business](https://www.cnn.com/videos/business/2021/11/23/holiday-shopping-in-store-pickup-sb-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 21:25:41+00:00

Between supply chain issues and shipping delays, many retailers want you to shop in their brick-and-mortar locations instead of ordering online. And they're not wrong. CNN Business' Nathaniel Meyersohn reports.

## Lionel Messi wins Ballon d'Or -- again
 - [https://www.cnn.com/2021/11/29/football/lionel-messi-alexia-putellas-ballon-dor-spt-intl/index.html](https://www.cnn.com/2021/11/29/football/lionel-messi-alexia-putellas-ballon-dor-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 21:19:29+00:00

Lionel Messi won his seventh Ballon d'Or title on Monday, while Alexia Putellas won her first Ballon d'Or Féminin title.

## Scientists 'astounded' as first living robots reproduce in way not seen in plants or animals
 - [https://www.cnn.com/2021/11/29/americas/xenobots-self-replicating-robots-scn/index.html](https://www.cnn.com/2021/11/29/americas/xenobots-self-replicating-robots-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 21:04:21+00:00

The US scientists who created the first living robots say the life forms, known as xenobots, can now reproduce -- and in a way not seen in plants and animals.

## Tony Bennett and Lady Gaga perform 'One Last Time'
 - [https://www.cnn.com/videos/entertainment/2021/11/29/tony-bennett-lady-gaga-concert-lon-orig-jk-tp.cnn](https://www.cnn.com/videos/entertainment/2021/11/29/tony-bennett-lady-gaga-concert-lon-orig-jk-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 20:32:06+00:00

In August 2021, Tony Bennett and Lady Gaga performed two sold-out concerts that were billed as Bennet's final New York performances. The August 3 show ran on November 28 in a CBS special called "One Last Time: An Evening With Tony Bennett and Lady Gaga."

## Fraternity boxing match leads to student's death
 - [https://www.cnn.com/videos/us/2021/11/29/unlv-student-dies-fraternity-boxing-match-nathan-valencia-newday-vpx.cnn](https://www.cnn.com/videos/us/2021/11/29/unlv-student-dies-fraternity-boxing-match-nathan-valencia-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 20:15:52+00:00

A 20-year-old student at the University of Nevada Las Vegas died after participating in Kappa Sigma fraternity's "Fight Night." Nathan Valencia was hospitalized following his fight and died November 23, just four days shy of his 21st birthday. His family and their lawyers join CNN New Day to discuss what happened to their son.

## Merriam-Webster's 2021 word of the year revealed
 - [https://www.cnn.com/2021/11/29/us/vaccine-merriam-webster-2021-word-of-the-year-trnd/index.html](https://www.cnn.com/2021/11/29/us/vaccine-merriam-webster-2021-word-of-the-year-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 20:11:57+00:00

Merriam-Webster just announced its Word of the Year. For some, it is a symbol of hope and health. For others, it's a representation of a politicized issue.

## 'West Side Story' star to appear in remake
 - [https://www.cnn.com/videos/entertainment/2021/11/29/rita-moreno-60-minutes-interview-orig-bdk.cnn](https://www.cnn.com/videos/entertainment/2021/11/29/rita-moreno-60-minutes-interview-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 19:56:21+00:00

Actress Rita Moreno talked about her rocky relationship with legendary actor Marlon Brando and her career-changing role in "West Side Story" during an interview with CBS' "60 Minutes."

## WHO spokesperson: We should not punish countries for reporting cases
 - [https://www.cnn.com/videos/health/2021/11/29/who-spokesperson-maria-van-kerkhove-covid-19-travel-bans-amanpour-vpx.cnn](https://www.cnn.com/videos/health/2021/11/29/who-spokesperson-maria-van-kerkhove-covid-19-travel-bans-amanpour-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 19:31:05+00:00

Maria Van Kerkhove, the World Health Organization's technical lead on Covid-19, tells CNN's Christiane Amanpour that travel bans can slow the spread of the virus but ultimately can't stop it.

## Channing Tatum to return in 'Magic Mike 3'
 - [https://www.cnn.com/2021/11/29/entertainment/channing-tatum-magic-mike-steven-soderbergh/index.html](https://www.cnn.com/2021/11/29/entertainment/channing-tatum-magic-mike-steven-soderbergh/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 18:17:26+00:00

Channing Tatum is back as Magic Mike.

## Jack Dorsey is stepping down as CEO of Twitter
 - [https://www.cnn.com/2021/11/29/tech/jack-dorsey-twitter/index.html](https://www.cnn.com/2021/11/29/tech/jack-dorsey-twitter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 16:48:15+00:00

Jack Dorsey, the cofounder and public face of Twitter, will step down from his role as CEO, effective immediately, the company announced Monday. Dorsey will remain a member of Twitter's board until at least next year.

## Pirelli's star-studded 2022 calendar unveiled
 - [https://www.cnn.com/style/article/pirelli-2022-bryan-adams-calendar/index.html](https://www.cnn.com/style/article/pirelli-2022-bryan-adams-calendar/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 15:22:21+00:00

Pirelli has unveiled "On the Road," its 2022 calendar starring some of the music industry's biggest names, including Iggy Pop, Cher, Grimes and Jennifer Hudson. This edition of the renowned calendar, which was put on pause last year due to the coronavirus, was shot by Canadian singer-turned-photographer Bryan Adams and is dedicated to the "greatest talents in the world of music," according to a news release.

## Jill Biden unveils this year's Christmas decorations
 - [https://www.cnn.com/videos/politics/2021/11/29/jill-biden-christmas-decorations-theme-vpx-newday.cnn](https://www.cnn.com/videos/politics/2021/11/29/jill-biden-christmas-decorations-theme-vpx-newday.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 14:29:33+00:00

Jill Biden reveals the White House Christmas decorations, spotlighting first responders and frontline workers with the theme "gifts from the heart."

## Google pledges to build a more 'vibrant and dynamic' digital ecosystem in Africa
 - [https://www.cnn.com/2021/11/29/africa/nitin-gajria-google-africa-billion-dollar-investment-mpa-spc-intl/index.html](https://www.cnn.com/2021/11/29/africa/nitin-gajria-google-africa-billion-dollar-investment-mpa-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 14:15:08+00:00

Africa has the lowest rate of internet connectivity of any region in the world. But that also means it has the highest potential for new growth.

## American family stuck in South Africa amid new travel bans
 - [https://www.cnn.com/videos/us/2021/11/29/american-family-south-africa-travel-ban-covid-19-newday-vpx.cnn](https://www.cnn.com/videos/us/2021/11/29/american-family-south-africa-travel-ban-covid-19-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 13:46:15+00:00

An American family stuck in Johannesburg, South Africa, amid new Covid-19 travel restrictions talk about their experience in trying to get back home.

## Deer are consuming the world's largest organism, killing off its opportunity for growth
 - [https://www.cnn.com/2021/11/29/world/deer-eating-pando-forest-partner-scn/index.html](https://www.cnn.com/2021/11/29/world/deer-eating-pando-forest-partner-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 13:32:14+00:00

In the Wasatch Mountains of the western US on the slopes above a spring-fed lake, there dwells a single giant organism that provides an entire ecosystem on which plants and animals have relied for thousands of years. Found in my home state of Utah, "Pando" is a 106-acre stand of quaking aspen clones.

## Boston Celtics center says he will change his name and become a US citizen
 - [https://www.cnn.com/2021/11/28/sport/enes-kanter-freedom-name-change/index.html](https://www.cnn.com/2021/11/28/sport/enes-kanter-freedom-name-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 13:26:50+00:00

Boston Celtics center Enes Kanter, an outspoken critic of human rights issues, will become a US citizen Monday and legally change his name to Enes Kanter Freedom, the NBA player told CNN's John Berman.

## New England Patriots defense bullies Tennessee Titans for sixth straight win
 - [https://www.cnn.com/2021/11/29/sport/new-england-patriots-down-tennessee-titans-nfl-spt-intl/index.html](https://www.cnn.com/2021/11/29/sport/new-england-patriots-down-tennessee-titans-nfl-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 13:24:00+00:00

On a weekend marked with feast, the New England Patriots made sure they had a seat at the table as their defense ate up the Tennessee Titans in the second half in a 36-13 victory.

## Russia says Zircon hypersonic missile hit target in latest test
 - [https://www.cnn.com/2021/11/29/europe/russia-hypersonic-missile-hits-target-test-intl/index.html](https://www.cnn.com/2021/11/29/europe/russia-hypersonic-missile-hits-target-test-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 13:21:59+00:00

Russia said on Monday it had carried out another successful test launch of its Zircon hypersonic cruise missile, hailed by President Vladimir Putin as part of a new generation of unrivaled arms systems.

## Afghanistan's American University in exile
 - [https://www.cnn.com/2021/11/29/opinions/afghanistan-university-collapse-bergen/index.html](https://www.cnn.com/2021/11/29/opinions/afghanistan-university-collapse-bergen/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 13:19:56+00:00

Five years ago, Breshna Musazai was studying law at the American University of Afghanistan in Kabul. Her future seemed bright. She was attending the best university in Afghanistan, a coed institution offering an American-style education and was on a full scholarship provided by the US government.

## Who is Ghislaine Maxwell? Socialite and ex-girlfriend of Jeffrey Epstein goes on trial
 - [https://www.cnn.com/2021/11/29/us/ghislaine-maxwell-epstein-profile-intl/index.html](https://www.cnn.com/2021/11/29/us/ghislaine-maxwell-epstein-profile-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 13:00:12+00:00

British socialite Ghislaine Maxwell has gained global notoriety as the former girlfriend and social companion of the convicted pedophile and disgraced financier Jeffrey Epstein.

## Ralf Rangnick appointed Manchester United interim manager
 - [https://www.cnn.com/2021/11/29/football/ralf-rangnick-manchester-united-interim-manager-appointment-spt-intl/index.html](https://www.cnn.com/2021/11/29/football/ralf-rangnick-manchester-united-interim-manager-appointment-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 12:48:52+00:00

Manchester United has announced Ralf Rangnick as the club's interim manager until the end of the season.

## DOJ prosecutors push back against Bannon for wanting to publicize evidence against him
 - [https://www.cnn.com/2021/11/29/politics/department-of-justice-steve-bannon-court-filing/index.html](https://www.cnn.com/2021/11/29/politics/department-of-justice-steve-bannon-court-filing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 12:46:01+00:00

Prosecutors in the case against former President Donald Trump's ex-adviser Steve Bannon have accused him of attempting to try his criminal case through the media instead of in court, saying his tactics could affect witnesses against him, according to a new filing in DC District Court.

## Tony Bennett, 95, performs moving final concert with Lady Gaga
 - [https://www.cnn.com/2021/11/28/entertainment/tony-bennett-lady-gaga-concert/index.html](https://www.cnn.com/2021/11/28/entertainment/tony-bennett-lady-gaga-concert/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 12:44:45+00:00

Tony Bennett won over generations of fans crooning "I Left My Heart in San Francisco." And on his 95th birthday, the beloved singer left his heart on the stage of Radio City Music Hall.

## These countries have found cases of the Omicron variant
 - [https://www.cnn.com/2021/11/29/world/covid-omicron-variant-countries-list-cmd-intl/index.html](https://www.cnn.com/2021/11/29/world/covid-omicron-variant-countries-list-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 12:35:46+00:00

Nations around the world are racing to identify how many cases of the Omicron Covid-19 variant they have, as fears over the new strain force governments to shutter borders and revisit restrictions.

## Dad of Parkland victim details FBI's 'mistake' he says enabled shooting
 - [https://www.cnn.com/videos/us/2021/11/29/parkland-shooting-settlement-fbi-mistake-guttenberg-intv-keilar-newday-ldn-vpx.cnn](https://www.cnn.com/videos/us/2021/11/29/parkland-shooting-settlement-fbi-mistake-guttenberg-intv-keilar-newday-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 12:29:10+00:00

CNN's Brianna Keilar speaks with Fred Guttenberg, the father of Parkland high school shooting victim Jaime, after more than a dozen families reached a settlement with the Justice Department in connection with a lawsuit they filed after the FBI failed to act on tips warning about the shooter, according to a court filing.

## Honduras set for woman president as leftist Castro storms towards victory
 - [https://www.cnn.com/2021/11/29/americas/honduras-election-xiomara-castro-intl/index.html](https://www.cnn.com/2021/11/29/americas/honduras-election-xiomara-castro-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:57:58+00:00

Honduran presidential candidate Xiomara Castro headed for a landslide win in Sunday's election, declaring victory as supporters danced outside her offices to celebrate the left's return to power 12 years after her husband was ousted in a coup.

## This could be the future of first-class airplane travel
 - [https://www.cnn.com/travel/article/future-of-first-class-teague-four-seasons-cmd/index.html](https://www.cnn.com/travel/article/future-of-first-class-teague-four-seasons-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:54:37+00:00

First class is on its way out at many airlines, as business class seats and mini-suites become larger, more private and more luxurious -- and fewer budgets stretch to adding on what might be an extra zero on the price tag for first class.

## Lebanese protesters block roads over economic meltdown
 - [https://www.cnn.com/2021/11/29/middleeast/lebanon-protests-economy-intl/index.html](https://www.cnn.com/2021/11/29/middleeast/lebanon-protests-economy-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:51:53+00:00

Demonstrators, some of them burning tires, blocked roads across parts of Lebanon on Monday in protest at the country's economic meltdown, days after the Lebanese pound sank to new lows.

## Macao casino shares tumble after police arrest Suncity founder
 - [https://www.cnn.com/2021/11/29/investing/macao-casinos-arrests/index.html](https://www.cnn.com/2021/11/29/investing/macao-casinos-arrests/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:46:20+00:00

Macao casino stocks slid on Monday, rattled by the arrests of 11 people over alleged links to cross-border gambling and money laundering, with the founder of the gaming hub's biggest junket operator among those detained.

## Coronavirus variants: Here's what we know
 - [https://www.cnn.com/2021/11/29/health/coronavirus-variants-what-we-know-november/index.html](https://www.cnn.com/2021/11/29/health/coronavirus-variants-what-we-know-november/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:45:04+00:00

Omicron, the newest coronavirus variant, is also the quickest to be labeled a "variant of concern" by the World Health Organization because of its seemingly fast spread in South Africa and its many troubling mutations.

## Trial of Jussie Smollett, accused of lying to police about an alleged hate crime, begins Monday with jury selection
 - [https://www.cnn.com/2021/11/29/us/jussie-smollett-trial-monday/index.html](https://www.cnn.com/2021/11/29/us/jussie-smollett-trial-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:40:55+00:00

The long road in the Jussie Smollett case finally reaches trial Monday in Chicago, more than two years after police first alleged the actor lied about being the victim of a hate crime and wrongfully diverted weeks of investigative manpower.

## CNN diplomatic editor explains history of Iran nuclear talks
 - [https://www.cnn.com/videos/world/2021/11/29/iran-nuclear-talks-resume-robertson-intl-ovn-vpx.cnn](https://www.cnn.com/videos/world/2021/11/29/iran-nuclear-talks-resume-robertson-intl-ovn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:30:21+00:00

The US and its allies will restart Iran nuclear talks unsure how Tehran's new government will approach negotiations, not optimistic about the prospects ahead and emphasizing that if diplomacy fails, the US is "prepared to use other options." CNN's Nic Robertson reports.

## Cristiano Ronaldo benching for Manchester United causes fierce debate between pundits
 - [https://www.cnn.com/2021/11/29/football/cristiano-ronaldo-signing-causes-fierce-debate-spt-intl/index.html](https://www.cnn.com/2021/11/29/football/cristiano-ronaldo-signing-causes-fierce-debate-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 11:06:37+00:00

Cristiano Ronaldo's benching in Manchester United's 1-1 draw against Chelsea on Sunday prompted a fierce debate between leading pundits Jamie Carragher and Roy Keane.

## Mikaela Shiffrin equals Ingemar Stenmark's record with 46th World Cup slalom win
 - [https://www.cnn.com/2021/11/29/sport/mikaela-shiffrin-world-cup-skiing-record-spt-intl/index.html](https://www.cnn.com/2021/11/29/sport/mikaela-shiffrin-world-cup-skiing-record-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 10:42:10+00:00

Skiing star Mikaela Shiffrin equaled Ingemar Stenmark's record for the most World Cup wins in a single discipline on Sunday as she claimed the 46th slalom victory of her career.

## Lydia Ko: 'Sometimes results are so overrated,' says former world No. 1
 - [https://www.cnn.com/2021/11/29/golf/lydia-ko-lpga-tour-gotm-spc-spt-intl/index.html](https://www.cnn.com/2021/11/29/golf/lydia-ko-lpga-tour-gotm-spc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 10:38:20+00:00

The 24-year-old Lydia Ko has had more success than most golfers can imagine.

## Safe and alive, but 'traumatized,' the future of these Afghan women footballers is very uncertain
 - [https://www.cnn.com/2021/11/28/sport/afghanistan-women-soccer-team-intl-spt-cmd/index.html](https://www.cnn.com/2021/11/28/sport/afghanistan-women-soccer-team-intl-spt-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 09:56:46+00:00

They are safe and alive, and have the prospect of new lives in the United Kingdom, but for 130 Afghan female football players and their families it's an existence still full of uncertainty.

## How to build a habit in 5 steps, according to science
 - [https://www.cnn.com/2021/11/29/health/5-steps-habit-builder-wellness/index.html](https://www.cnn.com/2021/11/29/health/5-steps-habit-builder-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 09:39:54+00:00

Most of us assume those hyper-achievers who are always able to squeeze in their workout, eat healthy foods, ace their exams and pick their kids up on time must have superhuman self-control. But science points to a different answer: What we mistake for willpower is often a hallmark of habit.

## Global markets brace for a nervous week ahead over Omicron concerns
 - [https://www.cnn.com/2021/11/29/investing/global-stocks-omicron-variant-intl-hnk/index.html](https://www.cnn.com/2021/11/29/investing/global-stocks-omicron-variant-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 09:13:18+00:00

Asia Pacific markets were down on Monday as investors continued to digest news about a new Covid-19 variant.

## Novak Djokovic likely to skip Australian Open over vaccine mandate, says father
 - [https://www.cnn.com/2021/11/29/tennis/novak-djokovic-australian-open-spt-intl/index.html](https://www.cnn.com/2021/11/29/tennis/novak-djokovic-australian-open-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 08:13:12+00:00

Novak Djokovic is unlikely to play at the Australian Open if rules on Covid-19 vaccinations are not relaxed, the world number one's father, Srdjan Djokovic, said.

## Expert explains how we'll know if vaccines work against Omicron variant
 - [https://www.cnn.com/videos/health/2021/11/27/omicron-variant-peter-hotez-vaccines-vpx.cnn](https://www.cnn.com/videos/health/2021/11/27/omicron-variant-peter-hotez-vaccines-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 08:00:12+00:00

Dr. Peter Hotez discusses the Omicron variant and when we'll know if vaccines are effective against it.

## Beverly Hills police say they're investigating anti-Semitic flyers distributed one night before the beginning of Hanukkah
 - [https://www.cnn.com/2021/11/29/us/beverly-hills-anti-semitic-flyers-investigation/index.html](https://www.cnn.com/2021/11/29/us/beverly-hills-anti-semitic-flyers-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 07:42:22+00:00

Police in Beverly Hills, California, have launched an investigation after residents received anti-Jewish hate speech flyers ahead of the first night of Hanukkah, the department said Sunday.

## The Queen will have one less realm this week
 - [https://www.cnn.com/2021/11/28/americas/barbados-to-remove-queen-head-of-state-republic-intl-cmd-gbr/index.html](https://www.cnn.com/2021/11/28/americas/barbados-to-remove-queen-head-of-state-republic-intl-cmd-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 07:27:07+00:00

Queen Elizabeth will have one less realm next week when Barbados severs its final imperial links to Britain by removing the 95-year-old as its head of state and declaring itself a republic.

## Louis Vuitton artistic director Virgil Abloh dies of cancer at 41
 - [https://www.cnn.com/collections/virgil-abloh/](https://www.cnn.com/collections/virgil-abloh/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 07:04:37+00:00



## Exploring Vardzia, Georgia's mysterious rock-hewed cave city
 - [https://www.cnn.com/travel/article/vardzia-georgia-cave-city-cmd/index.html](https://www.cnn.com/travel/article/vardzia-georgia-cave-city-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 05:33:49+00:00

From 3,000-year-old Uplistikhe to the 6th century David Gareja Monastery and the long-forgotten dwellings of Samshvilde, all of Georgia's cave sites are awe-inspiring.

## A University of Nevada Las Vegas student dies days after participating in fraternity charity boxing match
 - [https://www.cnn.com/2021/11/28/us/unlv-student-dies-kappa-sigma-fraternity-charity-boxing-match/index.html](https://www.cnn.com/2021/11/28/us/unlv-student-dies-kappa-sigma-fraternity-charity-boxing-match/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 04:43:34+00:00

A University of Nevada Las Vegas student died just days after participating in a fraternity's charity boxing match where he collapsed soon after the fight, according to statements from the university and his family's attorney.

## Taiwan scrambles fighters to see off Chinese warplanes as Xi meets top brass
 - [https://www.cnn.com/2021/11/28/asia/taiwan-china-warplane-flights-intl-hnk-ml/index.html](https://www.cnn.com/2021/11/28/asia/taiwan-china-warplane-flights-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 03:45:58+00:00

Taiwan's air force scrambled again on Sunday to warn away 27 Chinese aircraft that entered its air defense zone, Taiwan's Defense Ministry said, the latest increase in tensions across the Taiwan Strait as China's President met his top generals.

## Carrie Meek, trailblazing Black former congresswoman, dies at 95
 - [https://www.cnn.com/2021/11/28/politics/carrie-meek-florida-pioneer-congresswoman/index.html](https://www.cnn.com/2021/11/28/politics/carrie-meek-florida-pioneer-congresswoman/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 03:23:16+00:00

Former Rep. Carrie Meek, who broke barriers throughout her winding political career as the daughter of a sharecropper and granddaughter of a slave, died Sunday in her Miami home. She was 95.

## An Afghan refugee family was invited over for Thanksgiving. Here's what happened
 - [https://www.cnn.com/2021/11/27/us/thanksgiving-afghan-refugee-family-los-angeles/index.html](https://www.cnn.com/2021/11/27/us/thanksgiving-afghan-refugee-family-los-angeles/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 03:12:58+00:00

For his family's first experience with a traditional Thanksgiving meal, Wahidullah Asghary had to explain to his children what turkey is: "I said, 'turkey is like a big chicken.'"

## Matthew McConaughey will not run for Texas governor
 - [https://www.cnn.com/2021/11/28/politics/matthew-mcconaughey-not-running-texas-governor/index.html](https://www.cnn.com/2021/11/28/politics/matthew-mcconaughey-not-running-texas-governor/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 03:07:35+00:00

Actor Matthew McConaughey announced Sunday that a future in political leadership is not in the cards -- right now.

## Republican lawmaker explains her tweet about Taiwan
 - [https://www.cnn.com/videos/politics/2021/11/29/nancy-mace-china-taiwan-nr-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/11/29/nancy-mace-china-taiwan-nr-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 02:38:43+00:00

Rep. Nancy Mace (R-SC) discusses her recent trip to Taiwan with four fellow lawmakers to meet with government officials there, defying Beijing to visit the contested island. Mace also explained her reasoning behind a tweet in which she referred to the self-governing island as the "Republic of Taiwan".

## Dept. of Defense wants Esper to remove parts about Trump from book, lawsuit says
 - [https://www.cnn.com/2021/11/28/politics/esper-defense-department-lawsuit/index.html](https://www.cnn.com/2021/11/28/politics/esper-defense-department-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 00:34:33+00:00

Former Secretary of Defense Mark Esper is suing the Department of Defense for not clearing his book manuscript for publication, after the agency told Esper he needed to take out parts of the book about his time working under then-President Donald Trump.

## Bash asks Schiff: Is Merrick Garland letting Trump off the hook?
 - [https://www.cnn.com/videos/politics/2021/11/28/adam-schiff-trump-merrick-garland-department-of-justice-sotu-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/11/28/adam-schiff-trump-merrick-garland-department-of-justice-sotu-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-11-29 00:13:27+00:00

Rep. Adam Schiff (D-CA) says he wonders why the Department of Justice and Attorney General Merrick Garland haven't pursued an investigation into former President Donald Trump's effort to overturn the 2020 election results in a key state.

