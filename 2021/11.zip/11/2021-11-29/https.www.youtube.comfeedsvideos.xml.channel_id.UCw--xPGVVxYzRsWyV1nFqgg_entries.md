# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## JADE LEGACY INTERVIEW WITH FONDA LEE!
 - [https://www.youtube.com/watch?v=fOjYjXncTyg](https://www.youtube.com/watch?v=fOjYjXncTyg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-11-30 00:00:00+00:00

An interview with Fonda Lee! The author of the smash hit Greenbone Saga. 
Check out the book: https://amzn.to/3rkt4GD 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## Loial First Look! (WoT)😅 Mass Effect Adaptation (AGAIN)🛰️ Miyazaki Returns!🎞️ -FANTASY NEWS
 - [https://www.youtube.com/watch?v=ehXxEHs9A0U](https://www.youtube.com/watch?v=ehXxEHs9A0U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-11-30 00:00:00+00:00

Let's jump into the Fantasy News! 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene
#TheWheelOfTime
Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Intro

00:14 The Sunbear Trials: https://twitter.com/aidenschmaiden/status/1462843338210430977 

00:38 Chris Wooding: https://thewertzone.blogspot.com/2021/11/chris-wooding-completes-ember-blade.html

01:22 Ogier: https://www.cbr.com/wheel-of-time-image-first-look-ogier/amp/ 

02:16 Wheel Of Time Jewelry: https://twitter.com/BadaliJewelry/status/1463292227405242370?t=H4EYoyfhg0T1EIfHn7TuyQ&s=19 

02:42 Mass Effect: https://deadline.com/2021/11/the-wheel-of-time-premiere-ratings-amazon-prime-video-mass-effect-lort-of-the-rings-jennifer-salke-qa-1234879517/ 

05:01 Silent Sea: https://www.youtube.com/watch?v=er0jCPt4I8A&ab_channel=TheSwoon 

05:55 Pokemon Evolutions: https://www.youtube.com/watch?v=2-d_PruYR5Q&ab_channel=TheOfficialPok%C3%A9monYouTubechannel 

06:44 Miyazaki will return: https://twitter.com/DiscussingFilm/status/1463201543566544905

