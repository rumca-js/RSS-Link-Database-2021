# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## I get so much Cashback I even bought a Car with it. (Banks are suckers!)
 - [https://www.youtube.com/watch?v=wCe1yfEqI_Q](https://www.youtube.com/watch?v=wCe1yfEqI_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-11-30 00:00:00+00:00

I talk about how I churn and use credit cards. I made enough cashback to buy a high-quality used car with it.

Here are links to some of these cards:
Chase Freedom Flex: https://www.referyourchasecard.com/18a/GY790PP52C
Discover It: https://refer.discover.com/s/LUKE290
American Express: http://refer.amex.us/LUKESX7tC?xl=cp15

My website: https://lukesmith.xyz
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

