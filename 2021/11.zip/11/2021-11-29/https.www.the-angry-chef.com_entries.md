## The World’s Deadliest Thing — Anthony Warner
 - [https://www.the-angry-chef.com/blog/the-worlds-deadliest-thing](https://www.the-angry-chef.com/blog/the-worlds-deadliest-thing)
 - RSS feed: https://www.the-angry-chef.com
 - date published: 2021-11-29 16:26:51.747875+00:00

It is deadly, invisible and shapes much of the food we eat. A teaspoon of it could kill millions of people, and it is probably the most expensive material on earth. Yet you probably have some stuck to the bottom of you shoe.

