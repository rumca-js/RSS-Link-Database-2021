## Social media companies could soon be forced to end anonymity for online trolls. But will this stop the trolling? - ABC News
 - [https://www.abc.net.au/news/science/2021-11-30/online-bullying-trolling-identity-verification-legislation/100658084](https://www.abc.net.au/news/science/2021-11-30/online-bullying-trolling-identity-verification-legislation/100658084)
 - RSS feed: https://www.abc.net.au
 - date published: 2021-11-29 07:33:20+00:00

Social media companies could soon be forced to end anonymity for online trolls. But will this stop the trolling? - ABC News

