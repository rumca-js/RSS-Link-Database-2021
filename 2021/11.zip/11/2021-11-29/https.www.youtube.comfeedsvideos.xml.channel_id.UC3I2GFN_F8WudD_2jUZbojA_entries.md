# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ak Dan Gwang Chil (ADG7) - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=ugAkv-Bap4o](https://www.youtube.com/watch?v=ugAkv-Bap4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-29 00:00:00+00:00

http://KEXP.ORG presents Ak Dan Gwang Chil (ADG7) (악단광칠) performing live in the KEXP studio. Recorded November 5, 2021.

Songs:
Yeong Jeong Geo Ri
Hee Hee
The Dance Of Lions 
Whatever
Aucha

Kim Yak Dae - Daeguem
Lee Man Wol - Piri & Saenghwang
Grace Park - Ajaeng
Won Meon Dong Maru - Gayaguem
Chun Gung Dal - Percussion
Sunwoo Barabarabarabam - Percussion
Hong Ok - Vocals
Myeong Wol - Vocals
Yoo Wol - Vocals

Host: Darek Mazzone
Audio Engineers: Sae-rom Jung & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://sori.nyc/adg7
http://kexp.org

## Ak Dan Gwang Chil (ADG7) - Hee Hee (Live on KEXP)
 - [https://www.youtube.com/watch?v=retobpjJDUI](https://www.youtube.com/watch?v=retobpjJDUI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-29 00:00:00+00:00

http://KEXP.ORG presents Ak Dan Gwang Chil (ADG7) (악단광칠) performing “Hee Hee” live in the KEXP studio. Recorded November 5, 2021.

Kim Yak Dae - Daeguem
Lee Man Wol - Piri & Saenghwang
Grace Park - Ajaeng
Won Meon Dong Maru - Gayaguem
Chun Gung Dal - Percussion
Sunwoo Barabarabarabam - Percussion
Hong Ok - Vocals
Myeong Wol - Vocals
Yoo Wol - Vocals

Host: Darek Mazzone
Audio Engineers: Sae-rom Jung & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://sori.nyc/adg7
http://kexp.org

## Ak Dan Gwang Chil (ADG7) - The Dance Of Lions (Live on KEXP)
 - [https://www.youtube.com/watch?v=iONgYuxxqiQ](https://www.youtube.com/watch?v=iONgYuxxqiQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-29 00:00:00+00:00

http://KEXP.ORG presents Ak Dan Gwang Chil (ADG7) (악단광칠) performing “The Dance Of Lions” live in the KEXP studio. Recorded November 5, 2021.

Kim Yak Dae - Daeguem
Lee Man Wol - Piri & Saenghwang
Grace Park - Ajaeng
Won Meon Dong Maru - Gayaguem
Chun Gung Dal - Percussion
Sunwoo Barabarabarabam - Percussion
Hong Ok - Vocals
Myeong Wol - Vocals
Yoo Wol - Vocals

Host: Darek Mazzone
Audio Engineers: Sae-rom Jung & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://sori.nyc/adg7
http://kexp.org

## Ak Dan Gwang Chil (ADG7) - Whatever & Aucha (Live on KEXP)
 - [https://www.youtube.com/watch?v=QSNbz9aZo3E](https://www.youtube.com/watch?v=QSNbz9aZo3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-29 00:00:00+00:00

http://KEXP.ORG presents Ak Dan Gwang Chil (ADG7) (악단광칠) performing “Whatever" and "Aucha” live in the KEXP studio. Recorded November 5, 2021.

Kim Yak Dae - Daeguem
Lee Man Wol - Piri & Saenghwang
Grace Park - Ajaeng
Won Meon Dong Maru - Gayaguem
Chun Gung Dal - Percussion
Sunwoo Barabarabarabam - Percussion
Hong Ok - Vocals
Myeong Wol - Vocals
Yoo Wol - Vocals

Host: Darek Mazzone
Audio Engineers: Sae-rom Jung & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://sori.nyc/adg7
http://kexp.org

## Ak Dan Gwang Chil (ADG7) - Yeong Jeong Geo Ri (Live on KEXP)
 - [https://www.youtube.com/watch?v=oWLtEpwyWy4](https://www.youtube.com/watch?v=oWLtEpwyWy4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-11-29 00:00:00+00:00

http://KEXP.ORG presents Ak Dan Gwang Chil (ADG7) (악단광칠) performing “Yeong Jeong Geo Ri” live in the KEXP studio. Recorded November 5, 2021.

Kim Yak Dae - Daeguem
Lee Man Wol - Piri & Saenghwang
Grace Park - Ajaeng
Won Meon Dong Maru - Gayaguem
Chun Gung Dal - Percussion
Sunwoo Barabarabarabam - Percussion
Hong Ok - Vocals
Myeong Wol - Vocals
Yoo Wol - Vocals

Host: Darek Mazzone
Audio Engineers: Sae-rom Jung & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://sori.nyc/adg7
http://kexp.org

