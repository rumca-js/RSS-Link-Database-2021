# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Kulisy jednego z największych skandali w świecie sportu
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1090,S00E1090,635429?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1090,S00E1090,635429?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2021-11-14 10:43:41+00:00

<img alt="Kulisy jednego z największych skandali w świecie sportu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b3q18t-fifa1e-5488891/alternates/LANDSCAPE_1280" />
    Mundial w Katarze.

