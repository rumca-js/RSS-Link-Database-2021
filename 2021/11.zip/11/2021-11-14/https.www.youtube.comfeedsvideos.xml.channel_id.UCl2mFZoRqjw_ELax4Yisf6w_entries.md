# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## let's encourage this lad to quit his job
 - [https://www.youtube.com/watch?v=LdCv0KwvorE](https://www.youtube.com/watch?v=LdCv0KwvorE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-11-15 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.reddit.com/r/Justrolledintotheshop/comments/qtnr37/thinking_about_quitting_my_job_i_feel_like_we/?utm_source=share&utm_medium=web2x&context=3

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## Record number of people quitting their jobs, but don't worry, the economy is fine!
 - [https://www.youtube.com/watch?v=o50qhiN_wjk](https://www.youtube.com/watch?v=o50qhiN_wjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-11-14 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.nytimes.com/2021/11/12/business/economy/jobs-labor-openings-quit.html
🔵 https://www.bloomberg.com/news/articles/2021-11-12/a-record-number-of-americans-quit-their-jobs-in-september
🔵 https://www.bloomberg.com/news/articles/2021-11-12/u-s-consumer-sentiment-drops-to-10-year-low-on-inflation-fears

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

