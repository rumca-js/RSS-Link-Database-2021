# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Venom 2: Let There Be... Something
 - [https://www.youtube.com/watch?v=L9Fb99f2kP4](https://www.youtube.com/watch?v=L9Fb99f2kP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-11-15 00:00:00+00:00

Venom 2 definitely had some fun moments, but overall it didn't really make use of its talented cast or do anything particularly interesting or original.

