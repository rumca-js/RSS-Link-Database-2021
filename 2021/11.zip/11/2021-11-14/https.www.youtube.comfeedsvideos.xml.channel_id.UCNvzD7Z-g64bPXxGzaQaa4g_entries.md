# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 BEST Open World Games of 2021 [4K]
 - [https://www.youtube.com/watch?v=n5purHmHpr8](https://www.youtube.com/watch?v=n5purHmHpr8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-15 00:00:00+00:00

Looking for an open world (or sometimes semi-open world) game to play on PC, PS5, PS4, Xbox Series X/S/One, or Nintendo Switch this year? We’ve got you covered with these.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10 Riders Republic

Platform : PC PS4 PS5 Xbox One XSX|S Stadia Luna 

Release Date : October 28, 2021



9 Valheim

Platform : PC Linux 

Release Date : 2 February 2021 (early access) 



8 Grand Theft Auto: The Trilogy – The Definitive Edition

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : 11 November 2021 



7 Scarlet Nexus  

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : June 25, 2021 



6 Lost Judgment

Platform : PS4 PS5 Xbox One XSX|S 

Release Date : September 24, 2021 



5 Subnautica Below Zero

Platform : PC PS4 PS5 Xbox One XSX|S Switch  

Release Date : May 14, 2021 



4 Monster Hunter Rise

Platform : Switch 

Release Date : March 26, 2021 



3 Far Cry 6

Platform : PC PS4 PS5 Xbox One XSX|S Stadia 

Release Date : October 7, 2021 



2 The Ascent

Platform : PC Xbox One XSX|S

Release Date : 29 July 2021 



1 Forza Horizon 5

Platform : PC Xbox One XSX|S 

Release Date : 9 November 2021 



BONUS

Biomutant

Platform : PC PS4 Xbox One 

Release Date : May 25, 2021 



Gas Station Simulator 

Platform : PC PS4 Xbox One 

Release Date : September 15, 2021

## 10 Things RPGs NEED TO Stop Doing Immediately
 - [https://www.youtube.com/watch?v=KS0CeNhQ070](https://www.youtube.com/watch?v=KS0CeNhQ070)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-11-14 00:00:00+00:00

Some RPG creators do things we don't like. Here are some problems we'd prefer our RPGs avoid.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

