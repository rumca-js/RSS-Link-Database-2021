# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Halo Infinite Multiplayer Surprise Drop Livestream
 - [https://www.youtube.com/watch?v=qkIOEvQt7hE](https://www.youtube.com/watch?v=qkIOEvQt7hE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-15 00:00:00+00:00

Surprise! Halo Infinite's multiplayer has dropped a few weeks earlier than expected, so let's check it out.

## Halo Infinite | Season 1 Multiplayer - Heroes of Reach Launch Trailer
 - [https://www.youtube.com/watch?v=rA9k-vnr9dM](https://www.youtube.com/watch?v=rA9k-vnr9dM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-15 00:00:00+00:00

Check out the Halo Infinite Season 1 launch trailer, Heroes of Reach. Halo Infinite multiplayer season 1 dropped early on November 15th at the conclusion of Xbox's 20th anniversary stream.

#HaloInfinite

## Outriders New Horizon Update Full Presentation
 - [https://www.youtube.com/watch?v=iw7D-HIIPPU](https://www.youtube.com/watch?v=iw7D-HIIPPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-15 00:00:00+00:00

During this Outriders Broadcast we learn what updates the team from People Can Fly have been working on. We get more information on the upcoming update, as well as a new expansion coming in 2022. The biggest changes are coming to Expeditions which will no longer be timed. Now players can try different builds without fear of failing the timed Expeditions. Additionally, there will be new Expeditions coming as well for players to experience in Outriders. Legendary Drop rates have also seen a buff, and there will be additional ways to try to help you get the Legendary you're missing.

#Outriders

## Pokémon Brilliant Diamond & Pokémon Shining Pearl - Overview Trailer
 - [https://www.youtube.com/watch?v=KYlSjtdRcXM](https://www.youtube.com/watch?v=KYlSjtdRcXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-15 00:00:00+00:00

Check out the Pokemon Brilliant Diamond & Shining Pearl overview trailer coming to Nintendo Switch!

## Xbox 20th Anniversary Celebration Full Presentation
 - [https://www.youtube.com/watch?v=dUAtrRxjPqQ](https://www.youtube.com/watch?v=dUAtrRxjPqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-15 00:00:00+00:00

Check out the 20th Anniversary celebration for Xbox which paid honor to some of Xbox's history  as well as dropping the release of Halo Infinite season 1 multiplayer.

## Xbox 20th Anniversary Celebration Livestream
 - [https://www.youtube.com/watch?v=kZBzBXYUMIQ](https://www.youtube.com/watch?v=kZBzBXYUMIQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-15 00:00:00+00:00

Tune in Nov. 15 at 10am PT for a 20th anniversary celebration of Xbox and Halo.

Xbox has confirmed there will be no announcements of new games and instead will focus on looking back at 20 years of Xbox.

## History Of Call Of Duty WW2 Games
 - [https://www.youtube.com/watch?v=BIJagpuSlWg](https://www.youtube.com/watch?v=BIJagpuSlWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-14 00:00:00+00:00

From Infinity Ward's original Call of Duty to Sledgehammer's latest, Call of Duty: Vanguard, we chart the history of the World War II Call of Duty games.

From wars in the past, wars in the present, and even wars in the far-flung future, Call of Duty has been there. But the juggernaut franchise first made its mark with one of the biggest events of the 20th Century: WW2, an era it has revisited multiple times over the years since, including its latest entry, Call of Duty: Vanguard.

In the above video, we chronicle the Call of Duty games that explore World War II (from the first in the series, created by Infinity Ward), the introduction of the Zombies mode to those games, and how the latest WW2 CoD game, Vanguard, ties into the battle royale-focused Call of Duty: Warzone. 

For more on Call of Duty, make sure to check out our latest episode of Firearms Expert Reacts, where Jonathan Ferguson breaks down the WW2 weapons in the game. Make sure to subscribe at youtube.com/gamespot so you don't miss an episode.

00:25 - Call of Duty (2003)
04:01 - Call of Duty: United Offensive (2004)
05:11 - Call of Duty: Finest Honor (2004)
06:41 - Call of Duty 2 (2005)
09:38 - Call of Duty 2: Big Red One (2005)
10:52 - Call of Duty 3 (2006)
12:48 - Call of Duty: Roads to Victory (2007)
13:38 - Call of Duty: World at War (2008)
15:13 - Call of Duty: World at War Final Fronts (2008)
16:03 - Call of Duty: WWII (2017)
17:20 - Call of Duty: Vanguard 2021

## How BOTW's Most Complex Glitch Was Found
 - [https://www.youtube.com/watch?v=fixmBwon3jk](https://www.youtube.com/watch?v=fixmBwon3jk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-11-14 00:00:00+00:00

Memory Storage is one of The Legend of Zelda: Breath of the Wild's most complex glitches allowing you to get the Bow Of Light and start a new game with all of your equipment. But is it found by luck, skill, or knowledge? We explain how complicated glitches are discovered.

#BreathoftheWild

