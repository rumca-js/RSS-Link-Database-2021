# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## This tiny railroad across the sea has an important job
 - [https://www.youtube.com/watch?v=NL5sRCRa7AE](https://www.youtube.com/watch?v=NL5sRCRa7AE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-11-15 00:00:00+00:00

The Lorenbahn, the Lüttmoorsiel-Nordstrandischmoor island railway, is famous for the tiny, private trains that take residents to and from the mainland. But that's not why it was built: and it's got a more useful purpose as well.

Thanks to everyone from Landesbetrieb für Küstenschutz, Nationalpark und Meeresschutz Schleswig-Holstein, and to the islanders, for all your time and patience!

Camera operator: Richard Bielau
Producer: Maximilian Thesseling of Klein Aber https://kleinaber.de/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

