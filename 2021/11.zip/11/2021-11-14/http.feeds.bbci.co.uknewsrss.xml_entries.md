# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Macron switches to using navy blue on France's flag - reports
 - [https://www.bbc.co.uk/news/world-europe-59283134?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59283134?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 19:12:03+00:00

The French president wants to reconnect with a symbol of the French Revolution, reports say.

## Arctic walrus spotted on Northumberland beach
 - [https://www.bbc.co.uk/news/uk-england-tyne-59282114?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-59282114?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 14:24:18+00:00

Conservationists appeal for people to stay away from the walrus at Seahouses to keep it safe.

## Remembrance Sunday: Royals and politicians lay wreaths as nation remembers war dead
 - [https://www.bbc.co.uk/news/uk-59280801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59280801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 13:12:19+00:00

The nation fell silent at 11:00GMT to honour those who have died in conflict.

## COP26: China and India must explain themselves, says Sharma
 - [https://www.bbc.co.uk/news/uk-59280241?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59280241?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 11:55:06+00:00

COP26 President Alok Sharma says Glasgow climate pact is historic and it keeps 1.5C within reach.

## Remembrance Sunday: Nation falls silent to remember the war dead
 - [https://www.bbc.co.uk/news/uk-59280848?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59280848?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 11:51:02+00:00

Services see the return of pre-pandemic crowds, after events were scaled back last year.

## Bart Simpson graffiti appears following Kidderminster speed camera 'moon'
 - [https://www.bbc.co.uk/news/uk-england-hereford-worcester-59280919?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hereford-worcester-59280919?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 11:39:46+00:00

The street art is on the wall of a subway in Darrell Meekcom's home town.

## US bank robber identified after decades-long hunt
 - [https://www.bbc.co.uk/news/world-us-canada-59280706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59280706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 11:26:19+00:00

Ted Conrad disappeared with $1.7 million after pulling off a bizarre heist more than 50 years ago.

## Channel Tunnel: Cocaine haul found in shipment of onion rings
 - [https://www.bbc.co.uk/news/uk-england-kent-59280849?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-59280849?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 11:14:35+00:00

A man appears in court accused of smuggling drugs with an estimated value of £33m.

## Queen misses Remembrance Sunday service after back sprain
 - [https://www.bbc.co.uk/news/uk-59280608?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59280608?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 10:52:34+00:00

The monarch is "disappointed" after making the decision not to attend this morning, the palace says.

## Eight murder arrests as fatal stabbing Nottingham victim named
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-59280929?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-59280929?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 10:40:51+00:00

Police say eight people have been arrested on suspicion of murder.

## 'Andy Farrell's Ireland touch the sky after All Blacks win but ultimate vindication must wait'
 - [https://www.bbc.co.uk/sport/rugby-union/59278344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/59278344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 10:34:34+00:00

Ireland's win over New Zealand must be the start of something as Andy Farrell's Ireland announce themselves as a potential force.

## Brentford stabbing: Man charged with murder and attempted murder
 - [https://www.bbc.co.uk/news/uk-england-london-59280396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59280396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 09:27:43+00:00

Ali Abucar Ali, 20, died from his stab wounds while an 82-year-old woman remains in hospital.

## Gallagher gets first England call-up as five miss out on Monday's World Cup qualifier
 - [https://www.bbc.co.uk/sport/football/59278354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59278354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 09:10:25+00:00

Crystal Palace midfielder Conor Gallagher is called into the senior England team for the first time as five players are ruled out of the San Marino trip.

## Celtic defender Ralston given first Scotland call-up
 - [https://www.bbc.co.uk/sport/football/59280358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59280358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 09:05:12+00:00

Celtic right-back Anthony Ralston is called into the Scotland squad for Monday's World Cup qualifier against Denmark.

## 'Steward's arrival on world stage should be as celebrated as Itoje's was'
 - [https://www.bbc.co.uk/sport/rugby-union/59278101?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/59278101?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 07:42:42+00:00

Freddie Steward's arrival on the world stage should be as feted as Maro Itoje's was, former England scrum-half Matt Dawson says.

## Arm-wrestling: The woman at the centre of sport's UK rise
 - [https://www.bbc.co.uk/news/uk-wales-59266189?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59266189?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 07:14:24+00:00

Kath Whitaker is Britain's only female arm-wrestling referee.

## COP26: The two week summit in two minutes
 - [https://www.bbc.co.uk/news/science-environment-59277713?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59277713?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 06:45:35+00:00

The UN’s climate summit has come to an end after two weeks in Glasgow, here are some of the stand out moments.

## Robert Bradford: 'Find the killers of MP and my brother'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-59267142?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-59267142?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 06:37:11+00:00

Belfast man describes 40-year search for justice after IRA double murder in November 1981.

## Newspaper headlines: Sharma 'sorry' as India and China 'thwart' COP deal
 - [https://www.bbc.co.uk/news/blogs-the-papers-59278204?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59278204?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 06:23:57+00:00

The climate deal that has been reached in Glasgow at COP26 features on several Sunday front pages.

## Ecuador prison riot: New fighting at Guayaquil jail kills 68
 - [https://www.bbc.co.uk/news/world-latin-america-59276428?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-59276428?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 04:10:18+00:00

Rival inmates attack each other as guns and explosives are discovered at the facility in Guayaquil.

## Renewable energy: How Scottish Isle of Eigg relies on wind, water, solar
 - [https://www.bbc.co.uk/news/science-environment-59238305?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59238305?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 02:11:58+00:00

As the world slowly moves away from using fossil fuels for electricity, a tiny Scottish island has shown it’s possible to rely almost entirely on renewables.

## 'Brian Clough's incredible kindness saved my life'
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-59207830?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-59207830?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 02:10:52+00:00

Craig Bromfield was taken in by the Forest manager Brian Clough and his family in the 1980s.

## Covid vaccine ‘waning immunity’: How worried should I be?
 - [https://www.bbc.co.uk/news/health-59260294?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-59260294?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 01:06:41+00:00

Is the effectiveness of Covid vaccines waning over time? We look at how much protection being double vaccinated offers.

## COP26 climate deal: 'It won't save us from drowning'
 - [https://www.bbc.co.uk/news/science-environment-59268394?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59268394?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 01:01:42+00:00

Young activists on the frontline of climate change explain what the deal struck at COP26 means to them.

## What the 'Joker attack' revealed about Japanese society
 - [https://www.bbc.co.uk/news/world-asia-59257736?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59257736?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 00:10:40+00:00

An attack which injured 17 people on Halloween has shocked a country that rarely sees violent crime.

## Majorca plane adventure reveals new migrant route
 - [https://www.bbc.co.uk/news/world-europe-59258413?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59258413?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 00:08:37+00:00

When 20 people fled a passenger plane it shed light on migration routes as well as airport safety.

## Your pictures on the theme of 'a long journey'
 - [https://www.bbc.co.uk/news/in-pictures-59224887?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-59224887?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 00:04:59+00:00

A selection of striking images from our readers around the world.

## Arm wrestling: Pontypridd woman is 'UK's first female referee'
 - [https://www.bbc.co.uk/news/uk-wales-59254159?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59254159?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 00:04:51+00:00

Perceptions the muscle-bound sport is not a place for women are wrong, says Katherine Whitaker.

## Dress embroidery project unifies women around the world
 - [https://www.bbc.co.uk/news/uk-england-somerset-59181514?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-59181514?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 00:04:37+00:00

The artist behind a dress made in global embroidery project said it embodies the "unity" of women.

## 'I've been teaching for 50 years and still loving it'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-59240471?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-59240471?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 00:04:19+00:00

Joanna Harriot has been a teacher in west Belfast since taking up her first post in 1972.

## The circus helping Senegal's former child beggars
 - [https://www.bbc.co.uk/news/world-africa-59175763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-59175763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-11-14 00:02:17+00:00

Senegal's only circus troupe was set up to help child beggars get off the streets.

