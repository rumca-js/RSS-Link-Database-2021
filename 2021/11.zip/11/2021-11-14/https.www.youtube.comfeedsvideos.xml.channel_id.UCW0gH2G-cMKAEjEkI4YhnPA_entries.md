# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Middle-earth Ultimate Collector's Edition 4K UHD Review - The Lord of the Rings & The Hobbit
 - [https://www.youtube.com/watch?v=uVW4k2Ytwb8](https://www.youtube.com/watch?v=uVW4k2Ytwb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-11-15 00:00:00+00:00

We cover the entire contents of the newly released Middle-earth Ultimate Collector's Edition on 4K UHD Blu-ray.  This is a really great 31-disc set that features all six films from The Hobbit and The Lord of the Rings trilogies in both extended and theatrical forms - both of which come on both 4K UHD as well as regular Blu-ray.  In addition to my review, I also lay out my ideal "Ultimate Edition", what I like to call "The Mithril Edition", which I hope will be the next release we get from WB.

*Affiliate Links* (NOTR gets a small cut, at no cost to you)
Middle-earth Ultimate Collector's Edition
Amazon (US): https://amzn.to/3neh86T
Amazon (UK):  https://amzn.to/3HwTF9o

2020 4K Edition
Amazon (US): https://amzn.to/3c9IYLm
Amazon (UK): https://amzn.to/3kBnWKh

RELEASE THE MITHRIL EDITION PETITION: https://chng.it/nzCHPpFKXr

We also dive into the bonus items: the collectible book, mini travel posters, and Disc 31, which contains the three Alamo Drafthouse cast reunions featuring Elijah Wood, Sean Astin, Billy Boyd, Dominic Monaghan, Viggo Mortensen, Cate Blanchett, Liv Tyler, Orlando Bloom, Andy Serkis, Ian McKellen, and Peter Jackson - hosted by Stephen Colbert.

The set also includes the newly released Cannes 2001 Presentation - the reel that brought the attention of the world to New Zealand and the soon to be massive hit that was The Lord of the Rings.

For a more spec-oriented review of these films, check out Bill's review at Digital Bits: https://thedigitalbits.com/item/middle-earth-6-film-2021-4k-uhd-bd-box

Special thanks to Warner Brothers for sending me this set in order to review on the channel!

00:00-01:22 Packaging
01:22-01:54 What's In The Box
01:54-02:51 4K & Blu-ray Quality
02:51-04:07 Physical Extras
04:07-06:35 Disc 31: Bonus Features
06:35-11:41 My Pitch for "The Mithril Edition"
11:41-12:32 Final Word

#middleearth4k #lotr4k #lordoftherings4k

