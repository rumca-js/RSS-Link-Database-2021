# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Apple's REALLY tempting me... MacBook Pro 14" 2021
 - [https://www.youtube.com/watch?v=SUyD2QXfGUg](https://www.youtube.com/watch?v=SUyD2QXfGUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-15 00:00:00+00:00

Use code LINUS to get 70% off a 2-year Nordpass Premium plan with one extra month FREE at https://www.nordpass.com/linus

Get your Crucial P5 Plus NVMe SSD today at:
https://crucial.gg/LinusTechTips

Apple Silicon took the world by storm with M1, but now we’ve got the next generation: M1 Pro. The 14 inch MacBook Pro is the next major redesign and Apple has gone all-out to make sure it impresses… Mostly.


Buy an Apple MacBook Pro 2021: https://geni.us/NdTVcp

Buy an Apple MacBook Pro 13 2020: https://geni.us/pQKq5

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1388689-apples-really-tempting-me/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:51 Tempting industrial design
2:36 Notch your dad's MacBook
3:57 It has how many speakers?
5:08 That new display tho
6:28 Benchmarks!
9:24 Games.
10:11 Thermals and skin temperature
11:22 Battery life
12:20 Let's pop the hood
13:34 That's a lot of good... Let's talk bad
14:54 Recommendations and conclusion

## Check out my HUGE Rack! - New House Network Update
 - [https://www.youtube.com/watch?v=pyZSqfmN_0I](https://www.youtube.com/watch?v=pyZSqfmN_0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-11-14 00:00:00+00:00

Thanks to VOLTA for sponsoring today’s video! You can check out the VOLTA Spark 60W + 1 Tip and VOLTA Spark 100W + 1 Tip charging cables here: https://geni.us/Jo8c

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Now that Linus' home is sort of smart, it's time to bring in the network rack to house the brains of the operation: Routers, switches, NVRs, UPSes, the whole nine yards! Why is it pink?


Check out RackSolutions' RS148 Data Canter Server Cabinet at https://lmg.gg/cDiVF

Check out the Ubiquiti store: https://lmg.gg/UbiquitiLTT

Buy a Ubiquiti Networks UniFi Dream Machine Pro: https://lmg.gg/KlNKQ

Buy a Ubiquiti Networks Switch Pro 48 PoE: https://lmg.gg/sStI7

Buy a Ubiquiti UniFi Protect Network Video Recorder: https://lmg.gg/FO7b7

Buy a Ubiquiti Networks UniFi SmartPower Redundant Power System: https://lmg.gg/2caLh

Buy an Eaton 9PX Lithium Ion UPS on Newegg: https://geni.us/L9ZA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1388464-check-out-my-huge-new-rack/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:29 Unboxing
3:46 How are we gonna move this thing??
6:23 Linus makes the obvious joke
6:30 It's almost TOO big...
7:48 ... Or is it? Here comes the UPS
10:13 Wire support
12:40 Linus drops his nuts
13:19 Big racks attract lots of cameras
15:18 96 network ports??
16:18 Time to get settled in
19:16 That's a lot of gear Linus can't use right now

