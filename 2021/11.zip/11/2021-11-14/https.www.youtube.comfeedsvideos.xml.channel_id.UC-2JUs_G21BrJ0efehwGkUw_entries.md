# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Crazy Train | Ozzy Osbourne | funk cover ft. Cody Fry
 - [https://www.youtube.com/watch?v=qpZKh7UO6e8](https://www.youtube.com/watch?v=qpZKh7UO6e8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-11-15 00:00:00+00:00

Subscribe to Cody Fry’s YouTube channel: https://www.youtube.com/c/CodyFry
To learn more about Cody’s music, visit http://codyfry.com

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Ozzy Osbourne's "Crazy Train" by Scary Pockets & Cody Fry.

MUSICIAN CREDITS
Lead vocal: Cody Fry
Drums: Tamir Barzilay
Bass: Sean Hurley
Guitar: Eric Krasno & Ryan Lerman
Keys: Jack Conte

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Hannah Kacmarsky
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Ricky Chavez 
Editor: Adam Kritzberg

Recorded Live at East West in Los Angeles, CA.

#ScaryPockets #Funk #CodyFry #CrazyTrain #OzzyOsbourne

