# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Metaverse, a własność prywatna. Luźne rozważania o wirtualnych światach!
 - [https://www.youtube.com/watch?v=2TFmj1WrgiE](https://www.youtube.com/watch?v=2TFmj1WrgiE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-11-15 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3nkOyRG
2. https://bit.ly/3hNDpFX
3. https://bit.ly/2YPhjwh
4. https://bit.ly/3Ckzoje
5. https://bit.ly/31URwDW
6. https://bit.ly/3nh1WG5
7. https://bit.ly/3wN0O0l
8. https://bit.ly/3Fjz7iF
9. https://bit.ly/3Ckjsh1
10. https://bit.ly/3wQoYH7
11. https://bit.ly/3kFe5Tw
---------------------------------------------------------------
💡 Tagi: #Metaverse #blockchain
--------------------------------------------------------------

## Szykują się nowe podatki! Katastralny, od flipów i pustostanów! Które zostaną wprowadzone pierwsze?
 - [https://www.youtube.com/watch?v=R3aAfDaObf0](https://www.youtube.com/watch?v=R3aAfDaObf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-11-14 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3naOnIl
2. https://bit.ly/3HoJZxq
3. https://bit.ly/3CdXDQo
4. https://bit.ly/3HilLF8
5. https://bit.ly/3l5pyeT
6. https://bit.ly/3DvNJLv
7. http://bit.ly/34dDw4q
8. https://bit.ly/3ChlyhR
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę: 
gov.pl - http://bit.ly/2lVWjQr
---
Adrian Grycuk - https://bit.ly/3ceCZoF
---------------------------------------------------------------
💡 Tagi: #kataster #mieszkania
--------------------------------------------------------------

