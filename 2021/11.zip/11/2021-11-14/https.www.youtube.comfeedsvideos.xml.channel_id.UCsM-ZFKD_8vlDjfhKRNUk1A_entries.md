# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Kolory - Wszystko co mówiłem - live MUZO.FM
 - [https://www.youtube.com/watch?v=DfKGEwXr9d4](https://www.youtube.com/watch?v=DfKGEwXr9d4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2021-11-14 00:00:00+00:00

Kolory na żywo w MUZO.FM. Utwór Wszystko co mówiłem pochodzi z debiutanckiej płyty Kolorów - Chcieliśmy tylko coś poczuć. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Kolory: http://www.facebook.com/koloryband
Instagram Kolory: http://www.instagram.com/koloryband
Instagram: http://www.instagram.com/muzofm 
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

