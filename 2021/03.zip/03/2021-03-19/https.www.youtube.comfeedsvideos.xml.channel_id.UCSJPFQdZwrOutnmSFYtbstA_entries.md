# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Zack Snyder's Justice League - Worth The Wait?
 - [https://www.youtube.com/watch?v=UHS17wRP4aI](https://www.youtube.com/watch?v=UHS17wRP4aI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-03-20 00:00:00+00:00

Well, it's finally here. But is The Snyder Cut any good? Let's find out...


Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8%3Fref=dbs_a_mng_rwt_scns_share
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on SubscribeStar: https://www.subscribestar.com/the-critical-drinker

