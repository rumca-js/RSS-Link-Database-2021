# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Microsoft 365 vs Office Online: What’s free, what’s not and do you need the paid version?
 - [https://www.techradar.com/news/microsoft-365-vs-office-online](https://www.techradar.com/news/microsoft-365-vs-office-online)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2021-03-19 07:34:23+00:00

The Microsoft 365 productivity suite comes in free, home and business versions, so we’ve explained the differences between the tiers – and explored which one is worth your time

