# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Silicon Valley's POWER GRAB - Can Big Tech Be Broken Up?
 - [https://www.youtube.com/watch?v=dQIEcflbdbw](https://www.youtube.com/watch?v=dQIEcflbdbw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-03-19 00:00:00+00:00

There have been calls to regulate Big Tech from both sides of the political spectrum, but what are the factors determining whether this is possible, and are the right measurements being used to judge Big Tech’s effects on society? 
#bigtech #siliconvalley

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com​/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Under The Skin podcast to hear from guests including Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Get a one month free trial at http://luminary.link/russell​

My Audible Original, ‘Revelation', is released on 25 March
My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

