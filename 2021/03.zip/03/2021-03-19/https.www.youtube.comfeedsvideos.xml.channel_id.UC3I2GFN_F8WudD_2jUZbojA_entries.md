# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Yung - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=EnCDW680YVc](https://www.youtube.com/watch?v=EnCDW680YVc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-20 00:00:00+00:00

http://KEXP.ORG presents Yung performing live, recorded exclusively for KEXP.

Session recorded at Dreamland Studio in Nibe, Denmark 
Video Production by Emma Acs & Frederikke-Agnete Svarre
Videographer: F. Agnete Svarre
Editor: Emma Acs

Session Producer: Kim Ambrosius Møgelby
Assistant Producer: Rosa Lois Balle Hansen Yahiya

Audio Recorded, produced and mixed by Neil R. Young

https://www.pnkslm.com/yung
http://kexp.org

## Yung - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=dnKutJQrkIE](https://www.youtube.com/watch?v=dnKutJQrkIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-19 00:00:00+00:00

http://KEXP.ORG presents Yung sharing a live performance recorded exclusively for KEXP and talking to DJ Troy Nelson. Recorded March 4, 2021.

Session recorded at Dreamland Studio in Nibe, Denmark 
Video Production by Emma Acs & Frederikke-Agnete Svarre
Videographer: F. Agnete Svarre
Editor: Emma Acs

Session Producer: Kim Ambrosius Møgelby
Assistant Producer: Rosa Lois Balle Hansen Yahiya

Audio Recorded, produced and mixed by Neil R. Young

https://www.pnkslm.com/yung
http://kexp.org

