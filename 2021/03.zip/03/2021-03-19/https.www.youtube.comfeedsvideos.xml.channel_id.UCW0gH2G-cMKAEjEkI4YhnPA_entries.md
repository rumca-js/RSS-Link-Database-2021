# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Why Balrogs Do NOT Have Wings | Tolkien 101
 - [https://www.youtube.com/watch?v=eXKnO8DO9tU](https://www.youtube.com/watch?v=eXKnO8DO9tU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-03-20 00:00:00+00:00

Do Balrogs have wings? It's a common debate among fans.  Today, I'm launching my new series "Tolkien 101" where we answer some of the most common questions - and misconceptions - about Middle-earth.  We look at all the passages involving balrogs for clues in order to answer the great wing debate!

Special thanks to our friends who were great resources for this video:
Corey Olsen - The Tolkien Professor: @SignumUniversity 
Alan Sisto & Shawn Marchese - The Prancing Pony Podcast: https://theprancingponypodcast.com

Frodo and Nazgul in Osgiliath - Anakin Jones
Saruman - Eric Faure-Brac
Balrog - Kosken Salmi
The Bridge of Khazad-dum - Philipp A Ulrich
Balrog - Sander Agelink
Spirit of Fire - CK Goksoy
Gandalf and the Balrog of Moria - K Mendou
The Balrog - Matt DeMino
The Bridge of Khazad-dum - Anna Kulisz
Gandalf and the Balrog - Anato Finnstark
Eagles of Manwe - Ted Nasmith
Dark Lore of LOTR - Into the Storm - Sebastian Rodriguez
Balrogs Defending Morgoth from Ungoliant - Jovan Delic
Hurin and the Balrogs - Pete Amachree
Bilbo and the Eagles - Ted Nasmith
The Dwarves Delve Too Deep - Ted Nasmith
The Bridge of Khazad-dum - Gustavo Pelissari
Gandalf Falls with the Balrog - John Howe
Flight to the Ford - M Hugo
The Fellowship in Hollin - The Brothers Hildebrandt
Gildor, Sam, Pippin, Frodo, and Elves - Steamey
Moria - Ralph Bakshi
Balrog - Stephen Najarian
Morgoth and Fingolfin - Joel Kilpatrick
The Winged Dragons - Anato Finnstark
Dragons of the War of Wrath - Anato Finnstark
Gandalf and the Balrog Upon Celebdil - Ted Nasmith
Balrog vs Glorfindel - Rui Goncalves
Ancalagon and Earendil - Ivana Lekseich
Glorfindel and the Balrog - Justin Gerard
The Vanyar Prepare for Battle - Jenny Dolfen
Melkor - Thomas Rouillard
Balrog - Juan Manuel Pelaez Duarte
Gandalf and the Balrog - Evolvana
Fall of Gondolin - CK Goksoy
Echthelion Fighting Gothmog - Vargasni
The Fall of Gondolin - Edvige Faini
Flight of the Doomed - Ted Nasmith
Glorfindel and the Balrog - Alan Lee
Gandalf vs Balrog - Minjun Kim
Balrog - Marco Ferrari
Zirak-zigil - John Howe
Gothmog, Lord of Balrogs - Jovan Delic
Flame of Udun - Manuel Castanon
Shadow of War Balrog - Wardenlight Studio
Gothmog and Ecthelion - Eric Velhagen

To learn more about Balrogs and other creatures from Middle-earth, check out:
The Lord of the Rings
The Silmarillion
The Fall of Gondolin
History of Middle-earth Volume 10: Morgoth's Ring
The Encyclopedia of Arda
Tolkien Gateway

#balrog #tolkien #lordoftherings

