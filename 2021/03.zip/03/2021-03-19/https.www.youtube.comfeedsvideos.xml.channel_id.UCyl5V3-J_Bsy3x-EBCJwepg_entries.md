# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## It’s For The Kids and National Socialism
 - [https://www.youtube.com/watch?v=uy5wfBZmV0k](https://www.youtube.com/watch?v=uy5wfBZmV0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-19 00:00:00+00:00

Kyle and Ethan talk about the week’s biggest stories like a man sitting in a pool of bean dip for a good cause, brave teacher’s unions literally laying their lives down for the kids, and the entire world becoming national socialists. Ethan talks about losing his dad this week, the guys will do anything for money, and we get sent the best hate mail.

00:06:25 Subscriber Dare 
00:10:03 Weird News
00:30:46 Is This Like The Nazis?
00:35:55 Teacher's Union Negotiations
00:42:03 Hate Mail

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## The Real Victims of Cancel Culture Finally Speak Out!
 - [https://www.youtube.com/watch?v=viRylVLRK5g](https://www.youtube.com/watch?v=viRylVLRK5g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-19 00:00:00+00:00

Mr. Potato Head, Gina Carano, Kermit the Frog, Pepe Le Pew and The Land-O-Lakes Lady finally fight back against cancel culture and tell their side of the story! Oh... and Andrew Cuomo too.

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

