# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Hitman 3 VR Is A Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=rP8g04bUWB0](https://www.youtube.com/watch?v=rP8g04bUWB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2021-03-19 22:00:11+00:00

The first 1000 people to use this link will get a free trial of Skillshare Premium Membership: https://skl.sh/upisnotjump03211

Hitman 3 is finally here, and with it comes a VR version. So my hands are tied and I must review it! This VR version is not on steam currently by the way, it is only on PSVR.

So I must dust off my totally not useless PS4 and buy a PSVR which apparently doesn’t even come with wireless controllers even though it’s a VR console! Anyway...

When I heard Hitman 2 was getting a VR version I actually thought they meant Silent Assassin because I am an idiot. All 3 of this new trilogy can be played in VR using the PS4 and PSVR but I only played and reviewed Hitman 3 VR for this video.

Overall Hitman 3 is a good but slightly pricey game, Hitman 3 PSVR I would say is a bad game that comes free with it. So Hitman VR it’s definitely worth trying, but it won’t knock your socks off. 

I may move away from VR for a while after this review, my hopes are to do Fallout Is A Nightmare but cover all of those games.

Patreon: https://www.patreon.com/UpIsNotJump
Merch: https://www.pixelempire.com/pages/upisnotjump
Twittz: https://twitter.com/UpIsNotJump

Super special thanks to my members!
BioGeek
Superhero3807
GreenCoatGaming
Bunbun
Clementine
Superhero3807
Dylan Kenny
QuietAlice
Dyllan Meacham
SAMEJINX
Goxid
Ali Khan
Donald Callahan
Gisca
Deadeth
Flame Soulis
Coat Hook
lordofthesea 3
CaptainFlowers
Bio Geek
John Engelhardt
Pfnoll
DJJax
Ellana Rose Thornton-Wheybrew
MikeTheSpike
hamsterking5
Jacob Rodriguez
GreenCoatGaming
randandy31
kennedy kempton
Anders Rokke
Daniel Sánchez Suárez
Sarah Luczyk
ASSISTJORDAN
Wiseman Labs
Andrew Harrison
Kaleb Jacobsen
Spectere
Troubleshoot Fox
WhiteDragonTC
steven Dielissen

