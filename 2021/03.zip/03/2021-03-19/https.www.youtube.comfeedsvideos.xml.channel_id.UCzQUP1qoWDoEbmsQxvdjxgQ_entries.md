# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Jim Breuer's Coronavirus Questions
 - [https://www.youtube.com/watch?v=3FHRe3ISh5M](https://www.youtube.com/watch?v=3FHRe3ISh5M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-20 00:00:00+00:00

https://open.spotify.com/episode/7bbJslK5lnJrA7ZN4Zfy9r?si=e9b12475194941b5

## Why Jim Breuer Quit SNL
 - [https://www.youtube.com/watch?v=6YQvWK9GPsY](https://www.youtube.com/watch?v=6YQvWK9GPsY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-20 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1621 with Jim Breuer.  https://open.spotify.com/episode/7bbJslK5lnJrA7ZN4Zfy9r?si=e9b12475194941b5

