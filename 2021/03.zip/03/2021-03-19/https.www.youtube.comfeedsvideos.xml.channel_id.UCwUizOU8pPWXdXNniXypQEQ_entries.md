# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## When Political Correctness Is LIFE
 - [https://www.youtube.com/watch?v=ggn0L4AtuRQ](https://www.youtube.com/watch?v=ggn0L4AtuRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-03-20 00:00:00+00:00

Grab your Remedy Sleep Mask and other Blublox Products Here - https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Check out my NEW MERCH here! - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

When political correctness is life! Watch two idiots be PC on current events. You’ll learn how to be the most amount of political correct instead of being yourself.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

