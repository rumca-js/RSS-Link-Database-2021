# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Best Replacement iPhone Screen? Every Type Compared - LCD | OLED - Soft - Hard - OEM
 - [https://www.youtube.com/watch?v=e2U4LULXOT4](https://www.youtube.com/watch?v=e2U4LULXOT4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-03-20 00:00:00+00:00

With so many different types, buying a replacement iPhone screen can be confusing, lets compare them all and find the best ones!
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
Screens used in the video:
https://www.ifixit.com/Store/iPhone/iPhone-XS-Screen/IF406-017?o=3
https://www.crazyparts.com.au/oled-assembly-for-iphone-xs-crazy-hard.html
https://www.crazyparts.com.au/oled-assembly-for-iphone-xs-gx-hard-15284.html
https://www.crazyparts.com.au/oled-assembly-for-iphone-xs-refurbished.html

Tools I Use: https://www.hughjeffreys.com/tools

Get parts, tools, and thousands of free repair guides from iFixit at: 
                               https://iFixit.com/hughjeffreys
Australian Store: https://ifix.gd/2FPxhKy

---------------------------------------------------------------------------------------
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

