# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Samsung is running out of chips too...
 - [https://www.youtube.com/watch?v=0KEibglJZog](https://www.youtube.com/watch?v=0KEibglJZog)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-03-19 00:00:00+00:00

Sponsored by Skillshare. The first 1000 to sign up with this link can try Skillshare Premium for free: https://skl.sh/thefridaycheckout03211

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► About this video◄◄◄

This week Samsung announced they are running out of chips, and the Note series, Wikipedia announced an Enterprise API to start making money, and Volkswagen announced they are really, really serious about electric cars.

The Friday Checkout - Episode 39

This video on Nebula: https://watchnebula.com/videos/the-friday-checkout-samsung-is-also-running-out-of-chips-now

Quiz: https://link.crrowd.com/quiz (should open either in the Android app or on the web depending on what device you're on!)
Release monitor: https://www.crrowd.com/release-monitor

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:37 Release Highlights
1:22 Samsung running out of chips
3:34 Volkswagen vs. Tesla
5:24 Wikipedia Enterprise

