# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#226] Czy instytucja Kościoła jest niepotrzebna?
 - [https://www.youtube.com/watch?v=Vk_Vsir8hA8](https://www.youtube.com/watch?v=Vk_Vsir8hA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-20 00:00:00+00:00

#CNN  @Langustanapalmie 

Kazanie na V Niedzielę Wielkiego Postu, Rok B

1. czytanie (Jr 31, 31-34)

Pan mówi: «Oto nadchodzą dni, kiedy zawrę z domem Izraela i z domem Judy nowe przymierze. Nie takie jak przymierze, które zawarłem z ich przodkami, kiedy ująłem ich za rękę, by wyprowadzić z ziemi egipskiej. To moje przymierze złamali, mimo że byłem ich władcą, mówi Pan.

Lecz takie będzie przymierze, jakie zawrę z domem Izraela po tych dniach, mówi Pan: Umieszczę swe prawo w głębi ich jestestwa i wypiszę na ich sercach. Będę im Bogiem, oni zaś będą Mi ludem.

I nie będą się musieli wzajemnie pouczać, mówiąc jeden do drugiego: Poznajcie Pana! Wszyscy bowiem od najmniejszego do największego poznają Mnie, mówi Pan, ponieważ odpuszczę im występki, a o grzechach ich nie będę już wspominał».

2. czytanie (Hbr 5, 7-9)

Bracia: Chrystus z głośnym wołaniem i płaczem, za swych dni doczesnych, zanosił gorące prośby i błagania do Tego, który mógł Go wybawić od śmierci, i został wysłuchany dzięki swej uległości.
I chociaż był Synem, nauczył się posłuszeństwa przez to, co wycierpiał. A gdy wszystko wykonał, stał się sprawcą zbawienia wiecznego dla wszystkich, którzy Go słuchają.

Ewangelia (J 12, 20-33)

Wśród tych, którzy przybyli, aby oddać pokłon Bogu w czasie święta, byli też niektórzy Grecy. Oni więc przystąpili do Filipa, pochodzącego z Betsaidy Galilejskiej, i prosili go, mówiąc: «Panie, chcemy ujrzeć Jezusa». Filip poszedł i powiedział Andrzejowi. Z kolei Andrzej i Filip poszli i powiedzieli Jezusowi.

A Jezus dał im taką odpowiedź: «Nadeszła godzina, aby został otoczony chwałą Syn Człowieczy. Zaprawdę, zaprawdę, powiadam wam: Jeśli ziarno pszenicy, wpadłszy w ziemię, nie obumrze, zostanie samo jedno, ale jeśli obumrze, przynosi plon obfity. Ten, kto kocha swoje życie, traci je, a kto nienawidzi swego życia na tym świecie, zachowa je na życie wieczne. Kto zaś chciałby Mi służyć, niech idzie za Mną, a gdzie Ja jestem, tam będzie i mój sługa. A jeśli ktoś Mi służy, uczci go mój Ojciec.

Teraz dusza moja doznała lęku i cóż mam powiedzieć? Ojcze, wybaw Mnie od tej godziny. Ależ właśnie dlatego przyszedłem na tę godzinę. Ojcze, wsław imię Twoje!»

Wtem rozległ się głos z nieba: «Już wsławiłem i jeszcze wsławię». Stojący tłum to usłyszał i mówił: «Zagrzmiało!» Inni mówili: «Anioł przemówił do Niego». Na to rzekł Jezus: «Głos ten rozległ się nie ze względu na Mnie, ale ze względu na was. Teraz odbywa się sąd nad tym światem. Teraz władca tego świata zostanie wyrzucony precz. A Ja, gdy zostanę nad ziemię wywyższony, przyciągnę wszystkich do siebie».

To mówił, oznaczając, jaką śmiercią miał umrzeć.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## List do Hebrajczyków || Rozdział 13
 - [https://www.youtube.com/watch?v=I710ygREItw](https://www.youtube.com/watch?v=I710ygREItw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#740] Wola
 - [https://www.youtube.com/watch?v=7_rn89ndGzA](https://www.youtube.com/watch?v=7_rn89ndGzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-20 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 20.03 → https://youtu.be/dh6czmzWsQE

POD SERCEM to wielkopostna akcja charytatywna, której celem jest pomoc kobietom w ciąży, znajdującym się w trudnej sytuacji lub z różnych powodów niebędącym w stanie poradzić sobie z wiadomością o dziecku bądź jego chorobie. 

Fundacja Malak
Numer konta (PLN): 42 2490 0005 0000 4600 1184 3564
IBAN: PL 42 2490 0005 0000 4600 1184 3564
BIC/SWIFT: ALBPPLPW
"Pod sercem. Wielkopostna akcja charytatywna"

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Za kogoś  [#28] Okruchy 2 [SK/PL]
 - [https://www.youtube.com/watch?v=wUxon1yjNco](https://www.youtube.com/watch?v=wUxon1yjNco)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-20 00:00:00+00:00

@Langustanapalmie @Stacja7pl 

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## List do Hebrajczyków || Rozdział 12
 - [https://www.youtube.com/watch?v=QHwjo-J6OG4](https://www.youtube.com/watch?v=QHwjo-J6OG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-19 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#739] Troski
 - [https://www.youtube.com/watch?v=cToS6yaWxg4](https://www.youtube.com/watch?v=cToS6yaWxg4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-19 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 19.03 →https://youtu.be/Nlqh0Vfui40

POD SERCEM to wielkopostna akcja charytatywna, której celem jest pomoc kobietom w ciąży, znajdującym się w trudnej sytuacji lub z różnych powodów niebędącym w stanie poradzić sobie z wiadomością o dziecku bądź jego chorobie. 

Fundacja Malak
Numer konta (PLN): 42 2490 0005 0000 4600 1184 3564
IBAN: PL 42 2490 0005 0000 4600 1184 3564
BIC/SWIFT: ALBPPLPW
"Pod sercem. Wielkopostna akcja charytatywna"

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Śpij [#27] Okruchy 2 [SK/PL]
 - [https://www.youtube.com/watch?v=kyKpE660L-E](https://www.youtube.com/watch?v=kyKpE660L-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-19 00:00:00+00:00

​@Langustanapalmie @Stacja7pl 

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00

________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

