# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## How Apple Started A Dark Age of the Internet
 - [https://www.youtube.com/watch?v=8_-fcFivTS8](https://www.youtube.com/watch?v=8_-fcFivTS8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2021-03-20 00:00:00+00:00

This is the story of Apple, the forbidden fruit, that led us into a dark age of consumerism, conformity, and control. In this documentary, I explore how we got here, and how we might be able to find light in this darkness.

written, edited, filmed, and produced by me

with copywriting assistance by VinceVintage and friends

Track List:

Opening - The Legend of Zelda Majora's Mask
Question - Million Eyes
Revolution - The Beatles 8 Bit
Cantos de Medicina
Trmble - Lemoti
One Hundred Mornings - Windows96
Day Tripper - The Beatles 8 Bit
Amaze - Major Tweaks
Jerk It Out - Caesars 8 Bit
Temple of Ruhna - ELFL
Arabesque No 1 - Debussy
Clock Town Third Day - The Legend of Zelda Majora's Mask
Dream Baby Dream - Cover by Kevin Bessey (produced for this video)
Op 90 No 3 Una Corda Cotton - Shubert
Graze - Cover by Shuler and Slush (vocals by Slush, prod. by Shuler)

Special thanks to Kevin Bessey and Shuler for producing original tracks for this video, thanks to Slush for singing (I sang the "let me begin" part)

Check out Kevin Bessey's spotify: https://open.spotify.com/artist/53h4243mR88lDJIjU5JsOb

The G-Links:

https://twitter.com/GlinkLive
Twitter, where I publish all my hot takes and dank memes

https://www.reddit.com/r/glink/
Reddit, nobody uses this, but you can post memes here

https://www.instagram.com/glink_between_worlds/
Instagram, this is where things get real  a e s t h e t i c 

https://discord.gg/xtwYypf
My Discord, only for REAL gamers

https://www.patreon.com/Glink
Support me on Patreon and be included in Q & As, audio updates, discord roles, and credits at the end of my videos 

https://teespring.com/stores/shop-glink
Want to look fly while supporting my channel? Buy a T-shirt or poster here, all designs are custom made and completely original, not mention tasteful and artistic

https://www.youtube.com/channel/UChJT4Jg89AHMyybcXFeKp_A
My podcast with Slush

