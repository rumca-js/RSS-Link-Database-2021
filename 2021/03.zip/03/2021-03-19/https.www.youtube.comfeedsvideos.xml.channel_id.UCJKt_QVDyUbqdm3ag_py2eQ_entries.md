# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Jammer - Krak Zak (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=sS-oIompLP8](https://www.youtube.com/watch?v=sS-oIompLP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-20 00:00:00+00:00

"Krak Zak" (2002) by Jammer/MultiStyle Labs^Samar Productions (Kamil Wolnikowski). Art "Shrill" (2013) by Yazoo/Arsenic^Censor Design^Oxyron. Christopherjam palette used for more saturated colors.

My old upload from 2016, emulated and stereo Dolbyfied:
https://www.youtube.com/watch?v=W-lTwNSUcQs

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

## SID music: Saul Cross - Stranger Things C64 Mix (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=Qfp9p_bf9Z4](https://www.youtube.com/watch?v=Qfp9p_bf9Z4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-20 00:00:00+00:00

"Stranger Things C64 Mix" (2017) by Saul Cross/RGCD, original by Survive. Art "SuperFresh" (2020) by Facet/Genesis Project. Christopherjam palette used for more saturated colors.

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

## SID music: AMJ - Unsound Minds (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=suwJeL63QNw](https://www.youtube.com/watch?v=suwJeL63QNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-19 00:00:00+00:00

"Unsound Minds" (C64 demo, 1996) soundtrack by AMJ/Byterapers (Juha-Matti Hilpinen). Art by Mike/Byterapers (note sure about the logo, but 2nd and 3rd images for sure). Christopherjam palette used for more saturated colors.

My previous upload from 2012, emulated mono Dolbyfied, i wouldn't bother with it anymore:
https://www.youtube.com/watch?v=zpy6b3TILTI

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

