# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Tyranny Review
 - [https://www.youtube.com/watch?v=0HU1rMDGyB8](https://www.youtube.com/watch?v=0HU1rMDGyB8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2021-03-19 00:00:00+00:00

The Tyranny review covers the base game and all the fancy DLCs from the Gold Edition that aren't that fancy. Evil can be fun!
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/mandaloregaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
00:47 - Game Premise
01:37 - Visuals
03:38 - Music & Sound Design
05:50 - Character Creation
07:45 - Terratus Current Events
09:45 - Gameplay
18:29 - Story
21:13 - DLC
21:54 - Conclusions
22:34 - Credits
23:39 - Pain

#Tyranny #TyrannyReview #TyrannyGame #TyrannyPC #TyrannyRPG

