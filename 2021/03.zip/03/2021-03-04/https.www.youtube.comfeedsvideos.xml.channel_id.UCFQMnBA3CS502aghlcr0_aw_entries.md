# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Jay Mazini's $1,000,000 Scam Has Victims FURIOUS and Chasing Him
 - [https://www.youtube.com/watch?v=hls3yHrV8uk](https://www.youtube.com/watch?v=hls3yHrV8uk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-04 00:00:00+00:00

The man who can't stop digging himself into a hole, Jay Mazini. 
Jay Mazini has not only ran a giveaway scam, halal capital scam, but now he is running a bitcoin scam that is ongoing. Two of Jay Mazini's Victims who accuse him of being a huge scam allege that they were defrauded for $190,000 and $750,000 apiece. 

That's only the victims of Jay Mazini that have reached out to me. I would guess that there are many others still out there.  Watch the full Jay Mazini saga playlist here 

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

