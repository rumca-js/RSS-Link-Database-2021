# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## What I REALLY Think of the iPhone!
 - [https://www.youtube.com/watch?v=V7J9aMy_CFk](https://www.youtube.com/watch?v=V7J9aMy_CFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-03-05 00:00:00+00:00

Thoughts on a few months/years with the latest iPhone

Sponsor: Go to https://www.expressvpn.com/mkbhd to get 3 months free

LINKS
iPhone 12 Review: https://youtu.be/X1b3C2081-Q
iPhone 12 Pro Review: https://youtu.be/eWI_BtcDJu0
iPhone 12 Mini Review: https://youtu.be/Yhze-aRR6o0
iPhone 12 Pro Max Review: https://youtu.be/qrzCLgDplTw
On an iPhone with No Ports: https://youtu.be/Qfmeb2e_kb4
JerryRigEverything Durability test: https://youtu.be/LP6ppSM3xq4
Galaxy S21 is the only Android that doesn't suck at Snapchat: https://www.androidpolice.com/2021/02/22/the-galaxy-s21-is-the-only-android-phone-that-doesnt-suck-at-snapchat/
Belkin Magsafe car mount: https://www.belkin.com/us/p/P-WIC002/
MOMENT Car Vent Mount w/ MagSafe: https://www.shopmoment.com/products/car-vent-mount-for-magsafe
iOS 14's New Features: https://youtu.be/ZLyDvABxGF0
iOS 14 Widgets/Homescreen: https://youtu.be/cH66LWWluVE
Widgets poll: https://twitter.com/MKBHD/status/1364940776107438080
The Apple Ecosystem: Explained! https://youtu.be/KB4_WIPE7vo
5G Explained: https://youtu.be/_CTUs_2hq6Y
iPhone "Gates" Explained: https://youtu.be/ndphYju6PVM

0:00 Intro
3:57 Design
10:48 The Screen
18:07 Cameras
26:43 MagSafe
30:02 Battery
32:09 The iPhone
37:03 5G JUST Got Real?
40:36 GATES
45:28 Conclusion

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

