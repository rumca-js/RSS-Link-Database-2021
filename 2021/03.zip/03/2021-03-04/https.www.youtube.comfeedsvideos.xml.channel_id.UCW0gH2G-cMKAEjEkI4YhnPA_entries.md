# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Alan Sisto & Shawn Marchese (Prancing Pony Podcast) Livestream Interview
 - [https://www.youtube.com/watch?v=U0gywNAwwpM](https://www.youtube.com/watch?v=U0gywNAwwpM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-03-04 00:00:00+00:00

We welcome the hosts of The Prancing Pony Podcast - one of the most popular Tolkien-related podcasts - Alan Sisto & Shawn Marchese.   You can listen to the The Prancing Pony Podcast wherever you get your podcasts.  Alan & Shawn recently celebrated the 5th Anniversary of starting the PPP, which won the 2020 Tolkien Society Award for Best Online Content.

