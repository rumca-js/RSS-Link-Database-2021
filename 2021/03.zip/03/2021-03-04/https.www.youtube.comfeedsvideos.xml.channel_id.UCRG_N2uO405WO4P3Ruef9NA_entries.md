# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Google plans to ... stop tracking you?
 - [https://www.youtube.com/watch?v=8tWX12vrsgA](https://www.youtube.com/watch?v=8tWX12vrsgA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-03-05 00:00:00+00:00

This week, Google announced it wants to stop showing you personalized ads and will switch to FLoC (Federated Learnings of Cohorts) instead, Samsung got great at updates and the Carbon 1 MK II, the world's first carbon fiber phone was launched.

The Friday Checkout - Episode 37

This episode on Nebula: https://watchnebula.com/videos/the-friday-checkout-google-plans-to-stop-tracking-you

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Links mentioned in this video◄◄◄

Quiz: https://link.crrowd.com/quiz
Release monitor: https://www.crrowd.com/release-monitor

GDPR video: https://www.youtube.com/watch?v=v_W0wR4AClk
Carbon Mobile interview: https://youtu.be/U7-EaXZQvxk?t=655

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 - Intro
0:39 - Google tracking (FLoC)
3:54 - Samsung Android updates
5:54 - New releases

