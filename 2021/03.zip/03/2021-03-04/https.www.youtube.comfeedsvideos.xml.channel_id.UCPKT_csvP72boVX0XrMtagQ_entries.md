# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## WhoMadeWho live at Abu Simbel, Egypt for Cercle
 - [https://www.youtube.com/watch?v=BDwAlto-NKU](https://www.youtube.com/watch?v=BDwAlto-NKU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2021-03-05 00:00:00+00:00

WhoMadeWho playing an exclusive live set from the temples of Abu Simbel, in Egypt for Cercle. 

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ Cercle Records
WhoMadeWho - Abu Simbel
https://Cercle.lnk.to/WMWAbuSimbel

WhoMadeWho & Patrice Baümel - Nefertari
https://cercle.lnk.to/NefertariWMWPatriceBaumel

☞ WhoMadeWho
https://www.facebook.com/whomadewho
https://www.instagram.com/whomadewhoofficial/
https://open.spotify.com/artist/50Lr1puweM1hFsF1LpIZLM?si=E6_DcZD-QG6U3vIDWixy2Q
https://music.apple.com/fr/artist/whomadewho/332944048?l=en

22°20'12.7"N 31°37'32.4"E

Video credits:

Artist: WhoMadeWho
Venue: Abu Simbel, Egypt 
Produced by Cercle
Executive producers: Philippe Tuchmann & Derek Barbolla
Film directed by: Pol Souchier & Derek Barbolla
Director of photography:  Mickaël Fidjili & Mathieu Glissant
Drone pilots: Alexis Olas & Ifly
Sound mix & mastering: Jon Schumann
Production team: Anaïs De Framond, Dan Aufsesser, Armand Prouhèze
Communication: Anaëlle Rouquette & Pol Souchier
Technical Manager: Aurélien Moisan
Sound engineer: Ahmed Khalil
Post-production: Mathieu Glissant (Saison Unique Production)

--
Special thanks to:

Bas Enab & Mahmoud Zidan & Ahmed Khalil from Playground 
Carsten Levi from WMW's management
Galerie Joseph 

Khaded Al Anini (Minister of Antiquities and Tourism) Ahmed Youssef (Chairman of Egypt Tourism Promotion Authority)

Freedom Music, Sunrise Resorts & Hotels & Redbull. 

______

This artistic performance has been recorded live. 

Tracklist : 

0:00 WhoMadeWho - Abu Simbel 
8:31 WhoMadeWho, Patrice Bäumel - Nefertari
13:55 WhoMadeWho - Dynasty (Jimi Jules Remix) 
19:30 WhoMadeWho, Rampa - Everyday
24:40 WhoMadeWho, Mano Le Tough - Oblivion
31:00 UNRELEASED
34:18 Rampa, WhoMadeWho - Tell Me Are We
39:50 Whomadewho, Marc Piñol - Sooner 
43:18 WhoMadeWho, Sainte Vie - Hibernation 
49:02 WhoMadeWho - Montserrat (ARTBAT Edit) 
56:00 WhoMadeWho - Never Alone
1:01:10 ARTBAT, WhoMadeWho - Closer 
1:06:30 WhoMadeWho, Adana Twins - Immersion 
1:13:35 WhoMadeWho - I Don’t Know (Stereocalypse Remix) 
1:19:00 WhoMadeWho - Heads Above 
1:28:40 Q&A

______

Follow us on http://www.cercle.io

