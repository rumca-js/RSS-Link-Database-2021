# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Samsung S21 drop test
 - [https://www.youtube.com/watch?v=3mgOiNX25d8](https://www.youtube.com/watch?v=3mgOiNX25d8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-03-04 00:00:00+00:00

W tym filmie jest dużo zrzucania smartfonów. Z różnych wysokości :) Nie ma za to reklam, ponieważ film zawiera krótkie fragmenty sponsorowane. Dzięki nim mogłem pozwolić sobie na nieco więcej :D
Aplikacja ZEN: https://bit.ly/3rklh8W (kod przedłużający okres próbny: klawyzen)
S21 w OleOle: http://bit.ly/3kNK2bs

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

Spis treści:
00:00 Czy drop testy są potrzebne?
00:56 Fragment sponsorowany – ZEN
01:19 Samsung S21- unboxing
01:43 Fragment sponsorowany – Ole Ole
02:04 Wstęp do drop testów
02:23 Samsung S21 Ultra 5G – 1 metr
03:20 Samsung S21 Ultra 5G – 2 metry
04:25 Samsung S21 Ultra 5G – 4 metry
05:43 Samsung S21 Ultra 5G ekranem do dołu – 4 metry
06:30 Samsung S21 – 1 metr
07:28 Samsung S21 – 2 metry
08:21 Samsung S21 – 4 metry
09:10 Samsung S21 ekranem do dołu – 4 metry
10:39 Licytacja smartfonów
11:08 Wnioski

