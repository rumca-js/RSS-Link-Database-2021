# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Death by Rooster and Observing Lent While Hating Everybody
 - [https://www.youtube.com/watch?v=kXdHJDAOmlQ](https://www.youtube.com/watch?v=kXdHJDAOmlQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-05 00:00:00+00:00

Ethan is joined by Doug TenNapel in Exile and Wes Halula on this Bee Weekly to talk about Texas ditching mask mandates and what it’s like to celebrate Lent while hating everybody. Ethan and Wes discuss totally substantiated Lucasfilm and Star Wars rumors involving Gina Carano, Kathleen Kennedy, and Bill Burr. Also, irony strikes at cockfights and Satanic cats try to crash passenger airplanes. 

See more Doug TenNapel in Exile: https://www.youtube.com/channel/UCp8GId3Figb51baHAJjxHCg

Happy Birthday Bee, Subscriber Dares, Zuckerberg 00:01:10
Weird News 00:06:20
Star Wars Rumors 00:16:20
Doug TenNapel in Exile 00:22:08
Hate Mail 00:38:34

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

