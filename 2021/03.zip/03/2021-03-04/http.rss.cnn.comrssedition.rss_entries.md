# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Investigators examining communications between US lawmakers and Capitol rioters
 - [https://www.cnn.com/collections/intl-capitol-riot-fallout-0303/](https://www.cnn.com/collections/intl-capitol-riot-fallout-0303/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 22:51:37+00:00



## See Jupiter and Mercury align in the sky and an asteroid flyby this weekend
 - [https://www.cnn.com/2021/03/04/world/mercury-jupiter-conjunction-apophis-scn/index.html](https://www.cnn.com/2021/03/04/world/mercury-jupiter-conjunction-apophis-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 22:33:50+00:00

The solar system's largest and smallest planets will be in alignment this Friday.

## 'Matilda' star reveals why she left Hollywood
 - [https://www.cnn.com/videos/world/2021/03/04/matilda-mara-wilson-child-stars-exploitation-amanpour-vpx.cnn](https://www.cnn.com/videos/world/2021/03/04/matilda-mara-wilson-child-stars-exploitation-amanpour-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 22:00:46+00:00

CNN's Christiane Amanpour talks to "Matilda" actress Mara Wilson about the exploitation of child stars in Hollywood.

## Italy blocks the export of Covid-19 vaccines to Australia
 - [https://www.cnn.com/2021/03/04/europe/italy-astrazeneca-doses-australia-intl/index.html](https://www.cnn.com/2021/03/04/europe/italy-astrazeneca-doses-australia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 21:52:43+00:00



## Feds examining communications between US lawmakers and Capitol rioters
 - [https://www.cnn.com/2021/03/04/politics/capitol-riot-investigation-lawmakers/index.html](https://www.cnn.com/2021/03/04/politics/capitol-riot-investigation-lawmakers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 21:37:30+00:00

• Diplomatic security official removed from post for declaring 'death of America' after Trump lost

## Teenager dies after being stung by a box jellyfish in Australia
 - [https://www.cnn.com/2021/03/04/australia/australia-box-jellyfish-death-intl-scli/index.html](https://www.cnn.com/2021/03/04/australia/australia-box-jellyfish-death-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 21:06:45+00:00

A 17-year-old boy has died a week after being stung by a box jellyfish on a Queensland beach, Australia.

## Blinken and Austin will travel to Japan and South Korea this month
 - [https://www.cnn.com/2021/03/04/politics/blinken-austin-japan/index.html](https://www.cnn.com/2021/03/04/politics/blinken-austin-japan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 21:05:42+00:00

Secretary of State Antony Blinken and Secretary of Defense Lloyd Austin will travel to Japan and South Korea later this month, marking the first international trip by Biden Cabinet officials since President Joe Biden's inauguration, according to a State Department official and a diplomat from the region.

## YouTube CEO says Trump's account will be restored when risk of violence recedes
 - [https://www.cnn.com/2021/03/04/tech/youtube-trump-account/index.html](https://www.cnn.com/2021/03/04/tech/youtube-trump-account/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 21:02:41+00:00

Former President Donald Trump's YouTube account will eventually be restored in accordance with the platform's current policies, the company's CEO, Susan Wojcicki, said Thursday.

## Pro-Trump senator uses extreme tactics to slow stimulus passage
 - [https://www.cnn.com/2021/03/04/politics/ron-johnson-wisconsin-republican-stimulus-debate/index.html](https://www.cnn.com/2021/03/04/politics/ron-johnson-wisconsin-republican-stimulus-debate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 20:41:32+00:00

Sen. Ron Johnson seems to be relishing his place at the center of the controversies dominating Washington.

## Colossal arena transformed into drive-in runway for Paris Fashion Week
 - [https://www.cnn.com/style/article/paris-fashion-week-coperni-drive-in-fashion-show/index.html](https://www.cnn.com/style/article/paris-fashion-week-coperni-drive-in-fashion-show/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 20:28:05+00:00

Over the past year, fashion collections have been shown primarily through video and ultra-limited, socially distanced live presentations due to the ongoing pandemic. Now, a drive-in runway show can be added to the fashion world's creative workarounds thanks to French fashion brand Coperni.

## White House fires back at Trump testing czar over claims
 - [https://www.cnn.com/videos/politics/2021/03/04/white-house-psaki-trump-testing-czar-giroir-sot-vpx-nr.cnn](https://www.cnn.com/videos/politics/2021/03/04/white-house-psaki-trump-testing-czar-giroir-sot-vpx-nr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 20:11:11+00:00

White House press secretary Jen Psaki fired back at Admiral Brett Giroir, former President Donald Trump's coronavirus testing czar, when asked about giving the former President credit for the rollout of Covid-19 vaccines in the US.

## Trump trashed Gov. Kemp after election. See what Kemp says about Trump now.
 - [https://www.cnn.com/videos/politics/2021/03/04/keilar-roll-the-tape-republicans-courage-trump-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/03/04/keilar-roll-the-tape-republicans-courage-trump-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 19:50:56+00:00

CNN's Brianna Keilar says some prominent Republicans lack the courage needed to distance themselves from former President Donald Trump.

## Sputnik V maker's CEO blames media for Russians' hesitancy
 - [https://www.cnn.com/videos/world/2021/03/04/kirill-dmitriev-sputnik-v-coronavirus-vaccine-ctw-vpx.cnn](https://www.cnn.com/videos/world/2021/03/04/kirill-dmitriev-sputnik-v-coronavirus-vaccine-ctw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 19:07:26+00:00

Kirill Dmitriev, CEO of the organization that makes Sputnik V, sits down with CNN's Becky Anderson to discuss the Russian coronavirus vaccine and its standing around the world.

## 'QAnon Shaman' says he has one regret about January 6
 - [https://www.cnn.com/videos/media/2021/03/04/qanon-shaman-jacob-chansley-60-minutes-interview-orig-bdk.cnn](https://www.cnn.com/videos/media/2021/03/04/qanon-shaman-jacob-chansley-60-minutes-interview-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 18:32:43+00:00

Jacob Chansley, the man known as "QAnon Shaman," spoke to 60 Minutes+ from jail about his involvement in the January 6 insurrection at the US Capitol.

## Surfer Billy Kemper was enjoying the trip of his dreams until everything went wrong
 - [https://www.cnn.com/2021/03/04/sport/billy-kemper-surfing-injury-spt-intl/index.html](https://www.cnn.com/2021/03/04/sport/billy-kemper-surfing-injury-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 17:08:59+00:00

It was a tiny error in judgement, but within seconds he realized that the consequences could be potentially life threatening.

## Stolen 16th-century armor returned to Louvre decades after theft
 - [https://www.cnn.com/style/article/stolen-armor-returned-louvre-scli-intl/index.html](https://www.cnn.com/style/article/stolen-armor-returned-louvre-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 17:02:35+00:00

Two pieces of 16th-century armor have been returned to the Louvre museum in Paris almost 40 years after they were stolen.

## US-UK trade truce means cheaper whisky for Americans
 - [https://www.cnn.com/2021/03/04/intl_business/us-uk-trade-truce/index.html](https://www.cnn.com/2021/03/04/intl_business/us-uk-trade-truce/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 16:59:22+00:00

The United States has agreed to suspend tariffs on UK products including Scotch whisky and cashmere as both sides work to resolve a long-running dispute over Boeing and Airbus subsidies.

## More screen time is linked to binge eating in children, US study finds
 - [https://www.cnn.com/2021/03/04/us/screen-time-binge-eating-preteen-wellness-trnd/index.html](https://www.cnn.com/2021/03/04/us/screen-time-binge-eating-preteen-wellness-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 16:49:31+00:00

The ills of excessive screen time have been well-documented, but a recent study just identified another possible risk.

## Republicans' new strategy? Pointless obstruction
 - [https://www.cnn.com/2021/03/04/politics/marjorie-taylor-greene-ron-johnson-tom-cotton/index.html](https://www.cnn.com/2021/03/04/politics/marjorie-taylor-greene-ron-johnson-tom-cotton/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 16:30:58+00:00

Georgia freshman Republican Rep. Marjorie Taylor Greene isn't on any congressional committees. She was stripped of serving on them last month after a series of anti-Semitic and Islamaphobic comments she made prior to her time in Congress came out.

## The spiciest foods on Amazon that reviewers are obsessed with
 - [https://www.cnn.com/2021/03/04/cnn-underscored/spicy-food-amazon/index.html](https://www.cnn.com/2021/03/04/cnn-underscored/spicy-food-amazon/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 16:05:26+00:00

There are two types of people when it comes to spicy food: those who can't handle their spice, and those who can't help but add spice to almost everything. And if you fall into that latter group, you've come to the right place. Because we've scoured Amazon for the top-rated spicy snacks, sauces and seasonings so you can really add spice to basically every part of your diet.

## What to watch: The movies and TV shows we're most excited about
 - [https://www.cnn.com/style/article/cnn-film-school-hot-list-spc-intl/index.html](https://www.cnn.com/style/article/cnn-film-school-hot-list-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 14:36:35+00:00

What to watch is a question that has never been more difficult to answer -- even if a lot of us have never had more spare time on our hands.

## With no successor in sight, China's Xi Jinping has more power than ever
 - [https://www.cnn.com/collections/intl-hong-kong-0304/](https://www.cnn.com/collections/intl-hong-kong-0304/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 14:10:09+00:00



## Watch SpaceX Mars prototype rocket nail landing, explode on pad
 - [https://www.cnn.com/videos/business/2021/03/04/spacex-landing-explosion-prototype-starship-sn10-test-flight-eg-sc-orig.cnn](https://www.cnn.com/videos/business/2021/03/04/spacex-landing-explosion-prototype-starship-sn10-test-flight-eg-sc-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 13:54:18+00:00

SpaceX's Starship prototype, the SN10, successfully landed for the first time during a test flight. Minutes later the rocket exploded on its landing pad.

## Meghan accuses palace of 'perpetuating falsehoods'
 - [https://www.cnn.com/collections/intl-meghan-0304/](https://www.cnn.com/collections/intl-meghan-0304/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 13:44:29+00:00



## Bash: This is why key Republican senator is fighting Biden's stimulus
 - [https://www.cnn.com/videos/politics/2021/03/04/ron-johnson-republican-opposition-to-biden-stimulus-relief-plan-dana-bash-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/03/04/ron-johnson-republican-opposition-to-biden-stimulus-relief-plan-dana-bash-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 13:09:22+00:00

CNN's Dana Bash says that Sen. Ron Johnson (R-WI) is doing everything in his power to delay President Joe Biden's Covid-19 stimulus relief bill because Johnson believes that fighting Biden's agenda will help get him reelected.

## Trump election fraud investigation in Georgia enters new phase
 - [https://www.cnn.com/2021/03/04/politics/trump-georgia-grand-jury/index.html](https://www.cnn.com/2021/03/04/politics/trump-georgia-grand-jury/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 12:29:42+00:00

A criminal investigation into former President Donald Trump's attempts to overturn the 2020 election results in Georgia is set to intensify this week, as a grand jury convenes, offering the local district attorney her first shot at seeking subpoenas for records and interviews.

## Hong Kong no longer the poster child for economic freedom
 - [https://www.cnn.com/2021/03/04/business/hong-kong-economy-freedom-intl-hnk/index.html](https://www.cnn.com/2021/03/04/business/hong-kong-economy-freedom-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 12:27:34+00:00

Hong Kong has been booted off an index of economic freedom that it used to lead, dealing another blow to the city's standing as a global business hub.

## Britain's Prince Philip undergoes procedure for heart condition
 - [https://www.cnn.com/2021/03/04/uk/prince-philip-hospital-heart-procedure-gbr-intl/index.html](https://www.cnn.com/2021/03/04/uk/prince-philip-hospital-heart-procedure-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 12:07:29+00:00

Prince Philip, the 99-year-old husband of Queen Elizabeth II, underwent a medical procedure for a heart condition on Wednesday, Buckingham Palace said in a statement Thursday.

## Barcelona given some respite from off-field issues with stunning comeback to reach Copa del Rey final
 - [https://www.cnn.com/2021/03/04/football/barcelona-comeback-sevilla-copa-del-rey-st-intl/index.html](https://www.cnn.com/2021/03/04/football/barcelona-comeback-sevilla-copa-del-rey-st-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 11:03:42+00:00

Barcelona fans were given some respite from the club's off-the-field troubles as Lionel Messi and Co. mounted a stunning comeback to beat Sevilla and advance to the Copa del Rey final.

## Katie Ledecky wins by 21 seconds in her first race for a year
 - [https://www.cnn.com/2021/03/04/sport/katie-ledecky-tyr-pro-swim-series-spt-intl/index.html](https://www.cnn.com/2021/03/04/sport/katie-ledecky-tyr-pro-swim-series-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 10:12:43+00:00

Five-time Olympic gold medalist Katie Ledecky secured an emphatic victory in her first race since March 2020 on Wednesday, winning the 1500-meter freestyle by 21.37 seconds at the TYR Pro Swim Series in San Antonio, Texas.

## Germany's far-right AfD becomes first party to be put under government surveillance since Nazi era
 - [https://www.cnn.com/2021/03/04/europe/germany-afd-party-surveillance-intl-grm/index.html](https://www.cnn.com/2021/03/04/europe/germany-afd-party-surveillance-intl-grm/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 10:09:09+00:00

Germany's BfV domestic intelligence service has formally placed the far-right Alternative for Germany (AfD) under surveillance on suspicion of trying to undermine Germany's democratic constitution, a person briefed on the move said on Wednesday.

## Toko Shinoda, a leading figure in contemporary Japanese art, dies age 107
 - [https://www.cnn.com/style/article/toko-shinoda-artist-death/index.html](https://www.cnn.com/style/article/toko-shinoda-artist-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 09:19:51+00:00

Celebrated artist Toko Shinoda, who combined Abstract Expressionism with the traditions of Japanese calligraphy, has died at the age of 107.

## A dramatic rescue saves more than 30 crew members from a sinking ship off Nova Scotia
 - [https://www.cnn.com/2021/03/04/us/ship-rescue-nova-scotia-coast-guard/index.html](https://www.cnn.com/2021/03/04/us/ship-rescue-nova-scotia-coast-guard/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 08:33:01+00:00

More than 30 crew members were rescued via helicopters and naval vessels after a fire erupted on their ship roughly 130 miles from the Canadian coastline, according to a statement from the US Coast Guard.

## Explosive clip from Duchess of Sussex interview with Oprah
 - [https://www.cnn.com/videos/world/2021/03/04/meghan-oprah-interview-preview-nr-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/03/04/meghan-oprah-interview-preview-nr-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 07:59:24+00:00

CBS has released a further teaser ahead of Oprah's highly anticipated interview with the Duke and Duchess of Sussex.

## Video shows dramatic escalation of violence in Myanmar
 - [https://www.cnn.com/videos/world/2021/03/04/myanmar-protest-update-march-4-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/03/04/myanmar-protest-update-march-4-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 07:36:46+00:00

Myanmar saw a dramatic escalation in violence against protesters as at least 38 people were killed when Myanmar's security forces opened fire on peaceful protesters in towns and cities across the country. CNN's Paula Hancocks reports.

## South Korea's first transgender soldier found dead
 - [https://www.cnn.com/2021/03/03/asia/south-korea-transgender-soldier-death-intl-hnk/index.html](https://www.cnn.com/2021/03/03/asia/south-korea-transgender-soldier-death-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 04:30:42+00:00

South Korea's first transgender soldier, who was discharged from the military last year for having gender reassignment surgery, was found dead in her home on Wednesday, authorities said.

## Lost portrait by one of India's most famous female artists resurfaces after 90 years
 - [https://www.cnn.com/style/article/amrita-sher-gil-auction/index.html](https://www.cnn.com/style/article/amrita-sher-gil-auction/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 04:30:17+00:00

A long-forgotten painting by Amrita Sher-Gil, one of India's most important modern artists, is going under the hammer for the first time.

## 38 people killed in Myanmar's deadliest day of protest, says UN envoy
 - [https://www.cnn.com/2021/03/03/asia/myanmar-protest-deaths-intl/index.html](https://www.cnn.com/2021/03/03/asia/myanmar-protest-deaths-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 03:46:35+00:00

At least 38 people were killed at pro-democracy protests in Myanmar on Wednesday, the UN's Special Envoy to the country told a briefing Wednesday, in the deadliest day of violence since a military coup on February 1.

## SpaceX Mars prototype rocket nails landing for the first time, but explodes on pad
 - [https://www.cnn.com/2021/03/03/tech/spacex-starship-sn10-test-flight-scn/index.html](https://www.cnn.com/2021/03/03/tech/spacex-starship-sn10-test-flight-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 03:31:47+00:00

A SpaceX rocket prototype, known as SN10, soared over South Texas during test flight Wednesday before swooping down to a pinpoint landing near its launch site. Approximately three minutes after landing, however, multiple independent video feeds showed the rocket exploding on its landing pad.

## Women in sports don't get the media coverage that men do. These 4 Olympians are trying to change that
 - [https://www.cnn.com/2021/03/03/business/togethxr-womens-sports-trnd/index.html](https://www.cnn.com/2021/03/03/business/togethxr-womens-sports-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 03:24:44+00:00

US Olympians Sue Bird, Alex Morgan, Simone Manuel and Chloe Kim have teamed up to launch a new company aimed at focusing attention on women in sports and the media.

## Buckingham Palace to investigate Meghan bullying allegations ahead of Oprah interview
 - [https://www.cnn.com/2021/03/03/uk/meghan-harry-bullying-allegations-smear-gbr-intl/index.html](https://www.cnn.com/2021/03/03/uk/meghan-harry-bullying-allegations-smear-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 03:09:09+00:00

Buckingham Palace said Wednesday it would investigate allegations that Meghan, the Duchess of Sussex, bullied several staff members after a British media report cited unnamed royal aides saying a complaint had been made against her in 2018.

## Tennessee task force recovers 150 missing children
 - [https://www.cnn.com/2021/03/03/us/tennessee-missing-children-recovery-operation/index.html](https://www.cnn.com/2021/03/03/us/tennessee-missing-children-recovery-operation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 02:35:28+00:00

A total of 150 missing children ranging in age from 3 to 17 were recovered in January and February during a joint law enforcement operation, authorities in Tennessee said Wednesday.

## Trump CPAC statue said to be from Mexico actually from China
 - [https://www.cnn.com/videos/politics/2021/03/04/trump-gold-statue-china-cpac-sot-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2021/03/04/trump-gold-statue-china-cpac-sot-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 01:31:46+00:00

The golden statue of former President Donald Trump unveiled at CPAC and celebrated by supporters originally came from China, not Mexico as the artist initially said.

## Biden criticizes Texas and Mississippi's 'neanderthal thinking'
 - [https://www.cnn.com/2021/03/03/politics/biden-abbott-texas-coronavirus/index.html](https://www.cnn.com/2021/03/03/politics/biden-abbott-texas-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 01:11:19+00:00

President Joe Biden sharply criticized states such as Texas and Mississippi for lifting Covid-19 restrictions against pleas from the US Centers for Disease Control and Prevention and other top public health officials, accusing those in power of "Neanderthal thinking."

## Battles that will define US elections in 2022, 2024 and beyond are already here
 - [https://www.cnn.com/2021/03/03/world/meanwhile-in-america-march-3-intl/index.html](https://www.cnn.com/2021/03/03/world/meanwhile-in-america-march-3-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-04 01:01:38+00:00

Battles that will define elections in 2022, 2024 and beyond are already here.

