# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The Great Reset: Is Billionaire 'Philanthropy' Just Tax Avoidance?
 - [https://www.youtube.com/watch?v=zw0nYNMUIfA](https://www.youtube.com/watch?v=zw0nYNMUIfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-03-05 00:00:00+00:00

At the WEF in Davos the world's wealthiest people meet annually to discuss philanthropic solutions for saving the world. But few want to talk about the issue of tax avoidance through philanthropy. 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com​/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Under The Skin podcast to hear from guests including #JonathanHaidt, #JordanPeterson, #Naomi Klein, #KehindeAndrews, #AdamCurtis and #VandanaShiva.
Get a one month free trial at http://luminary.link/russell​

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

