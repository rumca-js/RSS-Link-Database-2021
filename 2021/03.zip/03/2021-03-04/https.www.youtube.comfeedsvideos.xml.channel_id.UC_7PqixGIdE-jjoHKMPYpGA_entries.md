# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Dlaczego ten dinozaur jest taki brzydki?
 - [https://www.youtube.com/watch?v=qPVw0CR_oa8](https://www.youtube.com/watch?v=qPVw0CR_oa8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-03-05 00:00:00+00:00

👉 Zbiórka ► https://zrzutka.pl/bjrax4
👉 Patronite ► https://patronite.pl/NaukowyBelkot 

📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook

🎧 Mix audio ► http://ratstudios.pl/

Dziękujemy za współpracę: https://muzeumewolucji.pl/

Moi Drodzy - oto film. Najbardziej profesjonalny jaki zrobiliśmy. Temat może wydawać się mało pociągający, ale dajcie mu szansę. Zwłaszcza, że z czasem historia dinozaura protoceratopsa, ustępuje miejsca historii większej i dużo, dużo ważniejszej.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 Opowieść protoceratopsa
26:15 Opowieść o Muzeum
38:38 Zróbmy coś z tym

