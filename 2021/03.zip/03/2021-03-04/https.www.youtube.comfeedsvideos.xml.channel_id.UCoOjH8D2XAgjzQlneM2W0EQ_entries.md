# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## High Frequency Stock Trading is absurd
 - [https://www.youtube.com/watch?v=aMhI70KUAzw](https://www.youtube.com/watch?v=aMhI70KUAzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-03-05 00:00:00+00:00

Sign up for a free account and get 20% off Grammarly Premium: https://grammarly.com/jaketran 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

The full interview with the quantitative developer, Coding Jesus: https://youtu.be/yUNtQVL-GWM

Subscribe to Coding Jesus: http://bit.ly/3qc9acU 

The HFT movie, The Hummingbird Project (2019): https://amzn.to/3aX0qTw 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🖥️ Website platform I use: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use: https://jake.yt/benchd 
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: 

-----------------------
The Trillion Dollar Flash Crash. Greece was drowning in debt and was on the verge of defaulting on that debt, and going bankrupt. The Greek Parliament announced massively unpopular austerity measures. The Greek Parliament approved these nasty austerity measures in exchange for a $140 billion dollar bailout by the European Union and International Monetary Fund. 

There’s a ton of trading activity in the US stock market. Volatility in the stock market was so high that the New York Stock Exchange had to force trading to slow down. A stock trader grew sick of these high frequency trading firms that have grown to dominate the market over the years. Navinder Sarao decided this would be the day he would go up against them head on and he started “spoofing” the market. He flooded the market with a bunch of sell orders, to trigger those algorithms from the high frequency trading firms causing them to sell, their selling would trigger more selling from other firms, crashing the market. 

Bloomberg releases this alert. Good news - if you saw that and you thought, hmm, I should buy some HP stock bc it’s probably gonna go up. You’d be correct - but you’d be too late bc this is what happened in the next four seconds of the alert going out. The HFT algorithms do what’s called Sentiment Analysis. You can bet that HFT firms are doing this right now in places like Wall Street Bets and Stocktwits

Let’s say you want to buy GameStop at $10 to keep things simple. However, if I’m a HFT and I want to make money off of your order, all I have to do is get your order before all the other sellers see it. I know you’re looking to buy at $10, so I go to the other sellers who haven’t seen that there’s another buyer at $10 bc I’m faster than you, and I buy from them at $9.99, a cheaper price, and then come back to you and sell it for $10. Imagine the profits bigger firms are raking in.

-----------------------

No Spirit - Forest Lake Walk https://chll.to/49da79e5 
No Spirit - Slightly Improvised https://chll.to/6347930b 

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

#Grammarly

