# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Terminator Genisys - From Failure to Farce
 - [https://www.youtube.com/watch?v=XIn_kj52-P0](https://www.youtube.com/watch?v=XIn_kj52-P0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-03-05 00:00:00+00:00

Terminator Genisys may be the worst movie in the entire franchise. Let's find out how it all went so wrong.

