# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Assedic // Les Escrocs // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=klIwRQ8kxvU](https://www.youtube.com/watch?v=klIwRQ8kxvU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-03-04 00:00:00+00:00

Here's our cover of Assedic, a French love song "of sorts"...we included the translation because the lyrics are pretty hysterical.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music: http://www.patreon.com/pomplamoose

A cover of Assedic by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Accordion/Rhodes: Jack Conte
Piano: Ross Garren
Nylon String Guitar: John Schroeder & Erik Miron
Upright Bass: Eliana Athayde
Drums: Ben Rose
Background Vocals: Sarah Dugas & Annick Brémault
Percussion: Roland Gajate Garcia
Clarinet & Reedless Clarinet: John Tegmeyer

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Branko Presley
Mixing/Mastering: Caleb Parker
Producer: John Schroeder

VIDEO CREDITS
Director: George Sloan
DP: Ricky Chavez
Camera Operators: Merlin Showalter, Sammy Rothman, Dijon Herron, Charlene Gibbs
Art Design: George Sloan, Susannah Honey
Video Editor: Athena Wheaton

Recorded at The Village in Los Angeles.

#Pomplamoose #FrenchJazz #LesEscrocs #Assedic

LYRICS (French - English)

J'en avais marre de travailler - I was sick of working
Et de perdre mon temps - And wasting my time
À faire des boulots mal payés - Doing underpaid jobs
Avec des gens très emmerdants - With very annoying people
Je cherchais la combine - I was looking for a scheme
Et c'est pas facile - And it's not an easy thing
De se tirer de l'usine - To get away from the factory
Pour partir dans les îles - And head for the islands
Je me creusais le ciboulot - I was wracking my brain
J'étais comme tous les gens - I was like everyone
Allergique au boulot - Allergic to work
Mais pas allergique à l'argent - But not allergic to money
Je n'connais qu'une façon - There's only one way I know
De se tirer sous les tropiques - Of escaping to the tropics
Quand on est petit, laid - When one is small, ugly
Et qu'on a pas de fric - And has no cash

ASSEDIC*
Je t'écrirai de temps en temps - I'll write to you from time to time
Toi tu m'enverras mon virement - And you'll wire my cash
Directement - On time
Tout là-bas, dans mon île - Way out there, on my island
ASSEDIC
Avec ton amie RMI - With your friend RMI**
Vous s'rez mes deux meilleurs amies - You'll be my two best friends
Ce s'ra dément - It's going to be insane

L'Agence Nationale Pour l'Emploi - The Agence Nationale Pour l'Emploi***
M'écrit de France - Writes to me from France
Ils veulent à peine au bout d'un mois - It's only been a month and they're
Me gâcher mes jolies vacances - Already messing with my lovely holiday
En m'envoyant chez "Prisunic" - They want to send me to "Prisunic"****
Décharger des camions - To unload their trucks
Avec ma copine ASSEDIC - My girl, ASSEDIC and I
Évidemment on a dit non - Obviously had to decline
J'veux qu'ça dure toute la vie - I want this to last forever
Que chaque jour soit férié - For every day to be a holiday
Un jour, je r'cevrai l'avis de fin de droit - Someday I'll get a benefit termination notice
Dans mon courrier - In the mail
Mais faudra me payer cher - but they'll have to pay me a fortune
Pour retourner au carnaval - To get me back into the circus
Du R.E.R. - Of the R.E.R.*****
Et du Leclerc de Bougival - And the Leclerc de Bougival******

ASSEDIC
Je t'écrirai de temps en temps - I'll write to you from time to time
Toi tu m'enverras mon virement - And you'll wire my cash
Directement - On time, please
Tout là-bas, dans mon île - Way out there, on my island
ASSEDIC
Enfin ma place au soleil - At least my place in the sun
À moi les ciels vermeils - All mine these vermillion skies
Et les beaux voyages - And the lovely trips
M'en priver ce s'rait dommage - Doing without would be a shame
ASSEDIC
Tu s'ras ma petite maman - You’ll be my little mama 
La maman de tous les gens - The mother of all those people
Qui n'ont pas d'argent - Who don’t have money
Enfin pas assez, quoi… - Well, not enough anyway…

*ASSEDIC is an acronym for Association pour l’emploi dans l’industrie et le commerce or the Association for Employment in Industry and Trade. It was a French agency that collected and paid unemployment insurance contributions.

**RMI is an acronym for Revenu minimum d’insertion, a type of social welfare that was aimed at people without any income, who were of working age and had no other employment benefits. 

***L’Agence nationale pour l’emploi or National Employment Agency was the French agency tasked with providing counseling and aid to those in search of employment and training.

****PRISUNIC was a large French retail chain that merged with Monoprix in 1997. Its last stores closed in 2003.

*****R.E.R. is an acronym for the Réseau express régional or Regional Express Network. It is a hybrid commuter rail and rapid transit system serving Paris and its suburbs.

******Leclerc or E.Leclerc officially, is a French hypermarket chain. The song refers to an E.Leclerc store located in Bougival, a small town 10 miles from the center of Paris.

