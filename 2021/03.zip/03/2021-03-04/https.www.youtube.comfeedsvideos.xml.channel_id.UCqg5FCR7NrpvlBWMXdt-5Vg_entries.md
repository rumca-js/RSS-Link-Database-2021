# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Katamari Damacy Delivers Therapy Through Destruction | Snapshot
 - [https://www.youtube.com/watch?v=1K6jOzKVL1w](https://www.youtube.com/watch?v=1K6jOzKVL1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-03-05 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

There are a lot of games about the act of creation. From slowly building up your island in Animal Crossing: New Horizons, to leveling up your Phantom Thieves in Persona 5, to Media Molecule’s Dreams, which is pretty much a video game that gives you all the tools needed to make your own video game. And of course, the opposite is true. There are plenty of games centered around the act of destruction. Bringing down a building in Battlefield 4, using your psychic powers to tear apart the Oldest House in Control, and hell, even clearing a Tetris board feels a bit destructive.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Loop Hero | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=7nB-J0E3Ikk](https://www.youtube.com/watch?v=7nB-J0E3Ikk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-03-05 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Amy Campbell reviews Loop Hero, developed by Four Quarters.

Loop Hero on Steam: https://store.steampowered.com/app/1282730/Loop_Hero/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

