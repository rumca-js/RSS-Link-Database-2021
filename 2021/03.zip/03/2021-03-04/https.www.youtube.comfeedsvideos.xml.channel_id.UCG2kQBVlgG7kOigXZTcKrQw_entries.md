# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## ŻUBRY. Jak wielkie są stada żubrów w Polsce?! 🐂 Znalazłem je za pomocą aplikacji!
 - [https://www.youtube.com/watch?v=tBEIOI5aztM](https://www.youtube.com/watch?v=tBEIOI5aztM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-03-04 00:00:00+00:00

Żubra chciałem zobaczyć już od baaaardzo dawna. Natomiast blisko 3 lata temu pojawił się w mojej głowie pomysł odwiedzenia Podlasia zimą celem poszukania żubrów i nagrania filmu z ciekawostkami dotyczącymi żubrów. Jako, że najlepszym okresem do obserwacji dziko żyjących żubrów jest zima, to też ciężko było mi się zebrać w sobie i pojechać na Podlasie w tym okresie. Sami rozumiecie - nie mam sań i reniferów żeby na Podlasie dojechać (eh te podlaskie żarciki :D). No ale przez deficyt podróży ostatnimi czasy w końcu się zmobilizowałem (było łatwiej po zrobieniu prawka :D ) no i pojechałem hen na daleką północ celem znalezienia Żubrów. Ale tych dzikich żubrów oczywiście! Żadne tam zagrody mnie nie interesują. No i po 2 tygodniach poszukiwań powstał taki oto właśnie film.

Mam nadzieję, że Wam się spodoba. Sporo poświęciłem na poszukiwanie informacji i ciekawostek o żubrach. Jeszcze więcej na znalezienie lokalizacji, gdzie można je namierzyć, gdzie żubry lubią przebywać, gdzie się je dokarmia i gdzie bywają najczęściej. Prawdę mówiąc 25% obszarów, gdzie żubry miały się znajdować, się potwierdziło, także jestem naprawdę bardzo zadowolony. Ale więcej już w samym filmie o żubrach. Zapraszam!

Zapis na listę kursową ►► https://bit.ly/3s9ctCQ 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Muzyka: Artlist oraz utwory Nevaeh

Szczególne podziękowania dla:
Jakuba Rybickiego

Piotra Kowalczuka za pomoc logistyczną i pomoc w szukaniu stada żubrów. Marcina Siekierko za udostępnienie ujęć dronowych z dużym stadem żubrów chodzących po Polach we wsi Kotówka k/Hajnówki . 
Strona Marcina: https://www.facebook.com/droneimagepl/

Spis treści
00:00 - 01:47 - Żubry w Polsce
01:48 - 02:29 Ile jest Żubrów w Polsce?
02:30 - 03:53 Puszcza Białowieska
03:54 - 04:21 Kiedy można spotkać żubra?
04:22 - 06:23 Historia Żubrów
06:24 - 07:02 Żubrówka
07:03 - 08:41 Ślady żubrów
08:42 - 11:41 Puszcza Augustowska
11:42 - 12:34 Dlaczego dokarmia się Żubry 
12:35 - 15:47 Jak liczy się Żubry?
15:48 - 16:16 Puszcza Knyszyńska
16:17 - 17:18 Czy żubry atakują ludzi?
17:19 - Dziko żyjące żubry

