# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## 1 Year of Coronavirus -- What Now?
 - [https://www.youtube.com/watch?v=pZMKZxY1NPU](https://www.youtube.com/watch?v=pZMKZxY1NPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-05 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1615 with Hamilton Morris. https://open.spotify.com/episode/2sv8XJd7hekqx3EOVDmdex?si=4b596cc551094b7c

## Baker Mayfield's Reported UFO Sighting
 - [https://www.youtube.com/watch?v=g2AyNRVWOxE](https://www.youtube.com/watch?v=g2AyNRVWOxE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-05 00:00:00+00:00

This clip is taken from the JRE MMA Show #104 with Cory Sandhagen. https://open.spotify.com/episode/6VHlRfaIUHhSQYRHUa3XV1?si=50f58f032b97454c

## Corey Sandhagen's Spectacular Flying Knee KO Over Frankie Edgar
 - [https://www.youtube.com/watch?v=Ki4_v9mwD7w](https://www.youtube.com/watch?v=Ki4_v9mwD7w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-05 00:00:00+00:00

This clip is taken from the JRE MMA Show #104 with Cory Sandhagen. https://open.spotify.com/episode/6VHlRfaIUHhSQYRHUa3XV1?si=50f58f032b97454c

## Dr. Carl Hart & The Argument for the Legalization of Drugs
 - [https://www.youtube.com/watch?v=ih3H3Fz0X_k](https://www.youtube.com/watch?v=ih3H3Fz0X_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-05 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1615 with Hamilton Morris. https://open.spotify.com/episode/2sv8XJd7hekqx3EOVDmdex?si=4b596cc551094b7c

## Joe Talks About "Knees Over Toes Guy"
 - [https://www.youtube.com/watch?v=VxksG15OgRY](https://www.youtube.com/watch?v=VxksG15OgRY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-05 00:00:00+00:00

This clip is taken from the JRE MMA Show #104 with Cory Sandhagen. https://open.spotify.com/episode/6VHlRfaIUHhSQYRHUa3XV1?si=50f58f032b97454c

## Toad Venom and DMT
 - [https://www.youtube.com/watch?v=nvcXs0RXWJo](https://www.youtube.com/watch?v=nvcXs0RXWJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-05 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1615 with Hamilton Morris. https://open.spotify.com/episode/2sv8XJd7hekqx3EOVDmdex?si=4b596cc551094b7c

