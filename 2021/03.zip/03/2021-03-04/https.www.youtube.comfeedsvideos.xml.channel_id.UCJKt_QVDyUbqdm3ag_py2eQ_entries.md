# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does IT: Basehead - Dreamland Level (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=XjEYbgCW_F4](https://www.youtube.com/watch?v=XjEYbgCW_F4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-04 00:00:00+00:00

"Dreamland Level" by Basehead (Dan Gardopée). This was intended for Jazz Jackrabbit 2, but was left unused.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 29 channels
- 100% flawless playback not guaranteed (the IT replayer is not perfect)

Visit my channel for more Amiga music.

