# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## You can buy Intel's Unreleased CPU RIGHT NOW - WAN Show March 5, 2021
 - [https://www.youtube.com/watch?v=5A-gkT2uOeM](https://www.youtube.com/watch?v=5A-gkT2uOeM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-05 00:00:00+00:00

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Save 10% at Ridge Wallet with offer code WAN at https://www.ridge.com/WAN

Start your build today at https://www.buildredux.com/linus

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/You-can-buy-Intels-Unreleased-CPU-RIGHT-NOW---WAN-Show-March-5--2021-es0d9v

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of MMAPSFAWNMR)
00:00:09 ----- Synopsis of Topics (AnandTechs 11700K review, Verified Actual Gamer Program, Google is a privacy company now, Arizona House Bill).
00:01:45 ----- Intro.
00:02:17 ----- Luke feels robbed and asks Linus where the new WAN Show intro is.
00:02:40 ----- How AnandTech published their full review of the Intel Core i7-11700K nearly two weeks early and how NDAs work.
00:03:14 ----- Quick sponsor announcement: Redux, Ridge Wallet, and Square Space.
00:15:03 ----- Tech specs of the Intel Core i7-11700K.
00:23:32 ----- Nvidia is working with GPU miners. The 3060 ATH mining limiter rumored to be on the 3080 Ti as well.
00:32:26 ----- Big Reveal: Sometime next week, Linus Media Group will be launching the Verified Actual Gamer Program (not a giveaway).
00:44:59 ----- Sponsor spot: Redux.
00:45:54 ----- Sponsor spot: Ridge Wallet.
00:46:32 ----- Sponsor spot: Square Space.
00:48:53 ----- Questions about the Verified Actual Gamer Program.
00:49:40 ----- Google is now a privacy company.
00:55:01 ----- LTT Store new shirt.
00:56:53 ----- AMDs 6700XT paper launcher.
01:00:02 ----- 8-year-old Fortnite pro (Joseph Dean).
01:02:19 ----- LTT Store desk pad update.
01:02:51 ----- Arizona House Bill that would require an allowance for third party payment on app platforms.
01:09:58 ----- Super Chats.

## These are TOTALLY Different - Let me Explain. (U.3 Storage Comparison)
 - [https://www.youtube.com/watch?v=uCXcqV31iZ8](https://www.youtube.com/watch?v=uCXcqV31iZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-04 00:00:00+00:00

Thanks to KIOXIA for sponsoring today's video! Check out their U.3 CM6 Enterprise SSD drives at https://lmg.gg/X9myK

U.3 is an interface that combines the power of NVMe, SAS, and SATA drives into one controller, but how does that work?

Check out Broadcom's GBA 9500-16i Tri-Mode Storage Adapter at https://lmg.gg/2zSY2
Check out the Super Micro Server A+ Server 1124US-TNRP at https://lmg.gg/YVzPP

Buy AMD Epyc 7702 Processor On Amazon (PAID LINK): https://geni.us/a0tN2di

Buy Toshiba HDD
On Amazon (PAID LINK): https://geni.us/uvrpdBS   
On NewEgg (PAID LINK): https://geni.us/UIoiKP7 

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1312068-these-are-totally-different-let-me-explain-sponsored/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

