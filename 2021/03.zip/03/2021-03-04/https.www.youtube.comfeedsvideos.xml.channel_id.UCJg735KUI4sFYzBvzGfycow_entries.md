## J. S. Bach - Partita in C moll BWV 997 -  Evangelina Mascardi, Liuto barocco
 - [https://www.youtube.com/watch?v=1JYjcwW9MmM](https://www.youtube.com/watch?v=1JYjcwW9MmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJg735KUI4sFYzBvzGfycow
 - date published: 2021-03-05 00:00:00+00:00

J. S. Bach - Partita in C moll BWV 997 -  Evangelina Mascardi, Liuto barocco
Prelude            0:00
Fuga                 3:46
Sarabande    11:55
Gigue             16:57
Double           20:13
Registrato a Mondovì (Cuneo) il 26 febbraio 2021 nella sede dell'Academia Montis Regalis da Edoardo Lambertenghi e Alma Zeccara
Liuto costruito da Cezar Mateus (New Jersey 2007)

