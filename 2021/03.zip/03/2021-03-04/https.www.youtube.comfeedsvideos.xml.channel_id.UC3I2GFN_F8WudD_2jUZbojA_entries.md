# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Y La Bamba - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=XY5qVuLvyhU](https://www.youtube.com/watch?v=XY5qVuLvyhU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-05 00:00:00+00:00

http://KEXP.ORG presents Y La Bamba performing live, recorded exclusively for KEXP.

Songs:
Bruja de Brujas
Perder
Boca Llena
Rios Sueltos

Music:
Luz Elena Mendoza - Vocals, Songwriting, Composition
Isabeau Waia'u Walker - Vocals
Ryan Oxford - Guitar, Backing Vocals
Zack Teran - Bass, Backing Vocals
Miguel Jiménez-Crùz - Drums, Backing Vocals
and of course Primo

Recorded and mixed at The Center for Sound, Light, and Color by Ryan Oxford
Video Director/DP/Editor - Madison Rowley
Additional Camera & Lighting - Rodrigo Melgarejo 
Visual FX created on ATARI VIDEO MUSIC

http://www.ylabamba.com
http://kexp.org

