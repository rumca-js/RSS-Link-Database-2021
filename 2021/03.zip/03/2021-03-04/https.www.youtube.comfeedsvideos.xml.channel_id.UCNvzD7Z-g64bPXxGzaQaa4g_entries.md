# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## PS5 + SERIES X GETTING BIG AMD GRAPHICS UPDATE, SWITCH PRO NEW LEAKS & MORE
 - [https://www.youtube.com/watch?v=Fo2F4elJWi4](https://www.youtube.com/watch?v=Fo2F4elJWi4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-05 00:00:00+00:00

Brought to you by Raycon. Go to http://buyraycon.com/gameranx for 15% off your order!

Some new developments for AMD graphics and PC cards could benefit Xbox and PS5, exciting new game trailers, and a Nintendo Switch Pro rumor round out a week full of gaming news.
Subscribe for more: https://www.youtube.com/gameranxTV?su...​...


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​


 ~~~~STORIES~~~~


AMD ADDING NEW TECH TO PS5 & SERIES X
https://mp1st.com/news/amds-equivalent-to-dlss-fidelityfx-super-resolution-is-coming-to-ps5-xbox-series-consoles

Switch Pro rumors
https://www.bloomberg.com/news/articles/2021-03-04/nintendo-plans-switch-model-with-bigger-samsung-oled-display

Elden Ring leak
https://www.videogameschronicle.com/news/a-leaked-elden-ring-trailer-is-being-circulated-online/
Link to the leaked trailer: https://youtu.be/UZ8kk0I3tkU

God of War update
https://www.pushsquare.com/news/2021/02/god_of_war_ragnarok_will_release_when_its_done_on_ps5



Xbox/Bethesda official
https://gameworldobserver.com/2021/03/05/microsoft-zenimax-deal-approved-us-securities-exchange-commission/


Artifact RIP
https://kotaku.com/valves-card-game-is-officially-dead-1846410290

Aliens: Fireteam
https://www.youtube.com/watch?v=e6B98KAIyF8
More gameplay: https://www.youtube.com/watch?v=RZco0Da52K0

DOOM 3 VR
https://www.youtube.com/watch?v=BkxxgsgrVe0
(Also PSVR patent)

https://www.polygon.com/2021/3/1/22307226/battlefield-6-release-date-need-for-speed-2021-delayed-ea-dice-criterion-codemasters

Ghost of Tsushima happy ending
https://www.videogameschronicle.com/news/ghost-of-tsushima-devs-to-be-made-permanent-ambassadors-of-the-real-island/

## 10 BIGGEST Game Worlds of the Last 3 Years [4K]
 - [https://www.youtube.com/watch?v=vbJE_XPcZKg](https://www.youtube.com/watch?v=vbJE_XPcZKg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-04 00:00:00+00:00

Video game open worlds are getting bigger and bigger. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

