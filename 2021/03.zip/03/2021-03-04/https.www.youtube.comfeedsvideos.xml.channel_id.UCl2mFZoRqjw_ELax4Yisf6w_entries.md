# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## The sad reality of what it takes to pass right to repair 😢
 - [https://www.youtube.com/watch?v=U8wBKfaZ1jw](https://www.youtube.com/watch?v=U8wBKfaZ1jw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-03-05 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Here is the followup to this video: https://www.youtube.com/watch?v=umqM01cMWZg

## A word on principles, tshirts, and being the asshole
 - [https://www.youtube.com/watch?v=0_K90lm-8yA](https://www.youtube.com/watch?v=0_K90lm-8yA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-03-04 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 This video was recorded with the following:
🔵 Duck: https://amzn.to/30aUCQ5
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

