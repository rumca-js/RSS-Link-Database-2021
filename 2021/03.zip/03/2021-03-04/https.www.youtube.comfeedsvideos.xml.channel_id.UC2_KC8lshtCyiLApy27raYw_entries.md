# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## The Recording Industry Is Evil
 - [https://www.youtube.com/watch?v=MB92J70Bmv8](https://www.youtube.com/watch?v=MB92J70Bmv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-03-05 00:00:00+00:00

Today I discuss a corporations doing bad things and Metallica doing Metallica things.

I might be a few decades late on this vid.

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

Additional Footage Credits:

FUSE
Sound On Sound magazine
Mark Mathosian
Gus Johnson
Techmoan
mjanovec
NakeyJakey
MadGamer
guitarheroROXS
RocketJump
RocketJump
Yoshimitsu4prez
ParallaxDG
Old Wide Web

