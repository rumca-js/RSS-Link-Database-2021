# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Instagram Models Be Like:
 - [https://www.youtube.com/watch?v=HdL0AeNqpRY](https://www.youtube.com/watch?v=HdL0AeNqpRY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-03-04 00:00:00+00:00

These IG gurls, insta models, influencers- whatever you want to call them- are a special breed...The first 1000 people to use this link will get a free trial of Skillshare Premium Membership: https://skl.sh/julienolke03211

Written by: Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay

Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke

