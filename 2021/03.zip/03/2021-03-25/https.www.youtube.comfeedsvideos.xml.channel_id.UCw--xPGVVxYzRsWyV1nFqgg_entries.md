# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## How To Find Success In Self Publishing
 - [https://www.youtube.com/watch?v=voAJSSW5tS4](https://www.youtube.com/watch?v=voAJSSW5tS4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-03-26 00:00:00+00:00

Evan Winter talks about his experience finding success in self-publishing his smash hit, The Rage of Dragons and Fires of Vengence! 
Rage Of Dragons: https://amzn.to/2Pl7Asq
Fires of Vengeance: https://amzn.to/2OUKCbT 

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

Interview: 

00:00 Intro

00:54 Time magazine

02:37 Self Pub First Steps 

06:04 Success in precision 

07:48 Early Sales Importance

11:14 First 100 Days of Ads

15:09 Budget 

17:14 Best investments 

21:57 Biggest Mistake 

23:13 Sweat Equity 

24:26 Start with novella

27:56 Genre

## MAGIC IS OUTDATED Pt. 2
 - [https://www.youtube.com/watch?v=-2xqfFBJVJ0](https://www.youtube.com/watch?v=-2xqfFBJVJ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-03-25 00:00:00+00:00

Social media beats out magic. Check out the new skit n stuff. Idk what am I supposed to use for the description? Magic, dark lords, goblins, fantasy.

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1

