# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Nick Lowe – three live songs (2019)
 - [https://www.youtube.com/watch?v=46oKekt__5Q](https://www.youtube.com/watch?v=46oKekt__5Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-03-25 00:00:00+00:00

Happy birthday to Nick Lowe, born March 24 in Walton-on-Thames, Surrey, England. To celebrate Lowe's birthday, here are three performances from his Sept. 13, 2019, concert at First Avenue in Minneapolis, recorded live by The Current. Nick Lowe appears with his trusty backing band, the mysterious and brilliant Los Straitjackets.

SONGS PERFORMED
0:00 "Half a Boy and Half a Man"
3:12 "Cruel to Be Kind"
7:31 "I Knew the Bride (When She Used to Rock 'n' Roll)" 

PERSONNEL
Nick Lowe – guitar, vocals
Los Straitjackets – everything else

CREDITS
Audio: Michael DeMark
Video Director: Nate Ryan
Camera Operators: Mary Mathis, Peter Ecklund, Kiera Faye, Erik Stromstad
Production Manager: Erik Stromstad

FIND MORE:
2011 studio session: https://www.thecurrent.org/feature/2011/12/07/nicklowe-live
2014 studio session: https://www.thecurrent.org/feature/2014/12/03/nick-lowe-with-los-straitjackets-performs-in-the-current-studio
2014 Guitar Collection interview:
https://www.thecurrent.org/feature/2014/12/10/the-current-s-guitar-collection-nick-lowe
2019 full concert at First Avenue:
https://www.thecurrent.org/feature/2019/10/18/watch-nick-lowe-and-los-straitjackets-live-from-first-avenue

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#nicklowe #losstraitjackets

