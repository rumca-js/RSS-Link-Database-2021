# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Weeb on Titan
 - [https://www.youtube.com/watch?v=Hi9t1-YETlg](https://www.youtube.com/watch?v=Hi9t1-YETlg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-03-26 00:00:00+00:00

Go to https://nordvpn.com/Flashgitz or use code Flashgitz to get a 2-year plan plus 1 additional month with a huge discount.

Weeb on Titan. The greatest symbolic rewrite of Attack on Titan ever made. Flashgitz.

Patreon ►
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Additional Animation ► 
Aris Lareti
Szymon kwinto 
Dannye8a


Backgrounds ►  
Javier Navarro https://www.instagram.com/naav_draws/
Soured Apple https://www.twitter.com/SouredApple

Sound ► 
Justin Greger

Music ► 
Tom Ryan

VO ► 
Meatcanyon

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/b5ekXbK

