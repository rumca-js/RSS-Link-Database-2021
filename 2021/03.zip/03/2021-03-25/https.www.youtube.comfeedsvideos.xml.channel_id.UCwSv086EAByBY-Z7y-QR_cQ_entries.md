# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Ruszają badania kliniczne nad Amantadyną! Wiadomo, kiedy będą wyniki!
 - [https://www.youtube.com/watch?v=XyTsHHljJ-M](https://www.youtube.com/watch?v=XyTsHHljJ-M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-03-26 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3fgTgMD
2. https://bit.ly/3tTgeNR
3. https://bit.ly/31noARu
4. https://bit.ly/3crR17o
-------------------------------------------------------------
🖼Grafika - wykorzystano grafikę ze strony: 
umlub.pl - https://bit.ly/3sDknFz
-------------------------------------------------------------
💡 Tagi: #Covid19 #Amantadyna
--------------------------------------------------------------

