# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Where Did Bitcoin Come From? – The True Story
 - [https://www.youtube.com/watch?v=W15A7Lf0_fI](https://www.youtube.com/watch?v=W15A7Lf0_fI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-03-25 00:00:00+00:00

Join my Discord Community today - https://discord.gg/coldfusion - Thanks to Discord for sponsoring today’s video.

Episode 2 of the Bitcoin story: https://youtu.be/iYn6EQDqTkU

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.investopedia.com/tech/three-people-who-were-supposedly-bitcoin-founder-satoshi-nakamoto/

https://www.coindesk.com/bitcoin-financial-crisis

https://spectrum.ieee.org/computing/software/bitcoin-the-cryptoanarchists-answer-to-cash

https://www.pcmag.com/encyclopedia/term/first-virtual
http://cryptome.org/jya/digicrash.htm

https://bitcoinmagazine.com/articles/quick-history-cryptocurrencies-bbtc-bitcoin-1397682630

https://velawoodlaw.com/bitcoins-solution-to-the-double-spend-problem/

https://groups.csail.mit.edu/mac/classes/6.805/articles/money/nsamint/nsamint.htm

https://www.thebalance.com/who-sets-bitcoin-s-price-391278

https://money.usnews.com/investing/articles/the-history-of-bitcoin

//Soundtrack//

**coming soon**

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

