# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Luke DEFENDS Javascript! (On Gemini and Gopher)
 - [https://www.youtube.com/watch?v=M5qoatSAsbY](https://www.youtube.com/watch?v=M5qoatSAsbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-03-26 00:00:00+00:00

Speculative technology has to overcome networking effects. As it is right now, https is the standard and there is little hope of reversing that. If you are in favor of some minimalist alternative to the modern bloated web like the Gemini or Gopher protocols, your priority should be to make such protocols accessible from normie technology and normie browsers. Since I am a old boomer, I care little about such technologies until they are generally usable by people who are not just aficionados of obscure technology. I also talk about when it is PROPER to use Javascript and advanced client and server-side scripting on websites: only when it is actually necessary. I do think the ability of the modern web to be "bloated" with new features is a good thing, but obvious discipline is required on the part of web developers.

My website: https://lukesmith.xyz
Please donate: https://donate.lukesmith.xyz
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://brave.com/luk005 Get the Brave browser.
https://odysee.com/$/invite/@Luke:7 View my videos on Odysee and get a bonus for joining.
https://www.coinex.com/register?refer_code=ndf87 Get crypto-rich on Coinex. Get reduced exchange fees for 3 months.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

