## Kamala Harris and Bill Clinton touting girls' empowerment together is a bad joke
 - [https://www.nbcnews.com/think/opinion/kamala-harris-bill-clinton-touting-girls-empowerment-together-bad-joke-ncna1261977](https://www.nbcnews.com/think/opinion/kamala-harris-bill-clinton-touting-girls-empowerment-together-bad-joke-ncna1261977)
 - RSS feed: https://www.nbcnews.com
 - date published: 2021-03-25 19:36:06+00:00

Kamala Harris and Bill Clinton touting girls' empowerment together is a bad joke

