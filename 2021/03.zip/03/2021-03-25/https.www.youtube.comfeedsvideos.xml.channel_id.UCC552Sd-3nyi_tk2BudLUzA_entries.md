# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The Truth About Nuclear Energy
 - [https://www.youtube.com/watch?v=glM80kRWbes](https://www.youtube.com/watch?v=glM80kRWbes)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-03-25 00:00:00+00:00

Chernobyl, Fukushima, The Simpsons power plant, they all involve lies!
The first 1000 people to use this link will get a free trial of Skillshare Premium Membership: https://skl.sh/asapscience03211

Join our mailing list: https://bit.ly/34fWU27

Written by Greg Brown and Laura Roklicer
Edited by Luka Šarlija

Video References: 
InANutShell - How Many People Did Nuclear Energy Kill? Nuclear Death Toll  https://youtu.be/Jzfpyo-q-RM
Real Engineering - The Economics of Nuclear Energy https://youtu.be/UC_BCz0pzMw

References:
The Story of More by Hope Jahren
https://academic.oup.com/eurheartj/article/40/20/1590/5372326
https://ourworldindata.org/safest-sources-of-energy
https://www.nature.com/articles/497539e
https://environmentalprogress.org/big-news/2020/6/29/on-behalf-of-environmentalists-i-apologize-for-the-climate-scare
https://www.health.harvard.edu/cancer/radiation-risk-from-medical-imaging
https://www.newyorker.com/news/dispatch/is-nuclear-power-worth-the-risk
How To Avoid a Climate Disaster by Bill Gates
https://www.google.com/url?q=http://wedocs.unep.org/bitstream/handle/20.500.11822/7790/-Radiation_Effects_and_sources-2016Radiation_-_Effects_and_Sources.pdg.pdf.pdf?sequence%3D1%26isAllowed%3Dy&sa=D&source=editors&ust=1616634317411000&usg=AOvVaw3RQ_1UzwPOVYd1BEN5JEMQ
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6194698/
https://ourworldindata.org/safest-sources-of-energy
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2996147/
https://vault.sierraclub.org/nuclear/factsheet.aspx

