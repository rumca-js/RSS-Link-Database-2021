# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 List św. Piotra || Rozdział 01
 - [https://www.youtube.com/watch?v=A-a_SgFvOMg](https://www.youtube.com/watch?v=A-a_SgFvOMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-26 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Daj mi pić
 - [https://www.youtube.com/watch?v=8MyDUaE_iy0](https://www.youtube.com/watch?v=8MyDUaE_iy0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-26 00:00:00+00:00

#JanSmoczyński  @AgnieszkaMusiaYT @Langustanapalmie 

Utwór zrealizowany na potrzeby rekolekcji 
// Cztery opowieści o Jezusie //

Daj mi pić

Pusty stół
Sucha studnia 
Jestem głodna
Chce mi się pić

W żyłach płynie 
porzucenie 
słabe serce 
Przestaje bić

Chowam się 
Przed samym sobą
Życie w drodze mija mnie 
Niespełnienie goni cele
Wstyd mi, że nie daje rady 

Daj mi pić, daj mi pić 
Wodą Żywą wypełnij serce
Daj mi pić, daj mi pić
Głębią jesteś, głębia woła mnie 
Ugaś pragnienie, głębia woła mnie 

Dłużej tak już  nie wytrzymam
Czuje jak oddalam się
Od zamiarów, które miałem 
Tylko strach odwiedza mnie 

Woda żywa to lekarstwo 
Na pragnienie pustych serc 
Tylko ona mnie ukoi 
wierzę, że uzdrowi mnie 
________________________________________

muzyka: Agnieszka Musiał || Jan Smoczyński
zespół w składzie: Agnieszka Musiał || Jan Smoczyński || Kamil Siciak
Produkcja serii: Sylwia Smoczyńska
Realizacja i produkcja muzyki: Jan Smoczyński 
zdjęcia: Marcin Jończyk || Jakub Stoszek || Łukasz Łatanik
montaż: Marcin Jończyk
Realizacja dźwięku: Krzysztof Salawa
Make Up: Zuza Górska

Nagranie zrealizowano dzięki uprzejmości i gościnie SIELSKO ANIELSKO
→ https://www.facebook.com/sielsko.anielsko.niesadna
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Krzyżu Święty || Paweł Wszołek TRIO || Medytacja Wielkopostna
 - [https://www.youtube.com/watch?v=UqCW26-16uQ](https://www.youtube.com/watch?v=UqCW26-16uQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-26 00:00:00+00:00

@Langustanapalmie @FundacjamalakPl 

“W ogrodzie” to cykl tradycyjnych pieśni wielkopostnych w nowoczesnych, instrumentalnych aranżacjach, którego pomysłodawcą jest Paweł Wszołek. Muzyka może być inspiracją do medytacji, początkiem modlitwy czy chwili zadumy. 

“Zależało mi, żeby projekt był na wysokim poziomie muzycznym i wizualnym i zachęcał po sięganie do tradycyjnych pieśni.” - Paweł Wszołek  

WYKONAWCY:
kontrabas
Paweł Wszołek  
fortepian
Franciszek Raczkowski  
perkusja
Szymon Madej
  
Zdjęcia: Adam Paśko, Kasia Lewek
Montaż: Adam Paśko
Produkcja, aranżacja, realizacja nagrania, miks: Paweł Wszołek
Produkcja całości: Fundacja Malak
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Program [#33] Okruchy 2 [PL/SK]
 - [https://www.youtube.com/watch?v=HhgbgAXeRcY](https://www.youtube.com/watch?v=HhgbgAXeRcY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-26 00:00:00+00:00

@Langustanapalmie @Stacja7pl 

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#745] Ufność
 - [https://www.youtube.com/watch?v=-W__lh6NLLo](https://www.youtube.com/watch?v=-W__lh6NLLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-26 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 26.03 → https://youtu.be/ZNaO28uPHhY

POD SERCEM to wielkopostna akcja charytatywna, której celem jest pomoc kobietom w ciąży, znajdującym się w trudnej sytuacji lub z różnych powodów niebędącym w stanie poradzić sobie z wiadomością o dziecku bądź jego chorobie. 

Fundacja Malak
Numer konta (PLN): 42 2490 0005 0000 4600 1184 3564
IBAN: PL 42 2490 0005 0000 4600 1184 3564
BIC/SWIFT: ALBPPLPW
"Pod sercem. Wielkopostna akcja charytatywna"

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Krzyżu Chrystusa || Paweł Wszołek TRIO || Medytacja Wielkopostna
 - [https://www.youtube.com/watch?v=PW8SmoboFRM](https://www.youtube.com/watch?v=PW8SmoboFRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-25 00:00:00+00:00

@Langustanapalmie @FundacjamalakPl 

“W ogrodzie” to cykl tradycyjnych pieśni wielkopostnych w nowoczesnych, instrumentalnych aranżacjach, którego pomysłodawcą jest Paweł Wszołek. Muzyka może być inspiracją do medytacji, początkiem modlitwy czy chwili zadumy. 

“Zależało mi, żeby projekt był na wysokim poziomie muzycznym i wizualnym i zachęcał po sięganie do tradycyjnych pieśni.” - Paweł Wszołek  

WYKONAWCY:
kontrabas
Paweł Wszołek  
fortepian
Franciszek Raczkowski  
perkusja
Szymon Madej
  
Zdjęcia: Adam Paśko, Kasia Lewek
Montaż: Adam Paśko
Produkcja, aranżacja, realizacja nagrania, miks: Paweł Wszołek
Produkcja całości: Fundacja Malak


Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## List św. Jakuba || Rozdział 05
 - [https://www.youtube.com/watch?v=p2-PzzJXAoA](https://www.youtube.com/watch?v=p2-PzzJXAoA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-25 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wiadomo szóste {#32] Okruchy 2  [PL/SK]
 - [https://www.youtube.com/watch?v=fiNXSv4krvg](https://www.youtube.com/watch?v=fiNXSv4krvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-25 00:00:00+00:00

@Langustanapalmie @Stacja7pl 

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#744] W sercu
 - [https://www.youtube.com/watch?v=rPfi0bqbrv8](https://www.youtube.com/watch?v=rPfi0bqbrv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-25 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 25.03 → https://youtu.be/eQt7S1TRbQU

POD SERCEM to wielkopostna akcja charytatywna, której celem jest pomoc kobietom w ciąży, znajdującym się w trudnej sytuacji lub z różnych powodów niebędącym w stanie poradzić sobie z wiadomością o dziecku bądź jego chorobie. 

Fundacja Malak
Numer konta (PLN): 42 2490 0005 0000 4600 1184 3564
IBAN: PL 42 2490 0005 0000 4600 1184 3564
BIC/SWIFT: ALBPPLPW
"Pod sercem. Wielkopostna akcja charytatywna"

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

