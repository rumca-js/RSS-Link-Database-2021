# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## OUTRIDERS CHEATER PUNISHMENT IS GENIUS, SWITCH 2 SPECS LEAKED, & MORE
 - [https://www.youtube.com/watch?v=Gp5UuGq60Fg](https://www.youtube.com/watch?v=Gp5UuGq60Fg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-26 00:00:00+00:00

Go to https://expressvpn.com/gameranx and find out how you can get 3 months of ExpressVPN free!

A new Nintendo Switch Pro rumor, new game reveal events, PSN shutdowns, delays, and more in a week full of gaming news.

Subscribe for more: https://www.youtube.com/gameranxTV?su...​...

0:00 Nintendo Switch 2
02:37 Microsoft Buying Discord?
04:14 Outriders Cheater Punishment
05:02 Old PSN stores
06:20 Back4Blood Delayed
07:52 Reggie bails on GameStop
08:42 Call of Duty 2021 Leaks
09:00 NEW Trailers
11:15 Half-life Alyx Bioshock Mod


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​​



 ~~~~STORIES~~~~


Switch specs leaked?
https://arstechnica.com/gaming/2021/03/report-the-next-nintendo-switch-will-deliver-4k-on-tvs-via-nvidias-dlss/
https://twitter.com/6d6f636869/status/1374260197724626944?s=20

Outriders hilarious cheater response: 
https://www.pcgamer.com/outriders-brand-cheaters-watermark/

Discord
https://www.cnbc.com/2021/03/23/microsoft-is-reportedly-in-talks-to-acquire-discord-for-more-than-10-billion.html

Old PSN stores
https://www.thegamer.com/ps3-vita-psp-stores-permanently-closed/

Call of Duty WW2 again: 
https://www.eurogamer.net/articles/2021-03-26-report-this-years-call-of-duty-returns-to-ww2

Back4Blood
https://twitter.com/back4blood/status/1375115260282073093

Reggie bails on GameStop
https://kotaku.com/former-nintendo-of-america-president-reggie-fils-aime-l-1846550898


Rocket League goes mobile
https://kotaku.com/rocket-league-is-coming-to-smartphones-1846544939
Future Games Show (including Gollum reveal trailer) 
https://youtu.be/7I9o2aBVhBk

Xbox indie event: 
https://youtu.be/0L8_GAB3Efg



Trailers:

Biomutant Combat Trailer
https://www.youtube.com/watch?v=yXIE68V3ajE

Hood: Outlaws and Legends
https://www.youtube.com/watch?v=BzKRegzoqcM

Hitman 3 Seven Deadly Sins
https://www.youtube.com/watch?v=Whwhg08AyzU

Atomic Heart Photo Mode
https://www.youtube.com/watch?v=JH5OpMfv698


2 cool things:

BB 4k
https://youtu.be/lOn2ludP6gM

Amazing half life Alyx mod:
https://youtu.be/p_MWIyxSZCc

## Top 10 New Games of April 2021
 - [https://www.youtube.com/watch?v=vfQR4ki3dOI](https://www.youtube.com/watch?v=vfQR4ki3dOI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-25 00:00:00+00:00

Looking for something to play on PC, PS5, Xbox Series X, PS4, or Nintendo Switch in April? We've got you covered with these major releases.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Humankind 

Platform : PC, Stadia

Release Date :  April 22, 2021



Century: Age of Ashes 

Platform : PC

Release Date : April TBC



Oddworld: Soulstorm 

Platform : PC, PS5, PS4

Release Date : April 6, 2021



Star Wars Republic Commando 

Platform : PS4, Switch

Release Date : April 6, 2021



MotoGP 21

Platform : PC NS, PS4, PS5, XBOX ONE, XSX

Release Date : April 22, 2021



MLB The Show 21 

Platform : PS5, XSX, PS4, XBOX ONE

Release Date : April 20, 2021



New Pokemon Snap 

Platform : Switch

Release Date : April 30, 2021



NieR Replicant ver 1.22474487139... 

Platform : PC, PS4, XBOX ONE

Release Date : April 23, 2021



Outriders 

Platform : PC, PS5, XSX, PS4, XBOX ONE, Stadia

Release Date : April 1, 2021



Returnal 

Platform : PS5

Release Date : April 30, 2021

