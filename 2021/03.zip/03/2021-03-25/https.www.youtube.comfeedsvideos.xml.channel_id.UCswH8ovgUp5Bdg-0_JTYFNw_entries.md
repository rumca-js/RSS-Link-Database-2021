# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Forever Wars: Business As Usual Under Biden’s Bombs
 - [https://www.youtube.com/watch?v=3Z5yuHVDcl0](https://www.youtube.com/watch?v=3Z5yuHVDcl0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-03-26 00:00:00+00:00

President Biden ran on ending forever wars and being tough on Saudi Arabia’s controversial regime. Is he already undermining those promises?
#Biden #War #SaudiArabia

My Audible Original, ‘Revelation', is out now!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com​/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Under The Skin podcast to hear from guests including Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Get a one month free trial at http://luminary.link/russell​

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

## ¡REVELATION!
 - [https://www.youtube.com/watch?v=hRjo2tJMmf8](https://www.youtube.com/watch?v=hRjo2tJMmf8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-03-25 00:00:00+00:00

My new Audible original REVELATION is OUT NOW - If you want it, you can get it here: 

US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

