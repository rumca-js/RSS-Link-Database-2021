# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## PVA - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=J8_faCSTyXg](https://www.youtube.com/watch?v=J8_faCSTyXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-26 00:00:00+00:00

http://KEXP.ORG presents PVA sharing a live performance recorded exclusively for KEXP and talking to DJ Troy Nelson. Recorded March 11, 2021.

Songs:
Sleek Form
Divine Intervention 
Exhaust / Surroundings

https://ninjatune.net/artist/pva
http://kexp.org

## Middle Kids - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=cYnb73Eq728](https://www.youtube.com/watch?v=cYnb73Eq728)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-25 00:00:00+00:00

http://KEXP.ORG presents Middle Kids performing live, recorded exclusively for KEXP.

Songs:
Stacking Chairs
R U 4 Me?
Today We’re The Greatest
Questions
Cellophane (Brain)

Record by Blaine A. Cunneen at Oceanic Studios, Melbourne, Australia
Filmed by Thom Davies
Mixed by Tim Fitz

https://www.middlekidsmusic.com
http://kexp.org

