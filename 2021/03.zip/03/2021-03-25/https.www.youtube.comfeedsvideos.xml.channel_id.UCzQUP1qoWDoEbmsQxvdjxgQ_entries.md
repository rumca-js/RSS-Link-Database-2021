# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Mark Sisson on Achieving Metabolic Flexibility Through Fasting
 - [https://www.youtube.com/watch?v=yhulQ0XuAPM](https://www.youtube.com/watch?v=yhulQ0XuAPM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-26 00:00:00+00:00

Taken from JRE #1624 w/Mark Sisson:
https://open.spotify.com/episode/0YoTG8B6spV31mCHk63zqD?si=026ca5ad698f4a40

## Mark Sisson on the Importance of Cholesterol, Problems with Statins
 - [https://www.youtube.com/watch?v=hDGLS28DDmQ](https://www.youtube.com/watch?v=hDGLS28DDmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-26 00:00:00+00:00

Taken from JRE #1624 w/Mark Sisson:
https://open.spotify.com/episode/0YoTG8B6spV31mCHk63zqD?si=026ca5ad698f4a40

## The Future of Meat Consumption
 - [https://www.youtube.com/watch?v=3QrOK8DC3RE](https://www.youtube.com/watch?v=3QrOK8DC3RE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-26 00:00:00+00:00

Taken from JRE #1624 w/Mark Sisson:
https://open.spotify.com/episode/0YoTG8B6spV31mCHk63zqD?si=026ca5ad698f4a40

## Doug Stanhope's Lucid Dreaming Experiences
 - [https://www.youtube.com/watch?v=5Jtv1GpPvHM](https://www.youtube.com/watch?v=5Jtv1GpPvHM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-25 00:00:00+00:00

Taken from JRE #1623 w/Doug Stanhope:
https://open.spotify.com/episode/5kbYltjZPKuT6h2u5Pae8x?si=_cMXQtQiQXqvmyv-QeoX2g

## This Is Stanhope's First Time Leaving Bisbee in 1 Year
 - [https://www.youtube.com/watch?v=394TNBPINAM](https://www.youtube.com/watch?v=394TNBPINAM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-25 00:00:00+00:00

Taken from JRE #1623 w/Doug Stanhope:
https://open.spotify.com/episode/5kbYltjZPKuT6h2u5Pae8x?si=_cMXQtQiQXqvmyv-QeoX2g

