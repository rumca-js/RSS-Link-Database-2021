# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## This is why we can't have nice things
 - [https://www.youtube.com/watch?v=j5v8D-alAKE](https://www.youtube.com/watch?v=j5v8D-alAKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-03-26 00:00:00+00:00

This video is about stuff: light bulbs, printers, phones and why they aren't better. Go to https://NordVPN.com/veritasium and use code VERITASIUM to get a 2-year plan plus 1 additional month with a huge discount. It’s risk free with Nord’s 30 day money-back guarantee!

References:
The Man in the White Suit — https://ve42.co/Suit

London, B. (1932). Ending the depression through planned obsolescence. — https://ve42.co/London32

Slade, G. (2009). Made to break: Technology and obsolescence in America. Harvard University Press — https://ve42.co/madetobreak

Krajewski, M. (2014). The great lightbulb conspiracy. IEEE spectrum, 51(10), 56-61. — https://ve42.co/Phoebus

Planet Money, The Phoebus Cartel - https://ve42.co/PMobs

The Light Bulb Conspiracy - https://youtu.be/e9xmn228HM0

Special thanks to Patreon supporters: Mac Malkawi, Oleksii Leonov, Michael Schneider, Jim Osmun, Tyson McDowell, Ludovic Robillard, jim buckmaster, fanime96, Juan Benet, Ruslan Khroma, Robert Blum, Richard Sundvall, Lee Redden, Vincent, Lyvann Ferrusca, Alfred Wallace, Arjun Chakroborty, Joar Wandborg, Clayton Greenwell, Pindex, Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal

Written by Derek Muller and Petr Lebedev
Animation by Ivy Tello
Filmed by Derek Muller and Raquel Nuno
Edited by Derek Muller
Video supplied by Getty Images

Music by Jonny Hyman and from https://epidemicsound.com"Aquatic Planet", "Rhythm of Dreams", "Tread Lightly", "Unexpected Visitors", "Curved Mirrors" "Drunken Lullaby" "Fluorescent Lights"

Thumbnail by Raquel Nuno and Karri Denise

