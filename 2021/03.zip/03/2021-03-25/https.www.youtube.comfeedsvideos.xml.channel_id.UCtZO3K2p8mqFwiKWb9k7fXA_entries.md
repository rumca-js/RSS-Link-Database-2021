# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Why making chips is so hard
 - [https://www.youtube.com/watch?v=CkNn98WE5_k](https://www.youtube.com/watch?v=CkNn98WE5_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2021-03-25 00:00:00+00:00

Sponsored by Audible. Get your free trial and listen to AI Superpower or other books at https://www.audible.com/techaltar 

From sand to silicon, the semiconductor industry is one of the most complex in the world. In this video I break down the most important players, trends and technologies from ISAs all the way to fabrication and packaging.

The Story Behind - episode 74

This video on Nebula: https://watchnebula.com/videos/techaltar-the-insanely-complex-economics-of-making-processors

Engadget's video on EUV: https://www.youtube.com/watch?v=oIiqVrKDtLc&t=132s

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

Intro music by Epidemic sound: https://www.epidemicsound.com/

Kai Fu Lee's photo by SheilaShang, TSMC photo by Briáxis F. Mendes (孟必思), 
CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0, via Wikimedia Commons

