# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## It Happened. (REPOST)
 - [https://www.youtube.com/watch?v=zk6UcUVbJko](https://www.youtube.com/watch?v=zk6UcUVbJko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-03-25 00:00:00+00:00

Yes, this is a repost of the video I released to mark the million subscriber milestone in December. I used the song "All By Myself" as part of a joke at the end of the video. I assumed it would be demonetized but no, they blocked it completely. So I replaced it with some stock music and here it is for anyone who wants to see it.

