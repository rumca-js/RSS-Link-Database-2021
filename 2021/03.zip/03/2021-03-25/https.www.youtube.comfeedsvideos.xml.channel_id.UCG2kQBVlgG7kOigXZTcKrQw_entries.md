# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Suwalskie klimaty. Najładniejsze miejsca, Polski Jakuck i czapka KST do zgarnięcia
 - [https://www.youtube.com/watch?v=A1Ve0J1L3gg](https://www.youtube.com/watch?v=A1Ve0J1L3gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-03-25 00:00:00+00:00

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/


spis treści
00:00 - 0:57 Co warto odwiedzić na Suwalszczyźnie?
1:11 Jezioro Wigry
2:06 Czapka!
2:58 Czarna Hańcza
4:40 Suwalski Park Krajobrazowy
6:28 Wiżajny - Polski Jakuck
7:27 Trójkąt Przejmującej Ciszy
8:30 Puńsk i Litwini w Polsce
9:44 Dlaczego na Podlasiu nie używają soli?
10:12 Mosty w Stańczykach
12:42 Karol Mówi ELO!

