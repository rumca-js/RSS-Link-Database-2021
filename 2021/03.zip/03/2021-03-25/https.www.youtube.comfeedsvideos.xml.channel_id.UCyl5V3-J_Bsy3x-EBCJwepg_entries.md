# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## New York Times Smears The Bee and How To Use Tragedy To Score Political Points
 - [https://www.youtube.com/watch?v=jzLGCIQKAGQ](https://www.youtube.com/watch?v=jzLGCIQKAGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-26 00:00:00+00:00

Kyle and Ethan talk to The Babylon Bee CEO Seth Dillon about The Bee’s recent mention in the New York Times as an example of a far-right site trafficking in misinformation disguised as “satire”. Kyle and Ethan talk about how to score political points during a national tragedy, why we can’t reach for the stars until we have a progressive tax system, and what not to do at the zoo.

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## All-Seeing Eye Of Sauron Unveiled At Facebook Headquarters
 - [https://www.youtube.com/watch?v=nDoq51tpP3A](https://www.youtube.com/watch?v=nDoq51tpP3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-25 00:00:00+00:00

Facebook proudly unveiled a brand new Eye of Sauron to be used to examine users’ every action, online and off. The Babylon Bee News Desk has the report.

Become a premium subscriber: https://babylonbee.com/plans​

The Official The Babylon Bee Store: https://shop.babylonbee.com​

Follow The Babylon Bee:
Website: https://babylonbee.com​
Twitter: http://twitter.com/thebabylonbee​
Facebook: http://facebook.com/thebabylonbee​
Instagram: http://instagram.com/thebabylonbee

