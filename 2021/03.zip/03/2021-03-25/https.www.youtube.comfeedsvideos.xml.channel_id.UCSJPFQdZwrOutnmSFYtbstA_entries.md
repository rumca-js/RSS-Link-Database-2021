# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Chronicles of Riddick - A Very Unexpected Sequel
 - [https://www.youtube.com/watch?v=PPHfH8G__nY](https://www.youtube.com/watch?v=PPHfH8G__nY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-03-26 00:00:00+00:00

The Chronicles of Riddick is one of the most baffling sequels to a decent movie that I've ever seen. So let's take a look at it, and laugh.

