# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Beats From Scratch - Elektron Digitakt (Chill Stuff)
 - [https://www.youtube.com/watch?v=0m15u4XTPEU](https://www.youtube.com/watch?v=0m15u4XTPEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-03-26 00:00:00+00:00

Let's make some stuff on the Elektron Digitakt.
Using this pack: https://www.elektron.se/soundpacks/the-calling/
Eletktron Digitakt: https://amzn.to/37ztU6d
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

