# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## New Intel CEO finally has a plan!
 - [https://www.youtube.com/watch?v=_Cx5nDItdmY](https://www.youtube.com/watch?v=_Cx5nDItdmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-03-26 00:00:00+00:00

Sponsored by Audible. Get your free trial and listen to AI Superpower or other books at https://www.audible.com/fridaycheckout

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► About this video◄◄◄

This week Microsoft is rumored to acquire Discord for over $10 billion, Windows gets new icons, and the new Intel CEO Pat Gelsinger lays out a bold plan for turning the company around.

The Friday Checkout - Episode 40

This video on Nebula: 

My chip industry video on TechAltar: https://www.youtube.com/watch?v=CkNn98WE5_k

Quiz: https://link.crrowd.com/quiz (should open either in the Android app or on the web depending on what device you're on!)
Release monitor: https://www.crrowd.com/release-monitor

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:27 Release Highlights
1:22 Microsoft & Discord
4:27 New Windows icons
5:01 The big Intel revival

