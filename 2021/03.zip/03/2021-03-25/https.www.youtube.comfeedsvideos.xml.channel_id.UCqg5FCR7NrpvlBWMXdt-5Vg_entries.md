# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Black Legend | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=XOQTuB2FxN0](https://www.youtube.com/watch?v=XOQTuB2FxN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-03-26 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

KC Nwosu reviews Black Legend, developed by Warcave.

Black Legend on Steam: https://store.steampowered.com/app/1094730/Black_Legend/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Designing The Opening Moments of Bioshock with Bill Gardner | Gameumentary
 - [https://www.youtube.com/watch?v=Zfv9v4bdTCw](https://www.youtube.com/watch?v=Zfv9v4bdTCw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-03-25 00:00:00+00:00

**Originally aired on Gameumentary, re-released on The Escapist to share with a new audience**

Bill Gardner, formerly the lead level designer on Bioshock at Irrational Games, discusses the making of the opening level of the game in this mini-doc from Gameumentary (now part of The Escapist).

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#Bioshock #Documentary

