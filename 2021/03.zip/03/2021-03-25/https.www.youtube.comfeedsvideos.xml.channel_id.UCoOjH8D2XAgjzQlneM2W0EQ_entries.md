# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## China’s Profitable Business of Enslaving Africa | Documentary
 - [https://www.youtube.com/watch?v=6lz1RQw_MgU](https://www.youtube.com/watch?v=6lz1RQw_MgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-03-26 00:00:00+00:00

Go to https://brilliant.org/jaketran for 20% off an annual premium subscription today!

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Check out the full interview with John Perkins, the Economic Hitman, here: https://youtu.be/N4Sm3vcW2lk
Learn & connect with John Perkins here: https://jake.yt/perkins 
Read Confessions of an Economic Hitman: https://amzn.to/3d8nUEW 

Watch our indebting less-developed nations video: https://youtu.be/jgqoGWE6pe4 
Watch our full interview with Robert Spalding: https://youtu.be/wA0pEDQG1RY

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🖥️ Website platform I use: https://jake.yt/kd
📈 Get up to $250 in free Bitcoin at http://blockfi.com/jake 
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use: https://jake.yt/benchd 
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3ff4LEf

-----------------------
The President of Sri Lanka started pushing to build a new port in a small town at the south end of Sri Lanka because ambitious projects like this make you look like a good, caring politician. The only problem was that everyone, including their own government studies estimated that the port wouldn’t be profitable. But then the President announced that the project had been greenlighted - with help from none other than China.

The port opened in 2012, and the forecasts were right - no one was interested in using this new port. And it’s finances were in the hole. So the President went back to China for another loan, this time for $757 million.

So what did they do? They took out another loan from China, this time for $1 billion dollars, to help pay off that upcoming debt payment. It’s safe to say that Sri Lanka found itself at the mercy of the Chinese government. It was drowning in debt payments and was left with an expensive port no one wanted to use. And now, China owns 85% of that port and managed to squeeze 15,000 acres of land around that port as well.

Debt traps, debt diplomacy is nothing new. China is probably just taking a page out of the original master at this game: the US. Why did the US go through all this effort to indebt these Less-Developed Countries, or LDCs? Simple: when you’re a global superpower, you need a lot of resources to stay on top: oil, energy, raw materials, nations under your influence so you can call them up when you need something like votes at the UN, and so on.

Today, China is in a similar position - they’re desperate for energy, money, and resources to continue their astronomical growth to the top.

Who knows in the long run what will happen with China's colonialism. China has the ability to be forceful when needed, especially in their sphere. 

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

