# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## See stunning video from inside the tornado in Alabama
 - [https://www.cnn.com/videos/us/2021/03/25/pelham-alabama-storm-video-sot-vpx.cnn](https://www.cnn.com/videos/us/2021/03/25/pelham-alabama-storm-video-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 23:58:49+00:00

Pelham, Alabama, resident Cesar Villaseñor captured dramatic footage from inside a tornado that struck the area Thursday.

## Here's the deal with Jack Dorsey's weird 'clock'
 - [https://www.cnn.com/2021/03/25/tech/jack-dorsey-clock-blockchain/index.html](https://www.cnn.com/2021/03/25/tech/jack-dorsey-clock-blockchain/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 23:26:04+00:00

On Wednesday, the CEOs of Facebook, Google and Twitter appeared (virtually) before a congressional committee to answer hours of pointed questions about how their platforms handle misinformation.

## Fuel ship finally docks in Yemen's Hodeidah port as blockade eases
 - [https://www.cnn.com/2021/03/25/middleeast/yemen-fuel-ship-hodeidah-dock-intl/index.html](https://www.cnn.com/2021/03/25/middleeast/yemen-fuel-ship-hodeidah-dock-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 22:47:55+00:00

A tanker carrying oil docked at Hodeidah port in Yemen on Thursday -- the first such ship to berth this year in the country's Houthi-controlled north, where fuel is desperately needed to distribute food and to keep the country's hospitals from shuttering.

## Chinese Ambassador: The goal is not to replace United States
 - [https://www.cnn.com/2021/03/25/world/chinese-ambassador-cui-tiankai-amanpour-intl/index.html](https://www.cnn.com/2021/03/25/world/chinese-ambassador-cui-tiankai-amanpour-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 22:16:37+00:00

China's goal is not to replace the United States as the world's leading country, the Chinese Ambassador to the US said Thursday.

## How the children of celebrities are working on their own stardom
 - [https://www.cnn.com/2021/03/25/entertainment/kids-celebrities-plc/index.html](https://www.cnn.com/2021/03/25/entertainment/kids-celebrities-plc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 22:10:52+00:00

How in the heck do you live up to being Beyoncé and Jay-Z's firstborn?

## Facebook, Twitter and Google CEOs testify before Congress on misinformation
 - [https://www.cnn.com/2021/03/25/tech/tech-ceos-hearing/index.html](https://www.cnn.com/2021/03/25/tech/tech-ceos-hearing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 21:45:22+00:00

Congress is set to grill the chief executives of Facebook, Google and Twitter about misinformation and online extremism on Thursday, in the executives' first appearance before lawmakers since the Jan. 6 Capitol riots and the rollout of the coronavirus vaccine.

## Octopuses stay busy while they're sleeping. See what they're up to.
 - [https://www.cnn.com/videos/world/2021/03/25/octopus-color-change-sleep-na-mh-orig.cnn](https://www.cnn.com/videos/world/2021/03/25/octopus-color-change-sleep-na-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 21:23:06+00:00

Some octopuses change color while they sleep, new research suggests. Here's what scientists believe the color change means.

## Video shows effort to release ship stuck in Suez Canal
 - [https://www.cnn.com/videos/business-videos/2021/03/25/suez-canal-ship-stuck-ever-given-blocking-orig-kj.cnn](https://www.cnn.com/videos/business-videos/2021/03/25/suez-canal-ship-stuck-ever-given-blocking-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 21:14:59+00:00

Tugboats are working to free a 224,000-ton container ship stuck in the Suez Canal. Here's why they need to act quick.

## LAPD cracks down on Echo Park homeless encampment
 - [https://www.cnn.com/2021/03/25/us/los-angeles-police-echo-park-homeless/index.html](https://www.cnn.com/2021/03/25/us/los-angeles-police-echo-park-homeless/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 21:12:20+00:00

Los Angeles officials moved ahead Thursday with the shut down of a homeless encampment in Echo Park following a night of confrontations between police and demonstrators.

## How AstraZeneca went from pandemic hero to villain
 - [https://www.cnn.com/2021/03/25/business/astrazeneca-covid-vaccine/index.html](https://www.cnn.com/2021/03/25/business/astrazeneca-covid-vaccine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 20:38:56+00:00

After teaming up with Oxford University, AstraZeneca produced a safe and effective Covid-19 vaccine in just nine months, a huge achievement that will help end the pandemic. But a series of missteps along the way has led to scathing criticism from policymakers and health officials, tarnishing the company's image as a hero of the coronavirus era.

## See CNN reporter's tough question for Biden
 - [https://www.cnn.com/videos/politics/2021/03/25/biden-kaitlan-collins-jim-crow-filibuster-vpx.cnn](https://www.cnn.com/videos/politics/2021/03/25/biden-kaitlan-collins-jim-crow-filibuster-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 20:23:48+00:00

CNN's Kaitlan Collins asks President Joe Biden about the filibuster and his plans for re-election.

## Russia says Navalny is in 'generally good health' after he describes 'severe pain'
 - [https://www.cnn.com/2021/03/25/europe/navalny-russia-health-concerns-intl/index.html](https://www.cnn.com/2021/03/25/europe/navalny-russia-health-concerns-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 19:19:23+00:00

Russia's prison service has said Kremlin critic Alexey Navalny is in "generally good health" after the activist's team expressed concern about his physical condition and said they were denied access to see him.

## A bottle of wine was blasted into space. Here's what it tastes like now
 - [https://www.cnn.com/travel/article/space-wine-tasting-scli-intl/index.html](https://www.cnn.com/travel/article/space-wine-tasting-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 17:46:44+00:00

When most of us need to sound smart about wine, we simply tilt the glass a little, take a big sniff, and mumble something about dark fruits.

## Unseen Vincent van Gogh painting of Paris sells for $19.1 million
 - [https://www.cnn.com/style/article/van-gogh-paris-painting-public-display-scli-intl/index.html](https://www.cnn.com/style/article/van-gogh-paris-painting-public-display-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 16:30:39+00:00

A painting of Paris by Vincent van Gogh, which has almost never been seen by the public after being stashed within a French family's private collection for more than a century, has sold for 16,251,000 euros ($19.1 million) after fees.

## Icelandic man gets naked next to erupting volcano
 - [https://www.cnn.com/travel/article/iceland-volcano-naked/index.html](https://www.cnn.com/travel/article/iceland-volcano-naked/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 16:28:50+00:00

Stripping off a few layers when things heat up can often be the most natural thing in the world.

## Why are more young people getting severely ill and dying of Covid in Brazil?
 - [https://www.cnn.com/collections/intl-global-covid-0324/](https://www.cnn.com/collections/intl-global-covid-0324/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 16:26:54+00:00



## Slack says it's fixing its tool to DM anyone after harassment concerns
 - [https://www.cnn.com/2021/03/24/tech/slack-connect-messaging/index.html](https://www.cnn.com/2021/03/24/tech/slack-connect-messaging/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 15:29:27+00:00

Wednesday morning, Slack rolled out a feature to let its users message people at other companies. By Wednesday afternoon, it was walking the feature back and making changes to prevent harassment after people pointed out that it could be used to send unsolicited DMs and perhaps even abusive emails.

## They see color: Two new Black 'Sesame Street' characters explain racial difference to children
 - [https://www.cnn.com/2021/03/25/health/sesame-street-two-new-black-muppets-wellness/index.html](https://www.cnn.com/2021/03/25/health/sesame-street-two-new-black-muppets-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 15:19:33+00:00

It's not unusual in American conversations on race for somebody to proclaim, "I don't see color," as his or her own personal credo on the matter.

## Chrissy Teigen's parting words as she left Twitter
 - [https://www.cnn.com/2021/03/25/entertainment/chrissy-teigen-twitter-intl-scli/index.html](https://www.cnn.com/2021/03/25/entertainment/chrissy-teigen-twitter-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 14:59:05+00:00

Chrissy Teigen has deleted her Twitter account, saying that the social media platform has started to serve her "negatively."

## Norway players wear t-shirts protesting Qatar World Cup ahead of qualifier against Gibraltar
 - [https://www.cnn.com/2021/03/25/sport/norway-tshirt-protest-against-qatar-world-cup-spt-intl/index.html](https://www.cnn.com/2021/03/25/sport/norway-tshirt-protest-against-qatar-world-cup-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 14:58:54+00:00

Norway's players wore t-shirts bearing the message "Human rights on and off the pitch" in the lead up to its World Cup qualifier against Gibraltar in protest of the next tournament being held in Qatar.

## GM adds Meg Whitman to its majority-women board
 - [https://www.cnn.com/2021/03/25/investing/whitman-gm-board/index.html](https://www.cnn.com/2021/03/25/investing/whitman-gm-board/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 14:25:46+00:00

Former Hewlett-Packard CEO Meg Whitman is joining the board of General Motors, adding another woman to one of the more diverse boards in corporate America.

## Champion snowboarder Julie Pomagalski dies in avalanche
 - [https://www.cnn.com/2021/03/25/sport/snowboarder-julie-pomagalski-death-scli-intl/index.html](https://www.cnn.com/2021/03/25/sport/snowboarder-julie-pomagalski-death-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 14:10:09+00:00

Former world champion snowboarder Julie Pomagalski has died in an avalanche at the age of 40.

## A huge ship is blocking a vital trade artery. It could get costly
 - [https://www.cnn.com/2021/03/25/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/03/25/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 13:35:25+00:00

Tug boats are working to free a large container ship stuck in Egypt's Suez Canal, halting traffic through one of the busiest and most important waterways in the world.

## Pepsi's newest flavor has Peeps in it
 - [https://www.cnn.com/2021/03/25/business/peeps-pepsi-flavor/index.html](https://www.cnn.com/2021/03/25/business/peeps-pepsi-flavor/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 12:59:50+00:00

Good news, Peeps fans! Not only will Peeps be back on store shelves in time for Easter, but they'll come in a new form too.

## British university to return Benin Bronze to Nigeria 'within weeks'
 - [https://www.cnn.com/2021/03/25/africa/aberdeen-return-nigeria-benin-bronze-intl/index.html](https://www.cnn.com/2021/03/25/africa/aberdeen-return-nigeria-benin-bronze-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 12:10:23+00:00

The University of Aberdeen said on Thursday it would return a Benin Bronze to Nigeria within weeks, one of the first public institutions to do so more than a century after Britain looted the sculptures and auctioned them to Western museums and collectors.

## Analysis: Brexit Britain won't leave Europe
 - [https://www.cnn.com/2021/03/25/uk/why-the-uk-will-remain-european-intl-gbr-cmd/index.html](https://www.cnn.com/2021/03/25/uk/why-the-uk-will-remain-european-intl-gbr-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 11:23:12+00:00

• Analysis: Boris Johnson's latest gaffe could threaten Britain's vaccine rollout

## CNN finds stranded Uyghur children in China
 - [https://www.cnn.com/videos/world/2021/03/24/china-xinjiang-children-culver-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/03/24/china-xinjiang-children-culver-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 10:14:58+00:00

Amnesty International reports that China's polices towards ethnic Uyghur Muslims have split up thousands of families, as some children are prevented from leaving China's Xinjiang region to be with their parents living abroad. The US and other countries have labeled China's treatment of Uyghurs as genocide. Beijing strongly denies the accusations, insisting that its actions are justified to combat religious extremism and prevent terrorism. With permission from Uyghur parents desperate for answers, CNN's David Culver traveled to the heavily surveilled Xinjiang region in search of their children left behind.

## A 230-year-old tree falls, destined to rebuild a Paris icon
 - [https://www.cnn.com/style/article/notre-dame-rebuild-oak-trees/index.html](https://www.cnn.com/style/article/notre-dame-rebuild-oak-trees/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 09:39:54+00:00

Deep in the former royal forest of Bercé, in France's Loire region, a 230-year-old tree comes crashing to the ground with thunderous intensity.

## This new artificial heart responds to the patient
 - [https://www.cnn.com/2021/03/25/business/carmat-artificial-heart-spc-intl/index.html](https://www.cnn.com/2021/03/25/business/carmat-artificial-heart-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 08:40:51+00:00

Heart disease is the world's biggest killer, and around one in five people in developed countries will suffer heart failure in their lifetime.

## How boys suffer from gender stereotypes — author Emma Brown weighs in
 - [https://www.cnn.com/2021/03/25/health/raise-a-boy-emma-brown-wellness/index.html](https://www.cnn.com/2021/03/25/health/raise-a-boy-emma-brown-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 08:21:32+00:00

When it came to raising her daughter, Emma Brown trusted her instincts. Determined to combat the stereotypes deployed against girls from birth, she developed a mantra for her little girl: "I am strong and fearless."

## How dangerous is North Korea's military arsenal right now?
 - [https://www.cnn.com/2021/03/25/asia/north-korea-arsenal-intl-hnk-scli-ml/index.html](https://www.cnn.com/2021/03/25/asia/north-korea-arsenal-intl-hnk-scli-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 08:06:55+00:00

Two ballistic missiles fired by North Korea fell harmlessly into the sea on Thursday, but experts say the launch is further proof Kim Jong Un's growing military arsenal poses a significant threat to South Korea, Japan -- and even the US mainland.

## Sophia the Robot 'self-portrait' NFT sells for almost $700K
 - [https://www.cnn.com/style/article/nft-art-sophia-robot-self-portrait-scn/index.html](https://www.cnn.com/style/article/nft-art-sophia-robot-self-portrait-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 06:51:18+00:00

A hand-painted "self-portrait" by the world-famous humanoid robot, Sophia, has sold at auction for over $688,000.

## The Olympic flame starts its final leg to Tokyo. Some suggest this day should never have come
 - [https://www.cnn.com/2021/03/24/sport/japan-olympics-fukushima-torch-relay-covid-hnk-intl-dst/index.html](https://www.cnn.com/2021/03/24/sport/japan-olympics-fukushima-torch-relay-covid-hnk-intl-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 04:13:36+00:00

It was meant to be a curtain-raiser for thousands of sports fans, a celebration of Japan's recovery from nuclear disaster 10 years ago that would showcase a country emerging strongly from years of economic gloom.

## The US is sanctioning Chinese officials over alleged abuse of Uyghurs in Xinjiang. Here's what you need to know
 - [https://www.cnn.com/collections/xinjiang-intl-2503/](https://www.cnn.com/collections/xinjiang-intl-2503/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 03:50:15+00:00



## North Korea fires two ballistic missiles, senior US official says
 - [https://www.cnn.com/2021/03/24/world/north-korea-missiles-intl/index.html](https://www.cnn.com/2021/03/24/world/north-korea-missiles-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 03:41:16+00:00



## The Colorado suspect allegedly used an AR-15-style pistol. Here's how it differs from an AR-15-style rifle
 - [https://www.cnn.com/collections/boulder-intl-2503/](https://www.cnn.com/collections/boulder-intl-2503/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 03:34:32+00:00



## Asian woman assaulted in San Francisco to donate almost $1M to fight racism
 - [https://www.cnn.com/2021/03/24/us/san-francisco-asian-woman-attacked-racism-donation-trnd/index.html](https://www.cnn.com/2021/03/24/us/san-francisco-asian-woman-attacked-racism-donation-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 02:43:03+00:00

A 75-year-old Asian woman who was attacked in the street is taking the nearly $1 million donated for her medical bills and using it to combat racism, her family says.

## Britney Spears' attorney files petition to remove her father from overseeing her medical decisions
 - [https://www.cnn.com/2021/03/24/entertainment/britney-spears-conservatorship-medical-decisions/index.html](https://www.cnn.com/2021/03/24/entertainment/britney-spears-conservatorship-medical-decisions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 02:31:13+00:00

Britney Spears' attorney is requesting the judge overseeing her court ordered conservatorship, remove her father, Jamie Spears, as the conservator of her person, and permanently replace him with Jodi Montgomery.

## Atlanta police detain man with five guns and body armor in grocery store
 - [https://www.cnn.com/2021/03/24/us/atlanta-man-with-guns-supermarket-publix/index.html](https://www.cnn.com/2021/03/24/us/atlanta-man-with-guns-supermarket-publix/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 02:28:52+00:00

A man armed with a rifle entered an Atlanta Publix Supermarket Wednesday in Midtown at Atlantic Station, a commercial and residential area in the city, police said.

## New AstraZeneca report says vaccine was 76% effective in preventing Covid-19 symptoms
 - [https://www.cnn.com/2021/03/24/health/astrazeneca-updated-coronavirus-vaccine-data/index.html](https://www.cnn.com/2021/03/24/health/astrazeneca-updated-coronavirus-vaccine-data/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 02:14:45+00:00

Drug giant AstraZeneca updated its data on how well its coronavirus vaccine works, saying late Wednesday the vaccine showed 76% efficacy against symptomatic coronavirus disease and 100% efficacy against severe or critical disease or the need for hospitalization.

## Chinese threat to Taiwan 'closer to us than most think,' top US admiral says
 - [https://www.cnn.com/2021/03/24/asia/indo-pacific-commander-aquilino-hearing-taiwan-intl-hnk-ml/index.html](https://www.cnn.com/2021/03/24/asia/indo-pacific-commander-aquilino-hearing-taiwan-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 01:40:38+00:00

China is quickly amassing weapons and systems to militarily overwhelm Taiwan, an action it could be poised to take within the next six years, the admiral chosen to be the next commander of US forces in the Pacific warned Tuesday.

## Doctors describe a worrying pattern in Brazil's latest surge, with young people getting severely ill and dying
 - [https://www.cnn.com/2021/03/24/americas/brazil-youth-covid-19-intl-latam/index.html](https://www.cnn.com/2021/03/24/americas/brazil-youth-covid-19-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 00:37:05+00:00

It took only 10 days from start to finish, from the time 28-year-old Graciane da Silva got sick to the time she died.

## Africa's second coronavirus wave was much worse than the first, analysis shows
 - [https://www.cnn.com/2021/03/24/health/coronavirus-africa-second-wave-intl/index.html](https://www.cnn.com/2021/03/24/health/coronavirus-africa-second-wave-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-25 00:28:14+00:00

The second wave of the coronavirus pandemic has hit Africa much harder than the first wave, a new analysis has shown.

