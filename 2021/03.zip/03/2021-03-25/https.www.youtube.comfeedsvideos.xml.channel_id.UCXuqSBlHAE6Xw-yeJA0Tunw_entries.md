# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Goodbye Discord!! - WAN Show March 26, 2021
 - [https://www.youtube.com/watch?v=ybCiD5Ju-xA](https://www.youtube.com/watch?v=ybCiD5Ju-xA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-26 00:00:00+00:00

Sign up for Notion for free! http://bit.ly/wanshownotion

Take control of your end-of-life upgrade strategy with Extended Lifecycle Support services from CloudLinux at https://hubs.ly/H0JpBnj0

Get the CORSAIR K65 RGB Mini 
On CORSAIR: https://geni.us/8fAd1Y
On Amazon (PAID LINK): https://geni.us/MB1aUMO
On Newegg (PAID LINK): https://geni.us/o5Zz

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Goodbye-Discord-----WAN-Show-March-26--2021-etq1v2

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of BlackWings)
0:11 Intro - discord acquisition, intel tick tok, semi conducter shortage at crisis point,  acer was hit with a 50 million dollar ransom
0:55 WAN Show intro
1:22 show brought to you by notion, corsair, cloud linux
1:30 Microsoft in talks to buy discord 10 BILLION USD
       5:00 Tangent into  Linus and luke playing "escape from tarkov" 
24:39 Intel returning to tik tok production cycle, team blue to catch up ?
33:16 Sponsors (Corsair, Notion, Cloud Linux)
36:00 GPU MSRP disaster :( 
          37:43 Linus talks about LMG buying GPUs at scalper prices and selling for MSRP for an upcoming video
          40:13 new partner for Verified Actual Gamer Programme [EVGA]
          42:10 Linus talks about in-person event in which they verify games for the programme
          43:25 Poll on whether they should user scalper GPUs or EVGA ones
          44:20 Games in VAGP
          45:09 Result of poll
          51:00 Luke talks about the since fixed error message in VAGP checkout system that happened last tuesday
54:38 LTX pins on lttstore and sticker pack
56:55 Intel tech trivia (major tech youtubers crossover event)
1:00:54 Superchats
1:02:27 A little more on VAGP
1:04:45 Conclusion
1:04:52 Outro

## Our Favorite Tech - Show and Tell
 - [https://www.youtube.com/watch?v=AflNDflM-LU](https://www.youtube.com/watch?v=AflNDflM-LU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-25 00:00:00+00:00

Get $5 for signing up with Privacy and enter to win a Alienware m15 R2 at https://lmg.gg/8KXJm

Try Pulseway for free and start remotely monitoring and managing your server or PC at https://lmg.gg/Ktd7Z

We usually show off the latest and greatest in tech, but what about what we actually use? Today we're giving you a show and tell of LMG's top tech, and the stories behind each piece.


Buy a Renewed Sega Dreamcast  on Amazon: https://geni.us/zj7vCDv

Buy a Macbook: https://geni.us/kiwJV

Buy a Yeetmule FPV Drone: https://geni.us/Yeetmule

Buy DJI  FPV Drone: https://geni.us/LOWn

Buy a Leica Camera: https://geni.us/L3Fl

Purchases made through some store links may provide some compensation to Linus Media Group.

Want more? Watch the 50 minute directors cut on Floatplane! 
https://www.floatplane.com/discover

Discuss on the forum: https://linustechtips.com/topic/1318870-our-favorite-tech-show-and-tell/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

