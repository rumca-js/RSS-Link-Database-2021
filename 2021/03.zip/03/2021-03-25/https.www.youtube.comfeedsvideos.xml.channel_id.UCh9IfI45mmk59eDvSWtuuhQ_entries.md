# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## If Adulthood Had A Job Orientation Day
 - [https://www.youtube.com/watch?v=b4ZGkEzn9PE](https://www.youtube.com/watch?v=b4ZGkEzn9PE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-03-26 00:00:00+00:00

Sign up for a free Grammarly account and get 20% off Grammarly Premium by visiting https://grammarly.com/ryangeorge

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

#Grammarly

