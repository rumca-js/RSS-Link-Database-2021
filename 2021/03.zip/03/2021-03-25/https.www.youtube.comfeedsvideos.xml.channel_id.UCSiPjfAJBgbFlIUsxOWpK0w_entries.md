# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Britney Spears Mashup // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=L-DH9aW6O-4](https://www.youtube.com/watch?v=L-DH9aW6O-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-03-25 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 We decided to mash up a couple Britney Spears tunes. The classics. Toxic + Hit Me Baby One More Time. It's a bit of a mindfork actually.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte
Bass: Nick Campbell
Drum Pad: Ben Rose
Background Vocals: Nahneen Kula

AUDIO CREDITS
Engineer: Bill Mims
Mixing/Mastering: Yianni AP
Producer: Ben Rose
Mashup Arrangement: Nataly Dawn & Ben Rose
Mashup Consultant: Lauren Driscoll

VIDEO CREDITS
Director: Dom Fera
DP: Merlin Showalter
Camera Operator: Isaac Park
Editor: Dominic Mercurio
Colorist: Charlene Gibbs
Production Designer: Susannah Honey
Wardrobe: Elle Olsen
Hair/Makeup: Christina Vo
PA: Chris Modl

Recorded at Cielo Galleries/Studios in Los Angeles.

#Pomplamoose #IndieRock #BritneySpears #Toxic #BabyOneMoreTime #Mashup

LYRICS

Baby can’t you see
I’m callin’
A guy like you
Should wear a warnin’
It’s dangerous
I’m fallin’

There’s no escape
I can’t wait
I need a hit
Baby give me it
You’re dangerous
I’m lovin’ it

Too high 
Can’t come down
Losin’ my head
Spinnin’ round and round
Can you feel me now?

With a taste of your lips, I'm on a ride
You're toxic, I'm slippin' under
With a taste of your poison paradise
I'm addicted to you
Don't you know that you're toxic?

Oh baby, baby
How was I supposed to know
That somethin’ wasn’t right here
Oh baby, baby
I shouldn’t have let you go
And now you’re out of sight, yeah

Too high 
Can’t come down
It’s in the air
And it’s all around
Tell me baby 
Cause I need to know now
Oh because

With a taste of your lips, I'm on a ride
You're toxic, I'm slippin' (under)
With a taste of a poison paradise
I'm addicted to you
Don't you know that you're toxic?
 
I must confess that my loneliness is killing me now
Don't you know I still believe
That you will be here, and give me a sign
Hit me baby one more time

With a taste of your lips, I'm on a ride
You're toxic, I'm slippin' (under)
With a taste of a poison paradise
I'm addicted to you
Don't you know that you're toxic?

