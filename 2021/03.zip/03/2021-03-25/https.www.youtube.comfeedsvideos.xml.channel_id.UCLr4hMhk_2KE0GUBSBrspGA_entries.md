# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Wózek BROR z IKEI i słuchawki Soundcore Liberty Air 2 Pro
 - [https://www.youtube.com/watch?v=qDwU5VT6HzU](https://www.youtube.com/watch?v=qDwU5VT6HzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-03-25 00:00:00+00:00

Film jest podzielony na dwie części, żeby Ci z Was, którzy przyszli tu obejrzeć recenzje słuchawek, nie musieli słuchać o moich przygodach związanych z wózkiem.
Soundcore Liberty Air 2 Pro na Allegro: https://bit.ly/3vTwVup
Mieszko: https://instagram.com/mahboob

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

00:00 - 07:34 Wózek BROR
07:35 - 16:34 Soundcore Liberty Air 2 Pro

