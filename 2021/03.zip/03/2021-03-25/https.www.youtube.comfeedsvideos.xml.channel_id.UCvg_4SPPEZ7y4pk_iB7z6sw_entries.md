# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Fortnite: The New Crysis
 - [https://www.youtube.com/watch?v=x6pUdMkruiU](https://www.youtube.com/watch?v=x6pUdMkruiU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-03-26 00:00:00+00:00

Running games at max settings can be demanding. Running Cyberpunk at max settings is absurd. But what if I told you there was a game that was truly, the next Crysis? 

Something beyond comprehension, beyond logic or reason.

It’s Fortnite.
Yup.


Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

