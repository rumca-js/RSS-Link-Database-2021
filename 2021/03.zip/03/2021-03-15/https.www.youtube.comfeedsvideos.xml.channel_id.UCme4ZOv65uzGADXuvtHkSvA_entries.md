# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## List do Hebrajczyków || Rozdział 09
 - [https://www.youtube.com/watch?v=INE9eKEuMMg](https://www.youtube.com/watch?v=INE9eKEuMMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-16 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Targ intencji || marzec 2021
 - [https://www.youtube.com/watch?v=VBgICFwZqDo](https://www.youtube.com/watch?v=VBgICFwZqDo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-16 00:00:00+00:00

Targ intencji marzec 2021
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#736] Co chcesz?
 - [https://www.youtube.com/watch?v=fmPLffxex3s](https://www.youtube.com/watch?v=fmPLffxex3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-16 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 16.03 → https://youtu.be/VvGATrwgpSk

POD SERCEM to wielkopostna akcja charytatywna, której celem jest pomoc kobietom w ciąży, znajdującym się w trudnej sytuacji lub z różnych powodów niebędącym w stanie poradzić sobie z wiadomością o dziecku bądź jego chorobie. 

Fundacja Malak
Numer konta (PLN): 42 2490 0005 0000 4600 1184 3564
IBAN: PL 42 2490 0005 0000 4600 1184 3564
BIC/SWIFT: ALBPPLPW
"Pod sercem. Wielkopostna akcja charytatywna"

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wyłącz czwarte [#24] Okruchy 2 [PL/SK]
 - [https://www.youtube.com/watch?v=ZV2CYSQsGKU](https://www.youtube.com/watch?v=ZV2CYSQsGKU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-16 00:00:00+00:00

@Langustanapalmie @Stacja7pl  

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## List do Hebrajczyków || Rozdział 08
 - [https://www.youtube.com/watch?v=uGpUhJt6DI8](https://www.youtube.com/watch?v=uGpUhJt6DI8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-15 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#735] Szalony
 - [https://www.youtube.com/watch?v=UMiD93KUlwk](https://www.youtube.com/watch?v=UMiD93KUlwk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-15 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 15.03 → https://youtu.be/5Jk7QBkxGAg

POD SERCEM to wielkopostna akcja charytatywna, której celem jest pomoc kobietom w ciąży, znajdującym się w trudnej sytuacji lub z różnych powodów niebędącym w stanie poradzić sobie z wiadomością o dziecku bądź jego chorobie. 

Fundacja Malak
Numer konta (PLN): 42 2490 0005 0000 4600 1184 3564
IBAN: PL 42 2490 0005 0000 4600 1184 3564
BIC/SWIFT: ALBPPLPW
"Pod sercem. Wielkopostna akcja charytatywna"

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Zapisz [#23] Okruchy 2 [PL/SK]
 - [https://www.youtube.com/watch?v=rlmO_LyorZo](https://www.youtube.com/watch?v=rlmO_LyorZo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-03-15 00:00:00+00:00

@Langustanapalmie @Stacja7pl 

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

