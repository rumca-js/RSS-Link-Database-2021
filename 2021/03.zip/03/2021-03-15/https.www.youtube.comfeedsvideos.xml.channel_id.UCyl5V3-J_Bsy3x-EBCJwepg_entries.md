# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Game Show — Is This Like The Nazis?
 - [https://www.youtube.com/watch?v=k_k6Qgvyveg](https://www.youtube.com/watch?v=k_k6Qgvyveg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-16 00:00:00+00:00

Watch this epic fail caught on live television at a recording of America’s favorite game show “Is This Like The Nazis?!”

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation​  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast...​

Submit Your Own Headlines: https://babylonbee.com/plans​

The Official The Babylon Bee Store: https://shop.babylonbee.com​

Follow The Babylon Bee:
Website: https://babylonbee.com​
Twitter: http://twitter.com/thebabylonbee​
Facebook: http://facebook.com/thebabylonbee​
Instagram: http://instagram.com/thebabylonbee

## Liberty and Kid's books: Julie Borowski Interview
 - [https://www.youtube.com/watch?v=FfcYLOySF1M](https://www.youtube.com/watch?v=FfcYLOySF1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-16 00:00:00+00:00

In this episode of The Babylon Bee Podcast, Kyle and Ethan talk to YouTube influencer and Libertarian advocate, Julie Borowski. Kyle and Ethan talk to Julie about the failing Libertarian party, disciplining, and anarchy.  While working at FreedomWorks, Julie rose to YouTube and Facebook fame by being a young voice for the Libertarian Party. She has since written two children books titled  Nobody Knows How To Make A Pizza and The Peaceful Porcupine. 

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Teacher's Union Negotiates a Few Simple Demands Before Going Back to Class
 - [https://www.youtube.com/watch?v=jvqW7yIAzKc](https://www.youtube.com/watch?v=jvqW7yIAzKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-15 00:00:00+00:00

With restrictions lifting, this teacher's union makes a few simple demands before going back to the classroom.

Submit Your Own Headlines: https://babylonbee.com/plans​

The Official The Babylon Bee Store: https://shop.babylonbee.com​

Follow The Babylon Bee:
Website: https://babylonbee.com​
Twitter: http://twitter.com/thebabylonbee​
Facebook: http://facebook.com/thebabylonbee​
Instagram: http://instagram.com/thebabylonbee

