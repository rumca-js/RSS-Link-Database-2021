# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## LOTR Loses Cast Member💔 D&D EXPLOSION🧨 Inheritance Adaptation🎞️- FANTASY NEWS
 - [https://www.youtube.com/watch?v=LmQD1sbShro](https://www.youtube.com/watch?v=LmQD1sbShro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-03-16 00:00:00+00:00

There is news. Maybe it's fantasy related. Maybe it's not. Let's talk about that! 
Check out my baby daddy Campfire here today: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20  

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 

00:00 intro

00:27 Inheritance Trilogy Adaptation: https://deadline.com/2021/03/the-inheritance-trilogy-searchlight-tv-nk-jemisons-fantasy-books-series-westbrook-1234710966/ 

02:16 City of Ghosts: https://www.instagram.com/p/CMSxoYsgMTy/?igshid=3ymmxrvsm6ec 

02:51 The Desert Prince: https://twitter.com/PVBrett/status/1369301800738754563?s=19 

03:13 Dark Rise: https://www.instagram.com/p/CMVaopdgcKr/?igshid=13t4ajofk51ge  

04:12 Witcher set: https://redanianintelligence.com/2021/03/12/new-pictures-of-the-witcher-season-2s-massive-new-suggest-geralt-is-headed-to-oxenfurt/ 

05:44 D&D Growth: https://www.cnbc.com/2021/03/13/dungeons-dragons-had-its-biggest-year-despite-the-coronavirus.html 

07:49 Warhammer new content: https://www.warhammer-community.com/2021/03/10/introducing-the-next-wave-of-warhammer-animations/ 

The Exodite (Warhammer): https://www.youtube.com/watch?v=Jz8iJN9L5qA 

08:30 LOTR Loses Cast Member: https://www.comingsoon.net/tv/news/1166446-tom-budge-departs-amazons-the-lord-of-the-rings-series 

09:15 Justice League Trailer: https://www.youtube.com/watch?v=ZrdQSAX2kyw 

10:06 The Irregulars: https://www.youtube.com/watch?v=lTE5MAGpflw&t=12s

