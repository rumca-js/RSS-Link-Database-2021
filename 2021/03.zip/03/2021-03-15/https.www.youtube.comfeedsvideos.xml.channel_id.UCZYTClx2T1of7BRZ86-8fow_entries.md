# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Do Our Bones Make Our Blood?
 - [https://www.youtube.com/watch?v=_zJzTMuemBI](https://www.youtube.com/watch?v=_zJzTMuemBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-03-16 00:00:00+00:00

Our bones are multi-functional body builders, but perhaps their most mysterious function is the production of blood. Scientists now think they have a pretty good idea why this is where our blood gets made. 

Go to http://Brilliant.org/SciShow to try their Physics of the Everyday course. Sign up now and get 20% off an annual Premium subscription.

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org

----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Charles Copley, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:https://doi.org/10.1038/s41586-018-0213-0 https://pubmed.ncbi.nlm.nih.gov/21566758/https://pubmed.ncbi.nlm.nih.gov/29907823/https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1555080/https://stemcells.nih.gov/info/2001report/chapter5.htm Image Sources:https://www.storyblocks.com/video/stock/dancing-skeleton--animation-green-background-loop-h_n-gx1cwkjgtc7lghttps://www.istockphoto.com/photo/northern-cardinal-gm172262353-3715783https://www.istockphoto.com/photo/topical-saltwater-clownfish-gm108270220-9016363https://www.istockphoto.com/photo/red-eyed-tree-frog-smile-gm1049028724-280573845https://www.istockphoto.com/vector/dog-bone-gm481971399-22818540https://www.istockphoto.com/photo/blood-cells-gm1257429592-368507071https://www.istockphoto.com/vector/vector-background-gm1167677658-322110997https://www.istockphoto.com/vector/hematopoietic-stem-cell-gm499405345-42410804https://www.istockphoto.com/vector/vector-set-of-sun-icons-gm1163216334-319333753https://www.istockphoto.com/vector/human-bone-anatomy-gm1218464203-356050584https://www.istockphoto.com/vector/blackboard-chalkboard-green-empty-gm481131675-36861090https://www.storyblocks.com/video/stock/underwater-ocean-waves-ripple-and-flow-with-light-rays-loop-sfjmg3-hxix9gmruuhttps://www.istockphoto.com/vector/people-have-heatstroke-concept-illustration-gm858472098-141632245https://www.nature.com/articles/s41586-018-0213-0#citeashttps://www.istockphoto.com/vector/vector-illustration-of-blue-umbrella-vector-set-on-white-background-gm1131169719-299428618https://www.istockphoto.com/vector/bright-rays-background-gm1157721782-315979058https://www.istockphoto.com/vector/skelettben-gm1062656882-284101041https://www.storyblocks.com/video/stock/inspection-of-blood-in-the-blood-vessels-of-the-circulatory-system-soy0swk5ika4wmtyihttps://www.istockphoto.com/vector/conveyor-belt-with-cardboard-boxes-at-factory-gm1275766018-375786051https://www.istockphoto.com/vector/drop-gm1081786788-290097354https://www.istockphoto.com/vector/safety-goggles-isolated-on-blue-background-with-a-shadow-underneath-gm833076746-135581363https://www.istockphoto.com/vector/creative-vector-illustration-of-factory-line-manufacturing-industrial-plant-scen-gm1136878200-302941711

## Cephalopods Have a Totally Wild Way of Adapting
 - [https://www.youtube.com/watch?v=dg86BVdufyI](https://www.youtube.com/watch?v=dg86BVdufyI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-03-15 00:00:00+00:00

With their squishy bodies and color-changing abilities, octopuses and other cephalopods already look like our planet’s resident aliens. But researchers have discovered yet another thing that separates them from most other animals on Earth!

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Charles Copley, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://doi.org/10.1016/j.cell.2017.03.025
https://doi.org/10.7554/eLife.05198 
https://doi.org/10.1093/nar/gkaa172
https://doi.org/10.1038/s41587-019-0013-6
https://doi.org/10.1093/mollus/eyw052
https://doi.org/10.1126/science.1212795
https://pubmed.ncbi.nlm.nih.gov/29182635/

Image sources: 
Thank you to 7Seil for the footage of an octopus opening a jar! (https://youtu.be/_xfDYs_6rUk)
https://www.istockphoto.com/vector/genetics-flat-design-baby-icon-gm915904400-252052163
https://www.istockphoto.com/photo/cuttlefish-gm139531609-667477
https://www.istockphoto.com/vector/education-icons-gm538049914-95611693
https://www.istockphoto.com/vector/cooking-class-chef-cook-stick-figure-pictogram-icons-gm496989862-78859591
https://www.istockphoto.com/vector/set-of-kitchen-utensil-icon-gm1296529250-389920253
https://www.istockphoto.com/vector/hot-pepper-flat-design-mexico-icon-with-side-shadow-gm926930526-254309654
https://www.istockphoto.com/vector/salt-or-pepper-shaker-icon-gm944153334-257926040
https://www.eurekalert.org/multimedia/pub/227559.php
https://www.istockphoto.com/photo/octopus-vulgaris-gm655094820-120552077
https://www.eurekalert.org/multimedia/pub/227560.php?from=459271
https://www.istockphoto.com/photo/a-nautilus-in-the-beautiful-blue-ocean-gm140789712-19146667
https://www.istockphoto.com/photo/octopus-tentacles-and-suckers-gm507858277-45917644

