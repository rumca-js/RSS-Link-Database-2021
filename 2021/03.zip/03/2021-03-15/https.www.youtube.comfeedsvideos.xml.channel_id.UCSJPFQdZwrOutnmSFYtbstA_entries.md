# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Tomb Raider - The Movie Everybody Forgot
 - [https://www.youtube.com/watch?v=XL-N2Girifg](https://www.youtube.com/watch?v=XL-N2Girifg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-03-16 00:00:00+00:00

2018's Tomb Raider reboot starring Alicia Vikander, was about as bland and forgettable as movies come. But why did it fail to make an impression? Grab your dual pistols, and let's find out.


Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8%3Fref=dbs_a_mng_rwt_scns_share
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on SubscribeStar: https://www.subscribestar.com/the-critical-drinker

