# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## No-one is going to save Covehithe
 - [https://www.youtube.com/watch?v=OW5MlvvqGjM](https://www.youtube.com/watch?v=OW5MlvvqGjM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-03-15 00:00:00+00:00

On the south-east coast of England sits Covehithe: a little Suffolk village going back at least a thousand years. By the end of the century, it'll likely have fallen into the sea. Here's why no-one's planning to save it.

Filmed safely: https://www.tomscott.com/safe/

SOURCES:

Shoreline Management Plans:
https://www.eastsuffolk.gov.uk/environment/coastal-management/shoreline-management-plans/
http://www.suffolksmp2.org.uk/actionplan/docs/2.%20Kessingland%20to%20Covehithe.pdf
https://web.archive.org/web/20140221104223/http://www.suffolksmp2.org.uk/publicdocuments/finalsmp/Section%204_Policy%20Development%20Zones/PDZ2v9.pdf

Article:
https://web.archive.org/web/20160913051551/http://www.edp24.co.uk/news/environment/covehithe_landowner_raises_fears_over_coastal_defence_proposals_1_1111983

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

