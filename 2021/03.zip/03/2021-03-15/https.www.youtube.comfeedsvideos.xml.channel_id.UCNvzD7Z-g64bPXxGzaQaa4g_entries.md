# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 SUPERHERO Mods That Give You EXTRAORDINARY Powers
 - [https://www.youtube.com/watch?v=A4bRXw1rF64](https://www.youtube.com/watch?v=A4bRXw1rF64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-16 00:00:00+00:00

SuperHero PC Game Mods: The creative modding world works hard to bring us super hero experiences in games that don't include them out of the box. Here are some of our favorites for Iron Man, Hulk, and more!
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources and references:

10. Ironman v2.0 - GTA 5

ref: http://gtaxscripting.blogspot.com/2015/08/ironmanv-installation-guide-armors-and.html



9. Thor Endgame script mod - Free Version 1.0 - GTA 5

ref: https://www.gta5-mods.com/scripts/thor-endgame-script-mod-free-version#comments_tab



8. Retro Superhero mod - Fallout: New Vegas

ref: https://www.nexusmods.com/newvegas/mods/68938/?tab=posts


7. Magneto mod - GTA 5

ref: https://gtaxscripting.blogspot.com/2018/09/gta-v-magneto-script-mod.html



6. Mutant powers - Fallout 4

ref: https://www.nexusmods.com/fallout4/mods/24419/

vid: https://www.youtube.com/watch?v=TIvBjOz3x_c



5. New The Flash script Mod - GTA 5

ref: http://gtaxscripting.blogspot.com/2016/04/gta-v-flash-script-mod-nibstyle.html




4. Real Flying SE - Skyrim Special Edition

ref: https://www.nexusmods.com/skyrimspecialedition/mods/18347?tab=posts



3 The Hulk script mod - GTA 5

ref: http://gtaxscripting.blogspot.com/2018/07/gta-v-new-hulk-script-mod.html




2. The Spiderman mod - GTA 5

ref: https://gtaxscripting.blogspot.com/2019/03/gta-v-spiderman-mod-by-julionib.html



1. Ultimate Superman Script mod - GTA 5

ref: https://www.gta5-mods.com/scripts/ultimate-superman-script-mod

## 10 Problems ONLY 2000s Gamers Faced
 - [https://www.youtube.com/watch?v=dw4nVPXUGlw](https://www.youtube.com/watch?v=dw4nVPXUGlw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-15 00:00:00+00:00

The 2000s were a golden age for video games, but the hobby wasn't without some annoyances. Here are some gaming problems we don't miss.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

