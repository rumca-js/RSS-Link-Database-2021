# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 5 Unsolved Space Mysteries | Answers With Joe
 - [https://www.youtube.com/watch?v=mP2FmbhU_-k](https://www.youtube.com/watch?v=mP2FmbhU_-k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-03-15 00:00:00+00:00

Go to http://www.mackweldon.com/joescott and enter promo code "JOESCOTT" at checkout to get 20% off your first order. 
Space has been blowing our minds from the beginning. And yet it feels like every question we answer only brings up more questions. From evidence of a parallel universe to the young surface of Venus to everybody's favorite, Omuamua, here are 5 space mysteries that have not yet fully been solved.

Watch this video ad-free on Nebula: https://nebula.tv/videos/joe-scott-5-unsolved-space-mysteries


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

Time Stamps:
00:00 - Intro
01:32 - The Star That Disappeared
04:37 - The Neutrino From a Parallel Universe
09:17 - Omuamua
13:00 - Why Is The Surface Of Venus So Young?
15:45 - What's The Source Of Cosmic Rays?

