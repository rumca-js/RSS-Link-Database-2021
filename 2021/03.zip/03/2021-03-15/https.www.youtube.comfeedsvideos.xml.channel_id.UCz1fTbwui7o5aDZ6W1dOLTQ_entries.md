# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Can Mary Sues Have Flaws?
 - [https://www.youtube.com/watch?v=W7CtqvjdnAY](https://www.youtube.com/watch?v=W7CtqvjdnAY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2021-03-15 00:00:00+00:00

The dreaded Mary Sue has become one of the most infamous elements in fiction. While the argument for the specific definition rages on - one of the largest issues has been the subject of flaws. Normally, flawlessness is a clear sign that a character is a Mary Sue, but is that really true? Let's see.
New Intro by: https://www.youtube.com/channel/UCS4jTMx3GHWZLlT7Rqy5GTQ

Common Mary Sue Tropes: https://tvtropes.org/pmwiki/pmwiki.php/Main/CommonMarySueTraits

Rey's Weakness: https://www.forbes.com/sites/erikkain/2018/03/10/star-wars-star-daisy-ridley-says-that-rey-has-no-weaknesses/?sh=2881a8ac4418

Art of Rey looking up at the sky: Derek Horne

Tutorial Demon artwork: (Xofrats) https://twitter.com/xofrats

Tutorial Demon voice: (Blue Teddy Narrations) https://www.youtube.com/channel/UCuzypZLbHNm5uil7WisBL5w

