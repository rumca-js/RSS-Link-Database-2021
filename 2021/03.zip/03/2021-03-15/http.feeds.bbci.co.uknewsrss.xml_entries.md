# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'We wanted three dirty points' - Klopp pleased with Jota winner at Wolves
 - [https://www.bbc.co.uk/sport/football/56316869](https://www.bbc.co.uk/sport/football/56316869)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 23:38:10+00:00

Diogo Jota rekindles Liverpool's Premier League top-four hopes with the winning goal on his return to Molineux in a game that ends with a worrying head injury to Wolves goalkeeper Rui Patricio.

## Pickleball: The racquet sport experiencing a pandemic boom
 - [https://www.bbc.co.uk/news/world-us-canada-56324048](https://www.bbc.co.uk/news/world-us-canada-56324048)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 23:03:32+00:00

Pickleball - a mash-up of tennis, badminton and ping-pong - saw a surge in participation last year.

## Australia March 4 Justice: Thousands march against sexual assault
 - [https://www.bbc.co.uk/news/world-australia-56406043](https://www.bbc.co.uk/news/world-australia-56406043)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 22:29:57+00:00

Tens of thousands of people across Australia protested against abuse and harassment.

## Covid: The inside story of the government's battle against the virus
 - [https://www.bbc.co.uk/news/uk-politics-56361599](https://www.bbc.co.uk/news/uk-politics-56361599)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 21:52:17+00:00

Twenty of Downing Street's most senior politicians, officials and former officials take you "into the room" where essential Covid decisions were being made.

## Sarah Everard vigil: 'All I wanted was to stand with other women'
 - [https://www.bbc.co.uk/news/uk-56402418](https://www.bbc.co.uk/news/uk-56402418)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 18:14:18+00:00

Why hundreds of women felt compelled to take part in the vigil for Sarah Everard - despite being told it was cancelled.

## Everyone’s Invited: Children recount 'rape culture' experiences
 - [https://www.bbc.co.uk/news/technology-56407441](https://www.bbc.co.uk/news/technology-56407441)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 18:07:55+00:00

More than 4,000 people have submitted their experiences to an online platform.

## Jed Mercurio: Line of Duty 'still in post-production'
 - [https://www.bbc.co.uk/news/entertainment-arts-56408763](https://www.bbc.co.uk/news/entertainment-arts-56408763)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 17:52:52+00:00

Line of Duty writer Jed Mercurio says the new series is still not ready, despite airing on Sunday.

## Oscars nominations 2021: Baron-Cohen, Mulligan and Kaluuya in the running
 - [https://www.bbc.co.uk/news/entertainment-arts-56363640](https://www.bbc.co.uk/news/entertainment-arts-56363640)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 12:48:06+00:00

Sacha Baron-Cohen, Carey Mulligan and Daniel Kaluuya and are among the UK actors in the running.

## Sarah Everard killing: Police search Sandwich town centre
 - [https://www.bbc.co.uk/news/uk-england-london-56399057](https://www.bbc.co.uk/news/uk-england-london-56399057)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 12:44:31+00:00

Police investigating the death of the 33-year-old cordon off part of Sandwich, Kent.

## Wildfires: Cambridgeshire archive saves couple's wedding album
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-56401868](https://www.bbc.co.uk/news/uk-england-cambridgeshire-56401868)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 12:41:21+00:00

Chris and Lindy Date, who married in the UK in 1963, lost everything in the 2020 US wildfires.

## Court of Appeal rejects claim CPS approach to rape prosecution was 'unlawful'
 - [https://www.bbc.co.uk/news/uk-56402068](https://www.bbc.co.uk/news/uk-56402068)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 12:15:28+00:00

Campaigners had argued changes in approach made by the Crown Prosecution Service were "unlawful".

## Sarah Everard vigil: Boris Johnson 'deeply concerned' by footage
 - [https://www.bbc.co.uk/news/uk-56396960](https://www.bbc.co.uk/news/uk-56396960)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 12:04:25+00:00

Police officers handcuffed women and removed them from the gathering on Clapham Common on Saturday.

## Smith Rowe and Hudson-Odoi named in strong England U21 Euros squad
 - [https://www.bbc.co.uk/sport/football/56400395](https://www.bbc.co.uk/sport/football/56400395)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 11:48:09+00:00

Mason Greenwood, Callum Hudson-Odoi & Emile Smith Rowe named in a strong England squad for next week's Uefa U21 Euro finals group stage.

## Covid-19: Netherlands suspends use of AstraZeneca vaccine
 - [https://www.bbc.co.uk/news/world-europe-56397157](https://www.bbc.co.uk/news/world-europe-56397157)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 11:16:08+00:00

It is the latest country to act over reports of blood clotting, but the WHO says the vaccine is safe.

## Redcar rescue: Man who pulled girl from sea 'acted on instinct'
 - [https://www.bbc.co.uk/news/uk-england-tees-56400548](https://www.bbc.co.uk/news/uk-england-tees-56400548)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 10:06:56+00:00

Cleveland Police said those that tried to help the 10-year-old girl were "heroes".

## No sanction for two-day Test pitch in Ahmedabad
 - [https://www.bbc.co.uk/sport/cricket/56400857](https://www.bbc.co.uk/sport/cricket/56400857)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 09:59:52+00:00

The Ahmedabad pitch on which India beat England in two days in the third Test will not be punished by the International Cricket Council.

## Cost of living: Hand gel in, white chocolate out
 - [https://www.bbc.co.uk/news/business-56395533](https://www.bbc.co.uk/news/business-56395533)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 09:31:07+00:00

Loungewear and smart watches are other commonly bought goods now used to measure changes in the cost of living.

## Covid: Hairdressers reopen in Wales as lockdown eases
 - [https://www.bbc.co.uk/news/uk-wales-56379279](https://www.bbc.co.uk/news/uk-wales-56379279)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 08:34:53+00:00

One salon owners says some of her clients burst into tears on being told they were reopening.

## Miles of new bus lanes and more services promised
 - [https://www.bbc.co.uk/news/business-56395526](https://www.bbc.co.uk/news/business-56395526)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 08:28:11+00:00

Ministers say a £3bn plan to upgrade England's bus networks will improve access and air quality.

## Lions watch - Owens & Sexton shine, while England stars redeem themselves
 - [https://www.bbc.co.uk/sport/rugby-union/56396029](https://www.bbc.co.uk/sport/rugby-union/56396029)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 08:00:40+00:00

England players redeem themselves, while Wales' Ken Owens and Ireland's Johnny Sexton impress as the 2021 British and Irish Lions tour draws closer.

## O'Connell masterminds Scots' downfall in loss to Ireland
 - [https://www.bbc.co.uk/sport/rugby-union/56389656](https://www.bbc.co.uk/sport/rugby-union/56389656)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 07:25:13+00:00

Scotland's British & Irish Lions hopes could be dashed along with their Six Nations chances after defeat by Ireland, writes Tom English.

## Review: The Grammy Awards reflect a year of solitude and protest
 - [https://www.bbc.co.uk/news/entertainment-arts-56398165](https://www.bbc.co.uk/news/entertainment-arts-56398165)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 07:01:22+00:00

Quarantine songs and Black Lives Matter anthems defined this year's music awards.

## Australia March 4 Justice: Thousands march against sexual assault
 - [https://www.bbc.co.uk/news/world-australia-56397170](https://www.bbc.co.uk/news/world-australia-56397170)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 06:22:54+00:00

The wave of protests follow a backlash to the government's response to rape allegations.

## Grammys 2021: Five weird and wonderful moments
 - [https://www.bbc.co.uk/news/entertainment-arts-56397661](https://www.bbc.co.uk/news/entertainment-arts-56397661)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 06:06:07+00:00

Harry Styles, Dua Lipa and Megan Thee Stallion all put on a spectacle. But who are Silk Sonic?

## The Papers: 'Shaming of the Met', and chief 'refuses to quit'
 - [https://www.bbc.co.uk/news/blogs-the-papers-56396945](https://www.bbc.co.uk/news/blogs-the-papers-56396945)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 05:49:39+00:00

Fallout from police's handling of the Clapham Common vigil for Sarah Everard dominates the papers.

## Grammys 2021: Beyoncé and Taylor Swift make history
 - [https://www.bbc.co.uk/news/entertainment-arts-56397324](https://www.bbc.co.uk/news/entertainment-arts-56397324)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 03:48:39+00:00

Beyoncé picks up a record-breaking 28th award, while Taylor Swift wins her third album of the year.

## Avatar reclaims title as highest-grossing film
 - [https://www.bbc.co.uk/news/business-56397511](https://www.bbc.co.uk/news/business-56397511)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 02:17:31+00:00

Disney said the blockbuster film regained top spot over the weekend knocking off Avengers: End Game.

## Grammy Awards 2021: Red carpet in pictures
 - [https://www.bbc.co.uk/news/entertainment-arts-56396203](https://www.bbc.co.uk/news/entertainment-arts-56396203)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 01:54:06+00:00

The stars swapped their lockdown outfits for glad rags on "music's biggest night".

## Coronavirus doctor's diary: Has Covid changed hospitals for the better?
 - [https://www.bbc.co.uk/news/health-56379088](https://www.bbc.co.uk/news/health-56379088)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 01:04:53+00:00

Dr John Wright of Bradford Royal Infirmary says some changes made as a result of the pandemic are here to stay.

## Curlew: Urgent work needed to save 'loved' endangered bird
 - [https://www.bbc.co.uk/news/uk-england-gloucestershire-56370427](https://www.bbc.co.uk/news/uk-england-gloucestershire-56370427)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 01:04:13+00:00

A new project is aiming to aid the recovery of the curlew, with its numbers in steep decline.

## India's interfaith couples on edge after new law
 - [https://www.bbc.co.uk/news/world-asia-india-56330206](https://www.bbc.co.uk/news/world-asia-india-56330206)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:46:18+00:00

A Hindu-Muslim couple, who dated secretly for 13 years, are now facing a fresh obstacle: the government.

## Viewpoint: France's President Macron doesn't get the impact of colonialism on Algeria
 - [https://www.bbc.co.uk/news/world-africa-56360817](https://www.bbc.co.uk/news/world-africa-56360817)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:43:55+00:00

The French president may not be able to repair relations with Algerians, argues writer Maher Mezahi.

## We asked for your first Covid text messages. These are your stories
 - [https://www.bbc.co.uk/news/world-us-canada-56338916](https://www.bbc.co.uk/news/world-us-canada-56338916)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:40:08+00:00

The US didn’t shut down until late March, but Americans were talking about the virus before that.

## Discovering WW1 tunnel of death hidden in France for a century
 - [https://www.bbc.co.uk/news/world-europe-56370510](https://www.bbc.co.uk/news/world-europe-56370510)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:33:37+00:00

The bodies of 270 German soldiers have lain hidden since they were buried alive by a French bombardment.

## Texas beekeeper viral videos saving bee nests
 - [https://www.bbc.co.uk/news/science-environment-56396914](https://www.bbc.co.uk/news/science-environment-56396914)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:03:18+00:00

Beekeeper Erika Thompson says the video, viewed over a million times, was "just a normal Tuesday".

## 'Interest in e-sports will only grow and grow'
 - [https://www.bbc.co.uk/news/business-56334015](https://www.bbc.co.uk/news/business-56334015)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:02:05+00:00

The global e-sports sector is expected to see revenues of more than $1bn in 2021.

## Tigray crisis: Why Sudan is a ‘second home’ to Ethiopian refugees
 - [https://www.bbc.co.uk/news/world-africa-56374725](https://www.bbc.co.uk/news/world-africa-56374725)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:01:44+00:00

More than 60,000 people have fled the conflict in Ethiopia’s Tigray region to seek refuge in Sudan.

## Nagorno-Karabakh: A home regained and a home lost in war
 - [https://www.bbc.co.uk/news/world-europe-56379811](https://www.bbc.co.uk/news/world-europe-56379811)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:01:35+00:00

How lives on both sides of the divide in Nagorno-Karabakh were changed by the last year's fighting.

## Coronavirus: 'I lost my job and launched a pop-up food business'
 - [https://www.bbc.co.uk/news/business-56298180](https://www.bbc.co.uk/news/business-56298180)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-15 00:01:34+00:00

Online takeaway deliveries have soared in the pandemic and some firms are stronger for making them.

