## Florida Sees Same COVID Case Rate as California, Despite No Statewide Restrictions
 - [https://www.newsweek.com/florida-sees-same-covid-case-rate-california-despite-no-statewide-restrictions-1576211](https://www.newsweek.com/florida-sees-same-covid-case-rate-california-despite-no-statewide-restrictions-1576211)
 - RSS feed: https://www.newsweek.com
 - date published: 2021-03-15 19:24:58+00:00

Florida Sees Same COVID Case Rate as California, Despite No Statewide Restrictions

