# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Disney PC is REAL and WE GOT ONE!
 - [https://www.youtube.com/watch?v=pKpAcBZUPuc](https://www.youtube.com/watch?v=pKpAcBZUPuc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-16 00:00:00+00:00

Get PDFelement 50% off deals here: https://bit.ly/37yN4uz 
Download #PDFelement to Edit PDF files: https://bit.ly/3sfFBZ9 

Save at least 15% site-wide and Free Worldwide Shipping at Ridge Wallet! Celebrate their 8th Anniversary by using offer code LINUS at https://www.ridge.com/LINUS

Disney, the company famous for its beloved animated films and shows, made a computer in the early 2000s… but why tho?

Discuss on the forum: https://linustechtips.com/topic/1315876-the-disney-pc-is-real-and-we-got-one/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## AMD is Dumb… like a FOX! - AMD EPYC Milan Announcement
 - [https://www.youtube.com/watch?v=xKj5sMVsMf8](https://www.youtube.com/watch?v=xKj5sMVsMf8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-15 00:00:00+00:00

Get 20% OFF + Free Shipping @manscaped with code TECH at https://manscaped.com/TECH

Buy a Seasonic Ultra Titanium Power Supply:
On Amazon: https://geni.us/q4lnefC
On NewEgg: https://lmg.gg/8KV3S
On Best Buy: https://geni.us/u5Wm


Fittings: https://www.ekwb.com/shop/fittings

RAM: https://www.micron.com/products/dram

GPU: https://www.asus.com/Motherboards-Components/Graphics-Cards/ASUS/RTX3090-24G-EK/

PSU: https://www.silverstonetek.com/product.php?pid=835&area=en

Buy Silverstone Sugo 15 (PAID LINK): https://geni.us/hcfEwT

Buy AMD EPYC CPUs (PAID LINK): https://geni.us/5wGpHpW

Check out the ASRock ROMED4ID-2T Motherboard at https://lmg.gg/6dNmY

Buy EKWB Fittings (PAID LINK): https://geni.us/6BmKq3y

Check out the Micron RAM used at https://lmg.gg/JP07Q

Buy ASUS EKWB GeForce RTX 3090 (PAID LINK): https://geni.us/k5pb4T

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1315389-amd-is-dumb%E2%80%A6-like-a-fox/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

