# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Retro Tech: Wearables
 - [https://www.youtube.com/watch?v=aFcoVbaKBP8](https://www.youtube.com/watch?v=aFcoVbaKBP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-03-15 00:00:00+00:00

I’m looking at wearable tech and how it’s developed over the years. I’m talking to Wyatt Cenac about everything from the first ever wearable computer glasses in 1984 to ‘90s cyber-fashion shows to the 21st century’s Google Glass. I’m also joined by both Austin Evans and Michael Gregory to check out old sneaker tech.

