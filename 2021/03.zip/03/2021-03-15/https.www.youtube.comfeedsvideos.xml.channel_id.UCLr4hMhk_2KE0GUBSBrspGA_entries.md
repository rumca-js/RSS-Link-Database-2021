# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Huawei Mate X2 - Tak powinien wyglądać składany smartfon
 - [https://www.youtube.com/watch?v=acQBqTAR7YU](https://www.youtube.com/watch?v=acQBqTAR7YU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-03-16 00:00:00+00:00

Nie było łatwo dorwać tego składaka, ale się udało. W tym filmie wyłączyłem reklamy, ponieważ pod koniec znajduje się fragment sponsorowany.
Aplikacja ZEN: https://bit.ly/3rklh8W (kod przedłużający okres próbny: klawyzen)

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

Spis treści:
00:00 Huawei Mate X2 – idealny składany smartfon?
00:25 Wygląd i ekrany: Samsung Z Fold 2 vs Huawei Mate X2
02:05 Odblokowywanie
02:45 Miejsce zgięcia
03:30 Pierwsze wrażenia
04:08 Ekrany
04:36 Cena
05:07 Brak usług Google
06:46 Składany smartfon – innowacja godna polecenia?
07:55 Fragment sponsorowany – ZEN
08:47 Pożegnanie

