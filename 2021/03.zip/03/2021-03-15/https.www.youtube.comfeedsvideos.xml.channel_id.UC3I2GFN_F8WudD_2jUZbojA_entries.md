# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Georgia - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=w15wmKlb1ek](https://www.youtube.com/watch?v=w15wmKlb1ek)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-16 00:00:00+00:00

http://KEXP.ORG presents Georgia performing live, recorded exclusively for KEXP.

Songs:
Started Out
24 Hours
Running Up That Hill
About Work the Dance Floor
Ultimate Sailor

Session recorded and filmed by Tristan Cassel-Delavois and Nick Peill
Edited by Tony Giambrone

https://georgiauk.com
http://kexp.org

## Georgia - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=NIgv-WjEmfI](https://www.youtube.com/watch?v=NIgv-WjEmfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-15 00:00:00+00:00

http://KEXP.ORG presents Georgia sharing a live performance recorded exclusively for KEXP and talking with Kevin Cole. Recorded March 2, 2021.

Songs:
Started Out
24 Hours
Running Up That Hill
About Work the Dance Floor
Ultimate Sailor

Session recorded and filmed by Tristan Cassel-Delavois and Nick Peill
Edited by Tony Giambrone

https://georgiauk.com
http://kexp.org

