# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The "FREE BOOK" That Costs $150/month
 - [https://www.youtube.com/watch?v=7e6kyuRUDBI](https://www.youtube.com/watch?v=7e6kyuRUDBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-16 00:00:00+00:00

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## What Linus Tech Tips DIDN'T Tell You About NiceHash
 - [https://www.youtube.com/watch?v=oZz-kKED2vI](https://www.youtube.com/watch?v=oZz-kKED2vI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-15 00:00:00+00:00

Gotta get that crypto money!!! 🤑 🤑 🤑

A great writeup on nicehash's founder: https://krebsonsecurity.com/tag/matjaz-skorjanc/
The U.S. Indictment
https://krebsonsecurity.com/wp-content/uploads/2019/10/newdarkodecharges.pdf
Linus Tech Tips video:
https://www.youtube.com/watch?v=swOj0wvuCO8&

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

