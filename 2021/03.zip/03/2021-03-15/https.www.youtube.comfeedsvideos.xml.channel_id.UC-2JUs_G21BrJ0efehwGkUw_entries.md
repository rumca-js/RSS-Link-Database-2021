# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Man in the Mirror | Michael Jackson | funk cover ft. Rozzi + MonoNeon
 - [https://www.youtube.com/watch?v=dv9RpfoByUA](https://www.youtube.com/watch?v=dv9RpfoByUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-03-15 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Michael Jackson's "Man in the Mirror" by Scary Pockets & Rozzi.

MUSICIAN CREDITS
Lead vocal: Rozzi
Drums: Tamir Barzilay
Bass: MonoNeon
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Cinematography: Ricky Chavez
Director: Mike Dempsey
Camera Operators: Ricky Chavez, Sammy Rothman, Alex Humphrey
Editor: Adam Kritzberg

Recorded Live at EastWest in Los Angeles, CA.

#ScaryPockets #Funk #MichaelJackson #ManInTheMirror #Rozzi

