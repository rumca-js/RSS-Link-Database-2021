# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## The Woke Mob Wants YOU! (Recruitment Video)
 - [https://www.youtube.com/watch?v=YqktEsc6JYc](https://www.youtube.com/watch?v=YqktEsc6JYc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-03-16 00:00:00+00:00

Grab your Blue Light Blocking Glasses Here - https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

The woke mob once you! In this recruitment video you’ll see all the perks and wife enhancing benefits of serving your country by joining the work mob. Radical left culture needs your service. Join the woke mob today!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

