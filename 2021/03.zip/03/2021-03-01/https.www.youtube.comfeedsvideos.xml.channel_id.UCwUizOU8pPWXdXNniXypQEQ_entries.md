# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Woke Anti-Racism Training
 - [https://www.youtube.com/watch?v=7LiztqtsIL8](https://www.youtube.com/watch?v=7LiztqtsIL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-03-02 00:00:00+00:00

Grab your BluBlox Glasses Here - https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here is the most intelligent woke anti-racism training available! Combined the wisdom of Coca-Cola’s anti-racism training with non-nuanced thought about white fragility and you have the cure for systemic racism. And best of all it’s 100% WOKE certified.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## Gov Funded Transgender Surgery for Kids?! - A Week In News
 - [https://www.youtube.com/watch?v=FxudQgoG4-c](https://www.youtube.com/watch?v=FxudQgoG4-c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-03-01 00:00:00+00:00

Grab your BluBlox Glasses Here - https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Should the government be able to fund sexual reassignment surgery for transgender kids? Should they be able to provide them with puberty blockers, even without the parents consent? Find out the latest with Biden‘s assistant health secretary pack as well as a full lying to your face news update on what’s happening around the world this week.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

