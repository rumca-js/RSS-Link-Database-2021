# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Enola Holmes - Fanciful, Forgettable Fluff
 - [https://www.youtube.com/watch?v=SEHVenNow-o](https://www.youtube.com/watch?v=SEHVenNow-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-03-01 00:00:00+00:00

So I finally got around to watching Enola Holmes, starring Millie Bobby Brown and Henry Cavill, and well... it wasn't quite what I was hoping for. So I thought I'd review it before I completely forget what I even saw.

