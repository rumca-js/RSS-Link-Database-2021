# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does IT: Alexander Brandon - Deus Ex Intro (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=kPDf7SbOLww](https://www.youtube.com/watch?v=kPDf7SbOLww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-02 00:00:00+00:00

Intro theme for Deux Ex by Alexander Brandon.

"Conspiravision: Deus Ex Remixed" from Alexander Brandon & Michiel van den Bos:
https://alexanderbrandon.bandcamp.com/album/conspiravision-deus-ex-remixed

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 28 channels
- 100% flawless playback not guaranteed (the IT replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does S3M: Alexander Brandon - Labratory Level (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=PEcnAQhf8As](https://www.youtube.com/watch?v=PEcnAQhf8As)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-02 00:00:00+00:00

"Labratory Level" by Alexander Brandon for Jazz Jackrabbit 2.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 12 channels
- 100% flawless playback not guaranteed (the S3M replayer is not perfect)

Visit my channel for more Amiga music.

