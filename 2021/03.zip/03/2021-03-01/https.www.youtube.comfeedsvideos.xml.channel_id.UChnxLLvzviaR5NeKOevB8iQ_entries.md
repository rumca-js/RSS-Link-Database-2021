# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Making Drum and Bass with Maschine + and Tracklib
 - [https://www.youtube.com/watch?v=6NVgNxOeLPU](https://www.youtube.com/watch?v=6NVgNxOeLPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-03-01 00:00:00+00:00

Sponsored by Tracklib
Get 15 records on Tracklib to sample from for free: https://www.tracklib.com/subscribe/redmeansrecording
Flipping 3 samples from Tracklib on the Native Instruments Maschine + into a drum and bass track. 
https://www.tracklib.com/song/o-2/#acapella
https://www.tracklib.com/song/kammani-kantireppala/
https://www.tracklib.com/song/epic-proportions/#vocals
Native Instruments Maschine + : https://amzn.to/3pI26nU

00:00 Explanation
03:39 Intro pattern
04:54 Verse 01a
05:58 Verse 01b
07:13 Chorus 1
09:18 Drop 1
12:44 Verse 02a
14:28 Verse 02b
16:37 Chorus 2
17:25 Bridge
18:23 Rap
21:58 OP-1 vs. Maschine thoughts
23:12 Bridge 2
24:45 Drop 2
25:01 Outro 01
26:36 Outro 02
27:47 Song Mode
29:12 Final Track
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

