## Ex-Times Reporter Who Used Racial Slur Publishes a Lengthy Defense - The New York Times
 - [https://www.nytimes.com/2021/03/01/business/donald-mcneil-new-york-times-racial-slur.html](https://www.nytimes.com/2021/03/01/business/donald-mcneil-new-york-times-racial-slur.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2021-03-01 14:25:55+00:00

Ex-Times Reporter Who Used Racial Slur Publishes a Lengthy Defense - The New York Times

