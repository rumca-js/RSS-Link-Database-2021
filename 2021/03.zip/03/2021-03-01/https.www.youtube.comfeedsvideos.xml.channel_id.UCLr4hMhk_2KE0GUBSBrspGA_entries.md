# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## DJI FPV - dron sportowy dla każdego?
 - [https://www.youtube.com/watch?v=9mr1Z1zX-aA](https://www.youtube.com/watch?v=9mr1Z1zX-aA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-03-02 00:00:00+00:00

Latanie dronami DJI stało się właśnie nieco bardziej ekscytujące.
Zapraszam na film przygodowy, niemalże familijny.
Maciek, pilot FPV: https://bit.ly/38jBO5V
Dzięki https://evdlaciebie.pl za udostępnienie Tesli! 
DJI FPV (PL): http://bit.ly/304Re9s

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

W odcinku:
00:00 Czy drony są nudne?
00:21 Dron DJI FPV
01:31 Pierwszy kontakt z dronem FPV - wrażenia
02:14 Możliwości nagrywania foto i video
02:33 Film z lotu
02:49 Funkcja śledzenia w trybie NEUTRAL i SPORT - Mavic Air 2 vs DJI FPV
04:31 Tryb MANUAL i pierwsze wrażenia Maćka - pilota FPV
05:30 DJI FPV a drony customowe
06:15 Symulator od DJI
06:52 Wyścig: DJI FPV vs Tesla
07:29 Pierwszy upadek
08:26 Nagrania z upadku?
09:00 Ustawienia nagrywania
09:18 Zasięg i powrót do domu
10;34 System hamowania awaryjnego
11:17 Drugi upadek
12:52 Szkody po upadku
13:27 Motion controler
14:59 Ceny
15:35 Dla kogo jest dronik garbusek?
16:12 Sam napraw sobie drona
16:52 Do zobaczenia!

