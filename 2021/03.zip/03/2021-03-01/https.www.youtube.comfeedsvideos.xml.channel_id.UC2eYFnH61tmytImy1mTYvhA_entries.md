# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Extreme Vim Macros for Traditionalist Catholics
 - [https://www.youtube.com/watch?v=FXCitlsA7eQ](https://www.youtube.com/watch?v=FXCitlsA7eQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-03-02 00:00:00+00:00

This is how you do pretty advanced actions in vim automatically. In this case, I want vim to automatically insert footnotes taken from the end of a text file in the appropriate place for them to be formatted automatically in a LaTeX document. This would be a huge chore for a Wordcuck or someone using a text editor or IDE without sufficient macro capabilities, but vim makes it pretty easy. Keys are displayed with screenkey.

My website: https://lukesmith.xyz
Please donate: https://lukesmith.xyz/donate
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

BTC: bc1qk2dz5x6m3sjnkzf0mhlz9pmsz4xfjtjmfrgm9d
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://brave.com/luk005 Get the Brave browser.
https://odysee.com/$/invite/@Luke:7 View my videos on Odysee and get a bonus for joining.
https://www.coinex.com/register?refer_code=ndf87 Get crypto-rich on Coinex. Get reduced exchange fees for 3 months.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

