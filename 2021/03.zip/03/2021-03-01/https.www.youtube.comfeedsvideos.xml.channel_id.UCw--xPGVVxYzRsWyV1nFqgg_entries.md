# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Henry Cavil for Mass Effect?🛸 Philip Pullman Criticizes Tolkien!🎭 MTG Gets LotR!💍-FANTASY NEWS
 - [https://www.youtube.com/watch?v=xCu0cJMUOg8](https://www.youtube.com/watch?v=xCu0cJMUOg8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-03-02 00:00:00+00:00

lets jump into the fantasy news!
Checkout Campfire here today: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 

00:00 Intro

00:20 Mass Effect Possibility: https://www.gamepressure.com/newsroom/henry-cavill-reads-mass-effect-suggests-a-secret-project/z02e09 

02:06 Magic LotR / Warhammer Cards: https://www.polygon.com/2021/2/25/22301104/magic-the-gathering-warhammer-40k-lord-of-the-rings-crossover-sets-universes-beyond  

04:45 Dragon Age Update: https://twitter.com/jasonschreier/status/1365005940739743745?s=19  

06:07 The Wood Bee Queen: https://fantasy-hive.co.uk/2021/03/the-wood-bee-queen-by-edward-cox-cover-reveal-and-interview/ 

07:11 Shadow and Bone Trailer: https://www.youtube.com/watch?v=UHJYYd_RnJc 

07:50 Pokemon Acres: https://www.youtube.com/watch?v=YUW1ZWAq09M 

08:48 Philip Pullman Lord Of The Rings comments: https://www.news18.com/news/buzz/exploring-lack-of-women-in-lord-of-the-rings-philip-pullman-calls-tolkiens-magnum-opus-dead-end-3469850.html 

11:47 Twilight Zone Canceled: https://www.hollywoodreporter.com/live-feed/the-twilight-zone-canceled-at-cbs-all-access-exclusive 

11:56 Spirited Away Play: https://ew.com/theater/spirited-away-is-becoming-a-play/

