# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Adrianne Lenker - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=EQdpd6iHTbM](https://www.youtube.com/watch?v=EQdpd6iHTbM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-02 00:00:00+00:00

http://KEXP.ORG presents Adrianne Lenker performing live, recorded exclusively for KEXP.

Songs:
anything
zombie girl
half return
forward beckon rebound

Session Recording:
Directors: Vanessa Haddad and Adam Gundersheimer
Director of Photography: Adam Gundersheimer
Recording/Mixing Engineer: Scott Cornish

https://www.adriannelenker.com
http://kexp.org

## Adrianne Lenker - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=poklSVlQ3X8](https://www.youtube.com/watch?v=poklSVlQ3X8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-01 00:00:00+00:00

http://KEXP.ORG presents Adrianne Lenker sharing a live performance recorded exclusively for KEXP and talking to DJ Morgan. Recorded December 11, 2020.

Songs:
anything
zombie girl
half return
forward beckon rebound

Session Recording:
Directors: Vanessa Haddad and Adam Gundersheimer
Director of Photography: Adam Gundersheimer
Recording/Mixing Engineer: Scott Cornish

https://www.adriannelenker.com
http://kexp.org

