# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The new voice of The Simpsons character Dr Julius Hibbert
 - [https://www.bbc.co.uk/news/world-us-canada-56247935](https://www.bbc.co.uk/news/world-us-canada-56247935)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 23:20:49+00:00

Kevin Richardson is the first black actor to voice Dr Julius Hibbert on the television comedy.

## 'Fake accounts used my pictures to sell sex'
 - [https://www.bbc.co.uk/news/uk-scotland-56182060](https://www.bbc.co.uk/news/uk-scotland-56182060)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 22:48:55+00:00

Women tell BBC Scotland how scammers used their images on fake accounts advertising sex work websites.

## 'Undiscovered Titian painting' found in Ledbury church
 - [https://www.bbc.co.uk/news/uk-england-hereford-worcester-56241825](https://www.bbc.co.uk/news/uk-england-hereford-worcester-56241825)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 22:20:16+00:00

An art historian claims to have found the Renaissance master's signature during restoration work.

## Possible 'Banksy' artwork appears on Reading prison wall
 - [https://www.bbc.co.uk/news/uk-england-berkshire-56231364](https://www.bbc.co.uk/news/uk-england-berkshire-56231364)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 19:47:09+00:00

The street art appears overnight on the side of Reading Prison which is under threat of development.

## The extraordinary rise and fall of trainer Gordon Elliott
 - [https://www.bbc.co.uk/sport/horse-racing/56230013](https://www.bbc.co.uk/sport/horse-racing/56230013)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 19:35:29+00:00

Profile of Irish racehorse trainer Gordon Elliott, who faces an inquiry after being pictured sat on a dead horse.

## Love Island: South Africa's reality show is 'too white'
 - [https://www.bbc.co.uk/news/world-africa-56244227](https://www.bbc.co.uk/news/world-africa-56244227)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 17:34:03+00:00

Viewers are asking why most contestants in the reality show are white in the majority-black country.

## Arsenal's Katie McCabe scores stunner into top corner to seal Aston Villa win
 - [https://www.bbc.co.uk/sport/av/football/56234334](https://www.bbc.co.uk/sport/av/football/56234334)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 13:39:50+00:00

Katie McCabe scores a stunner in the top corner as Arsenal convincingly beat Aston Villa 4-0 in the Women's Super League.

## Covid-19: Brazil variant case in England hunted by officials
 - [https://www.bbc.co.uk/news/uk-56234302](https://www.bbc.co.uk/news/uk-56234302)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 12:15:07+00:00

The whereabouts of one infected person is unknown, as they did not give their full contact details.

## Covid-19: Publication of NI lockdown exit plan delayed
 - [https://www.bbc.co.uk/news/uk-northern-ireland-56233243](https://www.bbc.co.uk/news/uk-northern-ireland-56233243)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 12:14:55+00:00

The blueprint is unlikely to be published until Tuesday, with work to finalise details ongoing.

## Police make arrests after search of Barcelona offices
 - [https://www.bbc.co.uk/sport/football/56236872](https://www.bbc.co.uk/sport/football/56236872)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 11:56:23+00:00

Catalan police make several arrests after searching the offices of La Liga side Barcelona.

## Covid: 'People are tired of working from home'
 - [https://www.bbc.co.uk/news/business-56237586](https://www.bbc.co.uk/news/business-56237586)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 11:07:02+00:00

Canary Wharf expects people to return to the office but may choose home working some of the time.

## UK meteor lights up sky over parts of England
 - [https://www.bbc.co.uk/news/uk-england-bristol-56237596](https://www.bbc.co.uk/news/uk-england-bristol-56237596)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 10:47:45+00:00

A meteor - which was caught on camera - was visible for around seven seconds on Sunday night.

## Aung San Suu Kyi seen for first time since coup
 - [https://www.bbc.co.uk/news/world-asia-56235405](https://www.bbc.co.uk/news/world-asia-56235405)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 10:25:27+00:00

Ms Suu Kyi's appearance follows the deadliest day of protests yet, after 18 people died on Sunday.

## Covid-19: Critical care beds shortage prompts calls for review
 - [https://www.bbc.co.uk/news/uk-56234898](https://www.bbc.co.uk/news/uk-56234898)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 10:08:13+00:00

The UK has 7.3 critical care beds per 100,000 people, compared to Germany's 33.8 and the US's 34.3.

## Trainer Elliott admits dead horse photo is real
 - [https://www.bbc.co.uk/sport/horse-racing/56234556](https://www.bbc.co.uk/sport/horse-racing/56234556)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 10:04:28+00:00

Leading Irish racehorse trainer Gordon Elliott says a photo circulating on social media of him sitting on a dead horse is real.

## Meghan and Harry Oprah interview: Diana discussed in teaser clips
 - [https://www.bbc.co.uk/news/entertainment-arts-56234900](https://www.bbc.co.uk/news/entertainment-arts-56234900)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 09:57:27+00:00

Harry draws parallels between the treatment of his mother and wife, in teaser clips of a TV special.

## Becca Cosmetics: Why lockdown is bad news for make-up brands
 - [https://www.bbc.co.uk/news/newsbeat-56215557](https://www.bbc.co.uk/news/newsbeat-56215557)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 09:26:28+00:00

The Australian company is the first big make-up brand to close its doors due to the global pandemic.

## Tomahawk Steakhouse staff told 'loan firm 10% or face sack'
 - [https://www.bbc.co.uk/news/uk-england-56213042](https://www.bbc.co.uk/news/uk-england-56213042)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 09:03:46+00:00

The GMB Union says employees have been told to sign a loan agreement or face possible dismissal.

## Woods thankful as top golfers show support by wearing his trademark red and black
 - [https://www.bbc.co.uk/sport/golf/56236347](https://www.bbc.co.uk/sport/golf/56236347)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 08:32:11+00:00

Tiger Woods expresses his gratitude after male and female golfers show their support for the 15-time major winner on Sunday.

## Golden Globes: Ben Stiller's baked trophy and 8 other highlights
 - [https://www.bbc.co.uk/news/entertainment-arts-56211035](https://www.bbc.co.uk/news/entertainment-arts-56211035)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 07:58:01+00:00

Hollywood actor Ben Stiller didn't need much more than flour and eggs at Sunday' Golden Globes.

## Covid: Cars from Leeds and Manchester barred from Formby beach
 - [https://www.bbc.co.uk/news/uk-england-merseyside-56236447](https://www.bbc.co.uk/news/uk-england-merseyside-56236447)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 07:50:06+00:00

Travellers from Leeds and Manchester are turned away from a Merseyside beauty spot, police say.

## The Papers: 'Race to stop Brazil variant' and jabs pass 20m
 - [https://www.bbc.co.uk/news/blogs-the-papers-56234291](https://www.bbc.co.uk/news/blogs-the-papers-56234291)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 05:22:03+00:00

Many papers report the Brazil variant being found in the UK as officials "hunt" an unidentified case.

## Golden Globe Awards 2021: Nomadland and Borat win top awards
 - [https://www.bbc.co.uk/news/entertainment-arts-56234587](https://www.bbc.co.uk/news/entertainment-arts-56234587)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 04:44:32+00:00

Chloé Zhao becomes the second woman ever to win best director at Hollywood's Golden Globe awards.

## Covid: How many people get self-isolation payments?
 - [https://www.bbc.co.uk/news/56201754](https://www.bbc.co.uk/news/56201754)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 02:19:00+00:00

Figures for England and Wales suggest two-thirds of people who ask for self-isolation payments get rejected.

## Coronavirus doctor's diary: Study shows one-in-three children have rarely been leaving the house
 - [https://www.bbc.co.uk/news/health-56222926](https://www.bbc.co.uk/news/health-56222926)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 02:02:04+00:00

Only a third of children in Bradford had sufficient exercise during the first lockdown, a study shows.

## Tips for first-time runners in lockdown
 - [https://www.bbc.co.uk/news/newsbeat-55996596](https://www.bbc.co.uk/news/newsbeat-55996596)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 01:28:23+00:00

Radio 1 Newsbeat finds out what you should and shouldn't be doing as a first-time runner.

## Why this teen set up a prize-winning fake cosmetics shop
 - [https://www.bbc.co.uk/news/world-europe-56172456](https://www.bbc.co.uk/news/world-europe-56172456)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:39:43+00:00

Polish teenager Krystyna Paszko's idea won an EU prize - she tells the BBC the story behind it.

## The midwives braving armed gangs in Colombia
 - [https://www.bbc.co.uk/news/world-latin-america-56201572](https://www.bbc.co.uk/news/world-latin-america-56201572)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:35:24+00:00

A group of Afro-Colombian women use their skills to help women give birth in areas run by gangs.

## Job applications: Tips for getting your dream job
 - [https://www.bbc.co.uk/news/education-56201233](https://www.bbc.co.uk/news/education-56201233)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:29:11+00:00

How to make you and your CV shine as unemployment levels continue to rise.

## Coronavirus: False vaccine claims debunked
 - [https://www.bbc.co.uk/news/world-56198229](https://www.bbc.co.uk/news/world-56198229)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:18:33+00:00

Misleading claims about coronavirus vaccines have been spreading online.

## Sir Kazuo Ishiguro warns of young authors self-censoring out of 'fear'
 - [https://www.bbc.co.uk/news/entertainment-arts-56208347](https://www.bbc.co.uk/news/entertainment-arts-56208347)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:17:06+00:00

Writers may be self-censoring because they don't want to be "cancelled", author Kazuo Ishiguro says.

## Coronavirus and homelessness: 'I was living in the back of a transit van’
 - [https://www.bbc.co.uk/news/uk-56216177](https://www.bbc.co.uk/news/uk-56216177)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:15:53+00:00

Alex has been homeless on and off for 10 years, and lost his job as lorry driver when the pandemic hit.

## Kooking with a Koori: How a Sydney father's simple meals have won hearts
 - [https://www.bbc.co.uk/news/world-australia-56205629](https://www.bbc.co.uk/news/world-australia-56205629)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:10:16+00:00

Aboriginal man Nathan Lyons has found unexpected fame with videos inspired by "doing it tough".

## Teen entrepreneurs: 'My friend's pug inspired my business'
 - [https://www.bbc.co.uk/news/business-56102509](https://www.bbc.co.uk/news/business-56102509)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:07:30+00:00

Meet three teenagers who decided to set up their own businesses in lockdown.

## Waste food: What do you do with 86 tonnes of celeriac?
 - [https://www.bbc.co.uk/news/business-55855846](https://www.bbc.co.uk/news/business-55855846)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:04:46+00:00

With hospitality closed during lockdown, charities and apps are stepping in to help cut food waste.

## Yemen: The nine-year-old war-zone school teacher
 - [https://www.bbc.co.uk/news/world-middle-east-56212929](https://www.bbc.co.uk/news/world-middle-east-56212929)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:04:33+00:00

Ahmed, blind since birth, stands in for teachers who don't make it in to their ruined school in Yemen.

## Alan Shearer on how Gareth Bale and Tottenham ‘ran riot’ against Burnley
 - [https://www.bbc.co.uk/sport/av/football/56234332](https://www.bbc.co.uk/sport/av/football/56234332)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-01 00:03:38+00:00

Alan Shearer and Danny Murphy analyse the demolition of Burnley by Tottenham's front four, inspired by Gareth Bale.

