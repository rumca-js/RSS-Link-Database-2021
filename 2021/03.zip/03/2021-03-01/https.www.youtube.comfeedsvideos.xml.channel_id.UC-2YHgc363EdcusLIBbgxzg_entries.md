# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Immortal Woman Who Saved Millions Of Lives | Answers With Joe
 - [https://www.youtube.com/watch?v=xHIooZqKesM](https://www.youtube.com/watch?v=xHIooZqKesM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-03-01 00:00:00+00:00

Get 30 days free when you go to http://www.audible.com/joescott or text "joescott" to 500-500.
Henrietta Lacks died of cancer in 1951, but her cells mysteriously kept on living. Since then her "immortal" cell line has been the cornerstone of medical breakthroughs that have saved millions.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.sciencealert.com/how-dead-girl-paris-ended-up-most-kissed-lips-in-history-l-inconnue-de-la-seine-resusci-anne-cpr-annie-death-mask

https://www.immunology.org/hela-cells-1951

https://en.wikipedia.org/wiki/Henrietta_Lacks

https://en.wikipedia.org/wiki/Brachytherapy#Cervical_cancer

https://www.statnews.com/2017/04/14/henrietta-lacks-hela-cells-science/

Crash Course: https://www.youtube.com/watch?v=CzNANZnoiRs

Sci Show: https://www.youtube.com/watch?v=sXY6-wLesYY

https://www.nature.com/articles/d41586-020-03042-5

http://www.thenewsrecord.com/index.php/news/article/an_epitaph_at_last/

https://www.hopkinsmedicine.org/henriettalacks/

