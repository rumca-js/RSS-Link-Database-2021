# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Why Progress Bars Don't Move Smoothly ▓▓▓░░░░░░
 - [https://www.youtube.com/watch?v=iZnLZFRylbs](https://www.youtube.com/watch?v=iZnLZFRylbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-03-01 00:00:00+00:00

4 minutes remaining. Then 15 seconds. Then 5 hours. Why can't computers just tell you how long something's going to take? • MORE BASICS: https://www.youtube.com/playlist?list=PL96C35uN7xGLLeET0dOWaKHkAlPsrkcha

Written with Sean Elliott https://twitter.com/SeanMElliott/ • Graphics by William Marler https://wmad.co.uk

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

