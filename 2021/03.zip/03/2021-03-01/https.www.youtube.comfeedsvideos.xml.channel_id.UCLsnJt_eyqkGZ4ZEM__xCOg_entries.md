# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Jak dziś wygląda podróżowanie po Meksyku? (Daily vlog Casha #5)
 - [https://www.youtube.com/watch?v=2P0AoesLgkI](https://www.youtube.com/watch?v=2P0AoesLgkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2021-03-02 00:00:00+00:00

🗺️ Meksyk #5. Wybraliśmy się się do stanowiska archeologicznego Teotihuacán, jednak niestety nie wszystko poszło zgodnie z naszym planem... 🙄

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #Meksyk

## Najbogatsza dzielnica Meksyku i nocna wyprawa na miasto (Daily vlog Casha #4)
 - [https://www.youtube.com/watch?v=yESorPg0Uqg](https://www.youtube.com/watch?v=yESorPg0Uqg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2021-03-01 00:00:00+00:00

🗺️ Meksyk #4. Dziś zobaczycie podejrzany bazar, najbogatszą dzielnicę Meksyku oraz relację z nocnej wyprawy po tacosy :)

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #Meksyk

