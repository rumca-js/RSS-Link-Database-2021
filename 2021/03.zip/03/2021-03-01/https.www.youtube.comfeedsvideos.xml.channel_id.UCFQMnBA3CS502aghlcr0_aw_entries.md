# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Charlie Munger Destroys Fake Gurus in 1 Minute
 - [https://www.youtube.com/watch?v=QWhGHxrK9w8](https://www.youtube.com/watch?v=QWhGHxrK9w8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-02 00:00:00+00:00

this guy seems smart... should start selling a course or something

Charlie Munger Destroying Fake Gurus in UNDER 2 MINUTES
( originally found Charlie munger's rant on @guruleaks1 on twitter, so I had to make this:  https://twitter.com/Guruleaks1 )
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
channel music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Jay Mazini is having a Bad Year
 - [https://www.youtube.com/watch?v=sJXvl3PL8vY](https://www.youtube.com/watch?v=sJXvl3PL8vY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-02 00:00:00+00:00

Check out the lawsuit yourself below: 
https://iapps.courts.state.ny.us/fbem/DocumentDisplayServlet?documentId=%2F39ViL4tKtuQM4x0dqQIEA%3D%3D&system=prod
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
channel music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Instagram King 'Hushpuppi' Helps Launder $1.3B For Hackers
 - [https://www.youtube.com/watch?v=jPC0hU8NuQU](https://www.youtube.com/watch?v=jPC0hU8NuQU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-01 00:00:00+00:00

Flexing your way to jail. 
https://www.justice.gov/opa/pr/three-north-korean-military-hackers-indicted-wide-ranging-scheme-commit-cyberattacks-and
https://www.justice.gov/usao-cdca/pr/nigerian-national-brought-us-face-charges-conspiring-launder-hundreds-millions-dollars
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
channel music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

