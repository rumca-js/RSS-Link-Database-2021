# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## What REALLY happens at DAVOS?
 - [https://www.youtube.com/watch?v=KLcpr3rIKU0](https://www.youtube.com/watch?v=KLcpr3rIKU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-03-02 00:00:00+00:00

What REALLY happens at Davos? A clip from my podcast Under The Skin with Joel Bakan. 
Joel has attended Davos and has documented what really happens there and reveals what the true intentions of big businesses and CEOS are.

Joel has recently published a book, The New Corporation: How “Good” Corporations are Bad for Democracy, and released a documentary film based upon it. You can find out more about both at http://www.joelbakan.com. 

You can listen to the rest of the conversation and all episodes of Under The Skin on Luminary here:
http://luminary.link/russell

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Join my members-only mailing list here: https://www.russellbrand.com/join/

If you like this conversation, you can watch more like that in this playlist here: https://www.youtube.com/playlist?list=PL5BY9veyhGt7eapYiWXyxGuSxTcysPpJ7

Produced by Jenny May Finn (Instagram: @jennymayfinn)

