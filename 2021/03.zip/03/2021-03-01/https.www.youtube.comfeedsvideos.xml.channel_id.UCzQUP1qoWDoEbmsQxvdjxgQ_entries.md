# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Ayaan Hirsi Ali on France's Proposed Law Against Muslim Extremism
 - [https://www.youtube.com/watch?v=C6_pDRdIo1k](https://www.youtube.com/watch?v=C6_pDRdIo1k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-02 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1613 with Ayaan Hirsi Ali. https://open.spotify.com/episode/0yA586XjDwo2eKSYj01ziZ?si=f8d0ce613ddb432a

## The Divisive Nature of Covid Policies
 - [https://www.youtube.com/watch?v=MSMKtl_Td0c](https://www.youtube.com/watch?v=MSMKtl_Td0c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-02 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1613 with Ayaan Hirsi Ali. https://open.spotify.com/episode/0yA586XjDwo2eKSYj01ziZ?si=f8d0ce613ddb432a

## The Experiences That Made Ayaan Hirsi Ali an Activist
 - [https://www.youtube.com/watch?v=7F1H64wpDSU](https://www.youtube.com/watch?v=7F1H64wpDSU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-02 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1613 with Ayaan Hirsi Ali. https://open.spotify.com/episode/0yA586XjDwo2eKSYj01ziZ?si=f8d0ce613ddb432a

