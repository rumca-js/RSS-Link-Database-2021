# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Beyoncé - Single Ladies (Put A Ring On It) - funk cover ft. Brooke Simpson
 - [https://www.youtube.com/watch?v=a4Zsk-m_n_o](https://www.youtube.com/watch?v=a4Zsk-m_n_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-03-01 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Beyoncé's "Single Ladies" by Scary Pockets & Brooke Simpson.

MUSICIAN CREDITS
Lead vocal: Brooke Simpson
Drums: Kyle Crane
Bass: Solomon Dorsey
Guitar: Harrison Whitford
Wurlitzer: Swatkins
Keys: Jack Conte

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Kevin Brown
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
DP: Ricky Chavez
Camera operators: Sammy Rothman, Ricky Chavez
Editor: Adam Kritzberg

Recorded Live on a rooftop in Los Angeles, CA.

#ScaryPockets #Funk #Beyonce #SingleLadies #BrookeSimpson

