# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Ginormous Food, Gigantic Cancelation: The Josh Denny Interview
 - [https://www.youtube.com/watch?v=ftr0uBbIGm4](https://www.youtube.com/watch?v=ftr0uBbIGm4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-02 00:00:00+00:00

In this episode of The Babylon Bee Podcast, Kyle and Ethan talk to stand up comedian, Josh Denny. Josh was the host of Ginormous Food on Food Network until he was canceled back in 2018 for a tweet. You can support his podcast and comedy on Locals.com by searching Josh Denny. Kyle and Ethan talk to him about how he became a food show host, why McDonald's is worth fighting for, and the future of stand up comedy. 

Be sure to check out The Babylon Bee YouTube Channel for more podcasts, podcast shorts, animation, and more.

To watch or listen to the full podcast, become a subscriber at https://babylonbee.com/plans

