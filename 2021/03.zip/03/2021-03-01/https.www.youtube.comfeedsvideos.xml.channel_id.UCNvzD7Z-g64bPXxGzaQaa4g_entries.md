# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 WEIRD Gaming Stories of February 2021
 - [https://www.youtube.com/watch?v=g6pikNlUiFg](https://www.youtube.com/watch?v=g6pikNlUiFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-02 00:00:00+00:00

The early days of 2021 have had no shortage of crazy video game news stories. Here's some of the weirdest stuff happening in gaming.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

SOURCES:


https://www.pcgamer.com/developer-booted-off-steam-for-putting-its-name-as-very-positive/

https://www.inputmag.com/gaming/new-elite-dangerous-players-are-getting-tricked-into-a-forced-labor-camp

https://www.fox32chicago.com/news/illinois-lawmakers-want-to-ban-grand-theft-auto-amid-spike-in-carjackings

https://arstechnica.com/gaming/2021/02/epic-will-pay-off-class-action-loot-box-settlement-with-in-game-currency/

https://www.saanichnews.com/news/federal-court-orders-b-c-prison-to-return-playstation-game-card-to-inmate/#

https://www.cnet.com/news/scientists-teach-pigs-how-to-play-a-video-game-and-pigs-are-good-at-it/

https://kotaku.com/stadia-developers-cant-fix-the-bugs-in-their-own-game-b-1846331302?fbclid=IwAR0oyocLxt9JTstZS1_Hp6BOwGrn-EV5o4IldomlqPaiKb5XvuI9JYenv1s + https://www.extremetech.com/computing/320032-google-told-stadia-developers-they-were-making-great-progress-then-fired-them + https://www.androidpolice.com/2021/02/20/google-faces-possible-class-action-over-stadias-4k-claims/

#3
https://twitter.com/AJapaneseDream/status/1355332901240365057
PS5 chaos at Akihabara as customers rush to grab new consoles【Videos】
IMPORTANT Context - https://soranews24.com/2021/01/31/ps5-chaos-at-akihabara-as-customers-rush-to-grab-new-consoles%e3%80%90videos%e3%80%91/

#2
https://www.eurogamer.net/articles/2021-02-25-activision-warns-a-standard-500gb-ps4-may-no-longer-fit-call-of-duty-warzone-black-ops-cold-war-and-modern-warfare

#1 https://happymag.tv/video-games-reduce-depressive-symptoms/

## 10 Game Endings Almost NO ONE HAS SEEN
 - [https://www.youtube.com/watch?v=mdEhR4cRLos](https://www.youtube.com/watch?v=mdEhR4cRLos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-01 00:00:00+00:00

These video game endings may not be completely secret, but the act of getting to the point of seeing them is nearly impossible. Here are some wild examples of rare, lesser-seen game endings.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

