# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Implant do płatności zbliżeniowych Walletmor
 - [https://www.youtube.com/watch?v=xrXZf_i_BjQ](https://www.youtube.com/watch?v=xrXZf_i_BjQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-03-11 00:00:00+00:00

Jak wygląda, jak działa i jak przebiega proces umieszczania go w ciele? O tym opowiada ten film. 
Firma Wojtka, Walletmor: https://walletmor.com

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

Spies treści:
00:00 Formy płatności
00:33 Dlaczego lepiej płacić dłonią?
00:53 Kim jest gość?
01.08 Dlaczego implant, a nie karta, opaska czy telefon?
02:07 Jak wygląda implant?
02:33 Jak wszczepia się implant?
05:07 Implanty Wojtka
05:33 Testy bezpieczeństwa
06:19 Czy implant może się zepsuć?
06:50 Jak ludzie reagują widząc płatności implantem?
07:52 Blizny
08:36 Co jest w implancie?
09:49 Czy z implantem możemy być śledzeni?
10:41 Implanty w przyszłości
11:44 Wszczepianie implantu - zabieg
15:43 Pierwsza płatność
16:22 Refleksje
16:56 Po ilu razach płatność implantem staje się naturalna?

