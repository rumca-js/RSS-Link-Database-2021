# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Arteta says Arsenal are their own worst enemy after Olympiakos win
 - [https://www.bbc.co.uk/sport/football/56351003](https://www.bbc.co.uk/sport/football/56351003)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 23:47:25+00:00

Martin Odegaard sets Arsenal on their way to a commanding first-leg lead over Olympiakos in their Europa League last-16 tie.

## Nightmare start for McIlroy as Garcia takes Players Championship lead
 - [https://www.bbc.co.uk/sport/golf/56365272](https://www.bbc.co.uk/sport/golf/56365272)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 23:44:58+00:00

Rory McIlroy makes a disappointing start to the defence of his title at the Players Championship as he slumped to a seven-over 79 at TPC Sawgrass.

## Cumbria coal mine: 'Increased controversy' prompts public inquiry
 - [https://www.bbc.co.uk/news/uk-politics-56364306](https://www.bbc.co.uk/news/uk-politics-56364306)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 23:00:25+00:00

Ministers were warned the proposal is damaging the UK's reputation ahead of a major climate summit.

## 'He does everything' - Kane double sees Spurs put one foot in quarter-finals
 - [https://www.bbc.co.uk/sport/football/56351374](https://www.bbc.co.uk/sport/football/56351374)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 22:56:32+00:00

Harry Kane scores twice as Tottenham put one foot in the Europa League quarter-finals with a clinical win against Dinamo Zagreb.

## Nazanin Zaghari-Ratcliffe needs mental health treatment, charity says
 - [https://www.bbc.co.uk/news/uk-56362220](https://www.bbc.co.uk/news/uk-56362220)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 22:19:46+00:00

The British-Iranian woman faces a new court hearing this weekend, following a five-year sentence.

## Late AC Milan equaliser denies Man Utd win after Diallo's first goal
 - [https://www.bbc.co.uk/sport/football/56351824](https://www.bbc.co.uk/sport/football/56351824)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 21:10:05+00:00

AC Milan score a late equaliser to cancel out Amad Diallo's first Manchester United goal in the first leg of their Europa League last-16 tie.

## Rangers recover to earn valuable draw at Slavia Prague
 - [https://www.bbc.co.uk/sport/football/56259324](https://www.bbc.co.uk/sport/football/56259324)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 19:51:49+00:00

Rangers recover from an early setback to earn a creditable away draw in the first leg of their Europa League last-16 tie against Slavia Prague.

## China's parliament remakes Hong Kong in its own image
 - [https://www.bbc.co.uk/news/world-asia-china-56364912](https://www.bbc.co.uk/news/world-asia-china-56364912)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 18:15:51+00:00

"One Country, Two Systems" was an experiment centred on the defining ideological divide of our time.

## 'Puppy scammers left me heartbroken'
 - [https://www.bbc.co.uk/news/uk-56354154](https://www.bbc.co.uk/news/uk-56354154)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 17:17:07+00:00

More than 6,000 people in the UK have been victims of pet scammers since the first lockdown a year ago.

## The digital artist who just netted a cool £50m
 - [https://www.bbc.co.uk/news/technology-56362174](https://www.bbc.co.uk/news/technology-56362174)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 16:17:51+00:00

The digital-only artist is now among the top three most valuable living artists.

## Covid: Jet2 customer asked to pay £1,000 to change flight dates
 - [https://www.bbc.co.uk/news/uk-england-leeds-56351703](https://www.bbc.co.uk/news/uk-england-leeds-56351703)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 16:08:56+00:00

Olivia Sparnenn-Josh says she opted against a refund when her trip last year was cancelled.

## Kathleen Folbigg: Could science free Australian jailed for killing babies?
 - [https://www.bbc.co.uk/news/world-australia-56355695](https://www.bbc.co.uk/news/world-australia-56355695)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 16:03:50+00:00

Kathleen Folbigg has been called Australia's worst female murderer - now scientists doubt her guilt.

## Sinkholes appearing in Croatian village after earthquake
 - [https://www.bbc.co.uk/news/world-europe-56359244](https://www.bbc.co.uk/news/world-europe-56359244)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 14:18:04+00:00

They've been appearing in unusually high numbers after an earthquake hit the region in December.

## The Hebrides' wild swimming 'real-life' mermaid
 - [https://www.bbc.co.uk/news/uk-scotland-highlands-islands-56359621](https://www.bbc.co.uk/news/uk-scotland-highlands-islands-56359621)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 11:46:30+00:00

Kate MacLeod can be found swimming in seas and lochs around the Western Isles in summer - and winter.

## Virtual reality headsets for work ‘could snowball’
 - [https://www.bbc.co.uk/news/business-56359061](https://www.bbc.co.uk/news/business-56359061)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 11:42:58+00:00

Use of the headsets by people working from home could pick up quite rapidly, a business group says.

## Eurovision 2021: James Newman reveals Embers as UK song
 - [https://www.bbc.co.uk/news/newsbeat-56349129](https://www.bbc.co.uk/news/newsbeat-56349129)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 11:16:58+00:00

The singer will take 'fun and upbeat' track Embers to the Eurovision Song Contest in Rotterdam.

## Wartime love letters discovered under Scarborough hotel floorboards
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-56339136](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-56339136)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 08:10:05+00:00

Archaeologists hope to find out who the mystery sweethearts were after the discovery in Scarborough.

## Christopher Steele: Urgent need for laws to stop foreign influence
 - [https://www.bbc.co.uk/news/uk-56348936](https://www.bbc.co.uk/news/uk-56348936)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 05:48:42+00:00

Christopher Steele, who compiled the Trump-Russia dossier, says Russia and China are concerns.

## Covid-19: Brazil surge reaches new level as daily deaths pass 2,000
 - [https://www.bbc.co.uk/news/world-latin-america-56355861](https://www.bbc.co.uk/news/world-latin-america-56355861)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 05:33:26+00:00

The country records more than 2,000 Covid-related deaths in a single day for the first time.

## The papers: Sarah Everard case and 'fury' over nurses' pay
 - [https://www.bbc.co.uk/news/blogs-the-papers-56355464](https://www.bbc.co.uk/news/blogs-the-papers-56355464)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 05:06:34+00:00

Most of Wednesday's newspaper front pages lead on the latest developments in the Sarah Everard case.

## Brexit: NI official being sent to US amid UK-EU tensions
 - [https://www.bbc.co.uk/news/uk-56356033](https://www.bbc.co.uk/news/uk-56356033)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 03:23:00+00:00

US president Joe Biden has previously expressed concerns about the situation in Ireland after Brexit.

## Warren Buffett finally joins exclusive $100bn club
 - [https://www.bbc.co.uk/news/business-56355992](https://www.bbc.co.uk/news/business-56355992)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 01:53:20+00:00

The 90-year-old investor is part of an elite group of five, although he has given billions to charity.

## Teenage suicide: Bereaved siblings fight mental health 'stigma'
 - [https://www.bbc.co.uk/news/uk-england-kent-56333571](https://www.bbc.co.uk/news/uk-england-kent-56333571)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 01:32:13+00:00

Three young people who lost their siblings to suicide are urging distressed teenagers to seek help.

## Australians to be offered half-price flights to boost local tourism
 - [https://www.bbc.co.uk/news/world-australia-56355694](https://www.bbc.co.uk/news/world-australia-56355694)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 01:25:23+00:00

Travel subsidies will help the local tourism sector recover from the pandemic, PM Scott Morrison says.

## The Little Things: A crime thriller but not as you know it
 - [https://www.bbc.co.uk/news/entertainment-arts-55718906](https://www.bbc.co.uk/news/entertainment-arts-55718906)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 01:22:55+00:00

Denzel Washington, Rami Malek and Jared Leto on obsession, Covid-19 and getting into character.

## Being gay in Ghana: LGBT community is ‘under attack’
 - [https://www.bbc.co.uk/news/newsbeat-56325310](https://www.bbc.co.uk/news/newsbeat-56325310)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 01:12:08+00:00

Since the country’s first LGBT safe space was closed down by police, queer Ghanaians are "not safe".

## Magic reveals hidden tactics of politics and marketing
 - [https://www.bbc.co.uk/news/education-56352500](https://www.bbc.co.uk/news/education-56352500)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 01:10:38+00:00

Magicians use "powerful tools" of psychology that could manipulate people in other ways, says study.

## Palin and Jones: 'We didn't talk about the stammer'
 - [https://www.bbc.co.uk/news/uk-56351958](https://www.bbc.co.uk/news/uk-56351958)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:59:57+00:00

Former rugby player Mark Jones and Sir Michael Palin talk about their experiences of stammering.

## Covid: Are Texas and Mississippi lifting restrictions too soon?
 - [https://www.bbc.co.uk/news/world-us-canada-56297329](https://www.bbc.co.uk/news/world-us-canada-56297329)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:44:08+00:00

Two US states are lifting compulsory coronavirus restrictions, but are they in a position to do so?

## Japan's triple disaster 10 years on: The day ‘tomorrow didn’t come’
 - [https://www.bbc.co.uk/news/world-asia-56344142](https://www.bbc.co.uk/news/world-asia-56344142)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:28:39+00:00

Ten years on from Japan’s triple disaster, a survivor remembers the day his entire family disappeared.

## LGBT+ groups' 'deep concern' over minister's approach
 - [https://www.bbc.co.uk/news/uk-politics-56353313](https://www.bbc.co.uk/news/uk-politics-56353313)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:12:13+00:00

Nearly 20 LGBT+ groups have written to the government about lack of action to ban conversion therapy.

## M&S to sell clothes from rival brands to boost online sales
 - [https://www.bbc.co.uk/news/business-56346245](https://www.bbc.co.uk/news/business-56346245)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:03:58+00:00

The High Street stalwart will sell items from 11 different clothing brands on its website from spring.

## Cancer patients 'less protected' after first jab
 - [https://www.bbc.co.uk/news/health-56351084](https://www.bbc.co.uk/news/health-56351084)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:03:22+00:00

A 12-week gap could leave those having two Pfizer jabs vulnerable to Covid-19, researchers suggest.

## 'I went from Hollywood glamour to food donations'
 - [https://www.bbc.co.uk/news/business-56334012](https://www.bbc.co.uk/news/business-56334012)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:02:33+00:00

The Los Angeles awards season workers who have had to find new jobs.

## Covid: The man with 'super antibodies'
 - [https://www.bbc.co.uk/news/world-us-canada-56324050](https://www.bbc.co.uk/news/world-us-canada-56324050)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-11 00:01:41+00:00

John Hollis has antibodies that can kill the virus and variants but the discovery was nearly missed.

