# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe on Petr Yan's Illegal Knee at UFC 259
 - [https://www.youtube.com/watch?v=bzbRGTkIZVU](https://www.youtube.com/watch?v=bzbRGTkIZVU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-12 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1618 with Mat Fraser. https://open.spotify.com/episode/7EMkEw8Rpg6vntJoKUfDk8?si=9dc369e65fe94b1d

## Mat Fraser Has Won 5 Straight CrossFit Games
 - [https://www.youtube.com/watch?v=Z87GN1jA7nA](https://www.youtube.com/watch?v=Z87GN1jA7nA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-12 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1618 with Mat Fraser. https://open.spotify.com/episode/7EMkEw8Rpg6vntJoKUfDk8?si=9dc369e65fe94b1d

## Mat Fraser on Doping in the Olympics
 - [https://www.youtube.com/watch?v=qYM4Rl632ug](https://www.youtube.com/watch?v=qYM4Rl632ug)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-03-12 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1618 with Mat Fraser. https://open.spotify.com/episode/7EMkEw8Rpg6vntJoKUfDk8?si=9dc369e65fe94b1d

