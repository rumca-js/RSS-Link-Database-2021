# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Why Bill Gates is Now the Biggest US Farmland Owner
 - [https://www.youtube.com/watch?v=nOdOwRVk7VE](https://www.youtube.com/watch?v=nOdOwRVk7VE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-03-11 00:00:00+00:00

Invest in yourself! Use my link and check out the first chapter of any course for FREE! https://bit.ly/2N4qlzw 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

The Land Report article: https://landreport.com/2021/01/bill-gates-americas-top-farmland-owner/ 

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🖥️ Website platform I use: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use: https://jake.yt/benchd 
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: bit.ly/3t9V3GV

-----------------------
A mysterious Louisiana investor completed one of the biggest land sales in recent memory. When you look at farmland sales, you’re typically talking about 100’s of acres. But thousands of acres? Those are blue-moon events made by very big buyers. It had it be someone as big if not bigger than a billion dollar insurance company.

O’Keefe dug deeper and forwarded his findings to his Land Report 100 Research Team. A few minutes later, he gets this response: “Ever hear of Bill Gates?”

O’Keefe’s team followed the paper trail up the chain: That LLC is associated with the Angelina Agriculture Co is controlled by Cascade Investment, L.L.C. Cascade Investment, L.L.C. is what’s called a “family office” located in Kirkland, Washington that goes by the name Bill and Melinda Gates Investments, or BMGI. 

Michael Larson is the chief investment officer for the Gates Foundation. Larson was headhunted to work for Bill Gates in 1994. And after the 2008 financial crisis, the farmland empire began: Larson swooped up “at least 100,000 acres of farmland” all over the country in places like California, Illinois, Iowa, Louisiana, and more, on behalf of Gates. By 2017, the Agriculture Company of America sold half-a-billion-dollars worth of farmland. And the buyer? The paper trail led right back to none other than Cascade Investment. Which is definitely not outside the realm of possibility - buuut that’s probably not the truth.

After Bill bought nearly 25,000 acres of land west of Phoenix, Arizona - the media was quick to pick up the rumor that Bill Gates was planning on building “the city of the future”. So it’s understandable that when news broke of Bill’s farmland gains, the media was quick to call Bill the “Sustainable Agriculture Champion”. But like most things, reality is oftentimes a lot less glamorous than the theories.

Gates and his money manager, Larson, have a very simple relationship. Larson grows the money, and Gates gives it away. 

-----------------------

No Spirit, Kyle McEvoy, Dillan Witherow - Campfire https://chll.to/25a3ba7c 

This video was sponsored by DataCamp

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

