# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Brian Rose Faked a Criminal Record 😂
 - [https://www.youtube.com/watch?v=enP8973CmwI](https://www.youtube.com/watch?v=enP8973CmwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-12 00:00:00+00:00

NO MORE MR. NICE BRIAN. Did you DONATE?!

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Death by Self Help
 - [https://www.youtube.com/watch?v=3tWnZct2co0](https://www.youtube.com/watch?v=3tWnZct2co0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-03-12 00:00:00+00:00

James Arthur Ray calls himself a guru of many kinds, a Tony Robbins Wannabe, mixing spiritual, wealth, health, but what happens when pushing for enlightenment goes too far? This interview dives deep into James Ray Arthur's historic disaster with the 2009 Sweat lodge, which killed 3 people, including the daughter of Virginia Brown, Kirby Brown. 

Virginia survives her daughter and has created https://www.seeksafely.org/ to empower seekers of all kinds to find self-help in a modern age. 

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

