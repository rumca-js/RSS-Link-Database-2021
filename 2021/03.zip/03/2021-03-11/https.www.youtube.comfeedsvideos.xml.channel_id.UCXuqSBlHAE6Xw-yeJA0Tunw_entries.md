# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Our Sponsor Went Bankrupt... - WAN Show March 12, 2021
 - [https://www.youtube.com/watch?v=MH6fSbJP9RQ](https://www.youtube.com/watch?v=MH6fSbJP9RQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-12 00:00:00+00:00

Get a 15-day free trial for unlimited backup at https://backblaze.com/WAN

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/wan

Honey automatically applies the best coupon codes to save you money at different online checkouts, try it now at https://www.joinhoney.com/linus

See the full details of the Channel Super Fun Writer/Producer role at https://linusmediagroup.com/jobs 

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Our-Sponsor-Went-Bankrupt------WAN-Show-March-12--2021-eskq0m

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of BlackWings)
0:00 Intro, intel extreme tech upgrade
1:37 Broke sponsor 
3:27 Stalling for time
4:37 New intro 
5:42 Broke sponsor continuation
13:46 Clarification on Verified Actual Gamer Program
15:57 XBOX game pass exclusivity
30:39 Sponsor for WAN Show (Honey, BackBlaze, Freshbooks,)
33:55 Channel SuperFun job openings  
34:19 Radeon overhead and performance variations
42:09 adata quietly swapping out XPGSX8200 SSD components to revise performance
45:53 OVH data center destroyed in a massive fire
52:04 Russia attempted to throttle twitter instead ended up throttling their entire internet
52:30 NFT discussion 
56:33 GME stonks go brrr update
1:00:28 Is AMD joining the GPU mining craze more?
1:02:42 Superchats
1:03:08 No virtual LTX 2021
1:04:15 Major collab with tech youtubers, "Tech trivia answered in the form of a question"
1:12:34 WAN Show go bye bye

## The ALL-WHITE Gaming PC!
 - [https://www.youtube.com/watch?v=J_90BPrG8hQ](https://www.youtube.com/watch?v=J_90BPrG8hQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-11 00:00:00+00:00

Get a Free 32GB Flash Drive and 32GB Micro SD Card at Micro Center: https://micro.center/ad519
Check out the Micro Center Custom PC Builder: https://micro.center/1c982

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

ASUS asked us to check out their new RTX 3090 white edition and it's so cool that we decided to do an entire white-themed build around it. This is gonna be sweet.


Buy AMD Ryzen 9 5950X (PAID LINK): https://geni.us/qofcW

Buy ASUS PRIME X570-Pro (PAID LINK): https://geni.us/vuuzJ

Buy Corsair iCUE 5000X RGB (White) (PAID LINK): https://geni.us/L9fs

Buy ASUS RTX 3090 (White) (PAID LINK): https://geni.us/fBxle

Buy ASUS ROG Strix 850G (PAID LINK): https://geni.us/iYfC8

Buy G.Skill Trident Z NEO 128GB (4x32GB) DDR4 RAM (PAID LINK): https://geni.us/p4b1

Buy Samsung 980 Pro 2TB (PAID LINK): https://geni.us/OB7LWJX

Buy Corsair H150i Elite Capellix CPU Cooler (PAID LINK): https://geni.us/4PHW4vv

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1314313-the-ultimate-all-white-build/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

