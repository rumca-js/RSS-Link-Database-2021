# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Goodbye, tiny phones
 - [https://www.youtube.com/watch?v=1UctPJniJTs](https://www.youtube.com/watch?v=1UctPJniJTs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-03-12 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc

You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us. 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► About this video◄◄◄

This week, we finally say goodbye to small phones and the iPhone 12 Mini in particular, Beeple makes $69 million from NFTs (nice), and Apple builds a new 5G facility in Munich.

The Friday Checkout - Episode 38

This video on Nebula: https://watchnebula.com/videos/the-friday-checkout-the-end-for-mini-phones-is-here

Quiz: https://link.crrowd.com/quiz (should open either in the Android app or on the web depending on what device you're on!)
Release monitor: https://www.crrowd.com/release-monitor

NFT explainer: https://www.youtube.com/watch?v=vspxztRONak

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:37 Release Highlights
2:00 Small phones, mini sales
4:49 Digital art
7:13 Apple 5G facility

