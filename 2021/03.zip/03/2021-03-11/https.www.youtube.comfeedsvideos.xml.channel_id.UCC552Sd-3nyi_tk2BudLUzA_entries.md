# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Influencers are RUINING THE PLANET!!!
 - [https://www.youtube.com/watch?v=vAJM5EdDwjU](https://www.youtube.com/watch?v=vAJM5EdDwjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-03-11 00:00:00+00:00

How many Earths would be needed to sustain the lifestyle of everyone living like David Dobrik? SPOILER ALERT: IT'S A LOT!
Watch our podcast on Influencers: https://youtu.be/nSnxaxX1UC4
Join our mailing list: https://bit.ly/34fWU27​

David Dobrik lives in a 9.5 million dollar mansion with an Aston Martin and a career that withstands many controversies. Jake Paul, James Charles, Kim K, The Sway House also share similar lifestyles. BIG MANSIONS, MANSION TOURS, HOLLYWOOD HILL INFINITY POOLS, PRIVATE JETS, FIRST CLASS FLIGHTS etc. And uploading videos about these insane lifestyles get MAD clicks, buuuuut the environmental impact of the lifestyles ruin the planet. So, today we we did a thought experiment to figure out what would happen if everyone on Earth lived like an influencer, and lemme tell you - the results are INSANE!!!

Written by Greg Brown
Edited by Luka Šarlija

References:
The Story Of More by Hope Jahren
Metazoa By Peter Godfrey-Smith
Inconspicuous Consumption by Tatiana Schlossberg
https://www.energy.ca.gov/data-reports/energy-almanac/california-electricity-data/2019-total-system-electric-generation/2018
https://www.pewresearch.org/fact-tank/2020/01/15/renewable-energy-is-growing-fast-in-the-u-s-but-fossil-fuels-still-dominate/
https://www.bbc.com/news/magazine-33133712
http://www.oecd.org/newsroom/global-oecd-welcomes-colombia-as-its-37th-member.htm#:~:text=The%20OECD's%2037%20members%20are,Poland%2C%20Portugal%2C%20Slovak%20Republic%2C
https://www.usgs.gov/faqs/how-much-carbon-dioxide-does-united-states-and-world-emit-each-year-energy-sources?qt-news_science_products=0#qt-news_science_products
https://www.vox.com/the-goods/2018/12/7/18131132/public-transportation-bus-subway-america-us
https://www150.statcan.gc.ca/n1/pub/11-621-m/11-621-m2005023-eng.htm
https://www.theglobeandmail.com/opinion/rich-poor-who-leaves-the-biggest-eco-footprint/article25579800/
https://theconversation.com/rich-and-famous-lifestyles-are-damaging-the-environment-in-untold-ways-71641
https://www.bbc.com/news/magazine-33133712
https://data.world/blog/which-countries-live-within-their-ecological-means/
https://www.footprintcalculator.org/home5a

