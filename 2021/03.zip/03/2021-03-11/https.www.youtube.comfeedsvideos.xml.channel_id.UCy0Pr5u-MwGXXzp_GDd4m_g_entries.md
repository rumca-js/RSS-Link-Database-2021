# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## I Guess I'm Leaving my Boyfriend (ft. Trey Kennedy)
 - [https://www.youtube.com/watch?v=rLqEBqyDdhQ](https://www.youtube.com/watch?v=rLqEBqyDdhQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-03-11 00:00:00+00:00

This is what happens when girls talk about their boyfriends... 
Also go watch the video we made on his channel: https://www.youtube.com/watch?v=2d8YOw8LH5g
Check out Trey here:  @Trey Kennedy  

Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke

Written by: Julie Nolke
Starring: Trey Kennedy & Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay

