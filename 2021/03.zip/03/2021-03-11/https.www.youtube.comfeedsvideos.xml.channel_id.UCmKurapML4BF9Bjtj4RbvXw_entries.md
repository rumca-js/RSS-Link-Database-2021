# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Boston - More Than A Feeling / Long Time (Piano/Cello) - The Piano Guys
 - [https://www.youtube.com/watch?v=IjW6SbLT5NE](https://www.youtube.com/watch?v=IjW6SbLT5NE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2021-03-11 00:00:00+00:00

► GET OUR LATEST ALBUM: https://smarturl.it/TPG_LATEST_ALBUM 
► Get the SHEET MUSIC (now includes CHORD symbols): https://smarturl.it/TPG10_SheetMusic
► Learn about our beliefs here: https://smarturl.it/TPG_Beliefs

Point the "AR Pianist APP" at ANY piano and watch what happens! If you don’t have one, wait for it...
►DOWNLOAD “AR Pianist” (For iOS) here: https://smarturl.it/AR_PianoGuys
►DOWNLOAD “AR Pianist” (For Android) here: https://smarturl.it/AR_Pianist_TPGA

Follow The Piano Guys:
Instagram: https://instagram.com/thepianoguys
Facebook: https://facebook.com/ThePianoGuys
Twitter: https://twitter.com/thepianoguys

Watch More of The Piano Guys: 
Covers: https://youtube.com/playlist?list=PL7j5iXGSdMwc7n8Tsjl-I8zEOEZsjWydx&playnext=1&index=2 
Official Music Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwfDukj_bIIB_1JhbYtaWRYg&playnext=1&index=2 
Newest Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&playnext=1&index=2
Most Popular: https://youtube.com/playlist?list=PL7j5iXGSdMweXm56WEjskhCT5oAeEZJQF&playnext=1 

Listen to The Piano Guys: 
Spotify: https://open.spotify.com/artist/0jW6R8CVyVohuUJVcuweDI?si=8GgyFRhiTz6POs8b0ir2IA&dl_branch=1 
Apple Music: https://music.apple.com/us/artist/the-piano-guys/498030399 
Amazon Music: https://amazon.com/The-Piano-Guys/e/B00BXLTTI4 

We took a huge risk arranging and producing this passion project. It’s one that we’ve wanted to do for a “long time!" Since we’re worried the new style will throw you off, we won’t make it an official video release yet (i.e. filmed at Boston Fenway Baseball Stadium or somewhere cool). This A.I. video (Yes, those are artificial intelligence generated hands from our brand new A.I. Technology. It transfers midi info from my key strokes and voila!) is sort of a trial balloon to see what you think. Here’s hoping people will feel “more than a feeling!"

Produced by Chuck E. Myers "sea" Big Idea Music productions inc. and Jon Schmidt 

Engineered and mixed by Jake Bowen

Recorded and mixed at Big Idea Music studios, Sandy, Utah

Reverb by the Exponential Audio Phoenix / Symphony Reverb

Yamaha c7 Disklavier pro piano tuning and regulation by Rick Baldassin - Baldassin performance pianos

Special thanks to Debbie Olds for the 12 string guitar, Eric Myers and Suzette Shepherd for food runs!

Special thanks to our sponsors and vendors:
KIMBER KABLE - Ray Kimber,  FDW|Worldwide - Buzz Goodwin, Harman Pro,  Lexicon, EXPONENTIAL AUDIO - Michael Carnes 

About The Piano Guys:
Paul, a Yamaha dealer who dabbled in videography, Jon, a professional pianist, Al, a music producer and studio engineer, and Steve, a cellist with a creative superpower called ADHD, all serendipitously joined forces to create the most successful YouTube instrumental music group in history. The Piano Guys’ mission is to inspire and spread hope through incomparably imaginative piano music videos filmed all over the world. On this channel you can regularly find piano covers of music from genres like top 40, pop, classic rock, R&B, hiphop, country, and more. 

#Boston #PianoCover #Piano #MoreThanAFeeling #LongTime

