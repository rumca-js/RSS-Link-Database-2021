# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## CUSTOM PS5 MOD LOOKS AMAZING, XBOX GIVES UPDATE ON BETHESDA EXCLUSIVITY, & MORE
 - [https://www.youtube.com/watch?v=T-E14XxnHXE](https://www.youtube.com/watch?v=T-E14XxnHXE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-12 00:00:00+00:00

Thanks to Omaze for sponsoring. For your chance to win a Gaming Rig worth $20k and support a great cause, go to http://www.omaze.com/gameranx.

Xbox's Phil Spencer outlines Bethesda exclusivity (sort of), a crafty modder makes an insane water-cooled PS5, new game trailers, and more in a week full of gaming news.

Subscribe for more: https://www.youtube.com/gameranxTV?su...​...


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​


 ~~~~STORIES~~~~

Xbox Boss Gives Update on Bethesda Exclusivity 
https://twistedvoxel.com/phil-spencer-comments-on-bethesda-games-releasing-exclusively-on-xbox-and-pc/
+
https://wccftech.com/unannounced-xbox-games-2021-microsoft/
https://news.xbox.com/en-us/2021/03/11/20-bethesda-games-now-on-xbox-game-pass/

WATERCOOLED PS5?
https://www.videogameschronicle.com/news/pc-modder-creates-fully-functioning-water-cooled-playstation-5/amp/

Roblox
https://www.investors.com/news/technology/roblox-ipo-trading-begins-online-gaming-value-29-billion-rblx/



Feb NPD
https://venturebeat.com/tag/february-2021-npd/


Square Enix event
https://twitter.com/SquareEnix/status/1370056962143096835/photo/1

Japanese playstation event
https://www.videogameschronicle.com/news/playstation-confirms-live-stream-event-featuring-ff7-remake-and-resident-evil/

Rust server devastation
https://www.eurogamer.net/articles/2021-03-10-rust-developer-warns-large-amount-of-data-lost-in-devastating-server-blaze


Outer Worlds DLC
https://youtu.be/CBtKKqrIqO4

Apex on Switch
https://youtu.be/JJVPrXFGsVs


TMNT
https://youtu.be/ijKD0HIpgJM

## 10 SADDEST Easter Eggs That Hit You RIGHT IN THE FEELS
 - [https://www.youtube.com/watch?v=iJbfUeUcnPA](https://www.youtube.com/watch?v=iJbfUeUcnPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-11 00:00:00+00:00

Easter eggs are often fun, but there are a few that will tug at your heartstrings. Here are some sad Easter eggs and references in recent games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

SOURCES:

ref: https://starwars.fandom.com/wiki/Mar_Ti_Kam%27Ron

twitter thread: https://twitter.com/RamblingCameron/status/1196841022715678721




9. Gears 5 - Tomb of the Unknown

ref: https://gearsofwar.fandom.com/wiki/Easter_Eggs#Easter_Eggs_in_Gears_5

-


8. Hitman 3 - Agent 47 erases his memories

ref: https://hitman.fandom.com/wiki/HITMAN%E2%84%A2_III/_Easter_eggs



7. Just Cause 4 - Hidden Memorials

ref: https://justcause.fandom.com/wiki/Easter_Eggs_in_Just_Cause_4#Memorials



6. Hollow Knight - Dung Defender's Secret

ref: https://hollowknight.fandom.com/wiki/Dung_Defender



5. Spider-man (PS4) and Spider-man: Miles Morales  - Uncle ben's grave and The stan lee Statue



4. Paper Mario and the Origami King- The Secret ending

ref: https://www.youtube.com/watch?v=nW-xMMOwhBc




3. Celeste - Reversed Audio in act 5

ref: https://www.youtube.com/watch?v=rE8diav5I1k




2. RE3 Remake - Kendo's Daughter

RE3 ref: https://micky.com.au/resident-evil-3-remake-easter-eggs-you-may-have-missed/




1. Red Dead Redemption 2 - Paying Respects and Bonnie's Ex

ref: https://reddead.fandom.com/wiki/Paying_Respects

ref: https://www.gamespot.com/articles/how-to-find-this-very-sad-red-dead-redemption-2-ea/1100-6462967/?ftag=GSS-05-10aab8e&utm_campaign=trueAnthem:+New+Content+(Feed)&utm_content=5bdcc8e804d3011a09be6f07&utm_medium=trueAnthem&utm_source=twitter

