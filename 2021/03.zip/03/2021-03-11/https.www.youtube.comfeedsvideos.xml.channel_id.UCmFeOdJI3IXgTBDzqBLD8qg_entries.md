# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## Why I Hate Elon Musk
 - [https://www.youtube.com/watch?v=Dkix4UzEbjU](https://www.youtube.com/watch?v=Dkix4UzEbjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2021-03-12 00:00:00+00:00

This the truth behind how Elon Musk made so much of his money. 

In this video, we explore the dark truth and story behind Elon Musk, who is the CEO of Tesla and Space X and has been dubbed the richest man in the world. However, Elon Musk's rise to billions has lead to many hating Elon Musk, not only for his stealing of idea's, lawsuits, lies, and his Neuralink ambition to introduce brain chips to the population but also for his hollow facade. This video documents Elon Musk's rise to power and gives perspective on the reasons Elon Musk is hated and Elon Musk sucks. This is some real education on the truth about Elon Musk's money. 
******
►  Become a Patron:  https://www.patreon.com/MoonReal

📹𝗠𝘆 𝗘𝗾𝘂𝗶𝗽𝗺𝗲𝗻𝘁:
► Microphone: https://www.amazon.co.uk/gp/product/B07DV2WK77/ref=as_li_tl?ie=UTF8&camp=1634&creative=6738&creativeASIN=B07DV2WK77&linkCode=as2&tag=moonreal-21&linkId=1e984828cb3122716d17530c662a0776

💊* Ultimate Blackpill on China*:
►https://www.amazon.co.uk/gp/product/0099507374/ref=as_li_tl?ie=UTF8&camp=1634&creative=6738&creativeASIN=0099507374&linkCode=as2&tag=moonreal-21&linkId=296f051e6483a68d0d1fff2e5e074a86

🎶 Music:
►Epidemic Sounds - https://www.epidemicsound.com/referral/w1vpsh/

******
#elonmusk #tesla

Prologue - 00:00
Part 1: Childhood - 00:55
Part 2: Origins - 02:29
Part 3: Paypal - 04:45
Part 4: Tesla - 08:07
Part 5: The Dark Truth Behind Elon Musk - 15:36
Part 6: Conclusion - 16:34

THANK YOU FOR WATCHING!

