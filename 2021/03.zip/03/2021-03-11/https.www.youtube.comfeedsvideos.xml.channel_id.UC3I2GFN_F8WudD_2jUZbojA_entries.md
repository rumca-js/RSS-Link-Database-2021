# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Aaron Frazer - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=JKKxFbH8ydU](https://www.youtube.com/watch?v=JKKxFbH8ydU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-12 00:00:00+00:00

http://KEXP.ORG presents Aaron Frazer sharing a live performance recorded exclusively for KEXP and talking to DJ Morgan. Recorded February 26, 2021.

Songs:
Bad News
Have Mercy
If I Got It
Love Is
Over You

Session recorded at The Jalopy Theatre in Brooklyn, NY
Directed by Sam Graff
DP / Steadicam by Matthew Marino
Audio engineering & mixing by Vince Chiarito

http://aaronfrazermusic.com
http://kexp.org

## Alex Lahey x Gordi - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=ZM4NZrXCOXg](https://www.youtube.com/watch?v=ZM4NZrXCOXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-11 00:00:00+00:00

http://KEXP.ORG presents Alex Lahey and Gordi performing live, recorded exclusively for KEXP.

Songs:
Dino's
Extraordinary Life
Unspoken History
Wes Anderson
Sandwiches

Session recorded at Small Time in Melbourne, Australia
Audio Engineer: Connor Black-Harry
Cameras: Rick Clifford & Lucy Campbell
Director/Editor: James Seymour

https://alexlahey.com.au
http://www.gordimusic.com
http://kexp.org

