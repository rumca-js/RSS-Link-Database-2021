# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Cherry Glazerr - three songs at The Current (2019)
 - [https://www.youtube.com/watch?v=GZbnIlbRAzA](https://www.youtube.com/watch?v=GZbnIlbRAzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-03-12 00:00:00+00:00

Two years ago today, Los Angeles band Cherry Glazerr visited The Current studio just bit more than a month after the release of their album "Stuffed & Ready." 

"I feel like it's always the most exciting to play the things you've written most recently, and so it feels really fresh and very exciting," said Cherry Glazerr songwriter and frontperson Clementine Creevy (who has one of the coolest-sounding names in rock and roll). "It's been a really great run so far."

Watch three songs by Cherry Glazerr from that March 2019 session. 

SONGS PERFORMED
0:00 "That's Not My Real Life"
2:54 "Self Explained"
6:29 "Wasted Nun"

PERSONNEL
Clementine Creevy – vocals, guitar
Tabor Allen – drums
Devin O'Brien – bass

CREDITS
Video & Photo: Nate Ryan, Mary Mathis
Audio: John Miller; Johnny Vince Evans
Production: Derrick Stevens

FIND MORE:
2019 studio session: https://www.thecurrent.org/feature/2019/03/11/cherry-glazerr-perform-in-the-current-studio
2019 set at The Current's Day Party during SXSW: https://www.thecurrent.org/feature/2019/03/17/watch-cherry-glazerr-perform-at-the-current-day-party-in-austin-texas-sxsw

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#cherryglazerr

## Thundercat - two songs at The Current (2017)
 - [https://www.youtube.com/watch?v=19aMBrD0umo](https://www.youtube.com/watch?v=19aMBrD0umo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-03-11 00:00:00+00:00

Four years ago, Thundercat (aka Stephen Bruner) visited The Current not long after winning a Grammy for Best Rap/Sung Collaboration on Kendrick Lamar's "To Pimp a Butterfly."

Recalling the moment immediately following his Grammy win, Thundercat said, "It was trippy because I texted [Kendrick Lamar] after, and I was like, 'Yo dude, we won one,' and he was like, 'Tight.'"

During their March 2017 visit to The Current, Thundercat and his bandmates — drummer Justin Brown and pianist Dennis Hamm — stopped in to chat with host Mac Wilson and to perform songs off their latest album, "Drunk" and from 2013's "Apocalypse," live in studio. Watch two songs from that performance.

SONGS PERFORMED
0:00 "A Fan's Mail (Tron Song Suite II)"
4:24 "Tron Song"

PERSONNEL
Thundercat – bass, vocals
Justin Brown – drums
Dennis Hamm – piano

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2017 studio session: https://www.thecurrent.org/feature/2017/03/10/thundercat-performs-in-the-current-studio
2020 "Dragonball Durag" video:
https://www.thecurrent.org/feature/2020/02/27/thundercat-new-song-new-video-dragonball-durag

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#thundercat #thundercatmusic

