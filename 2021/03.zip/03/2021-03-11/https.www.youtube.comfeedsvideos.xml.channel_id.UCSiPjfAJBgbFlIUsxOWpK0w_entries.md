# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## You Get What You Give // New Radicals // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=KzZUDAhxTFc](https://www.youtube.com/watch?v=KzZUDAhxTFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-03-12 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Because it is our duty to inspire you today...also, this is just a great song.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of New Radicals' "You Get What You Give" by Pomplamoose.

MUSICIAN CREDITS
Vocals: Nataly Dawn
Keys, Percussion: Jack Conte
Guitar, Drums, Percussion, Keys: Ben Rose

AUDIO CREDITS
Mixing/Mastering: Yianni AP
Producer: Ben Rose

VIDEO CREDITS
Camera Operator: Nataly Dawn
Assistant to the Regional Camera Operator: Ben Rose
Wardrobe: Elle Olsen
Video Editor: Dominic Mercurio
Colorist: Charlene Gibbs

Recorded in our home studio in San Francisco.

#Pomplamoose #IndieRock #YouGetWhatYouGive #NewRadicals

LYRICS

Wake up, kids
We got the dreamers disease
Age fourteen, they got you down on your knees
So polite, you're busy still saying please

But when the night is falling
You cannot find the light (light)
You feel your dreams are dying
Hold tight

You've got the music in you
Don't let go
You've got the music in you
One dance left
This world is gonna pull through
Don't give up
You've got a reason to live
Can't forget
We only get what we give

4 AM, we ran a miracle mile
We're flat broke
But hey, we do it in style
The bad rich
God's flying in for your trial

But when the night is falling
You cannot find a friend (friend)
You feel your tree is breaking
Just then

You've got the music in you
Don't let go
You've got the music in you
One dance left
This world is gonna pull through
Don't give up
You've got a reason to live
Can't forget
We only get what we give

This whole damn world could fall apart
You'll be okay, follow your heart
I'm right behind
Now say you're mine
You've got the music in you
Don't let go
You've got the music in you
One dance left
This world is gonna pull through
Don't give up
You've got a reason to live
Can't forget
We only get what we give

