# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Pirat - Judgement (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=vez-OO-Xx6g](https://www.youtube.com/watch?v=vez-OO-Xx6g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-12 00:00:00+00:00

"Judgement" (1996) by Pirat/Phase Distortion (Sascha von Dages). Art "Atome-1" (1996, unsure) by Norm/Skarla.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## SID music: Toggle - Cheers & Tributes (SIDFX 8580 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=jGc_WjhwvEc](https://www.youtube.com/watch?v=jGc_WjhwvEc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-12 00:00:00+00:00

"Cheers & Tributes" (2013) by Toggle (Tobias Göhlke). Art "Let Roses Speak" (2013) by Sphinx/Arsenic. Christopherjam palette used for more saturated colors.

Made using real C64 audio in SIDFX dual mono config (identical audio data for both chips):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

