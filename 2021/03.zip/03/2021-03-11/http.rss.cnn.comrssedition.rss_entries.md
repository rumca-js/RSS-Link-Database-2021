# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Matthew McConaughey is considering a run for Texas governor
 - [https://www.cnn.com/videos/entertainment/2021/03/11/matthew-mcconaughey-considering-texas-governor-run-sot-mxp-vpx.hln](https://www.cnn.com/videos/entertainment/2021/03/11/matthew-mcconaughey-considering-texas-governor-run-sot-mxp-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 21:02:56+00:00

Actor Matthew McConaughey, whose home state is Texas, says he is seriously considering a run for governor and it may be what he wants to do with the next chapter of his life. HLN's Melissa Knowles has the details.

## Watch Sharon Osbourne clash with co-host over Piers Morgan support
 - [https://www.cnn.com/videos/business/2021/03/11/sharon-osbourne-racism-piers-morgan-orig.cnn](https://www.cnn.com/videos/business/2021/03/11/sharon-osbourne-racism-piers-morgan-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 20:32:18+00:00

"The Talk" co-host Sharon Osbourne got emotional during an on-air discussion of her support for Piers Morgan after his controversial comments about Meghan, the Duchess of Sussex.

## Drone footage shows aftermath of blasts in Equatorial Guinea
 - [https://www.cnn.com/videos/world/2021/03/11/equatorial-guinea-blast-drone-footage-adma-bks-lon-orig.cnn](https://www.cnn.com/videos/world/2021/03/11/equatorial-guinea-blast-drone-footage-adma-bks-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 19:37:33+00:00

Footage shows the scale of the destruction from a series of explosions in Equatorial Guinea. The blasts happened at a military base in the port city of Bata on March 7.

## SE Cupp on Governor Cuomo: When is enough, enough?
 - [https://www.cnn.com/videos/opinions/2021/03/11/se-cupp-andrew-cuomo-democrat-liability-unfiltered-vpx.cnn](https://www.cnn.com/videos/opinions/2021/03/11/se-cupp-andrew-cuomo-democrat-liability-unfiltered-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 19:11:48+00:00

CNN Political Commentator SE Cupp says New York Governor Andrew Cuomo's ongoing controversies will cost Democrats for not holding him accountable.

## Analysis: This is the Biden way to get things done
 - [https://www.cnn.com/2021/03/11/politics/president-biden-way-covid-relief-bill/index.html](https://www.cnn.com/2021/03/11/politics/president-biden-way-covid-relief-bill/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 15:02:21+00:00

There's a story President Joe Biden likes to tell about himself.

## Patio chairs at center of Oprah's Meghan and Harry interview sell out online
 - [https://www.cnn.com/2021/03/11/business/oprah-patio-chairs-christopher-knight/index.html](https://www.cnn.com/2021/03/11/business/oprah-patio-chairs-christopher-knight/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 15:01:15+00:00

An unlikely TV character's name is at the center of Oprah's sit-down interview with Meghan, Duchess of Sussex, and Prince Harry: 'Peter Brady.'

## Prince William: Royals 'not a racist family'
 - [https://www.cnn.com/2021/03/11/uk/prince-william-response-racism-harry-meghan-intl-gbr/index.html](https://www.cnn.com/2021/03/11/uk/prince-william-response-racism-harry-meghan-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:58:00+00:00

Prince William -- in his first public comments on the interview given by his brother Prince Harry and his wife Meghan -- said the royal family was "very much not a racist family."

## UK's 1st Black female MP reacts to Prince William's claim that royal family is not racist
 - [https://www.cnn.com/collections/intl-royals-0310/](https://www.cnn.com/collections/intl-royals-0310/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:57:00+00:00



## Satellite and drone images show extent of damage from Equatorial Guinea blast
 - [https://www.cnn.com/2021/03/11/africa/thousands-flee-equatorial-guinea-blast-intl/index.html](https://www.cnn.com/2021/03/11/africa/thousands-flee-equatorial-guinea-blast-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:55:19+00:00

Callers seeking the parents of lost children have been regularly dialing in to radio and television programs since a series of explosions leveled much of Equatorial Guinea's largest city and sent thousands fleeing for the countryside.

## WSJ: Trump pressured Georgia investigator to find 'the right answer' in baseless fraud push
 - [https://www.cnn.com/collections/intl-wsj-trump-0311/](https://www.cnn.com/collections/intl-wsj-trump-0311/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:53:52+00:00



## Judge reinstates third-degree murder charge against Derek Chauvin in George Floyd's death
 - [https://www.cnn.com/2021/03/11/us/derek-chauvin-george-floyd-charges/index.html](https://www.cnn.com/2021/03/11/us/derek-chauvin-george-floyd-charges/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:44:34+00:00

Former Minneapolis Police officer Derek Chauvin now faces an additional murder charge in the death of George Floyd after a Hennepin County judge reinstated a charge of third-degree murder on Thursday.

## Trump pressured Georgia investigator to find 'the right answer' in baseless fraud push
 - [https://www.cnn.com/2021/03/10/politics/donald-trump-georgia-phone-call/index.html](https://www.cnn.com/2021/03/10/politics/donald-trump-georgia-phone-call/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:29:57+00:00

In a phone call to the Georgia secretary of state's office in December, then-President Donald Trump urged a top investigator to find fraud in the 2020 presidential election, telling her that she would be "praised" for overturning results that were in favor of Joe Biden, according to audio of the call obtained by CNN.

## Microsoft suspends new LinkedIn sign-ups in China
 - [https://www.cnn.com/2021/03/11/tech/linkedin-china-microsoft-intl-hnk/index.html](https://www.cnn.com/2021/03/11/tech/linkedin-china-microsoft-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:29:35+00:00

LinkedIn — one of the few Western social media networks available in China — has suspended new sign-ups in the country, but said the decision has nothing to do with a recent cyberattack on parent company Microsoft.

## 'Bridgerton' fans can watch Regé-Jean Page read a bedtime story
 - [https://www.cnn.com/2021/03/11/entertainment/reg-jean-page-cbeebies-scli-intl-gbr/index.html](https://www.cnn.com/2021/03/11/entertainment/reg-jean-page-cbeebies-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:26:39+00:00

Regé-Jean Page, the British star of the lavish regency-era romance series "Bridgerton," will read a bedtime story on the BBC children's program Cbeebies in a move that is sure to delight parents as well as children.

## He clung to a tree for hours to escape death in Japan's worst natural disaster
 - [https://www.cnn.com/2021/03/10/asia/japan-tohoku-fukushima-tenth-anniversary-hnk-dst-intl/index.html](https://www.cnn.com/2021/03/10/asia/japan-tohoku-fukushima-tenth-anniversary-hnk-dst-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:25:45+00:00



## ECB will buy bonds at a faster pace to keep the recovery on track
 - [https://www.cnn.com/2021/03/11/investing/ecb-stimulus-bond-market/index.html](https://www.cnn.com/2021/03/11/investing/ecb-stimulus-bond-market/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:09:56+00:00

The European Central Bank plans to pick up the pace of its bond buying in the coming months to bolster the region's lackluster recovery from the coronavirus pandemic and counter a spike in borrowing costs.

## Brazil plunges into crisis as a second wave and deadly new variant overwhelm hospitals
 - [https://www.cnn.com/collections/intl-covid-news-lines-0311/](https://www.cnn.com/collections/intl-covid-news-lines-0311/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 14:05:32+00:00



## 'We cannot survive', tennis counts the cost of empty stands
 - [https://www.cnn.com/2021/03/11/tennis/tennis-survive-covid-19-money-spt-intl/index.html](https://www.cnn.com/2021/03/11/tennis/tennis-survive-covid-19-money-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:58:26+00:00

Tennis has limped back to some semblance of normality after last year's lengthy disruption due to the Covid-19 pandemic, but stakeholders fear playing tournaments in front of empty stands might not be sustainable for long.

## Meet Gen C, the Covid generation
 - [https://www.cnn.com/collections/intl-covid-mental-health-0311/](https://www.cnn.com/collections/intl-covid-mental-health-0311/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:55:15+00:00



## Ikea's novel way to deal with boredom
 - [https://www.cnn.com/2021/03/11/business/ikea-catalog-audio-version/index.html](https://www.cnn.com/2021/03/11/business/ikea-catalog-audio-version/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:48:19+00:00



## Italy unveils 'Covid-free' trains to tourist destinations
 - [https://www.cnn.com/travel/article/italy-covid-free-trains/index.html](https://www.cnn.com/travel/article/italy-covid-free-trains/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:42:12+00:00

We've had pre-travel testing, quarantine on arrival and "covid-free" flights. Now comes something new in the travel industry's battle against the pandemic: "covid-free" trains.

## Arkansas abortion ban isn't a law. It's a message
 - [https://www.cnn.com/2021/03/11/opinions/arkansas-abortion-ban-roe-v-wade-ziegler/index.html](https://www.cnn.com/2021/03/11/opinions/arkansas-abortion-ban-roe-v-wade-ziegler/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:15:14+00:00

This week, Arkansas passed one of the nation's most sweeping abortion bans to date, criminalizing any procedure unless a patient's life is at risk. But the sweep of Arkansas's proposal, which very consciously includes a ban for cases of rape and incest, isn't the only thing that stands out. Quite simply, Arkansas's latest abortion ban isn't just a law. It's a letter to the Supreme Court's conservative six -justice majority -- and a preview of the case against Roe v. Wade.

## The spotlight is on 3 people at a delicate moment for markets
 - [https://www.cnn.com/2021/03/11/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/03/11/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:10:41+00:00

Investors are starting to push away anxiety about a spike in prices later this year. But continued calm may hinge on what three people have to say in the next week.

## They're called 'Gen C' and the pandemic is shaping their futures
 - [https://www.cnn.com/2021/03/11/us/covid-generation-gen-c/index.html](https://www.cnn.com/2021/03/11/us/covid-generation-gen-c/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:09:12+00:00

• LIVE UPDATES Iceland and Norway suspend use of AstraZeneca vaccine 
• Denmark suspends use of AstraZeneca

## Frisbee and oval ball star Cat Phillips fired up by fight for gender equality
 - [https://www.cnn.com/2021/03/11/football/cat-phillips-frisbee-australian-football-gender-equality-cmd-spt-intl/index.html](https://www.cnn.com/2021/03/11/football/cat-phillips-frisbee-australian-football-gender-equality-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:07:50+00:00

For someone who describes herself as a "pretty quiet person," Cat Phillips has shown herself to be utterly unafraid of speaking out.

## The latest Dictionary.com words include several from African American Vernacular English and phrases related to race and identity
 - [https://www.cnn.com/2021/03/11/us/dictionary-race-new-words-trnd/index.html](https://www.cnn.com/2021/03/11/us/dictionary-race-new-words-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 13:00:51+00:00

Adding a word to the dictionary has long been a sign of mainstream legitimacy. And in the latest batch added to Dictionary.com, the online dictionary has included multiple African American Vernacular English words such as "finna" and "chile," among other words and phrases related to race and identity.

## Famine is returning to Yemen -- and a Saudi fuel blockade stands to make it worse
 - [https://www.cnn.com/2021/03/10/middleeast/yemen-famine-saudi-fuel-intl/index.html](https://www.cnn.com/2021/03/10/middleeast/yemen-famine-saudi-fuel-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 12:42:47+00:00

When 10-month-old Hassan Ali arrived at the hospital, doctors were hopeful they could save him. So many children in northern Yemen, after all, don't even get this far, starved not only of food but also the fuel needed just to reach medical help.

## How a 19-year-old TikToker become a martyr for democracy
 - [https://www.cnn.com/videos/world/2021/03/11/myanmar-protests-angel-ma-kyal-zin-watson-dnt-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/03/11/myanmar-protests-angel-ma-kyal-zin-watson-dnt-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 12:14:24+00:00

Nineteen-year-old "Angel" Ma Kyal Zin is one of the many protesters shot dead while demonstrating against Burmese security forces in recent weeks. Her image dressed in an "Everything will be OK" t-shirt while running away from authorities moments before being fatally wounded quickly turned the teenager into a symbol of the deadly struggle for democracy in Myanmar. CNN's Ivan Watson reports.

## Lionel Messi scores 'special' goal but misses penalty as Barcelona crashes out of the Champions League
 - [https://www.cnn.com/2021/03/11/football/lionel-messi-barcelona-psg-goal-champions-league-spt-intl/index.html](https://www.cnn.com/2021/03/11/football/lionel-messi-barcelona-psg-goal-champions-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 12:07:14+00:00

It wasn't enough to ensure Barcelona progressed to the Champions League quarterfinals but Lionel Messi's strike against Paris Saint-Germain on Wednesday will live long in the memory.

## Coupang, the Amazon of South Korea, raises $4.6 billion in US IPO
 - [https://www.cnn.com/2021/03/11/investing/coupang-ipo-us-stock-korea-intl-hnk/index.html](https://www.cnn.com/2021/03/11/investing/coupang-ipo-us-stock-korea-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 11:53:23+00:00

Coupang, South Korea's biggest e-commerce company, has pulled off the largest US initial public offering so far this year.

## Former Presidents Carter, Clinton, Bush and Obama urge Americans to get vaccinated
 - [https://www.cnn.com/2021/03/11/politics/former-presidents-vaccine-psa/index.html](https://www.cnn.com/2021/03/11/politics/former-presidents-vaccine-psa/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 11:49:58+00:00

Former Presidents Jimmy Carter, Bill Clinton, George W. Bush, Barack Obama and their respective former first ladies are part of a newly released ad campaign urging Americans to get the coronavirus vaccine when it is their turn, a push that is aimed squarely at combating vaccine skepticism.

## Superstar quarterback Dak Prescott eyes Super Bowl parade after signing mega deal
 - [https://www.cnn.com/2021/03/11/sport/dak-prescott-super-bowl-dallas-cowboys-spt-intl/index.html](https://www.cnn.com/2021/03/11/sport/dak-prescott-super-bowl-dallas-cowboys-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 11:17:06+00:00

Dallas Cowboys quarterback Dak Prescott has his eyes set on a Super Bowl victory after signing a new mega deal with the franchise.

## The world went on a debt binge last year. There could be a nasty hangover
 - [https://www.cnn.com/2021/03/11/investing/government-debt-bond-yields-interest-rates/index.html](https://www.cnn.com/2021/03/11/investing/government-debt-bond-yields-interest-rates/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 10:55:38+00:00

Desperate to save their economies from complete collapse, governments borrowed unprecedented amounts of money on the cheap to support workers and businesses during the pandemic. Now, with recovery in sight, a big risk looms: interest payments.

## Warren Buffett is now worth $100 billion
 - [https://www.cnn.com/2021/03/11/business/warren-buffett-net-worth-intl-hnk/index.html](https://www.cnn.com/2021/03/11/business/warren-buffett-net-worth-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 10:30:44+00:00

Warren Buffett has just joined the world's most exclusive club of the mega rich.

## House set to vote on gun legislation that would expand background checks
 - [https://www.cnn.com/2021/03/11/politics/background-checks-gun-bills-house-vote/index.html](https://www.cnn.com/2021/03/11/politics/background-checks-gun-bills-house-vote/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 10:04:02+00:00

The House is set to vote Thursday on legislation that would expand background checks on all commercial gun sales, marking the first congressional move on significant gun control since Democrats won the White House and the majority in both chambers of Congress.

## Ex-MLB star Johnny Damon had 4 times legal limit after DUI arrest, during which he voiced support for Trump and Blue Lives Matter
 - [https://www.cnn.com/2021/03/11/us/johnny-damon-dui-bodycam-video-spt-trnd/index.html](https://www.cnn.com/2021/03/11/us/johnny-damon-dui-bodycam-video-spt-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 09:53:08+00:00

Former professional baseball player Johnny Damon mentioned his support for former President Donald Trump and the Blue Lives Matter movement during a traffic stop and subsequent DUI arrest on February 19, bodycam video released by the Windermere Police Department in Florida shows.

## Deadly new Covid variant overwhelms hospitals in Brazil
 - [https://www.cnn.com/2021/03/10/americas/brazil-variant-covid-icu-crisis-intl/index.html](https://www.cnn.com/2021/03/10/americas/brazil-variant-covid-icu-crisis-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 09:39:52+00:00



## China's parliament endorses plan to 'improve' Hong Kong elections, further curbing opposition
 - [https://www.cnn.com/2021/03/11/asia/china-hong-kong-election-reform-intl-hnk/index.html](https://www.cnn.com/2021/03/11/asia/china-hong-kong-election-reform-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 09:04:05+00:00

China's rubber-stamp parliament on Thursday overwhelmingly endorsed a proposal on "improving the electoral system" of Hong Kong, further restricting the ability of people in the city to freely elect their leaders.

## These Bronze Age women were more powerful than we thought
 - [https://www.cnn.com/2021/03/10/europe/female-power-bronze-age-spain-scli-intl-scn/index.html](https://www.cnn.com/2021/03/10/europe/female-power-bronze-age-spain-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 07:23:52+00:00

Archaeologists working at an ancient complex in southeastern Spain say women probably held political power in the Bronze Age society that ruled the area 4,000 years ago -- a sharp contrast with earlier views of the civilization.

## Indonesia bus carrying school children plunges into ravine, killing 27
 - [https://www.cnn.com/2021/03/11/asia/indonesia-bus-crash-intl-hnk/index.html](https://www.cnn.com/2021/03/11/asia/indonesia-bus-crash-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 06:27:21+00:00

A bus carrying school children and parents returning from an excursion plunged into a ravine on the Indonesian island of Java on Wednesday night, killing 27 people, the country's transportation ministry said.

## Lemon to Republican senator: I don't want to yell, but what are you doing?
 - [https://www.cnn.com/videos/politics/2021/03/11/tim-scott-woke-supremacists-dons-take-vpx.cnn](https://www.cnn.com/videos/politics/2021/03/11/tim-scott-woke-supremacists-dons-take-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 06:17:26+00:00

CNN's Don Lemon reacts to Sen. Tim Scott's (R-SC) comment on Fox News saying that "woke supremacy is as bad as white supremacy."

## 'The Masked Singer' reveals the identity of the Snail
 - [https://www.cnn.com/videos/media/2021/03/11/masked-singer-snail-reveal-identity-eg-orig.cnn](https://www.cnn.com/videos/media/2021/03/11/masked-singer-snail-reveal-identity-eg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 06:02:17+00:00

A famous Muppet was revealed as the identity of the Snail in the season premiere of "The Masked Singer."

## Myanmar police who fled to India say they refused orders to shoot protesters
 - [https://www.cnn.com/2021/03/11/asia/myanmar-india-mizoram-intl-hnk/index.html](https://www.cnn.com/2021/03/11/asia/myanmar-india-mizoram-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 05:37:44+00:00

When Tha Peng was ordered to shoot at protesters with his submachine gun to disperse them in the Myanmar town of Khampat on February 27, the police lance corporal said he refused.

## 'Even prisoners get fresh air': Inside Australia's hotel quarantine system
 - [https://www.cnn.com/travel/article/australia-hotel-quarantine-system/index.html](https://www.cnn.com/travel/article/australia-hotel-quarantine-system/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 03:43:19+00:00

When my plane finally touched down in Sydney, I was overwhelmed by a sense of disbelief.

## How one Republican-leaning county is welcoming Biden's Covid-19 relief
 - [https://www.cnn.com/videos/politics/2021/03/11/williamson-west-virginia-covid-relief-bill-tuchman-pkg-ac360-vpx.cnn](https://www.cnn.com/videos/politics/2021/03/11/williamson-west-virginia-covid-relief-bill-tuchman-pkg-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 02:39:32+00:00

CNN's Gary Tuchman talks to residents in Williamson, a Republican-leaning town in West Virginia, about their feelings on Biden's $1.9 trillion Covid-19 relief bill recently passed by Congress.

## Seth Rogen starts cannabis home delivery in US
 - [https://www.cnn.com/style/article/seth-rogen-houseplant-cannabis-us/index.html](https://www.cnn.com/style/article/seth-rogen-houseplant-cannabis-us/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 02:12:35+00:00

After summiting the stoner comedy genre with movies like "Pineapple Express" and "This is the End," actor Seth Rogen and screenwriter-director Evan Goldberg have set their sights on the US cannabis market.

## The growing GOP rebellion against Marjorie Taylor Greene
 - [https://www.cnn.com/2021/03/10/politics/marjorie-taylor-greene-congress-adjourn-backlash/index.html](https://www.cnn.com/2021/03/10/politics/marjorie-taylor-greene-congress-adjourn-backlash/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-11 00:37:19+00:00

For the fourth time in the last two weeks, Georgia freshman Republican Rep. Marjorie Taylor Greene called for a motion to adjourn the House on Thursday morning.

