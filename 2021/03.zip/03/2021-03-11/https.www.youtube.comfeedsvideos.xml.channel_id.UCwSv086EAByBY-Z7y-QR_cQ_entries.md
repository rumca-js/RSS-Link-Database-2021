# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Mateusz Morawiecki chce masowej produkcji mikroczipów w Europie. Polemika z Suwerenny PL
 - [https://www.youtube.com/watch?v=KnhQfSISqiI](https://www.youtube.com/watch?v=KnhQfSISqiI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-03-12 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3ldmzAI
2. https://bit.ly/3vmcuGf
3. http://bit.ly/38BRjpT
4. http://bit.ly/3l9LViG
5. https://bit.ly/3lcitbJ
6. https://bit.ly/3tdGtht
7. http://on.ft.com/3rH7tWk
8. http://bit.ly/3et5OQy
9. http://bit.ly/3bIVbHi
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
gov.pl - http://bit.ly/2lVWjQr
---------------------------------------------------------------
💡 Tagi: #polityka #gospodarka #Morawiecki
--------------------------------------------------------------

## ID2020 i WFP testują płatności biometryczne, oraz tworzenie tożsamości suwerennej od podstaw
 - [https://www.youtube.com/watch?v=xc9xieG-7IA](https://www.youtube.com/watch?v=xc9xieG-7IA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-03-11 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3rE5mCR
2. https://bit.ly/30B6smU
3. http://bit.ly/38xY8bT
4. http://bit.ly/3cnWVFd
5. https://bit.ly/3l8EgB5
6. https://bit.ly/38kyMyf
-------------------------------------------------------------
💡 Tagi: #biometria #ID2020
--------------------------------------------------------------

