# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Tweeting Elon and Pouring One Out For Cancelled Homies
 - [https://www.youtube.com/watch?v=exFr14TKUZQ](https://www.youtube.com/watch?v=exFr14TKUZQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-12 00:00:00+00:00

Kyle and Ethan are joined by The Babylon Bee CEO Seth Dillon and Managing Editor Joel Berry. They discuss the eccentric Elon Musk tweeting at The Bee while roasting The Onion, all those who have been recently canceled in the culture wars, and Alabama kangaroos. There’s also plenty of weird news and glorious hate mail.

00:05:15 Subscriber Dare
00:08:18 Weird News
00:21:35 Elon Musk Tweets The Bee
00:27:22 In Memoriam Those We Lost To Cancel Culture
00:45:22 Hate Mail
00:49:41 Joel’s Subscriber Testimony

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

