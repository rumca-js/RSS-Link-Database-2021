# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The REAL Reason Edward Snowden Hasn’t Been Pardoned
 - [https://www.youtube.com/watch?v=iOceOnghdjg](https://www.youtube.com/watch?v=iOceOnghdjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-03-12 00:00:00+00:00

As the NSA and GCHQ hail the 75th anniversary of their alliance, successive presidents refuse to pardon #EdwardSwowden and a growing number of convicted whistleblowers. Were they traitors to their country, or is there another reason? 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com​/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Under The Skin podcast to hear from guests including Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Get a one month free trial at http://luminary.link/russell​

My Audible Original, ‘Revelation', is released on 25 March
My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

