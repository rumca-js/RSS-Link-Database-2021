# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Zrównoważony Rozwój wymaga rewolucji kulturowej. Przemyślenia i scenariusze
 - [https://www.youtube.com/watch?v=sKyrgM_Fnq4](https://www.youtube.com/watch?v=sKyrgM_Fnq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-03-23 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. http://bit.ly/31cRFiE
-------------------------------------------------------------
🖼Grafika - wykorzystano grafikę ze strony: 
weforum.org - https://bit.ly/3axLnhz
-------------------------------------------------------------
🎥Film - wykorzystano fragment filmy ze strony: 
douyin.com - http://bit.ly/2QpqpuW
-------------------------------------------------------------
💡 Tagi: #TikTok #ZrównoważonyRozwój
--------------------------------------------------------------

## Mateusz Morawiecki nawołuje do nowej formy kapitalizmu! Szanse i zagrożenia. Analiza
 - [https://www.youtube.com/watch?v=F0nzZt0efzA](https://www.youtube.com/watch?v=F0nzZt0efzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-03-22 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/317ssGe
2. http://bit.ly/318HqM4
3. http://bit.ly/3d1VZH3
4. https://bit.ly/3g8QpUm
5. http://bit.ly/2PmpeMA
6. https://bit.ly/2QuecFw
7. https://bit.ly/2OHblb8
8. http://bit.ly/2PdrRQC
-------------------------------------------------------------
🖼Grafika - wykorzystano grafikę ze strony: 
gov.pl - http://bit.ly/2lVWjQr
weforum.org - https://bit.ly/3axLnhz
-------------------------------------------------------------
💡 Tagi: #kapitalizm #polityka
--------------------------------------------------------------

