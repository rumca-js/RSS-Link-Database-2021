# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Might and Magic VI (Re)Review | Dementia™ Edition™
 - [https://www.youtube.com/watch?v=yG9g2byXR2c](https://www.youtube.com/watch?v=yG9g2byXR2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2021-03-22 14:28:38+00:00

Special thanks to Paul Anthony Romero.

Buy the entire Might & Magic Series, up to 85% off:
https://www.gog.com/magicsseth

Download the mod (Requires Might and Magic VIII: Day of the Destroyer):
https://www.celestialheavens.com/forum/10/16657
Mod Mirror links (use if main is down):
https://drive.google.com/file/d/1A2Jyw5Gw6YAJ5nB52h46vzJ7Tcj4SCKT/view?usp=sharing
https://mega.nz/file/ipBh0AZB#sqYOrwSTTdj0_J8m09Jb1LuCsB5j0M2GisXSzRub5iQ

Since the game has a tendency to punish you for mistakes you didn't know you were committing,
I recommend the following site for tips and hints.
It won't give you full on walkthrough solutions, just enough to help you get by.
https://www.uhs-hints.com/uhsweb/mm6.php
https://www.uhs-hints.com/uhsweb/mm7.php
https://www.uhs-hints.com/uhsweb/mm8.php

Enjoy.
-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

