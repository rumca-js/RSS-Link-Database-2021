# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## OnePlus 9 czy 9 Pro? Którego wybrać?
 - [https://www.youtube.com/watch?v=EXv_Zxh-O8c](https://www.youtube.com/watch?v=EXv_Zxh-O8c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-03-23 00:00:00+00:00

Wbrew pozorom, wybór nie jest aż tak oczywisty. 
Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

W odcinku:
00:00 Życie recenzenta
00:30 Etuje
00:39 Szybka ładowarka
01:14 Ładowarka 65W
01:33 Smartfony
02:29 Ed Sheeran
02:49 Proces powstawania recenzji
03:23 Szybkie porównanie i recenzja
04:08 Weryfikacja recenzji i porównanie zdjęć
05:47 Przednia kamera: OnePlus 9 vs OnePlus 9 Pro vs iPhone 12 Pro Max
07:14 Możliwości foto/video: iPhone 12 Pro Max vs OnePlus 9 Pro
08:12 Przypomnienie: Recenzje na tym kanale nie są sponsorowane
08:31 Możliwości foto/video OnePlusów – ciąg dalszy
12:12 Głośniki
12:25 Nagrany dźwięk-mikrofony
13:04 Czego nie było w recenzji
14:14 Który smartfon wybrać?
15:31 Pożegnanie i zaproszenie na anglojęzyczny kanał Mrkeybrd

