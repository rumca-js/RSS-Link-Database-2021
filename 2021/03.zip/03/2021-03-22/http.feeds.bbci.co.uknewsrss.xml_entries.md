# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Lockdown newborns: 'A crazy year to bring a baby into the world'
 - [https://www.bbc.co.uk/news/uk-scotland-56484706](https://www.bbc.co.uk/news/uk-scotland-56484706)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 23:17:11+00:00

Four mums share their experiences of having a baby amid coronavirus lockdown restrictions.

## 'Grealish should be number one' - who you & pundits say should start for England
 - [https://www.bbc.co.uk/sport/football/56487138](https://www.bbc.co.uk/sport/football/56487138)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 21:28:37+00:00

England boss Gareth Southgate is spoilt for choice in attack this summer - this is who you and our pundits think should play with Harry Kane.

## What is happening to the size of the Army?
 - [https://www.bbc.co.uk/news/uk-42774738](https://www.bbc.co.uk/news/uk-42774738)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 20:13:12+00:00

Defence spending is going up, but the number of soldiers in the Army is going to fall.

## Covid: Penguins' move from Isle of Man to Northern Ireland 'a miracle'
 - [https://www.bbc.co.uk/news/world-europe-isle-of-man-56489503](https://www.bbc.co.uk/news/world-europe-isle-of-man-56489503)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 17:51:18+00:00

Covid rules force keepers to move 14 birds across four countries to get to their new home.

## Huge fire sweeps through Rohingya camp in Bangladesh
 - [https://www.bbc.co.uk/news/56490348](https://www.bbc.co.uk/news/56490348)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 17:28:26+00:00

Several people have been killed and tens of thousands have fled the fire.

## Erin Brockovich: California water battle 'woke me up'
 - [https://www.bbc.co.uk/news/world-us-canada-56462793](https://www.bbc.co.uk/news/world-us-canada-56462793)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 16:32:05+00:00

She has continued to call for safe water in the decades since the major case in the town of Hinkley.

## MOTD 2 analysis: How Arsenal's Martin Odegaard went from 'bang average' to 'sensational' against West Ham
 - [https://www.bbc.co.uk/sport/av/football/56483327](https://www.bbc.co.uk/sport/av/football/56483327)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 13:20:15+00:00

Match of the Day 2 pundits Alex Scott and Carlton Cole analyse Martin Odegaard "sensational" performance for Arsenal at West Ham after being "bang average" earlier in the season.

## Coronavirus: Third wave will 'wash up on our shores', warns Johnson
 - [https://www.bbc.co.uk/news/uk-politics-56486067](https://www.bbc.co.uk/news/uk-politics-56486067)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 13:13:15+00:00

Boris Johnson says the UK will "feel effects" of growing case numbers in Europe amid a row over vaccines.

## BBC to screen Women's Super League football
 - [https://www.bbc.co.uk/sport/football/56459754](https://www.bbc.co.uk/sport/football/56459754)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 12:59:18+00:00

BBC will show live Women's Super League matches on network TV for the first time as part of a multi-million-pound broadcast deal with Sky Sports.

## Iceland volcano eruption: Onlookers flock to see Mount Fagradalsfjall
 - [https://www.bbc.co.uk/news/world-europe-56482798](https://www.bbc.co.uk/news/world-europe-56482798)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 12:58:09+00:00

People have trekked to Mount Fagradalsfjall after lava started bursting out on Friday evening.

## Meghan's Mail on Sunday statement on hold
 - [https://www.bbc.co.uk/news/uk-56485477](https://www.bbc.co.uk/news/uk-56485477)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 12:57:33+00:00

A notice about the Duchess of Sussex's copyright win is on hold pending a possible appeal by the newspaper.

## Rise of new 'young DIY-ers' boosts B&Q-owner
 - [https://www.bbc.co.uk/news/business-56483953](https://www.bbc.co.uk/news/business-56483953)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 12:55:02+00:00

Kingfisher says 18-34 year-olds did more home improvements during lockdown than any other age group.

## London elections 2021: What can the mayor of London do?
 - [https://www.bbc.co.uk/news/uk-england-london-56455840](https://www.bbc.co.uk/news/uk-england-london-56455840)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 12:41:45+00:00

Londoners elect a new mayor on 6 May. The role has the largest personal mandate of any politician in the UK, what do they do with it?

## Line of Duty: Series six opener attracts record 9.6m audience
 - [https://www.bbc.co.uk/news/entertainment-arts-56482757](https://www.bbc.co.uk/news/entertainment-arts-56482757)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 12:12:14+00:00

Series six of Jed Mercurio's hit cop drama made its much-hyped debut on BBC One on Sunday night.

## Aretha Franklin's family protest about National Geographic's Genius biopic
 - [https://www.bbc.co.uk/news/entertainment-arts-56482684](https://www.bbc.co.uk/news/entertainment-arts-56482684)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 11:56:33+00:00

The star's family say they "do not support" the TV series, starring British actress Cynthia Erivo.

## MP's 'grave concerns' over child killer's parole hearing
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-56461241](https://www.bbc.co.uk/news/uk-england-leicestershire-56461241)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 11:49:20+00:00

Colin Pitchfork was jailed in 1988 after DNA linked him to the rape and murder of two 15-year-olds.

## Bristol riot: Violent clashes with police 'shameful'
 - [https://www.bbc.co.uk/news/uk-england-bristol-56461796](https://www.bbc.co.uk/news/uk-england-bristol-56461796)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 11:48:16+00:00

Police, who have arrested seven people so far, say "thuggish citizens" will be brought to justice.

## Covid: Boris Johnson's roadmap very optimistic - Mark Drakeford
 - [https://www.bbc.co.uk/news/uk-wales-politics-56457861](https://www.bbc.co.uk/news/uk-wales-politics-56457861)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 11:05:22+00:00

Mark Drakeford says he wants to be honest and realistic, not "paint the most optimistic plan I can".

## Where are England going wrong - and how can Jones turn things around?
 - [https://www.bbc.co.uk/sport/rugby-union/56478150](https://www.bbc.co.uk/sport/rugby-union/56478150)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 10:55:17+00:00

Slow starts. Record points conceded. A sky-high penalty count. How England's Six Nations campaign fell short on multiple fronts.

## Australia floods: Thousands evacuated as downpours worsen
 - [https://www.bbc.co.uk/news/world-australia-56476998](https://www.bbc.co.uk/news/world-australia-56476998)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 10:22:26+00:00

A severe warning is extended to the whole New South Wales coast, in the worst flooding in decades.

## What is the Police, Crime, Sentencing and Courts Bill and how will it change protests?
 - [https://www.bbc.co.uk/news/uk-56400751](https://www.bbc.co.uk/news/uk-56400751)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 09:58:33+00:00

Public protests have pushed the government's controversial new police bill into the spotlight.

## Football's Darkest Secret: Survivors of child abuse in football tell their stories
 - [https://www.bbc.co.uk/sport/football/56378292](https://www.bbc.co.uk/sport/football/56378292)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 09:06:28+00:00

In a new BBC three-part programme, Football's Darkest Secrets, survivors of child sexual abuse in football talk about the impact on their lives and about speaking out.

## Covid vaccine: US trial of AstraZeneca jab confirms safety
 - [https://www.bbc.co.uk/news/health-56479462](https://www.bbc.co.uk/news/health-56479462)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 08:39:28+00:00

Regulators in America have been waiting for these results to decide on approval.

## Covid: 'Young medics have seen more deaths than some do in a career'
 - [https://www.bbc.co.uk/news/uk-england-london-56286593](https://www.bbc.co.uk/news/uk-england-london-56286593)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 07:38:48+00:00

About a third of Ealing Hospital staff are under 30 - how have they coped with a year of Covid-19?

## Scotland's first medical cannabis clinic approved
 - [https://www.bbc.co.uk/news/uk-scotland-tayside-central-56475596](https://www.bbc.co.uk/news/uk-scotland-tayside-central-56475596)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 06:49:05+00:00

Sapphire Medical in Stirling will start holding virtual appointments after it received official registration.

## Watch the best tries from the 2021 Six Nations
 - [https://www.bbc.co.uk/sport/av/rugby-union/56477940](https://www.bbc.co.uk/sport/av/rugby-union/56477940)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 06:32:51+00:00

Watch the best tries from the 2021 Six Nations - with starring roles for England's Jonny May, France's Antoine Dupont and Wales wing Louis Rees-Zammit.

## The Papers: 'Tussle' over Covid vaccines, and fiery protest pictures
 - [https://www.bbc.co.uk/news/blogs-the-papers-56479125](https://www.bbc.co.uk/news/blogs-the-papers-56479125)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 06:11:18+00:00

Brussels' threat to ban AstraZeneca Covid vaccine exports to Britain dominates Monday's front pages.

## Seven options, three spots - who should start in England's attack with Kane?
 - [https://www.bbc.co.uk/sport/football/56330575](https://www.bbc.co.uk/sport/football/56330575)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 06:01:47+00:00

England manager Gareth Southgate appears spoilt for choice with attacking options this summer, who do you think he should take?

## Defence review: Army 'to be reduced by 10,000 troops'
 - [https://www.bbc.co.uk/news/uk-56477900](https://www.bbc.co.uk/news/uk-56477900)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 04:19:36+00:00

A review of the UK's defence policy sees new investment in cyber warfare, robotics and drones.

## Australia floods: Cows rescued from swollen rivers and beaches
 - [https://www.bbc.co.uk/news/world-australia-56480142](https://www.bbc.co.uk/news/world-australia-56480142)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 02:56:17+00:00

Exhausted animals have been pulled from swollen rivers, beaches and flooded suburbs.

## Covid inequality: 'I struggled with the bills and my health'
 - [https://www.bbc.co.uk/news/business-56359863](https://www.bbc.co.uk/news/business-56359863)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 02:08:49+00:00

People on the financial precipice are disproportionately likely to be unemployed, renting, female, and black.

## Kitboga: How AI is helping me waste scammers’ time
 - [https://www.bbc.co.uk/news/technology-56458267](https://www.bbc.co.uk/news/technology-56458267)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:10:35+00:00

Twitch streamer, Kitboga, says he wanted to stop con artists trying to steal from people.

## 'I’ll buy five items and only keep one of them'
 - [https://www.bbc.co.uk/news/explainers-56103106](https://www.bbc.co.uk/news/explainers-56103106)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:08:27+00:00

With online returns soaring during the pandemic, tech firms are helping retailers deal with the rise.

## Coronavirus: Covid nurses' song of hope from Italy
 - [https://www.bbc.co.uk/news/world-europe-56368178](https://www.bbc.co.uk/news/world-europe-56368178)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:06:53+00:00

Simona Camosci wrote the song in the first Covid wave, and now she and her colleagues have released it.

## Covid: The countries that nailed it, and what we can learn from them
 - [https://www.bbc.co.uk/news/uk-56455030](https://www.bbc.co.uk/news/uk-56455030)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:05:58+00:00

A year into the pandemic, we look at countries that have had some success in tackling the virus.

## Israel election hopes and fears play out in crater town
 - [https://www.bbc.co.uk/news/world-middle-east-56441048](https://www.bbc.co.uk/news/world-middle-east-56441048)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:04:07+00:00

For voters in Mitzpe Ramon, Tuesday's poll means keeping or casting out Israel's PM Benjamin Netanyahu.

## Why India is talking about ripped jeans and knees
 - [https://www.bbc.co.uk/news/world-asia-india-56453929](https://www.bbc.co.uk/news/world-asia-india-56453929)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:01:43+00:00

Thousands of women are sharing their photos in ripped jeans on social media - but why?

## How can I stop my houseplants dying?
 - [https://www.bbc.co.uk/news/uk-56419276](https://www.bbc.co.uk/news/uk-56419276)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:00:17+00:00

With houseplant sales booming, expert Giacomo Plazzotta offers tips for keeping them healthy.

## Dog thefts: The woman who rescues stolen dogs
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-56253889](https://www.bbc.co.uk/news/uk-england-nottinghamshire-56253889)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:00:16+00:00

A woman who rescues stolen pets says the crime has "rocketed out of control" during lockdown.

## One Year On: A pandemic poem for Londoners
 - [https://www.bbc.co.uk/news/uk-england-london-56436460](https://www.bbc.co.uk/news/uk-england-london-56436460)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:00:14+00:00

The writers behind All on the Board pay tribute to Londoners on the eve of the anniversary of the start of first lockdown.

## The former fighters embracing peace in the Philippines Mindanao region
 - [https://www.bbc.co.uk/news/world-asia-56462199](https://www.bbc.co.uk/news/world-asia-56462199)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-03-22 00:00:13+00:00

Former fighters are embracing peace in Mindanao in the Philippines, in the hope of ending decades of killing.

