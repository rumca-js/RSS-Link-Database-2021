# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Donna Grantis   two songs at The Current 2019
 - [https://www.youtube.com/watch?v=0wN3MQwSXnY](https://www.youtube.com/watch?v=0wN3MQwSXnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-03-23 00:00:00+00:00

On March 22, 2019, Donna Grantis visited The Current for a studio session. Three years after playing guitar with 3RDEYEGIRL and Prince, Grantis released her debut solo album, "Diamonds & Dynamite."

After Prince's death in 2016, Grantis spent time living in New York and Los Angeles before deciding to settle in Minneapolis and focus on her solo career. She found local bandmates to fit the project — Cody McKinney (bass), JT Bates (drums), Bryan Nichols (organ), and Suphala (tabla) — after "hanging out in Minneapolis for a couple months at First Avenue and Icehouse," Grantis said.

For the session at The Current, Grantis and crew brought their own lighting; they darkened the room, covered the windows, and flipped on blue LED bars. "It feels a little uncomfortable for me to play rock riffs in bright light," Grantis explained to host Mark Wheat with a laugh, later revealing that it was Prince who inspired her to reach beyond music and find ways to get creative with performance. Watch two songs from that session.

SONGS PERFORMED
0:00 "Mr. Majestic"
4:53 "Trashformer"

PERSONNEL
Donna Grantis – guitar
Cody McKinney – bass
JT Bates – drums
Bryan Nichols – organ
Suphala – tabla

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark; Matt Lentz
Production: Derrick Stevens

FIND MORE:
2017 interview:
https://www.thecurrent.org/feature/2017/04/21/3rdeyegirl-guitarist-donna-grantis-calls-the-twin-cities-home
2017 Theft of the Dial:
https://www.thecurrent.org/feature/2017/04/21/theft-of-the-dial-donna-grantis-of-3rdeyegirl
2017 article: 
https://blog.thecurrent.org/2017/06/3rdeyegirl-guitarist-donna-grantis-announces-debut-show-with-new-band/
2019 studio session:
https://www.thecurrent.org/feature/2019/03/22/donna-grantis-performs-brand-new-music-in-the-currents-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#donnagrantis

## Interview: Cannons
 - [https://www.youtube.com/watch?v=sCQ_IrChdto](https://www.youtube.com/watch?v=sCQ_IrChdto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-03-23 00:00:00+00:00

Cannons' three members--Michelle Joy, Ryan Clapham, and Paul Davis connect with Zeke to talk about what they'd play on the radio if they were DJs, their aspirations for the band, and what they've been up to this year.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#cannons

