# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Why Shakespeare Could Never Have Been French
 - [https://www.youtube.com/watch?v=dUnGvH8fUUc](https://www.youtube.com/watch?v=dUnGvH8fUUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-03-22 00:00:00+00:00

Shakespeare sounds a certain way. Why? And why could it only work in English? • Written with Gretchen McCulloch of Lingthusiasm! Her podcast has an episode about how translators approach texts: https://lingthusiasm.com/post/632086691477323776/lingthusiasm-episode-49-how-translators-approach

Gretchen's book BECAUSE INTERNET, all about the evolution of internet language, is available:
🇺🇸 US: https://amzn.to/30tLpjT
🇨🇦 CA: https://amzn.to/2JsTYWH
🇬🇧 UK: https://amzn.to/31K8eRD

(Those are affiliate links that give a commission to me or Gretchen, depending on country!)

Audio mix by Graham Haerther: https://haerther.net

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

