# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Shake It Off | Taylor Swift | funk cover ft. Solomon Dorsey
 - [https://www.youtube.com/watch?v=eohvV3ZhASM](https://www.youtube.com/watch?v=eohvV3ZhASM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-03-22 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Taylor Swift's "Shake It Off" by Scary Pockets & Solomon Dorsey.

MUSICIAN CREDITS
Lead vocal: Solomon Dorsey
Drums: Kyle Crane
Guitar: Harrison Whitford
Keys: Swatkins
Bass: Ryan Lerman
Wurlitzer: Jack Conte

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Kevin Brown
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
Cinematography: Ricky Chavez
Camera Operators: Sammy Rothman, Ricky Chavez
Editor: Adam Kritzberg

Recorded Live on a rooftop in downtown Los Angeles.

#ScaryPockets #Funk #TaylorSwift #ShakeItOff #SolomonDorsey

