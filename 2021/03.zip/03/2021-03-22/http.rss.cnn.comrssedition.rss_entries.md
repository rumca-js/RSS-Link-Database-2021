# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Actress shares powerful words at 'Stop Asian Hate' rally
 - [https://www.cnn.com/videos/us/2021/03/22/sandra-oh-stop-asian-hate-oakland-pennsylvania-rally-mxp-vpx.hln](https://www.cnn.com/videos/us/2021/03/22/sandra-oh-stop-asian-hate-oakland-pennsylvania-rally-mxp-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 22:10:36+00:00

Actress Sandra Oh gives remarks during a "Stop Asian Hate" rally in Pennsylvania.

## Ex-NFL star, now a US Congressman, 'was prepared to fight' during Capitol insurrection
 - [https://www.cnn.com/2021/03/22/sport/nfl-colin-allred-insurrection-cmd-spt-intl/index.html](https://www.cnn.com/2021/03/22/sport/nfl-colin-allred-insurrection-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 22:00:19+00:00

As a second-term Congressman Colin Allred carefully respects the traditions of his hallowed workplace.

## Top Fox producer dies from coronavirus
 - [https://www.cnn.com/2021/03/22/media/fox-business-network-producer-eric-spinato-death/index.html](https://www.cnn.com/2021/03/22/media/fox-business-network-producer-eric-spinato-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 21:06:27+00:00

Eric Spinato, the head booker and senior story editor for the Fox Business Network, died over the weekend, the network said Monday.

## Should I travel? Expert advice on what to consider
 - [https://www.cnn.com/travel/article/should-i-travel-expert-advice-pandemic/index.html](https://www.cnn.com/travel/article/should-i-travel-expert-advice-pandemic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 20:54:39+00:00

An already powerful pent-up desire to travel has only intensified with global weariness of pandemic restrictions and the rollout of vaccines in some countries.

## Fox News anchor wrongly reports DHS secretary had resigned during Trump interview
 - [https://www.cnn.com/2021/03/22/media/fox-news-harris-faulkner-dhs-secretary/index.html](https://www.cnn.com/2021/03/22/media/fox-news-harris-faulkner-dhs-secretary/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 20:34:05+00:00

Fox News anchor Harris Faulkner made a grave and bizarre error on Monday, interrupting a live phone interview with former President Donald Trump to wrongly report that Department of Homeland Secretary Alejandro Mayorkas had resigned.

## Spiders and snakes swarm Australian homes as they flee record floods
 - [https://www.cnn.com/2021/03/22/australia/spider-exodus-australia-scli-intl/index.html](https://www.cnn.com/2021/03/22/australia/spider-exodus-australia-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 20:28:05+00:00

• Floods turn areas of Australia into 'inland seas'

## US announces sanctions against Chinese officials over Uyghurs
 - [https://www.cnn.com/2021/03/22/politics/us-eu-china-uyghur-sanctions/index.html](https://www.cnn.com/2021/03/22/politics/us-eu-china-uyghur-sanctions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 19:38:13+00:00

The US announced sanctions Monday against two Chinese officials for "serious human rights abuses" against Uyghur Muslims, a step coordinated with the European Union, Canada and the United Kingdom, which imposed sanctions on the same individuals and others, the Treasury Department said.

## Surfing prodigy, 22, killed after being struck by lightning
 - [https://www.cnn.com/2021/03/22/sport/katherine-diaz-killed-surfing-spt-intl/index.html](https://www.cnn.com/2021/03/22/sport/katherine-diaz-killed-surfing-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 19:23:31+00:00

A 22-year-old Olympic surfing hopeful from El Salvador has died while training for an upcoming qualifying competition, the country's National Institute for Sport (INDES) has confirmed.

## Police handcuffed husband of one of spa shooting victims for hours while she lay dead
 - [https://www.cnn.com/2021/03/22/us/spa-shootings-officers-handcuffed-husband-of-victim-trnd/index.html](https://www.cnn.com/2021/03/22/us/spa-shootings-officers-handcuffed-husband-of-victim-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 19:17:23+00:00

Mario González and his wife Delaina Yaun ventured to Youngs Asian Massage near Acworth, Georgia, last week for a relaxing couples activity.

## John Oliver calls out Meghan McCain's response to Atlanta shootings
 - [https://www.cnn.com/videos/business/2021/03/22/john-oliver-meghan-mccain-orig.cnn-business](https://www.cnn.com/videos/business/2021/03/22/john-oliver-meghan-mccain-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 19:00:30+00:00

In a segment on "Last Week Tonight with John Oliver," Oliver called out Meghan McCain for tweeting a "Stop Asian Hate" graphic after defending calling Covid-19 "the China virus" earlier in the pandemic.

## Nikes are getting harder to find at stores. Here's why
 - [https://www.cnn.com/2021/03/22/business/nike-independent-shoe-stores/index.html](https://www.cnn.com/2021/03/22/business/nike-independent-shoe-stores/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 18:53:35+00:00

Struggling to find Nike sneakers at your neighborhood shoe store? That's by design.

## Spiders and snakes swarm Australian homes as they flee record floods
 - [https://www.cnn.com/collections/oz-floods-intl-032221/](https://www.cnn.com/collections/oz-floods-intl-032221/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 18:53:18+00:00



## Video shows inundated towns after historic flooding in Australia
 - [https://www.cnn.com/videos/world/2021/03/22/nsw-floods-australia-video-lon-orig-tp.cnn](https://www.cnn.com/videos/world/2021/03/22/nsw-floods-australia-video-lon-orig-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 18:48:50+00:00

Thousands of people have been evacuated in Australia's New South Wales after parts of the state have been battered by record rainfall that led to historic flooding.

## Why Biden won't be able to totally undo Trump's tax cuts
 - [https://www.cnn.com/2021/03/22/economy/tax-hikes-biden-goldman-sachs/index.html](https://www.cnn.com/2021/03/22/economy/tax-hikes-biden-goldman-sachs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 18:43:03+00:00

President Joe Biden got almost everything he wanted with his $1.9 trillion economic rescue plan. Goldman Sachs thinks Biden will face far more resistance in his quest to unwind former President Donald Trump's tax cuts.

## Demi Lovato feels 'more joy' in her life, two years after her overdose
 - [https://www.cnn.com/2021/03/22/entertainment/demi-lovato-more-joy-trnd/index.html](https://www.cnn.com/2021/03/22/entertainment/demi-lovato-more-joy-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 18:37:35+00:00

Demi Lovato says her life is so much better since she had to "essentially die" from a 2018 overdose in order to "wake up."

## Goldman Sachs CEO responds to analyst survey describing 'inhumane' 95-hour weeks and abuse
 - [https://www.cnn.com/2021/03/22/business/goldman-sachs-saturday-rule-workplace-survey/index.html](https://www.cnn.com/2021/03/22/business/goldman-sachs-saturday-rule-workplace-survey/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 18:16:10+00:00

Goldman Sachs' CEO says the bank will strengthen enforcement of its "Saturday rule" and speed up hiring of junior bankers after a group of analysts described "inhumane" working conditions, including 95-hour weeks and instances of workplace abuse.

## Tesla's stock will rise 350% by 2025, analyst predicts
 - [https://www.cnn.com/2021/03/22/investing/tesla-shares-target-price/index.html](https://www.cnn.com/2021/03/22/investing/tesla-shares-target-price/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 17:54:24+00:00

Tesla shares have slumped in recent weeks, losing 26% of their value between a record high in late January and its closing price Friday. But at least one analyst sees better times ahead — much, much better.

## US and allies sanction Myanmar's military
 - [https://www.cnn.com/2021/03/22/politics/us-allies-burma-sanctions/index.html](https://www.cnn.com/2021/03/22/politics/us-allies-burma-sanctions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 17:38:04+00:00

US Secretary of State Antony Blinken announced new sanctions against members of Myanmar's military on Monday for the ongoing crackdown on pro-democracy protests since the military seized power in a February 1 coup.

## Brazilian governor: Millions are paying price due to 'psychopathic' Bolsonaro
 - [https://www.cnn.com/videos/world/2021/03/22/brazil-coronavirus-bolsonaro-sao-paulo-governor-joao-doria-intv-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/03/22/brazil-coronavirus-bolsonaro-sao-paulo-governor-joao-doria-intv-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 17:32:27+00:00

• See queues as Brazilians wait for a vaccine that doesn't exist

## Refugees flee on foot as massive fire destroys homes of thousands
 - [https://www.cnn.com/2021/03/22/asia/rohingya-refugee-camp-fire-bangladesh-intl/index.html](https://www.cnn.com/2021/03/22/asia/rohingya-refugee-camp-fire-bangladesh-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 17:26:46+00:00

A fire has swept through a sprawling Rohingya refugee camp in Cox's Bazar, Bangladesh, destroying shelters and endangering the lives of tens of thousands of refugees, the UN refugee agency UNHCR reported Monday.

## Supreme Court agrees to review Boston Marathon bomber's death penalty case
 - [https://www.cnn.com/2021/03/22/politics/boston-marathon-supreme-court-death-penalty/index.html](https://www.cnn.com/2021/03/22/politics/boston-marathon-supreme-court-death-penalty/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 17:01:17+00:00

The Supreme Court on Monday agreed to review a lower court opinion that wiped away the death sentence of Dzhokhar Tsarnaev, one of the brothers convicted in the 2013 Boston Marathon bombing that killed three spectators and injured hundreds.

## Photos reveal conditions for children and adults in a US Border Patrol facility
 - [https://www.cnn.com/2021/03/22/politics/border-patrol-overcrowded-photos/index.html](https://www.cnn.com/2021/03/22/politics/border-patrol-overcrowded-photos/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 16:52:41+00:00

As the number of unaccompanied migrant children crossing the US-Mexico border continues to rise, hundreds have been kept in US Border Patrol facilities not meant for minors.

## Kylie Jenner faces backlash for promoting makeup artist's GoFundMe
 - [https://www.cnn.com/2021/03/22/entertainment/kylie-jenner-gofundme-trnd/index.html](https://www.cnn.com/2021/03/22/entertainment/kylie-jenner-gofundme-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 16:40:34+00:00

Kylie Jenner seeking support for a GoFundMe effort aimed at helping pay medical bills for makeup artist Samuel Rauda did not go over well.

## Woman ends up paying $5,700 for a cup of coffee
 - [https://www.cnn.com/videos/us/2021/03/22/woman-charged-5700-for-coffee-pkg-vpx.kmgh](https://www.cnn.com/videos/us/2021/03/22/woman-charged-5700-for-coffee-pkg-vpx.kmgh)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 16:36:48+00:00

A woman in Colorado realized she was charged $5,700 for a cup of coffee she purchased on Christmas Eve in 2020. CNN affiliate KMGH reports.

## 'Our city is a tinder right now': Miami Beach extends state of emergency
 - [https://www.cnn.com/collections/intl-covid-0322/](https://www.cnn.com/collections/intl-covid-0322/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 16:33:36+00:00



## McConnell defends legislative filibuster as 'Kentucky's veto'
 - [https://www.cnn.com/2021/03/22/politics/mitch-mcconnell-filibuster-oped-kentucky-veto/index.html](https://www.cnn.com/2021/03/22/politics/mitch-mcconnell-filibuster-oped-kentucky-veto/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 16:27:43+00:00

Minority Leader Mitch McConnell explained his support for the legislative filibuster's 60-vote threshold, making the case in an op-ed in his home state paper, the Courier-Journal, published Monday that the filibuster is actually "Kentucky's veto" to prevent "radical" changes that would hurt the state.

## Why Turkey's lira is plummeting
 - [https://www.cnn.com/2021/03/22/economy/turkey-lira-erdogan-central-bank-intl-hnk/index.html](https://www.cnn.com/2021/03/22/economy/turkey-lira-erdogan-central-bank-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 16:26:37+00:00

Turkey's lira is plunging against the US dollar Monday after President Recep Tayyip Erdogan abruptly fired the head of the country's central bank this weekend.

## World's first ship tunnel to be built under Norwegian mountains
 - [https://www.cnn.com/travel/article/norway-ship-tunnel/index.html](https://www.cnn.com/travel/article/norway-ship-tunnel/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 15:39:36+00:00

Norway has got the go-ahead to construct what's being billed as the world's first ship tunnel, designed to help vessels navigate the treacherous Stadhavet Sea.

## Archaeologists uncover 3,000-year-old gold mask in southwest China
 - [https://www.cnn.com/style/article/sanxingdui-gold-mask-intl-hnk/index.html](https://www.cnn.com/style/article/sanxingdui-gold-mask-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 15:29:42+00:00

The remains of a gold mask are among a huge cache of 3,000-year-old artifacts found at an archaeological site in China's Sichuan province.

## See Claudia Conway sing on 'American Idol'
 - [https://www.cnn.com/videos/business/2021/03/22/claudia-conway-american-idol-mxp-vpx.hln](https://www.cnn.com/videos/business/2021/03/22/claudia-conway-american-idol-mxp-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 15:22:42+00:00

Claudia Conway, the daughter of former White House counselor Kellyanne Conway, performs on "American Idol."

## See queues as Brazilians wait for a vaccine that doesn't exist
 - [https://www.cnn.com/videos/world/2021/03/22/brazil-coronavirus-covid-19-vaccine-delivery-rivers-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/03/22/brazil-coronavirus-covid-19-vaccine-delivery-rivers-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 14:36:02+00:00

Brazil has seen record-breaking a record breaking death toll and rise in cases of Covid-19 recently. A shortage of medical supplies and a slow vaccine rollout has made the crisis even worse. CNN's Matt Rivers reports.

## Elon Musk responds to spying concerns in China: Trust us, we're just like TikTok
 - [https://www.cnn.com/2021/03/22/tech/elon-musk-tesla-china-military-ban-intl-hnk/index.html](https://www.cnn.com/2021/03/22/tech/elon-musk-tesla-china-military-ban-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 11:31:02+00:00

Tesla CEO Elon Musk says his company's cars would never be used for spying in China, in response to reports that the country's military has banned the vehicles over such concerns.

## Juventus decides to keep 'best in the world' Cristiano Ronaldo
 - [https://www.cnn.com/2021/03/22/football/juventus-cristiano-ronaldo-spt-intl/index.html](https://www.cnn.com/2021/03/22/football/juventus-cristiano-ronaldo-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 11:11:04+00:00

Cristiano Ronaldo will stay at Juventus beyond this season, the club's managing director Fabio Paratici said after a 1-0 defeat to Benevento.

## Brutal reality of a Kremlin-backed regime
 - [https://www.cnn.com/2021/03/22/europe/belarus-abuse-claims-intl-cmd/index.html](https://www.cnn.com/2021/03/22/europe/belarus-abuse-claims-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 10:41:12+00:00



## Leaked video from inside police stations shows ferocious beatings
 - [https://www.cnn.com/videos/world/2021/03/22/belarus-police-abuse-paton-walsh-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/03/22/belarus-police-abuse-paton-walsh-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 09:18:07+00:00

As part of a months long investigation into the crackdown inside Belarus, CNN has spoken to several Belarusians who fled the repression of President Lukashenko's regime. In dozens of interviews, protesters and opposition activists have spoken of torture -- from systematic beatings to rape with a police baton. CNN's Nick Paton Walsh reports.

## Philippines demands Chinese fishing flotilla leave disputed South China Sea reef
 - [https://www.cnn.com/2021/03/22/asia/china-fishing-boats-philippines-reef-intl-hnk/index.html](https://www.cnn.com/2021/03/22/asia/china-fishing-boats-philippines-reef-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 08:44:34+00:00

The Philippines has demanded that China recall more than 200 Chinese boats it said had been spotted at a disputed reef claimed by both Manila and Beijing, describing their presence as a "clear provocative action."

## Netanyahu has made Israel's handling of the pandemic, and its robust vaccine drive, personal
 - [https://www.cnn.com/2021/03/22/middleeast/benjamin-netanyahu-covid-election-campaign-intl/index.html](https://www.cnn.com/2021/03/22/middleeast/benjamin-netanyahu-covid-election-campaign-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 04:09:52+00:00

A mask may have been covering his face, but Benjamin Netanyahu's pleasure was undeniable as Austrian Chancellor Sebastian Kurz complimented the Israeli Prime Minister's handling of the pandemic and world-leading coronavirus vaccination campaign at an event in Jerusalem earlier this month.

## New York Rep. Tom Reed takes 'full responsibility' following allegation of sexual misconduct
 - [https://www.cnn.com/2021/03/21/politics/tom-reed-sexual-misconduct-allegation/index.html](https://www.cnn.com/2021/03/21/politics/tom-reed-sexual-misconduct-allegation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 01:03:32+00:00

Republican Rep. Tom Reed of New York apologized and took "full responsibility" on Sunday for the sexual misconduct allegations made against him by a former lobbyist.

## Former top Capitol riot prosecutor says 'maybe the President is culpable' when asked about Trump
 - [https://www.cnn.com/2021/03/21/politics/capitol-riot-prosecutor-michael-sherwin-donald-trump/index.html](https://www.cnn.com/2021/03/21/politics/capitol-riot-prosecutor-michael-sherwin-donald-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 01:01:33+00:00

The former top prosecutor for the US Capitol riot said former President Donald Trump might be "culpable" for the January 6 insurrection and federal investigators are "looking at everything," according to an interview airing on CBS Sunday night.

## Winners and losers in race for vaccine passports
 - [https://www.cnn.com/collections/intl-covid-travel-0320/](https://www.cnn.com/collections/intl-covid-travel-0320/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-03-22 00:30:35+00:00



