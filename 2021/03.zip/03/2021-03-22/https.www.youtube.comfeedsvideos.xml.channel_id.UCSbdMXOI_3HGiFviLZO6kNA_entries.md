# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Valve’s next VR projects are INSANE
 - [https://www.youtube.com/watch?v=tMt07IF4c-4](https://www.youtube.com/watch?v=tMt07IF4c-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-03-23 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. Today I’ll be covering the latest in Valve Virtual Reality patents. 3 new headset concepts that are pretty insane. Also Space Force and XR government contracts, population one, new Playstation VR controllers and more!
Hope you enjoy.

My links-

Sources-
COMING SOON

