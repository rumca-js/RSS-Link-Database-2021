# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Christian Apologist Canceled By CNN: The Sean McDowell Interview
 - [https://www.youtube.com/watch?v=2zXGM0zMYDw](https://www.youtube.com/watch?v=2zXGM0zMYDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-23 00:00:00+00:00

In this episode of The Babylon Bee Podcast, Kyle and Ethan talk to Christian Apologist and Author, Sean McDowell. They talk about Purity Culture, the BLM organization, Yoga, and evil G-Rated Disney films. Sean is an author, speaker, and apologetics professor at Biola University. Sean has earned his PhD in Apologetics and Worldview Studies from Southern Baptist Theological Seminary. He has since used his knowledge to equip the church in apologetics speaking at conferences, schools, and churches nationwide. Sean has authored, co-author or edited over 18 books on various topics in apologetics.

00:02:32 Intro
00:05:10 Teaching Apologetics to young people
00:13:28 Secular movies coming into culture
00:25:00 Tolerance and BLM
00:38:35 Purity Culture 

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation​​  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast...​

Submit Your Own Headlines: https://babylonbee.com/plans​​

The Official The Babylon Bee Store: https://shop.babylonbee.com​​

Follow The Babylon Bee:
Website: https://babylonbee.com​​
Twitter: http://twitter.com/thebabylonbee​​
Facebook: http://facebook.com/thebabylonbee​​
Instagram: http://instagram.com/thebabylonbee

## The Babylon Bee Breaks Down The Worst Tweet Of All Time
 - [https://www.youtube.com/watch?v=O-8uD88Eq44](https://www.youtube.com/watch?v=O-8uD88Eq44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-23 00:00:00+00:00

Bill Burr is in the news for being Bill Burr and a Social Justice Warrior tries to call Bill Burr a racist, which doesn’t go well once his wife gets involved.

See the full show here:  
https://youtu.be/uy5wfBZmV0k

Subscribe to The Babylon Bee: https://babylonbee.com/plans​

Hit the bell to get your daily dose of fake news that you can trust.

## The Bee Reads LOTR Is Back
 - [https://www.youtube.com/watch?v=9oaOu5YeueA](https://www.youtube.com/watch?v=9oaOu5YeueA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-03-22 00:00:00+00:00

The Bee Reads The Lord Of The Rings will continue on, but just on BabylonBee.com.

Become a subscriber today: https://babylonbee.com/plans

