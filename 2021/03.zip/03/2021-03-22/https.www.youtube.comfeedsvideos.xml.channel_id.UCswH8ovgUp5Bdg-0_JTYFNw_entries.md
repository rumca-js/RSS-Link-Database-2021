# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Fungi: Why Are We Ignoring Nature’s Hidden Solution?
 - [https://www.youtube.com/watch?v=L790O6Ot3W4](https://www.youtube.com/watch?v=L790O6Ot3W4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-03-23 00:00:00+00:00

This week I spoke with Merlin Sheldrake on my Under The Skin podcast! Merlin is a biologist and author of Entangled Life: How Fungi Make Our Worlds, Change Our Minds and Shape Our Futures. He has a background in plant sciences, microbiology, ecology, and the history and philosophy of science. Fungi are a powerful force, why are we ignoring nature's hidden solution?
The full podcast is available on Luminary: http://luminary.link/russell

For more information on Merlin’s work go to http://www.merlinsheldrake.com 

Listen to my Under The Skin podcast to hear from guests including Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Get a one month free trial at http://luminary.link/russell​

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com​/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is released on 25 March
My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn

