# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## OnePlus 9 Pro Review: A Huge Hasselblad Promise!
 - [https://www.youtube.com/watch?v=8eNNJESKjrE](https://www.youtube.com/watch?v=8eNNJESKjrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-03-23 00:00:00+00:00

OnePlus 9 Pro talks a BIG game with their Hasselblad collab. Does it live up?
The first 1000 people to use this link will get a free trial of Skillshare Premium Membership to access my class (and more): https://skl.sh/marquesbrownlee03211

OnePlus 9 Review: https://youtu.be/RY63Nw0w33w

OnePlus 9 Pro skins: http://dbrand.com/robot-camo

0:00 Intro/Price
1:26 Unboxing
2:04 Design
4:04 The OnePlus special
5:40 Specs/Performance
7:16 Battery Life & Charging
9:53 The Hasselblad Cameras
17:38 Bonus stuff
18:14 Final Rating
18:56 My First Skillshare Class!

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by OnePlus for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

