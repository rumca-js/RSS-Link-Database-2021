# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Return of the Space Planes | Answers With Joe
 - [https://www.youtube.com/watch?v=w1-QZ35sb4Q](https://www.youtube.com/watch?v=w1-QZ35sb4Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-03-22 00:00:00+00:00

The first 1000 people to use the link will get a free trial of Skillshare Premium Membership: https://skl.sh/joescott03211
Going from the Space Shuttle back to flying in capsules might feel like a bit of a step backwards, but the Space Shuttle had its problems. Problems that a new generation of space planes are looking to solve.


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.space.com/12085-nasa-space-shuttle-history-born.html

https://www.space.com/10741-space-shuttle-origins-history-nasa.html

https://www.worldatlas.com/articles/what-is-the-karman-line.html

https://www.nasa.gov/centers/dryden/history/pastprojects/Lifting/index.html

https://www.defensemedianetwork.com/stories/what-might-have-been-x-20-dyna-soar/

http://www.buran.ru/htm/molniya3.htm

http://www.astronautix.com/h/hermes.html

https://spaceflight.nasa.gov/history/station/x38/parafoil.html

http://www.russianspaceweb.com/kliper_history.html

https://www.space.com/12166-space-shuttle-program-cost-promises-209-billion.html

https://www.nasa.gov/feature/nasa-selects-blue-origin-dynetics-spacex-for-artemis-human-landers

https://spaceflightnow.com/2021/02/13/ula-delivers-vulcan-test-article-to-cape-canaveral-for-pathfinder-operations/

https://www.space.com/dream-chaser-space-plane-tenacity-tour.html

