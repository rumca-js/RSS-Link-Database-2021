# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Falcon and The Winter Soldier - Episode 1 (My Thoughts)
 - [https://www.youtube.com/watch?v=X5NhvxYdU9g](https://www.youtube.com/watch?v=X5NhvxYdU9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-03-23 00:00:00+00:00

Check out the trailer to "Own The Room" here: http://owntheroomfilm.com/?utm_campaign=jeremy_jahns&utm_medium=preroll&utm_source=youtube
Thank you to Shopify for sponsoring this video!

Episode 1 of THE FALCON AND THE WINTER SOLDIER is on Disney+ now, so here are my thoughts on the introductory episode of the MCU's newest series!

#TheFalconAndTheWinterSoldier

