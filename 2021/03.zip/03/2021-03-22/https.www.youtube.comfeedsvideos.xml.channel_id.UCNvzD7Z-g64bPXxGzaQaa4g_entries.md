# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 WORST Cash Grab Attempts By Activision
 - [https://www.youtube.com/watch?v=S89kh-BFcag](https://www.youtube.com/watch?v=S89kh-BFcag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-23 00:00:00+00:00

Activision and Blizzard have made some aggressive moves to make you part with your hard earned cash. Here are some of the biggest consumer-unfriendly examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10. The Dawning Gear - Destiny 2

ref: https://www.destructoid.com/stories/bungie-s-latest-destiny-2-event-is-pure-greed-even-by-low-loot-box-standards-478831.phtml

ref: https://www.polygon.com/2017/12/22/16811582/destiny-2-the-dawning-holiday-loot-box-community-outrage

ref: https://www.reddit.com/r/DestinyTheGame/comments/7l5k38/wait_hold_up_why_is_this_dawning_gear_so_dope/




9. Call of Duty WW2: Nazi Zombies - The Tortured Path 

ref: https://callofduty.fandom.com/wiki/The_Tortured_Path

ref: https://www.reddit.com/r/WWII/comments/95cjr3/salty_rant_the_tortured_path_easily_the_worst_map/






8. The Demo - Tony Hawk's Pro Skater 1 + 2

ref: https://www.standard.co.uk/tech/gaming/tony-hawks-pro-skater-remaster-demo-a4480106.html





7. The Summer games event - Overwatch

ref: https://www.forbes.com/sites/erikkain/2016/08/19/did-blizzard-break-a-promise-with-the-overwatch-summer-games/?sh=44cee9e53136




6.  - Skylanders

ref: http://www.binderbits.com/blog-1/2015/10/6/the-toy-to-life-craze-an-easy-cash-grab

ref: https://www.bostonherald.com/2014/10/26/its-a-good-thing-skylanders-is-fun-because-its-not-cheap/

ref: https://www.polygon.com/2014/4/16/5614716/skylanders-story-toys-for-bob-skylanders-swap-force





5. The Simpsons Wrestling -

ref: https://www.metacritic.com/game/playstation/the-simpsons-wrestling




4. Modern Warfare Remastered - Call of Duty: Infinite Warfare

ref: https://www.forbes.com/sites/insertcoin/2017/04/23/its-time-for-call-of-duty-modern-warfare-remastered-to-be-free-from-infinite-warfare/?sh=748aca4f7a17




3. The Tony Hawk Ride skateboard

ref: https://www.metacritic.com/game/playstation-3/tony-hawk-ride

ref: https://www.destructoid.com/stories/review-tony-hawk-ride-156837.phtml




2. Call of Duty: Modern Warfare - K/D Tracker

ref: https://www.alphr.com/how-to-check-your-k-d-radio-modern-warfare/





1. The Variety Map Pack - Call of Duty: Modern Warfare Remastered

ref: http://dispatches.cheatcc.com/2836




BONUS

-Crash Team racing sneaking in microtransactions (mentioned this in the 'things activision wants you to forget' video)

ref: https://www.destructoid.com/stories/activision-s-post-launch-microtransactions-are-the-peak-of-anti-consumer-practices-562857.phtml



-Warcraft 3: Reforged -  

ref: https://arstechnica.com/gaming/2021/01/warcraft-iii-reforged-tops-our-list-of-2020s-most-disappointing-video-games/

## 10 Illusions Video Games Create to LIE TO YOU
 - [https://www.youtube.com/watch?v=kxpGx3XR_vU](https://www.youtube.com/watch?v=kxpGx3XR_vU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-03-22 00:00:00+00:00

Even the best video games use clever tricks and shortcuts to make the game world more convincing or immersive. Here are more of our favorite developer illusions and tricks.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources and references:

https://twitter.com/slaktus/status/711919549218689025?lang=en

https://www.resetera.com/threads/your-thoughts-on-dantes-inferno-2010.17994/page-4

https://www.gamesradar.com/the-secret-art-of-the-video-game-loading-screen-and-why-they-wont-be-going-away-anytime-soon/

https://www.reddit.com/r/gamedev/comments/9111km/so_how_is_the_mirror_in_duke_nukem_3d_programmed/

