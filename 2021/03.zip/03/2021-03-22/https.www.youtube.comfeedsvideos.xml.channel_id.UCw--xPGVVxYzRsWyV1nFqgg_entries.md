# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## No Ageless Aes Sedai?🥲 NEW Terry Brooks Fantasy Series!✍️ Last Of Us BS🧨 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=pIr3jyOMxmY](https://www.youtube.com/watch?v=pIr3jyOMxmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-03-23 00:00:00+00:00

Let’s talk about the week's Fantasy News! From the amazing Terry Brooks to Wheel of Time, fantasy tides be moving. 
Check out my baby daddy Campfire here today: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 

00:00 Intro

00:51 Child Of Light: https://io9.gizmodo.com/terry-brooks-has-a-brand-new-fantasy-series-and-weve-g-1846494869 

03:55 Schwab comic covers: https://www.instagram.com/p/CMkSffWgKjk/?igshid=864w7ggdlder 

06:31 Wheel of Time Ageless Aes Sedai: https://www.cbr.com/wheel-of-time-rafe-judkins-aes-sedai-ageless-cgi/ 

08:37 Last of Us Changes: https://www.ign.com/articles/the-last-of-us-hbo-show-season-1-adapts-the-first-game-but-will-deviate-greatly-in-some-episodes 

10:44 Dragon Prince Board Game: https://www.youtube.com/watch?v=zzOOcI4GV1Q  

11:10 Ewok Special: https://variety.com/2021/tv/news/star-wars-holiday-special-boba-fett-ewoks-caravan-of-courage-disney-plus-1234932286/ 

12:26 Godzilla VS Kong trailer: https://www.youtube.com/watch?v=NseVUieeklg 

12:44 Resident Evil Title: https://www.ign.com/articles/resident-evil-2021-movie-welcome-to-raccoon-city-title

