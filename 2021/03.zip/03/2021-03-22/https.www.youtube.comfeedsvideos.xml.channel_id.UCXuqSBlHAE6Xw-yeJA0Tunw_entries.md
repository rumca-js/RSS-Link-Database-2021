# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Was RIGHT!!!! (and I hate it) - Semiconductor Shortage Explained
 - [https://www.youtube.com/watch?v=3A4yk-P5ukY](https://www.youtube.com/watch?v=3A4yk-P5ukY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-23 00:00:00+00:00

Go to http://Fubotv.com/linus to start your FREE trial and get 15% off your first month.

Try Pulseway for free and start remotely monitoring and managing your server or PC at https://lmg.gg/Ktd7Z

At the start of the pandemic I guessed we were about to have a massive shortage of computer hardware... and unfortunately I was right.  

This drop of the Verified Actual Gamer program is SOLD OUT. Check back soon for future drops!

Local places we love: https://linustechtips.com/topic/1318170-places-we-love/

Buy a Ryzen 9 5900X CPU: https://geni.us/SOqq

Buy an RTX 3080 GPU: https://geni.us/ESAhtm

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1318176-i-was-right-and-i-hate-it/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Your Gaming PC Has A Bottleneck!
 - [https://www.youtube.com/watch?v=_6zGlk8y1Ks](https://www.youtube.com/watch?v=_6zGlk8y1Ks)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-03-22 00:00:00+00:00

Thanks to Seasonic for sponsoring this video! Buy Seasonic PSU's
On Amazon (PAID LINK): https://geni.us/cBo1Y
On Newegg (PAID LINK): https://geni.us/bECDLlj

Whether it’s your CPU, Graphics Card, RAM, Motherboard, Case, or even your operating system, there’s always going to be something holding you back.

Buy Intel Core i3 8100 CPU (PAID LINK): https://geni.us/4VFREHx

Buy Intel Core i5 9600k CPU (PAID LINK): https://geni.us/SMqJe9

Buy Intel Core i9 9900k CPU (PAID LINK): https://geni.us/kId9B

Buy ASUS GT 1030 GPU (PAID LINK): https://geni.us/bvVNYZk

Buy ZOTAC GTX 1050 Ti Mini GPU (PAID LINK): https://geni.us/UX7jO

Buy Nvidia RTX 2060 Founder's Edition GPU (PAID LINK): https://geni.us/o6ie

Buy Cooler Master Hyper 212 EVO CPU Cooler (PAID LINK): https://geni.us/MKAgZ1A

Buy Crucial Ballistix RGB 16GB 3600mhz DDR4 RAM (PAID LINK): https://geni.us/PBpg5

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1316872-your-gaming-pc-has-a-bottleneck/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

