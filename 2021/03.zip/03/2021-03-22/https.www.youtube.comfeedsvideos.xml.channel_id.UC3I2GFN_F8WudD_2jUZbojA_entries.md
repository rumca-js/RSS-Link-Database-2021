# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Faye Webster - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=liiYpHmp89o](https://www.youtube.com/watch?v=liiYpHmp89o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-23 00:00:00+00:00

http://KEXP.ORG presents Faye Webster performing live, recorded exclusively for KEXP.

Songs:
Better Distractions
Kingston
In A Good Way
I Know I’m Funny haha
Cheers

Session recorded at Tweed Studios in Athens, GA
Engineered + Mixed by Drew Vandenberg
Filmed by Matt Swinsky

Guitar + Vocals - Faye Webster
Guitar + Pedal Steel - Matt Stoessel
Bass Guitar - Bryan Howard
Drums - Harold Brown
Keyboards - Nick Rosen

https://www.fayewebster.com
http://kexp.org

## Faye Webster - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=pnwlTwNMJNg](https://www.youtube.com/watch?v=pnwlTwNMJNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-03-22 00:00:00+00:00

http://KEXP.ORG presents Faye Webster sharing a live performance recorded exclusively for KEXP and talking to DJ Sean. Recorded March 9, 2021.

Songs:
Better Distractions
Kingston
In A Good Way
I Know I’m Funny haha
Cheers

Session recorded at Tweed Studios in Athens, GA
Engineered + Mixed by Drew Vandenberg
Filmed by Matt Swinsky

Guitar + Vocals - Faye Webster
Guitar + Pedal Steel - Matt Stoessel
Bass Guitar - Bryan Howard
Drums - Harold Brown
Keyboards - Nick Rosen

https://www.fayewebster.com
http://kexp.org

