# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Jeroen Tel - Eliminator Ingame (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=JbawUQHp07g](https://www.youtube.com/watch?v=JbawUQHp07g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-03-22 00:00:00+00:00

"Eliminator" (C64, 1988) ingame theme by Jeroen Tel. Art is using Christopherjam palette for more saturated colors.

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

