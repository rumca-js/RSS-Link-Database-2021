## Bill Gates tells Reddit why he's bought so much farmland
 - [https://agfundernews.com/bill-gates-tells-reddit-why-hes-acquired-so-much-farmland](https://agfundernews.com/bill-gates-tells-reddit-why-hes-acquired-so-much-farmland)
 - RSS feed: https://agfundernews.com
 - date published: 2021-03-22 14:26:56+00:00

Bill Gates tells Reddit why he's bought so much farmland

