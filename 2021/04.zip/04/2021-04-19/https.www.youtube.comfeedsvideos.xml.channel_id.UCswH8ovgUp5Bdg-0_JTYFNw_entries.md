# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Super League Breakaway - Impossible Greed?
 - [https://www.youtube.com/watch?v=2ggsqrqoWyc](https://www.youtube.com/watch?v=2ggsqrqoWyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-04-20 00:00:00+00:00

Fans and pundits have vented their anger at plans for six English Premier League teams to join a breakaway European Super League in a move seemingly all about money. Could this galvanise fans and the general public to challenge power and create change?
#SuperLeague #GaryNeville #Football #ManchesterUnited #Liverpool #PremierLeague

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Under The Skin podcast to hear from guests including Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Get a 7 day free trial at http://luminary.link/russell

My Audible Original, ‘Revelation', is out NOW!
US: 
http://adbl.co/revelation
UK: 
http://adbl.co/revelationuk
AU: 
http://adbl.co/revelationau
CA: 
http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

