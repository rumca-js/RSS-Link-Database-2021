# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Thinking Out Loud | Ed Sheeran | funk cover ft. Ty Taylor + MonoNeon
 - [https://www.youtube.com/watch?v=8uRmBpnLdNs](https://www.youtube.com/watch?v=8uRmBpnLdNs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-04-19 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Ed Sheeran's "Thinking Out Loud" by Scary Pockets & Ty Taylor.

MUSICIAN CREDITS
Lead vocal: Ty Taylor
Drums: Tamir Barzilay
Bass: MonoNeon
Keys: Jack Conte
Guitar: Ryan Lerman
Keys, Synth, Percussion: Jake Sherman

AUDIO CREDITS
Recording Engineer/Mixing/Mastering: Caleb Parker
Producer: Jake Sherman

VIDEO CREDITS
DP: Ricky Chavez
Director: Mike Dempsey
Camera Operators: Ricky Chavez, Sammy Rothman, Alex Humphrey
Editor: Adam Kritzberg
Art Design: KJ Sadural
Tech: Joonas Cohen

Recorded Live at EastWest in Los Angeles, CA.

#ScaryPockets #Funk #EdSheeran #TyTaylor #ThinkingOutLoud

