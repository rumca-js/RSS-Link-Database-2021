# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Interview: Colin Meloy of The Decemberists
 - [https://www.youtube.com/watch?v=LQqiLFPqRQc](https://www.youtube.com/watch?v=LQqiLFPqRQc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-20 00:00:00+00:00

Colin Meloy and Mac Wilson sit down for a virtual interview as The Decemberists celebrate their 20th anniversary this month. The two look back at iconic releases and memories from The Decemberists' catalog, and  discuss the craft of building a setlist in the age of streams.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

Credits
Host - Mac Wilson
Technical Director - Eric Romani
Producer - Derrick Stevens
Digital Producer - Jesse Wiza

## Chris Koza - The Blackberry Moon (2011)
 - [https://www.youtube.com/watch?v=gfZG29lJkBM](https://www.youtube.com/watch?v=gfZG29lJkBM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-19 00:00:00+00:00

Back in April 2011, jeremy messersmith hosted Works for Words, an event at the Fitzgerald Theater in St. Paul, Minn., where messersmith welcomed a group of friends — including Chris Koza — for a night of the best lyrical works in song. From that night 10 years ago at the Fitz, here's a performance by Chris Koza of his band Rogue Valley's song, "The Blackberry Moon," from their 2010 album, "The Bookseller's House."

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#chriskoza #roguevalley

