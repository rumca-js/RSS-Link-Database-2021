# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Case For Hydrogen - With Matt Ferrell | Answers With Joe
 - [https://www.youtube.com/watch?v=AoXJYPfag1I](https://www.youtube.com/watch?v=AoXJYPfag1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-04-19 00:00:00+00:00

Big thanks to Matt Ferrell for guest hosting this episode!
Much has been made about hydrogen fuel cells and their use in cars, but there are many other uses for hydrogen that make more sense. We examine those in today's video.

CHECK OUT MATT'S CHANNEL HERE:
https://www.youtube.com/user/mtf169


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

