# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The HTC Vive Air is WEIRD
 - [https://www.youtube.com/watch?v=MLpSPbdusIc](https://www.youtube.com/watch?v=MLpSPbdusIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-04-20 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. Today I have some good and bad Oculus Quest 2 news as well as news on the new HTC Vive Air.. which well never see.. plus some new decagear info. 

HIGH SCHOOL HEROES LINKS: https://www.hsvrleague.com/
QUEST 2 GIVEAWAY: https://gleam.io/A5mtF/thrill-od-oculus-quest-2-giveaway


My links:
2nd Channel:
https://youtu.be/Xp-p5RGoGpM
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill
Ridge Wallet
ridge.com/THRILL + 10% off


Sources:
https://uploadvr.com/htc-vive-air-concept

