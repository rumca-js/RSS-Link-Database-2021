# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Rejected By David Letterman, Accepted By Christ: The John Branyan Interview
 - [https://www.youtube.com/watch?v=WqxlRr67l0c](https://www.youtube.com/watch?v=WqxlRr67l0c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-20 00:00:00+00:00

On The Babylon Bee Interview Show, Ethan and Dan talk to stand-up comedian, John Branyan. They talk comedy, frogs, and bad Atheist memes. John Branyan has been doing stand-up comedy for the last 25 years. His ‘Shakespeare’ version of The Three Little Pigs has been viewed more than a million times on YouTube. He has written his second book titled, Life is Hardy-Har-Hard: How to Use Comedy to Make Your Life Better in which he discusses why we need to laugh more at ourselves when we fall down, especially if a banana peel is involved. 

Buy John's book here: 
https://www.amazon.com/Life-Hardy-Har-Hard-Comedy-Make-Better-ebook/dp/B08795148J

Find his website here: 
https://johnbranyan.com/

Start of the show 00:02:44
Rejected by Letterman 00:05:21
Dissecting Comedy 00:23:58
Why we want to see you fall 00:34:52

Subscribe on iTunes: https://podcasts.apple.com/us/podcast...​

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans​

The Official The Babylon Bee Store: https://shop.babylonbee.com​

Follow The Babylon Bee:
Website: https://babylonbee.com​
Twitter: http://twitter.com/thebabylonbee​
Facebook: http://facebook.com/thebabylonbee​
Instagram: http://instagram.com/thebabylonbee

## Lego Introduces New Sharper Bricks That Instantly Kill You When You Step On Them
 - [https://www.youtube.com/watch?v=R1X_QuKoSf0](https://www.youtube.com/watch?v=R1X_QuKoSf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-19 00:00:00+00:00

Coming soon from Lego! Instant Death Legos! Avoid the pain normally caused by stepping on Lego bricks with this new, advanced Lego brick that kills you instantly!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

