# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## How Ocean Currents Work (and How We Are Breaking Them)
 - [https://www.youtube.com/watch?v=f2evaLaDvCI](https://www.youtube.com/watch?v=f2evaLaDvCI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-04-19 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

Head over to Animal IQ on Terra: https://youtu.be/Nc3mUNkJZZk
Celebrate Earth Day with other PBS Channels! https://bit.ly/32nmIsp

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

Ocean currents are our planet’s circulatory system, and they keep everything from ecosystems to the climate healthy. But we’re changing Earth in ways that threaten to disrupt and even break critical ocean currents like the planet-wide Great Ocean Conveyor. This could have devastating effects on our future. In this video, we explain how ocean currents work, how climate change is threatening to disrupt them, and what we can do to stop that from happening.

References: https://sites.google.com/view/ocean-conveyor-belt/home 

-----------

Big Thank you to our Brain Trust Patrons:

Andrew Campbell 
Robert
Brian Chang
Roy Lasris
Javier Soto
dani bowman
David Johnston
Zenimal
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Benjamin Teinby
Eric Meer
Peter Ehrnstrom
Dustin
Marcus Tuepker
Karen Haskell
AlecZero


Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

