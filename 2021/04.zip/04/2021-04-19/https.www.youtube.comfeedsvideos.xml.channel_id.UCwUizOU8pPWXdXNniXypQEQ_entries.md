# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## When You Take Coffee TOO Seriously!
 - [https://www.youtube.com/watch?v=NjjX28mnrIc](https://www.youtube.com/watch?v=NjjX28mnrIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-04-20 00:00:00+00:00

Check out my NEW MERCH here! - https://awakenwithjp.com

Check out my favorite coffee: http://BlackRifleCoffee.com/JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

What happens when you take coffee too seriously? Coffee lovers are just the right amount of obsessed with their one true love!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

