# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Action Bronson Remembers DMX
 - [https://www.youtube.com/watch?v=0hD6mcKEc4s](https://www.youtube.com/watch?v=0hD6mcKEc4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-20 00:00:00+00:00

Taken from JRE #1637 w/Action Bronson:
https://open.spotify.com/episode/1d1WYWULDiZeIrGremIubi?si=b35cd92a5fdd440c

## Action Bronson on Losing 130lbs
 - [https://www.youtube.com/watch?v=qEWHetW2W4k](https://www.youtube.com/watch?v=qEWHetW2W4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-20 00:00:00+00:00

Taken from JRE #1637 w/Action Bronson:
https://open.spotify.com/episode/1d1WYWULDiZeIrGremIubi?si=b35cd92a5fdd440c

