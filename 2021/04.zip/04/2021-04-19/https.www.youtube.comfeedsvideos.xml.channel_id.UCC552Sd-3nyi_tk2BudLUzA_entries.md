# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## What Happens When You Quit Marijuana?
 - [https://www.youtube.com/watch?v=7u_cm5b1s7Y](https://www.youtube.com/watch?v=7u_cm5b1s7Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-04-20 00:00:00+00:00

When you stop smoking weed, your body changes. This is what happens in the first 28 days of quitting.
Quitting Marijuana Podcast: https://youtu.be/bJ726lxPwvc

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Greg Brown
Edited by: Luka Šarlija
Clipart by: https://vectortoons.com

People are likely watching the Marvel Shang-Chi trailer, or the Jake Paul fight, or Drag Race like us WITH THE MUNCHIES THESE DAYS! I have been thinking about the neurophysiology of quitting weed since being stuck at home, it's more of a habit. It turns out the brain changes a lot with weed, also there physiological symptoms I didn't know before, and all the science is not cutting edge. This video goes through the scientific evidence of how your body changes after consuming weed.

References:
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4015312/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3986824/
https://www.statista.com/statistics/587705/marijuana-consumption-canada-by-age/
https://www.washingtonpost.com/news/wonk/wp/2017/04/19/11-charts-that-show-marijuana-has-truly-gone-mainstream/
https://pubmed.ncbi.nlm.nih.gov/29556883/
https://pubmed.ncbi.nlm.nih.gov/31040502/
https://pubmed.ncbi.nlm.nih.gov/30039154/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2797098/

