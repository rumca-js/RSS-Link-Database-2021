# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 SECRET Console Features Discovered Years Later
 - [https://www.youtube.com/watch?v=XuXFSknJt_Y](https://www.youtube.com/watch?v=XuXFSknJt_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-20 00:00:00+00:00

Some video game consoles have hidden features, tricks, and even games inside of them that took years to discover. Here are our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources and references:

Dreamcast fishing: https://youtu.be/s_qxOR-QR0E


PS1 memory card restore trick:
https://www.youtube.com/watch?v=-aFIUAbL2cg

Secret master system game: https://segaretro.org/Snail_Maze

Expansion pak: https://nintendo.fandom.com/wiki/Nintendo_64_Expansion_Pak

Dreamcast hack: https://youtu.be/34i3uhXCipk

3DS sound: https://youtu.be/9K1B586ATws

Breakout: https://youtu.be/zKar7eOvuOI

Gamecube: https://www.youtube.com/watch?v=rjEsXf3SJ6o&t=64s

## Resident Evil 8 Village: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=A5P8S1dr3sA](https://www.youtube.com/watch?v=A5P8S1dr3sA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-20 00:00:00+00:00

Resident Evil Village (PC, PS5, PS4, Xbox One, Xbox Series X|S) is launching soon! Here's everything you need to know to be caught up.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources and references:

https://www.youtube.com/watch?v=v-hd-76EAPE&t=23s

https://www.dexerto.com/gaming/resident-evil-village-weapons-guide-1554883/

https://www.reddit.com/r/HighQualityReloads/comments/mjbmhe/resident_evil_8_tactical_reload/

https://twitter.com/Wario64/status/1382829228677234692

Clip via Where's Barry: https://www.youtube.com/channel/UCoBS-YX2Hd9ZLtsPEd6Kdnw

## The Day Before's Ambitious Take on Division Meets Last of Us
 - [https://www.youtube.com/watch?v=at2WCJxy9nY](https://www.youtube.com/watch?v=at2WCJxy9nY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-19 00:00:00+00:00

The Day Before caught our eye after a reveal trailer. Is it too ambitious? Too derivative? Full of potential? Let's dive in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

