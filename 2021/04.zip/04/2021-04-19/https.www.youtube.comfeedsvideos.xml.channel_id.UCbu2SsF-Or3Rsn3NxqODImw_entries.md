# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Alanah Pearce Answers 24 Questions
 - [https://www.youtube.com/watch?v=QAHi_udJt9I](https://www.youtube.com/watch?v=QAHi_udJt9I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-20 00:00:00+00:00

What’s Alanah Pearce’s strangest expression of Batman fandom? Her hair routine? And, most importantly, what is fairy bread? Alanah Pearce answers those and more in this special Q&A.

Alanah’s YouTube Channel: https://www.youtube.com/user/Charalanahzard

You may know Alanah Pearce from Funhaus, IGN, or maybe even her voice acting work in Cyberpunk 2077. Needless to say, Alanah has had a long and diverse career in the games industry, and is now working at God of War developer Sony Santa Monica Studio as a games writer. 

Alanah could be one of the busiest people in the industry. When she’s not writing a game, she’s uploading videos to her YouTube channel, making short films like One Year, streaming and raising money for charities such as AbleGamers, and hosts her very own podcast Play, Watch, Listen, featuring industry sweethearts like Troy Baker, Austin Wintory, and Mike Bithell. And yet, still, she took time out of her day to answer 24 questions about her work, her routines, and Australian delicacies. 

In the above video, Alanah goes over her favorite swear word, her favorite Batman collectible, whether or not she can break an egg by squeezing it in her hand, and many more.

You can follow Alanah on Twitter here: https://twitter.com/Charalanahzard

## Apex Legends Legacy - What We Know So Far
 - [https://www.youtube.com/watch?v=IckaR6LNsuE](https://www.youtube.com/watch?v=IckaR6LNsuE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-20 00:00:00+00:00

Apex Legends Legacy is scheduled to begin May 4, following the conclusion of the game's War Games event. Legacy will add a new playable character, weapon, and map overhaul to Apex Legends.

In the video above, Jordan Ramée details everything we know about Legacy so far, such as who the new playable character is. Kairi "Valkyrie" Imahara is the daughter of Titanfall 2's Viper, taking to the skies in Apex Legends with a jetpack fashioned from the remains of her father's Northstar Titan.

Alongside Valkyrie, Legacy will add the Bocek Bow, a powerful mid-range weapon. The new season will also redesign Olympus, which will become infested with plantlife. As usual, the new season will also add a new battle pass to unlock and challenges to complete, though Respawn is cryptically teasing that there will be something more this time around.

Respawn recently celebrated Apex Legends reaching 100 million players. Apex Legends is also getting a mobile port called Apex Legends Mobile, which will begin beta testing this spring.

## Every Mortal Kombat 9 Fatality
 - [https://www.youtube.com/watch?v=fAoG8nGBYsI](https://www.youtube.com/watch?v=fAoG8nGBYsI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-20 00:00:00+00:00

Mortal Kombat turns ten! Well, to be clear, Mortal Kombat 9 is celebrating its ten-year anniversary. To commemorate MK 9’s special day, we’ve compiled a complete round-up of fatalities from Scorpion to Kitana to Freddy Krueger.

00:00 - Scorpion
00:33 - Kung Lao
01:01 - Sub-Zero
01:35 - Sindel
01:56 - Ermac
02:20 - Reptile
02:58 - Johnny Cage
03:28 - Jade
03:53 - Mileena
04:26 - Kitana
04:49 - Nightwolf
05:16 - Cyrax
05:41 - Sonya Blade
06:06 - Noob Saibot
06:31 - Smoke
06:58 - Liu Kang
07:25 - Jax
07:52 - Sektor
08:18 - Kano
08:41 - Stryker
09:10 - Shang Tsung
09:42 - Baraka
10:09 - Kabal
10:35 - Raiden
11:07 - Cyber Sub-Zero
11:34 - Sheeva
12:10 - Quan Chi
12:29 - Skarlet
13:05 - Kenshi
13:30 - Rain
13:54 - Freddy Krueger

## Everything To Know About Black Ops Cold War Season 3 In Under 4 Minutes
 - [https://www.youtube.com/watch?v=AbppSp9WaE4](https://www.youtube.com/watch?v=AbppSp9WaE4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-20 00:00:00+00:00

Call Of Duty: Black Ops Cold War and Warzone are entering Season 3 with limited-time events, new operators including Wraith, new weapons including the PPSH-41, new 6v6 maps like the Yamantau mountain, a new scorestreak, and added content for Zombies. 

Call Of Duty: Black Ops Cold War and Warzone are entering Season 3 with some huge changes to core multiplayer and Warzone. Cold War is getting three new operators, including Wraith, Knight, and Antonov. Not to be left out, Modern Warfare’s Captain Price will also be joining the roster. Season 3 will add six new weapons:PPSh-41: SMG, Swiss K31: Sniper Rifle, Ballistic Knife, CARV.2: Tactical Rifle, AMP63: Pistol, and a Baseball Bat. 

In terms of locations, Cold War picks up four multiplayer locations, which are Yamanatau, Diesel, Standoff, and Duga. Yamantau is a mountainous 6v6 map; Diesel supports multiple player counts and is set in a badlands gas station; Standoff is a classic Black Ops 2 remake map, and Duga is a multi-team map set around the massive radar array in the Ural Mountains. Alongside these maps are added modes, such as Sticks and Stones, as well as Multi-Team Elimination, which sounds a lot like classic battle royale with teams fleeing radiation zones. Finally, there’s a new mid-tier Scorestreak: Strafe Run that lasts longer than comparable streaks Napalm Strike and is designed for better area denial. 

On the other hand, Zombies fans are getting the new Field Upgrade: Toxic Growth, a special perk that can be used in round-based maps and Outbreak, which slows zombies with a deadly growth of toxic thorns. The Duga region will also come to Outbreak with new secrets to find. 

Finally, the Warzone map event has entered a Containment Protocol phase with Corruption Zones springing up around the map that can turn players into zombies leading up to Operation Rapid Sunder on Wednesday, April 21st.

## Apex Legends | Stories from the Outlands –  Northstar
 - [https://www.youtube.com/watch?v=h-AsMeFRPJE](https://www.youtube.com/watch?v=h-AsMeFRPJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-19 00:00:00+00:00

Check out the all new Apex Legends | Stories from the Outlands - Northstar trailer! Stories from the Outlands - Northstar takes us into the Titanfall universe and shows off a potential new legend in, Valk! 

#ApexLegends #Titanfall #Valk

## Resident Evil Village Preview
 - [https://www.youtube.com/watch?v=pNsufTHEra4](https://www.youtube.com/watch?v=pNsufTHEra4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-19 00:00:00+00:00

We got a glimpse of an hour of Resident Evil Village footage that primarily focused on the the village, and Lady Dimitrescu's castle. Resident Evil Village looks like a combination of Resident Evil 7 and the more action-oriented Resident Evil 4. The village portion of the game has heavy Resident Evil 4 vibes, with Ethan fighting through hordes of werewolf-like creatures. In the castle, though, Ethan will have to deal with the vampiric Lady Dimitrescu and her daughters. The castle looks like a big change of pace from the more action-heavy village are, as you'll primarily be avoiding Lady Dimitrescu and her daughters, rather than fighting them. Resident Evil Village's next demo, which drops at 5 PM PDT Saturday, April 24, will allow you to explore the Castle for 30 minutes on PlayStation 4 and PlayStation 5.

## Zelda BOTW Pro Speedrunner and Combat Expert React to New Viral Clips
 - [https://www.youtube.com/watch?v=plywqaNzMv8](https://www.youtube.com/watch?v=plywqaNzMv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-19 00:00:00+00:00

We gathered Breath of the Wild pro speedrunner Limcube and combat expert RinHara5aki together to break down some speedruns, combat, glitches, and more.

Breath of the Wild is the game that keeps on giving, with people still finding new things four years later. Luca Jakobi, aka "Limcube," and Max Blumenthal, aka "RinHara5aki," specialize in two separate fields of Breath of the Wild and react to interesting new viral Breath of the Wild clips. 

Limcube previously has done reacts videos and consistently speedruns Breath of the Wild to this day, even performing runs for Games Done Quick. He optimizes speedruns, as well, to make new routes. RinHara5aki is one of the first to delve into Breath of the Wild combat specifically, and with his videos amassing more than 13 million views, he continues to document and push the game's evolving combat system.

In the video above, the pair breaks down what's going on behind the scenes, how difficult the techniques are, and how they're performed. Complex glitches such as Extended Shield clips, Horse Slides, Spaceships, Shield Block Resets, and others are examined.

