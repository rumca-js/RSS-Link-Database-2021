## ‘Covid is just an excuse’: the scandal of Rome’s saturated cemeteries | Italy | The Guardian
 - [https://www.theguardian.com/world/2021/apr/29/shameful-situation-rome-cemeteries-run-out-of-space](https://www.theguardian.com/world/2021/apr/29/shameful-situation-rome-cemeteries-run-out-of-space)
 - RSS feed: https://www.theguardian.com
 - date published: 2021-04-19 08:16:06+00:00

‘Covid is just an excuse’: the scandal of Rome’s saturated cemeteries | Italy | The Guardian

