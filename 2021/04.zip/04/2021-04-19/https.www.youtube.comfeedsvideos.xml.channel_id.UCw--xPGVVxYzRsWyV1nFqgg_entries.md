# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Amazon Cancels LotR RPG😱 Mistborn Series Update🗡️ Possible DUNE Sequel⏳-FANTASY NEWS
 - [https://www.youtube.com/watch?v=cNft0tcEnzE](https://www.youtube.com/watch?v=cNft0tcEnzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-04-20 00:00:00+00:00

New Officer Same old Fantasy News! Let's talk about everything from Mistbron to Lord Of The Rings!! 
BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)


Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/


Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 


NEWS: 


00:00 intro


00:49 Wisdom of Crowds: https://twitter.com/SciFiNow/status/1382982102916886533 


01:49 Dune Sequel: https://collider.com/dune-movie-update-eric-roth-interview/ 


01:50 Red Rising Update: https://www.instagram.com/p/CNvTVGHFIVI/?igshid=qi60uxv8abks 


02:39 Blood Of The Chosen: https://twitter.com/orbitbooks/status/1383146795832897537/photo/1 


03:08 Amazon Cancels LotR MMORPG: https://www.ign.com/articles/amazon-cancels-its-the-lord-of-the-rings-mmorpg 


03:54 LotR Budget: https://www.rnz.co.nz/news/political/440587/government-to-give-amazon-over-100m-boost-for-lord-of-the-rings-filming 


05:05 Winter Soldier Co-creator upset: https://www.ign.com/articles/winter-soldier-co-creator-ed-brubaker-criticize-marvel-studios 


06:16 Predator Lawsuit: https://www.hollywoodreporter.com/thr-esq/predator-screenwriters-suing-disney-to-recapture-rights 


07:19 Disney Must Pay Update: https://www.reddit.com/r/Fantasy/comments/mrfz6g/disney_and_alan_dean_foster_reach_agreement_on/?utm_medium=android_app&utm_source=share 


08:26 NK Jemisin Class: https://www.youtube.com/watch?v=mZVRXistd5k&ab_channel=MasterClass 


08:51 Greenbone Saga Update: https://twitter.com/FondaJLee/status/1381697948203896833?s=20 


10:02 Mistborn Series Update: https://twitter.com/CosmereNetwork/status/1384293188572094465

