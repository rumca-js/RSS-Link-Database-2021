# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Tune Yards - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=laGUZH0YOkg](https://www.youtube.com/watch?v=laGUZH0YOkg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-20 00:00:00+00:00

http://KEXP.ORG presents Tune-Yards performing live, recorded exclusively for KEXP.

Songs:
Hold Yourself
Hypnotized
My Neighbor
Make It Right

Session recorded at Tiny Telephone in San Francisco, CA on February 2, 2021
Merrill Garbus: Vocals, keys
Nate Brenner: Bass
Hamir Atwal: Drums
Ayo Awosika: Backup Vocals
Moira Smiley: Backup Vocals
Matt Nelson: Saxophone

https://tune-yards.com
http://kexp.org

## Tune Yards - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=O5oRXdidpsI](https://www.youtube.com/watch?v=O5oRXdidpsI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-19 00:00:00+00:00

http://KEXP.ORG presents Tune-Yards sharing a live performance, recorded exclusively for KEXP and talking to Larry Mizell, Jr., host of the Afternoon Show. Recorded March 30, 2021.

Songs:
Hold Yourself
Hypnotized
My Neighbor
Make It Right

Session recorded at Tiny Telephone in San Francisco, CA on February 2, 2021
Merrill Garbus: Vocals, keys
Nate Brenner: Bass
Hamir Atwal: Drums
Ayo Awosika: Backup Vocals
Moira Smiley: Backup Vocals
Matt Nelson: Saxophone

https://tune-yards.com
http://kexp.org

