# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Starship Troopers - Deceptively Smart Satire
 - [https://www.youtube.com/watch?v=S8nM5N4ptkw](https://www.youtube.com/watch?v=S8nM5N4ptkw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-04-19 00:00:00+00:00

I've been waiting a long time for this one. Paul Verhoeven's 1997 sci-fi action epic, Starship Troopers, turned out to be a surprisingly sharp and biting satire on modern culture. Would you like to know more? 


Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

