# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## See how Dr. Gupta was surprised for 20 years at CNN
 - [https://www.cnn.com/videos/health/2021/04/19/dr-sanjay-gupta-20-years-at-cnn-pkg-tsr-vpx.cnn](https://www.cnn.com/videos/health/2021/04/19/dr-sanjay-gupta-20-years-at-cnn-pkg-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 23:53:53+00:00

Dr. Sanjay Gupta was surprised with a look back at his career to celebrate his 20 years at CNN.

## A White friend and a Black friend experienced two very different traffic stops in Minneapolis
 - [https://www.cnn.com/videos/politics/2021/04/19/police-traffic-stops-comparison-minneapolis-minnesota-orig-me.cnn](https://www.cnn.com/videos/politics/2021/04/19/police-traffic-stops-comparison-minneapolis-minnesota-orig-me.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 19:17:01+00:00

Two friends, on White and one Black, were pulled over for speeding on separate occasions. They compare their experiences with traffic stops in the Minneapolis suburbs.

## John Oliver to White Americans: 'March in the streets'
 - [https://www.cnn.com/videos/business/2021/04/19/john-oliver-fatal-police-shootings-monologue-orig.cnn-business](https://www.cnn.com/videos/business/2021/04/19/john-oliver-fatal-police-shootings-monologue-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 17:10:13+00:00

Listen to John Oliver address the recent fatal police shootings of Daunte Wright and Adam Toledo in a passionate monologue on "Last Week Tonight."

## See moment child is saved from oncoming train
 - [https://www.cnn.com/videos/world/2021/04/19/child-saved-from-train-india-lon-orig-tp.cnn](https://www.cnn.com/videos/world/2021/04/19/child-saved-from-train-india-lon-orig-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 16:20:55+00:00

CCTV cameras captured the moment a railroad worker saved the life of a child who slipped and fell onto the tracks at a station in Mumbai.

## 'Passion of the Christ' actor pushes false QAnon theory
 - [https://www.cnn.com/videos/media/2021/04/19/jim-caviezel-theory-donie-osullivan-qanon-pkg-newday-vpx.cnn](https://www.cnn.com/videos/media/2021/04/19/jim-caviezel-theory-donie-osullivan-qanon-pkg-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 12:18:20+00:00

CNN's Donie O'Sullivan reports on the false QAnon conspiracy theory pushed by "Passion of the Christ" star Jim Caviezel.

## Did China's former Premier just subtly criticize President Xi Jinping?
 - [https://www.cnn.com/2021/04/19/china/wen-jiabao-xi-jinping-china-mic-intl-hnk/index.html](https://www.cnn.com/2021/04/19/china/wen-jiabao-xi-jinping-china-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 08:00:10+00:00

Under President Xi Jinping, China's former leaders have grown accustomed to keeping their heads down.

## 12 European football teams to form breakaway 'Super League'
 - [https://www.cnn.com/2021/04/18/sport/football-super-league-announced/index.html](https://www.cnn.com/2021/04/18/sport/football-super-league-announced/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 07:57:22+00:00

Twelve of the top football clubs in Europe made an announcement Sunday that may shift the landscape of European football.

## A body with Covid washed ashore. Now this Pacific Island nation isn't taking any chances
 - [https://www.cnn.com/2021/04/19/asia/vanuatu-covid-body-intl-hnk/index.html](https://www.cnn.com/2021/04/19/asia/vanuatu-covid-body-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 07:33:18+00:00

A Pacific Island country has banned outward travel from its main island for three days after a body washed ashore that later tested positive for Covid-19, Radio New Zealand has reported.

## In the race between Covid-19 vaccines and the virus, hesitancy gives dangerous variants a leg up, expert says
 - [https://www.cnn.com/2021/04/19/health/us-coronavirus-monday/index.html](https://www.cnn.com/2021/04/19/health/us-coronavirus-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 06:54:31+00:00

More than half of all US adults have now gotten at least one dose of a Covid-19 vaccine, according to data from the Centers for Disease Control and Prevention.

## Chinese feminists are being silenced by nationalist trolls. Some are fighting back
 - [https://www.cnn.com/2021/04/19/china/china-feminists-silenced-intl-hnk-dst/index.html](https://www.cnn.com/2021/04/19/china/china-feminists-silenced-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 06:43:05+00:00

The torrent of hate messages filling Liang Xiaowen's inbox stopped as suddenly as it had started.

## Mars helicopter's first flight could happen on Monday
 - [https://www.cnn.com/2021/04/17/world/mars-helicopter-ingenuity-flight-monday-scn-trnd/index.html](https://www.cnn.com/2021/04/17/world/mars-helicopter-ingenuity-flight-monday-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 05:59:14+00:00

The Ingenuity helicopter is preparing for its historic flight on Mars Monday if everything goes according to plan. The first powered, controlled flight on another planet will take place at 3:30 a.m. ET on April 19, according to NASA.

## Trump calls Afghanistan withdrawal 'a wonderful and positive thing to do' and criticizes Biden's timeline
 - [https://www.cnn.com/2021/04/18/politics/trump-afghanistan-troop-withdrawal/index.html](https://www.cnn.com/2021/04/18/politics/trump-afghanistan-troop-withdrawal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 05:57:31+00:00

• Analysis: Joe Biden is meeting the cold reality of office

## 'Out of control' fire breaks out in Cape Town's Table Mountain National Park
 - [https://www.cnn.com/2021/04/18/africa/table-mountain-south-africa-fire-intl-afr/index.html](https://www.cnn.com/2021/04/18/africa/table-mountain-south-africa-fire-intl-afr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 05:49:17+00:00

An "out of control" fire has broken out in Cape Town's Table Mountain National Park on Sunday, according to South African officials, prompting the evacuation of hikers from the city's most famous landmark.

## Trump calls Afghanistan withdrawal 'a wonderful and positive thing to do' and criticizes Biden's timeline
 - [https://www.cnn.com/collections/intl-afghanistan-withdrawal-0419/](https://www.cnn.com/collections/intl-afghanistan-withdrawal-0419/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 05:22:51+00:00



## Max Verstappen wins at Imola but Lewis Hamilton stays ahead
 - [https://www.cnn.com/2021/04/18/motorsport/max-verstappen-lewis-hamilton-imola-gp-spt-intl/index.html](https://www.cnn.com/2021/04/18/motorsport/max-verstappen-lewis-hamilton-imola-gp-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 05:21:52+00:00

Red Bull's Max Verstappen won a chaotic and crash-halted Emilia Romagna Grand Prix at Imola on Sunday, with Lewis Hamilton second for Mercedes and retaining the lead in the championship by a single point.

## See who won at the Academy of Country Music Awards 2021
 - [https://www.cnn.com/2021/04/18/entertainment/acm-awards-2021-winners/index.html](https://www.cnn.com/2021/04/18/entertainment/acm-awards-2021-winners/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 05:18:04+00:00

The Academy of Country Music Awards, celebrating the best in country music, are being presented Sunday.

## Bitcoin suffers flash crash following week of crypto hype
 - [https://www.cnn.com/2021/04/18/business/bitcoin-sharp-fall/index.html](https://www.cnn.com/2021/04/18/business/bitcoin-sharp-fall/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 04:08:13+00:00

After a hype-filled week for cryptocurrencies, Bitcoin experienced a flash crash over the weekend, plunging nearly 14% in less than an hour, from about $59,000 to $51,000, on Saturday night before rebounding. Other popular cryptocurrencies including ethereum and Dogecoin also fell dramatically, before recouping some of their losses.

## Mass shootings and the Chauvin trial force America to confront its culture of violence
 - [https://www.cnn.com/2021/04/19/politics/mass-shootings-police-violence-chauvin-trial-george-floyd/index.html](https://www.cnn.com/2021/04/19/politics/mass-shootings-police-violence-chauvin-trial-george-floyd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 04:03:48+00:00

America is being forced to confront a basic failure to keep its own citizens safe with a murderous daily churn of mass shootings and the nation on edge for the end of the trial into George Floyd's murder.

## After centuries of nomadic living, Thailand's 'sea people' adapt to life on land
 - [https://www.cnn.com/travel/article/thailand-tourism-sea-people-moken/index.html](https://www.cnn.com/travel/article/thailand-tourism-sea-people-moken/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 03:22:45+00:00

These days, Salamak Klathalay, like most of us, lives in a house, on land. But this is a relatively new experience for the 78-year-old.

## Vaccine giant puts 'catastrophic' hold on exports
 - [https://www.cnn.com/collections/intl-global-covid-0418/](https://www.cnn.com/collections/intl-global-covid-0418/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 03:20:25+00:00



## US and China agree to cooperate on climate change after talks in Shanghai
 - [https://www.cnn.com/collections/intl-climate-change-0419/](https://www.cnn.com/collections/intl-climate-change-0419/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 01:25:07+00:00



## Mars didn't lose all of its water at once, based on Curiosity rover find
 - [https://www.cnn.com/2021/04/18/world/mars-water-curiosity-rover-scn/index.html](https://www.cnn.com/2021/04/18/world/mars-water-curiosity-rover-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 01:13:57+00:00

Mars was a warm, wet planet that was likely capable of supporting life billions of years ago. Something caused the planet to lose its atmosphere and turn into the harsh, frozen desert it is today.

## Younger Americans are least likely to vaccinate
 - [https://www.cnn.com/collections/intl-covid-0416/](https://www.cnn.com/collections/intl-covid-0416/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-19 00:58:58+00:00



