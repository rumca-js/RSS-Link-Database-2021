# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## American Conservative covers Right To Repair and NAILS it!
 - [https://www.youtube.com/watch?v=ZCRpoj8cuvw](https://www.youtube.com/watch?v=ZCRpoj8cuvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-10 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.theamericanconservative.com/articles/david-vs-goliath-and-the-right-to-repair/
https://www.gofundme.com/f/lets-get-right-to-repair-passed

## Judge allows case against Apple over display defect to continue
 - [https://www.youtube.com/watch?v=1CRTk3XThNg](https://www.youtube.com/watch?v=1CRTk3XThNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-10 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.macrumors.com/2021/04/01/apple-flexgate-macbook-pro-models-court/
https://www.ifixit.com/News/13979/apples-2018-macbook-pros-attempt-to-solve-flexgate-without-admitting-it-exists
https://support.apple.com/13-inch-macbook-pro-display-backlight-service
https://youtu.be/_b3tnN7AtkI

## Right to Repair fundraiser raised over $450,000 in a week
 - [https://www.youtube.com/watch?v=fz_GgFR1jYM](https://www.youtube.com/watch?v=fz_GgFR1jYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-09 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.gofundme.com/f/lets-get-right-to-repair-passed SUPERCHATS & STREAMLABS DO NOT GO TO THE 501C4 FOR RIGHT TO REPAIR, THEY GO TO LOUIS. PLEASE REMEMBER THAT! 


This is a continuation of these three videos:


https://www.youtube.com/watch?v=dWIF3ZRpf0I

https://www.youtube.com/watch?v=U8wBKfaZ1jw
https://www.youtube.com/watch?v=umqM01cMWZg
https://www.youtube.com/watch?v=VAC53PqWr4E
About the platform: https://www.reddit.com/r/hardware/comments/mgs7gd/louis_rossmann_crowdfunds_for_right_to_repair/gsvqvnc?utm_source=share&utm_medium=web2x&context=3 https://drive.google.com/file/d/1MgbW2fU0rQcJ6od0SoJuzqGETjwjpDrC/view



Copy & paste link if it doesn't work, youtube redirect breaks it. 
🔵 Duck: https://amzn.to/30aUCQ5
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

SUPERCHATS & STREAMLABS DO NOT GO TO THE 501C4 FOR RIGHT TO REPAIR, THEY GO TO LOUIS. PLEASE REMEMBER THAT! Post a message: https://streamlabs.com/louisrossmann  - this goes to Louis, not 501c4! Same with superchats - superchats do NOT go to right to repair lobbying.

