# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Xiaomi Mi 11 Ultra - Wygina się?
 - [https://www.youtube.com/watch?v=tvZmrOrMIqE](https://www.youtube.com/watch?v=tvZmrOrMIqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-04-10 00:00:00+00:00

I czy ten ekran do selfie się do czegokolwiek nadaje?
Mi 11 Ultra (wersja global) - https://bit.ly/3daFoSJ
Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

