# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Modular Techno Set: Thomann Keys & Frequencies
 - [https://www.youtube.com/watch?v=sxe6EylQt7k](https://www.youtube.com/watch?v=sxe6EylQt7k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-04-09 00:00:00+00:00

I was asked to play the Thomann Keys & Frequencies streaming event and decided to use the same rig I've been using for a bit. This is the final showing for this rig for a while! 124 improvised techno with a few edits to keep it under 30 minutes.
If you like this style, check out my album Cast in Amber: https://fanlink.to/castinamber
Read more about this rig here: https://www.patreon.com/posts/let-me-tell-you-46839588
Watch a video about this rig here: https://youtu.be/Hwn6Yu_cJTI
Check out my NYMS set with this rig here: https://youtu.be/JG3NqDSmDeA
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

