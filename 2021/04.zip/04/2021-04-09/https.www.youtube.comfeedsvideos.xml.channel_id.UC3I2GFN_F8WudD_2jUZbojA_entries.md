# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Flock of Dimes - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=K0mrkMDgwo4](https://www.youtube.com/watch?v=K0mrkMDgwo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-10 00:00:00+00:00

http://KEXP.ORG presents Flock of Dimes performing live, recorded exclusively for KEXP.

Songs:
Two
Price of Blue
Lightning
Hard Way
The Weakness in Me (Joan Armatrading cover)

Session Filmed by Cricket Arrison
Edited by Seannie Bryan
Recorded and Mixed by Jenn Wasner

https://www.flockofdimes.com
http://kexp.org

## Flock of Dimes - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=KV0Z9bG0b-w](https://www.youtube.com/watch?v=KV0Z9bG0b-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-09 00:00:00+00:00

http://KEXP.ORG presents Flock of Dimes sharing a live performance recorded exclusively for KEXP and talking to Cheryl Waters. Recorded March 26, 2021.

Songs:
Two
Price of Blue
Lightning
Hard Way
The Weakness in Me (Joan Armatrading cover)

Session Filmed by Cricket Arrison
Edited by Seannie Bryan
Recorded and Mixed by Jenn Wasner

https://www.flockofdimes.com
http://kexp.org

