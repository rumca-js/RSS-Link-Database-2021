# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Can Catholics Be Pro-Choice?
 - [https://www.youtube.com/watch?v=U0teEDLD080](https://www.youtube.com/watch?v=U0teEDLD080)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-10 00:00:00+00:00

On The Babylon Bee Interview Show, Bishop Barron, Kyle, and Ethan talk about how believers of Christ shouldn’t accept the “modern peace treaty” of keeping their faith private and detached from any public spaces, while also avoiding imposing religious authoritarianism.

See the full show here:
https://youtu.be/xCv3kquDCL4

Hit the bell to get your daily dose of fake news that you can trust!

## Project Veritas Goes Undercover To Expose The Babylon Bee
 - [https://www.youtube.com/watch?v=gPkPXppfvkQ](https://www.youtube.com/watch?v=gPkPXppfvkQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-09 00:00:00+00:00

James O'Keefe of Project Veritas exposes The Babylon Bee by hacking into the site's conference call, revealing the site is actually dangerous misinformation and not satire at all. Not good!

Become a premium subscriber: https://babylonbee.com/plans​

The Official The Babylon Bee Store: https://shop.babylonbee.com​

Follow The Babylon Bee:
Website: https://babylonbee.com​
Twitter: http://twitter.com/thebabylonbee​
Facebook: http://facebook.com/thebabylonbee​
Instagram: http://instagram.com/thebabylonbee

