# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Tom Segura Fully Explains His Dunk Injury
 - [https://www.youtube.com/watch?v=Cw7MSbLs3Uo](https://www.youtube.com/watch?v=Cw7MSbLs3Uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-10 00:00:00+00:00

Taken from JRE #1632 w/Tom Segura:
https://open.spotify.com/episode/0PtNt3U5pawDwslM0IUTAW?si=d861074fa2a54726

