# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Robimy prawdziwe meksykańskie tacos i guacamole! Przepis
 - [https://www.youtube.com/watch?v=GkCrXqYwz20](https://www.youtube.com/watch?v=GkCrXqYwz20)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2021-04-10 00:00:00+00:00

🗺️ Meksyk #15. Dziś mała odskocznia od vlogów podróżniczych. Wraz z Sofi nauczymy się przygotowywać tacosy z guacamole i salsą pico de gallo!

Instagram Sofi: https://www.instagram.com/cocinawithsofi/
La Espirituosa: https://www.instagram.com/la.espirituosa/
Airbnb experience: https://www.airbnb.com/experiences/1205273

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

//Salsa "przypalana"
2 pomidory
4 ząbki czosnku
pół cebuli
pół habanero

//Salsa pico de gallo
2 pomidory
pół dużej cebuli
jalapeño
Kolendra
Awokado
Oliwa z oliwek, sól, pieprz

//Marynata do mięsa
300 g mięsa wieprzowego (sprawdzić jakiego)
pół pomarańczy
pół mandarynki
dwa ząbki czosnku
wino czerwone
oliwa z oliwek, sól, pieprz

/drink
dopiszę jutro

Vlogi z Meksyku (2021): http://bit.ly/3c7Jycf
Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #Meksyk

