# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Top 5 Mercedes EQS Features: Electric Luxury!
 - [https://www.youtube.com/watch?v=wUqZQTp_gpI](https://www.youtube.com/watch?v=wUqZQTp_gpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-04-11 00:00:00+00:00

This is the perfect type of car to go electric... but I'd still rather be driven in this car than drive it! The 2022 Mercedes EQS

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Equillibre by Hocus Pocus
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

