# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Can Catholics Be Pro-Choice?
 - [https://www.youtube.com/watch?v=U0teEDLD080](https://www.youtube.com/watch?v=U0teEDLD080)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-10 00:00:00+00:00

On The Babylon Bee Interview Show, Bishop Barron, Kyle, and Ethan talk about how believers of Christ shouldn’t accept the “modern peace treaty” of keeping their faith private and detached from any public spaces, while also avoiding imposing religious authoritarianism.

See the full show here:
https://youtu.be/xCv3kquDCL4

Hit the bell to get your daily dose of fake news that you can trust!

