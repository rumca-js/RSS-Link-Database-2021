## #Upscaling hd 50 fps - Volkswagen Golf GTi - Singing in the Rain (2005, UK)
 - [https://www.youtube.com/watch?v=Myxb1f07cAo](https://www.youtube.com/watch?v=Myxb1f07cAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnRk6CzqFBW4Em3SBw6RDiw
 - date published: 2021-04-10 00:00:00+00:00

Original video: https://www.youtube.com/watch?v=sTP_2EAzXdk

Gene Kelley's most beloved number is remixed in more ways than one in an ad that, like the car, puts a fresh spin on old traditions. Directed by NE-O at Stink, with VFX by MPC.

#Upscaling to 1080p & interpolation to 50 Fps by https://www.reparafoto.com

