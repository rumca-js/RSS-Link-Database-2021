# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 25 NEW Switch Games of 2021
 - [https://www.youtube.com/watch?v=8n5WN7P1AqM](https://www.youtube.com/watch?v=8n5WN7P1AqM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-11 00:00:00+00:00

Nintendo Switch is seeing no shortage of games available to play throughout 2021. Here's what we're either currently playing or looking forward to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

25 Evil Dead: The Game

Platform : Switch PS5 XSX|S PS4 Xbox One PC

Release Date : 2021



24 Hot Wheels Unleashed 

Platform : Switch PS5 XSX|S PS4 Xbox One PC 

Release Date : September 30, 2021



23 Shin Megami Tensei V

Platform : Switch 

Release Date : 2021 



22 No More Heroes 3

Platform : Switch 

Release Date : August 27, 2021 



21 Eastward

Platform : Switch PC

Release Date : 2021



20 Big Rumble Boxing Creed Champions

Platform : Switch PC PS4 Xbox One 

Release Date : Q2 2021



19 Diablo II: Resurrected

Platform : Switch PS5 XSX|S PS4 Xbox One PC

Release Date : 2021



18 Persona 5 Strikers

Platform : Switch PC PS4 

Release Date : February 23, 2021



17 Samurai Warriors 5

Platform : Switch PS4 PC Xbox One

Release Date : July 27, 2021 



16 Bayonetta 3

Platform : Switch 

Release Date : 2021 



15 Pokemon Brilliant Diamond and Shining Pearl

Platform : Switch 

Release Date : Late 2021



14 Miitopia 

Platform : Switch 

Release Date : May 21, 2021 



13 BRAVELY DEFAULT II

Platform : Switch 

Release Date : February 26, 2021 



12 Lego Star Wars: The Skywalker Saga

Platform : Switch PS5 XSX|S PS4 Xbox One PC 

Release Date : TBA 2021



11 New Pokemon Snap                                                                      

Platform : Switch 

Release Date : April 30, 2021



10 Monster Hunter Stories 2: Wings of Ruin

Platform : Switch PC

Release Date : July 9, 2021



9 Hitman 3

Platform : Switch PS5 XSX|S PS4 Xbox One PC  Stadia

Release Date : 20 January 2021



8 Knockout City

Platform : Switch PS5 XSX|S PS4 Xbox One PC 

Release Date : May 21, 2021



7 Subnautica: Below Zero

Platform : Switch PS5 XSX|S PS4 Xbox One PC 

Release Date : May 14, 2021



6 Mario Golf Super Rush

Platform : Switch

Release Date : June 25, 2021



5 Super Mario 3D World + Bowser's Fury

Platform : Switch 

Release Date : February 12, 2021



4 Little Nightmares II

Platform : Switch PC PS4 Xbox One Stadia 

Release Date : 11 February 2021 



3 Legend of Zelda: Skyward Sword HD

Platform : Switch 

Release Date : July 16, 2021 



2 Monster Hunter Rise

Platform : Switch 

Release Date : March 26, 2021 



1 Breath of the Wild 2

Platform : Switch 

Release Date : TBA 2021



BONUS

Destroy All Humans!

Platform : PC Xbox One PS4 Switch Stadia                               

Release Date : June 2021



Tony Hawk's Pro Skater 1 + 2

Platform : Switch (2021) (PC PS4 Xbox One Sep 4, 2020)

Release Date : PS5 XSX|S March 26, 2021 



Maneater

Platform : Switch PS5 XSX|S PS4 Xbox One PC 

Release Date : May 25, 2021



Crash Bandicoot 4: It's About Time 

Platform : Switch PS5 XSX|S PC Xbox One PS4 

Release Date : March 12, 2021

## 10 Best Games of 2007 We NEVER FORGOT
 - [https://www.youtube.com/watch?v=dcstjRa4DBs](https://www.youtube.com/watch?v=dcstjRa4DBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-10 00:00:00+00:00

2007 was one of the best years for video game releases...let's take a trip down memory lane and revisit some of the best games from that year. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

