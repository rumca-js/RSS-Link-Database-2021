# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Interview: Jack Antonoff of Bleachers
 - [https://www.youtube.com/watch?v=_ZrdPaO9MzA](https://www.youtube.com/watch?v=_ZrdPaO9MzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-10 00:00:00+00:00

Maddie catches up with Bleachers' Jack Antonoff about listening to your gut and filtering out the noise when it comes to songwriting, his quarantine dreams, and who his first source of confidence was as a music producer.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Night Moves - two songs at The Current (2016)
 - [https://www.youtube.com/watch?v=1aAmnckrwcs](https://www.youtube.com/watch?v=1aAmnckrwcs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-10 00:00:00+00:00

As we continue to feature Minnesota music this month, today we're sharing a couple of songs by Minneapolis band Night Moves. 

On March 25, 2016, Night Moves released "Pennied Days," their sophomore album, and they also stopped by The Current to chat with host Jade and to perform the new songs live in the studio. Watch two performances from that session.

SONGS PERFORMED
0:00 "Carl Sagan"
4:09 "Denise, Don't Wanna See You Cry"

PERSONNEL
John Pelant – vocals, guitar
Micky Alfano – bass
Jared Isabella – drums
Charles Murlowski – guitar, keys

CREDITS
Video & Photo: Leah Garaas
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2011 studio session: https://www.thecurrent.org/feature/2011/05/23/night_moves
2012 studio session: https://www.thecurrent.org/feature/2012/10/15/night-moves-live
2016 studio session:
https://www.thecurrent.org/feature/2016/03/25/night-moves-perform-in-the-current-studio
2019 studio session:
https://www.thecurrent.org/feature/2019/07/18/night-moves-perform-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#nightmoves #nightmovesmpls #nightmovesband

