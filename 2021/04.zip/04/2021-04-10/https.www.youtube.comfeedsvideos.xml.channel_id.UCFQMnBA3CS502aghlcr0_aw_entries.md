# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Reviewing Fake Guru Memes
 - [https://www.youtube.com/watch?v=-g7FX0GD1kQ](https://www.youtube.com/watch?v=-g7FX0GD1kQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-04-10 00:00:00+00:00

Pumping the reddit all week bois.
►Reddit: https://reddit.com/r/coffeezilla_gg

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Sociopaths On Stage Selling Ponzi Schemes
 - [https://www.youtube.com/watch?v=r5CaLjB22Nk](https://www.youtube.com/watch?v=r5CaLjB22Nk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-04-10 00:00:00+00:00

Free money at 20% returns... what could go wrong?

More reading on the Income Store Debacle
https://lancasteronline.com/business/local_business/feds-accuse-website-selling-firm-of-56m-scam-force-its-lancaster-office-to-close/article_c1b33774-371b-11ea-afb8-5b04b60324e5.html
https://www.chicagotribune.com/business/ct-biz-income-store-ponzi-websites-20200304-wuzxfrixpfaudmqvw7titqodsi-story.html

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

