# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Isolated Tracks Episode 8: Daniel Lanois
 - [https://www.youtube.com/watch?v=mNglW_7ibsg](https://www.youtube.com/watch?v=mNglW_7ibsg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-11 00:00:00+00:00

In this episode of Isolated Tracks KEXP Audio Engineer Julian Martlew talks to Grammy winning producer Daniel Lanois about the songs "Power, Way Down, and Under The Heavy Sun" from his new album "Under The Heavy Sun".

To hear the full songs: https://www.youtube.com/channel/UCxEfNic0agoEydDyDLB0UQw

Thumbnail photo by: Marthe Vannebo
http://kexp.org

## Flock of Dimes - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=K0mrkMDgwo4](https://www.youtube.com/watch?v=K0mrkMDgwo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-10 00:00:00+00:00

http://KEXP.ORG presents Flock of Dimes performing live, recorded exclusively for KEXP.

Songs:
Two
Price of Blue
Lightning
Hard Way
The Weakness in Me (Joan Armatrading cover)

Session Filmed by Cricket Arrison
Edited by Seannie Bryan
Recorded and Mixed by Jenn Wasner

https://www.flockofdimes.com
http://kexp.org

