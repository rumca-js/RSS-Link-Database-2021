# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Outriders Is a Surprisingly Fun Looter Shooter | The Escapist Show
 - [https://www.youtube.com/watch?v=B-36NIHL0vg](https://www.youtube.com/watch?v=B-36NIHL0vg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-04-11 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Today on The Escapist Show, Nick is joined by special guest Parris Lilly of GamerTag Radio and Kinda Funny to discuss their thoughts on Outriders and whether or not the industry has already moved on from E3.

Timestamps
Outriders impressions 0:00 - 19:13
Has the industry moved on from E3 19:15 - 37:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#Outriders #E3

## Almost 30 Years Late to Alone in the Dark | Behind Schedule
 - [https://www.youtube.com/watch?v=FebNPtsmJPU](https://www.youtube.com/watch?v=FebNPtsmJPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-04-10 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

In this episode of Behind Schedule, Jesse Galena gives his retro review take on Frédérick Raynal and Infogrames’ Alone in the Dark.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#AloneintheDark

