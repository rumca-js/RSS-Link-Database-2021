# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## This Smart Home Isn’t Stupid
 - [https://www.youtube.com/watch?v=85yH56DS5mg](https://www.youtube.com/watch?v=85yH56DS5mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2021-04-10 00:00:00+00:00

I show the ultimate smart house—one that does everything I want and nothing I don’t.
Check out Serena Shades by Lutron - https://serenashades.com

Snazzy Labs gives you a tour of his smart house built on three distinct principles: (1) all smart devices must be controllable non-smartly—either via a remote or on-device button, (2) all devices must integrate into a singular, centralized app with a singular voice assistant, and, (3) automation must never get in the way. This is a smart home that’s not stupid.

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Thumbnail by Richard Waterworth - https://YouTube.com/richardtech

