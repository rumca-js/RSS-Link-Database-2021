# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Slaze - Recharge (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=dn1PWFds1N0](https://www.youtube.com/watch?v=dn1PWFds1N0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-04-11 00:00:00+00:00

"Recharge" by Slaze/Defiance (Hans Daniel Celion), 15th at Revision Online 2021 tracked music compo. Art "Quick introduction" by Koyot1222, 5th at Revision Online 2021 oldskool gfx compo.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## Amiga music: Slimey & Virgill - The Codewizard (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=_H1S_mwGbxs](https://www.youtube.com/watch?v=_H1S_mwGbxs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-04-11 00:00:00+00:00

"The Codewizard" by Slimey & Virgill/Maniacs of Noise (Aaron & Jochen Feldkötter), 2nd at Revision Online 2021 tracked music compo. Art "Welcome to Omega 6" by Critikill/Brainstorm^Rebels, 1st at Revision Online 2021 oldskool gfx compo.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

