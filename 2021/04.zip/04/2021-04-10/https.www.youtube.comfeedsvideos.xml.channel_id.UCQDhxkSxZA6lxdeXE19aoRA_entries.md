# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## eBay Score! - $130 iPhone "Parts Only" LOT
 - [https://www.youtube.com/watch?v=yQa1o8jNnmw](https://www.youtube.com/watch?v=yQa1o8jNnmw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-04-10 00:00:00+00:00

--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
Tools I Use: https://www.hughjeffreys.com/tools

Get parts, tools, and thousands of free repair guides from iFixit at: 
                               https://iFixit.com/hughjeffreys
Australian Store: https://ifix.gd/2FPxhKy
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

