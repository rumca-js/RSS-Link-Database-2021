# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Why They Moved the All Star Game to Colorado
 - [https://www.youtube.com/watch?v=Vv1XG1PgLkY](https://www.youtube.com/watch?v=Vv1XG1PgLkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-04-10 00:00:00+00:00

Grab your Magnesium Breakthrough at https://magnesiumbreakthrough.com/jp
Use code "JP2021" for a deal!

Brent's Channel - https://www.youtube.com/user/Official2030

Check out my NEW MERCH here! - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

In this video you’ll learn why major-league baseball moved the All-Star game from Georgia to Colorado. You’ll understand why the Georgia voting law forced this virtue signaling decision with incredible genius behind it. Luckily there’s no hypocrisy that we are willing to see.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

