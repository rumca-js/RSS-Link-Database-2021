# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete Travels of Saruman | Tolkien Explained
 - [https://www.youtube.com/watch?v=_c0FRHuJ5vw](https://www.youtube.com/watch?v=_c0FRHuJ5vw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-04-10 00:00:00+00:00

Covering the complete tale of Saruman the White, from his origins and early travels in the East, taking control of Isengard, and creating his own ring, all the way through to his eventual death in The Shire.  We will track all of Saruman's travels and deeds as he turns from a great wizard to an ally of Sauron to a traitor to both the Dark Lord and the White Council.

*Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!*  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, I highly recommend checking out these amazing artists online!

Ted Nasmith - https://www.tednasmith.com/shop/
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc

Saruman's Staff - Alexandr Elichev
Saruman - Daniel Pilla
Scouring of the Shire - Owen William Weber
Celebrimbor and Annatar - WETA
Forging the One Ring - Marko Manev
Ring of Doom - Jacek Kopalski
Saruman the White - Matt DeMino
Rise of Isengard - LOTRO
The Blue Wizards - Daniel Pilla
Gandalf is received by Cirdan 
Saruman's Corruption - Donato GIancola
The Istari - Angel Falto
Gandalf in the Libraries of Minas Tirith - Donato Giancola
Saruman with the Palantir - Anna Kulisz
Attack on Dol Guldur - Angus McBride
Saruman and the Palantir - The Brothers Hildebrandt
Orthanc in the Second Age - Ted Nasmith
Eowyn - Sara Morello
Wormtongue and Theoden - Donato Giancola
Uruk Hai - Skinny22
King Theoden and Grima Wormtongue - Alan Lee
Saruman - AlMaNeGrA
Forging The One Ring - Marko Manev
Saruman - Eyal Degabli
Saruman of Many Colours - Francesco Amadio
Gandalf: A Light in the Dark - Matthew Stewart
Nan Curunir - LOTRO
The Nazgul - Anato Finnstark
Saruman the White - Matt DeMino
Flight of the Ford - Cristi B
Dunelending - John Howe
Saruman - ZiJian
Treant - Nikaleles
The Ents Destroy Isengard - John Howe
Parley with Saruman - Ivan Cavini
Saruman - Suzanne Helmigh
Saruman - John Howe
The Defiance of Saruman - Carl Lundgren
Aragorn and Palantir - Magali Villeneuve
Pippin Steals the Palantir - Anke Eissmann
Orthanc Destroyed - John Howe
Saruman is Overtaken - Ted Nasmith
Saruman - Sandrine Gestin
The Scouring of the Shire - Inger Edelfeldt
Scouring of the Shire - Disco Gangsta
Death of Saruman - Joel Merriner

#saruman #tolkien #lordoftherings

