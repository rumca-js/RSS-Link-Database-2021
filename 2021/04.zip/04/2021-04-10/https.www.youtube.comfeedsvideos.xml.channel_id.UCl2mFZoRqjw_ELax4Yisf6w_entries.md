# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Paul Daniels' BREAKTHROUGH discovery explains no spill liquid damage to Apple products
 - [https://www.youtube.com/watch?v=60cNyLdVqMI](https://www.youtube.com/watch?v=60cNyLdVqMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.youtube.com/watch?v=r5OIhu_J-Tc&t=3621s
https://youtube.com/19pld73

## The pandemic is ending even if COVID is still here.
 - [https://www.youtube.com/watch?v=tl4t0dQj-iY](https://www.youtube.com/watch?v=tl4t0dQj-iY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.bloomberg.com/opinion/articles/2021-04-06/covid-not-even-a-fourth-wave-can-crush-vaccine-optimism-now

## American Conservative covers Right To Repair and NAILS it!
 - [https://www.youtube.com/watch?v=ZCRpoj8cuvw](https://www.youtube.com/watch?v=ZCRpoj8cuvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-10 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.theamericanconservative.com/articles/david-vs-goliath-and-the-right-to-repair/
https://www.gofundme.com/f/lets-get-right-to-repair-passed

## Judge allows case against Apple over display defect to continue
 - [https://www.youtube.com/watch?v=1CRTk3XThNg](https://www.youtube.com/watch?v=1CRTk3XThNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-10 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.macrumors.com/2021/04/01/apple-flexgate-macbook-pro-models-court/
https://www.ifixit.com/News/13979/apples-2018-macbook-pros-attempt-to-solve-flexgate-without-admitting-it-exists
https://support.apple.com/13-inch-macbook-pro-display-backlight-service
https://youtu.be/_b3tnN7AtkI

