# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## 5 Animals With Superpowered Senses
 - [https://www.youtube.com/watch?v=elIOKDaIVBc](https://www.youtube.com/watch?v=elIOKDaIVBc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-04-11 00:00:00+00:00

From the ability to see “invisible” types of light to the power to taste all over their body, meet five incredible animals whose super senses far surpass our own!

Hosted by: Michael Aranda

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara Growing Violet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, Katie Marie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
Correspondence with Dr. John T. Caprio
https://pubmed.ncbi.nlm.nih.gov/24395960/
https://pubmed.ncbi.nlm.nih.gov/24458639/
https://www.sciencealert.com/now-we-know-how-the-mantis-shrimp-s-tiny-brain-processes-such-amazing-vision
https://onlinelibrary.wiley.com/doi/abs/10.1002/cne.24788
https://www.sciencedaily.com/releases/2008/03/080320120732.htm
https://pubmed.ncbi.nlm.nih.gov/18356053/

https://www.nature.com/articles/nature03250
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4731273/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3172592/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3386870/
https://www.guinnessworldrecords.com/world-records/fastest-eater-(mammals)

https://pubmed.ncbi.nlm.nih.gov/23180048/
https://pubmed.ncbi.nlm.nih.gov/33119653/
https://pubmed.ncbi.nlm.nih.gov/32077991/

https://pubmed.ncbi.nlm.nih.gov/7685945/
https://pubmed.ncbi.nlm.nih.gov/28502972/
https://www.livescience.com/32970-what-animal-has-the-best-sense-of-taste.html
https://science.sciencemag.org/content/344/6188/1154.long 

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5389353/
https://pubmed.ncbi.nlm.nih.gov/28432322/
https://www.nps.gov/yose/blogs/bear-series-part-one-a-bears-sense-of-smell.htm
https://mashable.com/article/bear-sense-of-smell/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3512284/pdf/joa0221-0609.pdf

Image sources:
https://bit.ly/32bJLGF
https://bit.ly/32c9S0a
https://bit.ly/3g5HJjp
https://bit.ly/3sbmj6R
https://bit.ly/3a91IKn
https://bit.ly/3a9gGA2
https://bit.ly/3gcQwjF
https://bit.ly/3mIg1KQ
https://bit.ly/2Q4lEHn
https://bit.ly/32egrPH
https://bit.ly/3a9297t
https://bit.ly/3mLE63m
https://bit.ly/329lJMB
https://bit.ly/3uMfydn
https://bit.ly/3tj4pk1
https://bit.ly/3ddmPgA
https://bit.ly/3dbJU3c
https://bit.ly/3x1JLYb
https://bit.ly/3x3u0jo
https://bit.ly/3mVnQ09
https://bit.ly/3gfGIoW
https://bit.ly/2QgLSWZ
https://bit.ly/3wTpuE4
https://bit.ly/3tkqO0n
https://bit.ly/2PS5DED
https://bit.ly/3mIgBIw
https://bit.ly/3x1K2dF
https://bit.ly/3ddjKgk
https://bit.ly/2PTPrTk
https://bit.ly/3dZ14A7
https://bit.ly/3soKcIx
https://bit.ly/2QqaJHK
https://bit.ly/3a4WX4s
https://bit.ly/3g8HVyv
https://bit.ly/3dfm8Dp
https://bit.ly/3mLERcI
https://bit.ly/3ti96uz
https://bit.ly/2ORrvzq
https://bit.ly/3a7CUm7
https://bit.ly/3e3UPLq
https://bit.ly/3g8SFwU

