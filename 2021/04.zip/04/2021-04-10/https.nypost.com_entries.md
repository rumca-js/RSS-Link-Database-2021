## Inside BLM co-founder Patrisse Khan-Cullors' real-estate buying binge
 - [https://nypost.com/2021/04/10/inside-blm-co-founder-patrisse-khan-cullors-real-estate-buying-binge/](https://nypost.com/2021/04/10/inside-blm-co-founder-patrisse-khan-cullors-real-estate-buying-binge/)
 - RSS feed: https://nypost.com
 - date published: 2021-04-10 19:51:55+00:00

Inside BLM co-founder Patrisse Khan-Cullors' real-estate buying binge

