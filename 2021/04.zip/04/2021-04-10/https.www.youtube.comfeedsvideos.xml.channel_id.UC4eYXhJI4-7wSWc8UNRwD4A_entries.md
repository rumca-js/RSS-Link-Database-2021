# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Amplify with Lara Downes: Regina Carter
 - [https://www.youtube.com/watch?v=MkpZIlLYQpo](https://www.youtube.com/watch?v=MkpZIlLYQpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-04-10 00:00:00+00:00

Lara Downes | April 10, 2021
When Duke Ellington famously coined the phrase "beyond category," he was talking about freedom — of choice, of expression, of belonging. He meant following your heart and your instincts into an artistic territory without borders. And that's the place where violinist Regina Carter makes her home. She plays everything — jazz, classical, R&B, Latin, blues, country, pop, you name it. It doesn't matter because, as she says, she just likes to call herself "a violinist." She's always done things beautifully, spectacularly her own way.

I look at the musical life Regina has made, and I see courage. I know it's not easy to do things your own way. But courage, as Regina says in our conversation, is just survival. You follow your heart because you have to, because you don't know any better, because it's the only way to get to where you need to go.

I'm blessed to call Regina my friend and my creative collaborator. She is one of the kindest people I've ever met — generous in spirit, honest and truly open-minded. At the very beginning of our new friendship, which started during this pandemic year, we made a misstep on our way to collaboration: We chose the wrong project at first, and tried to make it fit. But then we let ourselves admit our discomfort and show each other the cracks in our courage, and we helped each other find the way back. We're working on something together now that feels just right — something we found by following our hearts, in our own way.

