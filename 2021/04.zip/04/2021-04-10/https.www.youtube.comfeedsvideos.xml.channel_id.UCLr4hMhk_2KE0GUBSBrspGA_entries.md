# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Małpy cierpią grając w Ponga. Microsoft Edge, Xiaomi Mi 11 Ultra, DJI AIR 2S, Pixel 5A
 - [https://www.youtube.com/watch?v=xRf3ExmxvM0](https://www.youtube.com/watch?v=xRf3ExmxvM0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-04-11 00:00:00+00:00

Poza tym:
Można sobie zlicytować Samsunga:
S21: https://bit.ly/3d54274
S21 Ultra 5G: https://bit.ly/3d544vI
Clubhouse umożliwi płacenie twórcom: https://bit.ly/2PMek3i
Edge lepszy od Chrome'a: https://bit.ly/3dQIQkp
Xiaomi Mi 11 Ultra się wygina: https://bit.ly/3s47djL
Wyginający się smartfon od Lenovo: https://youtu.be/Jz_vxrm8rjM
DJI AIR 2S przecieki: https://bit.ly/3t8Srt7
Pixel 5A przecieki: https://bit.ly/3uFoUHP
Elon Musk męczy małpy: https://bit.ly/2PWAKPh
Wyciek danych z FB: https://bit.ly/3dSAR6q

Moje sociale:
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

## Xiaomi Mi 11 Ultra - Wygina się?
 - [https://www.youtube.com/watch?v=tvZmrOrMIqE](https://www.youtube.com/watch?v=tvZmrOrMIqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-04-10 00:00:00+00:00

I czy ten ekran do selfie się do czegokolwiek nadaje?
Mi 11 Ultra (wersja global) - https://bit.ly/3daFoSJ
Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

