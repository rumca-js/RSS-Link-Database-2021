# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Thunder Force Is Absolute Garbage
 - [https://www.youtube.com/watch?v=e5yMR5LP0Vc](https://www.youtube.com/watch?v=e5yMR5LP0Vc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-04-10 00:00:00+00:00

Why do I do this to myself? Somehow I made it through Thunder Force, and man, I was not prepared for just how bad this movie is. Grab a stiff drink or three, and strap in as I review this stinker.

