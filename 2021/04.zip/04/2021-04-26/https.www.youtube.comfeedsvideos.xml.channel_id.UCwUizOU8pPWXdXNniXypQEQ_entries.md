# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## NEWS UPDATE - The World is Burning!
 - [https://www.youtube.com/watch?v=u5RJFAb44IA](https://www.youtube.com/watch?v=u5RJFAb44IA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-04-27 00:00:00+00:00

Check out my NEW MERCH here! - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

In this breaking news update you’ll find out about the latest ridiculousness from around the world! Everything from BLM, LeBron James, Caitlyn Jenner, Gavin Newsom, the White House, and the border crisis. The worlds on fire and things have never been better, this episode will help you go deeper to sleep!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

