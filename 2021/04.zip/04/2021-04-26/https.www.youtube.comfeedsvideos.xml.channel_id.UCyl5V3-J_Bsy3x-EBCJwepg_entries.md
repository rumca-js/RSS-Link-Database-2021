# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## How To Fail At Getting On The Letterman Show
 - [https://www.youtube.com/watch?v=sKish2qUR2M](https://www.youtube.com/watch?v=sKish2qUR2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-27 00:00:00+00:00

On The Babylon Bee Interview Show, John Branyan tells Ethan and Dan how he attempted to get on the Letterman show by annoying producers with an excessive amount of postcards.

See the full show here: https://youtu.be/WqxlRr67l0c

Hit the bell to get your daily dose of fake news that you can trust.

## “Political Correctness is Deadly”: The Zuby Interview
 - [https://www.youtube.com/watch?v=TdTHkUmDpno](https://www.youtube.com/watch?v=TdTHkUmDpno)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-27 00:00:00+00:00

On The Babylon Bee Interview Show, Kyle and Ethan talk to rapper, podcast host, author, Zuby. They talk about going viral, disgusting English food, and political correctness. Zuby first gained fame for a video of him beating the women's deadlift record. Since going viral, Zuby has gained over 700,000 followers online and sold 25,000 albums independently. His most recent album, Word of Zuby, just became the most funded hip-hop project on Kickstarter in the U.K. You can pre-order his album and find his book on getting swol by going to Zuby’s website here: https://www.zubymusic.com/

Start of Interview 00:02:45
Bad English food 00:13:24
Being a rapper that is Christian 00:18:51
BLM viral tweet 00:28:52
Speaking out 00:38:22
Biggest factor in Covid deaths 00:47:22

Subscribe on iTunes: https://podcasts.apple.com/us/podcast...​

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans​​

The Official The Babylon Bee Store: https://shop.babylonbee.com​​

Follow The Babylon Bee:
Website: https://babylonbee.com​​
Twitter: http://twitter.com/thebabylonbee​​
Facebook: http://facebook.com/thebabylonbee​​
Instagram: http://instagram.com/thebabylonbee​

