# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## MURDERBOT TV SHOW!🤖 Captain America 4🛡️ Mother Of Madness🤪 -Fantasy News
 - [https://www.youtube.com/watch?v=ps5I6fgZOaI](https://www.youtube.com/watch?v=ps5I6fgZOaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-04-27 00:00:00+00:00

From Emelia Clarke to Murderbot, we have some exciting fantasy news!!! 
Check out my baby daddy Campfire here today: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20 

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 

00:00 Murderbot Show: https://www.ocregister.com/2021/04/25/how-murderbot-diaries-author-martha-wells-overcame-a-career-in-crisis-to-create-the-killer-series/ 

01:48 The Fall Of Babel: https://thefantasyinn.com/2021/04/22/the-fall-of-babel-by-josiah-bancroft-cover-launch/ 

02:24 Into The Dying Light: https://twitter.com/orbitbooks/status/1385541761574055936/photo/1 

02:40 The Darkest Dusk: https://twitter.com/binding_broken/status/1385641034936377344?s=19 

03:56 Mother Of Madness: https://ew.com/books/emilia-clarke-comic-book-mom-mother-of-madness-preview/ 

04:56 Neil Gaiman Tweet: https://twitter.com/neilhimself/status/1385027362773901317 

05:33 Fairly Odd Parents Live Action: https://discussingfilm.net/2021/04/20/live-action-fairly-oddparents-reboot-to-begin-filming-in-june-exclusive/ 

06:25 Captain America 4: https://www.hollywoodreporter.com/heat-vision/captain-america-4-in-the-works-with-falcon-and-the-winter-soldier-showrunner-malcolm-spellman-exclusive?utm_medium=social&utm_source=twitter 

08:06 Self Pub of May: https://www.robjhayes.co.uk/self-published-fantasy-releases-may-2021/ 

08:16 Russell Crowe To Play Zeus: https://ew.com/movies/russell-crowe-zeus-thor-love-and-thunder/

