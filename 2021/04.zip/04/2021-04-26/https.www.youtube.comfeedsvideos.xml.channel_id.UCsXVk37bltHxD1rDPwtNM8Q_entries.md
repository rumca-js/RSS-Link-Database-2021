# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## What If You Fall into a Black Hole?
 - [https://www.youtube.com/watch?v=QqsLTNkzvaY](https://www.youtube.com/watch?v=QqsLTNkzvaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2021-04-27 00:00:00+00:00

If you want to continue thinking about black holes a tad more, you can do so by getting one of the many black hole related things the Kurzgesagt team made with love: 
https://kgs.link/shop-141

Sources & further reading:
https://sites.google.com/view/sources-black-holes/

Our Video on Neutronstars: https://youtu.be/udFxKZRyQt4
Our Video on the Information Paradox: https://youtu.be/yWO-cvGETRQ

Black holes are the most powerful and extreme things in the universe and they are wildly weird and complicated. What would happen if you fell inside one and what are they really?

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ https://kgs.link/shop-141  
Join the Patreon Bird Army 🐧  https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          http://kgs.link/music-youtube2021
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:

Soundcloud:   https://bit.ly/3tTZztY
Bandcamp:     https://bit.ly/32O2iJn


🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons who support us every month and made this video possible:
Harshul Banthia, Priyadarshi Siddharth, Ethan, Chad, Mason Lagos, Zinovia, BigOlive, Edgar Galan, Lance Liu, Super Luigi Bros Animations, Nicolas Eckert, Drashya Goel, Francois, Seanskios, Alessandro Ticozzi, Cameron McPhail, Ace Sparrow, Russell Stockhammer, o+o, Alec Hogben, Mikolaj Pawlikowski, Alexandra Cheung, SubSonixx, Guillaume VIDAL, Andy Highland, Arina Maria Neculai, Jeremy Engelberg, Josh Lavine, Azreal, Jeremy Clark, Jordi Malaret, Daniel Lo, Kenna Miller, Motin, rayV, Maximo Brito, bque23, Evhen Samchuk, Riyo, Giakeimas, Sunny Bär, Alexander Utz, Gaspard Medina-Creimer, James McClelland, David Nejedlý, George-Cristian Bîrzan, James Ilesley, JP, Ariel Tubbs, Anon, Felicity, Prashanth Samuel, Doop a Derp, Brettyoke49, Oksana Sivchenko, Rene Duedam, Kacey Armbruster, Yu Shing Cheng, osama bin laden's cousin's white best friend, Miko Boulerice, Skyler Martin, Matt Harlow, Arash Amini, Christopher Thomas, João Pinheiro, Raj Patel, Maurizio, panic, Raghav Mahajan, Mate Serdult, Ethan (cathethanoob), Warren Price, Laiton, Drew Johnson, Cole Reid, Daniel Mayor, Vincent Strüh, Gamerbot43, Jonathan Elbaz, matt yang, Nikita Ivanov, Lindsay, David, IsThisRealLife, Sam Wallick, alxpck, Aina Piera Tur, Darius Soo Lum, Happy 1 Year Will Smith

