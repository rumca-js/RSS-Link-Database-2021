# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How the CCP Controls American Businesses in China
 - [https://www.youtube.com/watch?v=rLiTjbPnVLo](https://www.youtube.com/watch?v=rLiTjbPnVLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-27 00:00:00+00:00

Taken from JRE #1640 w/Josh Rogin:
https://open.spotify.com/episode/3PW4bCu6zKsG02r6VcfAMP?si=NSVZKGIxTZSfRGP33vhcmw

## Josh Rogin on Anthony Fauci's Influence
 - [https://www.youtube.com/watch?v=IqhKlkkc2Eo](https://www.youtube.com/watch?v=IqhKlkkc2Eo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-27 00:00:00+00:00

Taken from JRE #1640 w/Josh Rogin:
https://open.spotify.com/episode/3PW4bCu6zKsG02r6VcfAMP?si=NSVZKGIxTZSfRGP33vhcmw

