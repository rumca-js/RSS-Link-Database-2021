## Bill Gates under fire for saying vaccine formulas shouldn’t be shared with developing world
 - [https://news.yahoo.com/bill-gates-under-fire-saying-200557167.html](https://news.yahoo.com/bill-gates-under-fire-saying-200557167.html)
 - RSS feed: https://news.yahoo.com
 - date published: 2021-04-26 20:30:20+00:00

Bill Gates under fire for saying vaccine formulas shouldn’t be shared with developing world

