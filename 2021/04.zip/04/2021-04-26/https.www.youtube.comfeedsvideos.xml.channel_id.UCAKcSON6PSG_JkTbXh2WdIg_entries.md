# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Kara Laudon - two songs at The Current (2019)
 - [https://www.youtube.com/watch?v=9dm7ElYjHBw](https://www.youtube.com/watch?v=9dm7ElYjHBw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-27 00:00:00+00:00

For Minnesota Music Month, we're spotlighting Minnesota musicians, and today, we're featuring this two-song set from Kara Laudon, recorded in The Current studio in 2019.

Twin Cities-based singer-songwriter Kara Laudon released the album "Old Lives" on September 27, 2019; it was produced by John Mark Nelson. Shortly after its release, Laudon visited The Current to talk with Andrea Swensson and to play these songs from the album.

SONGS PERFORMED
0:00 "Leave You Alone" 
3:40 "All My Life"

PERSONNEL
Kara Laudon – vocals, keys
Ian Allison – bass
Steve Bosmans – guitar
Reese Kling – drums

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Jesse Wiza

FIND MORE:
2019 studio session: https://www.thecurrent.org/feature/2019/10/14/kara-laudon-performs-songs-from-old-lives-on-the-local-show
2020 virtual session for Sound Like Home: https://www.thecurrent.org/feature/2020/05/20/live-virtual-session-kara-laudon

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#karalaudon #karalaudonmusic

