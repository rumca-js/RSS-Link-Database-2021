# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Oscars Ratings Disaster - An Open Letter To Hollywood
 - [https://www.youtube.com/watch?v=9aRGYPxoZQY](https://www.youtube.com/watch?v=9aRGYPxoZQY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-04-27 00:00:00+00:00

The 2021 Academy Awards weren't exactly a big hit with audiences. In fact, they recorded their lowest ratings in the show's history. This is my response to Hollywood. 


Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

