# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## This won't end well for Nokia
 - [https://www.youtube.com/watch?v=Y7Ra343hvig](https://www.youtube.com/watch?v=Y7Ra343hvig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-04-09 00:00:00+00:00

Get the Crrowd app (Android only for now) and see our Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd  Note: you'll need an invite code. Learn more: https://www.crrowd.com/invite

This week Nokia launched 6 confusing new devices, the "Find My" wars have begun and LG Mobile is officially out.

The Friday Checkout - Episode 42

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► From this video ◄◄◄

This video on Nebula: https://watchnebula.com/videos/the-friday-checkout-this-aint-it-nokia

Quiz: https://link.crrowd.com/quiz (opens in the app or on the web automatically)

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:56 Release Highlights
1:48 Nokia's new strategy
4:12 Find My Junk
7:01 Bye, LG

