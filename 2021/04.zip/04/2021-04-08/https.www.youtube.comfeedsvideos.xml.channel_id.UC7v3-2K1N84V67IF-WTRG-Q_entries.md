# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Falcon and The Winter Soldier - Episode 4 (My Thoughts)
 - [https://www.youtube.com/watch?v=NAyFONTENHY](https://www.youtube.com/watch?v=NAyFONTENHY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-04-09 00:00:00+00:00

Star Wars: Republic Commando is available now - Relive the legendary campaign on Nintendo Switch and PlayStation: https://bit.ly/3fFQSPt
Thanks Aspyr Media for sponsoring!

The Falcon and The Winter Soldier continues with episode 4....and the ending was something else!

