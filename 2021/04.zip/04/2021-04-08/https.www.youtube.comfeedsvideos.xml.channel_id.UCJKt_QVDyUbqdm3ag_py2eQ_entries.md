# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Jogeir Liljedahl - Bugs Tribute (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=dy6T2_LMPow](https://www.youtube.com/watch?v=dy6T2_LMPow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-04-09 00:00:00+00:00

"Bugs Tribute" (2021) by Jogeir Liljedahl. Art "Mermaid" by Lycan, 7th at Revision Online 2021 oldskool gfx compo.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## Amiga music: Mygg & Bonefish - Brofists (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=r6sP_cAzZLo](https://www.youtube.com/watch?v=r6sP_cAzZLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-04-09 00:00:00+00:00

"Brofists" by Mygg (Jonas Sarvik) & Bonefish, 1st at Revision Online 2021 tracked music compo. Art "Teddies Invasion" by thUg/Desire, 6th at Revision Online 2021 oldskool gfx compo.

You should also watch this:
https://www.youtube.com/watch?v=knG9tfmkxgQ

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

