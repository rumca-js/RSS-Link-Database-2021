# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## REPLACING CENTOS - Everything you wanted to know about ALMA LINUX - Interview with Jack Aboutboul
 - [https://www.youtube.com/watch?v=sYPOol4Fpz0](https://www.youtube.com/watch?v=sYPOol4Fpz0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2021-04-08 00:00:00+00:00

Try KernelCare+ for free for 30 days by signing up here: https://lp.kernelcare.com/kernelcare-plus-experiment

Alma Linux has been released a week ago, and has already been quite well received, as a full on replacement for CentOS. I had the opportunity to talk to Jack Aboutboul, the community manager for that distribution, and ask him a bunch of questions.

Alma Linux Website: https://almalinux.org/
Alma Linux Reddit: https://www.reddit.com/r/AlmaLinux/

Contact the team: hello@almalinux.org

Become a channel member to get access to a weekly patroncast and vote on the next topics I'll cover:
https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Support the channel on Patreon: 
https://www.patreon.com/thelinuxexperiment

Follow me on Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

Follow me on ODYSEE: https://odysee.com/@TheLinuxExperiment:e
Or join ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

The Linux Experiment merch: get your goodies there! https://teespring.com/en-GB/stores/the-linux-experiment

00:00 Intro
02:02 Presentation of Jack Aboutboul
02:50 What is Alma Linux?
04:03 Is Cent OS Stream unsuitable for servers?
05:36 How is Alma Linux different from CloudLinux OS?
07:14 How is Alma Linux different from other similar projects?
09:13 Will Alma Linux stick to a stable release model?
11:51 What is the migration path from CentOS to Alma Linux?
12:38 Is Alma Linux a 1:1 fork of RHEL?
13:36 Are people from CentOS involved?
15:44 How will the community be involved in the decision making process?
18:09 What is CloudLinux's goal with Alma Linux?
19:41 Do you have any numbers to share?

