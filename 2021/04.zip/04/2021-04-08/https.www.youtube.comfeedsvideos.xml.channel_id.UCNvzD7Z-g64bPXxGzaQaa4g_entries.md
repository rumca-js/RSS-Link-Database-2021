# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## UNTIL DAWN 2? E3 2021 LINEUP REVEALED, & MORE
 - [https://www.youtube.com/watch?v=0f3Yq_6bVLc](https://www.youtube.com/watch?v=0f3Yq_6bVLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-09 00:00:00+00:00

Brought to you by Raycon. Go to  http://buyraycon.com/gameranx for 15% off your order!

A crazy Xbox Kojima rumor, new horror games, and more delays in a week chock full of gaming news.


Subscribe for more: https://www.youtube.com/gameranxTV?su...​...

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​​​​



 ~~~~STORIES~~~~
0:00 Until Dawn developer’s next game
1:31 Abandoned
4:00 Deathloop delayed
5:55 MGS3 fan remake scene
7:05 Diablo 2 Alpha 
8:04 Trailers
9:39 E3 2021 LINEUP 



0:15 Until Dawn developer’s next game

https://www.gamesradar.com/until-dawn-developer-supermassive-games-are-hiring-for-a-secret-unannounced-project/

1:31 Abandoned

https://blog.playstation.com/2021/04/07/abandoned-a-cinematic-survival-sim-hits-ps5-later-this-year/
Trailer: https://youtu.be/qL9pGRdCjNc

4:00 Deathloop delayed

https://www.theverge.com/2021/4/8/22373588/bethesda-deathloop-ps5-delayed-date


5:55 MGS3 fan remake scene

https://youtu.be/Ye_KMq_8RFw
https://twitter.com/erasmus_brosdau/status/1378773207453405189



7:05 Diablo 2 Alpha 

https://diablo2.blizzard.com/en-us/


8:04 Trailers

Oddworld: Soulstorm
https://www.youtube.com/watch?v=1lLDHWlnDiM

Republic Commando 
https://youtu.be/95LE-ZMxLh8

Pac-Man 99
https://youtu.be/DQ2c-6CJ-tM


9:39 E3 2021 LINEUP 

https://www.gamesindustry.biz/articles/2021-04-06-nintendo-xbox-and-ubisoft-back-digital-only-e3-2021

Jake’s It Takes Two video
https://youtu.be/8dC9yOMg83I

## 10 Video Game Stories That SUDDENLY CHANGED
 - [https://www.youtube.com/watch?v=dyy38FOPutA](https://www.youtube.com/watch?v=dyy38FOPutA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-08 00:00:00+00:00

Some video game stories change over time. Whether it's a mistake, a retcon, or something else, here are some of the biggest examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Assassin's Creed source: https://youtu.be/TW0epSDp3Sw

## How A Free Open World Game Made $1 Billion Dollars In RECORD Time
 - [https://www.youtube.com/watch?v=01lxCsqwqcE](https://www.youtube.com/watch?v=01lxCsqwqcE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-08 00:00:00+00:00

Genshin Impact has seen record downloads and massive revenue. Why is it so big? Let's take a look.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

**Sources and references: 
https://gamedaily.biz/article/1895/genshin-impact-downloaded-more-than-23-million-times-in-its-first-week-on-mobile-platforms

https://www.blog.udonis.co/mobile-marketing/mobile-games/mobile-games-whales

https://www.blog.udonis.co/mobile-marketing/mobile-games/genshin-impact-monetization

https://www.gamesindustry.biz/articles/2020-10-01-genshin-impact-becomes-biggest-international-launch-for-a-chinese-game

https://www.gamesindustry.biz/articles/2021-02-26-mihoyo-revenue-reportedly-close-to-usd800m-in-2020

https://www.washingtonpost.com/video-games/2020/10/06/genshin-impact-gambling/

