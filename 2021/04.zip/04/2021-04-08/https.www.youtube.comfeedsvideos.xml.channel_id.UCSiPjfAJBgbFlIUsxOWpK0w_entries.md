# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## 80's Mashup // POMPLAMOOSE (Whitney Houston + Cyndi Lauper)
 - [https://www.youtube.com/watch?v=efhoa0CDyXY](https://www.youtube.com/watch?v=efhoa0CDyXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-04-08 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Yet another 80's mashup that was MEANT. TO. BE. Whitney Houston's "I Wanna Dance with Somebody" meets Cyndi Lauper's "Girls Just Want to Have Fun"! 

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar, Synths, Extra Percussion: Brian Green
Bass: Nick Campbell
Drums: Ben Rose
Background Vocals: Erin Bentlage

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Branko Presley
Mixing/Mastering: Joey Genetti
Producer: Brian Green
Additional Production: Joey Genetti
Mashup Arrangement: Brian Green & Erin Bentlage

VIDEO CREDITS
DP: Ricky Chavez
Camera Operators: Merlin Showalter, Sammy Rothman, George Sloan
Video Editor: Dominic Mercurio
Colorist: Charlene Gibbs

Recorded at The Village in Los Angeles.

#Pomplamoose #Mashup #GirlsJustWantToHaveFun #IWannaDanceWithSomebody #CyndiLauper #WhitneyHouston

LYRICS
Yeah, I wanna dance with somebody
With Somebody who loves me

I come home in the morning light
My mother says, "When you gonna live your life right?"
Oh mother dear we're not the fortunate ones
And girls, they wanna have fun
Oh girls just want to have fun

I've done alright up til now
It's the light of day that shows me how
And when the night falls, loneliness calls

Oh, I wanna dance with somebody
(girls, they wanna)
I wanna feel the heat with somebody
(wanna have fun)
Yeah, I wanna dance with somebody
(girls, they wanna have fun)
With somebody who loves me
(With somebody who loves me)

I've been in love and lost my senses
Spinning through the town
Sooner or later, the fever ends
And I wind up feeling down
I need a man who'll take a chance
On a love that burns hot enough to last
So when the night falls
My lonely heart calls

(girls, they wanna)
Oh, I wanna dance with somebody
(wanna have fun)
I wanna feel the heat with somebody 
(girls, wanna have fun)
Yeah, I wanna dance with somebody
(they wanna, wanna have fun)
With somebody who loves me

That's all they really want
Some fun
When the working day is done
Oh girls, they wanna have fun
Oh girls just want

(Somebody who, somebody who)
Somebody who loves me
(Somebody who, somebody who)
To hold me in his arms

‘Cause I want to be the one to walk in the sun
And girls, they wanna have fun
Oh girls just wanna have fun

(girls, they wanna)
Oh, I wanna dance with somebody
(wanna have fun)
I wanna feel the heat with somebody 
(girls, they wanna have fun)
Yeah, I wanna dance with somebody
(wanna have fun)
With somebody who loves me

That's all they really want
Some fun
When the working day is done
Oh girls, they wanna have fun
Oh girls just wanna have fun

They just wanna
They just wanna
(Girls, girls just wanna have fun)
They just wanna
They just wanna
Oh, girls, girls just wanna have fun
(Just wanna, they just wanna)
Oh, girls just wanna have fun

