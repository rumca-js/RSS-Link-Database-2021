# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Redmi Note 10 Pro, POCO F3 i Samsung A52 5G - wcale nie takie średnie
 - [https://www.youtube.com/watch?v=oL2noK9PZqA](https://www.youtube.com/watch?v=oL2noK9PZqA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-04-08 00:00:00+00:00

Dziś w odcinku trzy średniaki, które potrafią zaskoczyć
Samsung na Allegro: https://bit.ly/39T0tyQ
Dwa pozostałe dostałem do testów z goboo (dystrybucja globalna):
Redmi Note 10 Pro: https://bit.ly/39RXc2T
POCO F3: https://bit.ly/39SWNgl

