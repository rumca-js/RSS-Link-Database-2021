# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Ultimate Gaming Phone!
 - [https://www.youtube.com/watch?v=cW1KJf7JKgI](https://www.youtube.com/watch?v=cW1KJf7JKgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-04-08 00:00:00+00:00

Plug it in TWICE. The Legion Duel 2 is unapologetically gamer.

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds​
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Lenovo for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

