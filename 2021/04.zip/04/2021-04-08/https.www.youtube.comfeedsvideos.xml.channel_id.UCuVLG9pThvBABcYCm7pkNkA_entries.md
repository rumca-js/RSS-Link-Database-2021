# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## How The Auto Industry Carjacked The American Dream | Climate Town
 - [https://www.youtube.com/watch?v=oOttvpjJvAo](https://www.youtube.com/watch?v=oOttvpjJvAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2021-04-08 17:09:33+00:00

Where we're going, we don't need roads.
sUbScRiBe FoR mOrE ViDes: https://www.youtube.com/c/climatetown?sub_confirmation=1
PATREON PAGE: https://www.patreon.com/ClimateTown

Shot and co-directed by Benjamin Boult: http://benjaminboult.com/
Ben is unbelievably talented, check out the rest of his work on the website above and hire him for your projects.

Based on an article by Spencer R. Scott P.h.D.: https://blog.usejournal.com/a-grand-theft-auto-industry-stole-our-streets-and-our-future-a2145d6e10e2

Supporting sources, documents, interviews, and articles in this doc: https://docs.google.com/document/d/1-SjpFrBjiEK2gHXzXv_6Ibof6rMwRzRzLuxfPY9OAm8

How GM beefed the electric car: https://www.youtube.com/watch?v=RNvvvVt_628
Read more about the streetcar conspiracy: 
Car free street resources: https://nyc.streetsblog.org/category/issues-campaigns/car-free-streets/
https://www1.nyc.gov/html/dot/html/pedestrians/openstreets.shtml
https://www.bloomberg.com/news/articles/2019-10-17/san-francisco-s-market-street-car-ban-is-overdue

 

THREE ORGANIZATIONS YOU SHOULD JOIN RIGHT NOW:
Sunrise Movement: https://www.sunrisemovement.org/volunteer/
Extinction Rebellion: https://extinctionrebellion.us/get-involved
Climate Action Network: http://www.climatenetwork.org/

Follow Climate Town on Instagram: https://www.instagram.com/climatetown 
if you wanna see ... I dunno, mostly memes and some lukewarm takes about climate change I guess?
Also, subscribe to @Climemechange on Instagram: https://www.instagram.com/climemechange
They're the best in the game.

Some reading to do:

The Merchants of Doubt: https://www.merchantsofdoubt.org/
All We Can Save: https://www.allwecansave.earth/
The Uninhabitable Earth: https://www.penguinrandomhouse.com/books/586541/the-uninhabitable-earth-by-david-wallace-wells/
This Changes Everything: Capitalism vs. The Climate: https://thischangeseverything.org/book/

