# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 500 million LinkedIn users' data is for sale on a hacker site
 - [https://www.cnn.com/2021/04/08/tech/linkedin-data-scraped-hacker-site/index.html](https://www.cnn.com/2021/04/08/tech/linkedin-data-scraped-hacker-site/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 23:58:44+00:00

Information scraped from around 500 million LinkedIn user profiles is part of a database posted for sale on a website popular with hackers, the company confirmed Thursday.

## Fleetwood hits memorable hole-in-one at Masters
 - [https://www.cnn.com/2021/04/08/golf/tommy-fleetwood-hole-in-one-masters-spt-intl/index.html](https://www.cnn.com/2021/04/08/golf/tommy-fleetwood-hole-in-one-masters-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 23:24:39+00:00

He was having a poor opening round of the Masters, but in one fell swoop, that all changed for Tommy Fleetwood.

## Biden calls US gun violence 'international embarrassment'
 - [https://www.cnn.com/2021/04/08/politics/gun-actions-joe-biden/index.html](https://www.cnn.com/2021/04/08/politics/gun-actions-joe-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 23:20:07+00:00

• Analysis: Manchin crushes liberals' dream for Biden's first term

## Friend of Matt Gaetz likely to strike deal to cooperate with government
 - [https://www.cnn.com/2021/04/08/politics/greenberg-gaetz/index.html](https://www.cnn.com/2021/04/08/politics/greenberg-gaetz/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 23:04:38+00:00

Joel Greenberg, a key figure in the ongoing investigation into Florida Republican Rep. Matt Gaetz, is likely to strike a plea deal with federal prosecutors, his attorney and prosecutors said in court Thursday.

## Trump's fingerprints are all over the 2022 Senate fight
 - [https://www.cnn.com/2021/04/08/politics/2022-senate-donald-trump-endorsements/index.html](https://www.cnn.com/2021/04/08/politics/2022-senate-donald-trump-endorsements/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 22:34:11+00:00

How's former President Donald Trump filling his days now that he's gone from the White House? Judging from his public statements, he's watching the battle for the Senate majority in 2022 closely -- and trying to handpick GOP candidates in several key races.

## Pulmonologist describes in disturbing detail how George Floyd fought to breathe
 - [https://www.cnn.com/2021/04/08/us/derek-chauvin-trial-george-floyd-day-9/index.html](https://www.cnn.com/2021/04/08/us/derek-chauvin-trial-george-floyd-day-9/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 22:18:30+00:00

A renowned pulmonary critical care doctor testified Thursday morning that George Floyd died from a "low level of oxygen" as former police officer Derek Chauvin pinned him to the street and restricted his ability to breathe.

## Rory McIlroy hits father with ball in sloppy first round of Masters
 - [https://www.cnn.com/2021/04/08/golf/rory-mcilroy-gerry-dad-hit-masters-spt-intl/index.html](https://www.cnn.com/2021/04/08/golf/rory-mcilroy-gerry-dad-hit-masters-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 21:51:06+00:00

Parents' attendance at sporting events is normally for supportive measures.

## Bus torched in more Northern Ireland violence as British and Irish leaders call for calm
 - [https://www.cnn.com/2021/04/07/europe/northern-ireland-belfast-riots-intl-hnk/index.html](https://www.cnn.com/2021/04/07/europe/northern-ireland-belfast-riots-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 21:08:52+00:00

Parts of Northern Ireland saw their sixth consecutive night of violence Wednesday as unionists and nationalists clashed with police and each other.

## How common are blood clots with AstraZeneca's vaccine?
 - [https://www.cnn.com/2021/04/08/health/astrazeneca-covid-vaccine-blood-clots-explainer-cmd-gbr-intl/index.html](https://www.cnn.com/2021/04/08/health/astrazeneca-covid-vaccine-blood-clots-explainer-cmd-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 21:07:44+00:00

• LIVE: Belgian health chief backs 'good' AstraZenca vaccine
• Fauci says new Covid-19 cases are at a disturbing level

## Russian 'Lord of the Rings' adaptation is barely recognizable
 - [https://www.cnn.com/videos/world/2021/04/08/russian-lord-of-the-rings-movie-mh-orig.cnn](https://www.cnn.com/videos/world/2021/04/08/russian-lord-of-the-rings-movie-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 21:07:42+00:00

Russia's Channel Five digitized and posted a 1991 adaptation of "The Fellowship of the Ring" that already has over 1.5 million views on YouTube.

## Myanmar military denies responsibility for child deaths and says elections could be pushed back
 - [https://www.cnn.com/2021/04/08/asia/myanmar-zaw-min-tun-interview-intl-hnk/index.html](https://www.cnn.com/2021/04/08/asia/myanmar-zaw-min-tun-interview-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 20:49:14+00:00



## This is what Disney Parks of the future will look like
 - [https://www.cnn.com/2021/04/08/media/disney-parks-future-interview/index.html](https://www.cnn.com/2021/04/08/media/disney-parks-future-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 20:30:41+00:00

Walt Disney World is celebrating its 50th anniversary this year, and Disneyland plans to reopen later this month. But Disney Parks Chairman Josh D'Amaro is thinking about the next 50 years.

## US considering sending warships to Black Sea amid Russia-Ukraine tensions
 - [https://www.cnn.com/2021/04/08/politics/ukraine-us-black-sea/index.html](https://www.cnn.com/2021/04/08/politics/ukraine-us-black-sea/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 20:23:46+00:00

The United States is considering sending warships into the Black Sea in the next few weeks in a show of support for Ukraine amid Russia's increased military presence on Ukraine's eastern border, a US defense official told CNN Thursday.

## Khloe Kardashian's leaked bikini photo has revealed an ugly truth
 - [https://www.cnn.com/style/article/khloe-kardashian-unedited-bikini-photo/index.html](https://www.cnn.com/style/article/khloe-kardashian-unedited-bikini-photo/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 20:17:37+00:00

Earlier this week, a candid photo of Khloe Kardashian in a leopard print bikini was mistakenly shared on social media. Her team fruitlessly tried to scrub all traces of the image after it was reportedly posted by one of her assistants.

## Covid-19 long hauler describes relief after getting vaccine
 - [https://www.cnn.com/videos/health/2021/04/08/covid-long-haulers-vaccine-cohen-dnt-vpx.cnn](https://www.cnn.com/videos/health/2021/04/08/covid-long-haulers-vaccine-cohen-dnt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 19:59:48+00:00

Jessamyn Smyth, a Covid-19 long hauler, hopes that two Pfizer vaccine doses may be what finally delivers her from the lasting effects of a virus that wreaked chaos in her life. CNN's Elizabeth Cohen has more

## Watch former 'Mrs. Sri Lanka' snatch winner's crown
 - [https://www.cnn.com/videos/style/2021/04/08/mrs-sri-lanka-crown-taken-lon-orig.cnn](https://www.cnn.com/videos/style/2021/04/08/mrs-sri-lanka-crown-taken-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 19:30:27+00:00

A former Mrs. Sri Lanka forcefully removed the crown from the newly appointed beauty pageant queen after falsely claiming she was ineligible to take part.

## The guy who started the GameStop mania will soon be chairman of the board
 - [https://www.cnn.com/2021/04/08/investing/gamestop-ryan-cohen-chairman/index.html](https://www.cnn.com/2021/04/08/investing/gamestop-ryan-cohen-chairman/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 18:44:12+00:00

George Sherman may still be the CEO of meme stock poster child GameStop. But it looks like Chewy co-founder Ryan Cohen is really running the show.

## Watch model train play classical music medley with glasses
 - [https://www.cnn.com/videos/travel/2021/04/08/longest-melody-played-by-model-train-na-lon-orig.cnn](https://www.cnn.com/videos/travel/2021/04/08/longest-melody-played-by-model-train-na-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 17:50:56+00:00

Germany's Miniatur Wunderland set a new world record for the longest melody played by a model train.

## Unseen footage of Queen Elizabeth revealed
 - [https://www.cnn.com/style/article/unseen-queen-footage-scli-intl-gbr/index.html](https://www.cnn.com/style/article/unseen-queen-footage-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 17:44:22+00:00

New and previously unseen footage of Queen Elizabeth II, including home movies and recently digitized "lost" material from her tours around the world, will be shown Thursday in the UK for the first time.

## How common are blood clots with AstraZeneca's vaccine, and should you be worried?
 - [https://www.cnn.com/collections/covid-intl-040821/](https://www.cnn.com/collections/covid-intl-040821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 17:30:26+00:00



## Almost like a surgeon had removed the lungs: Pulmonologist on Floyd's position
 - [https://www.cnn.com/videos/us/2021/04/08/derek-chauvin-trial-pulmonologist-george-floyd-vpx.cnn](https://www.cnn.com/videos/us/2021/04/08/derek-chauvin-trial-pulmonologist-george-floyd-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 17:14:25+00:00

Dr. Martin Tobin, a physician in pulmonary and critical care medicine, said George Floyd died from a low level of oxygen and that there was no way that Floyd's chest could expand properly to breathe.

## Ancient cave artists starved themselves of oxygen while painting
 - [https://www.cnn.com/style/article/cave-art-study-scli-intl-scn/index.html](https://www.cnn.com/style/article/cave-art-study-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 16:46:00+00:00

Ancient cave decorations can be breathtaking to behold, but new research claims the artists may have been starved of oxygen when they were painting.

## Stunning footage shows restoration work on Notre Dame
 - [https://www.cnn.com/videos/style/2021/04/08/paris-inside-notre-dame-restoration-bell-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/style/2021/04/08/paris-inside-notre-dame-restoration-bell-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 16:42:19+00:00

Two years after a fire devastated the iconic Notre Dame Cathedral in Paris, CNN's Melissa Bell goes inside the cathedral to uncover the hard restoration work going on behind the scenes.

## Rat poison found in over 80% of bald eagles in a US study
 - [https://www.cnn.com/2021/04/08/us/bald-eagle-rat-poison-study-scn/index.html](https://www.cnn.com/2021/04/08/us/bald-eagle-rat-poison-study-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 16:21:29+00:00

The majority of American eagles likely have rat poison in their systems, a new study reported Wednesday.

## Giant monitor lizard freaks out shoppers at a 7-Eleven
 - [https://www.cnn.com/videos/world/2021/04/08/monitor-lizard-7-11-thailand-orig-jk.cnn](https://www.cnn.com/videos/world/2021/04/08/monitor-lizard-7-11-thailand-orig-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 16:18:43+00:00

A huge Asian water monitor lizard visited a 7-11 in Thailand. A bystander caught shoppers' nervous laughs and screams as the lizard climbed a shelf.

## Biden calls gun violence in US an 'international embarrassment' and takes first steps on gun control
 - [https://www.cnn.com/collections/us-pols-intl-040821/](https://www.cnn.com/collections/us-pols-intl-040821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 16:16:33+00:00



## America is facing a ketchup packet shortage
 - [https://www.cnn.com/2021/04/08/business/ketchup-shortage-heinz/index.html](https://www.cnn.com/2021/04/08/business/ketchup-shortage-heinz/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 16:11:34+00:00

When the doors open at the Blake Street Tavern every day, owner Chris Fuselier is looking for customers and looking for ketchup. "Absolutely," the Denver restaurateur says. "In hindsight, if you'd have asked me eighteen months ago would I have concerns about ketchup shortages, I would have said 'Are you crazy?'"

## Hungary vs. EU: Sacking of soccer coach over homophobic and xenophobic comments escalates into diplomatic spat
 - [https://www.cnn.com/2021/04/08/football/hungary-zsolt-petry-homophobia-xenophobia-spt-intl/index.html](https://www.cnn.com/2021/04/08/football/hungary-zsolt-petry-homophobia-xenophobia-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 15:44:08+00:00

Hungary's Minister of Foreign Affairs has questioned the European Union's "freedom of expression" after a Hungarian goalkeeping coach was sacked by his German club over homophobic and xenophobic comments.

## UK desperately needs a coherent China strategy
 - [https://www.cnn.com/collections/uk-china-intl/](https://www.cnn.com/collections/uk-china-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 15:40:50+00:00



## 'The fraud is this farce': Cuomo calls out Fox News host
 - [https://www.cnn.com/videos/media/2021/04/08/chris-cuomo-fox-news-tucker-carlson-rewrite-capitol-riot-history-sot-cpt-vpx.cnn](https://www.cnn.com/videos/media/2021/04/08/chris-cuomo-fox-news-tucker-carlson-rewrite-capitol-riot-history-sot-cpt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 14:30:58+00:00

CNN's Chris Cuomo says Fox News host Tucker Carlson is contributing to the division in the country by trying to rewrite the history of the January 6 insurrection at the US Capitol.

## You're vaccinated now, so can you go to a restaurant? What you should know
 - [https://www.cnn.com/travel/article/restaurants-safety-pandemic-wellness/index.html](https://www.cnn.com/travel/article/restaurants-safety-pandemic-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 14:24:39+00:00

As the vaccinated percentage of the population increases, you may be wondering whether now is finally the time to enjoy a meal that isn't homemade or takeout.

## What it takes to protect the world's most endangered zebra
 - [https://www.cnn.com/2021/04/08/africa/kenya-endangered-grevys-zebra-africa-spc-intl/index.html](https://www.cnn.com/2021/04/08/africa/kenya-endangered-grevys-zebra-africa-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 13:34:25+00:00

The Grevy's zebra, covered in white and black stripes, may not look dissimilar to the common zebra. But there are clear differences -- especially to someone like Sheila Funnell, who has dedicated her life's work to its protection.

## The man recreating airplane meals to get through lockdown
 - [https://www.cnn.com/travel/article/airplane-food-lockdown/index.html](https://www.cnn.com/travel/article/airplane-food-lockdown/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 12:38:49+00:00

Some of Nik Sennhauser's earliest memories are of long-haul flights -- and of eating on a plane.

## Forget SUVs. These auto makers think tiny electric cars are the next big thing
 - [https://www.cnn.com/2021/04/08/success/small-electric-cars/index.html](https://www.cnn.com/2021/04/08/success/small-electric-cars/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 12:35:31+00:00

Americans have long had a love affair with big SUVs that can carry more people and stuff than they usually need to transport and go much further than most of us drive in a day. But now there's a number of start ups that are betting they can sell car shoppers on vehicles that offer the exact opposite.

## You can have a summer picnic in the Queen's Buckingham Palace gardens
 - [https://www.cnn.com/travel/article/buckingham-palace-gardens-scli-intl-gbr/index.html](https://www.cnn.com/travel/article/buckingham-palace-gardens-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 12:35:02+00:00

Green fingered enthusiasts will be able to freely roam the gardens of London's historic Buckingham Palace this summer, as Queen Elizabeth II allows self-guided tours of the grounds for the first time in the palace's history.

## Beloved animal expert has dementia
 - [https://www.cnn.com/videos/us/2021/04/07/jack-hanna-dementia-orig-jm.cnn](https://www.cnn.com/videos/us/2021/04/07/jack-hanna-dementia-orig-jm.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 11:45:04+00:00

Jack Hanna, an animal and wildlife expert who became famous after his many TV appearances, is retiring from public life due to dementia, his family announced Wednesday.

## The 'Tiger Slam': 20 years on from when Tiger Woods won it all
 - [https://www.cnn.com/2021/04/08/golf/tiger-slam-woods-20-year-anniversary-masters-cmd-spc-spt-intl/index.html](https://www.cnn.com/2021/04/08/golf/tiger-slam-woods-20-year-anniversary-masters-cmd-spc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 11:41:18+00:00

As Tiger Woods walked onto the 18th green at the 2001 Masters, throngs of fans were in hot pursuit to catch a glimpse of the golfer and all cameras were pointed at the then 25-year-old, who was on the precipice of etching his name into golf history.

## Can anything derail the 'Goldilocks' economy?
 - [https://www.cnn.com/2021/04/08/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/04/08/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 11:28:20+00:00

America's economy could be heading for a golden era of growth. But higher prices and the coronavirus pandemic still present risks.

## The women explorers who changed the travel world
 - [https://www.cnn.com/travel/article/women-explorers-breaking-barriers/index.html](https://www.cnn.com/travel/article/women-explorers-breaking-barriers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 11:24:19+00:00

They'd traveled hundreds and thousands of miles between them, but explorer Blair Niles and one-time spy Marguerite Harrison were disappointed to learn that they were deemed unsuitable to join the Explorers Club.

## Karate, Wonton, Chow Fun: The end of 'chop suey' fonts
 - [https://www.cnn.com/style/article/chop-suey-fonts-hyphenated/index.html](https://www.cnn.com/style/article/chop-suey-fonts-hyphenated/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 08:46:16+00:00

Here's a thought experiment: Close your eyes and imagine the font you'd use to depict the word "Chinese."

## Paris not Tokyo could be last Olympics, hints Simone Biles
 - [https://www.cnn.com/2021/04/08/sport/simone-biles-olympics-paris-tokyo-spt-intl/index.html](https://www.cnn.com/2021/04/08/sport/simone-biles-olympics-paris-tokyo-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 08:44:30+00:00

After thinking hard about hanging on another year to compete at the Covid-19 delayed Tokyo Olympics, four-time gold medalist gymnast Simone Biles said on Wednesday she just might stick around for another three years for the 2024 Paris Summer Games.

## Filipino dies after being forced to do 300 squats for breaking Covid-19 curfew
 - [https://www.cnn.com/2021/04/07/asia/philippines-police-crackdown-intl-hnk/index.html](https://www.cnn.com/2021/04/07/asia/philippines-police-crackdown-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 03:49:24+00:00

A man in the Philippines has died after being forced to do 300 squats for breaching Covid curfews, making him the latest victim of the country's often brutal approach to enforcing restrictions.

## This airplane-shaped bag is selling for more than some actual planes
 - [https://www.cnn.com/videos/business/2021/04/08/jeanne-moos-airplane-bag-vpx.cnn](https://www.cnn.com/videos/business/2021/04/08/jeanne-moos-airplane-bag-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-08 00:25:28+00:00

Louis Vuitton sells $39,000 bag shaped like an airplane. Jeanne Moos wonders if it will take off.

