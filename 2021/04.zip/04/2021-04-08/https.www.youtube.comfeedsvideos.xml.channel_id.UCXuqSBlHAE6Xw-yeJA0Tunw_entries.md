# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I turned my Diamond Play Button into a Gaming PC
 - [https://www.youtube.com/watch?v=qflqUpxTZP4](https://www.youtube.com/watch?v=qflqUpxTZP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-04-09 00:00:00+00:00

Check out the DROP ENTR Mechanical Keyboard at https://dro.ps/ltt-entr-april21

Get up to 30% off your order and free shipping at: http://vincerocollective.com/techsale

We put a PC into our Diamond Play Button - and it's sooooo sick... and of course also a bit janky.

Even more machining footage! https://youtu.be/rYdJ7w6QZug 
Check out SS CADCAM: https://www.instagram.com/sscadcam/?hl=en

Check out SimplyNUC: https://simplynuc.com/

Buy Intel NUC Kit - i7-10710U (PAID LINK): https://geni.us/bRu3a3

Buy ASRock DESKMINI (PAID LINK): https://geni.us/F5CI2v

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1324047-i-turned-my-diamond-play-button-into-a-gaming-pc/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## My Phone Number Leaked. Thanks Facebook. - WAN Show April 9, 2021
 - [https://www.youtube.com/watch?v=-qj6hkLkdYg](https://www.youtube.com/watch?v=-qj6hkLkdYg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-04-09 00:00:00+00:00

Take control of your end-of-life upgrade strategy with Extended Lifecycle Support services from CloudLinux at https://hubs.ly/H0JpBnj0

Check out Seasonic's PRIME 850 W Titanium on Amazon at https://lmg.gg/seasonicprime

Get Private Internet Access VPN at https://lmg.gg/piawan

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/My-Phone-Number-Leaked--Thanks-Facebook----WAN-Show-April-9--2021-euoo3v

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Noah Love)
2:24 intro
2:41 Sponsors 
3:00 Facebook Leak
12:40 Intel drops prices on new gen
16:20 Direct storage and "future proofing"
19:45 Intel Xeon Ice Lake still loses to AMD 
26:15 LTT "copies" Austin Evans
29:30 LTT "copies" Jayz2cents on "Ghetto Neworking
32:30 Nerd Sports and Hockey Memories
35:40 LTT's not so legal beginnings
36:50 Sponsors! Linux Cloud, Seasonic and PIA
40:30 "The Thing!" Verified actual gamer program details (game against Linus)
43:55 LTTstore update 
43:35 Google Pixel Watch renders "leaked"
47:10 Stadia and using different cloud services and gpu pricing
52:35 The watch is cancelled? Maybe?
52:55 LG is out of the phone business
58:55 Twitch monitors streamers off platform
1:08:50 Shoutout to floatplane
1:12:00 Shift in media reporting on streaming vs celebs
1:15:25 Superchats!
1:16:20 Right to repair with Louis Rossman! 
1:17:00 Sorry New Zealand
1:17:35 "Luke is the best" 
1:17:40 Linus's motorcycle
1:20:15 Linus making motorcycle noises
1:25:05 Nathan spends $20 to send "Steve"
1:26:45 Outro

