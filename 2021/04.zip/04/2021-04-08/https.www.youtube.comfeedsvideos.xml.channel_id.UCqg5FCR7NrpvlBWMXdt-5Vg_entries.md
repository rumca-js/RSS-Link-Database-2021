# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Remembering Dead Space with Former Visceral Games Devs | Gameumentary
 - [https://www.youtube.com/watch?v=ucG9_UA_p3U](https://www.youtube.com/watch?v=ucG9_UA_p3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-04-09 00:00:00+00:00

**ORIGINALLY RELEASED ON GAMEUMENTARY** This mini-documentary was shot during our documentary shoot at Outpost Games, where we spoke with a number of Visceral Games developers not long after the closure of their studio to discuss their favorite memories working on the Dead Space franchise.

Want to support more content like this on The Escapist? Join our YouTube Membership program at $2 / early access tier!

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

