# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Physicist Brian Greene Explains Black Holes
 - [https://www.youtube.com/watch?v=MYimxshUK1c](https://www.youtube.com/watch?v=MYimxshUK1c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-08 00:00:00+00:00

Taken from JRE #1631 w/Brian Greene:
https://open.spotify.com/episode/3Atye1uCqaW2Ver3d16wJO?si=c8b47b3c643e4f8a

