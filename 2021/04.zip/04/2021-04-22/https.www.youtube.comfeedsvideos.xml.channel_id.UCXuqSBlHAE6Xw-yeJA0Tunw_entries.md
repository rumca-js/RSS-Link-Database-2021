# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Apple HULK SMASHES the Competition - WAN Show April 23, 2021
 - [https://www.youtube.com/watch?v=K2u4-w5Ioco](https://www.youtube.com/watch?v=K2u4-w5Ioco)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-04-23 00:00:00+00:00

Save 10% at Ridge Wallet with offer code WAN at https://www.ridge.com/WAN

Check out Seasonic's PRIME 850 W Titanium on Amazon at https://lmg.gg/seasonicprime

Get Private Internet Access VPN at https://lmg.gg/piawan

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Apple-HULK-SMASHES-the-Competition---WAN-Show-April-23--2021-evn0qr

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Dylan Richards)
[OVERVIEW]
00:00:16 | Topic #1: Apple 4/20 Event [00:02:08]
--:--:-- | Topic #2: Tile Seeks to Reinforce Ongoing Antitrust Charges against Apple over AirTags [00:35:50]
00:01:12 | Non-News Topic #1: Linus Brings Go-Karts Home for His Kids [00:48:21]
00:01:24 | Non-News Topic #2: Linus May Be Building a PC with an NBA Star [00:54:39]
--:--:-- | Topic #3: Canada Computers Employee Says Company Is Refusing to Sell Its "Substantial Stock" of GeForce RTX 30 Series GPUs, Despite Backorders [01:00:59]
00:00:55 | Topic #4: Microsoft Project xCloud Beta for iOS and PC [01:08:39]
--------
00:01:38 | [INTRO]
--------
[TOPIC #1]
00:02:08 | Topic #1: Apple 4/20 Event
00:02:47 | 12.9" Apple iPad Pro (5th Gen) with M1 SoC
00:05:40 | Linus and Luke Try to Identify the Use Cases for Tablets
00:07:42 | Linus Tries to Compel Luke to Use an iPad Pro
00:08:02 | Linus Tries to Compel Luke to Buy an iPad Pro
00:16:31 | 23.5" Apple iMac (Mid 2021) with M1 SoC
00:27:22 | Linus Discusses the Lack of Upgradability with M1 Silicon Products
--------
[INTERMISSION]
00:31:04 | Linus Has a Big Surprise for Live WAN Show Viewers
00:31:10 | Luke Gets a Call
00:31:34 | Linus Is Given the All-Clear
00:31:43 | Verified Actual Gamers Live WAN Show Drop
--------
[TOPIC #1 CONTINUED]
00:34:42 | Apple TV 4K (6th Gen) with A12 Bionic
00:35:47 | Apple iPhone 12 and 12 Mini Now Available in Purple
--------
[TOPIC #2]
00:35:50 | Topic #2: Tile Seeks to Reinforce Ongoing Antitrust Charges against Apple over AirTags
--------
[SPONSORS]
00:45:45 | Private Internet Access VPN (Try Risk-Free: https://lmg.gg/piawan )
00:46:34 | Ridge Wallet (Save 10% with Offer Code "WAN": https://ridge.com/wan )
00:47:11 | Seasonic Power Supplies ( https://seasonic.com/ )
--------
[NON-NEWS TOPIC #1]
00:48:21 | Non-News Topic #1: Linus Brings Go-Karts Home for His Kids
00:48:36 | Ninebot Gokart PRO
00:49:55 | Linus Shares a Video from His Phone ft. His Daughter
00:51:59 | Linus Asks the Community for Ideas on Content with the Gokart PRO
00:53:01 | YouTube Viewers Suggest a Review Akin to a Car Review
--------
[NON-NEWS TOPIC #2]
00:54:39 | Non-News Topic #2: Linus May Be Building a PC with an NBA Star
--------
[INTERMISSION]
00:58:57 | A Note to Linus from Luke to Buy Titanfall 2 on Steam ($10 EA Sale)
--------
[TOPIC #3]
01:00:59 | Topic #3: Canada Computers Employee Says Company Is Refusing to Sell Its "Substantial Stock" of GeForce RTX 30 Series GPUs, Despite Backorders
01:03:37 | Linus's Hot Take
01:04:08 | Luke Nails It
01:04:24 | NCIX Did a Lot of Things Wrong, but It Honored FIFO
01:05:26 | Canada Computers Won't Fulfill Backorders because It Wants People to Buy Entire Systems Instead
01:06:14 | Anthony's Hot Take
01:06:30 | NVIDIA's Terrible RTX 3060 Launch Is a Major Reason Why We Have the Verified Actual Gamers Program
01:07:22 | Linus Invited NVIDIA to Join the Verified Actual Gamers Program, but They Declined
01:07:36 | Upcoming Verified Actual Gamers Drop ft. 270 Radeon RX 6800 XT GPUs
--------
[TOPIC #4]
01:08:39 | Topic #4: Microsoft Project xCloud Beta for iOS and PC
01:09:06 | Xbox Series S|X Are Getting AMD FidelityFX
01:09:18 | Microsoft Has Removed Xbox LIVE Gold Subscription Requirement for Multi-Player in Free-to-Play Games
--------
01:09:54 | [SUPER CHATS]
01:10:27 | Luke's "Mooostache"
01:12:48 | Angry Mom Sells "RTX 2060" on Craigslist for MSRP; Turns Out It's an RTX 3060
--------
01:16:34 | [OUTRO]

## You Can ACTUALLY Buy This PC!
 - [https://www.youtube.com/watch?v=go6kUc8y7J8](https://www.youtube.com/watch?v=go6kUc8y7J8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-04-22 00:00:00+00:00

Thanks to MSI for sponsoring this video! 
Buy MSI MPG Z590 Tomahawk WiFi (PAID LINK): https://geni.us/gpAiy
Buy MSI MPG CORELIQUID K360 AIO CPU Cooler (PAID LINK): https://geni.us/ZD5lP
Buy MSI MPG A650GF PSU (PAID LINK): https://geni.us/7Lga
Buy Intel Core i7-11700K CPU (PAID LINK): https://geni.us/kBVb
Buy Phanteks P500A Case (PAID LINK): https://geni.us/cIPp
Buy Crucial P5 2TB NVMe SSD (PAID LINK): https://geni.us/bqMpfQ
Buy Crucial Ballistix RGB 16GB Kit (2 x 8GB) (PAID LINK): https://geni.us/e9yTKjB

Here's a build that you can actually go out and buy despite the recent hardware shortages, but there's a twist...

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1330138-you-can-actually-buy-this-pc/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

