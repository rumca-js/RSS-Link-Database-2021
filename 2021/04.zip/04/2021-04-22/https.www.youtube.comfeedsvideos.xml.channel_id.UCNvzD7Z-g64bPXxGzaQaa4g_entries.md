# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## XBOX SERIES X GRAPHICS UPGRADE UNLOCKED, SONY ADDING NEW STUFF TO PS PLUS, & MORE
 - [https://www.youtube.com/watch?v=mpw8h-j08m0](https://www.youtube.com/watch?v=mpw8h-j08m0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-23 00:00:00+00:00

Thanks to Vessi for sponsoring our video. To experience the world’s first 100% waterproof knit shoe, visit https://vessi.com/gameranx and use code GAMERANX for $25 off

Exciting new things coming for PS5 and Xbox Series X owners, Battlefield 6 is on the horizon, KOTOR remake rumors resurface, and more in a week FULL of gaming news.
Subscribe for more: https://www.youtube.com/gameranxTV?su...​...


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​

*How a 'Before You Buy' video is made:
https://youtu.be/GhhfmGjxi8U

 ~~~~STORIES~~~~

Xbox graphics update:
https://youtu.be/RTtVC-Zk5yI
https://videocardz.com/newz/amd-enables-fidelityfx-technologies-for-xbox-series-xs-consoles
(Also Cloud beta for Windows and iOS)
https://kotaku.com/xbox-cloud-gaming-for-windows-10-and-ios-launches-limit-1846712281


Sony’s PS Plus video: 
https://in.ign.com/news/157780/sony-accidentally-teases-playstation-plus-video-pass
PS3 and Vita lives
https://www.theverge.com/2021/4/19/22392126/sony-ps3-ps-vita-stores-open-backtrack-psp-july-2nd-mistake

Jeff Kaplan leaves Blizzard
https://www.polygon.com/22394111/overwatch-jeff-kaplan-quits-blizzard-aaron-keller

Play Tomb Raider in a browser
http://xproger.info/projects/OpenLara/

Test Drive Solar Crown
https://www.youtube.com/watch?v=ae-7FJiM7SM

Portal Reloaded: https://youtu.be/xbdTO5xqCJA

New Warzone map: https://youtu.be/s2JTy3Y3DV0

BF 6 coming soon
https://www.polygon.com/22396791/battlefield-6-2021-dice-reveal-soon


KOTOR rumors again: 
https://youtu.be/l1KNluEDsOE
https://www.ign.com/articles/star-wars-knights-of-the-old-republic-remake-reportedly-coming-from-port-studio-aspyr

## 10 Bosses That Looked HARD But Ended Up As Pushovers
 - [https://www.youtube.com/watch?v=k-ywYcv0wPk](https://www.youtube.com/watch?v=k-ywYcv0wPk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-22 00:00:00+00:00

Some video game bosses look menacing and challenge but end up being totally easy to beat. Here are some of our favorite silly examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#7 Borderlands clip via: https://youtu.be/xFEjt10sg3I

## Portal Reloaded - Before You Buy
 - [https://www.youtube.com/watch?v=3LGFzEWwgyE](https://www.youtube.com/watch?v=3LGFzEWwgyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-22 00:00:00+00:00

Portal Reloaded (yes, it's free) is available on Steam and feels almost like an official sequel. What is it exactly? Let's dive in.

Check out the game here: https://store.steampowered.com/app/1255980/Portal_Reloaded/

