# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Mortal Kombat (2021) - Movie Review
 - [https://www.youtube.com/watch?v=GGtTL9-yks0](https://www.youtube.com/watch?v=GGtTL9-yks0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-04-22 00:00:00+00:00

As the Mortal Kombat tournament comes around once a generation, so too does a big screen Mortal Kombat movie. Here are my thoughts on the 2021 MORTAL KOMBAT movie!

#MortalKombat

