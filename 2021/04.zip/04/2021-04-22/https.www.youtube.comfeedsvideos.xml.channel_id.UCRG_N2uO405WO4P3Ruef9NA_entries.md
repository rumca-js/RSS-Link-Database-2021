# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Hey Siri, what's a computer?
 - [https://www.youtube.com/watch?v=awRFd5kmETk](https://www.youtube.com/watch?v=awRFd5kmETk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-04-23 00:00:00+00:00

This week Apple questioned what a computer is, Microsoft questioned what an app store is and, Motorola switched strategies.

The Friday Checkout - Episode 44

-

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   
Quiz: https://link.crrowd.com/quiz   
This video on Nebula: https://watchnebula.com/videos/the-friday-checkout-what-is-a-computer

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:34 Release Highlights
1:02 The new Moto
2:39 iPad: What's a computer?
5:14 New Microsoft Store

