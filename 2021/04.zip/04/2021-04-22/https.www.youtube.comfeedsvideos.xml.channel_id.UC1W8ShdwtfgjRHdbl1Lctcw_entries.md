# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## A Day in Los Angeles 1950's in color [60fps, Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=IXPYQU78sIc](https://www.youtube.com/watch?v=IXPYQU78sIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2021-04-23 00:00:00+00:00

I colorized, restored and created a sound design for this video of California, a time travel in  Los Angeles, Santa Monica, San Fernando Valley, we can clearly see what is happening in broad daylight,

05:10 - 08:01 San Fernando Valley ca. late 1940s

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

Thanks to Jeff Kaplan for share the amazing B&W Video Source

B&W Video Source from:  Jeff Kaplan on archive.org
B&W Video Source: https://archive.org/details/LAprocessplatesandcoronation
B&W Video Source:https://archive.org/details/SP-23A_C_LA
Music RADIO background source: Philco Radio Time, January 29, 1947
Music RADIO background source: https://archive.org/details/Philco_Radio_Time_January_29_1947

Rights to the black and white 35mm Video Source are held by Internet Archive. under the Creative Commons Attribution License
Rights to Music RADIO background: Public Domain
- - - - - - - - - - - - - - - - - - - -
📨 Contact me at :nassthegoodman@gmail.com
- - - - - - - - - - - - - - - - - - - -
For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page! Please consider "fair use" before filing a claim. Thank You!

