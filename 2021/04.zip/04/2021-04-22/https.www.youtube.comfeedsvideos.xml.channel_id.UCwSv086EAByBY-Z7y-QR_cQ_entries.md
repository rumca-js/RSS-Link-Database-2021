# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Media społecznościowe to pomysł DARPA. Powiązania Zuckerberg'a ze służbami
 - [https://www.youtube.com/watch?v=XjHSLWgRGNY](https://www.youtube.com/watch?v=XjHSLWgRGNY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-04-23 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/3gxV1p4
2. https://bit.ly/3azzt7W
3. https://bit.ly/3xjmMI3
4. https://bit.ly/3ndNJIB
5. https://bit.ly/3dKFqkf
6. https://bit.ly/2Pmxnks
7. https://bit.ly/3ayupkf
8. https://bit.ly/3xdNbHj
9. https://bit.ly/2QqpcnD
10. https://nym.ag/3nfqYUt
11. https://bit.ly/3gy2BQE
---------------------------------------------------------------
🖼Grafika - źródło: 
wikipedia.org / Anthony Quintano - https://bit.ly/3tMwOiM
---------------------------------------------------------------
💡 Tagi: #facebook #MediaSpołecznościowe #Zuckerberg
--------------------------------------------------------------

## Co się dzieje? Masowa wycinka lasów na niespotykaną skalę!
 - [https://www.youtube.com/watch?v=EhUorE7S1Ho](https://www.youtube.com/watch?v=EhUorE7S1Ho)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-04-22 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅źródła:
1. https://bit.ly/32BDYdS
2. https://bit.ly/3v704B2
3. https://bit.ly/3tEtcPS
4. https://bit.ly/3dEVZOI
5. https://bit.ly/3gHeG6n
6. https://bit.ly/3sFu2dF
7. https://bit.ly/3tHuRE7
---------------------------------------------------------------
🖼Grafika - źródło: 
lasyiobywatele.pl - https://bit.ly/32BDYdS
---------------------------------------------------------------
💡 Tagi: #lasy #klimat #ekologia
--------------------------------------------------------------

