# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Read Me // POMPLAMOOSE Original
 - [https://www.youtube.com/watch?v=febnsUYUBYY](https://www.youtube.com/watch?v=febnsUYUBYY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-04-22 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 One of the BEAUTIFUL things that came out of being stuck at home was getting to work with Ben Rose on original music. Not only did he produce this Pomplamoose song, we also WROTE the whole thing together. So *technically* this should be called "Read Me" Ben Rose ft. Pomplamoose. I'm also open to changing the bandname to PomplaRose. 

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

An original song by Pomplamoose.

CREDITS
Vocals: Nataly Dawn
Keys, Mandola, Acoustic Guitar, Percussion: Jack Conte
Drums, Keys, Electric Guitar, Percussion: Ben Rose
Mixing/Mastering: Yianni AP
Producer: Ben Rose
Camera Operator: Nataly Dawn
Assistant to the Regional Camera Operator: Ben Rose
Video Editor: Athena Wheaton
Colorist: Charlene Gibbs
Wardrobe: Elle Olsen

Recorded at our home studio in San Francisco.

#Pomplamoose #IndieRock #ReadMe

LYRICS

I would like to know you
Would that be alright
Take you out for soda
On a summer night
I’m an open book
Won’t you take the time
Cause I’m a little old-fashioned
Can I hold your hand
Tell me your favorite song
We can play it on my walkman
Cause I’m an open book
So won’t you take the time
To read me

Tell me how it’s been
Tell me how it’s gonna be
Come on take a chance
Honey don’t you want to read me?

So you were born in Ohio
But then you moved out West
And you bite your nails I know
And then keep them in your pockets
Are you an open book
Or just an easy rhyme
Too easy

I used to watch a lot
Of Dawson’s Creek
Wasn’t allowed
But I would sneak upstairs
On weekends
Turn the volume down low
And hope no one
Was listening
Are you listening
Do you ever dream of summer camp
Slow dance, sweaty hands
First kiss, what did I miss
What did I miss
Are you listening
Cause I miss everything

And if you were a novel
I would check you out
K that’s a really bad line
But that’s what I’m all about
Oh Thank gosh you’re laughing
You might have figured how
To read me

