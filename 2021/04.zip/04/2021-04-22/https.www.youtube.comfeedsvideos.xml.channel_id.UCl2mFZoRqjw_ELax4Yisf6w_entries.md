# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## NYC business owner fined 25k; fights city and WINS!
 - [https://www.youtube.com/watch?v=JjjMM47nhqE](https://www.youtube.com/watch?v=JjjMM47nhqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-23 00:00:00+00:00

https://tinyurl.com/rossmatrix
Tell propel we say hi & wish them luck with their business: https://www.youtube.com/watch?v=dYkHmV7C2lY

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Remember, COVID is still here; ALWAYS WEAR A MASK!
 - [https://www.youtube.com/watch?v=lh2j8x86jts](https://www.youtube.com/watch?v=lh2j8x86jts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-23 00:00:00+00:00

https://tinyurl.com/rossmatrix
I will be able to tell from the upvote/downvote ratio & comments how many people raged at the title without watching the video. :) 


To be clear, I am not anti mask, as I explained here a year ago.  https://youtu.be/3PGwnm_pNnM Just having some fun. 


SOURCE CLIP: https://youtu.be/aZJ__QWHg2g

## John Deere security flaw exposed address of every customer & more!
 - [https://www.youtube.com/watch?v=hqablgjQ02g](https://www.youtube.com/watch?v=hqablgjQ02g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.gofundme.com/f/lets-get-right-to-repair-passed
👉 https://www.youtube.com/watch?v=QSt6dgRvFig
👉 https://www.vice.com/en/article/4avy8j/bugs-allowed-hackers-to-dox-all-john-deere-owners
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## THANK YOU LINUS!
 - [https://www.youtube.com/watch?v=-F-Wxj-v9-g](https://www.youtube.com/watch?v=-F-Wxj-v9-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.gofundme.com/f/lets-get-right-to-repair-passed
https://www.youtube.com/watch?v=nvVafMi0l68

