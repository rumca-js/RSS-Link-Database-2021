# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## China's Big "F U" to Crypto
 - [https://www.youtube.com/watch?v=9duWGp9guCk](https://www.youtube.com/watch?v=9duWGp9guCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-04-22 00:00:00+00:00

Discover where your data is and take it back at https://bit.ly/3ggrHn7

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🖥️ Website platform I use: https://jake.yt/kd
📈 Get up to $250 in free Bitcoin at http://blockfi.com/jake 
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use: https://jake.yt/benchd 
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3guPvnb

-----------------------
Money - we spend our existence chasing it in the modern world. Yet hardly any of us knows how it works, how the idea of money has changed over time and how we’re on the precipice of the next evolution of money. An evolution that’s either going to be really dystopian, or one that might set us free. And the main player fighting for a more dystopian financial future? China.

During the Tang Dynasty, China invented the next evolution of money. Traders started leaving those strings of coins behind to a trustworthy agent. That trustworthy agent would then record how much money the trader deposited on a piece of paper, the trader would hang on to that piece of paper, to use in place of physical coins. That piece of paper would be known as receipt money. And today, that trustworthy agent can be not-so-trustworthy - and goes by the name of a banker.

Today - it’s also China who’s pushing for the next evolution of money.

Alibaba and Jack Ma launch Alipay, a mobile wallet app that lets users pay for almost anything with a QR code on their phone. Bitcoin is invented. China paid attention. WeChat, China’s messaging app that is used for almost everything, launched its own mobile wallet, WeChat Pay

Facebook announces that it’s going to launch its own cryptocurrency, Libra, that it’s 2 billion users at the time could use to transact on the platform. While the US focused their efforts on stopping Facebook’s power grab - China accelerated their’s.

Although the Chinese government does have ultimate control over these tech giants and they have to send their data to the gov, it’s still a black box, the data is still delayed, the data is still in the hands of powerful people that the gov might not be able to trust, and these tech giants were starting to take over many functions of the traditional banking system and even the gov.

Since the start of the initial Digital Yuan trials, more than 100,000 people have downloaded the government’s mobile app. Basically, China took all the good stuff about cryptocurrencies. 

-----------------------

No Spirit - Slightly Improvised https://chll.to/6347930b 

Thanks to Mine for sponsoring the video. 

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

