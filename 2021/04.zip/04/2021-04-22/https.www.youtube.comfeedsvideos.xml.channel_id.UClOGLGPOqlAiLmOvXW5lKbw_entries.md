# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Advent Rising Review
 - [https://www.youtube.com/watch?v=fUk3_3eBD_M](https://www.youtube.com/watch?v=fUk3_3eBD_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2021-04-23 00:00:00+00:00

The Advent Rising review covers another Halo Killer™ that was hugely marketed with theatrical trailers, comic books, and a million dollar contest. Let's see how that went.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/mandaloregaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
01:23 - Issues & Fixes
01:47 - Game Premise
03:55 - Visuals
06:22 - Music & Sound Design
10:53 - The Advent Rising Experience
17:28 - Story
23:00 - Conclusions
23:53 - Credits
24:59 - It Never Ends
#AdventRising #AdventRisingGame #AdventRisingReview #AdventRisingPC

