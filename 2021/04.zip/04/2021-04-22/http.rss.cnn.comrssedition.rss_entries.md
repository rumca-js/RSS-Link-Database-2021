# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Acid attack victim speaks after horrifying incident
 - [https://www.cnn.com/videos/us/2021/04/22/acid-attack-victim-nafiah-ikram-new-york-speaks-out-vpx.wcbs](https://www.cnn.com/videos/us/2021/04/22/acid-attack-victim-nafiah-ikram-new-york-speaks-out-vpx.wcbs)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 22:51:25+00:00

A New York woman, who was attacked in her driveway, is hoping for answers, as police are searching for the man who threw a cup of acid in her face.

## Chauvin juror speaks out
 - [https://www.cnn.com/videos/us/2021/04/22/chauvin-juror-interview-vpx.cnn](https://www.cnn.com/videos/us/2021/04/22/chauvin-juror-interview-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 21:14:45+00:00

An alternate juror from the Derek Chauvin trial speaks to CNN about the experience.

## SE Cupp: The Rock, Matthew McConaughey and Caitlin Jenner walk into a bar
 - [https://www.cnn.com/videos/opinions/2021/04/22/se-cupp-unfiltered-celebrities-run-for-office-trump-vpx.cnn](https://www.cnn.com/videos/opinions/2021/04/22/se-cupp-unfiltered-celebrities-run-for-office-trump-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 18:58:01+00:00

CNN's SE Cupp discusses why it wasn't the fact that former President Trump was a celebrity that made him a bad leader and that other celebrities have the right to run for office.

## See superyacht squeeze through narrow canals
 - [https://www.cnn.com/videos/travel/2021/04/21/superyacht-feadship-holland-lon-orig-tp.cnn](https://www.cnn.com/videos/travel/2021/04/21/superyacht-feadship-holland-lon-orig-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 10:22:19+00:00

Photographer Tom van Oossanen captured footage of a massive yacht being transported through tiny canals in Holland. The ship was built by a Dutch company at their shipyard in Kaag and it's on its way to Amsterdam where it will undergo sea trials.

## How the European Super League united football against the game's wealthy owners
 - [https://www.cnn.com/2021/04/22/football/european-super-league-football-ownership-cmd-spt-intl/index.html](https://www.cnn.com/2021/04/22/football/european-super-league-football-ownership-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 08:05:50+00:00

As crowds gathered outside Chelsea's Stamford Bridge stadium, there was a moment -- almost like the flick of a switch -- when angry jeers turned to whooping cheers.

## Indonesian Navy searches for missing submarine with 53 people on board
 - [https://www.cnn.com/2021/04/21/asia/indonesia-missing-submarine-intl/index.html](https://www.cnn.com/2021/04/21/asia/indonesia-missing-submarine-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 08:01:14+00:00

Indonesia's Navy is searching for a missing submarine with 53 people on board that went missing during a military exercise on Wednesday and is seeking help from neighboring Australia and Singapore in the hunt, Indonesian authorities say.

## How the European Super League united football against the game's wealthy owners
 - [https://www.cnn.com/collections/intl-european-super-league-0421/](https://www.cnn.com/collections/intl-european-super-league-0421/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 07:51:37+00:00



## Companies are crucial to solving the climate crisis. 75% are falling short
 - [https://www.cnn.com/collections/intl-earth-day-0422/](https://www.cnn.com/collections/intl-earth-day-0422/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 07:46:07+00:00



## Virginia police officer fired after reports of donation to Kyle Rittenhouse
 - [https://www.cnn.com/2021/04/22/us/virginia-officer-fired-donations-kyle-rittenhouse/index.html](https://www.cnn.com/2021/04/22/us/virginia-officer-fired-donations-kyle-rittenhouse/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 07:20:37+00:00

A Norfolk police officer has been relieved of his duty after an internal investigation into reports that he donated and expressed support for the actions of Kyle Rittenhouse, who is facing two felony charges of homicide in the deaths of two men and a felony attempted homicide charge in the wounding of another man during street protests in August.

## Derek Chauvin verdict may rock the US Senate
 - [https://www.cnn.com/2021/04/22/politics/police-reform-compromise-political-hurdles/index.html](https://www.cnn.com/2021/04/22/politics/police-reform-compromise-political-hurdles/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 07:10:38+00:00

Real hope for police reform -- even in the rancorously divided US Senate -- shows the seismic impact of the guilty verdict in the trial for George Floyd's murder.

## US has the opportunity to overcome the pandemic but a major challenge lies ahead, expert says
 - [https://www.cnn.com/collections/covid-intl-041921/](https://www.cnn.com/collections/covid-intl-041921/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 06:51:10+00:00



## After more than two decades, there's a new world's busiest airport
 - [https://www.cnn.com/travel/article/worlds-busiest-airports-2020-coronavirus-pandemic/index.html](https://www.cnn.com/travel/article/worlds-busiest-airports-2020-coronavirus-pandemic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 06:13:25+00:00

Seven of the world's top 10 busiest airports in 2020 were in China while the former world's busiest airport -- Hartsfield-Jackson Atlanta International Airport in the United States -- fell to No. 2 in the rankings after 22 consecutive years in the top spot.

## Pro-Navalny protesters defy ban as Putin warns world against crossing Russia's 'red lines'
 - [https://www.cnn.com/2021/04/21/europe/russia-putin-address-navalny-protests-intl/index.html](https://www.cnn.com/2021/04/21/europe/russia-putin-address-navalny-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 05:32:27+00:00

Russia's President Vladimir Putin called for all citizens to get vaccinated against Covid-19 as he gave his annual address to the nation on Wednesday, delivered as rallies began in support of opposition leader Alexey Navalny.

## Lemon: Fox News host had a meltdown over Chauvin verdict
 - [https://www.cnn.com/videos/media/2021/04/22/brian-stelter-tucker-carlson-derek-chauvin-verdict-ctn-vpx.cnn](https://www.cnn.com/videos/media/2021/04/22/brian-stelter-tucker-carlson-derek-chauvin-verdict-ctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 05:28:15+00:00

CNN's Brian Stelter and Don Lemon discuss Fox News host Tucker Carlson's coverage of the Derek Chauvin verdict.

## Images by one of history's earliest photographers fetch almost $2M
 - [https://www.cnn.com/style/article/talbot-photography-sale-sothebys/index.html](https://www.cnn.com/style/article/talbot-photography-sale-sothebys/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 05:26:11+00:00

A collection of around 200 images by one of history's first photographers, William Henry Fox Talbot, has smashed auction estimates to sell for over $1.95 million.

## Australian government tears up Victoria's Belt and Road agreement with China, angering Beijing
 - [https://www.cnn.com/2021/04/22/business/australia-china-belt-and-road-initiative-intl-hnk/index.html](https://www.cnn.com/2021/04/22/business/australia-china-belt-and-road-initiative-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 05:17:36+00:00

The Australian government has canceled a Belt and Road agreement signed by China and the state government of Victoria, escalating trade and diplomatic tensions between Beijing and Canberra.

## Four killed in car bombing outside Pakistan hotel where Chinese ambassador was reportedly staying
 - [https://www.cnn.com/2021/04/21/asia/pakistan-bomb-blast-chinese-ambassador-intl-hnk/index.html](https://www.cnn.com/2021/04/21/asia/pakistan-bomb-blast-chinese-ambassador-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 04:29:21+00:00

A car bomb blast outside a luxury hotel where the Chinese ambassador was staying in the southwestern Pakistani city of Quetta killed four people and injured 12, the city's deputy commissioner of police said.

## US Capitol Police officer allegedly told units to only monitor for 'anti-Trump' protesters on January 6
 - [https://www.cnn.com/2021/04/21/politics/us-capitol-police-officer-investigation-radio-broadcast-lofgren/index.html](https://www.cnn.com/2021/04/21/politics/us-capitol-police-officer-investigation-radio-broadcast-lofgren/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 03:14:31+00:00

A US Capitol Police officer directed "all outside units" on the morning of January 6 to only monitor for anti-Trump agitators "who want to start a fight," not any "pro-Trump in the crowd," according to the findings of a newly revealed internal investigation.

## Only 2 'breakthrough' infections among hundreds of fully vaccinated people, new study finds
 - [https://www.cnn.com/2021/04/21/health/two-breakthrough-infections-covid-19/index.html](https://www.cnn.com/2021/04/21/health/two-breakthrough-infections-covid-19/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 03:11:28+00:00

For fully vaccinated people, the risk of still getting Covid-19 -- described as "breakthrough infections" -- remains extremely low, a new study out of New York suggests.

## Biden preparing to declare massacre of Armenians a 'genocide,' risking break with Turkey
 - [https://www.cnn.com/2021/04/21/politics/biden-armenia-genocide-turkey/index.html](https://www.cnn.com/2021/04/21/politics/biden-armenia-genocide-turkey/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 03:03:02+00:00

President Joe Biden is preparing to declare the massacre of an estimated million or more Armenians under the Ottoman Empire a "genocide" this week, risking a potential fracture with Turkey but fulfilling a campaign pledge to finally use the word as President to describe the mass killings after a series of his predecessors stopped short.

## Ohio officials release more body cam video of fatal police shooting of Black teen
 - [https://www.cnn.com/2021/04/21/us/ohio-columbus-police-shooting-15-year-old/index.html](https://www.cnn.com/2021/04/21/us/ohio-columbus-police-shooting-15-year-old/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 01:41:02+00:00

Columbus, Ohio, officials released additional body camera video on Wednesday of a police officer fatally shooting a Black teen who charged two females with a knife.

## Pfizer and Moderna Covid-19 vaccines do not appear to pose serious risk during pregnancy, research shows
 - [https://www.cnn.com/2021/04/21/health/pregnancy-mrna-vaccines-safe-effective/index.html](https://www.cnn.com/2021/04/21/health/pregnancy-mrna-vaccines-safe-effective/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 01:36:10+00:00

The mRNA Covid-19 vaccines made by Pfizer/BioNTech and Moderna do not appear to pose any serious risk during pregnancy, according to new data published Wednesday in the New England Journal of Medicine.

## 'Beginner's Guide to America' and 5 other works that illuminate the US immigrant experience
 - [https://www.cnn.com/style/article/beginners-guide-america-roya-hakakian-immigration-culture-queue/index.html](https://www.cnn.com/style/article/beginners-guide-america-roya-hakakian-immigration-culture-queue/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 00:34:03+00:00

Imagine searching for "traces of Americanness" as an immigrant first arriving in the US, and four name tags seen in the airport stop you in your tracks.

## Was justice served in the Derek Chauvin trial? Here's what our readers told us
 - [https://www.cnn.com/2021/04/21/us/chauvin-trial-verdict-reader-reactions-trnd/index.html](https://www.cnn.com/2021/04/21/us/chauvin-trial-verdict-reader-reactions-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-22 00:21:11+00:00

Photos: Verdict reactions | Timeline: Floyd's death

