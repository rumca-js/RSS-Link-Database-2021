# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Dave Smith Passionately Opposes Vaccine Passports
 - [https://www.youtube.com/watch?v=x9c3w_QFfbE](https://www.youtube.com/watch?v=x9c3w_QFfbE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-23 00:00:00+00:00

Taken from JRE #1639 w/Dave Smith:
https://open.spotify.com/episode/7taqki4fGUkcXESbaUzjgh?si=a13f5806749c45aa

## The Military Industrial Complex and CNN Being Exposed
 - [https://www.youtube.com/watch?v=hlzJXCMzjR0](https://www.youtube.com/watch?v=hlzJXCMzjR0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-23 00:00:00+00:00

Taken from JRE #1639 w/Dave Smith:
https://open.spotify.com/episode/7taqki4fGUkcXESbaUzjgh?si=a13f5806749c45aa

## Joe Discusses the Masvidal vs. Usman Rematch with Stephen "Wonderboy" Thompson
 - [https://www.youtube.com/watch?v=nA3UapKTPl8](https://www.youtube.com/watch?v=nA3UapKTPl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-22 00:00:00+00:00

Taken from JRE MMA Show #108 w/Stephen Thompson:
https://open.spotify.com/episode/0hiHQp5AcoPmUDOuoG3KUx?si=d9477ddc1b684b76

## Stephen "Wonderboy" Thompson on the Relief of Being KO'D
 - [https://www.youtube.com/watch?v=fD3p_P208xQ](https://www.youtube.com/watch?v=fD3p_P208xQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-22 00:00:00+00:00

Taken from JRE MMA Show #108 w/Stephen Thompson:
https://open.spotify.com/episode/0hiHQp5AcoPmUDOuoG3KUx?si=d9477ddc1b684b76

