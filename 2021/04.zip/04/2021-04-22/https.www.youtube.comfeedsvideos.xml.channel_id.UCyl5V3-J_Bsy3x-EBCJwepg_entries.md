# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Chip and Joanna Gaines Team Up With Antifa For New Show... Smasher Upper!
 - [https://www.youtube.com/watch?v=qj-xafacSsQ](https://www.youtube.com/watch?v=qj-xafacSsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-23 00:00:00+00:00

Coming soon to Discovery+, Chip and JoJo from Fixer Upper are back! But this time, they’ll be destroying the building of Antifa’s dreams. This is Smasher Upper.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Pastor Loses Building to Covid, Has Church In His Driveway
 - [https://www.youtube.com/watch?v=0QB1kR1gVzY](https://www.youtube.com/watch?v=0QB1kR1gVzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-23 00:00:00+00:00

Pastor Craig Hamilton of ChurchTwo42 in California talks about how he lost his church meeting space when Covid hit and decided to keep the church meeting in his driveway. The church has 200 members and continues to grow. To help the church get out of the driveway and into a new building please go to https://my.gobluefire.com/App/Form/89f65d90-502a-43a9-9768-02046b9317c9

## Sins and Dangerous Croissants
 - [https://www.youtube.com/watch?v=Edm1LmBbKhM](https://www.youtube.com/watch?v=Edm1LmBbKhM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-23 00:00:00+00:00

On The Babylon Bee Weekly Podcast, Kyle and Ethan are joined by guest host, Pastor Craig Hamilton of Church Two42. They find the strangest of news like the police being called on a woman afraid of a croissant and Twitter censoring James O’Keefe for doing actual reporting. Kyle and Ethan hear about Pastor Craig’s fundraiser to build a church that isn’t in his front yard and play the game,‘Sin or Not Sin, where Pastor Craig lets you know if a well-done steak or jazzercise will be getting you in trouble with the good Lord. As always we end with our everlasting hate mail, this time coming from a YouTube commenter that was most likely wearing a mask when he made his comment.

Donate to Pastor Craig's church here: https://my.gobluefire.com/App/Form/89f65d90-502a-43a9-9768-02046b9317c9

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## BLM Founder Reminds Everyone Justice Won't Fully Be Served Until She Can Buy A 5th House
 - [https://www.youtube.com/watch?v=EK2EIaVlWQM](https://www.youtube.com/watch?v=EK2EIaVlWQM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-22 00:00:00+00:00

What's next for racial justice? One BLM founder thinks there is a long, lucrative future ahead for BLM. 

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

