# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The New Purple iPhone 12!
 - [https://www.youtube.com/watch?v=t7jbT1YhyQU](https://www.youtube.com/watch?v=t7jbT1YhyQU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-04-23 00:00:00+00:00

Unboxing a brand new iPhone - the purple one this time. They've really done it.

Try Luminar AI https://l.skylum.com/MKBHD
Use MKBHD at checkout to save $15

The Truth about Colored Phones: https://youtu.be/fJ_PNOXycwg

Purple dbrand skin: https://dbrand.com/purple

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds​​​ 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## Apple AirTags Unboxing & Demo!
 - [https://www.youtube.com/watch?v=ehv3zQAa9zM](https://www.youtube.com/watch?v=ehv3zQAa9zM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-04-22 00:00:00+00:00

AirTags and the new "Precision Finding" in action.

dbrand AirTags: https://dbrand.com/airtag

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

AirTags provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

