# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## What if you had amnesia?
 - [https://www.youtube.com/watch?v=cQAHt8GDx8A](https://www.youtube.com/watch?v=cQAHt8GDx8A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-04-22 00:00:00+00:00

What if life was exactly like The Fast & The Furious ... Thank you to Betterhelp for sponsoring today's video. Get 10% off you first month here: https://betterhelp.com/nolke

So I may or may not have binged the entire Fast and Furious franchise in a matter of days... zero regrets! Who knew that such a beautiful moral could be drawn alongside Vin Diesel's bulging and beautiful biceps? Anyone else excited for F9: the ninth Fast and Furious? 

Support the channel by liking and subscribing! 
Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke

Written by: Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay

