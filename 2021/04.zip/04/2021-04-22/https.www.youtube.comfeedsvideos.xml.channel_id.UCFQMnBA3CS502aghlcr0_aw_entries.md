# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Confronting an Accidental Crypto "Billionaire"
 - [https://www.youtube.com/watch?v=lT9Pimq6v7k](https://www.youtube.com/watch?v=lT9Pimq6v7k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-04-23 00:00:00+00:00

This guy became a crypto "billionaire" in 30 minutes by creating a random trash coin. CRYPTO IS NOT A BUBBLE. 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## THE TRUTH ABOUT DOGECOIN
 - [https://www.youtube.com/watch?v=yKV3dICxnN4](https://www.youtube.com/watch?v=yKV3dICxnN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-04-22 00:00:00+00:00

DogeCoin to the dirt or to the moon?  In this video I discuss Dogecoin and my thoughts on whether cryptocurrency is in a bubble right now, whether you should hold DOGE, buy DOGE or trade DOGE. 

Do you hold doge? Let me know in the comments below. 

► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

