# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Psychedelic Porn Crumpets - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Pui8Yberr_k](https://www.youtube.com/watch?v=Pui8Yberr_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-23 00:00:00+00:00

http://KEXP.ORG presents Psychedelic Porn Crumpets sharing a live performance recorded exclusively for KEXP. Band members Jack McEwan and Chris Young talk to DJ Troy Nelson. Recorded April 1, 2021.

Songs:
Mr. Prism
Tally-Ho
Pukebox
Mundungus
Found God in a Tomato

Performance filmed & recorded at Corner Gallery, Subiaco, Western Australia
Audio mixed by Michael Jelinek
Video shot & directed by Tay Kaka
Assistant Camera by Alec Kucy

https://www.psychedelicporncrumpets.com
http://kexp.org

