# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This Epic Studio Tour Almost Killed Me!!
 - [https://www.youtube.com/watch?v=zk97ywS-fGc](https://www.youtube.com/watch?v=zk97ywS-fGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-04-13 00:00:00+00:00

Thanks to AnkerWork for sponsoring this video! Check out the PowerConf C300 webcam at US: http://ankerfast.club/LTT_PowerConfC300_US UK: http://ankerfast.club/LTT_PowerConfC300_UK 
DE: http://ankerfast.club/LTT_PowerConfC300_DE

The Linus Media Group team has been expanding a lot in the past few years, and with it so has our office! Linus is here to show you all around and see what's been happening behind the scenes.

Check out Ubiquiti's Unifi Protect gear at https://lmg.gg/uJ5ng

Subscribe to the new Mac Address channel at https://lmg.gg/UQ5vh
Subscribe to Carpool Critics at https://lmg.gg/Nx4Vw
Subscribe to ShortCircuit at https://lmg.gg/kmFFM
Subscribe to TechLinked at https://lmg.gg/8bKG7
Subscribe to Techquickie at https://lmg.gg/umVjs

Check out our industrial laser cutter/engraver from Trotec at http://geni.us/trotec

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1326345-this-epic-studio-tour-almost-killed-me-sponsored/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## ULTIMATE RGB PC Build Guide 2021
 - [https://www.youtube.com/watch?v=qkIpTWIiuI4](https://www.youtube.com/watch?v=qkIpTWIiuI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-04-12 00:00:00+00:00

Get $25 off each pair with offer code LinusTechTips at https://www.vessifootwear.com/linustechtips

Check out Crucial at: https://crucial.gg/LinusTechTips

We're at it again, this time using no internal proprietary Corsair parts and relying entirely on ARGB headers for the update to our 2017 RGB Build Guide


Buy Intel Core i9 10850K CPU: https://geni.us/JuTllC
Buy ASUS ROG Strix RX 6800 GPU: https://geni.us/5nGt
Buy ASUS ROG Thor 1200w RGB PSU: https://geni.us/23RR0L
Buy G.Skill Trident Z RGB 4x16GB RAM: https://geni.us/r2clEbq
Buy MSI MAG Coreliquid 360R CPU Cooler: https://geni.us/ee3mj
Buy Phanteks p500a Digital : https://geni.us/NFeG
Buy Phanteks Neon Digital ARGB LED Strip Combo: https://geni.us/PtVhJ5
Buy Phanteks Neon Digital ARGB LED Strip M5: https://geni.us/hWksyCH
Buy Cooler Master ARGB GPU Support Bracket: https://geni.us/I0NkhjZ
Buy Cooler Master ARGB LED Controller: https://geni.us/rvHhx
Buy Cooler Master ARGB 1-3 RGB Splitter Cable: https://geni.us/F3JV90
Buy ARCTIC BioniX P120 A-RGB Fan: https://geni.us/QqM2Z
Buy Corsair iCUE LT100 Smart Lighting Towers Starter Kit: https://geni.us/6eCRz
Buy Corsair ST100 RGB Premium Headset Stand: https://geni.us/1U0nu
Buy Corsair Virtuoso RGB Wireless High-Fidelity Gaming Headset: https://geni.us/Ta74q
Buy Corsair MM700 RGB Extended Mouse Pad: https://geni.us/6BAvkj
Check out the Marsback M1 Keyboard at https://lmg.gg/lK21x
Check out the Marsback Zephyr Gaming Mouse at https://lmg.gg/RUA1A

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1325795-ultimate-rgb-pc-build-guide-2021/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

