# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Ali Macofsky Was Making Prank Calls for Ryan Seacrest at Age 7
 - [https://www.youtube.com/watch?v=03kiFNh-9ME](https://www.youtube.com/watch?v=03kiFNh-9ME)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-13 00:00:00+00:00

Taken from JRE #1633 a/Ali Macofsky:
https://open.spotify.com/episode/3VKj1OlBttVfM0ASVgJaMu?si=3220668973594fe4

## How Joe Biden is Dealing with the US-Mexico Border Crisis
 - [https://www.youtube.com/watch?v=uyW8djsHKCo](https://www.youtube.com/watch?v=uyW8djsHKCo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-13 00:00:00+00:00

Taken from JRE #1633 w/Ali Macofsky:
https://open.spotify.com/episode/3VKj1OlBttVfM0ASVgJaMu?si=3220668973594fe4

## OnlyFans Becoming Popular During the Pandemic
 - [https://www.youtube.com/watch?v=yQFuQwEsJg4](https://www.youtube.com/watch?v=yQFuQwEsJg4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-04-13 00:00:00+00:00

Taken from JRE #1633 /Ali Macofsky:
https://open.spotify.com/episode/3VKj1OlBttVfM0ASVgJaMu?si=3220668973594fe4

