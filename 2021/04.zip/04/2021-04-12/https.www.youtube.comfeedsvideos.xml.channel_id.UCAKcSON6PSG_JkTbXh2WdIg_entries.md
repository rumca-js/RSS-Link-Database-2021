# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Emilio Estevez on returning to the role of Gordon Bombay in 'The Mighty Ducks: Game Changers'
 - [https://www.youtube.com/watch?v=LkQg_xOy0Oo](https://www.youtube.com/watch?v=LkQg_xOy0Oo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-13 00:00:00+00:00

Emilio Estevez joined The Current's Jill Riley for a conversation about returning to the iconic role of Gordon Bombay in the new Disney+ series 'The Mighty Ducks: Game Changers.' After all these years, how's Gordon doing? It sounds like he's going to need a little help.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/​
https://twitter.com/TheCurrent​
https://www.instagram.com/thecurrent/

## Low - three songs at The Current (2015)
 - [https://www.youtube.com/watch?v=QM8D8RlrfGY](https://www.youtube.com/watch?v=QM8D8RlrfGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-13 00:00:00+00:00

Duluth rock band Low are Monday's featured artists for Minnesota Music Month. Here's a session by Low recorded back in September 2015, just days after the release of their 11th album, "Ones and Sixes."

Low have played together since 1993, but frontman Alan Sparkhawk has a simple formula for the way the band members have sustained their passion and creativity for more than two decades. "Luckily we've always been pretty naïve," Sparhawk said, "and [we] didn't really know what we're doing and always felt like we're learning."

For "Ones and Sixes," Low recorded at Justin Vernon's April Base studio in Eau Claire, Wis., and worked with producer and engineer BJ Burton. "We've bveen able to work with a lot of great people," Sparhawk said. "That, in a lot of ways, is sort of a key. You kind of always need to find a new way, a new filter to try to see what you do will end up being."

SONGS PERFORMED
0:00 "What Part of Me"
3:09 "No Comprende"
8:13 "DJ"

PERSONNEL
Alan Sparhawk – guitar, vocals
Mimi Parker – drums, vocals
Steve Garrington – bass

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2007 studio session: https://www.thecurrent.org/feature/2007/03/30/low
2011 studio session:
https://www.thecurrent.org/feature/2011/04/15/-low-in-the-current-studio
2013 studio session:
https://www.thecurrent.org/feature/2013/03/28/low-live
2015 studio session:
https://www.thecurrent.org/feature/2015/09/18/low-perform-in-the-current-studio
2015 Alan Sparhawk of Low, Guitar Collection interview:
https://www.thecurrent.org/feature/2015/09/23/the-current-s-guitar-collection-low-s-alan-sparhawk-danelectro-convertible


Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#low #lowtheband

## St. Vincent talks about 'Daddy's Home,' and SNL
 - [https://www.youtube.com/watch?v=1jSl44JmPZU](https://www.youtube.com/watch?v=1jSl44JmPZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-13 00:00:00+00:00

St. Vincent's Annie Clark connects with Jade to talk about her upcoming album Daddy's Home, the visual representations that have accompanied the eras of her discography, and putting together the band for her recent Saturday Night Live performance.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​
https://twitter.com/TheCurrent​​
https://www.instagram.com/thecurrent/

## Judith Hill - Burn It All (live performance)
 - [https://www.youtube.com/watch?v=6zI0QpLKvds](https://www.youtube.com/watch?v=6zI0QpLKvds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-12 00:00:00+00:00

Watch @JudithHillMusic perform her 2021 track, "Burn It All," from her latest record 'Baby, I'm Hollywood!' Don't miss Judith Hill's full virtual session with The Current here: https://youtu.be/j0TYFDksEJA

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​
https://twitter.com/TheCurrent​​
https://www.instagram.com/thecurrent/

## Judith Hill - God Bless the Mechanic (live performance)
 - [https://www.youtube.com/watch?v=93pKqAeeXU0](https://www.youtube.com/watch?v=93pKqAeeXU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-12 00:00:00+00:00

Watch @JudithHillMusic perform her 2021 track, "God Bless the Mechanic," from her latest record 'Baby, I'm Hollywood!' Don't skip out on Judith Hill's full virtual session with The Current here: https://youtu.be/j0TYFDksEJA

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​
https://twitter.com/TheCurrent​​
https://www.instagram.com/thecurrent/

## Judith Hill - When My World Is Blue (live performance)
 - [https://www.youtube.com/watch?v=TGMI2eETnWI](https://www.youtube.com/watch?v=TGMI2eETnWI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-04-12 00:00:00+00:00

Watch @JudithHillMusic perform her 2021 track, "When My World Is Blue," from her latest record 'Baby, I'm Hollywood!' Don't skip out on Judith Hill's full virtual session with The Current here: https://youtu.be/j0TYFDksEJA

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​
https://twitter.com/TheCurrent​​
https://www.instagram.com/thecurrent/

