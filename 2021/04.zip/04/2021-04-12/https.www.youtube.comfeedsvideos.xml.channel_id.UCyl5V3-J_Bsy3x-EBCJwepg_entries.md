# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## "Satanic" Metal Bands That Were Actually Closeted Jesus Lovers
 - [https://www.youtube.com/watch?v=9zLAOtFcf30](https://www.youtube.com/watch?v=9zLAOtFcf30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-04-13 00:00:00+00:00

On The Babylon Bee Podcast, Kyle, Ethan, and guest-host Trevor Andersen talk about which popular metal bands you may not realize have Jesus-loving members.

See the full show here:
https://www.youtube.com/watch?v=5PRFGwuResI&t=978s

Hit the bell to get your daily dose of fake news that you can trust.

