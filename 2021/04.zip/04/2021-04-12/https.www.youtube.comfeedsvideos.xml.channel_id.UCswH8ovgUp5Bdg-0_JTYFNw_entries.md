# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Vandana Shiva: Bill Gates’s Book Is Rubbish!
 - [https://www.youtube.com/watch?v=3_8owv2dtP0](https://www.youtube.com/watch?v=3_8owv2dtP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-04-13 00:00:00+00:00

In my latest Under The Skin podcast I spoke with Indian scholar, food sovereignty advocate and environmental activist #VandanaShiva. In this video she speaks about #BillGates's book, the colonisation of land and food production, however she provides us with hopeful and powerful words of advice that might help us challenge these Tech Giants and monopolies.

Listen to my Under The Skin podcast to hear from guests including Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Get a free trial at http://luminary.link/russell

For more information on Vandana’s work and to take part in her online courses go to navdanya.org 

Her latest book is called: Oneness VS the 1%: Shattering Illusions, Seeding Freedom.

Also please check out the documentary film about Vandana’s work “The Seeds of Vandana” here: https://vandanashivamovie.com

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is out NOW!
US: 
http://adbl.co/revelation
UK: 
http://adbl.co/revelationuk
AU: 
http://adbl.co/revelationau
CA: 
http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

