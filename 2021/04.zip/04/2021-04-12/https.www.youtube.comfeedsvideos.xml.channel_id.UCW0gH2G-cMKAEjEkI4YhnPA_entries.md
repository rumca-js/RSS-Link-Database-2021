# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Russian Lord of the Rings - Reaction Livestream
 - [https://www.youtube.com/watch?v=y10w8npo3cE](https://www.youtube.com/watch?v=y10w8npo3cE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-04-13 00:00:00+00:00

Join us in watching and reacting to the newly-released Russian version of The Lord of the Rings.  Released in 1991, this Soviet-era teleplay adaptation is called "Khraniteli", which means "Keepers" (of the Ring).  It originally aired in 1991 and was thought lost, until recently being republished on YouTube.

WATCH THE ORIGINAL HERE: https://youtu.be/vquKyNdgH3s

Notable for it's inclusion of Tom Bombadil, Goldberry, and the Barrow-wight, the adaptation runs roughly two hours and covers the events of The Fellowship of the Ring.

*We will also announce the WINNERS of our 200k subscriber giveaway at the beginning of this stream!*

