# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Star Wars: Detours FINALLY!🌑 Live-Action Gundam!🦾 &… GOODBYE!👋-Fantasy News
 - [https://www.youtube.com/watch?v=cNQ3dgWXExI](https://www.youtube.com/watch?v=cNQ3dgWXExI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-04-13 00:00:00+00:00

Let's go right ahead and talk about the fantasy news! From Star Wars to the Witcher... and Powerpuff Girls. 
The first 1000 people to use the link will get a free trial of Skillshare Premium Membership: https://skl.sh/danielgreene04211  

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS:

00:00 intro 

00:29 Perhaps The Stars: https://twitter.com/torbooks/status/1379811206513352704?s=19  

01:00 Iron Widow: https://twitter.com/XiranJayZhao/status/1380599113461366787 

02:39 Witcher Loses Actress: https://deadline.com/2021/04/jodie-turner-smith-exits-the-witcher-blood-origin-netflix-limited-series-prequel-scheduling-1234729941/ 

03:06 Godzilla Kong Box Office: https://deadline.com/2021/04/godzilla-vs-kong-third-weekend-mortal-kombat-opening-china-global-international-box-office-1234732035/ 

04:37 Star Wars Detour: https://www.thevulcanreporter.com/exclusives/star-wars-detours-disney-plus-release/ 

05:59 Primal: https://www.youtube.com/watch?v=Nf0tqWiOfgA&ab_channel=AdultSwimUK 

06:26 Alien Remastered: https://www.thedigitalfix.com/film/home-releases-news/aliens-exclusive/ 

07:13 Powerpuff Girls First Look:  https://twitter.com/DiscussingFilm/status/1381684663324979201?s=20 

07:25 Live Action Gundam https://www.ign.com/articles/netflix-is-making-a-live-action-gundam-movie-with-jordan-vogt-roberts-directing  

08:08 New Most Valuable Comic: https://screenrant.com/superman-action-comics-sale-record-price-dc/ 

08:29 Zemo Dancing: https://www.instagram.com/p/CNaufXBnR_i/?igshid=c9b09qqtvhz5 

08:53 Goodbye.. office.

