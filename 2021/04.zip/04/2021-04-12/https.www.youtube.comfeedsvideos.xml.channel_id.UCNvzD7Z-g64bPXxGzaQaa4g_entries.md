# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 5 OPEN WORLD Games With INCREDIBLE Enemy AI
 - [https://www.youtube.com/watch?v=C8NLT6P9mgY](https://www.youtube.com/watch?v=C8NLT6P9mgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-13 00:00:00+00:00

Some video game enemies feel super smart thanks to great design. Here are some of our favorite recent examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Shadow of Mordor/War
https://www.theguardian.com/technology/2015/feb/05/shadow-of-mordor-nemesis-system#:~:text=This%20sandbox%20approach%20to%20the,beings%2C%20but%20rarely%20in%20games.
+
https://www.youtube.com/watch?v=gm7K68663rA&ab_channel=GDC
+
https://shadowofwar.fandom.com/wiki/Nemesis


MGSV
https://www.forbes.com/sites/erikkain/2015/09/03/12-incredible-things-about-metal-gear-solid-v-the-phantom-pain/?sh=1bd2025452df
+
https://metalgear.fandom.com/wiki/Revenge_System_(enemy_preparedness)


STALKER
https://www.reddit.com/r/stalker/comments/6to9wt/the_ai_of_stalker/
+
https://www.reddit.com/r/stalker/comments/7848az/i_would_argue_that_stalker_has_the_best_ai_in/
+
https://dzone.com/articles/a-life-an-insight-into-ambitious-ai



BoTW
https://www.reddit.com/r/gaming/comments/5xh5lb/when_the_smart_ai_outplays_the_player_breath_of/
https://www.reddit.com/r/zelda/comments/kops12/botw_i_still_find_cool_little_things_in_breath_of/



Red Dead:

https://www.thegamer.com/red-dead-redemption-2-ai-fix-scripted-scene/

https://medium.com/the-sound-of-ai/the-reality-of-red-dead-redemption-2s-ai-part-1-c276e9da2763

https://www.youtube.com/watch?v=cj7KnllcYzE&ab_channel=R-Type

## 10 GTA Clones That ACTUALLY SUCKED
 - [https://www.youtube.com/watch?v=LThyyR2qrys](https://www.youtube.com/watch?v=LThyyR2qrys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-12 00:00:00+00:00

Many games try to capitalize on the success of Grand Theft Auto and GTA Online. Here are some of our least favorites.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

cancelled open world South Park game: https://youtu.be/ifgnTz1oN5I

