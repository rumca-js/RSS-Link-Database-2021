# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## drivers license | Olivia Rodrigo | funk cover ft. Astyn Turr
 - [https://www.youtube.com/watch?v=590pA-PHcsI](https://www.youtube.com/watch?v=590pA-PHcsI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-04-12 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Olivia Rodrigo's "drivers license" by Scary Pockets & Astyn Turr.

MUSICIAN CREDITS
Lead vocal: Astyn Turr
Drums: Kristen Gleeson-Prata
Bass: JP Maramba
Guitar: Jude Smith
Baritone Guitar: Ryan Lerman
Keys: Jack Conte

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Kevin Brown
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
Director: Merlin Camozzi
DP: Marc Patterson
Camera Operator: Nate Nguyen-Le
Editor: Adam Kritzberg

Recorded Live at Debs Park in Los Angeles, CA.

#ScaryPockets #Funk #DriversLicense #OliviaRodrigo #AstynTurr

