# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Retro Tech: Flying Cars
 - [https://www.youtube.com/watch?v=ifI_fwg55k8](https://www.youtube.com/watch?v=ifI_fwg55k8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-04-13 00:00:00+00:00

No matter what year, the idea of flying vehicles helps cement our sense of when the future begins. I’m taking a look at everything flying – from cars to skateboards – and seeing where the tech currently stands. I also look at some classic old toys with comedian Michael Ian Black.

0:00 Intro
0:40 Unboxing The Segway
3:09 Talking Flying Cars
5:32 Hyperchange’s Galli Russell
8:29 The Hoverboard
11:14 Dope Or Nope
16:10 Omni Hoverboards
18:44 Wrap Up

## The World's Largest Smartphone Camera!
 - [https://www.youtube.com/watch?v=R5_v0OdFD0A](https://www.youtube.com/watch?v=R5_v0OdFD0A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-04-12 00:00:00+00:00

Xiaomi Mi 11 Ultra sets some records, plus a screen on the back for good measure!

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Xiaomi for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

