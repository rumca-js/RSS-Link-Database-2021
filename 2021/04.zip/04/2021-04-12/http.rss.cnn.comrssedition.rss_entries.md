# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 95-year-old Covid-19 survivor sings Sinatra for Anderson Cooper
 - [https://www.cnn.com/videos/us/2021/04/12/marine-veteran-covid-19-survivor-james-ingargiola-acfc-full-episode-vpx.cnn](https://www.cnn.com/videos/us/2021/04/12/marine-veteran-covid-19-survivor-james-ingargiola-acfc-full-episode-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 23:47:42+00:00

Anderson Cooper talks with 95-year-old Marine, WWII veteran, father and grandfather, lung cancer survivor and Covid-19 survivor James Ingargiola. Watch "Full Circle" Monday, Tuesday and Friday at 6p E.T.

## George Floyd's brother testifies at Chauvin trial in unique 'spark of life' testimony
 - [https://www.cnn.com/2021/04/12/us/derek-chauvin-trial-george-floyd-day-11/index.html](https://www.cnn.com/2021/04/12/us/derek-chauvin-trial-george-floyd-day-11/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 22:11:08+00:00

Pausing every so often to wipe away tears, Philonise Floyd testified Monday at Derek Chauvin's trial that his elder brother George Floyd was a big mama's boy who was distraught by her death in 2018.

## One dead, officer injured in Tennessee school shooting
 - [https://www.cnn.com/2021/04/12/us/knoxville-school-shooting/index.html](https://www.cnn.com/2021/04/12/us/knoxville-school-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 21:54:04+00:00

Knoxville Police Department (KPD) in Tennessee said that multiple agencies are at the scene of a shooting Austin-East Magnet High School.

## This robot can deliver a pizza. Could your neighborhood be next?
 - [https://www.cnn.com/videos/business/2021/04/12/dominos-pizza-delivery-robot-nuro-gr-orig.cnn](https://www.cnn.com/videos/business/2021/04/12/dominos-pizza-delivery-robot-nuro-gr-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 21:24:25+00:00

Domino's has teamed up with the autonomous vehicle company Nuro to test a new way for customers to get their pizzas.

## One dead, one injured in shooting outside Paris hospital
 - [https://www.cnn.com/2021/04/12/europe/paris-hospital-shooting-intl/index.html](https://www.cnn.com/2021/04/12/europe/paris-hospital-shooting-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 21:14:29+00:00

One person was killed and another injured after a shooting in front of a private hospital in Paris on Monday, a police source told CNN.

## Virginia police officer who pepper-sprayed Army officer during traffic stop is fired
 - [https://www.cnn.com/2021/04/12/us/caron-nazario-officer-fired/index.html](https://www.cnn.com/2021/04/12/us/caron-nazario-officer-fired/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 21:11:39+00:00

One of the police officers accused of using excessive force in a Virginia traffic stop has been fired following an investigation, the town manager said late Sunday.

## 'How the hell does that happen?': Brooke Baldwin reacts to police explanation
 - [https://www.cnn.com/videos/us/2021/04/12/daunte-wright-police-chief-shooting-accident-ramsey-honig-sot-vpx.cnn](https://www.cnn.com/videos/us/2021/04/12/daunte-wright-police-chief-shooting-accident-ramsey-honig-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 21:00:38+00:00

CNN's Brooke Baldwin discusses Brooklyn Center, Minnesota, Police Chief Tim Gannon's opinion that a police officer meant to deploy a Taser instead of her gun when she shot Daunte Wright.

## Mysterious blackout in Iran threatens to undermine nuclear talks
 - [https://www.cnn.com/2021/04/12/middleeast/iran-natanz-talks-intl/index.html](https://www.cnn.com/2021/04/12/middleeast/iran-natanz-talks-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 20:39:28+00:00

Iran's Foreign Minister Javad Zarif has vowed revenge against Israel after an apparent attack on an Iranian nuclear site caused a blackout at the facility over the weekend.

## Lachlan Murdoch dismisses complaint against Tucker Carlson's 'replacement theory' remarks
 - [https://www.cnn.com/2021/04/12/media/murdoch-response-adl-tucker-carlson/index.html](https://www.cnn.com/2021/04/12/media/murdoch-response-adl-tucker-carlson/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 20:23:50+00:00

Fox Corporation chief executive Lachlan Murdoch dismissed the Anti-Defamation League's demand that the company fire host Tucker Carlson, telling the organization in a letter that his company saw no problem with comments Carlson made about the racist "great replacement" theory.

## Biden admin secures agreements with Mexico, Honduras and Guatemala to secure borders, official says
 - [https://www.cnn.com/2021/04/12/politics/biden-agreement-mexico-honduras-guatemala/index.html](https://www.cnn.com/2021/04/12/politics/biden-agreement-mexico-honduras-guatemala/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 20:05:11+00:00

The Biden administration has secured agreements for Mexico, Honduras, and Guatemala to tighten their borders and stem the flow of migration, Special Assistant to the President for Immigration for the Domestic Policy Council Tyler Moran told MSNBC Monday.

## CEOs vow to fight voting restrictions despite threats from Trump and McConnell
 - [https://www.cnn.com/2021/04/12/business/ceos-voting-restrictions-trump-mcconnell/index.html](https://www.cnn.com/2021/04/12/business/ceos-voting-restrictions-trump-mcconnell/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 20:03:45+00:00

Dozens of business leaders held an hour-long brainstorming session over the weekend to discuss ways to fight controversial voting restrictions proposed in states around the country.

## A guide for Muslims celebrating Ramadan in the US during the pandemic
 - [https://www.cnn.com/2021/04/12/us/ramadan-muslim-coronavirus-vaccine-fasting-wellness-trnd/index.html](https://www.cnn.com/2021/04/12/us/ramadan-muslim-coronavirus-vaccine-fasting-wellness-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 19:09:12+00:00

This week, Muslims across the United States will begin observing another pandemic Ramadan.

## Officer who fatally shot Daunte Wright shouted 'Taser!' but pulled gun instead, police say
 - [https://www.cnn.com/2021/04/12/us/brooklyn-center-minnesota-police-shooting/index.html](https://www.cnn.com/2021/04/12/us/brooklyn-center-minnesota-police-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 19:01:01+00:00

[Breaking news update at 1:16 p.m. ET]

## Covid-19 is out of control in Brazil. So why are some officials easing restrictive measures?
 - [https://www.cnn.com/collections/covid-int-04-12/](https://www.cnn.com/collections/covid-int-04-12/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 18:47:37+00:00



## Covid-19 is out of control in Brazil. So why are some officials easing restrictions?
 - [https://www.cnn.com/2021/04/12/americas/brazils-covid-crisis-lockdowns-intl-latam/index.html](https://www.cnn.com/2021/04/12/americas/brazils-covid-crisis-lockdowns-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 18:12:38+00:00

• Chinese Covid-19 vaccine efficacy is 'not high'
• More young people hospitalized as 'stickier,' more infectious strain becomes dominant

## Brazil is building a new statue of Jesus -- and it's going to be bigger than Rio's
 - [https://www.cnn.com/travel/article/brazil-christ-statue-encantado-scli-intl/index.html](https://www.cnn.com/travel/article/brazil-christ-statue-encantado-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 16:53:17+00:00

A huge statue of Jesus Christ is under construction in southern Brazil, and it will be even taller than its famous counterpart in Rio de Janeiro.

## 100 days later, Brexit isn't working and business wants it fixed
 - [https://www.cnn.com/2021/04/12/business/brexit-trade-100-days/index.html](https://www.cnn.com/2021/04/12/business/brexit-trade-100-days/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 16:35:09+00:00

When British Prime Minister Boris Johnson announced his Brexit trade deal on December 24, he said it would enable UK companies "to do even more business" with the European Union.

## Grimes shows off the 'beautiful alien scars' she's had tattooed across her back
 - [https://www.cnn.com/2021/04/12/entertainment/grimes-alien-scars-tattoos-scli-intl/index.html](https://www.cnn.com/2021/04/12/entertainment/grimes-alien-scars-tattoos-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 16:14:40+00:00

Canadian musician Grimes has unveiled the "beautiful alien scars" she's had tattooed across her entire back.

## While the Masters winner celebrated, his caddie's humility went viral
 - [https://www.cnn.com/2021/04/12/golf/masters-2021-hideki-matsuyama-caddie-shota-hayafuji-spt-intl/index.html](https://www.cnn.com/2021/04/12/golf/masters-2021-hideki-matsuyama-caddie-shota-hayafuji-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 16:05:53+00:00

After winning the Masters, cameras were naturally trained on a visibly emotional Hideki Matsuyama as he took in the magnitude of his triumph.

## Harry pays tribute to 'cheeky' grandpa Prince Philip as he returns to UK for funeral
 - [https://www.cnn.com/2021/04/12/uk/prince-harry-prince-philip-funeral-gbr-intl/index.html](https://www.cnn.com/2021/04/12/uk/prince-harry-prince-philip-funeral-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 15:20:09+00:00

Britain's Prince Harry has paid tribute to his grandfather Prince Philip, describing him as "a man of service, honour and great humour," after reportedly flying back to the United Kingdom ahead of the funeral on Saturday.

## Here's the biggest myth in the Republican Party today
 - [https://www.cnn.com/2021/04/12/politics/donald-trump-mitch-mcconnell-gop/index.html](https://www.cnn.com/2021/04/12/politics/donald-trump-mitch-mcconnell-gop/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 15:18:34+00:00

In the wake of Donald Trump calling Mitch McConnell a "dumb son of a b*tch" over the weekend at an event for major donors to the Republican National Committee, the big storyline has been of the ongoing struggle between the two men for control of the GOP.

## 'WTF With Marc Maron' awarded the Governors Award by The Podcast Academy
 - [https://www.cnn.com/2021/04/12/entertainment/marc-maron-wtf-podcast-award/index.html](https://www.cnn.com/2021/04/12/entertainment/marc-maron-wtf-podcast-award/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 14:28:26+00:00

"WTF with Marc Maron" will receive the first-ever Governors Award at the inaugural Awards for Excellence in Audio (The Ambies) on May 16.

## US and China deploy aircraft carriers in South China Sea as tensions simmer
 - [https://www.cnn.com/2021/04/12/china/south-china-sea-taiwan-military-tensions-intl-hnk/index.html](https://www.cnn.com/2021/04/12/china/south-china-sea-taiwan-military-tensions-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 14:17:57+00:00

Military activity in the South China Sea spiked over the weekend as a Chinese aircraft carrier entered the region and a US Navy expeditionary strike group wrapped up exercises.

## Major Biden to get training after two biting incidents
 - [https://www.cnn.com/2021/04/12/politics/major-biden-training/index.html](https://www.cnn.com/2021/04/12/politics/major-biden-training/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 14:09:46+00:00

President Joe Biden's German shepherd, Major, will receive training after two biting incidents involving workers at the White House, according to first lady Jill Biden's spokesman.

## The Soviet cosmonaut who fueled the space race
 - [https://www.cnn.com/2021/04/12/world/space-race-yuri-gagarin-scn/index.html](https://www.cnn.com/2021/04/12/world/space-race-yuri-gagarin-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 14:03:04+00:00

President John Fitzgerald Kennedy was having a rough time of it in April 1961.

## Tottenham star Son Heung-Min racially abused online after Premier League defeat
 - [https://www.cnn.com/2021/04/12/football/son-heung-min-tottenham-racist-abuse-spt-intl/index.html](https://www.cnn.com/2021/04/12/football/son-heung-min-tottenham-racist-abuse-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 13:32:44+00:00

Tottenham Hotspur has condemned the "abhorrent" online abuse directed at star player Son Heung-Min after the side's 3-1 Premier League defeat by Manchester United on Sunday.

## Colombian soccer team fields only seven players due to Covid outbreak
 - [https://www.cnn.com/2021/04/12/football/aguilas-doradas-covid-outbreak-spt-intl/index.html](https://www.cnn.com/2021/04/12/football/aguilas-doradas-covid-outbreak-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 13:07:19+00:00

Colombian professional football team Águilas Doradas fielded only seven players on Sunday for a regular match in the country's División Mayor top league due to a Covid-19 outbreak in the squad.

## Chet Hanks releases risqué 'White Boy Summer' teaser video
 - [https://www.cnn.com/2021/04/12/entertainment/chet-hanks-white-boy-summer-video-intl-scli/index.html](https://www.cnn.com/2021/04/12/entertainment/chet-hanks-white-boy-summer-video-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 12:54:10+00:00

If there's one thing Chet Hanks has mastered, it's the art of causing a stir.

## Ukraine's President heads to the trenches as Russia masses its troops
 - [https://www.cnn.com/2021/04/12/europe/ukraine-zelensky-front-lines/index.html](https://www.cnn.com/2021/04/12/europe/ukraine-zelensky-front-lines/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 12:39:00+00:00

Ankle-deep in thick black sludge, Ukrainian President Volodymyr Zelensky moves stealthily with his troops in single file through the warren of trenches and tunnels that form the tense front lines in the east of his country.

## Unprecedented footage shows front line of Ukrainian conflict with Russia
 - [https://www.cnn.com/videos/world/2021/04/12/zelensky-ukraine-matthew-chance-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/04/12/zelensky-ukraine-matthew-chance-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 12:29:58+00:00

As tensions with Russia continue to rise in eastern Europe, CNN gains unprecedented access to the Ukrainian president on the front line in Donbas, eastern Ukraine. Ukrainian military officials tell CNN they estimate more than 50,000 Russian troops are massing near the border. CNN's Matthew Chance reports.

## Early Chinese Americans were blamed for diseases and denied health care. So they built their own hospital
 - [https://www.cnn.com/2021/04/12/us/chinese-hospital-sf-chinatown-disease-outbreaks-trnd/index.html](https://www.cnn.com/2021/04/12/us/chinese-hospital-sf-chinatown-disease-outbreaks-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 11:20:39+00:00

When diseases have historically spread in the US, so too has discrimination and hate against Asian Americans.

## China creates world's first traffic signal for camels
 - [https://www.cnn.com/travel/article/china-camel-traffic-lights-scli-intl/index.html](https://www.cnn.com/travel/article/china-camel-traffic-lights-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 11:19:32+00:00

Officials in northern China have inaugurated what they say is the world's first traffic signal for camels.

## Alibaba's record fine is a 'warning shot' in China's tech crackdown
 - [https://www.cnn.com/2021/04/12/tech/alibaba-antitrust-fine-intl-hnk/index.html](https://www.cnn.com/2021/04/12/tech/alibaba-antitrust-fine-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 10:57:52+00:00

Alibaba is trying to draw a line under accusations that it behaved like a monopoly after Chinese regulators hit the online shopping giant with a record fine over the weekend. But that doesn't mean the crackdown on tech in China is over yet.

## Floating hotel concept creates its own electricity
 - [https://www.cnn.com/travel/article/qatar-eco-hotel-concept/index.html](https://www.cnn.com/travel/article/qatar-eco-hotel-concept/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 10:38:49+00:00

Floating hotels have been popping up all over the world in recent years, with destinations like Dubai and Qatar leading the way with increasingly innovative and outlandish structures.

## Millions of pilgrims gather as Covid cases rise
 - [https://www.cnn.com/2021/04/12/india/india-covid-kumbh-mela-crowd-intl-hnk-scli/index.html](https://www.cnn.com/2021/04/12/india/india-covid-kumbh-mela-crowd-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 09:59:35+00:00

Hindu devotees packed the streets of Haridwar, in northern India, on Monday for the largest religious pilgrimage on Earth, in scenes that defied social distancing rules just as Covid-19 infections soared in the country.

## 122 goals in 36 matches: The making of Bayern Munich's wonderkid Jamal Musiala
 - [https://www.cnn.com/2021/04/12/football/jamal-musiala-bayern-munich-whitgift-germany-spt-intl/index.html](https://www.cnn.com/2021/04/12/football/jamal-musiala-bayern-munich-whitgift-germany-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 09:38:44+00:00

"Unbelievable" is the word that one of Jamal Musiala's former coaches continually uses to describe the 18-year-old, who is fast developing into one of Europe's most exciting talents.

## Vice removes altered photos of Khmer Rouge victims as Cambodia protests
 - [https://www.cnn.com/2021/04/12/media/cambodia-khmer-rouge-photos-vice-intl-hnk/index.html](https://www.cnn.com/2021/04/12/media/cambodia-khmer-rouge-photos-vice-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 09:02:38+00:00

US media group Vice has removed altered photographs of Khmer Rouge genocide victims from its website after a furious backlash in Cambodia and on social media.

## Remote tribe worships Prince Philip as god, mourns his death
 - [https://www.cnn.com/videos/world/2021/04/12/prince-philip-vanuatu-special-bond-ripley-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/04/12/prince-philip-vanuatu-special-bond-ripley-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 08:22:32+00:00

For the past 50 years, villagers on the island of Tanna in Vanuatu have worshipped Prince Philip as a god. The late Duke of Edinburgh maintained a respectful relationship with them over several decades. CNN's Will Ripley reports.

## Chloé Zhao and crew reveal how they made 'Nomadland'
 - [https://www.cnn.com/style/article/nomadland-film-making-of-spc-intl/index.html](https://www.cnn.com/style/article/nomadland-film-making-of-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 04:49:13+00:00

Having been wrenched from the earth, the mineral gypsum is crushed first. It's then blasted at high temperatures and ground down, packed up and shipped out to find a new purpose. What's left behind is a void; an empty space where something once thought permanent used to be.

## Myanmar's military is charging families $85 to retrieve bodies of relatives killed in crackdown
 - [https://www.cnn.com/2021/04/11/asia/myanmar-families-bago-bodies-intl-hnk/index.html](https://www.cnn.com/2021/04/11/asia/myanmar-families-bago-bodies-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 04:05:46+00:00

Myanmar's military is charging families $85 to retrieve the bodies of relatives killed by security forces in a bloody crackdown on Friday, according to activists.

## Embattled Rep. Matt Gaetz is denied a meeting with Trump
 - [https://www.cnn.com/2021/04/11/politics/matt-gaetz-donald-trump-denied-meeting/index.html](https://www.cnn.com/2021/04/11/politics/matt-gaetz-donald-trump-denied-meeting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-12 01:58:12+00:00

Rep. Matt Gaetz, who's facing a federal investigation into sex trafficking allegations, was recently denied a meeting with Donald Trump at his Mar-a-Lago estate as the ex-President and his allies continue to distance themselves from the Florida congressman.

