# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Cercle: 5 years and counting...
 - [https://www.youtube.com/watch?v=tpmoiWCdKrg](https://www.youtube.com/watch?v=tpmoiWCdKrg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2021-04-12 00:00:00+00:00

Today, Cercle is 5 years old!

5 years of unforgettable experiences, 5 years of encounters, and more importantly: 5 years that you’ve been sharing this incredible journey with us.

We decided to celebrate this very special anniversary together and launch our first ever Cercle of Fortune! We’ll also broadcast an exclusive radio show next Monday with all the team and some surprise guests, read below for more information.

Click to enter the Cercle of Fortune and win some incredible gifts: https://Cercle.lnk.to/Fortune

The Cercle of Fortune will be on until the 20th of April at 00h CET.
Winners will be announced on Wednesday 21st! Enjoy, and good luck!

Rewards:
Gold ticket: You choose!
The winner of the Gold ticket will have the choice between two gifts: A LIFETIME TICKET or the CERCLE EXPERIENCE!

The Lifetime Ticket
Get access to every Cercle Show with audience… forever! Choose a +1 and and enjoy unlimited dancing at all Cercle Shows & Festivals and some more surprise perks (transport and accommodation are not included)

or

The Cercle Experience
Have you ever wondered what really takes place behind the scenes?
The gold ticket winner will have the possibility to become a member of the team and follow the whole crew on a show.
Feel the pressure before the show, the relief after the success, spend some time with the crew and the artists and discover the secrets behind a Cercle Show. Transport, food, housing: EVERYTHING will be included for our newest Cercle member!

Silver ticket: GET THE CERCLE PASS
5 years of Cercle… for you!
The lucky winner will receive an exclusive pass allowing him/her to have access to e v e r y Cercle Show or Festival  with audience and some surprise perks for 5 full years!
Choose your +1, choose your shows, and enjoy the moment!
(transport and accommodation are not included)

Last but not least!
20 lucky winners will receive an emblematic HD-25 light headset from Sennheiser.

Radio Show: Cercle Crew x Surprise Guests

As we are feeling nostalgic about the good old times, we will go back to our roots and host a Radio Show, live on our Twitch channel on Monday 19th of April at 8 pm CET, around the very same table where everything started 5 years ago.
Turn your camera on, and you might be able to join and discuss with the Cercle Crew and the surprise guests. Note that this particular show will be held in french.

We will never thank you enough for your unwavering support and we hope we will get to meet you back on the dancefloor very soon!

After a crazy year, we can’t wait to share our newest projects with you.

Thanks to each one of you for being a part of this incredible journey.

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

