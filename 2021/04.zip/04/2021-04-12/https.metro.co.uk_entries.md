## Boris Johnson is a creeping dictator – we need to stop him in his tracks
 - [https://metro.co.uk/2021/04/12/boris-johnson-is-a-creeping-dictator-we-need-to-stop-him-14382294/amp/?__twitter_impression=true](https://metro.co.uk/2021/04/12/boris-johnson-is-a-creeping-dictator-we-need-to-stop-him-14382294/amp/?__twitter_impression=true)
 - RSS feed: https://metro.co.uk
 - date published: 2021-04-12 14:08:39+00:00

Boris Johnson is a creeping dictator – we need to stop him in his tracks

