## NHS Covid-19 app update blocked for breaking Apple and Google's rules
 - [https://www.bbc.com/news/technology-56713017](https://www.bbc.com/news/technology-56713017)
 - RSS feed: https://www.bbc.com
 - date published: 2021-04-12 21:45:08+00:00

NHS Covid-19 app update blocked for breaking Apple and Google's rules

