# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## What Color Is My Hoodie?
 - [https://www.youtube.com/watch?v=HeKuX063bcs](https://www.youtube.com/watch?v=HeKuX063bcs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-04-12 00:00:00+00:00

Grey? Blue? Purple? It can look different, depending on the context. Let's talk about color perception, color temperature, and the history of laundry.

Atmospheric opacity image from ESA/Hubble (F. Granato): https://www.eso.org/public/images/atm_opacity/ - image licensed under CC by 4.0 - https://creativecommons.org/licenses/by/4.0/

The optical illusion is original, but based on the work of David Novick: https://twitter.com/novickprof/status/1139342022551191553

More on Illuminant D65: https://en.wikipedia.org/wiki/Illuminant_D65 - the references in this article go into the full technical detail

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

