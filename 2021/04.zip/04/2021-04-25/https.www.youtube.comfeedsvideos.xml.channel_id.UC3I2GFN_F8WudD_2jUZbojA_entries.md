# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Claud - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=hLy1Pz8ewJQ](https://www.youtube.com/watch?v=hLy1Pz8ewJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-04-26 00:00:00+00:00

http://KEXP.ORG presents Claud sharing a live performance recorded exclusively for KEXP and talking to DJ Evie. Recorded April 5, 2021.

Songs:
Cuff Your Jeans
Guard Down
In or In Between
This Town
Soft Spot

https://claud.online
http://kexp.org

