# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## PlayStation Ruined My Video
 - [https://www.youtube.com/watch?v=PF79wK4gtsw](https://www.youtube.com/watch?v=PF79wK4gtsw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-04-26 00:00:00+00:00

Good news is good unless you make videos about bad things.

Here is the remnants of what would have been the greatest YouTube video ever made.



Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

Additional Footage Sources:
Bolandish
NeoGamer - The Video Game Archive
Old and New Games
gamemaster14neo
MrGamerGod
Polygon
High Quality Gaming
andrewsqual
PS2museum
GDC
MasterKOfficial
justincronaldo7
gamedaily
IGN
Uncharted Tomb Raider
Neta Sustaita

