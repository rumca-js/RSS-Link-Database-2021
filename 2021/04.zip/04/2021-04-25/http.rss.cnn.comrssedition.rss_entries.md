# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Some parts of the US are more vulnerable to another hit by coronavirus. Here's why
 - [https://www.cnn.com/2021/04/25/health/us-coronavirus-sunday/index.html](https://www.cnn.com/2021/04/25/health/us-coronavirus-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 23:43:17+00:00

• Why India keeps setting coronavirus world records

## 'Cleanup on aisle insurrection': Avlon slams McCarthy's remarks
 - [https://www.cnn.com/videos/politics/2021/04/25/kevin-mccarthy-fox-news-trump-insurrection-response-avlon-sot-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/04/25/kevin-mccarthy-fox-news-trump-insurrection-response-avlon-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 22:46:48+00:00

Kevin McCarthy defended on Fox News former President Donald Trump's handling of the January 6 Capitol insurrection. CNN's John Avlon slammed the House minority leader's comments, saying it is "too kind" to classify his response as whitewashing.

## 'Trying to tell us the sky is not blue': Omar reacts to Lindsey Graham's remarks
 - [https://www.cnn.com/videos/politics/2021/04/25/lindsey-graham-systemic-racism-america-ilhan-omar-sot-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/04/25/lindsey-graham-systemic-racism-america-ilhan-omar-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 21:44:06+00:00

Republican Sen. Lindsey Graham (R-SC) denied that there is systemic racism in the US claiming "America's not a racist country," as President Joe Biden and others urge people to directly confront the issue as the nation grapples with a spate of police killings of Black Americans.

## Manchester City clinches fourth consecutive League Cup title as fans return to Wembley Stadium
 - [https://www.cnn.com/2021/04/25/football/manchester-city-league-cup-title-tottenham-spt-intl/index.html](https://www.cnn.com/2021/04/25/football/manchester-city-league-cup-title-tottenham-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 21:40:41+00:00

Manchester City clinched a fourth consecutive League Cup title on Sunday after beating Tottenham Hotspur 1-0 at Wembley.

## Dr. Fauci gives clarification on vaccine boosters
 - [https://www.cnn.com/videos/health/2021/04/25/dr-fauci-vaccine-booster-third-shot-coronavirus-protection-intv-nr-vpx.cnn](https://www.cnn.com/videos/health/2021/04/25/dr-fauci-vaccine-booster-third-shot-coronavirus-protection-intv-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 21:35:49+00:00

Dr. Anthony Fauci addresses public concern surrounding a possible third-dose vaccine booster. Fauci tells CNN's Jim Acosta the need is not a matter of efficacy, but rather an extension of durability of protection against coronavirus.

## Poll shows slight majority approve of Biden's performance
 - [https://www.cnn.com/videos/politics/2021/04/25/joe-biden-approval-rating-100-days-president-poll-johns-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/04/25/joe-biden-approval-rating-100-days-president-poll-johns-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 20:39:25+00:00

President Joe Biden's first term is well underway, and the American public has a track record by which to judge him. CNN's Joe Johns reports Biden sports the steadiest approval rating on record for a president through nearly 100 days in office.

## Viral pool noodle brawl started as a 'pandemic boredom' joke
 - [https://www.cnn.com/videos/us/2021/04/25/josh-fight-pool-noodle-battle-nebraska-joshfight-orig-kj.cnn](https://www.cnn.com/videos/us/2021/04/25/josh-fight-pool-noodle-battle-nebraska-joshfight-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 18:27:22+00:00

The viral event #JoshFight challenged anyone with the name Josh to show up for a raucous pool noodle fight in Lincoln, Nebraska. Find out who won the title of "ultimate Josh."

## Fareed on the J&J vaccine pause: The damage has been done
 - [https://www.cnn.com/videos/politics/2021/04/25/fareed-take-johnson-and-johnson-vaccine-pause-coronavirus-pandemic-gps-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/04/25/fareed-take-johnson-and-johnson-vaccine-pause-coronavirus-pandemic-gps-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 16:33:32+00:00

CNN's Fareed Zakaria discusses the CDC and FDA's recommendation to pause and then quickly resume the use of the Johnson & Johnson coronavirus vaccine, which has been linked to 15 cases of a rare blood clotting condition.

## 53 crew of lost naval submarine declared dead as Indonesia finds wreckage
 - [https://www.cnn.com/2021/04/25/asia/indonesia-submarine-wreckage-intl/index.html](https://www.cnn.com/2021/04/25/asia/indonesia-submarine-wreckage-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 14:55:00+00:00

The wreckage of an Indonesian Navy submarine missing since Wednesday has been found on the sea floor and all its 53 crew are confirmed dead, Indonesia military commander Air Chief Marshal Hadi Tjahjanto said Sunday.

## Harris: I wish the public could see the Joe Biden I see
 - [https://www.cnn.com/videos/politics/2021/04/25/kamala-harris-biden-afghanistan-decision-bash-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2021/04/25/kamala-harris-biden-afghanistan-decision-bash-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 14:41:36+00:00

When asked about President Joe Biden's decision to withdraw US troops from Afghanistan, Vice President Kamala Harris said Biden was a man of extraordinary courage because he made decisions based on his convictions rather than politics.

## Kamala Harris cements her place in Biden's inner circle during a consequential week
 - [https://www.cnn.com/2021/04/25/politics/kamala-harris-cnntv/index.html](https://www.cnn.com/2021/04/25/politics/kamala-harris-cnntv/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 13:41:50+00:00

Vice President Kamala Harris was huddled with other White House officials in President Joe Biden's private dining room last week when the room let out a "collective exhale." A Minnesota jury had found Derek Chauvin guilty of murdering George Floyd.

## She killed 7 members of her own family while pregnant. Now her son could be orphaned by execution
 - [https://www.cnn.com/2021/04/24/india/india-shabnam-execution-intl-dst-hnk/index.html](https://www.cnn.com/2021/04/24/india/india-shabnam-execution-intl-dst-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 11:11:48+00:00

Neighbors woke to a woman's cries for help just after 2 a.m. in Bawan Kheri, a village in the northern Indian state of Uttar Pradesh.

## Officials say the US is getting closer to the 'finish line' for coronavirus. What does that mean?
 - [https://www.cnn.com/2021/04/25/health/us-covid-19-pandemic-finish-line/index.html](https://www.cnn.com/2021/04/25/health/us-covid-19-pandemic-finish-line/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 10:01:42+00:00

Everybody is talking about the "finish line."

## Trial for former officer charged in connection with Breonna Taylor's shooting pushed to 2022
 - [https://www.cnn.com/2021/04/25/us/breonna-taylor-shooting-brett-hankison-trial-pushed-back/index.html](https://www.cnn.com/2021/04/25/us/breonna-taylor-shooting-brett-hankison-trial-pushed-back/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 08:14:06+00:00

The trial for a former Louisville police officer charged in connection with Breonna Taylor's shooting has been pushed back to February 1, 2022, according to a pre-trial hearing held in Kentucky's Jefferson County on Friday.

## India sets Covid-19 infection record for fourth straight day with hospitals desperate for oxygen
 - [https://www.cnn.com/2021/04/25/asia/india-covid-fourth-day-record-infections-intl-hnk/index.html](https://www.cnn.com/2021/04/25/asia/india-covid-fourth-day-record-infections-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 07:43:12+00:00

India reported 349,691 new cases of Covid-19 on Saturday, the fourth day in a row the country has set a world record for daily infections during the coronavirus pandemic, according to government and scientific tallies.

## At least 24 killed in massive Baghdad hospital fire after oxygen tanks exploded
 - [https://www.cnn.com/2021/04/24/middleeast/baghdad-hospital-fire-oxygen-tanks-explosion-intl/index.html](https://www.cnn.com/2021/04/24/middleeast/baghdad-hospital-fire-oxygen-tanks-explosion-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 06:46:34+00:00

At least 19 people died in a hospital fire in Baghdad Saturday night after oxygen tanks exploded, two health officials at the hospital told CNN.

## Cop shoots unarmed man who he gave a ride home to an hour earlier
 - [https://www.cnn.com/2021/04/24/us/virginia-deputy-shooting-isaiah-brown/index.html](https://www.cnn.com/2021/04/24/us/virginia-deputy-shooting-isaiah-brown/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 05:59:46+00:00

An unarmed man was shot by a Virginia sheriff's deputy about an hour after the same deputy gave the man a ride home, Virginia State Police confirmed to CNN.

## Optimism on police reform in the US Capitol collides with anguish in the streets
 - [https://www.cnn.com/collections/intl-policing-america/](https://www.cnn.com/collections/intl-policing-america/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 04:19:42+00:00



## The sigh of relief after Chauvin judge uttered the word 'guilty' three times did not last long
 - [https://www.cnn.com/2021/04/25/world/floyd-chauvin-verdict-killings-analysis-intl/index.html](https://www.cnn.com/2021/04/25/world/floyd-chauvin-verdict-killings-analysis-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 04:02:28+00:00

The world's eyes were on Minnesota's Hennepin County Courthouse as Judge Peter Cahill uttered the word "guilty" three times.

## Troy Carter wins Louisiana special election runoff, CNN projects
 - [https://www.cnn.com/2021/04/24/politics/louisiana-2nd-district-special-election/index.html](https://www.cnn.com/2021/04/24/politics/louisiana-2nd-district-special-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 03:04:24+00:00

Democratic state Sen. Troy Carter will win the special election runoff in Louisiana's 2nd Congressional District, CNN projects.

## Late rapper DMX honored in memorial attended by family and friends in Brooklyn
 - [https://www.cnn.com/2021/04/24/entertainment/rapper-dmx-memorial/index.html](https://www.cnn.com/2021/04/24/entertainment/rapper-dmx-memorial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 02:49:29+00:00

The late rapper DMX was honored at a "Celebration of Life Memorial" in Brooklyn on Saturday in a tribute attended by his fiancée, children and his Ruff Ryders Entertainment collaborators.

## Missing Indonesian submarine believed sunk as debris is found, navy says
 - [https://www.cnn.com/2021/04/23/asia/indonesia-submarine-intl-hnk/index.html](https://www.cnn.com/2021/04/23/asia/indonesia-submarine-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 02:00:24+00:00

Indonesia's Navy changed the status of its missing submarine from "sub miss" to "sub sank" on Saturday, as a naval chief presented debris believed to be from the vessel at a news conference.

## Oscars 2021: Where to watch the best picture nominees
 - [https://www.cnn.com/collections/intl-oscars-0425/](https://www.cnn.com/collections/intl-oscars-0425/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-04-25 01:36:08+00:00



