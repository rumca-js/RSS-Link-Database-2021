# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Apex Legends Legacy Preview
 - [https://www.youtube.com/watch?v=Wo9CSF9Ff0w](https://www.youtube.com/watch?v=Wo9CSF9Ff0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-26 00:00:00+00:00

After going hands-on with Apex Legends Legacy, Persia, Jordan, and Max sat down to talk about Season 9's Arenas mode, new playable legend Valkyrie, Bocek Bow weapon, Olympus map changes, and more.

## Apex Legends – Legacy Gameplay Trailer
 - [https://www.youtube.com/watch?v=iol6Qs3uHs8](https://www.youtube.com/watch?v=iol6Qs3uHs8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-26 00:00:00+00:00

Check out the all new Apex Legends - Legacy Gameplay trailer showing off some of the new features, modes, and weapons coming to Apex Legends - Legacy! Apex Legends - Legacy follows season 8 of the popular battle royale title! 

#ApexLegends #Legacy

## Dying Light 2 - Developer Ask Me Anything
 - [https://www.youtube.com/watch?v=GgrR018SXbQ](https://www.youtube.com/watch?v=GgrR018SXbQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-26 00:00:00+00:00

The developers behind Dying Light 2 just released an ask me anything taking a look at all the questions from fans after the most recent Dying Light 2 update! 

Dying Light 2 is the long-awaited sequel to Dying Light and this is the first episode of the developers breaking down some of your most asked questions! 

#DyingLight2 #DyingLight #Techland

## Fortnite - Neymar Jr. Outfit Cinematic Reveal Trailer
 - [https://www.youtube.com/watch?v=4Rg2otpUf3A](https://www.youtube.com/watch?v=4Rg2otpUf3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-26 00:00:00+00:00

Check out the official Fortnite Neymar Jr. outfit cinematic reveal trailer! This marks the first official entrance of a full real-life athlete skin entering Fortnite Battle Royale! 

#Fortnite #Neymar

## Apex Legends & Titanfall Timeline Explained
 - [https://www.youtube.com/watch?v=OWaQNdqedXc](https://www.youtube.com/watch?v=OWaQNdqedXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-25 00:00:00+00:00

As the Legacy season of Apex Legends approaches, it's important to know how it intertwines with Titanfall to understand what's on the way for Respawn Entertainment's Sci-Fi universe. Join Persia as she goes into a deep dive on the connections between Apex Legend and Titanfall that occur over the course of over 700 years and major connections within the titles such as Kuben Blisk, Ash, and Viper. 

In this video, Persia goes into a deep dive on the various connections between Apex Legends and the Titanfall universe. Season 9 of Apex Legends is right around the corner and will be bridging its gap between Titanfall 2 more than ever with the introduction of Viper's daughter as the newest legend to join the Apex Games.

Persia runs through the entire timeline beginning in the 2100s and leading to the present-day in Apex which is 2735. The beginnings of this ever-expanding universe were controlled by the rise of Hammond Engineering and the IMC who become one of the biggest connections besides Kuben Blisk, the leader of the Apex Predators and the commissioner of the Apex Games.

Other notable connections that Persia mentions are Ash, the doctor or Apex Predator depending on who you're asking, and  Bangalore who has a family history within the IMC as soldiers and scientists.

Plenty more lore from Respawn Entertainment's Sci-Fi universe is on the way, so if you want to stay up to date on everything Apex and Titanfall, then be sure to leave a like and subscribe!

## Resident Evil Village | Castle Demo Gameplay (PS5)
 - [https://www.youtube.com/watch?v=JQ6mv73GTQM](https://www.youtube.com/watch?v=JQ6mv73GTQM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-04-25 00:00:00+00:00

Enjoy a look at the Castle portion of the Resident Evil Village demo, running on PS5.

