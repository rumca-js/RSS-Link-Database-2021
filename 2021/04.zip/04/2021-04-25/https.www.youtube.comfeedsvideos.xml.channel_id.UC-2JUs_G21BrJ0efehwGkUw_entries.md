# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## The Middle | Maren Morris, Zedd, Grey | funk cover ft. India Carney, Mario Jose & Kenton Chen
 - [https://www.youtube.com/watch?v=X88mSupg3Y4](https://www.youtube.com/watch?v=X88mSupg3Y4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-04-26 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Maren Morris, Zedd & Grey's "The Middle" by Scary Pockets, Kenton Chen, India Carney & Mario Jose.

MUSICIAN CREDITS
Vocal Arrangement: India Carney
Lead vocal: Kenton Chen, India Carney, Mario Jose
Drums: Kristen Gleeson-Prata
Bass: JP Maramba
Keys: Jack Conte
Guitar: Ryan Lerman
Synth, Percussion, Keys: Tyler Duncan

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Kevin Brown
Mixing/Mastering: Caleb Parker
Producer: Tyler Duncan

VIDEO CREDITS
Director: Merlin Camozzi
DP: Marc Patterson
Camera Operator: Nate Nguyen-Le
Editor: Adam Kritzberg
Tech: Joonas Cohen
PA: Rachel McGowan
Costumes: Molly Irelan

Recorded Live at Debs Park in Los Angeles, CA.

#ScaryPockets #Funk #TheMiddle #MarenMorris #Zedd #Grey #KentonChen #IndiaCarney #MarioJose

