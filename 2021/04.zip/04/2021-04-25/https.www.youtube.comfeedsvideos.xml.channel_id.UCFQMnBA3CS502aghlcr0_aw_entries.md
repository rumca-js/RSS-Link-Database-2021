# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## SafeMoon Is Insane...
 - [https://www.youtube.com/watch?v=2DLek8pa4iI](https://www.youtube.com/watch?v=2DLek8pa4iI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-04-25 00:00:00+00:00

Safemoon bills itself as "a community driven, fair launched DeFi Token." In reality, it's just another pumpamental coin built on deflationary "tokenomics" that's trying to bill itself as getting people safely to the moon. Will SafeMoon change finance and save the world? I think not. Safemoon is one of many memecoins that are structured to maximize FOMO and hype, but actually have very little use-case. DO NOT INVEST.

SOCIALS:
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

