# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## England's oldest attraction turns teddy bears to stone
 - [https://www.youtube.com/watch?v=AJ38l6DX4f8](https://www.youtube.com/watch?v=AJ38l6DX4f8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-04-26 00:00:00+00:00

In Knaresborough, in Yorkshire, sits Mother Shipton's Cave. Folks there have been charging admission for nearly 400 years, and the star of the show is a "petrifying well". A few folk legends do actually turn out to be true.

Mother Shipton's Cave: https://www.mothershipton.co.uk/ - thanks to all the team there, and especially to John!

Edited by Michelle Martin (@mrsmmartin)
Filmed safely: https://www.tomscott.com/safe/
Thanks to Jake Robshaw for the suggestion.

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

