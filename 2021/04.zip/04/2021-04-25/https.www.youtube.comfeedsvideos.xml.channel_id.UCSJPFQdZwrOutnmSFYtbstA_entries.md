# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Falcon And The Winter Soldier - It's The Best Show Ever Made
 - [https://www.youtube.com/watch?v=8e0B_7es0_g](https://www.youtube.com/watch?v=8e0B_7es0_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-04-25 00:00:00+00:00

Truly, Falcon and the Winter Soldier stunned me with its fantastic writing, great performacnes and social commentary that never felt forced or heavy handed. Join me as I explore this wonder of modern TV. 


Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

