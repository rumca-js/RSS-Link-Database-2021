# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## OnePlus Watch Review: They Settled!
 - [https://www.youtube.com/watch?v=07mIwEa3xbQ](https://www.youtube.com/watch?v=07mIwEa3xbQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-04-26 00:00:00+00:00

OnePlus Watch vs the smartwatch formula

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds​​​​ 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Watch provided by OnePlus for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

