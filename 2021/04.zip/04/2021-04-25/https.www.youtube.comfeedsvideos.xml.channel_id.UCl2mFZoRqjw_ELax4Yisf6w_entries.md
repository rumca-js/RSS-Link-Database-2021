# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Let's talk about ice cream, mcdonalds, and why it matters
 - [https://www.youtube.com/watch?v=tl34nW9c4wo](https://www.youtube.com/watch?v=tl34nW9c4wo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.wired.com/story/they-hacked-mcdonalds-ice-cream-makers-started-cold-war/
👉 https://www.youtube.com/watch?v=SrDEtSlqJC4
👉 https://www.gofundme.com/f/lets-get-right-to-repair-passed
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## NYC DOESN'T KNOW ITS OWN LAWS!
 - [https://www.youtube.com/watch?v=yi8_9WGk3Ok](https://www.youtube.com/watch?v=yi8_9WGk3Ok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
3:14 is where the call starts. NYC issued my business a fine for a violation, for breaking the law. When I called to ask how to be in compliance with the law, they couldn't answer me. Welcome to NYC!
👉 https://www.youtube.com/watch?v=965BLLWv8h8

👉 https://www.gofundme.com/f/lets-get-right-to-repair-passed
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## JOHN DEERE INSTIGATES HACKERS - GETS HACKED *AGAIN!!* 🤣
 - [https://www.youtube.com/watch?v=rB_SleNKBus](https://www.youtube.com/watch?v=rB_SleNKBus)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-04-25 00:00:00+00:00

https://tinyurl.com/rossmatrix
Check out sick codes here: https://twitter.com/sickcodes

👉 https://twitter.com/JohnDeere/status/1383925815092518918
👉 https://www.gofundme.com/f/lets-get-right-to-repair-passed
👉 https://www.youtube.com/channel/UCl2mFZoRqjw_ELax4Yisf6w
👉 https://www.youtube.com/watch?v=QSt6dgRvFig
👉 https://www.vice.com/en/article/4avy8j/bugs-allowed-hackers-to-dox-all-john-deere-owners
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

