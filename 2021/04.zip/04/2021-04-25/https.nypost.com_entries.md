## Fauci expects new CDC guidance on outdoor masks
 - [https://nypost.com/2021/04/25/fauci-expects-new-cdc-guidance-on-outdoor-masks/](https://nypost.com/2021/04/25/fauci-expects-new-cdc-guidance-on-outdoor-masks/)
 - RSS feed: https://nypost.com
 - date published: 2021-04-25 19:33:48+00:00

Fauci expects new CDC guidance on outdoor masks

## You’re no safer from COVID social distancing at 6 or 60 feet: study
 - [https://nypost.com/2021/04/25/youre-no-safer-from-covid-social-distancing-at-6-or-60-feet-study/](https://nypost.com/2021/04/25/youre-no-safer-from-covid-social-distancing-at-6-or-60-feet-study/)
 - RSS feed: https://nypost.com
 - date published: 2021-04-25 19:33:08+00:00

You’re no safer from COVID social distancing at 6 or 60 feet: study

