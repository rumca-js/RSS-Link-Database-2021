# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Nie tylko Czarnobyl - cywilne wypadki radiacyjne
 - [https://www.youtube.com/watch?v=m2RQbSCA7-I](https://www.youtube.com/watch?v=m2RQbSCA7-I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-04-26 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

35 lat temu Czarnobyl zmienił myślenie ludzi o energetyce jądrowej. Obawiam się, że w wielu przypadkach nieodwracalnie. Wiele osób nie zdaje sobie sprawy, że ryzyko incydentu radiacyjnego istnieje nawet w sytuacji, gdy nie mamy elektrowni w naszym kraju, a w historii zebrała ona wiele ofiar w cywilnych incydentach. Wszystko dlatego, że z promieniowania korzystamy niemal każdego dnia i życie bez niego nie mogłoby wyglądać tak, jak wygląda...

🎞 Moja seria o Czarnobylu sprzed 5 lat
https://www.youtube.com/watch?v=BmPry7Gr0-M
https://www.youtube.com/watch?v=RT3TSZADe3o
https://www.youtube.com/watch?v=5kCaXs-bMAU

🎞 Vlogi Krzysztofa Gonciarza ze Strefy Wykluczenia
https://www.youtube.com/watch?v=BBKTmGtVtjw
https://www.youtube.com/watch?v=FMzZFQWxZo4
https://www.youtube.com/watch?v=4v6uIWdDbfQ

🎞 Mój film o dawkach promieniowania
https://www.youtube.com/watch?v=6plZbmQHHaA

🎞 Inne wartościowe treści o Czarnobylu
https://www.youtube.com/watch?v=IGFjeox3Isw
https://www.youtube.com/watch?v=uk7kODGzqk8
https://www.youtube.com/watch?v=RXuuLht0NQI

🎞 Inne moje filmy o promieniowaniu
https://www.youtube.com/watch?v=0Z2bi2Z7uho
https://www.youtube.com/watch?v=tRrPNHMXyQI
https://www.youtube.com/watch?v=3nbM5Pno9q8
https://www.youtube.com/watch?v=2GWNxJ-wBSk

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 Wprowadzenie
2:52 Domowa robota
5:25 Przy taśmie z jedzeniem
7:07 Nieudany recykling
12:01 Medycyna gone wrong
14:12 Materiały w stanie krytycznym
15:15 Demoniczny rdzeń
20:40 Nie ta japońska elektrownia o której myślicie
23:59 Jeszcze jedna scena ze sterowni


===
#czarnobyl #promieniowanie #wypadki

