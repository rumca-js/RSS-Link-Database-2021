# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 HARDEST Skyrim Quests We All HATED
 - [https://www.youtube.com/watch?v=UiXiQjTTq34](https://www.youtube.com/watch?v=UiXiQjTTq34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-26 00:00:00+00:00

We STILL love playing Skyrim but there are some broken, awkward, and challenging quests that we absolutely hate throughout the adventure.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 8 NEW Games of May 2021
 - [https://www.youtube.com/watch?v=_kBt3yXycDo](https://www.youtube.com/watch?v=_kBt3yXycDo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-04-25 00:00:00+00:00

Looking for something to play in May? We've got you covered with this 2021 game release dates for PC, PS5, Xbox Series X|S, Nintendo Switch, PS4, and more.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#8 Subnautica: Below Zero 

Platform : PS5, XSX, PS4, XBOX ONE, Switch 

Releas Date : May 14, 2021 



#7 Famicom Detective Club 

Platform : Switch

Release Date : May 14, 2021



#6 Hood: Outlaws and Legends 

Platform : PC, PS5, XSX, PS4, XBOX ONE

Release Date : May 10, 2021



#5 Miitopia 

Platform : Switch

Release Date : May 21, 2021



#4 Mass Effect Legendary Edition

Platform : PC, PS4, XBOX ONE

Release Date : May 14,2021



#3 Monster Harvest 

Platform : PC, Switch

Release Date : May 13, 2021



#2 Biomutant 

Platform : PC, PS4, XBOX ONE

Release Date : May 25, 2021



#1 Resident Evil 8 Village            

Platform : PC, PS5, XSX, PS4, XBOX ONE, Stadia

Release Date : May 7, 2021





BONUS

Days Gone 

Platform : PC 

Release Date : May 18, 2021

