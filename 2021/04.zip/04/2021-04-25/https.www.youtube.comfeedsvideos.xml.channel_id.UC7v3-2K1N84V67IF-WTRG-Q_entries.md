# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Mortal Kombat (2021) - SPOILER Talk
 - [https://www.youtube.com/watch?v=G2nvkDuxWYY](https://www.youtube.com/watch?v=G2nvkDuxWYY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-04-25 00:00:00+00:00

Hopefully all you Mortal Kombatants have gotten the chance to see Mortal Kombat. So now, let's get into some SPOILERS!

#MortalKombat

