# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Beast of Burden | The Rolling Stones | funk cover ft. Colin Jamieson
 - [https://www.youtube.com/watch?v=lRj0rbMzm7g](https://www.youtube.com/watch?v=lRj0rbMzm7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-09-27 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of The Rolling Stones' "Beast of Burden" by Scary Pockets & Colin Jamieson.

MUSICIAN CREDITS
Lead vocal: Colin Jamieson
Drums: Tamir Barzilay
Bass: Sean Hurley
Guitar: Eric Krasno
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Hannah Kacmarsky
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Ricky Chavez 
Editor: Adam Kritzberg

Recorded Live at East West in Los Angeles, CA.

#ScaryPockets #Funk #TheRollingStones #ColinJamieson #BeastOfBurden

