# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The world's most useful model railway
 - [https://www.youtube.com/watch?v=6TLcaJdsRr0](https://www.youtube.com/watch?v=6TLcaJdsRr0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-09-27 00:00:00+00:00

In Darmstadt, Germany, there's the Eisenbahnbetriebsfeld: a model railway connected to actual railway signalling equipment, so that controllers can learn without putting any real trains in danger. I got to learn the very basics. ■ More about the railway (in German): https://www.eisenbahnbetriebsfeld.de/

Camera: Moritz Janisch
Producer: Marcel Fenchel https://www.fenchel-janisch.de
Editor: Isla McTear

With thanks to Deutsche Bahn and DB Training, AKA Bahn, the Institut für Bahnsysteme und Bahntechnik at TU Darmstadt, and all the team at the Eisenbahnbetriebsfeld!

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

