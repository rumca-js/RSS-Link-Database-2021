# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Barbers in Afghan province now prohibited from shaving beards and playing music
 - [https://www.cnn.com/2021/09/26/world/taliban-afghanistan-beards-music-intl/index.html](https://www.cnn.com/2021/09/26/world/taliban-afghanistan-beards-music-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 23:06:45+00:00

Barbers in Afghanistan's Helmand Province are now prohibited from shaving men's beards and playing music in their shops, according to a statement issued by the province's Taliban-led department of virtue and vice.

## 'Significant development' in Sabina Nessa murder investigation
 - [https://www.cnn.com/2021/09/26/uk/sabina-nessa-suspect-arrest-intl-gbr/index.html](https://www.cnn.com/2021/09/26/uk/sabina-nessa-suspect-arrest-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 22:48:21+00:00

The arrest of a man in connection with the murder of teacher Sabina Nessa is a "significant development" in the case, London's Metropolitan Police said on Sunday.

## Iceland won't have female-majority Parliament after all, recount shows
 - [https://www.cnn.com/2021/09/26/europe/iceland-women-majority-parliament-intl/index.html](https://www.cnn.com/2021/09/26/europe/iceland-women-majority-parliament-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 22:42:07+00:00

Iceland has voted more women than men into its parliament, a first in Europe, in a national election that saw the ruling left-right coalition strengthen its majority, final results showed on Sunday.

## US makes Ryder Cup history
 - [https://www.cnn.com/2021/09/26/golf/ryder-cup-2021-results-us-win-spt-intl/index.html](https://www.cnn.com/2021/09/26/golf/ryder-cup-2021-results-us-win-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 22:26:24+00:00

Team US regained the Ryder Cup on Sunday following a dominant performance over Europe at Whistling Straits.

## The story of 'probably the worst drug approval decision in recent US history'
 - [https://www.cnn.com/2021/09/26/politics/alzheimers-drug-aduhelm-fda-approval/index.html](https://www.cnn.com/2021/09/26/politics/alzheimers-drug-aduhelm-fda-approval/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 22:00:14+00:00



## Substack's CEO wants writers to publish what they want — even if it's wrong
 - [https://www.cnn.com/2021/09/26/media/substack-ceo-reliable-sources/index.html](https://www.cnn.com/2021/09/26/media/substack-ceo-reliable-sources/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 21:45:05+00:00

Substack has taken advantage of a new model for the internet, where subscriptions for content are increasingly becoming the norm. The website is the current king of paid newsletters, where writers publish directly to subscribers without the standards of newsroom editors.

## Center-left SPD has slight lead in Germany: exit poll
 - [https://www.cnn.com/2021/09/26/europe/germany-election-results-polls-2021-grm-intl/index.html](https://www.cnn.com/2021/09/26/europe/germany-election-results-polls-2021-grm-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 21:42:55+00:00

• What happens if Germany shifts left?
• The world's crisis manager is stepping down

## Trump went all-out to win farmer support. Now they're all in on Biden's infrastructure plan
 - [https://www.cnn.com/2021/09/26/politics/infrastructure-bill-republican-support-farmers/index.html](https://www.cnn.com/2021/09/26/politics/infrastructure-bill-republican-support-farmers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 20:50:38+00:00

Former President Donald Trump sent billions in federal aid in a bid to win over America's farmers -- but now they're all for President Joe Biden's $1.2 trillion infrastructure package, in hopes it will mean fixing roads and bridges critical to the delivery of food to the rest of the nation.

## What we were not allowed to see at R. Kelly's trial
 - [https://www.cnn.com/2021/09/26/us/r-kelly-trial-public-not-allowed-to-see/index.html](https://www.cnn.com/2021/09/26/us/r-kelly-trial-public-not-allowed-to-see/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 20:44:51+00:00

Before the federal trial for R. Kelly even began, it has been shrouded in secrecy, with journalists and the public barred from the courtroom where prosecutors laid out their racketeering case against the singer -- charges that could send him to prison for decades.

## What we know about Gabby Petito's final days
 - [https://www.cnn.com/2021/09/26/us/what-we-know-gabby-petito-final-days/index.html](https://www.cnn.com/2021/09/26/us/what-we-know-gabby-petito-final-days/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 20:24:57+00:00

Over the summer, Gabby Petito set out with her fiancé, Brian Laundrie, to travel across the country in her white Ford van, planning to hit national parks throughout the western United States.

## Russia: Mali plans to hire our mercenaries
 - [https://www.cnn.com/2021/09/26/world/mali-russian-mercenaries-intl/index.html](https://www.cnn.com/2021/09/26/world/mali-russian-mercenaries-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 19:33:30+00:00

Mali plans to hire private Russian mercenaries to assist with security in the country, Russian Foreign Minister Sergey Lavrov said Saturday.

## Mother and toddler fall to their deaths at baseball stadium, police say
 - [https://www.cnn.com/2021/09/26/us/petco-park-fall-mother/index.html](https://www.cnn.com/2021/09/26/us/petco-park-fall-mother/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 19:21:15+00:00

A mother and her young son fell to their deaths at Petco Park, the home of the San Diego Padres baseball team, minutes before a game Saturday afternoon, according to a news release from the San Diego Police Department.

## At least three dead in Amtrak derailment in Montana
 - [https://www.cnn.com/2021/09/25/us/amtrak-train-derailed-montana/index.html](https://www.cnn.com/2021/09/25/us/amtrak-train-derailed-montana/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 19:04:22+00:00

Three people are dead after an Amtrak train derailed in Montana on Saturday afternoon, the Liberty County Sheriff's office said in a statement to CNN.

## Swiss overwhelmingly vote to legalize same-sex marriage
 - [https://www.cnn.com/2021/09/26/europe/switzerland-same-sex-marriage-referendum-intl/index.html](https://www.cnn.com/2021/09/26/europe/switzerland-same-sex-marriage-referendum-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 18:47:50+00:00

Voters in Switzerland, one of the last Western European countries that still bans gay marriage, will decide in a referendum on Sunday whether to allow same-sex couples to get married and adopt children.

## Vanuatu will seek International Court of Justice opinion on climate protection
 - [https://www.cnn.com/2021/09/26/asia/vanuatu-climate-change-protection-rights-intl/index.html](https://www.cnn.com/2021/09/26/asia/vanuatu-climate-change-protection-rights-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 18:43:27+00:00

The Pacific island nation of Vanuatu wants the International Court of Justice (ICJ) to weigh in the rights of current and future residents to be protected from climate change.

## See what's happening to Afghan refugees arriving in the UK
 - [https://www.cnn.com/videos/world/2021/09/26/afghan-refugees-britain-nada-bashir-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/09/26/afghan-refugees-britain-nada-bashir-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 18:13:29+00:00

After fleeing the Taliban takeover in Afghanistan, some refugees are seeking a new life in the UK. CNN's Nada Bashir reports.

## Tapper calls out McEnany for blaming Biden for murder rate under Trump
 - [https://www.cnn.com/videos/politics/2021/09/26/tapper-kayleigh-mcenany-biden-murder-rate-tweet-sotu-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/09/26/tapper-kayleigh-mcenany-biden-murder-rate-tweet-sotu-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 17:31:14+00:00

CNN's Jake Tapper says former Trump White House Press secretary Kayleigh McEnany's tweet blaming President Joe Biden for a murder rate that occurred during the Trump administration is an example of partisans on both sides of the aisle who use upsetting news to launch political attacks.

## These tiny homes offer LA's homeless a new lease on life
 - [https://www.cnn.com/2021/09/26/us/homeless-tiny-home-villages-los-angeles/index.html](https://www.cnn.com/2021/09/26/us/homeless-tiny-home-villages-los-angeles/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 17:28:44+00:00

Jolinn Bracey slept in her Toyota Corolla for five years until she put homelessness in her rearview mirror by moving into a tiny home.

## Lewis Hamilton claims historic F1 victory
 - [https://www.cnn.com/2021/09/26/motorsport/lewis-hamilton-100-win-russian-gp-spt-intl/index.html](https://www.cnn.com/2021/09/26/motorsport/lewis-hamilton-100-win-russian-gp-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 16:48:58+00:00

Lewis Hamilton became the first Formula 1 driver ever to reach 100 wins after he finished first at a drama-packed Russian Grand Prix on Sunday.

## Exit polls show tight race to replace Merkel as voting ends in German election
 - [https://www.cnn.com/collections/intl-germany-election-092621/](https://www.cnn.com/collections/intl-germany-election-092621/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 16:44:53+00:00



## Russian jets escort US bomber after it reportedly approached Russian airspace
 - [https://www.cnn.com/2021/09/26/politics/russian-fighter-jets-escorted-us-air-force-bombers/index.html](https://www.cnn.com/2021/09/26/politics/russian-fighter-jets-escorted-us-air-force-bombers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 16:33:43+00:00

Russian fighter jets were scrambled to escort a US Air Force plane that reportedly approached Russian airspace over the Pacific Ocean, Russian state news agency TASS said Sunday.

## See inside SPD headquarters after exit poll
 - [https://www.cnn.com/videos/world/2021/09/26/germany-election-exit-poll-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/09/26/germany-election-exit-poll-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 16:26:27+00:00

CNN's Salma Abdelaziz reports from the SPD headquarters after a Forschungsgruppe Wahlen exit poll shown on CNN affiliate n-tv suggests the SPD has narrowly come out on top in the German elections, at 26%. Second is the CDU at 24%, followed by the Greens at 14.5%, the FDP at 12% and the AfD at 10%.

## The roots of the Murdaugh family crime saga run deep through these US towns. But no one wants to talk about it
 - [https://www.cnn.com/2021/09/26/us/murdaugh-family-murders-deaths/index.html](https://www.cnn.com/2021/09/26/us/murdaugh-family-murders-deaths/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 15:54:47+00:00

The store clerk asked, "Can I help you?" But it sounded more like, "What the hell are you doing here?"

## Fareed Zakaria: 'The complexity of the China challenge'
 - [https://www.cnn.com/videos/tv/2021/09/26/gps-0926-fareeds-take.cnn](https://www.cnn.com/videos/tv/2021/09/26/gps-0926-fareeds-take.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 15:41:41+00:00

In the wake of the creation of the US-UK-Australia security pact, Fareed gives his take on the challenges ahead for America's "pivot to Asia."

## Rep. Jayapal recounts emotional Oval Office moment
 - [https://www.cnn.com/videos/politics/2021/09/26/rep-pramila-jayapal-immigration-oval-office-biden-moment-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2021/09/26/rep-pramila-jayapal-immigration-oval-office-biden-moment-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 14:16:47+00:00

Rep. Pramila Jayapal speaks to CNN's Jake Tapper about the emotional Oval Office moment she shared with President Joe Biden.

## Can Europe power the recovery as US and China stumble?
 - [https://www.cnn.com/2021/09/26/investing/stocks-week-ahead/index.html](https://www.cnn.com/2021/09/26/investing/stocks-week-ahead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 14:15:43+00:00

The United States and China have each taken turns powering the global economic recovery from the pandemic. Is Europe next?

## Rivian is no Tesla. That's exactly what these buyers want
 - [https://www.cnn.com/2021/09/26/cars/rivian-tesla-comparison/index.html](https://www.cnn.com/2021/09/26/cars/rivian-tesla-comparison/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 13:46:51+00:00

Today Tesla dominates the world of electric vehicles, selling about two of every three EVs sold in the US. It's worth more than twice as much as any other automaker. Teslas are a status symbol and its CEO, Elon Musk, is a celebrity, with 59 million more Twitter followers than the next most popular automotive CEO.

## Trump suggests Stacey Abrams might make better governor than Kemp at rally
 - [https://www.cnn.com/videos/politics/2021/09/26/trump-stacey-abrams-kemp-georgia-governor-rally-sot-analysis-bts-ip-vpx.cnn](https://www.cnn.com/videos/politics/2021/09/26/trump-stacey-abrams-kemp-georgia-governor-rally-sot-analysis-bts-ip-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 13:36:58+00:00

At a rally in Perry, Georgia, former President Donald Trump suggested that Democrat Stacey Abrams would make a better governor than Republican Gov. Brian Kemp who defeated Abrams in the state's 2018 gubernatorial election and refused to interfere in the 2020 presidential election.

## Paris Fashion Week 2021: How to watch the Spring-Summer 2022 shows
 - [https://www.cnn.com/style/article/paris-fashion-week-2021-how-to-watch-spring-summer-2022-shows/index.html](https://www.cnn.com/style/article/paris-fashion-week-2021-how-to-watch-spring-summer-2022-shows/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 13:26:09+00:00

From September 27 to October 5, the streets of Paris will once again come alive with models, designers and editors as fashion week prepares to take over the capital. There are more than 100 brands on the official Paris Fashion Week schedule -- and while only around a third of designers are planning in-person shows, the event already stands in stark contrast to last season's entirely digital program.

## The roots of QAnon run deeper than you may think
 - [https://www.cnn.com/videos/business/2021/09/23/qanon-roots-reality-check-orig.cnn-business](https://www.cnn.com/videos/business/2021/09/23/qanon-roots-reality-check-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 11:38:53+00:00

The roots of QAnon tap into centuries-old conspiracy theories with echoes of anti-Semitic and anti-Catholic bigotry. In the latest "Reality Check with John Avlon: Extremist Beat," Avlon traces how far back these false beliefs go and explores the present-day implications with CNN's Donie O'Sullivan.

## UK makes biggest post-Brexit U-turn
 - [https://www.cnn.com/2021/09/26/business/uk-workers-foreign-visas-intl/index.html](https://www.cnn.com/2021/09/26/business/uk-workers-foreign-visas-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 10:03:04+00:00

Up to 10,500 lorry drivers and poultry workers are to be offered temporary UK visas in an attempt to avoid supply chain disruptions ahead of Christmas, the government has said in a statement.

## Climate change is intensifying the US border crisis. It will only get worse
 - [https://www.cnn.com/2021/09/26/us/climate-change-migration-border-haiti/index.html](https://www.cnn.com/2021/09/26/us/climate-change-migration-border-haiti/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 08:02:25+00:00

In the face of political turmoil following the assassination of the country's president, a 7.2-magnitude earthquake that killed more than 1,000 people and a tropical storm, Haitians are fleeing their country.

## Australian state records second-highest daily rise in virus cases
 - [https://www.cnn.com/2021/09/26/australia/australia-victoria-covid-intl-hnk/index.html](https://www.cnn.com/2021/09/26/australia/australia-victoria-covid-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 05:08:59+00:00

Australia's Victoria state reported 779 new COVID-19 infections and two deaths on Sunday, a decrease from the previous day's record high as the country's Prime Minister presses state leaders to be ready to reopen once they meet vaccination targets.

## The 74-year-old who dated her lovers, poisoned them with cyanide, and then inherited their money
 - [https://www.cnn.com/2021/09/25/asia/japan-black-widow-killer-intl-hnk-dst/index.html](https://www.cnn.com/2021/09/25/asia/japan-black-widow-killer-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 00:49:16+00:00

At 75, Isao Kakehi was in good health and in love.

## Team US on the brink of regaining Ryder Cup behind Dustin Johnson excellence
 - [https://www.cnn.com/collections/rider-cup-0926-intl-app/](https://www.cnn.com/collections/rider-cup-0926-intl-app/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-26 00:20:57+00:00



