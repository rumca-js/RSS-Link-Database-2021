## Labour conference: Not right to say only women have a cervix, says Starmer - BBC News
 - [https://www.bbc.co.uk/news/uk-politics-58698406](https://www.bbc.co.uk/news/uk-politics-58698406)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-09-26 20:10:45.850037+00:00

The Labour leader calls for "mature, respectful debate" over trans rights after MP's comments.

