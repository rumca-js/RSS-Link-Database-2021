# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Heavy Industry In Space - A Great Idea Or A Pipe Dream? | Answers With Joe
 - [https://www.youtube.com/watch?v=tY6aCg5InzY](https://www.youtube.com/watch?v=tY6aCg5InzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-09-27 00:00:00+00:00

Get 20% of a premium subscription to Brilliant when you're one of the first 200 people to sign up at http://www.brilliant.org/answerswithjoe
Blue Origin has stated their long-term goal is to move all heavy, polluting industry to space. But what would that look like? How could we get there? And maybe the biggest question... why?

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.independent.co.uk/climate-change/news/bezos-space-heavy-industry-pollution-b1888147.html

https://apnews.com/article/jeff-bezos-space-e0afeaa813ff0bdf23c37fe16fd34265

https://www.planetary.org/space-policy/cost-of-perseverance

https://phys.org/news/2021-09-nasa-perseverance-mars-rover-piece.html

https://en.wikipedia.org/wiki/OSIRIS-REx

https://en.wikipedia.org/wiki/Sample-return_mission

https://en.wikipedia.org/wiki/Hayabusa2

https://en.wikipedia.org/wiki/Chang%27e_5

https://spacenews.com/nasa-and-esa-outline-cost-of-mars-sample-return/

https://www.airbus.com/newsroom/press-releases/en/2021/06/earth-return-orbiters-first-step-to-mars.html

https://metro.co.uk/2019/06/27/gigantic-golden-asteroid-make-everyone-earth-billionaire-10075724/ 

https://www.forbes.com/sites/bridaineparnell/2017/05/26/nasa-psyche-mission-fast-tracked/?sh=5bdefac54ae8 

https://www.wired.com/story/nasas-moxie-experiment-is-making-oxygen-on-mars/

https://www.space.com/water-rich-asteroids-space-exploration-fuel.html, 

https://www.space.com/how-much-water-in-asteroids.html, 

https://www.forbes.com/sites/alexknapp/2014/11/26/the-first-object-has-been-3d-printed-in-space/?sh=58b452a32421

https://manufactur3dmag.com/redwires-ceramic-manufacturing-module-successfully-3d-prints-turbine-blisk-in-space/ 

https://www.northropgrumman.com/space/nasa-commercial-resupply-mission-ng-16/

https://madeinspace.us/capabilities-and-technology/archinaut/

https://spectrum.ieee.org/solar-power-from-space-caltechs-100-million-gambit

https://spectrum.ieee.org/engineers-and-architects-are-already-designing-lunar-habitats

https://www.bbc.com/future/article/20210601-how-transplant-organs-might-be-printed-in-outer-space

https://www.theguardian.com/science/2019/may/12/protect-solar-system-space-mining-gold-rush-say-scientists

