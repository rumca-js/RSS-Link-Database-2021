## Scotland becomes first country in world to embed LGBT education in school curriculum | The Scotsman
 - [https://www.scotsman.com/news/politics/scotland-becomes-first-country-in-world-to-embed-lgbt-education-in-school-curriculum-3393389](https://www.scotsman.com/news/politics/scotland-becomes-first-country-in-world-to-embed-lgbt-education-in-school-curriculum-3393389)
 - RSS feed: https://www.scotsman.com
 - date published: 2021-09-26 14:32:49.753330+00:00

Scotland has become the first country in the world to embed lesbian, gay, bisexual and transgender inclusive education across the school curriculum.

