# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The Evil Economics of OnlyFans
 - [https://www.youtube.com/watch?v=KUu9n6ASoEE](https://www.youtube.com/watch?v=KUu9n6ASoEE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2021-09-26 00:00:00+00:00

Grab AtlasVPN for 1.39$/mo before the deal expires! https://atlasv.pn/Moon

UNCENSORED VERSION : https://www.patreon.com/MoonReal
The title of this video Is a rip off of the great Ordinary Things video called The Evil Economics of Tinder. Check out his channel

PLEASE READ: You will notice that I've had to beep out words throughout the video. I was forced into doing this as this video was repeatedly age-restricted for saying sexual words etc. I hope it's not too annoying for you, but it's the only way I could release this video.

SECONDLY: There is an issue with the sound effect at Part 4. I only realized when I'd uploaded it to YouTube so by that point I decided to keep in the mistake. Apologies!

OnlyFans is an evil business. Onlyfans is wrong and is a waste of money. And not for the reasons you may think...

The business of Onlyfans capitalizes on loneliness and economic desperation because young people no longer have relationships or money. Which is why Onlyfans is wrong and ruining society. Onlyfans is a business that makes from simps and poor women. Onlyfans' economic sucess is a consequence of this. Because lonely simps pay onlyfans all their money, it makes Onlyfans bad for generation z. Don't be a lonelyfan. 

CLIPS USED

- Interview clips / Onlyfans logo taken from Glink: https://www.youtube.com/watch?v=djMojvschs0&t=183s
- Clip of Wojak taken from Prince of Zimbabwe: https://www.youtube.com/watch?v=NJW_av0PQXM
- Clip of SIMP taken from Dustin O'Daffer: https://www.youtube.com/watch?v=jyMvQEOtGPc


Support the channel here (all funds go back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

00:00 Why Is OnlyFans Bad?
04:12 AtlasVPN
05:21 Part 1: The Origins
11:45 Part 2: LonelyFans
19:25 Part 3: The Other Side
24:49 Part 4: The Cause

