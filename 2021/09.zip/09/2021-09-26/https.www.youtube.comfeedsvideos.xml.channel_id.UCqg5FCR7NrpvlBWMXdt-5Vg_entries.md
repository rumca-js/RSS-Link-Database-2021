# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Why Sea of Thieves Is Designed for Simplicity
 - [https://www.youtube.com/watch?v=iK4o3PrMrRk](https://www.youtube.com/watch?v=iK4o3PrMrRk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-27 00:00:00+00:00

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Welcome to The Anatomy of Sea of Thieves.

In this episode, we take a look at how Rare created one of the most perplexingly addictive games J has ever seen and the game design techniques that actually make this possible.

If you want to see more game design content a new Anatomy episode will release every other week, or you can subscribe to JM8s personal channel for similar content: 
https://www.youtube.com/c/JM8GameDesign

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps:
Introduction - 00:00
Overview - 00:25
Sea of Simplicity - 00:55
Daring Diegesis - 02:25
Nautical Ludo Narrative  - 05:00
Currency & Cosmetic Conundrum - 07:50
Final Thoughts - 10:55

---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## 'What If...Killmonger Rescued Tony Stark & Thor Were An Only Child?' Discussion | A Marvelous Escape
 - [https://www.youtube.com/watch?v=W33ia6WjKZE](https://www.youtube.com/watch?v=W33ia6WjKZE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-26 00:00:00+00:00

A Marvelous Escape returns this week with Darren, Amy and KC discussing the last two episodes of What If...?.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Sable | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=n4njwUQm5v0](https://www.youtube.com/watch?v=n4njwUQm5v0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-26 00:00:00+00:00

Will Cruz reviews Sable, developed by Shedworks.

Sable on Steam: https://store.steampowered.com/app/757310/Sable/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

