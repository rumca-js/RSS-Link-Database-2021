## A terminal case of Linux
 - [https://fasterthanli.me/articles/a-terminal-case-of-linux](https://fasterthanli.me/articles/a-terminal-case-of-linux)
 - RSS feed: https://fasterthanli.me
 - date published: 2021-09-26 11:37:47.597340+00:00

Has this ever happened to  you ? You want to look at a JSON file in your terminal, so you pipe it into  jq  so you can look at it with colors and stuff.                         ...

