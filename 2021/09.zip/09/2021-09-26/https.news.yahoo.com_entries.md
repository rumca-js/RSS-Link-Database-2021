## Kidnapping, assassination and a London shoot-out: Inside the CIA's secret war plans against WikiLeaks
 - [https://news.yahoo.com/kidnapping-assassination-and-a-london-shoot-out-inside-the-ci-as-secret-war-plans-against-wiki-leaks-090057786.html](https://news.yahoo.com/kidnapping-assassination-and-a-london-shoot-out-inside-the-ci-as-secret-war-plans-against-wiki-leaks-090057786.html)
 - RSS feed: https://news.yahoo.com
 - date published: 2021-09-26 21:27:39+00:00

Kidnapping, assassination and a London shoot-out: Inside the CIA's secret war plans against WikiLeaks

