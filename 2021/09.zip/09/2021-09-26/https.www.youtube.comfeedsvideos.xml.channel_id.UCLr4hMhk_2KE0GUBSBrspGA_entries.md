# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Xiaomi lepsze w cenzurę? Tech Week - ładowarka Sjömärke Ikea, Microsoft, Samsung S22 Ultra
 - [https://www.youtube.com/watch?v=B6xwXgIguKo](https://www.youtube.com/watch?v=B6xwXgIguKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-09-26 00:00:00+00:00

Kto kogo chce ograniczać i jak zrobić ładowarkę ze stołu?
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Wstęp
00:35 Dobry wieczór
00:39 Cenzura na smartfonach Xiaomi
04:07 Ładowarka bezprzewodowa ze stołu
04:57 Nowości od Microsoft
08:33 Standaryzacja portu USB C
09:17 Samsung Galaxy S22
09:43 Wystawa dzieł
10:25 Pożegnanko
10:48 Znośnego tygodnia!


Źródła: 
Litewski minister obrony: wyrzućcie Xiaomi! https://reut.rs/3AIGiiv
Litewski raport: https://bit.ly/3lY8mYV
Xiaomi odpowiada: https://reut.rs/3udkUPS
Bezprzewodowa ładowarka "podstołowa" IKEI: https://bit.ly/3ALrP5d
Nowości od Microsoftu w skrócie: https://bit.ly/2XVMNjY
Wszystkie smartfony na USB-C! https://politi.co/3zJAaFs
Samsung S22 Ultra przecieki: https://bit.ly/3lZhpZM

