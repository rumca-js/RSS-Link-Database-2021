# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 25 FREE Single Player Games of All Time
 - [https://www.youtube.com/watch?v=8BzXEVOL3mo](https://www.youtube.com/watch?v=8BzXEVOL3mo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-27 00:00:00+00:00

Looking for a free singleplayer game that doesn't suck? We've got you covered with this free to download games with minimal or zero microtransactions.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 INTRO
0:11 Cloud Climber 
0:45 UNDEFEATED
1:21 Path of Exile
2:05 Deltarune Chapters 1 and 2
2:59 Genshin Impact
3:52 Dr. Langeskov, The Tiger, and The Terribly Cursed Emerald: A WhirlWind Heist
4:34 Helltaker
5:06 Cry of Fear
5:37 Zero-k
6:19 Barkley: Shut up and Jam Gaiden
7:04 Shrine 2
7:35 Himno
8:10 Matilda Castilla
8:51 No One Lives Forever 1 and 2
9:35 If on a Winter's Night, Four travelers
10:04 Doki Doki Literature Club
10:40 Space Funeral
11:09 Loria
11:41 Sonic Robo Blast 2
12:24 Spelunky Classic
13:02 Teenage Mutant Ninja Turtles: Rescue-palooza
13:34 La Mulana
14:19 The Dark Mod
14:59 Another Metroid 2 Remake AKA AM2R
15:39 Cave Story

## 5 WORST Cash Grab Attempts By ROCKSTAR GAMES
 - [https://www.youtube.com/watch?v=K1XGkvpiyvw](https://www.youtube.com/watch?v=K1XGkvpiyvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-26 00:00:00+00:00

Rockstar has given us some great games, but even the better companies make the wrong moves sometimes.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

