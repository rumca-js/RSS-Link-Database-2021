# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## How to avoid destroying your Macbook when replacing the screen
 - [https://www.youtube.com/watch?v=JNvuEPZhYC0](https://www.youtube.com/watch?v=JNvuEPZhYC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-27 00:00:00+00:00

🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 TOOLS USED:
✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station with bent nozzles: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl

✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Discord: https://tinyurl.com/rossmatrix

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Apple DISABLES FaceID if you change the screen yourself - EVEN WITH AN OEM SCREEN!
 - [https://www.youtube.com/watch?v=c7P7Ytl7DGM](https://www.youtube.com/watch?v=c7P7Ytl7DGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 phonerepairguru video: https://www.youtube.com/watch?v=LgU5G41-c2g
👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

00:00 - start
00:02 - kittens
00:17 - iPhone 13 anti repair introduction
00:27 - What is FaceID?
00:39 - How did it work before?
01:20 - What changed? 
01:29 - Why is this a problem?
01:39 - How this affects independent repair
03:09 - This happened last year
03:35 - The propaganda we should expect
04:02 - Why not become authorized?
04:25 - Why being authorized/IRP is NOT an option
06:28 - Props to phonerepairguru
06:40 - The fallacy of "just don't buy Apple"

## How to tell you've entered New York State
 - [https://www.youtube.com/watch?v=v-EnJs6VkIc](https://www.youtube.com/watch?v=v-EnJs6VkIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
DJI Osmo Action camera: https://bit.ly/djiosmoaction4k

## Job ad for charity workshop instructor
 - [https://www.youtube.com/watch?v=vOq5xGs4VNA](https://www.youtube.com/watch?v=vOq5xGs4VNA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
here is what one of these workshops is like. You would be me. https://youtu.be/Vam93hQ6_nQ email louis@fighttorepair.org if qualified & interested. 

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## NYC nightlife is BACK - Saturday night bike tour, NY is not dead
 - [https://www.youtube.com/watch?v=h6FApKtVh6c](https://www.youtube.com/watch?v=h6FApKtVh6c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
NYC nightlife appears to have come back. There are lines around the block to enter run of the mill restaurants & bars.

00:00 - start
15:58 - some nice garbage
16:26 - cool car
16:54 a giant line on the street 
41:00 - line around a bar
41:55 - street crowding
43:25 traffic from a car doing something dumb

## NYC throws away food from unlicensed street vendor; let's dig into it
 - [https://www.youtube.com/watch?v=MrB0B2QZ8LU](https://www.youtube.com/watch?v=MrB0B2QZ8LU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.reddit.com/r/LateStageCapitalism/comments/pva5di/nyc_sanitation_trashing_an_entire_stall_of_fresh/
🔵 https://youtu.be/yi8_9WGk3Ok
🔵 https://youtu.be/3SE4B6K7odU
🔵 https://youtu.be/965BLLWv8h8
🔵 https://www.reddit.com/r/nyc/comments/pv9uq5/nyc_sanitation_trashing_an_entire_stall_of_fresh/he97tvx/
https://www.reddit.com/r/LateStageCapitalism/comments/pva5di/nyc_sanitation_trashing_an_entire_stall_of_fresh/
🔵 https://youtu.be/hz8csg8KxDc

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

00:00 - Introduction
00:32 - Video of event
02:37 - Licensing in NYC
03:10 - Takes 4 month for license to be mailed
03:30 - City is incompetent when it comes to licensing
04:13 - NYC's breply to citizens seeking licensing information
05:05 - Why not just get a license? 
07:10 - Private waste

## Vaccine mandates, racism & uprisings, courtesy of NYC Mayor Bill DeBlasio
 - [https://www.youtube.com/watch?v=6cIvBWBbf4w](https://www.youtube.com/watch?v=6cIvBWBbf4w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://finance.yahoo.com/news/blm-organizer-says-blasio-vaccine-205300935.html

https://youtu.be/3roD8cKdJlY

