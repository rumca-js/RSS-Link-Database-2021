# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Fresh prints: Clash bright colours and bold patterns – in pictures
 - [https://www.theguardian.com/fashion/gallery/2021/sep/26/fresh-prints-clash-bright-colours-and-bold-patterns-in-pictures](https://www.theguardian.com/fashion/gallery/2021/sep/26/fresh-prints-clash-bright-colours-and-bold-patterns-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-09-26 06:00:04+00:00

<p>Mix Arts and Crafts inspired prints with vintage finds for a winning combination</p> <a href="https://www.theguardian.com/fashion/gallery/2021/sep/26/fresh-prints-clash-bright-colours-and-bold-patterns-in-pictures">Continue reading...</a>

