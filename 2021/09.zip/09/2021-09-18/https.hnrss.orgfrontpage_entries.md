# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Norway is wealthy because of oil. Can it give up fossil fuels?
 - [https://www.csmonitor.com/World/Europe/2021/0913/Norway-is-wealthy-because-of-oil.-Can-it-give-up-fossil-fuels](https://www.csmonitor.com/World/Europe/2021/0913/Norway-is-wealthy-because-of-oil.-Can-it-give-up-fossil-fuels)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 14:38:35+00:00

<p>Article URL: <a href="https://www.csmonitor.com/World/Europe/2021/0913/Norway-is-wealthy-because-of-oil.-Can-it-give-up-fossil-fuels">https://www.csmonitor.com/World/Europe/2021/0913/Norway-is-wealthy-because-of-oil.-Can-it-give-up-fossil-fuels</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28576597">https://news.ycombinator.com/item?id=28576597</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## A collection of modern games for the TI-99/4A
 - [http://tigameshelf.net/asm.htm](http://tigameshelf.net/asm.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 14:37:03+00:00

<p>Article URL: <a href="http://tigameshelf.net/asm.htm">http://tigameshelf.net/asm.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28576589">https://news.ycombinator.com/item?id=28576589</a></p>
<p>Points: 23</p>
<p># Comments: 1</p>

## Gimp 2.10.28 Released
 - [https://www.gimp.org/news/2021/09/18/gimp-2-10-28-released/](https://www.gimp.org/news/2021/09/18/gimp-2-10-28-released/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 14:33:42+00:00

<p>Article URL: <a href="https://www.gimp.org/news/2021/09/18/gimp-2-10-28-released/">https://www.gimp.org/news/2021/09/18/gimp-2-10-28-released/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28576564">https://news.ycombinator.com/item?id=28576564</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Ireland raises privacy question over Facebook smart glasses
 - [https://www.reuters.com/technology/ireland-raises-privacy-question-over-facebook-smart-glasses-2021-09-17/](https://www.reuters.com/technology/ireland-raises-privacy-question-over-facebook-smart-glasses-2021-09-17/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 14:09:55+00:00

<p>Article URL: <a href="https://www.reuters.com/technology/ireland-raises-privacy-question-over-facebook-smart-glasses-2021-09-17/">https://www.reuters.com/technology/ireland-raises-privacy-question-over-facebook-smart-glasses-2021-09-17/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28576406">https://news.ycombinator.com/item?id=28576406</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## TrackerZapper Mac app silently removes tracking parameters from links you copy
 - [https://github.com/rknightuk/TrackerZapper](https://github.com/rknightuk/TrackerZapper)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 13:35:03+00:00

<p>Article URL: <a href="https://github.com/rknightuk/TrackerZapper">https://github.com/rknightuk/TrackerZapper</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28576147">https://news.ycombinator.com/item?id=28576147</a></p>
<p>Points: 26</p>
<p># Comments: 2</p>

## WAGI: WebAssembly Gateway Interface
 - [https://github.com/deislabs/wagi](https://github.com/deislabs/wagi)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 13:25:52+00:00

<p>Article URL: <a href="https://github.com/deislabs/wagi">https://github.com/deislabs/wagi</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28576090">https://news.ycombinator.com/item?id=28576090</a></p>
<p>Points: 33</p>
<p># Comments: 11</p>

## Alexa leaks private wishlists
 - [https://shkspr.mobi/blog/2021/09/alexa-leaks-your-private-wishlists/](https://shkspr.mobi/blog/2021/09/alexa-leaks-your-private-wishlists/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 12:56:38+00:00

<p>Article URL: <a href="https://shkspr.mobi/blog/2021/09/alexa-leaks-your-private-wishlists/">https://shkspr.mobi/blog/2021/09/alexa-leaks-your-private-wishlists/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575855">https://news.ycombinator.com/item?id=28575855</a></p>
<p>Points: 101</p>
<p># Comments: 61</p>

## Anatomy of a Cloud Infrastructure Attack via a Pull Request
 - [https://goteleport.com/blog/hack-via-pull-request/](https://goteleport.com/blog/hack-via-pull-request/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 12:41:36+00:00

<p>Article URL: <a href="https://goteleport.com/blog/hack-via-pull-request/">https://goteleport.com/blog/hack-via-pull-request/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575764">https://news.ycombinator.com/item?id=28575764</a></p>
<p>Points: 31</p>
<p># Comments: 4</p>

## Learning Mathematical Properties of Integers
 - [https://arxiv.org/abs/2109.07230](https://arxiv.org/abs/2109.07230)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 12:40:16+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2109.07230">https://arxiv.org/abs/2109.07230</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575756">https://news.ycombinator.com/item?id=28575756</a></p>
<p>Points: 23</p>
<p># Comments: 3</p>

## Shortcomings of Amazon Mechanical Turk May Threaten Natural Language Generation
 - [https://www.unite.ai/the-shortcomings-of-amazon-mechanical-turk-may-threaten-natural-language-generation-systems/](https://www.unite.ai/the-shortcomings-of-amazon-mechanical-turk-may-threaten-natural-language-generation-systems/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 12:14:57+00:00

<p>Article URL: <a href="https://www.unite.ai/the-shortcomings-of-amazon-mechanical-turk-may-threaten-natural-language-generation-systems/">https://www.unite.ai/the-shortcomings-of-amazon-mechanical-turk-may-threaten-natural-language-generation-systems/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575607">https://news.ycombinator.com/item?id=28575607</a></p>
<p>Points: 36</p>
<p># Comments: 11</p>

## Git Commands Explained with Cats (2017)
 - [https://girliemac.com/blog/2017/12/26/git-purr/](https://girliemac.com/blog/2017/12/26/git-purr/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 12:01:29+00:00

<p>Article URL: <a href="https://girliemac.com/blog/2017/12/26/git-purr/">https://girliemac.com/blog/2017/12/26/git-purr/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575524">https://news.ycombinator.com/item?id=28575524</a></p>
<p>Points: 103</p>
<p># Comments: 16</p>

## Porter (YC W22) Is Hiring a UX/Product Engineer
 - [https://docs.google.com/spreadsheets/d/1EX95XOnOKJdantxM9VCO68KEE8Tbltvedlzji9KoQhY/edit?usp=sharing](https://docs.google.com/spreadsheets/d/1EX95XOnOKJdantxM9VCO68KEE8Tbltvedlzji9KoQhY/edit?usp=sharing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 12:00:00+00:00

<p>Article URL: <a href="https://docs.google.com/spreadsheets/d/1EX95XOnOKJdantxM9VCO68KEE8Tbltvedlzji9KoQhY/edit?usp=sharing">https://docs.google.com/spreadsheets/d/1EX95XOnOKJdantxM9VCO68KEE8Tbltvedlzji9KoQhY/edit?usp=sharing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575517">https://news.ycombinator.com/item?id=28575517</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Berlin buys thousands of apartments from corporate landlords
 - [https://thinkpol.ca/2021/09/17/berlin-buys-thousands-of-apartments-from-corporate-landlords/](https://thinkpol.ca/2021/09/17/berlin-buys-thousands-of-apartments-from-corporate-landlords/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 11:45:56+00:00

<p>Article URL: <a href="https://thinkpol.ca/2021/09/17/berlin-buys-thousands-of-apartments-from-corporate-landlords/">https://thinkpol.ca/2021/09/17/berlin-buys-thousands-of-apartments-from-corporate-landlords/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575429">https://news.ycombinator.com/item?id=28575429</a></p>
<p>Points: 121</p>
<p># Comments: 231</p>

## Ultrawhite BaSO4 Paints and Films for Daytime Radiative Cooling
 - [https://pubs.acs.org/doi/10.1021/acsami.1c02368](https://pubs.acs.org/doi/10.1021/acsami.1c02368)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 11:43:33+00:00

<p>Article URL: <a href="https://pubs.acs.org/doi/10.1021/acsami.1c02368">https://pubs.acs.org/doi/10.1021/acsami.1c02368</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575410">https://news.ycombinator.com/item?id=28575410</a></p>
<p>Points: 34</p>
<p># Comments: 33</p>

## India antitrust probe finds Google abused Android dominance, report shows
 - [https://www.reuters.com/technology/india-antitrust-probe-finds-google-abused-android-dominance-report-shows-2021-09-18/](https://www.reuters.com/technology/india-antitrust-probe-finds-google-abused-android-dominance-report-shows-2021-09-18/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 11:29:48+00:00

<p>Article URL: <a href="https://www.reuters.com/technology/india-antitrust-probe-finds-google-abused-android-dominance-report-shows-2021-09-18/">https://www.reuters.com/technology/india-antitrust-probe-finds-google-abused-android-dominance-report-shows-2021-09-18/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28575329">https://news.ycombinator.com/item?id=28575329</a></p>
<p>Points: 66</p>
<p># Comments: 18</p>

## Python Programming Puzzles
 - [https://github.com/microsoft/PythonProgrammingPuzzles](https://github.com/microsoft/PythonProgrammingPuzzles)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 09:17:43+00:00

<p>Article URL: <a href="https://github.com/microsoft/PythonProgrammingPuzzles">https://github.com/microsoft/PythonProgrammingPuzzles</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28574790">https://news.ycombinator.com/item?id=28574790</a></p>
<p>Points: 29</p>
<p># Comments: 4</p>

## Acoup: The Trench Stalemate
 - [https://acoup.blog/2021/09/17/collections-no-mans-land-part-i-the-trench-stalemate/](https://acoup.blog/2021/09/17/collections-no-mans-land-part-i-the-trench-stalemate/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 08:45:03+00:00

<p>Article URL: <a href="https://acoup.blog/2021/09/17/collections-no-mans-land-part-i-the-trench-stalemate/">https://acoup.blog/2021/09/17/collections-no-mans-land-part-i-the-trench-stalemate/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28574670">https://news.ycombinator.com/item?id=28574670</a></p>
<p>Points: 82</p>
<p># Comments: 19</p>

## Modifying the Linux Kernel – New Syscalls
 - [https://codingkaiser.blog/2021/07/17/create-your-own-system-calls%e2%80%8a-%e2%80%8aprocess-weights/](https://codingkaiser.blog/2021/07/17/create-your-own-system-calls%e2%80%8a-%e2%80%8aprocess-weights/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 08:34:09+00:00

<p>Article URL: <a href="https://codingkaiser.blog/2021/07/17/create-your-own-system-calls%e2%80%8a-%e2%80%8aprocess-weights/">https://codingkaiser.blog/2021/07/17/create-your-own-system-calls%e2%80%8a-%e2%80%8aprocess-weights/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28574624">https://news.ycombinator.com/item?id=28574624</a></p>
<p>Points: 118</p>
<p># Comments: 20</p>

## Doing a Job – The Management Philosophy of Adm. Hyman G. Rickover
 - [https://govleaders.org/rickover.htm](https://govleaders.org/rickover.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 08:33:18+00:00

<p>Article URL: <a href="https://govleaders.org/rickover.htm">https://govleaders.org/rickover.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28574622">https://news.ycombinator.com/item?id=28574622</a></p>
<p>Points: 49</p>
<p># Comments: 14</p>

## Borb – A Python library to read, write, and edit PDF files
 - [https://borbpdf.com/](https://borbpdf.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2021-09-18 07:02:09+00:00

<p>Article URL: <a href="https://borbpdf.com/">https://borbpdf.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=28574298">https://news.ycombinator.com/item?id=28574298</a></p>
<p>Points: 129</p>
<p># Comments: 20</p>

