# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This is stupid, but I love it - Linus Home NAS Update 2021
 - [https://www.youtube.com/watch?v=TWRvB8fh8T8](https://www.youtube.com/watch?v=TWRvB8fh8T8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-19 00:00:00+00:00

Thanks to Kioxia for sponsoring today's video! Check out their Enterprise Data Center SSD storage drives at https://lmg.gg/iEYI8

Over the last few years, we've tried to deploy this Gigabyte server chassis as a video editing server NUMEROUS times. Unfortunately, we had issue after issue with the intel drives we were trying to use, but this time, with the help of our sponsor KIOXIA, we're deploying it as my new ultimate home NAS with their CD6 enterprise NVMe SSDs.

Check out Unraid at https://lmg.gg/Mku1H

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1374426-this-is-stupid-but-i-love-it-sponsored/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:09 Setting up the server's component
5:54 What Kioxia CD6 drives can do!
7:39 Powering on the server
8:00 lttstore.com
8:11 Explaining and setting up Unraid
14:23 Testing out the server
17:20 Sponsor Kioxia!
17:45 Outro

## The Bioluminescent Gaming PC
 - [https://www.youtube.com/watch?v=UxqX5XIzDA4](https://www.youtube.com/watch?v=UxqX5XIzDA4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-18 00:00:00+00:00

Join us in War Thunder for FREE at https://playwt.link/ltt Get an exclusive bonus using our link - thanks for supporting the channel!

By genetically modifying some E. Coli we make a PC glow. Really.


Buy Lian Li PC-O11D
On Amazon (PAID LINK): https://geni.us/4YMuy8
On Newegg (PAID LINK): https://geni.us/AlhysJ
On B&H (PAID LINK): https://geni.us/f2MmH

Buy MSI MPG Z590 Carbon EK X
On Amazon (PAID LINK): https://geni.us/4tJq
On Newegg (PAID LINK): https://geni.us/Jno2
On B&H (PAID LINK): https://geni.us/DQG9Aig

Buy Alphacool Eisball Reservoir
On Amazon (PAID LINK): https://geni.us/ZHvsd
On Newegg (PAID LINK): https://geni.us/aveu

Buy Alphacool Eisbecher Helix 250mm Reservoir
On Amazon (PAID LINK): https://geni.us/NqfWHX
On Newegg (PAID LINK): https://geni.us/AGpY6L

Buy Intel Core i7-11700K
On Amazon (PAID LINK): https://geni.us/oJlbxe
On Best Buy (PAID LINK): https://geni.us/VuDGui
On Newegg (PAID LINK): https://geni.us/OteN

Buy AMD Radeon 6900XT
On Amazon (PAID LINK): https://geni.us/SiDql2H
On Best Buy (PAID LINK): https://geni.us/YaFO
On Newegg (PAID LINK): https://geni.us/DIfUH8

Purchases made through some store links may provide some compensation to Linus Media Group.

Check out Nyoka Design Labs: https://www.lightbynyoka.com/linustech

Discuss on the forum: https://linustechtips.com/topic/1374224-the-bioluminescent-gaming-pc/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 - Say hello to the Angler Fish
0:37 - War Thunder
0:50 - LTT Intro
0:58 - What is Bioluminescence
2:04 - Intro to Genetic Engineering
3:15 - Biotechnology, cooking show style
4:51 - Linus playing with E. Coli
5:44 - Test tube glowing
7:15 - Purification feat. His-Tag
8:30 - Glow #2
10:56 - Filling the loop
13:42 - The Bioluminescent Gaming PC
14:23 - What this is actually used for
16:22 - War Thunder again!
17:06 - Outro

