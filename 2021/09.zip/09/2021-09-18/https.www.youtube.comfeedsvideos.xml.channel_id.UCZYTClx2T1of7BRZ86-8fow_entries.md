# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Some Parasites Are Actually GOOD (And Which Can Kill You) | Parasite Compilation
 - [https://www.youtube.com/watch?v=GsQTKd3tpEE](https://www.youtube.com/watch?v=GsQTKd3tpEE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-09-19 00:00:00+00:00

What comes to mind when you think of parasites? Parasites are all around us, from birds’ nests to litter boxes to our brains, and while plenty of them are harmful to the health of animals and humans, some of them actually help us! Join Stefan Chin for a fun SciShow compilation all about the world of parasites!

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, charles george, Christoph Schwanke, Ash, Silas Emrys, Eric Jensen, Adam, Brainard, Piya Shedden, Alex Hackman, James Knight, GrowingViolet, Sam Lutfi, Alisa Sherbow, Jason A Saslow, Dr. Melvin Sanicas, Melida Williams

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Original Episodes:
Human Parasites - https://youtu.be/ABeBqbBy2Lo
Brood Parasites - https://youtu.be/HpIhSLXQ5oc
Mind-controlling Parasites! - https://youtu.be/uvdiYg6ZN-U
Toxoplasmosis: How Parasites in Your Cat Can Infect Your Brain - https://youtu.be/FNm_MjrIUAI
Why Don't Humans Get Heartworm? (Spoiler: We Do) - https://youtu.be/8ilHOgTXnp0
Why You Might Want Parasitic Worms - https://youtu.be/qD6fmHUXBEg

## How Do Ducks Stay Dry?
 - [https://www.youtube.com/watch?v=uf3fpHDewgw](https://www.youtube.com/watch?v=uf3fpHDewgw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-09-18 00:00:00+00:00

You might be familiar with the phrase "like water off a ducks back". But it's not that ducks don't get wet, it's that they get wet, with style.

SciShow is supported by Brilliant.org. Go to https://Brilliant.org/SciShow to get 20% off of an annual Premium subscription. 

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, charles george, Christoph Schwanke, Ash, Silas Emrys, Eric Jensen, Adam, Brainard, Piya Shedden, Alex Hackman, James Knight, GrowingViolet, Sam Lutfi, Alisa Sherbow, Jason A Saslow, Dr. Melvin Sanicas, Melida Williams

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.eurekalert.org/news-releases/763343
https://pubs.acs.org/doi/10.1021/acsami.1c04480
https://www.tsfx.edu.au/resources/46606.pdf
https://news.mit.edu/2014/how-cormorants-emerge-dry-after-deep-dives-0616
http://naturevictoria.com/articles/buoyancy.html

IMAGES

https://www.istockphoto.com/photo/diving-mallard-gm183533292-14887154
https://www.istockphoto.com/photo/closeup-feather-detail-of-mallard-duck-gm157611351-13529105
https://www.storyblocks.com/video/stock/americans-male-mallard-duck-drake-on-the-lake-sylogx91vkckm6b9q
https://vtx.vt.edu/articles/2021/05/eng-research-boreyko-feathers-0521.html

