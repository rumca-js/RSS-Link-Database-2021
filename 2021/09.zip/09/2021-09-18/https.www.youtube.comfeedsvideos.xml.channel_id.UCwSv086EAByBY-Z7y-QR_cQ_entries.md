# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Ustawa, która niedługo będzie głosowana, jest rozwinięciem pomysłu Billa Gatesa. Analiza
 - [https://www.youtube.com/watch?v=FVU0IV0N02w](https://www.youtube.com/watch?v=FVU0IV0N02w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-09-18 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3tQeLZI
2. https://youtu.be/0gjjk0vVNko
3. https://bit.ly/3nLlSSd
4. https://bit.ly/3zqnZNs
5. https://bit.ly/3uccpDm
6. https://tcrn.ch/3hKG8jb
7. https://bit.ly/3nIfivX
8. https://bit.ly/3ytRJJN
9. https://bit.ly/3Ahb94V
10. https://on.msnbc.com/3AomOPL
11. https://bit.ly/3jtbafn
12. https://abcn.ws/3xrEkAr
13. https://bit.ly/3CjJP7Z
14. https://bit.ly/3hLLhY5
15. https://bit.ly/3zgM1dS
16. https://bit.ly/3Cpn3uD
17. https://bit.ly/3tOih6N
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę ze strony: 
Flickr / Sebastian Vital - https://bit.ly/397m3jm
---
gov.pl - http://bit.ly/2lVWjQr
---------------------------------------------------------------
💡 Tagi: #QR #BillGates
--------------------------------------------------------------

