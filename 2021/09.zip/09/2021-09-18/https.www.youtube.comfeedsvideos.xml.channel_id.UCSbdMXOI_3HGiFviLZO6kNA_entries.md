# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## What happens if you WATERCOOL an Oculus Quest 2?
 - [https://www.youtube.com/watch?v=6w9NY7pzv5Q](https://www.youtube.com/watch?v=6w9NY7pzv5Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-09-18 00:00:00+00:00

Hello! Today I did something incredibly dumb. I water-cooled my Oculus Quest 2. What happens if you give the Quest 2 WAY more thermal headroom than necessary? Well, lets find out. Basically, we need to overclock this headset.

Materials used in the video!
https://amzn.to/3AnoF7L
https://amzn.to/3Cptnm1
https://amzn.to/39j86Oo
https://amzn.to/3Eytj54

Join in my discord!
Discord.gg/Thrill
Twitch.tv/Thrilluwu

