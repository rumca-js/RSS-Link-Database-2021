# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Kaczyński: nasi przyjaciele z Platformy. Tusk: nasi przyjaciele z PiS". To nie deepfake. Kiedyś tak było
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1682,S00E1682,595354?source_id=bannernewsowy&source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1682,S00E1682,595354?source_id=bannernewsowy&source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2021-09-18 03:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie2e4ce9747e45094d8f35845b3e09bee7-tusk-i-kaczynski-kiedys-mowili-jednym-glosem-i-byli-po-tej-samej-stronie-politycznej-barykady-3681769/alternates/LANDSCAPE_1280" />
    Od przyjaźni do dzisiejszych napiętych stosunków obaj przywódcy przeszli długą i krętą drogę. Reportaż Dariusza Kubika.

