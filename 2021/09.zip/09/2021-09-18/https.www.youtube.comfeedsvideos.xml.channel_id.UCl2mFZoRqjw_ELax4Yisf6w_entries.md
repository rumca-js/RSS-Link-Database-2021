# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Let's talk about the importance of following your own rules
 - [https://www.youtube.com/watch?v=3VPk-ojOCp4](https://www.youtube.com/watch?v=3VPk-ojOCp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-19 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://abc7news.com/london-breed-masks-maskless-black-cat-tenderloin-sf/11028270/
https://www.youtube.com/watch?v=3PGwnm_pNnM
https://www.youtube.com/watch?v=r6rMJHcQYRU
https://www.youtube.com/watch?v=jYGKuZDnIlw
https://www.youtube.com/watch?v=FNMJf_VMK8o
https://www.youtube.com/watch?v=-P0y3AXetS0

## The REAL reason employees aren't returning to work in America.
 - [https://www.youtube.com/watch?v=52HpzZ4HT4g](https://www.youtube.com/watch?v=52HpzZ4HT4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-19 00:00:00+00:00

https://tinyurl.com/rossmatrix
Many people have their ideas about why workers aren't going back to work. The reality is that most employers used to sell the implication that what they were offering was a steady paycheck. 2020 made it clear that is NOT the case.

## What makes NYC great for people starting out on their business/life journey
 - [https://www.youtube.com/watch?v=12pUrIZUjn0](https://www.youtube.com/watch?v=12pUrIZUjn0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-18 00:00:00+00:00

https://tinyurl.com/rossmatrix

