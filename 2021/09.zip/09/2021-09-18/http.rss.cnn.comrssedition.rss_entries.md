# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 'Hotlanta' is even more sweltering in these neighborhoods due to a racist 20th Century policy
 - [https://www.cnn.com/2021/09/18/weather/extreme-urban-heat-environmental-racism-climate/index.html](https://www.cnn.com/2021/09/18/weather/extreme-urban-heat-environmental-racism-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 12:58:06+00:00

On a warm September afternoon, Mona Scott sat on the front porch while her home baked like an oven. As she ran a frozen water bottle across her forehead and arms, Scott told CNN her air conditioning broke 10 days earlier and had not yet been fixed.

## 'They didn't betray us yet,' says stranded Afghan ally with enduring hope of US rescue
 - [https://www.cnn.com/2021/09/18/asia/mazar-abandoned-afghan-us-intl-cmd/index.html](https://www.cnn.com/2021/09/18/asia/mazar-abandoned-afghan-us-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 12:55:14+00:00

Wakil's eyes fill with tears. He has no idea whether he and his family will get out of Afghanistan, and fears that if they don't the Taliban will hunt him down and kill him.

## CNN's pop Off: Summer celeb romances that are heading into fall
 - [https://www.cnn.com/videos/entertainment/2021/09/17/jennifer-lopez-ben-affleck-pop-life-pop-off-orig-mg-jm.cnn](https://www.cnn.com/videos/entertainment/2021/09/17/jennifer-lopez-ben-affleck-pop-life-pop-off-orig-mg-jm.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 11:44:32+00:00

This week on "Pop Off," CNN reporter Lisa Respers France tells you which celeb summer romances are heading into fall, chats with the stars of "The Morning Show" and debates the merits of Mariah Carey's "Glitter." Subscribe to Lisa's "Pop Life Chronicles" newsletter here.

## Tottenham to host world's first net zero carbon elite football game -- but is a carbon-neutral match possible?
 - [https://www.cnn.com/2021/09/18/football/tottenham-hotspur-game-zero-sustainability-spt-intl/index.html](https://www.cnn.com/2021/09/18/football/tottenham-hotspur-game-zero-sustainability-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 11:29:15+00:00

Tottenham Hotspur hopes to end Sunday's Premier League game against Chelsea on zero -- not zero goals or shots on target, but zero carbon emissions.

## High temperatures, wildfire smoke and drought: The politics of climate change in one California congressional district
 - [https://www.cnn.com/2021/09/18/politics/drought-climate-change-california-21-congressional-district/index.html](https://www.cnn.com/2021/09/18/politics/drought-climate-change-california-21-congressional-district/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 11:25:14+00:00

The changing climate is everywhere Gustavo Carranza looks when he walks through his undulating citrus farm here in this tiny town in the foothills of the Sierra Nevada.

## The world's tallest nation is getting shorter
 - [https://www.cnn.com/2021/09/18/europe/dutch-tallest-shorter-scli-scn-intl/index.html](https://www.cnn.com/2021/09/18/europe/dutch-tallest-shorter-scli-scn-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 11:21:39+00:00

The Netherlands has long been the world's tallest nation -- but its people are getting shorter, according to Dutch researchers.

## The Murdaugh family saga: a tangled web of secrets and murder
 - [https://www.cnn.com/2021/09/18/us/murdaugh-mystery-south-carolina/index.html](https://www.cnn.com/2021/09/18/us/murdaugh-mystery-south-carolina/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 11:01:20+00:00

A powerful family. A deadly boating accident. Two mysterious slayings. Drug addiction, stolen money and a botched shooting in an alleged insurance fraud scheme.

## Gabby Petito's family attorney says fiancé Brian Laundrie 'is not missing, he is hiding'
 - [https://www.cnn.com/2021/09/18/us/gabby-petito-missing-saturday/index.html](https://www.cnn.com/2021/09/18/us/gabby-petito-missing-saturday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 10:31:04+00:00

Along with the search for missing 22-year-old Gabby Petito, local and federal authorities in Florida are looking for Petito's fiance Brian Laundrie after his family told police they haven't seen him since Tuesday.

## It's not only the French who are furious with Australia's new defense pact
 - [https://www.cnn.com/2021/09/18/australia/nuclear-energy-climate-aukus-submarines-intl-cmd/index.html](https://www.cnn.com/2021/09/18/australia/nuclear-energy-climate-aukus-submarines-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 10:22:02+00:00

• France recall of ambassadors may be a first in modern times, official says
• Why France is angry about the US and UK giving Australia nuclear-powered submarines

## Chile, Fiji and South Africa are ready for travelers to come back
 - [https://www.cnn.com/travel/article/pandemic-travel-news-sept-18-chile-fiji-south-africa/index.html](https://www.cnn.com/travel/article/pandemic-travel-news-sept-18-chile-fiji-south-africa/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 09:00:51+00:00

There have been mixed fortunes for the world's island communities this week, as some have restricted entry due to Covid surges while others are making plans for reopening.

## Angry and afraid, Afghanistan's LGBTQ community say they're being hunted down after Taliban takeover
 - [https://www.cnn.com/2021/09/17/middleeast/afghanistan-lgbtq-evacuation-intl-hnk-dst/index.html](https://www.cnn.com/2021/09/17/middleeast/afghanistan-lgbtq-evacuation-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 08:04:44+00:00

Growing up as a teenager in Afghanistan, Rabia Balkhi felt lucky.

## Australia's nuclear-powered submarine deal is fueling anger in the country. Here's why
 - [https://www.cnn.com/collections/aukus-intl-091521/](https://www.cnn.com/collections/aukus-intl-091521/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 08:03:14+00:00



## Vaccine boosters are on the horizon. But the unvaccinated remain the biggest obstacle
 - [https://www.cnn.com/2021/09/18/health/us-coronavirus-saturday/index.html](https://www.cnn.com/2021/09/18/health/us-coronavirus-saturday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 07:46:24+00:00

While more people are likely to be eligible for Covid-19 vaccine booster shots, the most glaring issue prolonging the pandemic is the large swath of unvaccinated people, who are filling up hospitals and dying from the persistent virus, officials and health experts said.

## Robert Durst, millionaire who was focus of HBO documentary 'The Jinx,' found guilty
 - [https://www.cnn.com/2021/09/17/us/robert-durst-los-angeles-jury-verdict/index.html](https://www.cnn.com/2021/09/17/us/robert-durst-los-angeles-jury-verdict/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 05:51:45+00:00

A Los Angeles jury found Robert Durst, the notorious subject of the HBO series "The Jinx," guilty of first-degree murder for the killing of his best friend, Susan Berman, more than 20 years ago.

## Feds say man driven by hatred of Jews pleaded guilty to all charges after deadly 2019 assault on California synagogue
 - [https://www.cnn.com/2021/09/18/us/poway-synagogue-attack-verdict/index.html](https://www.cnn.com/2021/09/18/us/poway-synagogue-attack-verdict/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 05:01:43+00:00

A Southern Californian man who previously pleaded guilty to state murder and attempted murder charges following a 2019 attack on a synagogue in San Diego pleaded guilty Friday to federal hate crime charges, according to the Justice Department.

## Vietnam approves Cuba's Abdala vaccine as Delta variant outbreak continues
 - [https://www.cnn.com/2021/09/18/asia/vietnam-cuba-abdala-vaccine-intl-hnk/index.html](https://www.cnn.com/2021/09/18/asia/vietnam-cuba-abdala-vaccine-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 04:11:20+00:00

Vietnam has approved Cuba's Abdala vaccine for use against the coronavirus, the government said on Saturday, as the Southeast Asian country battles its worst outbreak of the pandemic.

## How Europe's hospitals are faring in the face of another pandemic fall
 - [https://www.cnn.com/collections/intl-covid-09162021/](https://www.cnn.com/collections/intl-covid-09162021/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 04:08:30+00:00



## Biden looks to recapture his political momentum with a full-court press on his domestic agenda
 - [https://www.cnn.com/2021/09/18/politics/joe-biden-political-momentum/index.html](https://www.cnn.com/2021/09/18/politics/joe-biden-political-momentum/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 04:02:29+00:00

A politically weakened President Joe Biden is looking to spark a turnaround with a renewed focus on his domestic agenda after a month marred by a spike in Covid-19 cases and a messy withdrawal from Afghanistan.

## How Europe's hospitals are faring in the face of another pandemic fall
 - [https://www.cnn.com/2021/09/18/europe/europe-covid-hospitalizations-intl-cmd/index.html](https://www.cnn.com/2021/09/18/europe/europe-covid-hospitalizations-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 04:00:50+00:00

Much of Europe has opened up to international visitors and scaled back Covid-19 restrictions since a wave of cases swept the continent in the spring.

## Two of California Gov. Gavin Newsom's children test positive for Covid-19
 - [https://www.cnn.com/2021/09/17/politics/gavin-newsom-children-covid/index.html](https://www.cnn.com/2021/09/17/politics/gavin-newsom-children-covid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 02:19:53+00:00

Two of California Gov. Gavin Newsom's four children have tested positive for Covid-19, his office said in a statement Friday.

## US aims to hit revenue streams of ransomware groups with sanctions
 - [https://www.cnn.com/2021/09/17/politics/biden-treasury-department-ransomware-sanctions/index.html](https://www.cnn.com/2021/09/17/politics/biden-treasury-department-ransomware-sanctions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 01:15:06+00:00

The Biden administration is planning to impose new sanctions to disrupt the source of revenue of ransomware groups that have extorted major US firms of millions of dollars, a US official and a private cybersecurity expert briefed on the matter told CNN.

## America's radicals are a problem we can't ignore
 - [https://www.cnn.com/2021/09/17/opinions/extremists-radicalization-in-america-miller/index.html](https://www.cnn.com/2021/09/17/opinions/extremists-radicalization-in-america-miller/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-18 01:06:12+00:00

Last month, a man drove to Washington, DC , police said, with explosive-making materials and threatened detonations near the US Capitol, although no functioning weapons were found in his vehicle. You'd think this would have been a big story, but after what seemed like just a few hours, it was swamped by the news of the Taliban taking over Afghanistan. This is understandable, as what was unfolding a world away was both dramatic and tragic. However, it was also a mistake to so quickly look away from the DC standoff.

