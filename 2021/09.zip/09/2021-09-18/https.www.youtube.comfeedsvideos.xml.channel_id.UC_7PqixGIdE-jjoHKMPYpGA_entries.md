# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Jak plastyczny jest Twój mózg?
 - [https://www.youtube.com/watch?v=v6XpVwph9EU](https://www.youtube.com/watch?v=v6XpVwph9EU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-09-19 00:00:00+00:00

👉 https://kwalifikacje.edu.pl/

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

W okresie narodzin współczesnej neurobiologii powszechne było stwierdzenie, że dorosły mózg jest niezmienny - że jedyne zmiany, jakie mogą w nim zajść to zmiany degeneracyjne... zniszczenia. A jednak są ludzie, którzy odzyskują niemal pełnię zdolności funkcjonowania po udarach. Są też tacy, którzy widzą... choć nie widzą oczami... A to każe nam trochę zmienić paradygmat!

===
Rozkład jazdy:

0:00 Echolokacja
2:50 Mózg z komórek
5:13 Wszystko może umrzeć
6:09 Mózg nie znosi próżni
8:22 Ruchy dłoni
11:11 Nareszcie neuroplastyczność
14:03 Stare psy
15:00 Przekaz od sponsora odcinka
16:53 To (chyba) dopiero początek

===
Źródła (wybrane):

S. Kean - Dziwne przypadki ludzkiego mózgu
B. Sadowski - Biologiczne Mechanizmy Zachowania się Ludzi i Zwierząt
L. Thaler i in. - Human Echolocation I
l. Thaler i in. -  Neural correlates of natural human echolocation in early and late blind echolocation experts
M. Kossut - Neuroplastyczność – podstawowe mechanizmy
P. Mateos-Aparicio i in. - The Impact of Studying Brain Plasticity

