# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The History of Númenor | Tolkien Explained
 - [https://www.youtube.com/watch?v=TRtUiTFSZvA](https://www.youtube.com/watch?v=TRtUiTFSZvA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-09-18 00:00:00+00:00

An overview of the Rise and Fall of Númenor!  Living on the island that was a gift from the Valar to the Edain, this great kingdom of Men would prove a pivotal player in the Second Age.  It is sure to be a primary location for the new Amazon Lord of the Rings on Prime series, and boasts some of the most dramatic stories from the time period.

Today's video tracks Númenor's beginning under King Elros Tar-Minyatur - the mortal brother of Elrond.  From there, we follow the story of these men as they help the elves of Lindon in the War of Elves and Sauron.  I'll explain how the Númenóreans begin to turn their backs on the elves and Valar, until their island is finally destroyed after Ar-Pharazôn falls prey to the lies of Sauron.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark

White Ships from Valinor - Ted Nasmith
Adunie - Greset David
Numenor - Sarka Skorpikova
The Edain - Wouter Florusse
Until the world is broken and remade - Jenny Dolfen
Imperial Numenorean Armour - Turner Mohan
Numenor - Volodymyr Ivanitsky
Nimloth - Rivkaz
White Tree of Gondor - 1OSHUART
Elros Tar-Minyatur - Liz Danforth
The Eagles of Manwe - Pete Amachree
Elrond and Elros Tar-Minyatur - Stardust
Port of Numenor - Giovanni Calore
Hillmen and Wolfdogs - Jan Popisil
Numenoreans - Abe Papakhian
Numenorean Armor Color - Turner Mohan
Pelargir Docks - Emilio Rodriguez
The Mariner's Wife - Turner Mohan
Dunlending - John Howe
Elves in Andunie - Matej Cadil
Aldarion Returns From His First Voyage - Ted Nasmith
Numenorean Guard - Luis F Bejarano
Middle-earth Panorama (Pelargir) - Roger Garland
Numenor - Inacio Henrique
Sauron - Jean Pascal Leclerc
Numenor - Izzi
Elfs of the Last Alliance - Tiamatnightmare
Eldalonde - Matej Cadil
The Evil Runs Deep in Numenor - Oznerol
Numenorean Tower - Greset David
Armenelos - Skullb*st*rd
Manwe Sulimo - Gustavo Malek
Sunrise on the Colossi at Numenor - Kip Rasmussen
Faithful Family, Inzilbeth and Inziladun - Juliana Pinho
Miriel - Un Cheon
Telperien - JB Mossa
Ar-Pharazon - Nemanja Bubalo
The Mighty Sauron - Toherrys
Sauron the Deceiver - Toherrys
Sauron Bows, Submits to Ar-Pharazon - Kip Rasmussen
Annatar Chained - Nemanja Bubalo
Sauron High Priest - Nemanja Bubalo
Sauron High Priest Masked - Nemanja Bubalo
Annatar - Alais
The Treasure - Nele Diel
Sauron and Ar-Pharazon - Janka Lateckova
Ar-Pharazon - Steamey
Ar-Pharazon - Clemence
Annatar - Anastasiya Cemetery
Sauron speaks to Ar-Pharazon - Marty Lionel
Morgoth - Timo Bg Vihola
Slave Inspection - Merlkir
Ar-Pharazon - Edvige Faini
Isildur and the fruit of Nimloth - Eva Zahradnikova
Isildur Steals the Last Fruit of Nimloth - Sara M Morello
Ar-Pharazon - Nemanja Bubalo
Ar-Pharazon Old - Nemanja Bubalo
The King's Counselor - Turner Mohan
Numenor's Legion of Armenelos - Sam McKinnon
Ar-Pharazon Defies - Paula DiSante
Ar-Pharazon Armor - Clemence Morisseau
Ar-Pharazon's Fleet at Umbar - Niwa Jongkind
The Destroying Wave over Numenor - Kip Rasmussen
The Fall of Numenor - Miriel - Rena Foxfairy
The Drowning of Numenor - John Howe
Lord of Mordor - Snow Monster
Ships of the Faithful - Ted Nasmith
Black Numenoreans - Jovan Delic Herumor
Mouth of Sauron - Nemanja Bubalo
Out Of The Sea I Am Come - Turner Mohan
Battle of Minas Tirith - Andrzej Grzechnik
Elendil and Sons - Abe Papakhian
The Palantir - Morgen Bell
Meneltarma - Peet
Numenor - Eric Faure Brac
Minas Tirith - Ludovic Bourgeois
Arthedain Rangers - Wouter Florusse

#numenor #tolkien #lotronprime

