## Mailchimp Insiders React to Employees Getting No Equity From Intuit Sale
 - [https://www.businessinsider.com/mailchimp-insiders-react-to-employees-getting-no-equity-2021-9?r=US&IR=T](https://www.businessinsider.com/mailchimp-insiders-react-to-employees-getting-no-equity-2021-9?r=US&IR=T)
 - RSS feed: https://www.businessinsider.com
 - date published: 2021-09-18 08:21:47.495630+00:00

Employees reacted with shock and anger after Intuit announced Monday it was buying Mailchimp for around $12 billion in stock and cash.

