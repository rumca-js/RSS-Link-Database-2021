# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Jack's 12 Minute Twist, Marty Gets Titanfall'd and Amy's Halo Misadventures | Escapist Highlights
 - [https://www.youtube.com/watch?v=I5srLEvp22E](https://www.youtube.com/watch?v=I5srLEvp22E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-18 00:00:00+00:00

This month on Escapist Highlights, Jack can't stand the twist in 12 Minutes, Nick can't escape the titanfall and Marty can't remember throwing grenades at teammates. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## TOEM | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=4bAkMyc4gSM](https://www.youtube.com/watch?v=4bAkMyc4gSM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-18 00:00:00+00:00

Will Cruz reviews Toem, developed by Something We Made.

Toem on Steam: https://store.steampowered.com/app/1307580/TOEM/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#Toem

