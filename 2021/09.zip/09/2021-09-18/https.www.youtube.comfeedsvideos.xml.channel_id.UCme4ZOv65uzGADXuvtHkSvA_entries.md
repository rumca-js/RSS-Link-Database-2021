# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Księga Liczb || Rozdział 28
 - [https://www.youtube.com/watch?v=woYhdJzcwxI](https://www.youtube.com/watch?v=woYhdJzcwxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-19 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#252] Samotność w tłumie
 - [https://www.youtube.com/watch?v=uhZaMbWDNaU](https://www.youtube.com/watch?v=uhZaMbWDNaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-18 00:00:00+00:00

Komentarz do czytań, czyli kazanko do okienka.

XXV niedziela zwykła, Rok B

1. czytanie (Mdr 2, 12. 17-20)

Bezbożni mówili: «Zróbmy zasadzkę na sprawiedliwego, bo nam niewygodny: sprzeciwia się naszemu działaniu, zarzuca nam przekraczanie Prawa, wypomina nam przekraczanie naszych zasad karności.
Zobaczmy, czy prawdziwe są jego słowa, wybadajmy, co będzie przy jego zgonie. Bo jeśli sprawiedliwy jest synem Bożym, Bóg ujmie się za nim i wyrwie go z rąk przeciwników.
Dotknijmy go obelgą i katuszą, by poznać jego łagodność i doświadczyć jego cierpliwości. Zasądźmy go na śmierć haniebną, bo – jak mówił – będzie ocalony».

2. czytanie (Jk 3, 16 – 4, 3)

Najmilsi: Gdzie zazdrość i żądza sporu, tam też bezład i wszelki występek. Mądrość zaś zstępująca z góry jest przede wszystkim czysta, dalej – skłonna do zgody, ustępliwa, posłuszna, pełna miłosierdzia i dobrych owoców, wolna od względów ludzkich i obłudy. Owoc zaś sprawiedliwości sieją w pokoju ci, którzy zaprowadzają pokój.
Skąd się biorą wojny i skąd kłótnie między wami? Nie skądinąd, tylko z waszych żądz, które walczą w członkach waszych. Pożądacie, a nie macie, żywicie morderczą zazdrość, a nie możecie osiągnąć. Prowadzicie walki i kłótnie, a nic nie posiadacie, gdyż się nie modlicie. Modlicie się, a nie otrzymujecie, bo się źle modlicie, starając się jedynie o zaspokojenie swych żądz.

Ewangelia (Mk 9, 30-37)

Jezus i Jego uczniowie przemierzali Galileę, On jednak nie chciał, żeby ktoś o tym wiedział. Pouczał bowiem swoich uczniów i mówił im: «Syn Człowieczy będzie wydany w ręce ludzi. Ci Go zabiją, lecz zabity, po trzech dniach zmartwychwstanie». Oni jednak nie rozumieli tych słów, a bali się Go pytać.
Tak przyszli do Kafarnaum. Gdy był już w domu, zapytał ich: «O czym to rozprawialiście w drodze?» Lecz oni milczeli, w drodze bowiem posprzeczali się między sobą o to, kto z nich jest największy. On usiadł, przywołał Dwunastu i rzekł do nich: «Jeśli ktoś chce być pierwszym, niech będzie ostatnim ze wszystkich i sługą wszystkich». Potem wziął dziecko, postawił je przed nimi i objąwszy je ramionami, rzekł do nich: «Kto jedno z tych dzieci przyjmuje w imię moje, Mnie przyjmuje; a kto Mnie przyjmuje, nie przyjmuje Mnie, lecz Tego, który Mnie posłał».

#cnn #kazankodookienka #dobrewiadomości
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Liczb || Rozdział 27
 - [https://www.youtube.com/watch?v=rsgGW2RjIC4](https://www.youtube.com/watch?v=rsgGW2RjIC4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-18 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#893] Wygodnie
 - [https://www.youtube.com/watch?v=t-x4naUJa88](https://www.youtube.com/watch?v=t-x4naUJa88)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-18 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

