# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The Hidden "Virtual Drive" Commands in Windows
 - [https://www.youtube.com/watch?v=A_vHHxkVXh0](https://www.youtube.com/watch?v=A_vHHxkVXh0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-09-18 00:00:00+00:00

A couple commands that might come in real handy 🤔
⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Introduction
0:34 - Why though?
1:11 - The Commands
1:31 - How to use 'subst'
2:47 - Downsides of 'subst'
3:18 - Making it Persistent
6:21 - The 'net use' Command

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

