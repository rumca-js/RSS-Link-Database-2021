# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## The Metroid Franchise - Which Are Worth Playing/Buying?
 - [https://www.youtube.com/watch?v=04aibjsKiXo](https://www.youtube.com/watch?v=04aibjsKiXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-09-19 00:00:00+00:00

This year marks the 35th anniversary of Metroid, the loveable bounty hunting, genre defining, child that Nintendo loves to forget about. Except to everyone’s surprise Nintendo did remember this year and are celebrating with Metroid 5, aka Metroid Dread, the first brand new 2D Metroid game in quite a long time.

So long in fact that there is a whole generation of people that have never experienced just how good classic Metroid is, and are looking at all the excitement Dread is causing, and they’re curious. 

For this video, Jean-luc details the best Nintendo approved options available for you. Unfortunately that means buying a Wii U.

#metroid

## Firearms Expert Reacts To Rainbow Six Siege’s Guns
 - [https://www.youtube.com/watch?v=YR87FPoacQI](https://www.youtube.com/watch?v=YR87FPoacQI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-09-18 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the weaponry of Rainbow Six Siege, including the C1 9mm, the DP27 and the L85A2 Assault Rifle.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down the guns of Rainbow Six Siege and compares them to their real-life counterparts.

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can either purchase Jonathan's book here. - https://www.headstamppublishing.com/bullpup-rifle-book

Or at the Royal Armouries shop here. - https://shop.royalarmouries.org/collections/thorneycroft-to-sa80-british-bullpup-firearms-1901-2020

#firearms #rainbow6siges

