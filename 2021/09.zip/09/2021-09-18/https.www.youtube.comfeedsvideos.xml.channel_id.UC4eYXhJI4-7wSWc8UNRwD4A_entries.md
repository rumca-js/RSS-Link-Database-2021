# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Mon Laferte: Una Conversación Con Alt.Latino
 - [https://www.youtube.com/watch?v=iyhmBMoRk-A](https://www.youtube.com/watch?v=iyhmBMoRk-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-09-19 00:00:00+00:00

Mon Laferte es una vocalista dinámica con experiencia tocando y produciendo música en todo tipo de géneros. Aunque es originaria de Chile, su álbum recientemente lanzado, 'Seis,' usa sonidos de Ranchera y Banda para rendir homenaje a la cantante de Banda, de fama mundial, nacida en Costa Rica y de origen mexicano, Chavela Vargas. Chavela era ampliamente conocida por romper barreras como una presencia femenina prominente en la música ranchera (un espacio dominado por hombres). Mon está canalizando esa energía en su nuevo álbum, explorando estilos y temas musicales que desafían las expectativas, rompiendo barreras en el proceso.

Mon Laferte is a dynamic vocalist with experience playing with and producing music in all kinds of genres. While originally from Chile, her newly released album, 'Seis,' uses Ranchera and Banda sounds to pay tribute to globally renowned Costa Rican-born, Mexican-made Banda vocalist Chavela Vargas. Chavela was widely known for breaking down barriers as a prominent female presence in Ranchera music (a male-dominated space). Mon is channeling that energy in her new album, exploring musical styles and themes that defy expectations, breaking down barriers in the process.

#altlatino #monlaferte #nprmusic

