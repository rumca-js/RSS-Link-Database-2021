# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Baby squirrel abandoned on Cambridge patio bonds with carer
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-58599762?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-58599762?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 23:40:45+00:00

The squirrel, named Paquito, formed an unexpected friendship with his temporary carer.

## Afghanistan: The 'shattered dreams' of the Ariana cabin crew
 - [https://www.bbc.co.uk/news/world-middle-east-58599522?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-58599522?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 23:34:56+00:00

The BBC's Lyse Doucet meets the female crew of Afghanistan's national airline, who are in hiding.

## Morgan Bullock makes professional debut in Riverdance
 - [https://www.bbc.co.uk/news/entertainment-arts-58602633?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58602633?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 23:22:34+00:00

Morgan Bullock from Richmond, Virginia, joins the UK touring company of the acclaimed Irish dance show.

## Fake Paralympians boss: 'I didn't know about cheating'
 - [https://www.bbc.co.uk/news/stories-58598677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-58598677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 23:22:03+00:00

The man fined for sending non-disabled athletes to the Sydney Paralympics breaks his silence.

## Get an Eiffel of this performer walking the line in Paris
 - [https://www.bbc.co.uk/news/world-europe-58612966?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58612966?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 23:18:06+00:00

Nathan Paulin walks along a 70m (230ft) high slackline attached to an iconic French landmark.

## Match of the Day analysis: How Arsenal showed ‘grit & determination’ to beat Burnley
 - [https://www.bbc.co.uk/sport/av/football/58612909?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/58612909?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 23:13:09+00:00

Match of the Day pundits Gary Lineker, Jermaine Jenas and Martin Keown discuss how Arsenal showed "grit and determination" in their hard-fought victory over Burnley in the Premier League.

## The link between climate change, seaweed and ice cream
 - [https://www.bbc.co.uk/news/stories-58582499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-58582499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 23:07:27+00:00

Seaweed production has been affected by warming seas – this is how farmers are adapting.

## Students must have say over online learning - regulator
 - [https://www.bbc.co.uk/news/education-58600875?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-58600875?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 22:57:28+00:00

The higher education regulator says students must have a say on how much of their teaching is online.

## Sherrock makes history by reaching final before losing to Van Gerwen
 - [https://www.bbc.co.uk/sport/darts/58612539?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/darts/58612539?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 22:31:59+00:00

Fallon Sherrock becomes the first woman to reach a televised PDC final, but loses to Michael van Gerwen at the Nordic Darts Masters.

## Former pro cyclist Sorensen dies after being hit by vehicle
 - [https://www.bbc.co.uk/sport/cycling/58612748?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/58612748?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 22:17:24+00:00

Danish former professional cyclist Chris Anker Sorensen dies at the age of 37 after being hit by a vehicle during a ride in Belgium, the International Cycling Union (UCI) says.

## Boxer Amir Khan removed from US flight
 - [https://www.bbc.co.uk/news/uk-58612530?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58612530?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 22:07:27+00:00

The Briton was asked to leave the plane at Newark airport after a reported row over face coverings.

## Kent put in superb fielding display to beat Somerset in T20 Blast final
 - [https://www.bbc.co.uk/sport/cricket/58609102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/58609102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 21:50:04+00:00

Kent Spitfires beat Somerset to win the T20 for the second time - 14 years on from their first triumph at Edgbaston

## Strictly champ Oti Mabuse goes for hat-trick with rugby star Ugo Monye
 - [https://www.bbc.co.uk/news/entertainment-arts-58611007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58611007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 21:48:40+00:00

Oti Mabuse and Ugo Monye's rivals include the show's first all-male pair - John Whaite and Johannes Radebe.

## T20 Blast final: Jordan Cox and Matt Milnes combine for magnificent relay catch
 - [https://www.bbc.co.uk/sport/av/cricket/58612343?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/58612343?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 20:33:46+00:00

Kent Spitfires' Jordan Cox parries the ball to Matt Milnes for an outstanding relay catch to dismiss Somerset's Lewis Gregory during the final of the T20 Blast at Edgbaston.

## Guardiola feels 'guilty' after Southampton stalemate
 - [https://www.bbc.co.uk/sport/football/58611848?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58611848?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 19:59:51+00:00

Manchester City manager Pep Guardiola says he feels "guilty" after his side fail to put on "a show" in Saturday's goalless draw with Southampton.

## Liverpool 3-0 Crystal Palace: Reds remain unbeaten as Sadio Mane scores 100th goal
 - [https://www.bbc.co.uk/sport/football/58525384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58525384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 15:57:50+00:00

Liverpool remain unbeaten in the Premier League this season after Sadio Mane scores his 100th goal for the club in a victory against Crystal Palace.

## Holiday bookings surge after travel rules change
 - [https://www.bbc.co.uk/news/uk-58606870?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58606870?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 11:52:26+00:00

Travel agents report a rise in bookings after the amber list is scrapped and testing rules are eased.

## Gas price rises prompt urgent government talks
 - [https://www.bbc.co.uk/news/uk-58605735?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58605735?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 11:45:54+00:00

There are concerns the high price of wholesale gas could have a far-reaching impact on the economy.

## NFL: 'The kid's got skills' - Jason & Osi analyse rookie quarterback Mac Jones
 - [https://www.bbc.co.uk/sport/av/american-football/58608897?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/58608897?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 11:35:04+00:00

Jason Bell and Osi Umenyiora analyse New England Patriots quarterback Mac Jones after an impressive debut against the Miami Dolphins in the NFL.

## Aukus: France recalls envoys amid security pact row
 - [https://www.bbc.co.uk/news/world-europe-58604677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58604677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 11:16:31+00:00

The "exceptional decision" follows a pact between Australia, the US and UK, which scuppered a French deal.

## Australia beat South Africa again to revive Rugby Championship hopes
 - [https://www.bbc.co.uk/sport/rugby-union/58607615?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/58607615?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 11:03:45+00:00

Australia secure their second successive win over world champions South Africa in the Rugby Championship.

## Covid passes: Relief and concern at Wales announcement
 - [https://www.bbc.co.uk/news/uk-wales-58607964?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-58607964?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 11:01:41+00:00

Club owners fear passes may harm Christmas trade, but those at clinical risk say they feel comforted.

## Afghanistan: Girls excluded as Afghan secondary schools reopen
 - [https://www.bbc.co.uk/news/world-asia-58607816?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-58607816?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 10:14:29+00:00

"Everything looks very dark," a schoolgirl tells the BBC as schools reopen for boys but not girls.

## Red Bull in trademark dispute with English gin firm Bullards
 - [https://www.bbc.co.uk/news/uk-england-norfolk-58607923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-58607923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 08:47:04+00:00

The Austrian energy drink company is pursuing a legal challenge over the use of the word "bull".

## US man sought over missing fiancée disappears too
 - [https://www.bbc.co.uk/news/world-us-canada-58607813?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-58607813?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 08:00:30+00:00

Brian Laundrie, a person of interest in the disappearance of Gabby Petito, has gone missing.

## 'Dachshund disco is a children's party for your dog'
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-58547748?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-58547748?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 06:33:38+00:00

Organisers James Morgan and Anushka Fernando want to help dogs socialise again after lockdown.

## Everybody's Talking About Jamie: Sheffield welcomes home coming-of-age story
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-58570178?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-south-yorkshire-58570178?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 06:22:32+00:00

Jamie Campbell salutes Sheffield's role in the story of his extraordinary life.

## Planes turned into graffiti canvasses by street artist
 - [https://www.bbc.co.uk/news/uk-wales-58573703?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-58573703?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 06:00:57+00:00

Street artist Jim Vision had an idea for what to do with planes that have ended their flying days.

## Newcastle boss Bruce battles on after 'difficult' night
 - [https://www.bbc.co.uk/sport/football/58605536?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58605536?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 05:16:08+00:00

Newcastle boss Steve Bruce admits he faced a "difficult" night against Leeds when fans turned on him.

## Robert Durst convicted: US millionaire found guilty of first-degree murder
 - [https://www.bbc.co.uk/news/world-us-canada-58605688?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-58605688?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 05:08:41+00:00

Durst was convicted of killing his best friend Susan Berman in 2000, and is likely to die in prison.

## The papers: Holiday bookings 'surge' and gas price rises
 - [https://www.bbc.co.uk/news/blogs-the-papers-58605201?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-58605201?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 04:41:10+00:00

A boom in holiday bookings following a change to England's travel rules is among the stories leading the papers.

## Climate change: Should green campaigners put more pressure on China to slash emissions?
 - [https://www.bbc.co.uk/news/science-environment-58584976?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-58584976?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 01:01:07+00:00

UK activists have protested on the M25, but should they instead be picketing China's embassy?

## German elections: How Angela Merkel changed her country
 - [https://www.bbc.co.uk/news/world-europe-58597504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58597504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 00:52:24+00:00

Young people have never known another leader, and many worry for the future as old certainties shift.

## Muriel Gardiner: The heiress who saved countless lives
 - [https://www.bbc.co.uk/news/uk-england-london-58399839?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-58399839?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 00:46:47+00:00

Muriel Gardiner's courage fighting fascism in Austria inspired an Oscar-winning film. Who was she?

## Strictly Come Dancing: 15 things we learned from the stars of 2021
 - [https://www.bbc.co.uk/news/entertainment-arts-58271367?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58271367?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 00:44:50+00:00

A round-up of 15 things we learned from this year's Strictly Come Dancing celebrities.

## Week in pictures: 11 - 17 September 2021
 - [https://www.bbc.co.uk/news/in-pictures-58597718?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-58597718?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 00:42:22+00:00

A selection of powerful images from all over the globe, taken this week.

## Lib Dem conference: Sir Ed Davey gambles on targeting Tories
 - [https://www.bbc.co.uk/news/uk-politics-58601889?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-58601889?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 00:28:40+00:00

The Lib Dems are facing a battle to get heard at their online conference but they are in good spirits.

## Ros Atkins On… the ethics of Covid booster jabs
 - [https://www.bbc.co.uk/news/health-58598166?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-58598166?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 00:19:09+00:00

Ros Atkins looks at the ethics of Western countries rolling out Covid booster jabs while millions globally remain unvaccinated.

## Covid calculator spots people vulnerable despite jabs
 - [https://www.bbc.co.uk/news/health-58599482?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-58599482?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-09-18 00:02:11+00:00

An online tool could help doctors identify those who would benefit from boosters or early therapy.

