# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Pfizer Releases Brand New Drug ‘Pfizermectin’
 - [https://www.youtube.com/watch?v=x9Gva3EKB_o](https://www.youtube.com/watch?v=x9Gva3EKB_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-09-10 00:00:00+00:00

Do you have Covid? Then ask your vet, I mean your doctor, about Pfizer’s new drug, Pfizermectin.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## THE BEE WEEKLY: Fact Check Checks and Losing Your Job for Holding Common Opinions
 - [https://www.youtube.com/watch?v=YxDzYa76WqQ](https://www.youtube.com/watch?v=YxDzYa76WqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-09-10 00:00:00+00:00

In this episode of The Bee Weekly, Ethan Nicolle is joined by Adam Yenser to discuss what happened this week, like a man losing his job for expressing an opinion half of Americans have. Also, who will check the fact checkers? There’s weird news, hate mail, and lots of tarantulas.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Racist Club Trilogy
 - [https://www.youtube.com/watch?v=9Yf7fX4m-9c](https://www.youtube.com/watch?v=9Yf7fX4m-9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-09-10 00:00:00+00:00

Can these racists get with the times and discover all the new ways to be racist? Watch all three episodes here and find out!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

