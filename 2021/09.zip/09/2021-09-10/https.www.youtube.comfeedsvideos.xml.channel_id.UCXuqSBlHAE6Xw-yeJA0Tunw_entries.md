# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Unlimited Budget WiFi at My New House
 - [https://www.youtube.com/watch?v=qJeKZkK31JE](https://www.youtube.com/watch?v=qJeKZkK31JE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-11 00:00:00+00:00

Get a 15-day free trial for unlimited backup at https://backblaze.com/LTT

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

The construction at my new "smart" house is underway, and while it's nowhere near move-in ready, we HAD to try out the sick new Ruckus and Ubiquiti-powered WiFi setup. It's gonna blow your mind.

Buy Ruckus R750 Wireless AP
On Amazon (PAID LINK): https://geni.us/vdDI
On Newegg (PAID LINK): https://geni.us/arJN

Buy Ruckus Wireless ZoneFlex T710 Outdoor Wireless AP
On Amazon (PAID LINK): https://geni.us/CGHCFB
On Newegg (PAID LINK): https://geni.us/Gn2K

Buy a UniFi Switch Pro 24 PoE: https://lmg.gg/a1icm

Buy Cabling From Infinite Cables: https://lmg.gg/k4GwH

Buy Fluke Network Testers: https://lmg.gg/Dqvnp

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1372477-my-unlimited-budget-wifi-upgrade/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:35 Backstory
2:57 The Game Plan
4:16 Outdoor WAPs (T710)
5:50 Tracing & Terminating Cables
6:54 The Switch
7:15 Ruckus Unleashed
8:16 Testing Outdoor WAP Range
9:02 Indoor WAPs (R750)
11:45 Preliminary Testing
12:28 The Final Test
14:37 Testing w/ a Single WAP
16:02 Outro

## Apple WON... but also Lost - WAN Show September 10, 2021
 - [https://www.youtube.com/watch?v=1VW0uaoN5Yc](https://www.youtube.com/watch?v=1VW0uaoN5Yc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-10 00:00:00+00:00

Try JumpCloud for free at https://cloud.jumpcloud.com/WANshow

Help your IT team take care of support, maintenance, and security for Enterprise Linux systems with TuxCare at https://hubs.ly/H0WRkfb0

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/wan

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Apple-WON----but-also-Lost---WAN-Show-September-10--2021-e17a83g

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (courtesy of NoKi1119)

[0:00] Chapters.
[1:20] Intro.
[2:10] Topic #1: Apple VS Epic suit is FINALLY over.
    6:26 Tim Sweeney's reaction.
    9:37 Epic's developer Apple account.
    11:02 Effects on the developers and consumers.
[17:26] Topic #2: ProtonMail is not really private.
    23:10 Changes and securing your mail.
[25:30] Sponsors.
    25:34 Jumpcloud Cloud Active Directory.
    28:21 TuxCare Open Source Linux Support.
    29:21 Freshbooks Accounting.
[30:36] Topic #3: The Matrix Resurrections Trailer.
    34:05 Linus criticizes the movie, genre & its' MMO.
    40:51 PS Showcase & Star Wars remake.
    43:12 Grand Theft Auto 5 Enhanced Edition delayed.
[44:31] Topic #4: Facebook smart glasses.
    46:02 Pricing and specs.
    49:19 Better POV videos.
    51:27 Comparing to Google Glass.
[53:28] Topic #5: Valorant anti-cheat & TPM 2.0.
[1:04:47] TechIngredient's thermal paste.
[1:05:36] LTTstore new merch.
[1:07:35] Superchats.
[1:19:06] Wrapping up.
[1:19:51] Outro.

