# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Lofi Remix / 'I'm Your Huckleberry' (Full Song)
 - [https://www.youtube.com/watch?v=YGMasdzlJ9A](https://www.youtube.com/watch?v=YGMasdzlJ9A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-09-11 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Watch the making-of: https://youtu.be/c6Y_QxWWq4k

One of my favourite scenes from the movie Tombstone
"Why Johnny Ringo, You Look Like Somebody Just Walked Over Your Grave."
"I'm Afraid The Strain Was More Than He Could Bear."

Created with:
@teenage engineering   OP-1
 @Korg  Minilogue
 @Korg  Microkorg
 @Moog Music Inc    Sub37
 @1010music   Blackbox & Bluebox
 @strymon   Mobius & Bigsky
and completed in Logic Pro X using stock plugins and instruments.

## The Matrix Remixed / 'Red Pill Blue Pill' (Extended) / Techno Acid Soundtrack
 - [https://www.youtube.com/watch?v=vngVw9Cz2eA](https://www.youtube.com/watch?v=vngVw9Cz2eA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-09-10 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Download this Extended Track: https://gum.co/redpillbluepill
Watch the making-of: https://youtu.be/W89lqLzIOTs

Here's the first time Neo takes the pill.
It all began when Morpheus offered Neo the pills.
“You take the blue pill, the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill, you stay in wonderland, and I show you how deep the rabbit hole goes.

The Matrix Resurrections Trailer: https://youtu.be/9ix7TUGVYIo

