# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Malignant - Movie Review
 - [https://www.youtube.com/watch?v=OjnC9mLNrug](https://www.youtube.com/watch?v=OjnC9mLNrug)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-09-11 00:00:00+00:00

A ridiculous throwback horror movie. Here's my review of MALIGNANT

#MalignantMovie

## The Matrix Resurrections - Trailer 1 (My Thoughts)
 - [https://www.youtube.com/watch?v=VXJRszP6txw](https://www.youtube.com/watch?v=VXJRszP6txw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-09-10 00:00:00+00:00

After years of speculation as to whether or not it will happen....it is happening, and we have the first trailer! Here are my thoughts on the trailer for THE MATRIX RESURRECTIONS!

Watch the trailer here: https://www.youtube.com/watch?v=9ix7TUGVYIo&ab_channel=WarnerBros.Pictures

#TheMatrixResurrections

