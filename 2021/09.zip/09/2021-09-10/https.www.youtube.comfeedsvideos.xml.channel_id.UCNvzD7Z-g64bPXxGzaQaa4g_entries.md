# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 20 NEW Third Person Games of 2021
 - [https://www.youtube.com/watch?v=qwJI44jdPWI](https://www.youtube.com/watch?v=qwJI44jdPWI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-11 00:00:00+00:00

2021 has had tons of cool third-person perspective games for PC, PS5, PS4, Xbox Series X/S/One, and Switch. Here are some of the ones worth checking out.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

20- The Dark Pictures Anthology: House of Ashes 

Release Date : PS4 PS5 PC Xbox One XSX|S 

Platform : 22 October 2021 



19- Samurai Warriors 5 

Release Date : PC PS4 Switch Xbox One 

Platform : July 27, 2021 



18- Knockout City 

Release Date : PC PS4 Switch Xbox One 

Platform : May 21, 2021 



17- Guardians of the Galaxy 

Release Date : PS4 PS5 PC Xbox One XSX|S Switch  

Platform : October 26, 2021



16- Aragami 2 

Release Date : PS4 PS5 PC Xbox One XSX|S 

Platform : September 17, 2021 



15- Solar Ash 

Release Date : PC PS4 PS5 

Platform : October 26, 2021 



14- Ghost of Tsushima: Director's Cut? 

Release Date : August 20, 2021 

Platform : PS5 PS4 



13- Scarlet Nexus 

Release Date : PS4 PS5 PC Xbox One XSX|S 

Platform : June 25, 2021 



12- Hitman 3 

Release Date : PS4 PS5 PC Xbox One XSX|S Switch Stadia 

Platform : 20 January 2021 



11- Monster Hunter Rise 

Release Date : Switch March 26, 2021 

Platform : PC Q1/Q2 2022 



10- NieR Replicant ver.1.22474487139... 

Release Date : PS4 Xbox One PC 

Platform : April 23, 2021 



9- It Takes Two 

Release Date : PS4 PS5 PC Xbox One XSX|S  

Platform : March 26, 2021



8- Returnal 

Release Date : PS5 

Platform : April 30, 2021 



7- Mass Effect Legendary Edition 

Release Date : PC PS4 Xbox One 

Platform : May 14, 2021 



6- Valheim 

Release Date : PC Linux 

Platform : 2 February 2021 (early access) 



5- Ratchet And Clank Rift Apart 

Release Date : PS5 

Platform : June 11, 2021 



4- Psychonauts 2 

Release Date : PS4 Xbox One PC XSX|S 

Platform : August 25, 2021 



3- Little Devil Inside 

Release Date : PC PS4 PS5 Xbox One Switch 

Platform : TBA 2021 



2- Lost Judgment 

Release Date : PS5 PS4 Xbox One XSX|S 

Platform : September 24, 2021 



1- Kena: Bridge of Spirits 

Release Date : PC PS4 PS5 

Platform : September 21, 2021 





BONUS

Alan Wake Remastered

Platform : PC PS5 Xbox One XSX|S 

Release: October 5, 2021


Far Cry 6  [*LIMITED THIRD PERSON PERSPECTIVE]

Platform : PC PS4 PS5 Xbox One XSX|S Amazon Luna Stadia 

Release Date : October 7, 2021

 0:00 INTRO
0:14 The Dark Pictures Anthology: House of Ashes
0:50 Samurai Warriors 5 
1:43 Knockout City 
2:14 Guardians of the Galaxy 
3:14 Aragami 2 
3:56 Solar Ash
4:30 Ghost of Tsushima: Director's Cut
4:57 Scarlet Nexus
5:45 Hitman 3 
6:23 Monster Hunter Rise 
7:01 Nier Replicant
7:41 It Takes Two 
8:14 Returnal 
8:54 Mass Effect Legendary Edition 
9:31 Valheim 
10:14 Ratchet And Clank Rift Apart
10:53 Psychonauts 2
11:20 Little Devil Inside
12:01 Lost Judgment
12:42 Kena: Bridge of Spirits
13:20 Bonus

## 10 BIGGEST Surprises from PS5 Showcase 2021 [4K]
 - [https://www.youtube.com/watch?v=wgLyeG9bVxk](https://www.youtube.com/watch?v=wgLyeG9bVxk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-10 00:00:00+00:00

Sony held a big PS5 showcase events with tons of new game announcements, gameplay, and release dates. From God of War Ragnarok to Wolverine and more- we've got you covered.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## WOLVERINE TRAILER SECRET SPOTTED, PS5 + SERIES X MORE STOCK PROBLEMS, & MORE
 - [https://www.youtube.com/watch?v=bH2vnz_yHCc](https://www.youtube.com/watch?v=bH2vnz_yHCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-10 00:00:00+00:00

Open up a Wealthfront investment account today through my link https://invest.wealthfront.com/gameranx and get your first $5,000 managed for free. Thanks to Wealthfront for sponsoring this video!

Disclosure: Gameranx receives cash compensation from Wealthfront Advisers LLC (“Wealthfront Advisers”)
for sponsored advertising materials. Gameranx is a client and this is a paid testimonial.
Gameranx and Wealthfront Advisers are not associated with one another and have no formal
relationship outside of this arrangement. Nothing in this communication should be construed as
a solicitation, offer, or recommendation, to buy or sell any security. Any links provided by
Gameranx are not intended to imply that Wealthfront Advisers or its affiliates endorses,
sponsors, promotes and/or is affiliated with the owners of or participants in those sites, or
endorses any information contained on those sites, unless expressly stated otherwise.
Investment management and advisory services are provided by Wealthfront, an SEC registered
investment adviser. All investing involves risk, including the possible loss of money you invest,
and past performance does not guarantee future performance.


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

MORE PlayStation event info here (our full breakdown)
https://youtu.be/wgLyeG9bVxk




 ~~~~STORIES~~~~


Wolverine trailer
https://youtu.be/WkKAyThShs8
Wolverine secret:
https://twitter.com/7Spideycomics/status/1436190399010332676

God of War Ragnarok trailer:
https://youtu.be/Ut7FkcpYL74

God of War character lookshttps://mp1st.com/news/god-of-war-ragnarok-thor-and-new-characters-first-look

Spider-Man 2 trailer:
https://youtu.be/-ekYxNjsh5o

KOTOR also on PC
https://twitter.com/LucasfilmGames/status/1436066933032439824?s=20

*FULL PLAYSTATION SHOWCASE HERE: 
https://youtu.be/T5VtfD2i3rc

MORE PlayStation event info here (our full breakdown)
https://youtu.be/wgLyeG9bVxk

More console shortages shortages
https://www.gamesradar.com/ps5-and-xbox-series-x-component-shortages-may-last-until-2023/


Apple Epic ruling
https://www.theverge.com/2021/9/10/22662320/epic-apple-ruling-injunction-judge-court-app-store



WarioWare Get It Together! launch trailer:
 https://youtu.be/Od0RTB_k73w

Tales of Arise:
https://youtu.be/EEKdQgbqg7A


Sifu preview
https://youtu.be/V9h3HvfnbIE

Bayonetta 3 update
https://www.videogameschronicle.com/news/platinum-says-its-proud-of-bayonetta-3-and-wants-to-show-it/

