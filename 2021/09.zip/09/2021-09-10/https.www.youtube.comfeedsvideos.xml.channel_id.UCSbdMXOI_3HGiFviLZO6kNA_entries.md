# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## It's FINALLY HERE! VR Omni-Directional Treadmill... and it's INSANE!
 - [https://www.youtube.com/watch?v=l1zuLwLLHY0](https://www.youtube.com/watch?v=l1zuLwLLHY0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-09-11 00:00:00+00:00

Hello! Today I have my early review of the KatWalk C, the first and only CONSUMER level and priced VR omni-directional treadmill.. well actually its much more like a "slidemill". It took a bit of getting used to but using this slidemill has completely changed the way I look at VR, VR gaming, and VR social cases. It really is probably my favorite peripheral hardware I have ever used (besides maybe full body trackers I suppose). So far I've been loving it and I hope you enjoy my review! Of course there are negatives which I talk about, especially the price at $1400, but still.. it's a ton of fun.

My links:
Join in my discord server:
Discord.gg/Thrill

Check out my streams:
Twitch.tv/Thrilluwu

Outro music:
https://open.spotify.com/track/3zSiHJI0ZCidNR8ygDXQGh?si=b374bab1eed244e0

KatWalk C:
https://www.kat-vr.com/

