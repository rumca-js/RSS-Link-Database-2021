# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Balrogs of Morgoth | Tolkien Explained
 - [https://www.youtube.com/watch?v=bLBd1Z4ktL8](https://www.youtube.com/watch?v=bLBd1Z4ktL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-09-11 00:00:00+00:00

Today, we dive into the history of the Balrogs - from their origins as maiar, to becoming demons who served Morgoth, to their many deeds of the First Age.  We meet Gothmog, the Lord of Balrogs, who kills the elf kings Fëanor and Fingon, before meeting his own demise in Ecthelion.  We also cover Glorfindel's epic fight with a balrog, and how Durin's Bane reached Moria.  We also cover common balrog questions like: how many balrogs were there?  How many balrogs were left after the first age?  What did balrogs actually look like?  All this and more regarding your favorite demons of shadow and flame!

Coupon Code: NERDOFMAPS saves 15% at LordOfMaps.com !
***Be sure to visit our sponsor Lord of Maps to get great deals on some epic maps!***

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark

Shadow and Flame - Anato Finnstark
Balrog - Stephen Najarian
Balrog - Artem Demura
Flame of Udun - Manuel Castanon
The Music of the Gods - Kip Rasmussen
Ainulindale - Anna Kulisz
The Discord of Melkor - Anna Kulisz
Utumno - Korvay Sigel
Balrog - Alvaro Olmos Sierra
Melkor - Anastasiya Cemetery
Balrog - Katerina Andreeva
Bridge of Khazad-dum - Marcos Poncio
War of Wrath - unknown
The Balrogs of Morgoth - Thylacinee
The Defense of Gondolin - Ozakuya
Melkor Destroys the Lamps - unknown
Tulkas - Antonio Vinci
Melkor and Ungoliant - Romero Leo
Beleriand Map - Lamaarcana
The Bargain with Ungoliant - Morkardfc
Morgoth and Ungoliant - Guy Gondron
Ungoliant and Melkor - Ruben Devela
Balrogs defending Morgoth from Ungoliant - Jovan Delic
Dagor Nuin Giliath - Alan Lee
Feanor's Last Stand - Kenneth Sofia
Gothmog vs Fingon - Rui Goncalves
Feanor vs Gothmog, Lord of Balrogs - Bob Greyvenstein
The Death of Feanor - Jenny Dolfen
Gothmog - Andrea Boloch
Balrogs and Glaurung with the Army of Morgoth - Oleg Kuzmin
The Battle of Sudden Flame - Jovandark Art
Gwindor's Charge - Peet
Troll Guard - JM Kilpatrick
Glaurung - Justin Gerard
Gothmog, Lord of Balrogs, Confronts Fingon - Kip Rasmussen
Gothmog - Fingon - Silmarillion - Helge C Balzer
Hurin's Last Stand - Fragoulis Garoufalis
Hurin in his Chair - Alan Lee
Flight of the Doomed - Ted Nasmith
The Fall of Gondolin - Per Sjogren
The Fall of Gondolin - Ralph Damiani
Glorfindel's Bane - Ted Nasmith
Glorfindel and the Balrog - John Howe
Glorfindel and the Balrog - Alan Lee
Glorfindel Duels a Balrog of Morgoth - Kip Rasmussen
Glorfindel vs Balrog - unknown
Balrog - Sander
Ecthelion fighting Gothmog - unknown
Ecthelion - Kamehame
Fall of Gondolin - CK Goksoy
Fountain of Gondolin - Edvige Faini
Balrogs - unknown
War of Wrath - unknown
Balrog - Daniel Govar
Balrog - Mika Koskensalmi
The Balrog - Matt DeMino
Morgoth at the War of Wrath - uknown
Gandalf vs Balrog - Gonzalo Kenny
Feanor fights the Balrogs - Pete Amachree
Balrog at the Bridge - Andrea Alemanno
Balrog - Omer Tunc
The Bridge of Khazad-Dum - Anna Kulisz
Durin VI - Narog Art
The Dwarves Delve Too Deep - Ted Nasmith
Balrog - Nina Butina
Balrog and a dwarf - unknown
Moria - Adam Breen
Sauron - Shadow of War
Morgoth and Fingolfin - Joel Kilpatrick
An Ancient Enemy - Laura Tolton
Dain Ironfoot - WETA
Azanulbazar - unkown
Moria - Cristian Otazu
In the Chamber of Mazarbul - Tulikoura
Moria Escape - unkown
Mines of Moria - JC Barquet
Moria - Donato Giancola
Gandalf in Moria - Donato Giancola
Gimli - Migali Villeneuve
Firewolf - Henriette Boldt
Balrog sketch - unknown
Gandalf Pensive - Donato Giancola
The Bridge of Khazad-dum - unknown
Gandalf and the Balrog - uknown
Khazad-dum - CK Goksoy
Gandalf vs Balrog - Elbardo
Gandalf and the Balrog Upon Celebdil - Ted Nasmith
Gandalf vs Balrog - Nicolas Siner
Balrog of Morgoth - James Bousema
Balrog of Moria - Donato Giancola
Gandalf v Balrog - Gustavo Pelissari
Gandalf and the Balrog - Evolvana
I threw down my enemy - Donato Giancola
Gandalf & Balrog - Julian Nguyen
Balrog Battle - Josu Solano
Gandalf vs Balrog - Minjun Kim

#balrogs #tolkien #lordoftherings

