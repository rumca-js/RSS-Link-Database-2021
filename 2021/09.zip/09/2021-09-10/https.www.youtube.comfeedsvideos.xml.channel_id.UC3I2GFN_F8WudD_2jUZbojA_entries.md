# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Little Simz - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=lz8pNa_YoMc](https://www.youtube.com/watch?v=lz8pNa_YoMc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-09-11 00:00:00+00:00

http://KEXP.ORG presents Little Simz performing live, recorded exclusively for KEXP.

Songs:
Introvert 
Woman 
Venom 
I Love You, I Hate You 
Rolling Stone

Session Recorded and Mixed by Claudio Cueni 
Kadeem 'Kadz Keyz' Clarke - Keys
Osiris 'OTG' Wilson - Vocals / Percussion / DJ 
Emanuel J Burton - Drums 
Kenan Shepherd - Bass 
Chrio Blake - Guitar 

https://www.littlesimz.com
http://kexp.org

## Little Simz - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=ynoR0zEdMe4](https://www.youtube.com/watch?v=ynoR0zEdMe4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-09-10 00:00:00+00:00

http://KEXP.ORG presents Little Simz sharing a live performance recorded exclusively for KEXP and talking to Gabriel Teodros, host of Early on KEXP. Recorded August 26, 2021.

Songs:
Introvert 
Woman 
Venom 
I Love You, I Hate You 
Rolling Stone

Session Recorded and Mixed by Claudio Cueni 
Kadeem 'Kadz Keyz' Clarke - Keys
Osiris 'OTG' Wilson - Vocals / Percussion / DJ 
Emanuel J Burton - Drums 
Kenan Shepherd - Bass 
Chrio Blake - Guitar 

https://www.littlesimz.com
http://kexp.org

