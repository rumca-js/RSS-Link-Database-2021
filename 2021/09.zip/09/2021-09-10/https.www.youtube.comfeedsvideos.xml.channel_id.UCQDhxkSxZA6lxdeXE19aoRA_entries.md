# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Samsung Z Fold 3 Disables Cameras After...
 - [https://www.youtube.com/watch?v=3cSd-2BcUVk](https://www.youtube.com/watch?v=3cSd-2BcUVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-09-11 00:00:00+00:00

I paid $2,500 for this phone but is it really mine if I cannot do what i like with it?
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Get parts, tools and repair guides at iFixit:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau

Tools I Use: https://www.hughjeffreys.com/tools
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

