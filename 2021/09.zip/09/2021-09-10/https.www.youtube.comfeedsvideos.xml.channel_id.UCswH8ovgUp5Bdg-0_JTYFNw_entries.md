# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Did Liberals Use Feminism to Justify Afghan Cluster F*ck?
 - [https://www.youtube.com/watch?v=ASAe4FHyhn4](https://www.youtube.com/watch?v=ASAe4FHyhn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-09-11 00:00:00+00:00

How the mainstream media and CIA weaponised women’s rights to manipulate public perception of the war in Afghanistan. 
#America #Afghanistan #women #war #terror #Blair #Bush 

John Pilger article: 
https://www.newstatesman.com/international-politics/2010/01/afghanistan-war-pilger-obama

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## Are You DISGUSTED By This?! Marine’s VIRAL Video Gets Him Sacked
 - [https://www.youtube.com/watch?v=s0c_qY22BAs](https://www.youtube.com/watch?v=s0c_qY22BAs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-09-10 00:00:00+00:00

Stuart Scheller, a US Marine Corps lieutenant colonel who posted a video demanding accountability from military leaders over Afghanistan has been relieved of his duties and will leave US service
#Afghanistan #taliban #StuartScheller #marine #military

Clip from my Under The Skin interview with Ex Navy SEAL Jocko Willink:  
https://www.youtube.com/watch?v=XpfglTsgEng&ab_channel=RussellBrand

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

