## Biden Doubled Mask Fines for Travelers. What Does it Mean for Passengers? - The New York Times
 - [https://www.nytimes.com/2021/09/10/travel/mask-fine-costs-flights-tsa.html](https://www.nytimes.com/2021/09/10/travel/mask-fine-costs-flights-tsa.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2021-09-10 09:58:33+00:00

Biden Doubled Mask Fines for Travelers. What Does it Mean for Passengers? - The New York Times

