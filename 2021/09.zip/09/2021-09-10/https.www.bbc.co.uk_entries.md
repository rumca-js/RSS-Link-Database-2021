## Hong Kong: Police raid Tiananmen Square museum - BBC News
 - [https://www.bbc.co.uk/news/world-asia-china-58506598](https://www.bbc.co.uk/news/world-asia-china-58506598)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-09-10 06:40:26.261889+00:00

The raid comes a day after four members of the group that ran the venue were arrested.

