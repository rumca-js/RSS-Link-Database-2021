## What if I were 1% charged? | Gravity and Levity
 - [https://gravityandlevity.wordpress.com/2013/05/22/what-if-i-were-1-charged/](https://gravityandlevity.wordpress.com/2013/05/22/what-if-i-were-1-charged/)
 - RSS feed: https://gravityandlevity.wordpress.com
 - date published: 2021-09-10 06:47:40.334136+00:00

In case you hadn’t heard, the universe is governed by four fundamental forces.  But when it comes to understanding nature at almost any level larger than a nucleus and smaller than a planet, …

