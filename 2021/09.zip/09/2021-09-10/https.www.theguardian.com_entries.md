## How 9/11 led the US to forever wars, eroded rights – and insurrection | September 11 2001 | The Guardian
 - [https://www.theguardian.com/us-news/2021/sep/10/september-11-us-reaction-forever-wars-rights-insurrection](https://www.theguardian.com/us-news/2021/sep/10/september-11-us-reaction-forever-wars-rights-insurrection)
 - RSS feed: https://www.theguardian.com
 - date published: 2021-09-10 21:32:03+00:00

How 9/11 led the US to forever wars, eroded rights – and insurrection | September 11 2001 | The Guardian

## The end of phone calls: why young people have silenced their ringtones | Mobile phones | The Guardian
 - [https://www.theguardian.com/technology/2021/aug/30/the-end-of-phone-calls-why-young-people-have-silenced-their-ringtones](https://www.theguardian.com/technology/2021/aug/30/the-end-of-phone-calls-why-young-people-have-silenced-their-ringtones)
 - RSS feed: https://www.theguardian.com
 - date published: 2021-09-10 09:02:30.962546+00:00

A survey has found only a fraction of 16- to 24-year-olds think phone calls are remotely important - so they’ve put their phones on vibrate

