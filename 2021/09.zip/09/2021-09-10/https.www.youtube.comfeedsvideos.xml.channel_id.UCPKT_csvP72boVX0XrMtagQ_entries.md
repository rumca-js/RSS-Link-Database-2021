# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Gorgon City (live) - Skywalk | The Last Cercle Story | Season 1
 - [https://www.youtube.com/watch?v=tVwPcL9MOMA](https://www.youtube.com/watch?v=tVwPcL9MOMA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2021-09-10 00:00:00+00:00

Gorgon City performing the transporting “Skywalk” from Biokovo Skywalk, in Croatia.

This Cercle Stories is part of an art installation in collaboration with Michael Murphy and Samsung, a spiral made of 11 state-of-the-art NeoQLED TVs, suspended in mid-air. 

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ Cercle Records: 
Gorgon City - Skywalk: https://cercle.lnk.to/GorgonCitySkywalk

☞ Gorgon City 
https://www.facebook.com/gorgoncity
https://www.instagram.com/gorgoncity/

☞ Samsung
https://www.samsung.com/perspectives/
https://www.linkedin.com/feed/update/urn:li:activity:6842111174490759169

Video credits:

Artist: Gorgon City 
Location: Biokovo Skywalk 
Produced by: Derek Barbolla
Artist curated by: Philippe Tuchmann
Film Directed by: Pol Souchier
DOP : Maëva Vo Dinh
Editing & Post-production: Mathieu Glissant (Saison Unique Production)
Steadicam Operator :Charlie Moreno
Assistant Operator: Georges Fromont
Drone pilot: Alexis Olas assisted by Mathieu Glissant 
FPV drone pilot: Arthur Maneint
Technical Manager: Aurélien Moisan
Sound Mastering: Tomislav Zubak
Photographe : Marko Edge 
BTS : Mickaël Fidjili
Production team: Anaïs de Framond, Dan Aufseesser, Armand Prouhèze
Communication: Bérénice Saïag
Graphic Design: Anaëlle Rouquette
CFO: Andy Cheremont
Label Assistant: Clémence Maillard

--

Official Partners: 
Samsung
Michael Murphy 
Visit Croatia 

--
Special thanks to:

Tom Cane
Greg Burnell
Georgina Fennessy
Dalibor Zjačić
Ksenija Protrka
Tomislav Lešćan
Laura Hobern
Saatchi Gallery
Galerie Joseph

______

Follow us on http://www.cercle.io

