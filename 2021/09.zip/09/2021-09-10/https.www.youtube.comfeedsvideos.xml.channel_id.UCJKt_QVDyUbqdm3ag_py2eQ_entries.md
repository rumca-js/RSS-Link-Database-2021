# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Dynamix - Moving Underground (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=JTZo4cxbzj4](https://www.youtube.com/watch?v=JTZo4cxbzj4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-09-11 00:00:00+00:00

"Moving Underground" (1996) by Dynamix/Destiny (Joost Jacobs). Art "Nature Calls" (2019) by Facet.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 20 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Keith303 - Eer Amak et Amorv'e! (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=fvvuWfaw-Yo](https://www.youtube.com/watch?v=fvvuWfaw-Yo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-09-11 00:00:00+00:00

"Eer Amak et Amorv'e!" (1996) by Keith303/Radical Rhythms etc. (Klaus Spang). Art "Ladies" (1996) by Norm.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 18 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

