# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Mazury - rowerem wśród zamków i jezior🚴‍♂️💨 Wielka pętla warmińsko-mazurska z Tatą!
 - [https://www.youtube.com/watch?v=j1J6XE0auLA](https://www.youtube.com/watch?v=j1J6XE0auLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-09-05 00:00:00+00:00

Książka "Rower to jest Świat"📙👉 https://rowertojestswiat.pl/

Kolejna rowerowa przygoda, podczas której szukamy ciekawych miejsc, zwłaszcza świetnie nadających się na wycieczki rowerowe. Wszystko to pod książkę, którą planuję napisać, także jeśli interesują Cie podróżnicze, rowerowe klimaty - zerknij tutaj 📙👉 https://kolemsietoczy.pl/ksiazka/

Chcesz nauczyć się tworzyć ciekawe i efektowne filmy, od których ciężko oderwać wzrok? Nie tylko podróżnicze? :) Zapraszam do swoich kursów

Kurs filmowania i montażu 🎬 https://www.kursfilmowaniaimontazu.pl/
Dodatek Podróżniczy 🎬 http://filmypodroznicze.pl/

Dzisiejszy film jest efektem naszej 5-dniowej wycieczki rowerowej przez Warmię i Mazury. Wystartowaliśmy sobie Łynostradą z Olsztyna i do tego miasta wróciliśmy zataczając pętlę. Po drodze odwiedziliśmy wiele ciekawych miejsc zarówno na Warmii, jak i już na Mazurach i w okolicy Wielkich mazurskich Jezior, ale szczególnie wypatrywaliśmy na horyzoncie zamków gotyckich, których jest zarówno na Warmii jak i Mazurach co nie miara. Szczególnie polecam te ostatnie - bo mazurskie jeziora zna każdy i każdy po nie tutaj jeździ, ale zamki? Wydaje mi się, że niekoniecznie :)

Wpis z Mazur i Warmii:
https://kolemsietoczy.pl/mazury-warmia-rowerem-trasy-szlaki-ciekawe-miejsca-mazurach

Muzyka:  Artlist oraz Nevaeh

0:00 Wstęp 
00:32 - Warmia - Olsztyn
01:15 - Łynostrada
03:26 - Zamki Gotyckie na Mazurach
04:09 - Mazury ciekawe miejsca
07:02 - Mazury - Wilczy Szaniec
08:09 - sprzedam rower
11:33- Giżycko i herb... ale Mrągowa
13:25 - Mazury rowerem - Ryn
15:31 - Trasy rowerowe na Mazurach - Mrągowo
17:41 - Noclegi na Mazurach

