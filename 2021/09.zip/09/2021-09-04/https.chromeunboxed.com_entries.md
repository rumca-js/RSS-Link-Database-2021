## Windows 11 Insider Preview makes it more difficult for users to default to Chrome
 - [https://chromeunboxed.com/windows-11-insider-preview-chrome-default-difficulties](https://chromeunboxed.com/windows-11-insider-preview-chrome-default-difficulties)
 - RSS feed: https://chromeunboxed.com
 - date published: 2021-09-04 15:05:44+00:00

Now that the Edge browser is built on Chromium, you'd think it would be virtually identical to Chrome, but both Google and Microsoft have maintained separate and quite distinct experiences even though their development teams are working closely together. For example, Edge implemented coupon hunting before Chrome added it to its new tab page modules...

