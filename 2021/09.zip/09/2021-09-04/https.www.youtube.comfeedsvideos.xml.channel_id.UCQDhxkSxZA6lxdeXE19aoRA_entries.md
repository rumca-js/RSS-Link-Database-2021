# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## How This Incredible Under Screen Camera Works - Axon 30 Teardown
 - [https://www.youtube.com/watch?v=CdjHdN9plFE](https://www.youtube.com/watch?v=CdjHdN9plFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-09-04 00:00:00+00:00

Lets see how ZTE's next level under screen selfie camera works!
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
This video was made using a review device provided by ZTE.
ZTE had no editorial input and isn’t providing me with any compensation for producing the video.
ZTE official website: https://bit.ly/2W0hZNm

Get parts, tools and repair guides at iFixit:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau

Tools I Use: https://www.hughjeffreys.com/tools
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

