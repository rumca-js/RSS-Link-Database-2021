# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## How To Charge Anime Energy In BOTW
 - [https://www.youtube.com/watch?v=pqVvD5e0ljA](https://www.youtube.com/watch?v=pqVvD5e0ljA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-09-05 00:00:00+00:00

One of the newest finds in Breath of the Wild has some utility use, but most of all, looks pretty awesome, and brings some anime themes to the game.

Discovered by Satougashi in June 2021, Active Arrow Smuggling, while purely a cosmetic bug, is surely one of the coolest looking glitches found so far. Breath of the Wild continues to show new discoveries, intended and unintended, and we continue to cover them still to this day.

#botw #zeldabotw

## Battlefield 2042 Gameplay Finally Shows Specialists In Action | GameSpot News
 - [https://www.youtube.com/watch?v=vQOErPdS5_c](https://www.youtube.com/watch?v=vQOErPdS5_c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-09-04 00:00:00+00:00

Persia talks about new gameplay revealed for Battlefield 2042, Hideo Kojima’s Director’s Cut trailer for Death Stranding which releases September 8th, Fortnite's end of Season 7 live event, and an adorable new update for Ghosts of Tsushima.

In this video, Persia talks about the new gameplay of Battlefield 2042 that was released along with plans to change Falck’s Syrette pistol after feedback from the alpha. 

She also covers the Director’s Cut trailer released on September 8th that was edited by Hideo Kojima himself and also discusses Fortnite’s upcoming event Operation: Sky Fire. This event will bring Fortnite Chapter 2 to a close and will be a limited-time event.

Lastly, Persia talks about a very important and very adorable update for Ghosts of Tsushima that adds new charm to its foxes of Ikki Island with heart-melting animations.

Intro - 00:00 
Battlefield 2042 - 00:19
Death Stranding - 01:22 
Fortnite - 02:28
Ghosts of Tsushima - 03:28 
Outro - 04:24

You can read more about all of today’s topics on gamespot.com

#Battlefield2042 #Battlefield

## Everything We Know about DokeV
 - [https://www.youtube.com/watch?v=nqTvgrKGx-8](https://www.youtube.com/watch?v=nqTvgrKGx-8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-09-04 00:00:00+00:00

DokeV's latest trailer was unleashed during Gamescom and its exciting style, world, and similarities to Pokemon have gotten people excited. But, what exactly do you do in the game? Here's everything we know so far.

One of Gamescom’s biggest trailers this year was for an upcoming game titled DokeV. The trailer was fun, stylish, and flashy—and had Pokemon in a big city vibes. But ultimately, we still don’t know all that much about the game. So, what the heck is DokeV… and why am I so excited about a trailer that ultimately didn’t really show actual gameplay?

#DokeV

## Firearms Expert Reacts To Fallout 4’s Guns
 - [https://www.youtube.com/watch?v=5FVzcoRjoN4](https://www.youtube.com/watch?v=5FVzcoRjoN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-09-04 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the weaponry of Fallout 4, including a selection of the game’s bizarre pipe-based firearms, the infamous 10mm pistol, and the man-portable cannon, the Broadsider.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down the guns of Fallout 4 and compares them to their real-life counterparts.

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can either purchase Jonathan's book here. - https://www.headstamppublishing.com/bullpup-rifle-book

Or at the Royal Armouries shop here. - https://shop.royalarmouries.org/collections/thorneycroft-to-sa80-british-bullpup-firearms-1901-2020

#firearms #fallout4 #royalarmouries

