# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Tether Is Hiding Something...
 - [https://www.youtube.com/watch?v=WgJjf4HaRsk](https://www.youtube.com/watch?v=WgJjf4HaRsk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-09-05 00:00:00+00:00

COFFEEZILLA RESERVES ARE 1:1 BACKED BY REAL SUBSCRIBERS GUARANTEED. --- pump $ZILLA to find out any updates with TETHER.

Tether calls itself "Digital money for a digital age Global, fast, and secure" and "unrivaled in transparency". 

But is that actually true? I FOIL'd the NYAG office to get the documents behind the New York Attorney General's investigation... and what happened next surprised me. 

Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryBagg96

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

