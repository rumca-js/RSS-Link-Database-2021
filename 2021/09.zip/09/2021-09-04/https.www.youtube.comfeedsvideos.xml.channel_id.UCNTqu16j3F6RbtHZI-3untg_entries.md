# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## The Dark Reality of Los Angeles
 - [https://www.youtube.com/watch?v=cdkvvafeMzk](https://www.youtube.com/watch?v=cdkvvafeMzk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2021-09-04 00:00:00+00:00

We've all heard about the problems of Los Angeles, but I wanted to see it for myself. Beneath the veneer of Hollywood and entertainment lies a dark reality we are often blind to. The first part to a new docu-series Im working on about the Promised Land of Los Angeles.

00:00 Intro
02:28 Trouble In Paradise
04:11 American Idol
10:06 Veterans of War
17:10 War On Poverty
23:00 A House, Not A Home
26:42 With Open Eyes
27:34 Outro

Intro song: https://youtu.be/Ig-4StuBfSE

Join this channel to get access to perks:
https://www.youtube.com/channel/UCNTqu16j3F6RbtHZI-3untg/join

The G-Links:

twitter.com/GlinkLive

Twitter, where I publish all my hot takes and dank memes

reddit.com/r/glink/

Reddit, nobody uses this, but you can post memes here

instagram.com/glink_between_worlds/

Instagram, this is where things get real  a e s t h e t i c 

https://discord.gg/xtwYypf
My Discord, only for REAL gamers

patreon.com/Glink

Support me on Patreon and be included in Q & As, audio updates, discord roles, and credits at the end of my videos 

teespring.com/stores/shop-glink

Want to look fly while supporting my channel? Buy a T-shirt or poster here, all designs are custom made and completely original, not mention tasteful and artistic

youtube.com/channel/UChJT4Jg89AHMyybcXFeKp_A

Gush - the podcast where me and Slush share stories with bold creators and brave influencers

