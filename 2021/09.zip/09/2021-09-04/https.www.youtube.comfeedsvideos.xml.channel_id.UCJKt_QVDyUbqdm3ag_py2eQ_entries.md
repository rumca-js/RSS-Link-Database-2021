# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Wacek - A 1000 Years of Darkness (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=qyX7mXZyni0](https://www.youtube.com/watch?v=qyX7mXZyni0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-09-05 00:00:00+00:00

"A 1000 Years of Darkness" (2020) by Wacek/Arise (Adam Waclawski). Art "Vampire" (1994) by Mirage.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- 1-bit fast interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 28 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga music: Mygg & Bonefish - 2 Days Later (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=7RgNBdCkoFg](https://www.youtube.com/watch?v=7RgNBdCkoFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-09-05 00:00:00+00:00

"2 Days Later (final)" by Mygg & Bonefish (Jonas Sarvik & Vlado Banda), 2nd at Edison 2021. Art "Sure Shot" (1997) by Made.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

