# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Fëanor | Tolkien Explained
 - [https://www.youtube.com/watch?v=oe7mFrL4hBw](https://www.youtube.com/watch?v=oe7mFrL4hBw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-09-04 00:00:00+00:00

Fëanor is considered the greatest of the Noldor.  He not only created the Palantíri and the Fëanorian lamps, but also the Silmarils - his greatest creation, and the namesake of The Silmarillion.  In this video, we track his life and travels, from his birth in Aman to becoming the great craftsman - from becoming King of the Noldor to leading his people in their exile - and finally, his fatal battle with the balrogs of Morgoth.

*Hit subscribe - and the bell!* 
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark

Heart of Feanor - Venlian
The Making of the Silmarils - Anna Kulisz
Feanor - Kenneth Sofia
Let the Havens Burn - Sirielle
The Oath of Feanor - Jenny Dolfen
Feanor - Bella Bergolts
Miriel and Feanaro - Francesco Amadio
Feanor Mourning Miriel - Steamey
Finwe and Indis - Alystraea
Young King Feanor - Venlian
Feanor - Yi Jong
Spirit of Fire - Jenny Dolfen
Feanor - Ryszard
Feanor - Ji You Zhong
Feanor and the Palantir - Kseniya Dol
Aragorn and the Palantir - Magli Villeneuve
Silver Lamp - Owen William Weber
Tuor, Gelmir, and Arminas - Ted Nasmith
In the Forest Under Night, Gwindor in Taur-nu-Fuin - Matt Stewart
Feanor - Lucio Parrillo
Feanor and Nerdanel - Pekaqueen
Meeting of Feanor and Nerdanel - Antti Autio
Melkor - Kimberly80
Melkor and Feanor - Pajalie
Feanor - Felix Sotomayor
The Two Trees Doom - Ted Nasmith
Trees of Valinor - Helen Kei
Artanis and Feanor - Tolman Cotton
Feanor - Wyn Estelle
The Silmarils - Lida Holubova
Feanor and the Silmarils - Alexey Rudikov
Feanor, Melkor, and Silmarils - Kaprriss
Lies - Simona Brunilde Jero
Fingolfin - Tolrone
Feanor close up - Maria Lombide Ezpeleta
Melkor teaches the Noldor to manufacture arms - Ivana Lekseich
Get thee gone, and take thy due place! - Jenny Dolfen
Half-Brothers - Tuuliky
Feanor - Bella Bergolts
The Threat of Feanor - Antti Autio
Melkor - Thomas Rouillard
Melkor and the Silmarils - Sara M Morello
Melkor at the gates of Formenos - Nequaril
Manwe Sulimo - Gustavo Malek
Feanor and Fingolfin - Kaprriss
Yavanna mourns dead trees - Valentina Mustajarvi
Manwe, king of the world and the breath of arda - Dymond Starr
Feanor - Catherine Karina Chmiel
Feanor - Luis F Bejarano
Formenos - Vunasti Mamut
Melkor - Fumeres Art
Feanor, Noldor King - Venlian
Feanor - Natalie Chen
The Oath of Feanor - Bella Bergolts
The Oath of Feanor - Antti Autio
The Oath of Feanor - Edarlein Art
Twin Trees of the Valar - Etherium Apex
Feanor (The Oath) - Angel Falto
At Lake Cuivienen - Ted Nasmith
Noldor - Cleisson de Oliveira
Tirion - Anubis1000
Beleriand Map - Lamaarcana
Feanor - Maria Kizimenko
Feanor - Clement Ribeyre Soret
Lord of the Gems - Mami02
The Oath Has Been Awakened - Jenny Dolfen
Alqualonde - Ted Nasmith
The Curse of Mandos - Lourdes Velez
The Burning of the Ships - Ted Nasmith
In the Name of the Oath! - Steamey
Feanor - Noei1984
Feanor's Last Stand - Kenneth Sofia
Feanor fights the balrogs - Pete Amachree
Feanor's last stand - Jenny Dolfen
Feanor and Gothmog - Guisadong Gulay
Fingolfin Rides to Angband - Kenneth Sofia
Death of Feanor - Jenny Dolfen
Yavanna - Gustavo Malek

For more on Feanor, check out:
The Silmarillion
The Encyclopedia of Arda
Tolkien Gateway

#feanor #tolkien #silmarillion

