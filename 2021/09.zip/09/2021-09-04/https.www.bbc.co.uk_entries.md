## Covid: What do parents think about vaccinating children? - BBC News
 - [https://www.bbc.co.uk/news/uk-58447040](https://www.bbc.co.uk/news/uk-58447040)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-09-04 15:26:59.005063+00:00

Parents share their thoughts on the prospect of offering Covid vaccines to all 12 to 15-year-olds.

## 'I've eaten the same breakfast for the last 22 years' - BBC News
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-business-58323888](https://www.bbc.co.uk/news/uk-scotland-scotland-business-58323888)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-09-04 15:25:08.557608+00:00

A veteran hotel inspector reveals the highs and lows of working undercover in Scotland.

