# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Caitlyn Smith - three songs for The Current (2020)
 - [https://www.youtube.com/watch?v=6ZhIqK__OYk](https://www.youtube.com/watch?v=6ZhIqK__OYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-09-04 00:00:00+00:00

On Sunday, Sept. 5, the Amateur Talent Contest finals take place at the Grandstand at the Minnesota State Fair. Nashville singer-songwriter Caitlyn Smith — who grew up in Cannon Falls, Minn., in Goodhue County — won the Minnesota State Fair's Amateur Talent Contest in 2001 as a 15-year-old. 

Smith has gone on to an excellent career in music, and last year, just after the release of her album "Supernova," Smith connected with The Current's Bill DeVille for a virtual session in which Smith performed tracks from that album. Watch three of these up-close-and-personal performances recorded right in Smith's home in 2020. On the final song, "Long Time Coming," Smith is accompanied on piano by her husband, musician Rollie Gaalswyk.

SONGS PERFORMED
0:00 "Feel That Way"
4:37 "Lonely Together"
8:29 "Long Time Coming"

PERSONNEL
Caitlyn Smith – vocals, guitar, piano
Rollie Gaalswyk – piano on "Long Time Coming"

FIND MORE:
2017 Local Current story:
https://blog.thecurrent.org/2017/11/caitlyn-smith-talks-about-chasing-that-perfect-song-from-cannon-falls-to-nashville/
2018 studio session: https://www.thecurrent.org/feature/2018/03/05/caitlyn-smith-performs-in-the-current-studio-live-music
2018 Guitar Collection interview:
https://www.thecurrent.org/feature/2018/03/15/talking-guitars-and-songwriting-with-caitlyn-smith
2018 (April) feature story:
https://www.thecurrent.org/feature/2018/04/18/caitlyn-smith-comes-home-cannon-falls
2018 (August) feature story:
https://www.thecurrent.org/feature/2018/08/28/from-state-fair-to-starfire-caitlyn-smith-recalls-minnesota-state-fair-talent-show
2020 interview with Jill Riley: https://blog.thecurrent.org/2020/03/caitlyn-smith-im-keeping-my-eyes-on-the-future/
2020 virtual session:
https://www.thecurrent.org/feature/2020/06/15/live-virtual-session-caitlyn-smith

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#caitlynsmith

