## Rejected internal applicants twice as likely to quit | Cornell Chronicle
 - [https://news.cornell.edu/stories/2021/08/rejected-internal-applicants-twice-likely-quit](https://news.cornell.edu/stories/2021/08/rejected-internal-applicants-twice-likely-quit)
 - RSS feed: https://news.cornell.edu
 - date published: 2021-09-04 09:48:11.744999+00:00

Internal job applicants who face rejection are nearly twice as likely to leave their organizations than those who were either hired for an internal job or had not applied for a new job at all, ILR School research finds.

