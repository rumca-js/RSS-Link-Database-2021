# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Trying TikTok Computer Hacks...
 - [https://www.youtube.com/watch?v=05K5glVCwis](https://www.youtube.com/watch?v=05K5glVCwis)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-05 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Personalize your PC with Cablemod at https://lmg.gg/FWai3 

Wanting to remain current and hip we investigate the tech tips of TikTok.

Buy Samsung Odyssey G9
On Amazon (PAID LINK): https://geni.us/8AL0p
On Best Buy (PAID LINK): https://geni.us/724Bp8c
On Newegg (PAID LINK): https://geni.us/8cZI

Buy 1TB HDD
On Amazon (PAID LINK): https://geni.us/bbAxqU
On Best Buy (PAID LINK): https://geni.us/p3ee
On Newegg (PAID LINK): https://geni.us/OZUBrN

Buy Dell XPS 15
On Amazon (PAID LINK): https://geni.us/z0NieS
On Best Buy (PAID LINK): https://geni.us/XGxX
On Newegg (PAID LINK): https://geni.us/SUPuo7

Buy HP ZBook Studio
On Amazon (PAID LINK): https://geni.us/lAz8ZUj
On Newegg (PAID LINK): https://geni.us/AWNU3s
On B&H (PAID LINK): https://geni.us/K2Bxd

Buy Xtrfy M42
On Amazon (PAID LINK): https://geni.us/IkUe
On Newegg (PAID LINK): https://geni.us/bqQMLD

Purchases made through some store links may provide some compensation to Linus Media Group.

Software tools mentioned in-video

Get Ninite here: https://ninite.com/
Get WinDirStat here: https://windirstat.net/
Get the sleeker, faster cousin of WinDirStat - WizTree - here: https://diskanalyzer.com/
Get ShareX here: https://getsharex.com/
Instructions for play video on login: https://community.spiceworks.com/topic/2196026-windows-10-play-a-video-upon-login-before-loading-the-desktop
Paste multiple things using Win+V instead of Ctrl+V
Reset GPU drivers with Win+Shift+Ctrl+B

Discuss on the forum: https://linustechtips.com/topic/1370910-trying-tiktok-computer-hacks/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:57 DVR HDD hack
4:45 Storage Space hack
6:40 "hacking" hacks
9:46 Homework folder
10:53 Inspect element with extra steps
11:23 Headphone warning
12:16 We hate you Dbrand
12:40 Video on wake 
14:02 Memory profiles 
14:43 Multiple clipboard entries - Windows key+V
15:05 Reset GPU drivers Win+Ctrl+Shift+B

## DLSS Swapper makes your games look better!
 - [https://www.youtube.com/watch?v=IXir0Y86N84](https://www.youtube.com/watch?v=IXir0Y86N84)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-04 00:00:00+00:00

Get 20% OFF + Free Shipping @manscaped at https://manscaped.com/TECH

Sign up for Linode to get your $100 in 60-day credit at https://www.linode.com/linus

DLSS has been around for a while now, and while Nvidia has improved it continuously, games almost never update the version they use. But now there’s a very simple way to do it for yourself…

Buy RTX 3080: https://geni.us/EVAxc0b

Purchases made through some store links may provide some compensation to Linus Media Group.

Check out DLSS Swapper here: https://github.com/beeradmoore/dlss-swapper

Check out Nvidia DLSS DLL's here: https://www.techpowerup.com/download/nvidia-dlss-dll/

Discuss on the forum: https://linustechtips.com/topic/1370649-how-to-upgrade-your-graphics-for-free/

What's a "Pitot Tube" at 5:42? They're actually pretty cool - https://www.youtube.com/watch?v=pwEZfmAVLd8 

► GET MERCH: lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxm...
iTunes Download Link: https://itunes.apple.com/us/album/sup...
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGB...
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnir...

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:33 Rage Anthony
1:00 DLSS Versions
1:25 DLSS Swapper
2:20 The Swap
4:23 Testing observations
8:07 Why DLSS Swapper?
8:52 What's next?

