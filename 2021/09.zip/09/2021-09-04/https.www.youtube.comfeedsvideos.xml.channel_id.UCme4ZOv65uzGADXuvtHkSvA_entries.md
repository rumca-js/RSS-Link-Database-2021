# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Księga Liczb || Rozdział 14
 - [https://www.youtube.com/watch?v=TlHKu-zlQLA](https://www.youtube.com/watch?v=TlHKu-zlQLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-05 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#250] Jezu, westchnij za mną!
 - [https://www.youtube.com/watch?v=0qG7Lz85fZc](https://www.youtube.com/watch?v=0qG7Lz85fZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-04 00:00:00+00:00

XXIII Niedziela zwykła, Rok B

Komentarz do czytań, czyli kazanko do okienka

1. czytanie (Iz 35, 4-7a)

Powiedzcie małodusznym: «Odwagi! Nie bójcie się! Oto wasz Bóg, oto pomsta; przychodzi Boża odpłata; On sam przychodzi, by was zbawić».
Wtedy przejrzą oczy niewidomych i uszy głuchych się otworzą. Wtedy chromy wyskoczy jak jeleń i język niemych wesoło wykrzyknie. Bo trysną zdroje wód na pustyni i strumienie na stepie; spieczona ziemia zmieni się w pojezierze, spragniony kraj w krynice wód.

2. czytanie (Jk 2, 1-5)

Bracia moi, niech wiara wasza w Pana naszego, Jezusa Chrystusa uwielbionego, nie ma względu na osoby. Bo gdyby przyszedł na wasze zgromadzenie człowiek przystrojony w złote pierścienie i bogatą szatę i przybył także człowiek ubogi w zabrudzonej szacie, a wy spojrzycie na bogato przyodzianego i powiecie: «Ty usiądź na zaszczytnym miejscu», do ubogiego zaś powiecie: «Stań sobie tam albo usiądź u podnóżka mojego», to czy nie czynicie różnic między sobą i nie stajecie się sędziami przewrotnymi?
Posłuchajcie, bracia moi umiłowani! Czy Bóg nie wybrał ubogich tego świata na bogatych w wierze oraz na dziedziców królestwa przyobiecanego tym, którzy Go miłują?

Ewangelia (Mk 7, 31-37)

Jezus opuścił okolice Tyru i przez Sydon przyszedł nad Jezioro Galilejskie, przemierzając posiadłości Dekapolu. Przyprowadzili Mu głuchoniemego i prosili Go, żeby położył na niego rękę. On wziął go na bok, z dala od tłumu, włożył palce w jego uszy i śliną dotknął mu języka; a spojrzawszy w niebo, westchnął i rzekł do niego: «Effatha», to znaczy: Otwórz się. Zaraz otworzyły się jego uszy, więzy języka się rozwiązały i mógł prawidłowo mówić. Jezus przykazał im, żeby nikomu nie mówili. Lecz im bardziej przykazywał, tym gorliwiej to rozgłaszali. I przepełnieni zdumieniem mówili: «Dobrze wszystko uczynił. Nawet głuchym słuch przywraca i niemym mowę».

#cnn #dobrewiadomości #kazankodookienka #słowonaniedzielę 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Liczb || Rozdział 13
 - [https://www.youtube.com/watch?v=EekcYVYRZRA](https://www.youtube.com/watch?v=EekcYVYRZRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-04 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#881] Trwać
 - [https://www.youtube.com/watch?v=vUDUNy5agHo](https://www.youtube.com/watch?v=vUDUNy5agHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-09-04 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

