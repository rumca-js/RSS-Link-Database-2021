# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Beginning and end
 - [https://www.youtube.com/watch?v=VL8QnUM81Wo](https://www.youtube.com/watch?v=VL8QnUM81Wo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-09-05 00:00:00+00:00

Link for you to vote on viral origins, https://www.youtube.com/c/Campbellteaching/community

US intelligence community, Unable, split on viral origins
https://www.bbc.com/news/world-us-canada-58361211
18 agencies, Office of the Director of National Intelligence

Time is running out to gather evidence

WHO panel

Soon, biologically impossible

The window of opportunity for conducting this crucial inquiry is closing fast

All agencies assess that two hypotheses are plausible: natural exposure to an infected animal and a laboratory-associated incident

Several agencies

natural exposure to an animal infected with it or a close progenitor virus, low confidence

One intelligence agency

moderate confidence, that the first human infection was likely due a "laboratory-associated incident" at the Wuhan Institute of Virology, 

which has studied coronaviruses in bats for more than a decade.

President Biden

Critical information about the origins of this pandemic exists in the People's Republic of China, 

yet from the beginning, government officials in China have worked to prevent international investigators and members of the global public health community from accessing it

The world deserves answers, and I will not rest until we get them

China

Foreign minister, anti-science

Fort Detrick hypothesis

https://www.youtube.com/c/Campbellteaching/community

 


Endgame and exit strategy

https://www.washingtonpost.com/politics/covid-how-will-it-end/2021/09/04/44bdd69a-fed7-11eb-a664-4f6de3e17ff0_story.html

Professor Monica Gandhi, University of California

I truly, truly think we are in the endgame

The cases will start plummeting in mid- to late September 

they mutate quickly, at a cost to themselves

we’re sort of at the peak of the pandemic because the delta variant is causing immunity like crazy

Delta comes in like a hurricane, but it leaves a lot of immunity in its wake

we’re going to get it

Unless you just sit in your room, you’re going to get it in your nose

but at least in this country, it will be manageable

Gandhi (Feb, 2020)

United States would not tolerate a disease that killed 100 Americans a day; people would come together to do whatever it took to stop that

Professor Ezekiel Emanuel, University of Pennsylvania

In March 2020, the country back to normal around November 2021

Now, It’s going to be at least spring 2022 and possibly much longer before most people are ready to resume normal activities

Professor Jay Bhattacharya, Stanford University

The emergency phase of the disease is over

Now, we need to work very hard to undo the sense of emergency. 

We should be treating covid as one of 200 diseases that affect people

Signed Great Barrington Declaration (4th October 2020)

https://gbdeclaration.org

(With Martin Kulldorff (Harvard) and Sunetra Gupta (Oxford)

## Delta plus and long covid
 - [https://www.youtube.com/watch?v=KlxFfiJsEfM](https://www.youtube.com/watch?v=KlxFfiJsEfM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-09-04 00:00:00+00:00

Delta plus, First identified in India in 2020

https://www.bbc.com/news/world-asia-india-57564560

India and Europe classified a new VOV

AY.1, additional mutation K417N (Aldo found in Beta, SA stain)

India says, spreads more easily, binds more easily to lung cells, potentially resistant to monoclonal antibody therapy

No data to be over concerned now

USA, UK, Portugal, Switzerland, Japan, Poland, Nepal, Russia, China

Long covid and vaccination

https://covid.joinzoe.com/post/double-covid-vaccination-halves-risk-of-long-covid

Risk factors and disease profile of post-vaccination SARS-CoV-2 infection in UK users of the COVID Symptom Study app: a prospective, community-based, nested, case-control study

https://www.sciencedirect.com/science/article/pii/S1473309921004606

Double vaccination

31% less likely to experience acute COVID symptoms

47% less likely to get Long COVID if they become infected

73% less likely to be hospitalised

Most common symptoms

Similar to unvaccinated adults

Anosmia, cough, fever, headaches, fatigue

All milder and less frequently

Half as likely to get multiple symptoms in the first week of illness

Sneezing, only symptom more common in vaccinated

Tim Spector

Vaccinations are massively reducing the chances of people getting Long COVID in two ways. 

Firstly, by reducing the risk of any symptoms by 8 to 10 fold 

and then by halving the chances of any infection turning into Long COVID, if it does happen.

We are encouraging people to get their 2nd jab as soon as they can

Sajid Javid

COVID-19 vaccines have saved more than 105,000 lives and prevented over 24 million infections in England alone

This research is encouraging, suggesting vaccines are not only preventing deaths but could also help prevent some of the longer lasting symptoms

80 long COVID assessment services have opened across England

It is clear vaccines are building a wall of defence against the virus and are the best way to protect people from serious illness

Australia

https://www.bbc.com/news/world-australia-58406526

Prime Minister Scott Morrison

Time to leave lockdowns

Come out of the cave, live with the virus

Radical change from ‘fortress Australia’

‘Covid zero’

E.g. Melbourne, 200 days of lockdown over 2 years

Now

Vaccinating fact

All over 12years

Ease out of lockdowns

Vaccinated people, more freedoms

Continue testing and tracing

Retain low-level restrictions, mask-wearing, social distancing

Borders open at 80% threshold double dosage

?? December

Prof Ivo Mueller, Melbourne

The plan that is proposed is actually very thoughtful and careful

It's not 'Freedom Day, it's not let's throw everything out the window and go party

Predicted

13 – 1,500 deaths in 6 months

