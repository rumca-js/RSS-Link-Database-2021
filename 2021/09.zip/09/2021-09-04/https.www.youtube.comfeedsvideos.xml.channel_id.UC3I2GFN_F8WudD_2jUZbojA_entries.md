# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Flyying Colours - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=N1kzLn2jgVM](https://www.youtube.com/watch?v=N1kzLn2jgVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-09-04 00:00:00+00:00

http://KEXP.ORG presents Flyying Colours performing live, recorded exclusively for KEXP. 

Songs:
1987
Not Today
Big Mess
White Knuckles

Session recorded and performed at Red Door Sounds in Collingwood, Australia
Recorded by Woody Annison
Video produced by Wild Rose
Camera operators: Aidan McDonald, Robert 'squid' Collins, Tori Styles & Scott Marrinan

Brodie J Brümmer - guitar, vocal
Gemma O'Connor - guitar, vocal
Melanie Barbaro - bass guitar
Andy Lloyd-Russell - drums

https://flyyingcolours.square.site
http://kexp.org

## Flyying Colours - White Knuckles (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=JwKJZO6vCLc](https://www.youtube.com/watch?v=JwKJZO6vCLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-09-04 00:00:00+00:00

http://KEXP.ORG presents Flyying Colours performing "White Knuckles" live, recorded exclusively for KEXP. 

Session recorded and performed at Red Door Sounds in Collingwood, Australia
Recorded by Woody Annison
Video produced by Wild Rose
Camera operators: Aidan McDonald, Robert 'squid' Collins, Tori Styles & Scott Marrinan

Brodie J Brümmer - guitar, vocal
Gemma O'Connor - guitar, vocal
Melanie Barbaro - bass guitar
Andy Lloyd-Russell - drums

https://flyyingcolours.square.site
http://kexp.org

