# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Danny Trejo: Una Conversación Con Alt.Latino
 - [https://www.youtube.com/watch?v=LJMFKzMdJmE](https://www.youtube.com/watch?v=LJMFKzMdJmE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-09-05 00:00:00+00:00

Felix Contreras hosted a special live conversation with renowned restaurateur and actor Danny Trejo. In addition to being a hollywood cariño and an icon in the Latinx community, Trejo is establishing himself as a force in the literary realm with the release of his new book, Trejo: My Life of Crime, Redemption, and Hollywood. In the words of one viewer, “If you haven’t been hugged by Danny Trejo, you haven’t been hugged.” We promise, watching this interview is like getting one big Danny Trejo hug.

Félix Contreras presentó una conversación especial en vivo con el reconocido restaurador y actor Danny Trejo (@officialdannytrejo). Además de ser un cariño de hollywood y un ícono en la comunidad latina, Trejo se está estableciendo como una fuerza en el ámbito literario con el lanzamiento de su nuevo libro, Trejo: My Life of Crime, Redemption, and Hollywood. En palabras de un espectador, "Si Danny Trejo no te ha abrazado, no has sido abrazado". Lo prometemos, ver esta entrevista es como recibir un gran abrazo de Danny Trejo.

#altlatino #dannytrejo #eltiny

