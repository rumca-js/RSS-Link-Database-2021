## Why can an ad break the Windows 11 desktop and taskbar?
 - [https://www.ctrl.blog/entry/windows11-empty-taskbar.html](https://www.ctrl.blog/entry/windows11-empty-taskbar.html)
 - RSS feed: https://www.ctrl.blog
 - date published: 2021-09-04 15:02:50.152895+00:00

A new promo message for Microsoft Teams broke the Windows desktop shell and the taskbar for Windows 11 Insider users. Why can cloud services break Windows PCs?

