# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Copshop - Movie Review
 - [https://www.youtube.com/watch?v=rIcU4XFA-g4](https://www.youtube.com/watch?v=rIcU4XFA-g4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-09-17 00:00:00+00:00

Go to https://bit.ly/32IMOWU & new customers get 20% off orders of $20 or more by using promo code: DSCJAHNS.
Thank you to Dr. Squatch for sponsoring!

A fun "gotta protect the guy that the hitmen want to take out movie that takes place in a police station. Here's my review for COPSHOP!

#Copshop

