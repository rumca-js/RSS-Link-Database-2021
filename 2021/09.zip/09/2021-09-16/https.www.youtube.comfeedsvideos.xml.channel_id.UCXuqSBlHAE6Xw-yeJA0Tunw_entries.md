# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Did Apple Just Prove the iPhone Could be Cheaper? - WAN Show September 17, 2021
 - [https://www.youtube.com/watch?v=jPidIspifRM](https://www.youtube.com/watch?v=jPidIspifRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-17 00:00:00+00:00

Save 10% at Ridge Wallet with offer code WAN at https://www.ridge.com/WAN

Head over to joinhoney.com/linus and start saving today

Buy a Seasonic Ultra Titanium PSU
On Amazon: https://geni.us/q4lnefC
On NewEgg: https://lmg.gg/8KV3S

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Did-Apple-Just-Prove-the-iPhone-Could-be-Cheaper----WAN-Show-September-17--2021-e17k9te

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of NoKi1119)
[0:00] Chapters.
[1:31] Intro.
[1:56] Colton blames Geoff for no sponsors.
[4:06] Topic #1: Apple's annual September event.
    5:57 A15 specs & Geekbench result.
    9:35 ProRes enabled on iPhone 13 Pro.
    13:56 iPhone & iPad Mini improvements.
    15:22 Lightning vs USB C.
    17:36 iPad Mini is a bigger iPhone.
    20:33 iPad 9th Gen & Apple Watch Series 7.
    21:34 Apple sued for "Sherlocking" apps.
    29:34 Issues with OLED displays on Windows.
[36:26] Sponsors.
    36:40 Seasonic's Ultra Titanium PSUs.
    37:51 Honey Promo Codes.
    38:50 Ridge Wallet.
[40:04] Topic #2: LG 325-Inch 8K "Whole Wall" TV.
    41:32 DVLED Home Theater Cinema TV.
    44:20 LG's peak watt usage & other specs.
    49:38 Different modules for TV models.
    55:14 Responding to chat regarding purchases.
    1:00:20 AirBnB & other leisure renting.
[1:04:55] Topic #3: FloatPlane early-access REMOVED.
[1:07:07] LTTstore new merch.
[1:08:18] Topic #4: Sennheiser's new HD 8xx.
[1:11:38] Superchats & discussing Framework.
[1:30:35] Wrapping up.
[1:31:23] Outro.

## 5 weird motherboards that shouldn't exist
 - [https://www.youtube.com/watch?v=SWOCCuL6maE](https://www.youtube.com/watch?v=SWOCCuL6maE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-16 00:00:00+00:00

Get 20% OFF + Free Shipping @manscaped at https://manscaped.com/TECH

Save 10% and Free Worldwide Shipping at Ridge Wallet by using offer code LINUS at https://www.ridge.com/LINUS

Motherboards are the heart of any PC build, but while we take certain features and form factors for granted, specialty use and just plain bizarre system design means we get a few oddballs…

Discuss on the forum: https://linustechtips.com/topic/1373740-5-weird-motherboards-that-shouldnt-exist/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:09 Ports? Well... - Portwell PEB-9783G2AR
4:15 Gonna give me a SURNIA - Enctec Rev Q270
6:02 Zeal? Give it your all - ZA-SK1050
8:45 Win to the max - PCWINMAX HM77-989Y
11:15 EPIC Win - PCWINMAX EPIC ITX-M37
13:19 Conclusion

