# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The Mystery of Earth's Disappearing Giants | IN OUR NATURE
 - [https://www.youtube.com/watch?v=95HP73Yemxo](https://www.youtube.com/watch?v=95HP73Yemxo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-09-16 00:00:00+00:00

“In Our Nature” is a NEW special limited series on It’s Okay To Be Smart!
We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

Seemingly distant ecosystems, even half a world apart, are connected in surprising ways. In this special limited series, Emily Graslie and Trace Dominguez join me as we explore the universal rules of life that tie together Earth’s living systems. In episode 6, we investigate a mystery. Millennia ago, while much of the Earth was covered in ice, enormous animals lived on every continent except Antarctica. Species like ground sloths, mammoths, gomphotheres, sabertooth cats, even wombats the size of cars! Today, Africa is the only continent where these megafaunas still exist. Why? What happened to the rest of Earth’s giants?

In Our Nature is a special miniseries produced by It’s Okay To Be Smart for PBS. Stay tuned for more episodes coming this summer, here on our YouTube channel!

Original Production Funding provided by: Anne Ray Foundation, a Margaret A. Cargill Philanthropy

-----------

Special thanks to our Brain Trust Patrons:

Joseph Spencer
Barbora Bei
Ken Board
Clinger-Hamilton Family
Attila Pix
Burt Humburg
DeliciousKashmiri
Brian Chang
Roy Lasris
Javier Soto
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Marcus Tuepker
Karen Haskell
AlecZero

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

