# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Why we’re always at war (Documentary)
 - [https://www.youtube.com/watch?v=1TPuBmuYa18](https://www.youtube.com/watch?v=1TPuBmuYa18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-09-17 00:00:00+00:00

The first 1,000 people to use this link will get a 1 month free trial of Skillshare: https://skl.sh/jaketran09211 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time. 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

‘Petrodollars’ film: https://www.petrodollarsfilm.com/ 
Uncovering The Hidden Costs Of The Petrodollar: https://bitcoinmagazine.com/culture/the-hidden-costs-of-the-petrodollar 
From the Petrodollar to a Bitcoin Standard with Alex Gladstein & Nic Carter: https://youtu.be/_KaeR_2JxNc 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✨ Follow us on TikTok: https://jake.yt/tiktok
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG for a chance to win $1,000: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran
💬 Join the community Discord: http://discord.gg/BmK8EnQ

💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎵 Get unlimited royalty-free music for your videos with Epidemic Sound! ➡️ https://share.epidemicsound.com/jaketran

🍿 OUR MOST VIRAL VIDEOS: 
Nestlé: The Most Evil Business in the World https://youtu.be/rj6JOKrL_vg
BlackRock: The Company that Owns the World https://youtu.be/1n4zkdfKUAE
Recycling is literally a scam https://youtu.be/LELvVUIz5pY
Why do Chinese Billionaires Keep Disappearing? https://youtu.be/qyMsrgI7-_s

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/3zpGZMk 

-----------------------
The British Pound had dominated the global economy since the early 19th century. Leaders from 44 countries met at a hotel in Bretton Woods, New Hampshire, to decide how the new global economy would run and what it’s financial bedrock would be. The Conference settled on the US Dollar as the de facto global currency. This meant that the paper money printed by one nation was used everywhere.

After JFK, the US chose a radically different economic path filled with expensive spending. The one nation the world trusted to uphold the entire financial system was drowning in debt. 

Nixon changed the very foundation of the global financial system in a total of 16 seconds. By giving the middle finger to countries wanting their gold back, as a “temporary” measure. 

For the first time in modern history, the world moved from the gold standard, to a global reserve currency not backed by anything at all, just the blind faith that the US dollar was worth something - fiat money. 

OPEC, the cartel of Arabic petroleum exporters, announced an embargo on oil sales to the US and the quadrupling of global oil prices.

Why was this so devastating? Because oil dominated every aspect of Americans’ daily lives. When OPEC exposed this giant weakness in America by restricting their oil supply, the US had to make sure something like this would never happen again. Enter - The Petrodollar 
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

