# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## 3 Features the iPhone 13 Didn't Add!
 - [https://www.youtube.com/watch?v=ZvPzY6MsmCs](https://www.youtube.com/watch?v=ZvPzY6MsmCs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-09-17 00:00:00+00:00

These three phones feature bleeding edge features that the newest iPhone doesn't touch.

The iPhone 13: https://youtu.be/C4sAUc_ZGMY

CreativeLive camera explainer: https://youtu.be/BsXIQkhsxEM

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds  http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

