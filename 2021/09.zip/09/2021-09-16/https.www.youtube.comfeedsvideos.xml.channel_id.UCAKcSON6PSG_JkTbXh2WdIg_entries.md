# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Adia Victoria performs songs from 'A Southern Gothic' (live for The Current)
 - [https://www.youtube.com/watch?v=lKjDTqVWsv8](https://www.youtube.com/watch?v=lKjDTqVWsv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-09-17 00:00:00+00:00

Adia Victoria plays three songs from her 2021 record, 'A Southern Gothic' in a virtual session for The Current. Check out the full virtual session, including an interview about her journey to Nashville, putting together the new record, and the community she built over quarantine: https://youtu.be/odg3YbS4k48

Songs Played
00:01 Magnolia Blues
03:22 South Gotta Change
07:15 Mean-Hearted Woman

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## PaviElle speaks her truth on 'Sovereign'
 - [https://www.youtube.com/watch?v=kRupXHjmHGA](https://www.youtube.com/watch?v=kRupXHjmHGA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-09-17 00:00:00+00:00

PaviElle's new album, "Sovereign," releases on September 17, 2021, and will be celebrated that night with an album-release show at Icehouse in Minneapolis.

"It's about the healing, the healer, the nurturer, the warrior, the priestess, the revolutionary," PaviElle says about the new album. "All these facets of me that I had to come back to myself and find so that I could step into my next level."

In the run-up to the album release, PaviElle spoke to The Current's Sean McPherson about "Sovereign" and also about her deep-rooted connection to St. Paul's Rondo neighborhood. PaviElle also talks about a concert she'll be doing soon at the San Francisco Conservatory of Music. Watch the entire interview in the video above.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://www.facebook.com/PurpleCurrent/
https://twitter.com/TheCurrent
https://twitter.com/PurpleCurrent
https://www.instagram.com/thecurrent/

## Adia Victoria - Virtual Session with The Current
 - [https://www.youtube.com/watch?v=odg3YbS4k48](https://www.youtube.com/watch?v=odg3YbS4k48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-09-16 00:00:00+00:00

​@adiavictoria6385 joins The Current to play songs from her 2021 record, 'A Southern Gothic'. Plus, we catch up with singer-songwriter about her journey to Nashville, putting together the new record, and what she's been up to during quarantine. 

Songs Played: 
00:01 Magnolia Blues
03:22 South Gotta Change
07:15 Mean-Hearted Woman

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits
Host - Jill Riley
Producers - Jesse Wiza, Christy Taylor
Technical Director - Peter Ecklund

