# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: The Bee’s New Book and Remembering Norm Macdonald
 - [https://www.youtube.com/watch?v=HNEqatjZTRc](https://www.youtube.com/watch?v=HNEqatjZTRc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-09-17 00:00:00+00:00

In this episode of The Bee Weekly, musician Chandler Juliet joins Kyle and Ethan to talk about what’s been going on at The Babylon Bee this week, The Babylon Bee’s new book that is available for pre-order now called The Babylon Bee Guide to Wokeness (www.amazon.com/Babylon-Bee-Guide-Wokeness/dp/1684512719/ref=sr_1_1?crid=O5Q90E5DAKQ6&dchild=1&keywords=the+babylon+bee+guide+to+wokeness&qid=1631751343&sprefix=the+babylon+bee+guide%2Caps%2C193&sr=8-1) and the saddest news ever about Norm Macdonald’s passing. In the subscriber-exclusive lounge, Adam Yenser joins in to discuss his memories of working with Norm Macdonald.

Keep up with Chandler Juliet: 

Music: 
https://fanlink.to/ChandlerLoveLanguage

YouTube:
https://www.youtube.com/channel/UCYJAxrOiTRmgPSZrrZ9jL8g

Instagram: 
https://www.instagram.com/chandlerjofficial/



Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## New iPhone 13 Will Require Vaccination To Unlock Screen
 - [https://www.youtube.com/watch?v=RR_2Von6EPI](https://www.youtube.com/watch?v=RR_2Von6EPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-09-16 00:00:00+00:00

Join Tim Apple as he reveals iPhone 13. The first iPhone to force you to be vaccinated… or else. Apple: Think different.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

