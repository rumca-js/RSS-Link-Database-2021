# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Bringing Google & Apple to justice
 - [https://www.youtube.com/watch?v=1U3ZXAiEQTw](https://www.youtube.com/watch?v=1U3ZXAiEQTw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-09-17 00:00:00+00:00

Sponsored by Skillshare. The first 1,000 people to use thislink will get a 1 month freetrial of Skillshare: https://skl.sh/thefridaycheckout09211

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week, the South Korean FTC fined Google over restricting competing Android forks, we got the outcomes of the Epic vs Apple lawsuit summarized and Apple released a curious new iPad Mini.

Episode 63

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-bringing-google-apple-to-justice

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:28 Release Monitor
1:38 Google vs Korea
4:20 Apple vs Epic
6:28 The iPad Mini question

