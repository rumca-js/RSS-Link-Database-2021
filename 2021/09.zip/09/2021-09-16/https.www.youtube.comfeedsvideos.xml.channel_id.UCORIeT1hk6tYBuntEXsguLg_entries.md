# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Don’t Speak - No Doubt (‘60s Style Cover) ft. Haley Reinhart
 - [https://www.youtube.com/watch?v=Txi7QuO99kM](https://www.youtube.com/watch?v=Txi7QuO99kM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2021-09-16 00:00:00+00:00

Postmodern Jukebox '60s Style cover of "Don't Speak" by No Doubt ft. Haley Reinhart.
Get the song: https://pmjlive.com/dontspeak | Live PMJ Tix: http://www.pmjtour.com
Shop PMJ Music/Merch:  https://www.shoppmj.com
Follow Us On Spotify: https://pmjlive.com/pmjspotify
Subscribe: http://bit.ly/subPMJ | NEW Covers: https://youtube.com/watch?v=NABuS9TdfZ0&list=PL7A4D9C100657150E&index=2

You’ve waited 5 years to hear this. Platinum-voiced retro superstar Haley Reinhart returns for her ninth PMJ collaboration: a ‘60s orchestral pop style remake of the No Doubt breakup anthem, “Don’t Speak."
____________________________________________

FOLLOW THE MUSICIANS:

Haley Reinhart (Vocals):
Spotify: https://open.spotify.com/artist/5cKlE8f6b26h61Ml7m052Q?si=1Tv_DJbWReqvrZbXcDMnOA&dl_branch=1
YouTube: https://youtube.com/haleyreinhart
Instagram: http://www.instagram.com/haleyreinhart 
Facebook: https://facebook.com/HaleyReinhart
Twitter: http://www.twitter.com/haleyreinhart
Website: https://haleyreinhart.com/

Grace Rodgers (Violin): https://instagram.com/graceannviolin/
Desiree Hazley (Violin): https://instagram.com/greendeezy
Mia Barcia-Colombo (Cello): https://instagram.com/mia_bc
Marta Honer (Viola): https://www.instagram.com/mmartassofia/
Karina Ward (Harp) https://www.instagram.com/harpbykarina
Adam Kubota (Bass): https://instagram.com/adamkubota_bass
Jacob Scesney (Xylophone): https://instagram.com/antijacobclub
Dave Tedeschi (Drums): https://instagram.com/davetedeschi
Conrad Bauer (Guitar): https://instagram.com/conradonguitar

Scott Bradlee (Piano & Arrangement):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

Audio: Thai Long https://www.instagram.com/tl2bass
Video: Guy Livneh
Set/Wardrobe: Sunny Holiday
____________________________________________

#NoDoubt #Cover #HaleyReinhart #DontSpeak #PMJ

