# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Line Between Discipline and Addiction
 - [https://www.youtube.com/watch?v=3SpWWU5O8TY](https://www.youtube.com/watch?v=3SpWWU5O8TY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-09-16 00:00:00+00:00

Taken from JRE #1707 w/Anna Lembke:
https://open.spotify.com/episode/5Be4tuggcybyb0T28zuEoy?si=06bhOi4gS56-5r8KlJGTzQ&dl_branch=1

## What Happens in the Brain During Addiction
 - [https://www.youtube.com/watch?v=PaINkG9A5cY](https://www.youtube.com/watch?v=PaINkG9A5cY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-09-16 00:00:00+00:00

Taken from JRE #1707 w/Anna Lembke:
https://open.spotify.com/episode/5Be4tuggcybyb0T28zuEoy?si=06bhOi4gS56-5r8KlJGTzQ&dl_branch=1

