# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## I love recompiling the Linux kernel! (200K livestream)
 - [https://www.youtube.com/watch?v=yMARzJCR8Ig](https://www.youtube.com/watch?v=yMARzJCR8Ig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2021-09-16 00:00:00+00:00

This channel's subscribe counter's about to roll over to 200,000, so let's celebrate in the best way I know how: by live-streaming some juicy Linux kernel recompile action!

Thanks to everyone who's subscribed, and if you want the shirt, grab it at redshirtjeff.com!

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com

#RaspberryPi #OpenSource #Linux

