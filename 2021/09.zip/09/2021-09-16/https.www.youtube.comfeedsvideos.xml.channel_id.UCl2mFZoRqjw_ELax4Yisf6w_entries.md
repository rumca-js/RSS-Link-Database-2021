# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Linus' framework investment, the sanity check, and investing in the repairable future
 - [https://www.youtube.com/watch?v=YNYFOMOIDYQ](https://www.youtube.com/watch?v=YNYFOMOIDYQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-16 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://frame.work
https://youtu.be/VFmKlcjvta0
https://youtu.be/vQLws5KfntE
https://youtu.be/LSxbc1IN9Gg

## let's talk about what happened tonight
 - [https://www.youtube.com/watch?v=qfgeTjRpoH0](https://www.youtube.com/watch?v=qfgeTjRpoH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-16 00:00:00+00:00

https://tinyurl.com/rossmatrix

## she thinks I'm a sellout :'(
 - [https://www.youtube.com/watch?v=BiQZKKDgAtg](https://www.youtube.com/watch?v=BiQZKKDgAtg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-09-16 00:00:00+00:00

https://tinyurl.com/rossmatrix

