# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## I Try // Macy Gray // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=3uitThgLpeQ](https://www.youtube.com/watch?v=3uitThgLpeQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-09-16 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 The other day this song came on while I was driving and I thought, “HOW HAVE I FORGOTTEN HOW EPIC THIS IS????” Especially right when it gets to the bridge and modulates and Macy is just yell-singing and the orchestra is ripping your heart out! We didn’t do that. But still. I wanted to point out that the original is awesome.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Macy Gray's "I Try" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte
Bass: Nick Campbell
Drums: Kyle Crane
Background Vocals: Loren Battley
Additional Percussion / Keys: Ben Rose

AUDIO CREDITS
Engineer: Bill Mims
Mixing/Mastering: Yianni AP
Producer: Ben Rose

VIDEO CREDITS
Director: Dom Fera
DP / A Cam: Ricky Chavez
B Cam: Merlin Showalter
Gaffer / Key Grip: Arjay Ancheta
Production Designer: Genevieve Parkes
Wardrobe: Elle Olsen
Assistant/Wardrobe: Alex Allen
PA: Chris Modl
Video Editor: Cleveen Dominguez
Colorist: Charlene Gibbs

LYRICS
Games, changes and fears
When will they go from here?
When will they stop?
I believe that fate has brought us here
And we should be together, babe
But we're not
 
I play it off, but I'm dreaming of you
And I'll keep my cool, but I'm feigning
 
I try to say goodbye and I choke
I try to walk away and I stumble
Though I try to hide it, it's clear
My world crumbles when you are not near
Goodbye and I choke
I try to walk away and I stumble
Though I try to hide it, it's clear
My world crumbles when you are not near
 
I may appear to be free
But I'm just a prisoner of your love
And I may seem alright and smile when you leave
But my smiles are just a front
Just a front, hey!
 
I play it off, but I'm dreaming of you
And I'll keep my cool, but I'm feigning
 
I try to say goodbye and I choke
I try to walk away and I stumble
Though I try to hide it, it's clear
My world crumbles when you are not near
Goodbye and I choke 
I try to walk away and I stumble
Though I try to hide it, it's clear
My world crumbles when you are not near
 
I play it off, but I'm dreaming of you
I'll keep my cool, but I'm feigning
 
I try to say goodbye and I choke
I try to walk away and I stumble 
Though I try to hide it, it's clear
My world crumbles when you are not near
Goodbye and I choke
I try to walk away and I stumble 
Though I try to hide it, it's clear 
My world crumbles when you are not near 
Goodbye and I choke 
I try to walk away and I stumble
Though I try to hide it, it's clear
My world crumbles when you are not near

