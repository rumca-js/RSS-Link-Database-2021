# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## José González - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=AquLuPDB9uM](https://www.youtube.com/watch?v=AquLuPDB9uM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-09-17 00:00:00+00:00

http://KEXP.ORG presents José González sharing a live performance recorded exclusively for KEXP and talking to Larry Mizell, Jr., host of The Afternoon Show. Recorded September 2, 2021.

Songs:
Visions
Swing
Leaf Off / The Cave
Head On
El Invento

Session recorded by Don Alsterberg at Don Pierre Studio
Mixed by Kalle Gustafsson Jerneholm at Svenska Grammofonstudion
Camera: Patrik Gunnar Helin
Video Production: Chuck&Bruno

https://jose-gonzalez.com
http://kexp.org

