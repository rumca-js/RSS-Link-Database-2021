# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Only 12% of People Can See This!
 - [https://www.youtube.com/watch?v=AShZx0TdxMY](https://www.youtube.com/watch?v=AShZx0TdxMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-09-16 00:00:00+00:00

Women and men see differently, this is the science of why!
The first 1,000 people to use this link will get a 1 month free trial of Skillshare: https://skl.sh/asapscience08211

Inspired by this INCREDIBLE book, PLZ BUY: https://milkweed.org/book/braiding-sweetgrass

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Gregory Brown
Edited by: Luka Šarlija

RESOURCES: 
https://www.aao.org/eye-health/tips-prevention/do-color-blindness-correcting-glasses-work
https://www.iflscience.com/brain/image-can-trick-your-brain-and-make-you-see-it-color/
https://www.youtube.com/watch?v=3P8q_dCU3RI&ab_channel=BBC
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6120989/
https://www.researchgate.net/publication/231075053_Complementary_colours_for_a_physicist
https://www.ncbi.nlm.nih.gov/books/NBK11059/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3562597/
https://journals.sagepub.com/doi/full/10.1177/2158244016682478
https://www.researchgate.net/publication/231075053_Complementary_colours_for_a_physicist
https://journals.sagepub.com/doi/10.1080/17470215708416225
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3562597/

