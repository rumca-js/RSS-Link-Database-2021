# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## NVIDIA RESPONDS TO GTA REMAKE LEAK FOR PC, KOJIMA TALKS NEXT GAME, & MORE
 - [https://www.youtube.com/watch?v=qD6uWpA3g1E](https://www.youtube.com/watch?v=qD6uWpA3g1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-17 00:00:00+00:00

Thank you Skillshare for sponsoring this video. The first 1,000 people to use this link will get a 1 month free trial of Skillshare: https://skl.sh/gameranx03211c

Thumbnail background image via: https://www.artstation.com/artwork/mD82de

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​



 ~~~~STORIES~~~~



Nvidia leaks
https://www.videogameschronicle.com/news/nvidia-confirms-leaked-geforce-now-list-is-real-but-claims-games-are-speculative/

https://wccftech.com/nvidia-responds-to-geforce-now-database-leak-says-list-included-speculative-titles/

Dying Light 2 delayed (dec to feb 4 2022)
https://www.ign.com/articles/dying-light-2-delayed-to-early-next-year
BF delayed (October to Nov 19th)
https://www.theverge.com/2021/9/15/22676330/battlefield-2042-release-date-delay

PlayStation update
https://youtu.be/jQZROCPKbYQ
https://kotaku.com/the-ps5-is-getting-a-major-update-1847671904

Nintendo Switch bluetooth!
https://arstechnica.com/gaming/2021/09/nintendo-switch-finally-supports-bluetooth-audio-but-beware-the-lag/


Deltarune
https://www.theverge.com/2021/9/16/22677626/toby-fox-undertale-sequel-deltarune-chapter-2-release-date-mac-pc



Hideo’s next game
https://www.siliconera.com/hideo-kojima-says-he-wants-to-make-games-that-change-in-real-time/

Deathloop Before You Buy:
https://youtu.be/8iCrbmokDpI


Ren and Stimpy 
https://youtu.be/fDNl6i3yXdA

**Futility - an awesome new board game
https://www.kickstarter.com/projects/futility/futilitytm-the-actual-game-of-livingtm

Severed Steel
https://www.youtube.com/watch?v=nzwCsMFiblc

THQ Nordic games
https://youtu.be/KxEA4VkLD3E

## Top 20 NEW FPS Games of 2021
 - [https://www.youtube.com/watch?v=z-6hyRYZbLA](https://www.youtube.com/watch?v=z-6hyRYZbLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-16 00:00:00+00:00

Looking for a game to play from a first-person perspective on PC, PS5, Xbox Series X/S/One, or Switch? We've got you covered with these 2021 games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1




20 In Sound Mind 

Platform : PC PS5 XSX|S Switch 

Release Date : September 28, 2021  



19 Bright Memory: Infinite 

Platform : PC PS5 XSX|S 

Release Date : TBA 2021 



18 THE HOUSE OF THE DEAD: Remake  

Platform : Switch 

Release Date : 2021 



17 After the Fall 

Platform : PC PS4 Oculus Quest 

Release Date : TBA 2021



16 Boundary 

Platform : PC PS4

Release Date : TBA 2021 



15 Shadow Warrior 3 

Platform : PC PS4 Xbox One 

Release Date : 2021 



14 Hell Let Loose 

Platform : PS5 XSX|S October 5, 2021 

Release Date : PC July 27, 2021  



13 Cruelty Squad 

Platform : PC  (Early Access: 4 January 2021)

Release Date : 16 June 2021



12 Sniper Ghost Warrior Contracts 2 

Platform : PC PS4 Xbox One XSX|S 4 June 2021 

Release Date : PS5 24 August 2021 



11 Boomerang X 

Platform : Switch PC 

Release Date : July 8, 2021 



10 Necromunda: Hired Gun   

Platform : PC PS4 PS5 XBOX ONE XSX|S  

Release Date : June 1, 2021



9 World War Z: Aftermath [Now has first person view]                   

Platform : PC PS4 PS5 XBOX ONE XSX|S 

Release Date : September 21, 2021 



8 Severed Steel 

Platform : Switch PS4 PS5 XBOX ONE XSX|S PC 

Release Date : September 17, 2021



7 Back 4 Blood

Platform : PS4 PC PS5 XBOX ONE XSX|S 

Release Date : October 12, 2021 



6 Battlefield 2042 

Platform : PS4 PC PS5 XBOX ONE XSX|S 

Release Date : November 19, 2021 



5 Far Cry 6 

Platform : Amazon Luna Stadia PC PS4 PS5 XBOX ONE XSX|S  

Release Date : October 7, 2021



4 Halo Infinite 

Platform : PC XBOX ONE XSX|S 

Release Date : December 8, 2021 



3 Resident Evil Village 

Platform : PC PS4 PS5 XBOX ONE XSX|S Stadia 

Release Date : May 7, 2021



2 Call of Duty Vanguard 

Platform : PS4 PS5 XBOX ONE XSX|S PC 

Release Date : November 5, 2021 



1 Deathloop 

Platform : PC PS5 

Release Date : 14 September 2021 



BONUS

Isonzo [Maybe delayed to Q1 2022] 

Platform : PS4 PS5 XBOX ONE XSX|S PC  

Release Date : Q4 2021/ Q1 2022 



Nine to Five 

Platform : PC 

Release Date : August 27, 2021 



Lemnis Gate  

Platform : PS4 PS5 XBOX ONE XSX|S PC 

Release Date :  September 28, 2021

0:00 INTRO
0:36 In Sound Mind 
1:14 Bright Memory: Infinite 
1:54 THE HOUSE OF THE DEAD: Remake 
2:23 After the Fall 
2:55 Boundary 
3:27 Shadow Warrior 3 
4:06 Hell Let Loose 
4:38 Cruelty Squad 
5:23 Sniper Ghost Warrior Contracts 2
5:52 Boomerang X 
6:25 Necromunda: Hired Gun 
7:04 World War Z: Aftermath
7:51 Severed Steel 
8:17 Back 4 Blood
8:52 Battlefield 2042 
9:56 Far Cry 6 
10:32 Halo Infinite 
11:06 Resident Evil Village 
11:34 Call of Duty Vanguard 
12:12 Deathloop 
13:11 BONUS

