# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Free Guy - Way Better Than I Expected
 - [https://www.youtube.com/watch?v=f85pd0xFTAg](https://www.youtube.com/watch?v=f85pd0xFTAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-09-16 00:00:00+00:00

I went into Free Guy with pretty low expectations, but I have to admit, I was pleasantly surprised by this movie.

