## The American Style of Quotation Mark Punctuation Makes No Sense
 - [https://www.erichgrunewald.com/posts/the-american-style-of-quotation-mark-punctuation-makes-no-sense/](https://www.erichgrunewald.com/posts/the-american-style-of-quotation-mark-punctuation-makes-no-sense/)
 - RSS feed: https://www.erichgrunewald.com
 - date published: 2021-09-16 19:37:17.143527+00:00

Erich Grunewald's blog: Texts on philosophy, poetry, literature, history, altruism, science, programming and music.

