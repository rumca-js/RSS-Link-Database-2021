# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Why Can't We Cure Type 1 Diabetes? (From My Nebula Series Mysteries Of The Human Body)
 - [https://www.youtube.com/watch?v=Plc3I3uettk](https://www.youtube.com/watch?v=Plc3I3uettk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-09-16 00:00:00+00:00

You're welcome, Albert. ;)
This is a clip from my Nebula series Mysteries of the Human Body, Episode 5: Common Diseases Science Still Can't Cure. Check out the rest of the series - there's only one more to go - on http://www.watchnebula.com.





Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

