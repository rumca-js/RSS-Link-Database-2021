# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## My call with Jeff Bezos
 - [https://www.youtube.com/watch?v=uDQjF0j6IIE](https://www.youtube.com/watch?v=uDQjF0j6IIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-09-16 00:00:00+00:00

Get Surfshark VPN at https://surfshark.deals/nolke - Enter promo code NOLKE for 83% off and 3 extra months for FREE! 

Writer: Julie Nolke
Camera: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Also, join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

