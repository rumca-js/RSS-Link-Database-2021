# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## The Expanse (SPECIAL EDITION REVIEW)
 - [https://www.youtube.com/watch?v=-z9HMzlKylI](https://www.youtube.com/watch?v=-z9HMzlKylI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-10-01 00:00:00+00:00

My review of the latest special edition of the first Expanse book, Leviathan Wakes.
Check out the book here: https://amzn.to/3AD74c0 

Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3nLIQca 

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

New P.O. Box: PO Box 7874 Henrico, VA 23231

## I'm Fed Bombs -PDGDBA💣
 - [https://www.youtube.com/watch?v=i3AFyL0Qvc8](https://www.youtube.com/watch?v=i3AFyL0Qvc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-09-30 00:00:00+00:00

Let's open some mail and hope nothing explodes! 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Give Maddy a follow: 
Twitter: https://twitter.com/misszaddy
Instagram: https://www.instagram.com/maddyspearz/ 

Kissing The Sick: https://amzn.to/3kL8rzP

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://t.co/sEHQP0VEJe?amp=1

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

New P.O. Box: PO Box 7874 Henrico, VA 23231

