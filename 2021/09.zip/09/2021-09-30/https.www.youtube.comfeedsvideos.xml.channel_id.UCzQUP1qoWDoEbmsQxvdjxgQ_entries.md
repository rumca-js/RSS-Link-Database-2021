# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Former CIA Officer Mike Baker on Afghanistan Withdrawal
 - [https://www.youtube.com/watch?v=KvfOVQq8JJM](https://www.youtube.com/watch?v=KvfOVQq8JJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-09-30 00:00:00+00:00

Taken from JRE #1713 w/Mike Baker:
https://open.spotify.com/episode/1NQoehS9tqvWGvyM8VjUlZ?si=dXQzc2zqTXecqxAPEqMvzw&dl_branch=1

