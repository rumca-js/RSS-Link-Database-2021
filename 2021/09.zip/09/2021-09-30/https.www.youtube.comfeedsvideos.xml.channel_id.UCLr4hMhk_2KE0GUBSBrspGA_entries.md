# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Louis Vuitton Horizon Light Up Speaker - głośnik za 11 tysięcy złotych!
 - [https://www.youtube.com/watch?v=BuX3tuxTrvs](https://www.youtube.com/watch?v=BuX3tuxTrvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-09-30 00:00:00+00:00

Louis Vuitton Horizon Light Up Speaker: https://bit.ly/3zR85Mh
Film zawiera lokowanie aplikacji ZEN. Z kodem KlawyZen możecie jej używać przez 4 miesiące za darmo: https://bit.ly/3rklh8W
EDIT z dnia 29.09.2022 - w związku ze zmianą planów taryfowych ZEN, uległa zmianie również liczba dni darmowej subskrypcji kodów dedykowanych. Od teraz są to 2 miesiące zamiast 4.

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Naprawa kwiatka
00:20 Unboxing głośnika
00:45 Głośnik czy torebka?
01:48 Zawartość opakowania
02:46 Głośnik za prawie 3000 $
03:17 Fragment sponsorowany – ZEN
03:42 LV Horizon Light Up Speaker - wygląd i opcje połączeń
05:16 Żywotność baterii
05:20 Mikrofony i aplikacja
05:36 Próba uruchomienia i połączenia głośnika z Bluetooth
08:25 Test dźwięku – próba na 3 głośnikach (JBL Link vs Harman Kardon vs LV Speaker)
10:34 Test brzmienia na grupie reprezentatywnej
12:15 Podsumowanie 3 głośników
12:38 Czy głośnik od Louis Vuitton wart jest takich pieniędzy?
12:44 Test mikrofonów
14:08 Jak przechowywać tak drogi głośnik?
14:22 Morał
14:36 Zaproszenie na Tech Weeka
14:43 Cześć!

