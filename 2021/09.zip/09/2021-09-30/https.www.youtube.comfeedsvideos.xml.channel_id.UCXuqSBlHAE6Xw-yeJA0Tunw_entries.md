# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Does Your PC Suck? Win A Free One! - ASUS ROG RIG REBOOT 2021 (CLOSED)
 - [https://www.youtube.com/watch?v=WyYPQ5SlxaY](https://www.youtube.com/watch?v=WyYPQ5SlxaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-01 00:00:00+00:00

Thanks to ASUS ROG for sponsoring this video series! We're no longer accepting entries, thank you to EVERYONE who entered.

We know building a PC can be both confusing and, most importantly, very expensive, especially these days. So we're partnering up once again with ASUS ROG to fly 3 lucky winners to build a PC at Linus Media Group HQ with Linus Sebastian! Good luck!

The contest is only available to residents of the United States of American and Canada. 

Last year's winners for inspiration!

Ethan - https://youtu.be/Y2LRYWDC6j0
Emma - https://youtu.be/CPq_f0iC3-k
Alberto - https://youtu.be/ci0vKafyzfc

Discuss on the forum: https://linustechtips.com/topic/1377657-rog-rig-reboot-2021-announcement/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Pre-Built PCs Are About to get MUCH Worse - WAN Show October 1, 2021
 - [https://www.youtube.com/watch?v=PvTCc0iXGcQ](https://www.youtube.com/watch?v=PvTCc0iXGcQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-10-01 00:00:00+00:00

Change the way you address patching concerns with rebootless QEMU/KVM patching at https://hubs.ly/H0X1rWt0

Get 30% off list price and 30% off onboarding at http://www.graphus.ai/linus

Save 10% off your Savage Jerky order today with code WANSHOW21 at http://savagejerky.com/ltt

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Pre-Built-PCs-Are-About-to-get-MUCH-Worse---WAN-Show-October-1--2021-e18a37r

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of NoKi1119)
[0:00] Chapters.
[1:21] Intro.
[1:51] Topic #1: Windows 11 VBS harms gaming performance.
    3:18 Virtual machine & hardware issues.
    7:46 Affected games & change in performance.
    9:52 VBS is not mandated on custom builds.
    13:03 Switching to Linux challenge.
    17:32 Issues with daily driving Linux.
    20:15 Polling which distro to use.
[25:23] Sponsors.
    25:27 TuxCare QEMU & KVM patching.
    27:01 Graphus anti phishing cloud software.
    28:22 Savage Jerky.
[32:27] Topic #2: Valve's "Deckard" VR headset.
    35:11 Going standalone in the VR market.
    37:46 Pricing of Valve products.
    42:37 Poll: Which Distro should Linus use?
    45:22 Tim Cook meeting with EU competition chief.
[46:48] Topic #3: Amazon's "Astro" house robot.
    48:24 Criticism towards the robot.
    48:52 Pricing & specs.
[52:06] LTTstore new merch & site redesign.
[52:56] Superchats.
[57:20] Topic #4: Asus's RTX 3070 with Noctua fans.
[58:20] Topic #5: Silicon Lottery closing.
[59:14] Topic #6: Steam disables downloading older builds.
[1:00:27] Topic #7: Dune Case has not shipped yet.
[1:01:04] Outro.

## Being an Early Adopter SUCKS - Trying to Fix Burn-in on my LG CX
 - [https://www.youtube.com/watch?v=hWrFEU_605g](https://www.youtube.com/watch?v=hWrFEU_605g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-30 00:00:00+00:00

New Customers Exclusive – Get a Free 240GB SSD From Micro Center: https://micro.center/2436a0

Check out Micro Center’s Business Solutions here: https://micro.center/373b62

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

I reviewed the LG OLED CX and LOVED IT but after daily driving for a few months I've already got burn in and keep running into a few other minor annoyances. So I'm gonna try to fix it!


Buy LG OLED CX TV
  Amazon (PAID LINK): https://geni.us/ipbFl
  Best Buy (PAID LINK): https://geni.us/SVOyMr
  Newegg (PAID LINK): https://geni.us/fRBc

Buy MKJ39170828 Replacement Service Remote
  Amazon (PAID LINK): https://geni.us/DJjaD
  Newegg (PAID LINK): https://geni.us/4wQlzUn

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1377353-being-an-early-adopter-sucks/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:00 Recap
1:40 Burn In
4:00 How Likely Is It?
5:00 Can We Do Anything?
6:05 Did it work?
7:20 Daily Use Issues
8:24 Service Remote
10:30 Results
11:50 Conclusion
14:20 Outro

