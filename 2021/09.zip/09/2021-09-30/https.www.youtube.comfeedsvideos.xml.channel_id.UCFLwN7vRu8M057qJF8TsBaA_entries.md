# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Pickles Are An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=_kOyYpmSkNM](https://www.youtube.com/watch?v=_kOyYpmSkNM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2021-09-30 21:00:11+00:00

Use code UPISNOTJUMP14 for up to 14 FREE MEALS across your first 5 HelloFresh boxes plus free shipping at https://bit.ly/3EFvnZd!

There are a lot of tier lists on YouTube, and I am yet to see one done on pickles (maybe that is a sign I shouldn't have done this...). Since my YouTube channel has no discernible theme I thought a tier list would only add to the charm.

Patreon bros: https://www.patreon.com/UpIsNotJump 
Merch-o-bros: https://www.pixelempire.com/pages/upi... 
Twitter-o-fish: https://twitter.com/UpIsNotJump

This pickle based tier list came to life when some friends suggested to both make a pickle, and buy a pickle form McDonalds, as part of the tier list. Once I heard those Ideas I know this video would work as there would be enough content to make a full tier list video.

A special thanks to my members!! 
Siberial 
Superhero3807

