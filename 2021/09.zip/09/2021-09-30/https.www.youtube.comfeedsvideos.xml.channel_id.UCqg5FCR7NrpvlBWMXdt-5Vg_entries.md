# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Hot Wheels Unleashed | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=f3EbTi5SjdM](https://www.youtube.com/watch?v=f3EbTi5SjdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-01 00:00:00+00:00

KC Nwosu reviews Hot Wheels Unleashed, developed by Milestone S.r.l.

Hot Wheels Unleashed on Steam: https://store.steampowered.com/app/1271700/HOT_WHEELS_UNLEASHED/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#HotWheelsUnleashed

## Venom: Let There Be Carnage Is the Antidote to Superhero Fatigue | Review
 - [https://www.youtube.com/watch?v=pIhadLO8AxE](https://www.youtube.com/watch?v=pIhadLO8AxE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-10-01 00:00:00+00:00

Matthew Razak reviews Venom: Let There Be Carnage for The Escapist. Review voiced by Darren Mooney. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## A Juggler's Tale | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=RvfJSWv7pt4](https://www.youtube.com/watch?v=RvfJSWv7pt4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-30 00:00:00+00:00

Elise Avery reviews A Juggler's Tale, developed by kaleidoscube.

A Juggler's Tale on Steam: https://store.steampowered.com/app/1252830/A_Jugglers_Tale/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## No Time to Die is Too Haunted By Its Past | Review
 - [https://www.youtube.com/watch?v=tCqJRU7gFWg](https://www.youtube.com/watch?v=tCqJRU7gFWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-30 00:00:00+00:00

Darren Mooney reviews No Time To Die for The Escapist.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#NoTimeToDie

