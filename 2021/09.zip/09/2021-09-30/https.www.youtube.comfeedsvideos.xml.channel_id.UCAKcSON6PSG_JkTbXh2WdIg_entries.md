# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Catching up with Lizzo on "Rumors," and returning to the stage
 - [https://www.youtube.com/watch?v=SKtX-f6sXvs](https://www.youtube.com/watch?v=SKtX-f6sXvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-01 00:00:00+00:00

Fresh off the release of her collaboration with @cardib on "Rumors," we catch up with the Grammy-winning artist @Lizzo about her first performance in two years, and what she's been up to during quarantine.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits
Host - Jill Riley
Guest - Lizzo
Producers - Christy Taylor, Jesse Wiza
Technical Director - Eric Romani

## Michael Bland and Tommy Barbarella of the New Power Generation talk 'Diamonds and Pearls'
 - [https://www.youtube.com/watch?v=Q3VsrbJx3HY](https://www.youtube.com/watch?v=Q3VsrbJx3HY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-01 00:00:00+00:00

On the 30th anniversary of Prince's "Diamonds and Pearls" album, drummer Michael Bland and keyboardist Tommy Barbarella of the New Power Generation join The Current's Sean McPherson to compare notes and to share memories of recording "Diamonds and Pearls," working with Prince, and being part of a great band and the lively Minneapolis music scene.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#prince #diamondsandpearls #newpowergeneration

## The Record Company - Paradise (live for The Current)
 - [https://www.youtube.com/watch?v=jeli25GL_rs](https://www.youtube.com/watch?v=jeli25GL_rs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-01 00:00:00+00:00

@therecordcomp perform "Paradise" from their third studio record, 'Play Loud'. Don't miss frontman Chris Vos catching up with The Current about the new record, and staying open minded in creative collaborations: https://youtu.be/Yiw7z6n0PPs 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## The Record Company perform songs from 'Play Loud' (live for The Current)
 - [https://www.youtube.com/watch?v=TPkrpCzkwJ8](https://www.youtube.com/watch?v=TPkrpCzkwJ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-10-01 00:00:00+00:00

Angeleno rockers @therecordcomp join The Current to play songs from their third studio record, 'Play Loud'. Don't miss frontman Chris Vos catching up with Mary Lucia in the full virtual session: https://youtu.be/Yiw7z6n0PPs

Songs Played: 
00:01 How High
03:10 Paradise

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## The Record Company - Virtual Session
 - [https://www.youtube.com/watch?v=Yiw7z6n0PPs](https://www.youtube.com/watch?v=Yiw7z6n0PPs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-09-30 00:00:00+00:00

Mary Lucia catches up with @therecordcomp's Chris Vos about staying open minded in artistic collaborations, Buddy Guy's polka dot Stratocaster--plus hear performances of tracks from their new record out October 8, 'Play Loud'.

Songs Played:
08:10 How High
25:41 Paradise 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits
Host - Mary Lucia
Producers - Jesse Wiza, Derrick Stevens
Technical Director - Eric Romani

