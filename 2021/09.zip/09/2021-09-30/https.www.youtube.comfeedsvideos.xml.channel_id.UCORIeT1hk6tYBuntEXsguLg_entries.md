# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Drivers License - Olivia Rodrigo ('50s Style Cover) ft. Piper Jones
 - [https://www.youtube.com/watch?v=y1bJNgX84n0](https://www.youtube.com/watch?v=y1bJNgX84n0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2021-09-30 00:00:00+00:00

Postmodern Jukebox '50s cover of "Drivers Licence" by Olivia Rodrigo ft. Piper Jones
Get the song: https://pmjlive.com/oldiefans | Subscribe: http://bit.ly/subPMJ
Live Show Tix: http://www.pmjtour.com  | Next, "Don't Speak" ( No Doubt Cover): https://youtu.be/Txi7QuO99kM

Nashville's own Piper Jones makes her pitch-perfect PMJ debut on this retro-styled remake of Olivia Rodrigo's smash hit, "Drivers License," with a special guest on percussion.

____________________________________________

Follow The Musicians:

Pipers Jones (Vocals)
TikTok: https://www.tiktok.com/@thepiperjonesmusic
Instagram: https://www.instagram.com/thepiperjonesmusic
Website: http://www.piperjonesmusic.com

Dave Johnstone (Drums) https://www.instagram.com/johnstonedrums
Erm Navarro (Trombone): https://www.instagram.com/ermnavarro
Marlon Martinez (Bass): https://www.instagram.com/marloniusmusic/
Conrad Bauer (Guitar): https://www.instagram.com/conradonguitar/
Eric Croissant (Bari Sax): https://www.instagram.com/saxcroissant/
Tim Kubart (Tambourine Guy): https://www.instagram.com/timkubart/

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

Arrangement by: Scott Bradlee
Audio By: Thai Long https://www.instagram.com/tl2bass
Video by: Guy Livneh
____________________________________________

#OliviaRodrigo #DriversLicense #Cover

