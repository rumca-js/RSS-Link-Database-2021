# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## New subpoenas indicate Durham probe of FBI investigation continues
 - [https://www.cnn.com/2021/09/30/politics/durham-subpoenas-probe-russia-fbi-sussman/index.html](https://www.cnn.com/2021/09/30/politics/durham-subpoenas-probe-russia-fbi-sussman/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 23:41:21+00:00

• Opinion: A scary portrait of life inside Trump's White House

## UK police officer who murdered Sarah Everard gets life in prison with no chance of parole
 - [https://www.cnn.com/collections/intl-everard-0930/](https://www.cnn.com/collections/intl-everard-0930/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 23:24:39+00:00



## This 'Big Brother' winner just made history
 - [https://www.cnn.com/videos/business/2021/09/30/big-brother-first-black-winner-mh-orig.cnn](https://www.cnn.com/videos/business/2021/09/30/big-brother-first-black-winner-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 23:00:08+00:00

After 21 years on TV, CBS' "Big Brother" crowned its first Black winner.

## Super Bowl LVI halftime show will be packed with star power
 - [https://www.cnn.com/2021/09/30/entertainment/super-bowl-lvi-halftime-show/index.html](https://www.cnn.com/2021/09/30/entertainment/super-bowl-lvi-halftime-show/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 22:40:38+00:00

A quintet of musical trailblazers will come together on the Super Bowl LVI halftime show stage in February.

## Canada to pay billions to Indigenous children removed from families, court rules
 - [https://www.cnn.com/2021/09/30/americas/canada-indigenous-children-compensation/index.html](https://www.cnn.com/2021/09/30/americas/canada-indigenous-children-compensation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 21:53:23+00:00

Canada observed its first national holiday honoring victims and survivors of the country's residential school system.

## Would you pay nearly $400k for this 'as-is' house?
 - [https://www.cnn.com/videos/business/2021/09/30/house-fire-sale-400k-housing-market-orig.cnn-business](https://www.cnn.com/videos/business/2021/09/30/house-fire-sale-400k-housing-market-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 18:17:27+00:00

A house outside of Boston, MA was involved in a fire, and then placed on the market before it was repaired. It's now selling for just under $400k.

## New CCTV footage shows Everard being stopped by murderer
 - [https://www.cnn.com/videos/world/2021/09/30/wayne-couzens-sentencing-sarah-everard-london-bashir-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/09/30/wayne-couzens-sentencing-sarah-everard-london-bashir-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 17:10:07+00:00

British police officer Wayne Couzens has been sentenced to life in prison without parole for the abduction, rape and murder of Sarah Everard. Couzens was fired from London's Metropolitan Police in July 2021, days after he pleaded guilty to Everard's kidnap, rape and murder. CNN's Nada Bashir reports.

## This poll should terrify Democrats ahead of 2022
 - [https://www.cnn.com/videos/politics/2021/09/30/poll-terrify-democrats-2022-cillizza-the-point.cnn](https://www.cnn.com/videos/politics/2021/09/30/poll-terrify-democrats-2022-cillizza-the-point.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 17:02:12+00:00

A new poll out of Iowa has put Democrats on red alert, as President Biden's job approval rating hits a term low in the Hawkeye State. In the latest episode of The Point, CNN's Chris Cillizza talks about what these new numbers out of the early-voting state to means for 2022, 2024 and beyond.

## Attorney for Jamie Spears calls his suspension 'disappointing' and a 'loss' for Britney Spears
 - [https://www.cnn.com/2021/09/30/entertainment/jamie-spears-suspended-statement-britney-spears-conservatorship/index.html](https://www.cnn.com/2021/09/30/entertainment/jamie-spears-suspended-statement-britney-spears-conservatorship/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 16:35:04+00:00

Britney Spears' father is reacting to his suspension as the conservator of his daughter's estimated $60 million dollar estate.

## Rare tornado strikes town in northern Germany
 - [https://www.cnn.com/videos/weather/2021/09/30/germany-tornado-kiel-rare-orig-kj.cnn](https://www.cnn.com/videos/weather/2021/09/30/germany-tornado-kiel-rare-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 16:17:39+00:00

The unexpected tornado tore through Kiel, Germany where social media videos captured uprooted trees and objects flying through the air.

## Shakira says she was attacked by purse snatching boars
 - [https://www.cnn.com/2021/09/30/entertainment/shakira-boar-attack/index.html](https://www.cnn.com/2021/09/30/entertainment/shakira-boar-attack/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 16:06:49+00:00

Her hips don't lie and Shakira says she's not telling tall tales about being a victim of a boar attack.

## Russia to host first royal wedding in more than a century
 - [https://www.cnn.com/2021/09/30/europe/russia-royal-wedding-scli-intl/index.html](https://www.cnn.com/2021/09/30/europe/russia-royal-wedding-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 15:22:15+00:00

Russia's former Imperial capital is set to play host to the wedding of a descendant of the Russian royal family in the first such event in more than a century.

## 96-year-old woman who fled Nazi war crimes trial is found
 - [https://www.cnn.com/2021/09/30/europe/german-96-year-old-nazi-intl-grm/index.html](https://www.cnn.com/2021/09/30/europe/german-96-year-old-nazi-intl-grm/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 14:02:21+00:00

A 96-year-old German woman fled ahead of the opening on Thursday of her trial on charges of aiding and abetting mass murder in a Nazi concentration camp during World War II, a court spokesperson said.

## A scary portrait of life inside Trump's White House
 - [https://www.cnn.com/2021/09/30/opinions/trump-white-house-stephanie-grisham-book-ghitis/index.html](https://www.cnn.com/2021/09/30/opinions/trump-white-house-stephanie-grisham-book-ghitis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 13:43:50+00:00

The indelible image that emerges from the latest tell-all book about the Trump White House is of a President plagued by insecurities and unmoored from morality. We piece it together from the eye-popping anecdotes revealed in advance excerpts, provided to the media, of "I'll Take Your Questions Now," the forthcoming memoir by Trump's former press secretary, Stephanie Grisham.

## Secret Service agent who took a bullet for Reagan reacts to shooter being released
 - [https://www.cnn.com/videos/politics/2021/09/30/john-hinckley-jr-released-reagan-shooting-tim-mccarthy-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/09/30/john-hinckley-jr-released-reagan-shooting-tim-mccarthy-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 13:23:05+00:00

John Hinckley Jr., the man who shot then President Ronald Reagan, is to be released from all court oversight if he continues to remain mentally stable over the next year. Former Secret Service Agent Tim McCarthy speaks to CNN's John Berman about the judge's decision.

## 4 things to know about the UK gasoline crisis
 - [https://www.cnn.com/2021/09/30/business/petrol-shortages-uk/index.html](https://www.cnn.com/2021/09/30/business/petrol-shortages-uk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 12:03:43+00:00

A fuel crisis that threatened to stop the world's fifth largest economy in its tracks appears to be easing.

## Kim Yo Jong, sister of North Korean leader, promoted to nation's top ruling body
 - [https://www.cnn.com/2021/09/30/asia/kim-yo-jong-promoted-leadership-intl-hnk/index.html](https://www.cnn.com/2021/09/30/asia/kim-yo-jong-promoted-leadership-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 11:08:44+00:00

Kim Yo Jong, the younger sister of North Korean leader Kim Jong Un, has been promoted to the nation's top decision-making body, state media said on Thursday.

## Cave chamber closed for 40,000 years could hold the key to the lives of Neanderthals
 - [https://www.cnn.com/travel/article/neanderthals-cave-gibraltar-scn-scli-intl/index.html](https://www.cnn.com/travel/article/neanderthals-cave-gibraltar-scn-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 09:35:38+00:00

The discovery of a chamber at least 40,000 years old in a Gibraltar cave previously inhabited by Neanderthals could lead to groundbreaking new finds about their lifestyles, according to researchers.

## It's official. China's manufacturing industry is in trouble
 - [https://www.cnn.com/collections/intl-uk-fuel-crisis-929/](https://www.cnn.com/collections/intl-uk-fuel-crisis-929/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 09:13:48+00:00



## Beijing will open next year's Winter Olympics to fans -- but only if they live in China
 - [https://www.cnn.com/2021/09/30/sport/beijing-winter-olympics-covid-measures-intl-hnk/index.html](https://www.cnn.com/2021/09/30/sport/beijing-winter-olympics-covid-measures-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 08:29:13+00:00

The Beijing 2022 Winter Olympics will be open to spectators -- but only if they live in mainland China, the International Olympic Committee (IOC) said Wednesday, as organizers gave a first glimpse into the country's plans to hold the event while enforcing a strict zero-Covid strategy.

## Covid surge after some Australians break lockdown to celebrate country's biggest football event of the year
 - [https://www.cnn.com/2021/09/30/australia/victoria-covid-grand-final-intl-hnk/index.html](https://www.cnn.com/2021/09/30/australia/victoria-covid-grand-final-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 07:57:38+00:00

Fans who gathered to watch two Victoria-based rivals play in one of Australia's top sporting events are partly to blame for a more than 50% increase in the state's daily reported Covid-19 cases, local officials said Thursday.

## Princess Diana's former London apartment is now an official tourist site
 - [https://www.cnn.com/travel/article/princess-diana-london-apartment-blue-plaque-intl-hnk/index.html](https://www.cnn.com/travel/article/princess-diana-london-apartment-blue-plaque-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 07:07:17+00:00

The London apartment where Diana Spencer lived before she became the Princess of Wales has been commemorated with an official blue plaque.

## Over 100 killed in Ecuador prison massacre
 - [https://www.cnn.com/2021/09/29/americas/ecuador-prison-deaths-intl/index.html](https://www.cnn.com/2021/09/29/americas/ecuador-prison-deaths-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 07:02:20+00:00

Over 100 people have died in a prison massacre that erupted yesterday in Ecuador, the country's prison agency said Wednesday. At least 52 people were injured, it also said.

## Relatives of family killed in Kabul missile strike are seeking resettlement in America
 - [https://www.cnn.com/2021/09/30/asia/afghanistan-kabul-drone-strike-family-intl-hnk-dst/index.html](https://www.cnn.com/2021/09/30/asia/afghanistan-kabul-drone-strike-family-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 06:57:19+00:00

Every day for the past month, Emal Ahmadi's 7-year-old daughter Hada has asked him the same thing: "Where is my sister?"

## CNN speaks to family of victims killed by US military's wrongful drone strike
 - [https://www.cnn.com/videos/world/2021/09/30/us-drone-strike-afghanistan-family-coren-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/09/30/us-drone-strike-afghanistan-family-coren-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 06:53:48+00:00

A top general admitted that the US military had made a "terrible mistake" by killing 10 civilians during a drone strike in Kabul in the final days of the US war in Afghanistan. CNN's Anna Coren followed up with the family of the victim Zamarai Ahmardi.

## Pelosi faces her toughest moment of truth yet
 - [https://www.cnn.com/2021/09/30/politics/nancy-pelosi-congress-biden-joe-manchin/index.html](https://www.cnn.com/2021/09/30/politics/nancy-pelosi-congress-biden-joe-manchin/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 06:37:50+00:00

Democrats have an almost mystical faith in Nancy Pelosi's ability to count votes, corral her caucus and pass historic legislation. But her reputation is facing its toughest test as the House speaker, trapped between progressive and moderate Democrats, struggles to save President Joe Biden's transformational agenda.

## Black woman says neighbor harasses family with monkey noises
 - [https://www.cnn.com/videos/us/2021/09/30/racist-neighbor-monkey-noises-virginia-martinez-dlt-sot-vpx.cnn](https://www.cnn.com/videos/us/2021/09/30/racist-neighbor-monkey-noises-virginia-martinez-dlt-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 05:22:22+00:00

CNN's Don Lemon speaks with Jannique Martinez, a Virginia woman who says a neighbor played recordings of racial slurs and monkey noises as her family came and went from their home.

## 'I'm trying to stay apolitical': Top US general faces wave of GOP attacks over Trump-era actions
 - [https://www.cnn.com/2021/09/29/politics/milley-afghanistan-hearings-gop-attacks/index.html](https://www.cnn.com/2021/09/29/politics/milley-afghanistan-hearings-gop-attacks/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 04:40:41+00:00

Top US General Mark Milley appeared before Congress this week to defend Pentagon decision making in Afghanistan but instead found himself fighting a personal battle with lawmakers who charged that he has been more preoccupied with rehabilitating and burnishing his own image.

## Jamie Spears suspended as conservator of Britney Spears
 - [https://www.cnn.com/2021/09/29/entertainment/jamie-spears/index.html](https://www.cnn.com/2021/09/29/entertainment/jamie-spears/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 04:15:18+00:00

Britney Spears scored a legal victory Wednesday in her fight to regain control of her life.

## Nearly two dozen species of birds, fish and other wildlife are set to be declared extinct and removed from the endangered species list
 - [https://www.cnn.com/2021/09/29/us/extinct-animals-2021-list-scn-trnd/index.html](https://www.cnn.com/2021/09/29/us/extinct-animals-2021-list-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 03:55:58+00:00

The ivory-billed woodpecker, along with 22 other species of birds, fish, mussels and other wildlife, is set to be declared extinct and removed from the endangered species list, US federal wildlife officials announced Wednesday.

## Amazon package delivery goes hilariously wrong
 - [https://www.cnn.com/videos/business/2021/09/29/delivery-driver-package-on-roof-jeanne-moos-vpx.cnn](https://www.cnn.com/videos/business/2021/09/29/delivery-driver-package-on-roof-jeanne-moos-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 03:36:14+00:00

How does a delivery guy ACCIDENTALLY throw a package on the roof? Jeanne Moos says you need to see the video to believe the story.

## 'Disgraceful performance': Lemon reacts to Gaetz questioning Milley
 - [https://www.cnn.com/videos/politics/2021/09/30/matt-gaetz-mark-milley-dons-take-dlt-vpx.cnn](https://www.cnn.com/videos/politics/2021/09/30/matt-gaetz-mark-milley-dons-take-dlt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 03:27:55+00:00

CNN's Don Lemon reacts after Rep. Matt Gaetz (R-FL) questioned Chairman of the Joint Chiefs of Staff Gen. Mark Milley about whether or not he should resign.

## A man died from rabies after waking up to a bat in his room. It's Illinois' first human case of the virus in nearly 70 years
 - [https://www.cnn.com/2021/09/29/us/illinois-rabies-death/index.html](https://www.cnn.com/2021/09/29/us/illinois-rabies-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 03:16:36+00:00

A man in northeastern Illinois died from rabies about a month after apparently being infected by a bat he found in his room, marking the first human case of the virus in the state since 1954, health officials said Tuesday.

## Rohingya leader shot dead in refugee camp
 - [https://www.cnn.com/2021/09/29/asia/bangladesh-rohingya-leader-shot-dead-intl-hnk/index.html](https://www.cnn.com/2021/09/29/asia/bangladesh-rohingya-leader-shot-dead-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 02:56:04+00:00

Gunmen shot and killed a prominent Rohingya Muslim leader in a refugee camp in southern Bangladesh on Wednesday, a United Nations spokesperson and a local police official said, following months of worsening violence in the world's largest refugee settlement.

## Three ways this gin made from peas is good for the climate
 - [https://www.cnn.com/2021/09/29/business/scotland-pea-based-gin-arbikie-climate-hnk-spc-intl/index.html](https://www.cnn.com/2021/09/29/business/scotland-pea-based-gin-arbikie-climate-hnk-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 02:36:02+00:00

Garden peas are sometimes an afterthought on our dinner plates. But one Scottish farm-based distillery is reimagining the humble legume as the star ingredient in its eco-friendly gin.

## Massive kitchens, unique tastes: India's ancient temple cuisine sits in a class of its own
 - [https://www.cnn.com/travel/article/india-temple-food-cmd/index.html](https://www.cnn.com/travel/article/india-temple-food-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 01:41:24+00:00

Across India, temples have long served not just a spiritual need but a social one as well.

## This new North Korean missile may be almost impossible to shoot down
 - [https://www.cnn.com/2021/09/29/asia/north-korea-hypersonic-missile-intl-hnk-ml/index.html](https://www.cnn.com/2021/09/29/asia/north-korea-hypersonic-missile-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 01:40:23+00:00

The hypersonic missile North Korea claims to have tested on Tuesday has the potential to be one of the world's fastest and most accurate weapons -- and could be fitted with a nuclear warhead, experts say.

## Kim Jong Un's arsenal ramps up during his first decade in power
 - [https://www.cnn.com/videos/world/2021/09/30/north-korea-claims-hypersonic-missile-will-ripley-lead-vpx.cnn](https://www.cnn.com/videos/world/2021/09/30/north-korea-claims-hypersonic-missile-will-ripley-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 01:35:29+00:00

North Korea claims it test-fired a new hypersonic missile, a move experts say could change the military equation in East Asia and beyond. CNN's Will Ripley reports.

## Timeline of events since Gabby Petito's fiancé returned to Florida becomes clearer
 - [https://www.cnn.com/2021/09/29/us/gabby-petito-brian-laundrie-update-wednesday/index.html](https://www.cnn.com/2021/09/29/us/gabby-petito-brian-laundrie-update-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 01:22:37+00:00

Reports that Brian Laundrie camped with his family this month before Gabby Petito was reported missing appear to clarify a timeline of his movements after he returned to Florida without his fiancée, who eventually was found dead in Wyoming.

## Florida man's trash can battle with gator goes viral
 - [https://www.cnn.com/videos/us/2021/09/30/florida-man-alligator-trash-can-dnt-vpx.wesh](https://www.cnn.com/videos/us/2021/09/30/florida-man-alligator-trash-can-dnt-vpx.wesh)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 01:04:29+00:00

A military veteran who's only lived in Florida for a year officially became a local when he successfully used a trash can to fight off and capture an alligator loitering in a neighbor's front yard. CNN affiliate WESH has more.

## Police officers convicted of serious crimes collect millions of dollars
 - [https://www.cnn.com/videos/us/2021/09/29/police-pensions-drew-griffin-lead-vpx.cnn](https://www.cnn.com/videos/us/2021/09/29/police-pensions-drew-griffin-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-09-30 00:10:16+00:00

Taxpayer money is helping to fund the generous retirements of cops who have served time for felony crimes. CNN's Drew Griffin reports.

