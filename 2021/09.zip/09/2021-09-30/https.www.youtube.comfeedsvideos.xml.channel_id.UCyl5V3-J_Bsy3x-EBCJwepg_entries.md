# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Vaccine Mandates from God, Woke Wrestling, and Kissing in Portland
 - [https://www.youtube.com/watch?v=UefgqsT4IGU](https://www.youtube.com/watch?v=UefgqsT4IGU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-10-01 00:00:00+00:00

It's a discussion on vaccine mandates this week on The Bee Weekly. Ethan Nicolle, Adam Yenser, and Kira Davis from RedState talk mandates, woke wrestling, and how it is now legal to kiss in Portland if you are vaccinated. Adam Yenser quizzes Kira and Ethan on whether headlines are real or fake. Kira answers subscriber questions in the subscriber lounge.

The Bee’s New Guide to Wokeness is coming out and You Can Join The Launch Team here: https://launchteamhq.com/babylon-bee-guide-to-wokeness-launch-team/

Check out Kira Davis on her podcast, Just Listen To Yourself (https://podcasts.apple.com/us/podcast/just-listen-to-yourself-with-kira-davis/id1475358928).


Check out Adam Yenser’s YouTube channel and stand-up comedy schedule (http://adamyenser.com/).


Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

