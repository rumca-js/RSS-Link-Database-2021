# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Many Saints of Newark - Movie Review
 - [https://www.youtube.com/watch?v=BP02lq0TbL8](https://www.youtube.com/watch?v=BP02lq0TbL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-10-01 00:00:00+00:00

Thank you to Hamilton Watch for sponsoring a portion of this video! Click here https://bit.ly/2WmFSiL and discover this limited edition watch!

The Sopranos gets a prequel film! Here's my review for THE MANY SAINTS OF NEWARK!

## Venom: Let There Be Carnage - Movie Review
 - [https://www.youtube.com/watch?v=uunDA7KJSTA](https://www.youtube.com/watch?v=uunDA7KJSTA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-09-30 00:00:00+00:00

Thank you Satisfye for sponsoring this video! All grips and bundles are on sale right now with up to 50% off and you can take off an additional 5% when you click https://bit.ly/satisfye-jeremyjahns and use my code JEREMY5

FINALLY Venom and Carnage face off on the big screen! Was it worth the wait? Here's my review for VENOM: LET THERE BE CARNAGE!

#Venom #LetThereBeCarnage

