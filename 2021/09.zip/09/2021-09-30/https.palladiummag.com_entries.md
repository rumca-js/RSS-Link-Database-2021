## A World Without Sci-Hub – Palladium
 - [https://palladiummag.com/2021/09/24/a-world-without-sci-hub/](https://palladiummag.com/2021/09/24/a-world-without-sci-hub/)
 - RSS feed: https://palladiummag.com
 - date published: 2021-09-30 08:14:39.951392+00:00

Sci-Hub has become foundational for scientific research. What if we didn’t need it at all?

