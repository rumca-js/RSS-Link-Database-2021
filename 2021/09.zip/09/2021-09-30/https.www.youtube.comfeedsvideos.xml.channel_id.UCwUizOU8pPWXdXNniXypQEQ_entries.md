# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## US Government Collapsing and We’re Pretending It’s Not - News Update!
 - [https://www.youtube.com/watch?v=Hn74sNysCKc](https://www.youtube.com/watch?v=Hn74sNysCKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-10-01 00:00:00+00:00

Get your Cacao Bliss Here - https://earthechofoods.com/jpsears
Discount code for 15% off  - JP 

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

The US government is collapsing and we’re pretending it’s not! All in the latest news update! Stay current on the latest breaking news by tuning in to we lie to you news!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

