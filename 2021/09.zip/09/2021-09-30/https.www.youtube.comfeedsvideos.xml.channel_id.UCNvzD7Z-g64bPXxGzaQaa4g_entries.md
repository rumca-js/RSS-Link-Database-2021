# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## SPIDER-MAN 2 MAKING A BIG CHANGE, GTA TRILOGY REMASTER RELEASE DATE LEAK & MORE
 - [https://www.youtube.com/watch?v=goa5gyVE0E8](https://www.youtube.com/watch?v=goa5gyVE0E8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-10-01 00:00:00+00:00

Thank you Turtle Beach for sponsoring this video. Click https://bit.ly/3kUR9Ag to order your Turtle Beach Recon Controller today!

An update on Insomniac's Spider-Man, the 4K Switch Pro rumors return,  Konami eyes a return to gaming with Metal Gear Solid/Castlevania, and more in a week full of gaming news.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​



 ~~~~STORIES~~~~



GTA trilogy leak
https://kotaku.com/the-gta-remastered-trilogy-sure-seems-imminent-now-1847774767

SPIDERMAN 2's BIGGEST CHANGE REVEALED
https://www.eurogamer.net/articles/2021-09-29-spider-man-2-will-be-a-darker-empire-strikes-back-style-sequel

Konami returns?
https://www.videogameschronicle.com/news/konami-is-set-to-revive-metal-gear-castlevania-and-silent-hill/
See also: https://www.videogameschronicle.com/news/konamis-free-to-play-efootball-is-already-the-worst-rated-steam-game-in-history/



Bluepoint
https://blog.playstation.com/2021/09/30/welcoming-bluepoint-games-to-the-playstation-studios-family/
Netflix buys Night School
https://www.polygon.com/22699258/netflix-night-school-studio-acquisition-oxenfree


Xbox accessibility
https://www.theverge.com/2021/10/1/22702660/xbox-games-accessibility-feature-tags
Cloud gaming
https://news.xbox.com/en-us/2021/09/30/xbox-cloud-gaming-launches-in-australia-brazil-japan-and-mexico/
Japan stuff: 
https://news.xbox.com/en-us/2021/09/30/xbox-at-tokyo-game-show-2021-recap/

**Making of Robocop vs Terminator
https://www.gamesradar.com/we-wanted-as-much-gore-and-blood-as-possible-the-making-of-robocop-versus-the-terminator/?utm_content=gamesradar&utm_source=facebook.com&utm_campaign=socialflow&utm_medium=social&fbclid=IwAR3mxKhPGeB1LiA709_S6Uer9JUpQKXMWJ4RpfkEDjkyxL0111a2ha-wNHs



Gungrave
https://youtu.be/xwGyD4ktGEo

Starship Troopers demo
https://www.pcgamer.com/starship-troopers-terran-command-is-getting-a-playable-demo-next-week/

Monster Hunter Rise PC
https://www.youtube.com/watch?v=nhk2DE7m8nc

Outer Worlds DLC LAunch trailer
https://www.youtube.com/watch?v=tpLzxZvNIlg

New World


Alan Wake 7 minutes 4k gameplay IGN
https://www.youtube.com/watch?v=GiD9rELS6r0


Switch 4k Dev kits
https://www.polygon.com/22701181/nintendo-switch-4k-model-release-date-report


Twisted Revival Free To Play?
https://www.ign.com/articles/twisted-metal-revival-destruction-allstars-developer

## 10 Open World Games With the MOST DANGEROUS WORLDS
 - [https://www.youtube.com/watch?v=g08yeljvSjw](https://www.youtube.com/watch?v=g08yeljvSjw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-30 00:00:00+00:00

Some video game open worlds are just harsh and unforgiving. Here are some gaming worlds where  almost everything is a danger to the player.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

