# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Anti-cheat works on Linux, Firefox stumbles again, and HDR support - Linux news - September 2021
 - [https://www.youtube.com/watch?v=KxyVC4zE1Qo](https://www.youtube.com/watch?v=KxyVC4zE1Qo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2021-10-01 00:00:00+00:00

Improve your VM patching workflow with QEMUCare: https://tuxcare.com/live-patching-services/qemucare/sysadmin/?utm_campaign=TC-QEMU-TLE-September&utm_source=youtube&utm_medium=paidsocial 


Get your Linux desktop or laptop here: https://slimbook.es/en/


This time, we have Red Hat hiring for HDR support on Linux, Firefox making more controversial decisions, and support for Linux from the major anti cheat providers, among a LOT of other linux gaming news.



👏 SUPPORT THE CHANNEL:
Get access to an exclusive weekly podcast, vote on the next topics I cover, and get your name in the credits:

YOUTUBE: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

🏆 FOLLOW ME ELSEWHERE:
Join us on our new Discord server: https://discord.gg/xK7ukavWmQ
Twitter : http://twitter.com/thelinuxEXP
My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw
Follow me on ODYSEE: https://odysee.com/@TheLinuxExperiment:e
Or join ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e


00:00 Intro
01:13 Linux News
05:45 Application News
07:30 Gaming News


Red hat seems to be hiring to finally have good HDR support on Linux.  
https://www.phoronix.com/scan.php?page=news_item&px=Red-Hat-Hiring-For-Linux-HDR


https://global-redhat.icims.com/jobs/89344/senior-software-engineer---hdr-enablement/job

Linux Mint has finally revamped their website, which was getting long in the tooth.
https://linuxmint.com/

Jordan Petridis, a GNOME developer, wrote a blog post about the recent drama about libadwaita and theming. 
https://blogs.gnome.org/alatiera/2021/09/18/the-truth-they-are-not-telling-you-about-themes/

GNOME 41 was released.
https://www.youtube.com/watch?v=qCeVAqj97DQ&t=353s

Google seems to want to bring the Android kernel closer to mainline Linux.
https://arstechnica.com/gadgets/2021/09/android-to-take-an-upstream-first-development-model-for-the-linux-kernel/

Christian Schaller, the Senior Desktop manager at RedHat outlined the vision that Fedora has for the future of the Linux desktop.
https://blogs.gnome.org/uraeus/2021/09/24/fedora-workstation-our-vision-for-linux-desktop/


Firefox seems to be experimenting with using Bing as the default search engine.
https://www.ghacks.net/2021/09/17/firefox-experiment-is-testing-bing-as-the-default-search-engine/

Now, a maybe more controversial decision, Firefox will be shipped as a SNAP by default on Ubuntu. 
https://www.omgubuntu.co.uk/2021/09/ubuntu-makes-firefox-snap-default

Another nice achievement for Proton, as the experimental branch managed to receive updates to get DeathLoop to run on day one on Linux, on AMD and Nvidia GPUs.
https://www.gamingonlinux.com/2021/09/proton-experimental-gets-deathloop-working-on-linux-with-amd-gpus


Ray tracing on AMD GPUs is also getting closer to being a reality.
https://www.basnieuwenhuizen.nl/raytracing-starting-to-come-together/

DXVK 1.9.2 was released.
https://github.com/doitsujin/dxvk


Nvidia released a new driver update for Linux, version 470.74.
https://www.gamingonlinux.com/2021/09/nvidia-47074-for-linux-is-out-fixing-up-memory-usage-for-direct3d-12-with-vkd3d-proton

Valve has published an official FAQ for the Steam Deck.
https://www.steamdeck.com/en/faq

Epic and BattleEye both announced support for Linux, including Wine and proton.
https://www.youtube.com/watch?v=aZ9SKS4tAvw&t=105s

WIne 6.18 was released.
https://www.winehq.org/announce/6.18

Proton 6.3-7 was released.
https://github.com/ValveSoftware/Proton/wiki/Changelog




▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Motion Graphics provided by https://www.tubebacks.com

YouTube Channel: https://goo.gl/aayJRf
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

