# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Console Wars - END OF PC MASTER RACE
 - [https://www.youtube.com/watch?v=HN_U7yyvq1Q](https://www.youtube.com/watch?v=HN_U7yyvq1Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-10-01 00:00:00+00:00

Get your PC Master Race sticker here! ► https://www.patreon.com/flashgitz 

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

Animation ►
Don Greger
CalebJordann
Holly Gee
Ollie Kremer

Backgrounds ►  
Soured Apple https://www.twitter.com/SouredApple
Naav Draws https://www.instagram.com/naav_draws/

Music ►
Zach Heyde https://youtu.be/9MvTtuFZK-E

Sound ► 
Justin Greger

VO ► 
Tom
   PC Master Race
   Rasheed
   Console Peasants
Don
   Additional PC Master Race

Ad Composited by ► 
Oddest of the Odd

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

