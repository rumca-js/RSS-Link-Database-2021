# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Waxahatchee - Can't Do Much (Live on KEXP)
 - [https://www.youtube.com/watch?v=hDlF9PEN9DE](https://www.youtube.com/watch?v=hDlF9PEN9DE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-01 00:00:00+00:00

http://KEXP.ORG presents Waxahatchee performing "Can't Do Much" live in the KEXP gathering space. Recorded September 16, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

https://www.waxahatchee.com
http://kexp.org

## Waxahatchee - Fire (Live on KEXP)
 - [https://www.youtube.com/watch?v=f1YLZ8EwFEU](https://www.youtube.com/watch?v=f1YLZ8EwFEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-01 00:00:00+00:00

http://KEXP.ORG presents Waxahatchee performing "Fire" live in the KEXP gathering space. Recorded September 16, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

https://www.waxahatchee.com
http://kexp.org

## Waxahatchee - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Dng1ahrZ3qU](https://www.youtube.com/watch?v=Dng1ahrZ3qU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-01 00:00:00+00:00

http://KEXP.ORG presents Waxahatchee performing live in the KEXP gathering space. Recorded September 16, 2021.

Songs:
Can't Do Much
Lilacs
Ruby Falls
Fire

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

https://www.waxahatchee.com
http://kexp.org

## Waxahatchee - Lilacs (Live on KEXP)
 - [https://www.youtube.com/watch?v=u9IaH5C7_44](https://www.youtube.com/watch?v=u9IaH5C7_44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-01 00:00:00+00:00

http://KEXP.ORG presents Waxahatchee performing "Lilacs" live in the KEXP gathering space. Recorded September 16, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

https://www.waxahatchee.com
http://kexp.org

## Waxahatchee - Ruby Falls (Live on KEXP)
 - [https://www.youtube.com/watch?v=kav3Ac8NK_o](https://www.youtube.com/watch?v=kav3Ac8NK_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-10-01 00:00:00+00:00

http://KEXP.ORG presents Waxahatchee performing "Ruby Falls" live in the KEXP gathering space. Recorded September 16, 2021.

Host: Cheryl Waters
Audio Engineers: Julian Martlew & Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

https://www.waxahatchee.com
http://kexp.org

