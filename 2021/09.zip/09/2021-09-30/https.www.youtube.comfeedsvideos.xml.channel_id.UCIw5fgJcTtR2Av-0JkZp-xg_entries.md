# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "No Soup For You!" / Remixing the Soup Nazi from Seinfeld
 - [https://www.youtube.com/watch?v=onpoHfisauE](https://www.youtube.com/watch?v=onpoHfisauE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-10-01 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Gear used:
- Korg M1 Plus One (the Seinfeld bass machine!)
- Teenage Engineering OP-1
- Korg Minilogue
- Korg Microkorg XL
- 1010music Blackbox & Bluebox
- Fender Stratocaster
- Ceriatone Prince Tut AA1164
- Fairfield Circuitry Shallow Water

George:
I didn't get any bread.
Jerry:
Just forget it. Let it go.
George:
Excuse me, I think you forgot my bread.
Soup Nazi:
Bread, two dollars extra.
George:
Two dollars? But everybody in front of me got free bread.
Soup Nazi:
You want bread?
George:
Yes, please.
Soup Nazi:
THREE dollars!
George:
What?!
Soup Nazi:
NO SOUP FOR YOU!

