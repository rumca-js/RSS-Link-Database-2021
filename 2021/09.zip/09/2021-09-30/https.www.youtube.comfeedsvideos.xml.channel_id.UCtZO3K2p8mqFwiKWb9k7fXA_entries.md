# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## The billionaire behind all your favorite tech
 - [https://www.youtube.com/watch?v=dEXH-K1m2kI](https://www.youtube.com/watch?v=dEXH-K1m2kI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2021-09-30 00:00:00+00:00

The Nebula / CuriosityStream bundle is no longer active. Instead, you can sign up for Nebula directly with my discount now for about $2.5 a month with a yearly plan, which includes Nebula Originals AND the whole Nebula Classes platform, too, including my own class. Sign up here: https://go.nebula.tv/techaltar

Technorama Season 1 Episode 1:  https://nebula.app/videos/technorama-what-early-scifi-monsters-tell-us-about-history

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

Foxconn is the world's largest contract manufacturer, the maker of Apple's iPhones, iPads and a ton of other consumer electronics. In this episode we find out how they got so big, what the founder Terry Gou is like and where the company is headed to next.

The Story Behind - ep. 80

This episode plus bonus footage on Nebula: https://nebula.app/videos/techaltar-how-foxconn-got-to-make-all-your-electronics-whats-next

New York Times article about 'iPhone City': https://www.nytimes.com/2016/12/29/technology/apple-iphone-china-foxconn.html

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  



TechAltar theme music by Edemski: https://soundcloud.com/edemski

All the other music comes from from Epidemic Sound: https://epidemicsound.com/creators

