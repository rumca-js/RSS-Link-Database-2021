# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Sofiane Pamart live under the Northern Lights, in Lapland, Finland for Cercle
 - [https://www.youtube.com/watch?v=2OHFgjuy3DI](https://www.youtube.com/watch?v=2OHFgjuy3DI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2021-10-01 00:00:00+00:00

Sofiane Pamart playing the first live on a grand piano at freezing temperatures under the Northern Lights, in Lapland, Finland for Cercle.

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ Cercle Records 
Sofiane Pamart - BOREALIS EP: https://cercle.lnk.to/SofianePamartBOREALIS

67° 53' 44.4" N 24° 03' 11.4" E

☞  Sofiane Pamart
https://www.instagram.com/sofianepamart/
https://apple.co/3zX8GvU
https://open.spotify.com/artist/4RB2EEsmLhQTOSVQQpDzNg

Video credits:

Artist: Sofiane Pamart
Venue: Northern Lights, in Lapland, Finland
Produced by Cercle
Executive producers: Philippe Tuchmann & Derek Barbolla
Film directed by: Pol Souchier & Derek Barbolla
Director of photography:  Mathieu Glissant
Cameraman: Mickaël Fidjili 
Drone pilots: Anthony Brzeski (pilot) + Brieuc Le Mercier (camera) - Let's Fly Production
FPV drone: Filip Petronijević
Post-production: Mathieu Glissant (Saison Unique Production)
Mix: Paul-Edouard Laurendeau
Sound Mastering: Equus
Production team: Anaïs De Framond, Dan Aufseesser, Armand Prouhèze
Communication: Pol Souchier, Bérénice Saïag & Lola Lebrati 
Graphic Design: Anaëlle Rouquette
Technical Manager: Aurélien Moisan
Chief Financial Officer: Andy Cheremond
Label Assistant: Clémence Maillard
Photographer : Jérémie Tridard
BTS: Mickaël Fidjili

--

Official Partners:
Moncler
Visit Finland 

Special thanks to:
Guillaume Heritier
Alex Drewniak (BC DGTL)
Sergei Shkurov
F-Musiikki
PIAS/ 88 Touches
Jacques Andre Desbuisson
Elisa Muzio
SONY
Camille Ratto
Columbia
Galerie Joseph

______

This artistic performance has been recorded live. 

Tracklist:

00:00 Aurora - Sofiane Pamart
02:14 Borealis - Sofiane Pamart
05:00 Le Caire - Sofiane Pamart
08:00 Solitude - Sofiane Pamart
11:12 Medellin - Sofiane Pamart
15:17 Paris - Sofiane Pamart
19:20 La Havane - Sofiane Pamart
22:19 Séoul - Sofiane Pamart
25:28 Chicago - Sofiane Pamart
29:03 Alba - Sofiane Pamart
32:15 Invisible - Sofiane Pamart
34:33 Ha Long Bay - Sofiane Pamart
36:37 Les Yeux de ma mère - Arno & Sofiane Pamart
39:14 London - Sofiane Pamart
41:25 Sahara - Sofiane Pamart
43:14 Madagascar - Sofiane Pamart
44:57 Sicilia - Sofiane Pamart
47:20 Nara - Sofiane Pamart
50:39 Kittila - Sofiane Pamart
53:55 Medellin - Sofiane Pamart
58:12 La Bohème - Charles Aznavour (Sofiane Pamart version)
01:00:37 Q&A

______

Follow us on http://www.cercle.io
ⓒ Photo thumbnail by AllAboutLapland

