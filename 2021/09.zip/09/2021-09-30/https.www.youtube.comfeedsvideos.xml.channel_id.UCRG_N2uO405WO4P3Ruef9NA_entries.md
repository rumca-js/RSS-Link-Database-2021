# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## The first Fairphone you might actually want
 - [https://www.youtube.com/watch?v=KZkFXF77Yiw](https://www.youtube.com/watch?v=KZkFXF77Yiw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-10-01 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc

You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us.

Technorama Season 1 Episode 1:  https://nebula.app/videos/technorama-what-early-scifi-monsters-tell-us-about-history

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week the Fairphone 4 and Fairphone True Wireless earbuds were released and they seem like good products with a catch, Honor reclaimed their marketshare in China, and LeTV announced the first non-Huawei phone with HMS and Huawei software.

Episode 65


Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 

Quiz: https://link.crrowd.com/quiz

This video on Nebula: https://nebula.app/videos/the-friday-checkout-the-first-fairphone-you-might-actually-want


 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   


Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 
LeTV video on Bilibili: https://www.bilibili.com/video/BV1fg411c7io?from=search&seid=15414570859356634474&spm_id_from=333.337.0.0

0:00 Intro
0:38 Release Monitor
2:21 Fairphone 4 & earbuds
5:23 Honor's big comeback
6:56 Huawei software on 3rd party phones

