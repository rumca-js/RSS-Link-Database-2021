# Source:Academy of Ideas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCiRiQGCHGjDLT9FQXFW0I3A, language:en-US

## The Big Lie - How to Enslave the World
 - [https://www.youtube.com/watch?v=6VfJ0BJvt7Y](https://www.youtube.com/watch?v=6VfJ0BJvt7Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCiRiQGCHGjDLT9FQXFW0I3A
 - date published: 2021-09-30 21:14:05+00:00

The Big Lie - How to Enslave the World

