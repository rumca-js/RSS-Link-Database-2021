# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Gingers Can't Feel Pain Properly - THIS IS WHY!
 - [https://www.youtube.com/watch?v=qkufPL1CE9w](https://www.youtube.com/watch?v=qkufPL1CE9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-09-30 00:00:00+00:00

There are ALOT of stereotypes for us gingers, and the scientific truth is even weirder!
Check out http://KiwiCo.com/Asap and get your first month free!

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Gregory Brown
Edited by: Luka Šarlija

References:
https://pubs.asahq.org/anesthesiology/article/102/3/509/7338/Increased-Sensitivity-to-Thermal-Pain-and-Reduced
https://jmg.bmj.com/content/42/7/583.short
https://www.nih.gov/news-events/nih-research-matters/study-finds-link-between-red-hair-pain-threshold
https://www.degruyter.com/document/doi/10.1016/j.sjpain.2010.08.005/html
https://www.futuremedicine.com/doi/abs/10.2217/14622416.9.2.179
https://pubmed.ncbi.nlm.nih.gov/30787281/
https://pubmed.ncbi.nlm.nih.gov/23362906/
https://pubmed.ncbi.nlm.nih.gov/2765023/
https://pubmed.ncbi.nlm.nih.gov/15731586/
https://pubmed.ncbi.nlm.nih.gov/34001865/

