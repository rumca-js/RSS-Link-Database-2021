# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Jak zabrać ze sobą prąd?
 - [https://www.youtube.com/watch?v=k2Z7OCtXndI](https://www.youtube.com/watch?v=k2Z7OCtXndI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-09-30 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Od dawna nasz rozwój opieramy na procesach, które emitują do atmosfery gazy cieplarniane. Jeżeli chcemy ograniczyć skutki takich występków czeka nas duża zmiana. Niekoniecznie jednak musi to być zmiana na gorsze - również w kwestii szeroko rozumianej mobilności.

===
Rozkład jazdy:

0:00 Tak się zaczęło
3:00 Nogi żaby
4:46 Co się dzieje w cytrynie
7:40 Baterie, akumulatory, ogniwa i... baterie...
14:27 Czy tak się skończy [Mercedes]

===
Źródła (wybrane):

Studia chemiczne (dużo... dużo lat)

K. Pigoń i in. - Chemia fizyczna
A. Bielański - Chemia nieorganiczna
R. Petrucci i in. - General chemistry: principles and modern applications
P. Atkins i in. - Chemia fizyczna

