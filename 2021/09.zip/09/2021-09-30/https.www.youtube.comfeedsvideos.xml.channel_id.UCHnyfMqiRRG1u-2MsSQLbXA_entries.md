# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## How They Caught The Golden State Killer
 - [https://www.youtube.com/watch?v=KT18KJouHWg](https://www.youtube.com/watch?v=KT18KJouHWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-09-30 00:00:00+00:00

Your genetic code is probably already in a database, without you ever giving a sample or permission. This video is sponsored by Brilliant. The first 200 people to sign up via https://brilliant.org/veritasium get 20% off a yearly subscription.

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
A huge thanks to Paul Holes, Billy Jensen, Brett Williams, Dr Connie Bormans and Dr Doc Edge for being part of this video. Thanks to Verogen and Family Tree DNA for giving me access to film.

Thanks to Sonya Pemberton, Joe Hanson, Raquel Nuno, CGP Grey, and numerous Patreon supporters for helpful feedback on an earlier version of this video.

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
References:
Phillips, C. (2018). The Golden State Killer investigation and the nascent field of forensic genealogy. Forensic Science International: Genetics, 36, 186-188. -- https://ve42.co/Phillips2018

Guerrini, C. J., Robinson, J. O., Petersen, D., & McGuire, A. L. (2018). Should police have access to genetic genealogy databases? Capturing the Golden State Killer and other criminals using a controversial new forensic technique. PLoS biology, 16(10), e2006906. -- https://ve42.co/Guerrini

Ram, N., Guerrini, C. J., & McGuire, A. L. (2018). Genealogy databases and the future of criminal investigation. Science, 360(6393), 1078-1079. -- https://ve42.co/Ram2019

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Special thanks to Patreon supporters: Andrew, Diffbot, Micah Mangione, MJP, Gnare, Nick DiCandilo, Dave Kircher, Edward Larsen, Burt Humburg, Blake Byers, Dumky, Evgeny Skvortsov, Meekay, Bill Linder, Paul Peijzel, Mac Malkawi, Michael Schneider, Big Badaboom, Ludovic Robillard, Jim buckmaster, fanime96, Juan Benet, Ruslan Khroma, Robert Blum, Richard Sundvall, Lee Redden, Vincent, Marinus Kuivenhoven, Alfred Wallace, Clayton Greenwell, Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal 


▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Executive Producer: Derek Muller
Writer: Derek Muller
Animators: Ivy Tello, Another Angle 3D Visuals
SFX: Shaun Clifford
Camerapeople: Derek Muller, Raquel Nuno, Shirley Dutoit, Emily Zhang
Editor: Derek Muller
Producers: Derek Muller, Casey Rentz, Petr Lebedev, Emily Zhang
Additional video supplied by Getty Images
Music from Epidemic Sound https://epidemicsound.com
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

