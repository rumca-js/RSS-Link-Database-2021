# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## The Pandemic - A Children's Song
 - [https://www.youtube.com/watch?v=Ldw10Ef4V8I](https://www.youtube.com/watch?v=Ldw10Ef4V8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-09-30 00:00:00+00:00

The realities of living through a pandemic but for kids... well, sort of...

Don't forget to SUBSCRIBE!!

Also, join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

