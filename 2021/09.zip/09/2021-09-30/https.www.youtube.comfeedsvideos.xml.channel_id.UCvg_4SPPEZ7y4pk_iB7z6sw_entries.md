# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Second Screen Gaming: A Failed Gimmick
 - [https://www.youtube.com/watch?v=_Az1Nuk4lVQ](https://www.youtube.com/watch?v=_Az1Nuk4lVQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-10-01 00:00:00+00:00

Wouldn't it be fun if, instead of playing games on one screen, you had two screens? Ya, you'd think so, wouldn't you.

Turns out a lot of people did, and there's a long line of predecessors to the whole "Wii U gamepad" craze. Today I kinda talk about that, and other stuff. Just a whole bunch of second screen stuff. 

Twitter: https://twitter.com/WhimsuHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpe...


Additional Credits for Footage:
NDS525
christopherlanges
greenduivel
sceablog
Stop Skeletons From Fighting
The Geek Critique
Sparkster28
The Nerd Lair
BOBdotEXE
IGN
Gadgets and Gears
SpaceKappa
videogameclipcollect
outsidexbox
gamedrunk.com
Adam Koralik
JoshKall Plays
jvgsjeff
TouchGameplay
GamerHubTV

