# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Eastward | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=9KtxHbkiORo](https://www.youtube.com/watch?v=9KtxHbkiORo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-14 00:00:00+00:00

Please welcome Elise Avery to the 3 Minute Review team with their first review on Eastward, developed by Pixpil.

Eastward on Steam: 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## What A Game Needs To Do To Hold Our Attention | Slightly Something Else
 - [https://www.youtube.com/watch?v=2zaeaNyLdys](https://www.youtube.com/watch?v=2zaeaNyLdys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-14 00:00:00+00:00

This week on Slightly Something Else, Yahtzee and Jack discuss primary and secondary loops of video games and what they need for a game to hold their attention.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Deathloop - The First Two Hours + Multiplayer | The Editor's Hour with Nick and KC
 - [https://www.youtube.com/watch?v=6_hkvWhZxds](https://www.youtube.com/watch?v=6_hkvWhZxds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-13 00:00:00+00:00

For The Editor's Hour today Nick is going to check out Deathloop.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## How Hollow Knight Makes You Feel Feeble
 - [https://www.youtube.com/watch?v=3kHamcSDgko](https://www.youtube.com/watch?v=3kHamcSDgko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-13 00:00:00+00:00

Welcome to The Anatomy of Hollow Knight.

In this episode, we take a look at how Team Cherry created one of the tightest games I have ever seen. Diving into the game feel, sound and map design of one of the best indie games in recent memory.

If you want to see more game design content a new Anatomy episode will release every other week, or you can subscribe to JM8s personal channel for similar content: https://www.youtube.com/c/JM8GameDesign

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps:
Introduction - 00:00
Overview - 00:20
Feeling Feeble - 01:30
Mechanical Mastery - 04:02
Tenuous Teaching  - 06:30
Silence & Signifiers - 08:22
Mystifying Map Design - 10:33
Lost in Translation - 12:38
Final Thoughts - 14:25


---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Escapist Indie Showcase Returns on September 20th
 - [https://www.youtube.com/watch?v=CU7JzmdD3-A](https://www.youtube.com/watch?v=CU7JzmdD3-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-09-13 00:00:00+00:00

The Escapist Indie Showcase returns on September 20th with a live premiere right here on the main Escapist YouTube channel. 70+ games, world premieres and plenty of brand new exclusive gameplay-filled trailers.

We're also launching an Indie Showcase Channel for everything indie game related alongside the showcase. https://www.youtube.com/c/TheEscapistIndieShowcase

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

