# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 5 Reasons The Victorian Era Was Utter Insanity | Answers With Joe
 - [https://www.youtube.com/watch?v=3IDN9gTAtjg](https://www.youtube.com/watch?v=3IDN9gTAtjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-09-13 00:00:00+00:00

Use code JOESCOTT14 to get 14 FREE MEALS across your first 5 HelloFresh boxes plus free shipping at https://bit.ly/3qmkZPn !
The Victorian Era was an age of new discoveries and technologies that changed everything about the way we live. It basically created the modern world as we know it. But that time of transition also led to some very, very weird ideas and dangers that seem baffling today.

Here's the video that includes the intro about L'Innconoe:
https://youtu.be/xHIooZqKesM


Watch this video ad-free on Nebula: https://nebula.tv/videos/joe-scott-5-reasons-the-victorian-era-was-utter-insanity

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.britannica.com/biography/Carl-Wilhelm-Scheele

https://www.smithsonianmag.com/smart-news/victorian-wallpaper-got-its-gaudy-colors-poison-180962709/

Absolute History: https://youtu.be/K3Jef7i7v1U

https://allthatsinteresting.com/victorian-facts

https://www.theatlantic.com/national/archive/2011/04/fdr-grew-up-in-a-dress-it-wasnt-always-blue-for-boys-and-pink-for-girls/237299/

https://thevictorianhistorian.com/beauty-fashion/

https://theconversation.com/air-pollution-in-victorian-era-britain-its-effects-on-health-now-revealed-87208

https://allthatsinteresting.com/victorian-death-photos

https://victorianchildren.org/victorian-child-labor/

https://fiveminutehistory.com/how-the-power-of-pictures-helped-end-child-labor-in-the-united-states/

https://www.historyextra.com/period/victorian/the-rise-and-fall-of-the-workhouse/

https://www.historic-uk.com/HistoryUK/HistoryofBritain/Victorian-Workhouse/

https://www.historic-uk.com/CultureUK/Two-Penny-Hangover/

https://wonderfulcollection.wordpress.com/2015/05/13/a-penny-for-your-lodgings/

https://historycollection.com/grim-realities-of-life-in-londons-19th-century-slums/9/

https://www.atlasobscura.com/articles/the-history-of-hermits-in-gardens

The History Guy's episode on The Great Stink: https://youtu.be/jD7nRrSH_VE

https://www.historic-uk.com/HistoryUK/HistoryofBritain/Londons-Great-Stink/

https://www.smithsonianmag.com/smithsonian-institution/great-moon-hoax-was-simply-sign-its-time-180955761/

