# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## ⚠️ Patch NOW ⚠️ - Devastating "NUCLEAR-TIER" Apple Exploit Found
 - [https://www.youtube.com/watch?v=OXzYYilrpXc](https://www.youtube.com/watch?v=OXzYYilrpXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-09-14 00:00:00+00:00

Though rare, this exploit is SO devastating that you should patch IMMEDIATELY.

• iMazing with Spyware Checker: https://imazing.com/

The exploit called "ForcedEntry", used by the infamous 'Pegasus' spyware, has finally been patched by Apple. It affects ALL iOS, MacOS, and WatchOS devices.
It is a No-Click iMessage exploit that can take over your phone simply by sending you a text message, with NO input by you. This is possibly the worst kind of exploit imaginable.
Though unlikely to affect average users, it HAS been used to target high profile public figures.

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Patches to Install
0:55 - What is the Exploit?
2:15 - Why You PROBABLY Shouldn't Worry
3:15 - Check if Your Phone Has the Spyware

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

