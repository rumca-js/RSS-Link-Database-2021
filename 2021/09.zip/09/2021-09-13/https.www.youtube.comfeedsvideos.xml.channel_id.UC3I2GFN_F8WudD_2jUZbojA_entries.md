# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Subsonic Eye - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=DUb9c_Bpk38](https://www.youtube.com/watch?v=DUb9c_Bpk38)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-09-14 00:00:00+00:00

http://KEXP.ORG presents Subsonic Eye performing live, recorded exclusively for KEXP.

Songs:
Cabin Fever
Fruitcake
Dijangka
Animinimism
Unearth

Session recorded at Kribo Records, Singapore
Directed by Edward Khoo
Assistant Director: Huang Junxiang
Camera Operators: JT, Chris Khoo, Lee Jing Wei (https://leejingwei.com), Christopher Sim (https://chris-sim.work)
Editors: Chris Khoo & Raphael Ong
Colorist: Lee Jing Wei
Production Assistant: Jarel Lim Jay Ee
Audio Engineer: Zhang Bo
Mix Engineers: Daniel Castro Borces & Jared Lim
Mastering Engineer: Kin Leonn (https://kinleonn.net)
Special Thanks to Maggot of Kribo Records (https://kriborecords.bandcamp.com)

Subsonic Eye is Nur Wahidah on vocals, Daniel Castro Borces & Jared Lim on guitar, Spencer Tan on bass, and Lucas Tee on drums

https://subsoniceye.bandcamp.com
https://middleclasscigars.com
http://kexp.org

## Subsonic Eye - Performance & Interview (Live on KEXP)
 - [https://www.youtube.com/watch?v=FfyC7kLf36I](https://www.youtube.com/watch?v=FfyC7kLf36I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-09-13 00:00:00+00:00

http://KEXP.ORG presents Subsonic Eye sharing a live performance recorded exclusively for KEXP and talking to DJ Troy Nelson. Recorded August 31, 2021.

Songs:
Cabin Fever
Fruitcake
Dijangka
Animinimism
Unearth

Session recorded at Kribo Records, Singapore
Directed by Edward Khoo
Assistant Director: Huang Junxiang
Camera Operators: JT, Chris Khoo, Lee Jing Wei (https://leejingwei.com), Christopher Sim (https://chris-sim.work)
Editors: Chris Khoo & Raphael Ong
Colorist: Lee Jing Wei
Production Assistant: Jarel Lim Jay Ee
Audio Engineer: Zhang Bo
Mix Engineers: Daniel Castro Borces & Jared Lim
Mastering Engineer: Kin Leonn (https://kinleonn.net)
Special Thanks to Maggot of Kribo Records (https://kriborecords.bandcamp.com)

Subsonic Eye is Nur Wahidah on vocals, Daniel Castro Borces & Jared Lim on guitar, Spencer Tan on bass, and Lucas Tee on drums

https://subsoniceye.bandcamp.com
https://middleclasscigars.com
http://kexp.org

