# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Craziness of Miami with Billy Corben
 - [https://www.youtube.com/watch?v=d4Xud2Gqoxk](https://www.youtube.com/watch?v=d4Xud2Gqoxk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-09-14 00:00:00+00:00

Taken from JRE #1706 w/Billy Corben:
https://open.spotify.com/episode/5cyr3P7FzRpjFUrRkH6fGt?si=MIVV5OWASXOVu_eQ6Rrzaw&dl_branch=1

## The Time Billy Corben Met Janet Jackson
 - [https://www.youtube.com/watch?v=5nW53a_RhYg](https://www.youtube.com/watch?v=5nW53a_RhYg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-09-14 00:00:00+00:00

Taken from JRE #1706 w/Billy Corben:
https://open.spotify.com/episode/5cyr3P7FzRpjFUrRkH6fGt?si=MIVV5OWASXOVu_eQ6Rrzaw&dl_branch=1

