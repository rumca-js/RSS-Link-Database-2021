# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## New LotR & Harry Potter Games!🎮 KOTOR Remake🤺 Ghost in the Shell IMAX🎥 -Fantasy News
 - [https://www.youtube.com/watch?v=l2cVsHsBqnk](https://www.youtube.com/watch?v=l2cVsHsBqnk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-09-14 00:00:00+00:00

Let's jump into the fantasy news!
Support Wraithmarked Creative here: https://www.kickstarter.com/projects/wraithmarked/amarkofkings?ref=eo4yew 

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: http://dbh.la/fantasynews
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

New P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Intro

00:44 Delightfully Deadly: https://twitter.com/SubPress/status/1437400077593681921 

01:33 One Piece sales: https://www.animenewsnetwork.com/news/2021-09-10/all-100-one-piece-manga-volumes-have-each-sold-over-1-million-copies/.177204 

02:27 LOTR Box Set: https://www.cbr.com/lord-of-the-rings-hobbit-4k-middle-earth-box-set/ 

05:37 LOTR Strategy Game: https://www.youtube.com/watch?v=BwRVrC0dMfU&ab_channel=TheLordoftheRings%3ARisetoWar 

07:14 Ghost In The Shell Imax Release: https://therottenusagi.com/anime/ghost-in-the-shell-4k-remaster-to-see-limited-time-imax-release/amp/ 

08:51 Spider-man better than superman: https://thehill.com/changing-america/enrichment/arts-culture/571770-spider-man-defeats-superman-to-become-most-expensive 

09:57 Attack on Titan Game: https://animecorner.me/new-attack-on-titan-mobile-game-announced/ 

10:37 Harry Potter Game: https://www.youtube.com/watch?v=zeyWrudLpHY&ab_channel=HarryPotter%3AMagicAwakenedNews 

11:43 Metroid First Look: https://www.youtube.com/watch?v=AOvefm5U250&ab_channel=Nintendo 

13:16 Pokemon Movie: https://www.theilluminerdi.com/2021/09/08/netflix-pokemon-film/ 

14:02 Kotor: https://www.youtube.com/watch?v=lL-RfE-ioJ8&ab_channel=PlayStation

