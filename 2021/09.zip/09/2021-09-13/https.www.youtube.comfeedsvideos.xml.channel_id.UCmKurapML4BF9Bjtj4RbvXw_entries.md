# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Sweet Child O' Mine - Guns N' Roses (Piano & Cello Cover) The Piano Guys
 - [https://www.youtube.com/watch?v=D7SqPiohNDU](https://www.youtube.com/watch?v=D7SqPiohNDU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2021-09-14 00:00:00+00:00

GET OUR LATEST ALBUM: https://smarturl.it/TPG_LATEST_ALBUM 
“Sweet Child O' Mine” by Guns N' Roses piano & cello cover from The Piano Guys
STREAM THIS SONG & GET SHEET MUSIC: https://smarturl.it/Sweet_Child | LIVE TOUR: https://smarturl.it/the10tour Subscribe: https://bit.ly/2XH4GCF | NEWEST videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&playnext=1&index=2

Learn about our beliefs here: https://smarturl.it/TPG_Beliefs 

Follow The Piano Guys:
Instagram: https://instagram.com/thepianoguys
Facebook: https://facebook.com/ThePianoGuys
TikTok: https://tiktok.com/@thepianoguys 
Twitter: https://twitter.com/thepianoguys

Watch More of The Piano Guys: 
Covers: https://youtube.com/playlist?list=PL7j5iXGSdMwc7n8Tsjl-I8zEOEZsjWydx&playnext=1&index=2 
Official Music Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwfDukj_bIIB_1JhbYtaWRYg&playnext=1&index=2 
Newest Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&playnext=1&index=2
Most Popular: https://youtube.com/playlist?list=PL7j5iXGSdMweXm56WEjskhCT5oAeEZJQF&playnext=1 

Listen to The Piano Guys: 
Spotify: https://open.spotify.com/artist/0jW6R8CVyVohuUJVcuweDI?si=8GgyFRhiTz6POs8b0ir2IA&dl_branch=1 
Apple Music: https://music.apple.com/us/artist/the-piano-guys/498030399 
Amazon Music: https://amazon.com/The-Piano-Guys/e/B00BXLTTI4 

Story Behind the Music: 
As you know, we love to reimagine iconic tunes. What musical “hook” is more recognizable than the opening guitar lick of “Sweet Child O’ Mine”? But go deep into your psyche and imagine what this legendary rock tune would have sounded like if it had been instead written by an emotional father of a bride for her walk down the aisle? Did we get it right? 😌👰🏼

We hope you can hear the bell chimes, the awe-inspired intake of breath, the heartfelt emotion, the heaviness of “losing a daughter” overcome by the buoyancy of “gaining a son;” the collective moments leading up to this life event; the hopes, the dreams, all underscored by the overarching joy of witnessing the opening of a beautiful new chapter. How does a father put into words this moment, when his daughter is flying away in order to fulfill what she is meant to become? Where words fail, music speaks. Our nickname for this special take is, “Sweet Child Divine.”

🎹 About the Piano: 
The very special piano used in this video, called the Yamaha Pro2000, was introduced to the piano industry by Phillip Keveren and Craig Knudsen on behalf of Yamaha at the NAMM Show in the year 2000. Only a handful were ever made, with one of them ending up in the Smithsonian. This piano featured a split plexiglass lid that was the original “big brother” to the Yamaha “Neo” featured in so many other TPG album covers and videos (What Makes You Beautiful, Bourne Vivaldi etc.) over the years. Master Piano builder/technician (and Kurt Russell look-alike) Justin Elliot wrapped it in a very special reflective chrome for this “chilled out” look. 
Exact Piano Location: 37.823500, -114.412676

 🎻 About the Cello:
Steve is playing the ONLY TITANIUM CELLO in the world. “Athena Titania'' was designed and handcrafted for Steven by the incomparable Andy Halbert. Andy spent 270 hours perfecting Athena, literally shaping her in the refiner’s fire in order for her to become what she was destined to become. Andy would like to specifically thank Robin Ankrom, his elementary school teacher, who he reports is a Piano Guys fan. 😄
Exact Cello Location: 37.823466, -114.412684

Song & Video Credits:
Sweet Child O’ Mine written by: Guns N’ Roses
The Piano Guys Arrangement produced by: Al van der Beek & Steven Sharp Nelson, written by David Tolk Phillip Keveren Al van der Beek & Steven Sharp Nelson
Orchestrated by: Phillip Keveren & Steven Sharp Nelson
Orchestral strings recorded by: Kent (Hoop) Hooper, recording engineer at “the house of BIG” in Franklin, Tennessee
Vocal textures by: Mackenzie Tolk, recorded at David Tolk Studios
Piano recorded by: David Tolk at his studios and Steve at TPG studios
Solo cello recorded at: TPG studios
Mixed & Mastered by: Al van der Beek
Performed by: Jon Schmidt (piano) & Steven Sharp Nelson (cello)
Sheet music transcriptions by: Craig Knudsen 

Special shoutout:
David Tolk https://davidtolk.com
Phillip Keveren https://phillipkeveren.com/

About The Piano Guys:
Paul, a Yamaha dealer who dabbled in videography, Jon, a professional pianist, Al, a music producer and studio engineer, and Steve, a cellist with a creative superpower called ADHD, all serendipitously joined forces to create the most successful YouTube instrumental music group in history. The Piano Guys’ mission is to inspire and spread hope through incomparably imaginative piano music videos filmed all over the world. On this channel you can regularly find piano covers of music from genres like top 40, pop, classic rock, R&B, hiphop, country, and more. 

#GunsNRoses #PianoCover #CelloCover #Piano #Cello

