## Fossil Fuel Capitalism Is Cutting Our Lives Short
 - [https://tribunemag.co.uk/2021/09/fossil-fuel-capitalism-is-cutting-our-lives-short](https://tribunemag.co.uk/2021/09/fossil-fuel-capitalism-is-cutting-our-lives-short)
 - RSS feed: https://tribunemag.co.uk
 - date published: 2021-09-13 16:10:09.362508+00:00

A new study shows that 17 billion life years could be saved if air pollution was reduced to WHO standards, but there's only one way to do it – ending the system that pollutes the world in the name of profit.

