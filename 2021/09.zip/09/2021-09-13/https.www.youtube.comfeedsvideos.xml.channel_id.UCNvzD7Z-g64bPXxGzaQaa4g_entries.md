# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Copycat Games That ACTUALLY SUCKED
 - [https://www.youtube.com/watch?v=5ifhm5zDlxY](https://www.youtube.com/watch?v=5ifhm5zDlxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-14 00:00:00+00:00

Some copycat games have brought us surprise gems while others have been complete embarrassments. Here are some of the worst ones.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Deathloop: 10 Things The Game DOESN'T TELL YOU
 - [https://www.youtube.com/watch?v=al_akhDljwU](https://www.youtube.com/watch?v=al_akhDljwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-14 00:00:00+00:00

DEATHLOOP (PC, PS5) is an Arkane FPS with lots of surprises and tricks. Here are some beginner tips to get you started.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Deathloop - Before You Buy
 - [https://www.youtube.com/watch?v=8iCrbmokDpI](https://www.youtube.com/watch?v=8iCrbmokDpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-09-13 00:00:00+00:00

Deathloop (PS5, PC) is an Arkane FPS with a different twist. How is it? Let's talk!
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Deathloop: https://amzn.to/3tHtw0T

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

