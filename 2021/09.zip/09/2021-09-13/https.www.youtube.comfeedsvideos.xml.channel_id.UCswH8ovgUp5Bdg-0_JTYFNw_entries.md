# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The Mainstream Media Are Trying To Start A CIVIL WAR!!
 - [https://www.youtube.com/watch?v=Egq8M3c_9pQ](https://www.youtube.com/watch?v=Egq8M3c_9pQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-09-14 00:00:00+00:00

I spoke with #TimPool on my Under the Skin podcast - in it Tim describes how the US have already entered into a psychological civil war! You can listen to the rest of my podcast with Tim Pool on Apple Podcasts here:  http://apple.co/russell 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Jenny May Finn

## Covid & Health: Why Can't We TALK ABOUT The Science?!!
 - [https://www.youtube.com/watch?v=y0PYlLQn_YM](https://www.youtube.com/watch?v=y0PYlLQn_YM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-09-13 00:00:00+00:00

The CEO of salad chain Sweetgreen is facing accusations of fatphobia after he claimed in a since-deleted LinkedIn post that Covid is linked to obesity. 
#Sweetgreen #Covid #health #science

Sources: 
https://www.independent.co.uk/life-style/sweetgreen-ceo-obesity-covid-b1913329.html
https://www.cnbc.com/2021/03/08/covid-cdc-study-finds-roughly-78percent-of-people-hospitalized-were-overweight-or-obese.html
https://www.cnbc.com/2021/09/01/sweetgreen-ceos-linkedin-post-tying-covid-deaths-to-obesity-draws-backlash.html
https://www.rt.com/op-ed/533240-bad-habits-lockdowns-covid/

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

