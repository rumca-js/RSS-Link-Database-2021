# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## COVID Restrictions RUIN Couple’s Night Out
 - [https://www.youtube.com/watch?v=MrgmaufTSx4](https://www.youtube.com/watch?v=MrgmaufTSx4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-09-14 00:00:00+00:00

Despite COVID, this couple just wants to have a night out at a restaurant. But with COVID restrictions changing by the second… is it even worth it?

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Jonathan Pageau Interview | Monsters, Hidden Symbols, and Jordan Peterson in Church
 - [https://www.youtube.com/watch?v=q5RsWX2g34I](https://www.youtube.com/watch?v=q5RsWX2g34I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-09-14 00:00:00+00:00

On The Babylon Bee Interview Show, Kyle and Ethan talk to Jonathan Pageau about making Christian carvings, monsters, and the breakdown of identity in our culture. Jonathan carves Eastern Orthodox images and other traditional images. He has been appearing on many podcasts, including one on Jordan Peterson’s podcast. Jonathan has a knack for discovering the hidden meaning behind things. Kyle and Ethan delve in deep on why we need symbolism and how the Bee is making the world turn right side up again. 

Check out BetterHelp.com/BabylonBee for 10% off

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

