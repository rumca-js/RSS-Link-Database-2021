# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## 8K TVs ARE THE FUTURE (Maybe)
 - [https://www.youtube.com/watch?v=sCbrlZ7JkpQ](https://www.youtube.com/watch?v=sCbrlZ7JkpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-09-13 00:00:00+00:00

8K is wacky. Wacky is sloppy. Slappy is fun. 8K is fun.

Let’s talk about TV, here on the TV channel!

Subscribe to my other channel it’s better than this:
https://www.youtube.com/c/Whimsu


Twitter: https://twitter.com/WhimsuHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub


Chart used:
https://www.rtings.com/tv/reviews/by-size/size-to-distance-relationship



Additional Footage Credits:
Unbox Therapy
Streaming Media
Reviewed
Linus Tech Tips
Tekzilla

