# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## MASSIVE Oculus Quest Pro LEAKS
 - [https://www.youtube.com/watch?v=hclpqgPdJ3g](https://www.youtube.com/watch?v=hclpqgPdJ3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-09-14 00:00:00+00:00

Hello and welcome to TUESDAY NEWSAY! Your number one resource for the entire weeks worth of VR news. Today we actually have a really exciting bit of news, some huge leaks on the Quest pro found through firmware by a reddit user, Lynx R1 updates and prices, Slime VR has funding for full body tracking, and a very weird "Half Dive" VR headset has emerged. Hope you enjoy todays episode!

My links:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Outro: Protostar Overdrive
https://open.spotify.com/track/3QifigzYiNKYk39TuwhPhJ?si=bee82cb55cf74414


Sources:
https://docs.google.com/document/d/17P0oMy6cueZNK_JA18emmRdp1E839noJ1cegbzAON00/edit
https://www.crowdsupply.com/slimevr/slimevr-full-body-tracker
https://lynx-r.com/lynxr1-specsheet.pdf
https://old.reddit.com/r/virtualreality/comments/pnfbxs/mega_leak_gforce_now_there_is_a_huge_list_of/
https://www.reddit.com/r/OculusQuest/comments/pmxx7z/v32_firmware_dive_oculus_quest_pro_references/
https://re-how.net/all/1376788/
https://www.vrfocus.com/2021/09/oculus-quest-space-sense-feature-discovered-provides-play-area-incursion-alert/
https://uploadvr.com/quest-pro-face-eye-tracking-oculus-firmware/
https://twitter.com/Basti564

