## How to back up your data and keep it safe - BBC News
 - [https://www.bbc.co.uk/news/business-58050387](https://www.bbc.co.uk/news/business-58050387)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-09-13 16:16:58.191474+00:00

Experts recommend using three drives to back up your data and using cloud-based services.

