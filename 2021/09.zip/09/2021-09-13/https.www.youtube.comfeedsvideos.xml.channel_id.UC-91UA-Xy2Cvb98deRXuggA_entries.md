# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## COMPANY STALKING EMPLOYEE TO AVOID PAYING | #corporatebullies
 - [https://www.youtube.com/watch?v=bTJ_HT1XtjM](https://www.youtube.com/watch?v=bTJ_HT1XtjM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2021-09-14 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

## CEO GETS GHOSTED, NOW WANTS JOB SEEKERS TO PAY TO APPLY?! | #grindreel
 - [https://www.youtube.com/watch?v=PmSH3HdJgDs](https://www.youtube.com/watch?v=PmSH3HdJgDs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2021-09-13 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

