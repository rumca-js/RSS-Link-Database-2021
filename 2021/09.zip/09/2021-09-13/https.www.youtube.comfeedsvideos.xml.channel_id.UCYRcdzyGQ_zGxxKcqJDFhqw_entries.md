## The Dead Internet Theory (Part 1)
 - [https://www.youtube.com/watch?v=DEn758DVF9I](https://www.youtube.com/watch?v=DEn758DVF9I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCYRcdzyGQ_zGxxKcqJDFhqw
 - date published: 2021-09-13 18:10:02+00:00

The Dead Internet Theory (Part 1)

