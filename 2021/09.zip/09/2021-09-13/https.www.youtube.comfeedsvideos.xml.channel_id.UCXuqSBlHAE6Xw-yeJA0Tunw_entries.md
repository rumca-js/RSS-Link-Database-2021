# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Do NOT Buy This For Gaming! - LG 32EP950
 - [https://www.youtube.com/watch?v=kYUbq2e6EYM](https://www.youtube.com/watch?v=kYUbq2e6EYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-09-13 00:00:00+00:00

Thanks to Adobe Photoshop Lightroom for sponsoring a portion of the video. Click the link below to learn more: https://adobe.ly/3hdxwBt

Adobe's Video & Motion YouTube channel: https://lmg.gg/FBcsn
#MadeWithLightroom

LG sent us one of their new mastering monitors currently being used by a few Disney studios. At 60Hz it might not be great for gaming, but can the LG 32EP950 provide an amazingly color-accurate experience?

Buy LG UltraFine 32” OLED UHD Monitor
On Best Buy (PAID LINK): https://geni.us/tnON1k
On B&H (PAID LINK): https://geni.us/ZYJSXji

Buy Acer Predator XB271HK
On Amazon (PAID LINK): https://geni.us/jOPAS

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1372937-do-not-buy-this-for-gaming/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:45 sRGB
2:35 32EP950 Features
3:20 Gaming On It
4:25 Side By Side Comparison
7:55 What Is It For
10:05 Downsides
11:12 ColorChecker
14:35 Outro

