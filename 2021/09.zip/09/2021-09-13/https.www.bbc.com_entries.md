## The outdated machine hampering the fight against Covid-19 - BBC Future
 - [https://www.bbc.com/future/article/20210903-how-covid-19-could-finally-be-the-end-of-the-fax-machine](https://www.bbc.com/future/article/20210903-how-covid-19-could-finally-be-the-end-of-the-fax-machine)
 - RSS feed: https://www.bbc.com
 - date published: 2021-09-13 14:35:00.915010+00:00

Major backlogs in processing patient data during the pandemic are forcing the healthcare sector to reassess its relationship with fax machines.

