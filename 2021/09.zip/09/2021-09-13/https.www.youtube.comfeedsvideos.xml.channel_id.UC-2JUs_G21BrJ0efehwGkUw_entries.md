# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Sunset Strip - J.E. Sunde (funk cover ft. J.E. Sunde + Theo Katzman)
 - [https://www.youtube.com/watch?v=2Fbp1ZnOX3M](https://www.youtube.com/watch?v=2Fbp1ZnOX3M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-09-13 00:00:00+00:00

Head over to the STORIES channel for an acoustic version of this song: https://youtu.be/rK6E0TCeuWg

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of J.E. Sunde's "Sunset Strip" by Scary Pockets & J.E. Sunde.

MUSICIAN CREDITS
Lead vocal / Acoustic Guitar: J.E. Sunde
Drums: Darren King
Bass: Joe Ayoub
Background Vocals: Theo Katzman + Ryan Lerman
Wurlitzer: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP / Camera Operator: Alejandro Echevarria
Editor: Adam Kritzberg
PA: Rachel McGowan
Tech: Will Easley

Recorded Live at Sunset Sound in Los Angeles, CA.

#ScaryPockets #Funk #JESunde #SunsetStrip

