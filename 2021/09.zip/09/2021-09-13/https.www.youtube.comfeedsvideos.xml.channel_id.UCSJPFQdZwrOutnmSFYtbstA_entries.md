# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Matrix Resurrections - Cool Trailer, But Why Now?
 - [https://www.youtube.com/watch?v=xnyEaDyhMBs](https://www.youtube.com/watch?v=xnyEaDyhMBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-09-13 00:00:00+00:00

So we're getting a fourth Matrix movie, apparently. Nearly 20 years after the original trilogy ended. Grab your red pills and join me as I break down the trailer, and my thoughts on the upcoming movie.

