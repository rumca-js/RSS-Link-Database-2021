## The World's Oldest Active Torrent Turns 18 Soon * TorrentFreak
 - [https://torrentfreak.com/the-worlds-oldest-active-torrent-turns-18-210912/](https://torrentfreak.com/the-worlds-oldest-active-torrent-turns-18-210912/)
 - RSS feed: https://torrentfreak.com
 - date published: 2021-09-13 16:12:06.646092+00:00

The world's oldest active torrent file turns 18 years old this month and is still being seeded by dozens of people.

