## Chris Corbett on Twitter: "Hey @StarbucksUK and @TrustArc if you get rid of the unnecessary timeouts there won't be any need for this processing "status". This only happens when you customise your privacy settings, can you explain that? Funny how some dark patterns are just accepted. https://t.co/qA231RjSeb" / Twitter
 - [https://twitter.com/pixelscript/status/1436664488913215490](https://twitter.com/pixelscript/status/1436664488913215490)
 - RSS feed: https://twitter.com
 - date published: 2021-09-13 13:21:14.633058+00:00

Hey @StarbucksUK and @TrustArc if you get rid of the unnecessary timeouts there won't be any need for this processing "status".  This only happens when you customise your privacy settings, can you explain that?  Funny how some dark patterns are just accepted. https://t.co/qA231RjSeb

