# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Interphace - To The Beach (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=ErtSvqp4Ock](https://www.youtube.com/watch?v=ErtSvqp4Ock)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-12-11 00:00:00+00:00

"To The Beach" Protracker arrangement by Interphace/Andromeda (Jan Reinert Karlsen), original by entropyloop. Art by Archmage/Andromeda. Both music and art from "Rule 30" Amiga OCS demo, winner of Gubbdata 2021 demo compo.

Watch the demo here: https://www.youtube.com/watch?v=GiK_RDQoayQ

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

