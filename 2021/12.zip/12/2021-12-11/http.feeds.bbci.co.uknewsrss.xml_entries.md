# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Aerials show aftermath of deadly Kentucky tornadoes
 - [https://www.bbc.co.uk/news/world-us-canada-59623946?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59623946?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 22:55:15+00:00

More than 70 people died in Kentucky in Friday night's storms, including dozens in a candle factory.

## 'Difficult to see' - De Gea speaks of fears over Lindelof as Man Utd beat Norwich
 - [https://www.bbc.co.uk/sport/football/59625324?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59625324?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 22:44:25+00:00

David de Gea speaks of his fears after Manchester United team-mate Victor Lindelof leaves the pitch with breathing difficulties during Saturday's win over Norwich.

## Kensington: Man dies after being shot in police confrontation
 - [https://www.bbc.co.uk/news/uk-england-london-59622531?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59622531?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 19:33:48+00:00

Officers were responding to reports of a man with a firearm at a bank and bookmakers, police say.

## 'Liverpool fans pay homage but Gerrard uninterested in sentimental return'
 - [https://www.bbc.co.uk/sport/football/59624620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59624620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 19:07:41+00:00

Phil McNulty observes Steven Gerrard on his return to Anfield and sees a man focused on his role at Aston Villa.

## Raheem Sterling: Man City star's best goals & stats as he reaches 100 Premier League goals
 - [https://www.bbc.co.uk/sport/av/football/59623925?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/59623925?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 17:16:24+00:00

As Raheem Sterling reaches 100 Premier League goals, BBC Sport looks back at some of his best goals and the key stats showing how the Manchester City forward reached the landmark.

## Kentucky weatherman films tornado 'ground zero'
 - [https://www.bbc.co.uk/news/59623945?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59623945?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 17:15:28+00:00

Meteorologist Noah Bergren shows the BBC the "utter devastation" of the tornadoes in the town of Mayfield.

## Covid: Care home visitors cut to three to slow Omicron spread
 - [https://www.bbc.co.uk/news/uk-59619889?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59619889?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 12:22:32+00:00

Residents will be allowed three visitors and one care worker from Wednesday under updated guidance.

## Queues form as Banksy Colston statue trial T-shirts go on sale
 - [https://www.bbc.co.uk/news/uk-england-bristol-59620631?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-59620631?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 12:20:41+00:00

The shirts were released to mark the trial of four people accused of toppling the Edward Colston statue.

## Covid: Omicron study suggests major wave in January
 - [https://www.bbc.co.uk/news/uk-59621029?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59621029?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 12:11:19+00:00

More stringent restrictions may be needed to prevent coronavirus from overwhelming hospitals, scientists say.

## 'England destined to lose first Ashes Test following team selection' - Agnew analysis
 - [https://www.bbc.co.uk/sport/cricket/59619301?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59619301?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 12:07:24+00:00

England were destined to lose the first Ashes Test because of the wrong team selection and a lack of match practice, says Jonathan Agnew.

## Postponed Tottenham-Rennes will not be rescheduled
 - [https://www.bbc.co.uk/sport/football/59620193?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59620193?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 11:36:53+00:00

Tottenham's postponed Europa Conference League game with Rennes - due to be played on 9 December - will not be rescheduled, says Uefa.

## More than 50 feared dead in Kentucky's worst ever tornadoes
 - [https://www.bbc.co.uk/news/world-us-canada-59620091?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59620091?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 11:27:48+00:00

The governor of the US state says that the number of victims could rise to 100.

## Arthur Labinjo-Hughes: Football club's tribute to young fan
 - [https://www.bbc.co.uk/news/uk-england-birmingham-59613311?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-59613311?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 11:13:42+00:00

Birmingham City has renamed the stadium's family zone in memory of the murdered six-year-old.

## Ex-England cricket captain backs calls for assisted dying
 - [https://www.bbc.co.uk/news/uk-england-leeds-59614627?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-59614627?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 07:58:34+00:00

Ray Illingworth says he wants people to have a choice after watching his wife die from breast cancer.

## The papers: Booster can stop Omicron and PM flat row 'deepens'
 - [https://www.bbc.co.uk/news/blogs-the-papers-59617378?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59617378?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 06:06:17+00:00

Saturday's papers cover the efficiency of booster jabs against Omicron and rows over PM's flat refurbishment.

## The Ashes: England slump to defeat against Australia on day four at the Gabba
 - [https://www.bbc.co.uk/sport/av/cricket/59617744?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/59617744?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 04:25:34+00:00

Watch highlights as England lose their last eight wickets for 74 runs as they slump to a crushing nine-wicket defeat against Australia in the first Ashes Test at the Gabba.

## Women's safety: Why I shared pictures of my assault online
 - [https://www.bbc.co.uk/news/newsbeat-59466693?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-59466693?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 01:46:59+00:00

Student Reegan Kay posted on Twitter about being assaulted on her way home from a night out.

## The Ashes: Ben Stokes caught at gully off Pat Cummins
 - [https://www.bbc.co.uk/sport/av/cricket/59603647?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/59603647?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 01:40:01+00:00

Australia's captain Pat Cummins has Ben Stokes caught in the gully as England lose their fourth wicket of the morning session on the fourth day of the first Ashes Test at the Gabba in Brisbane.

## Russia faces consequences if Ukraine invaded - Truss
 - [https://www.bbc.co.uk/news/uk-59616743?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59616743?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 01:30:03+00:00

The foreign secretary says G7 ministers will warn Moscow such action would be a "strategic mistake".

## The woman who digs for the truth in mass graves
 - [https://www.bbc.co.uk/news/stories-59587051?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-59587051?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 01:00:46+00:00

Mercedes Doretti has dedicated her life to searching for victims of war and state violence, as part of the Argentine Forensic Anthropology Team.

## Week in pictures: 4-10 December 2021
 - [https://www.bbc.co.uk/news/in-pictures-59607504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-59607504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 00:53:09+00:00

A selection of powerful images from all over the globe, taken this week.

## Ghislaine Maxwell trial: Prosecutors rest case after 10 days
 - [https://www.bbc.co.uk/news/world-us-canada-59616024?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59616024?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 00:42:23+00:00

Prosecutors say Ms Maxwell ran "a pyramid scheme of abuse" with convicted sex offender Jeffrey Epstein.

## Finnish teacher who secretly taught IS children in Syrian camps by text
 - [https://www.bbc.co.uk/news/world-europe-59577375?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59577375?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 00:24:07+00:00

Using WhatsApp, Ilona Taimela found a novel way to educate Finnish children held in a Syrian camp.

## The Ashes: Joe Root falls early on day four
 - [https://www.bbc.co.uk/sport/av/cricket/59603645?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/59603645?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 00:21:16+00:00

England captain Joe Root is caught behind off the bowling of Cameron Green on the fourth day of the first Ashes Test at the Gabba in Brisbane.

## Rosie Kay: Dancers write open letter to choreographer after gender row
 - [https://www.bbc.co.uk/news/entertainment-arts-59584638?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59584638?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 00:16:55+00:00

Choreographer Rosie Kay says she was forced out of her company over her views on sex and gender.

## Watch: Ros Atkins on… Compulsory Covid vaccinations
 - [https://www.bbc.co.uk/news/health-59609452?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-59609452?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 00:02:03+00:00

Ros Atkins examines the ethical arguments surrounding vaccine mandates.

## Houses of Parliament: The search for people to save palace buildings
 - [https://www.bbc.co.uk/news/uk-england-london-59602142?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59602142?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-11 00:01:54+00:00

The Palace of Westminster requires urgent repair, but a skills shortage means fresh talent is needed.

