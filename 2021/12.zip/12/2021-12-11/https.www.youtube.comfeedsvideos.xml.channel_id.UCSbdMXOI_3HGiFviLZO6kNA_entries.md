# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The BEST VR Full Body Tracker - TUNDRA TRACKER Review
 - [https://www.youtube.com/watch?v=bohzJkvHHqc](https://www.youtube.com/watch?v=bohzJkvHHqc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-12-11 00:00:00+00:00

Hello! Today I have a video on my favorite full body tracking solution that I have been waiting more than a year for. TUNDRA TRACKERS! Here in this video I show off the tracking quality, the pros and cons of Tundra Trackers and also dabble a little bit with concepts of full body tracking in general!

Tundras have become my go to tracker for VRChat and Neos and I have grown to use them just about every day sometimes from full charge to dead. Hopefully you enjoy this video! By the way if you do want to buy Tundras they will become available again to purchase likely in February.

Here is more information on them:
https://www.kickstarter.com/projects/tundralabs/tundra-tracker

My links:
Twitch.tv/Thrilluwu
Discord.gg/Thrill
Twitter.com/Thrilluwu
Patreon.com/Thrillseeker

TIMESTAMPS:
00:00 INTRO
00:52 What are Tundra Trackers?
01:47 Type of Full Body Tracking in VR
02:17 Weight and Size
03:15 Battery Life
04:15 Tracking Quality/ Occlusion
05:58 MY FAVORITE PART OF TUNDRA TRACKER
07:12 How to get the BEST tracking possible
9:15 Longevity 
10:20 The biggest problem with Tundra Trackers
11:09 Twitch stream with Tundras 
11:37 Pretty Outro

