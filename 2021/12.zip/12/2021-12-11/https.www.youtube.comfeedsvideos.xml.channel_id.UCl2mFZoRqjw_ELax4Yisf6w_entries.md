# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Let's get healthier together
 - [https://www.youtube.com/watch?v=Kb3xQQDg4OY](https://www.youtube.com/watch?v=Kb3xQQDg4OY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-12 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://youtu.be/MMkZ7ZV5IXA?list=PLxZtlCeYcL19VX0RoUykWKmhMHYry2ioG

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## Toyota thinks THEY own your car.
 - [https://www.youtube.com/watch?v=3MXgnecxVeU](https://www.youtube.com/watch?v=3MXgnecxVeU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-12 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.thedrive.com/news/43329/toyota-made-its-key-fob-remote-start-into-a-subscription-service

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## The man, the legend, the idol.
 - [https://www.youtube.com/watch?v=057I2v6D-1k](https://www.youtube.com/watch?v=057I2v6D-1k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.youtube.com/channel/UChIs72whgZI9w6d6FhwGGHA

## unhinged raging rant on schooling in NYC
 - [https://www.youtube.com/watch?v=FpIiLek97ds](https://www.youtube.com/watch?v=FpIiLek97ds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.nbcnewyork.com/news/local/new-nyc-schools-chancellor-wants-longer-school-days-saturday-and-summer-classes/3445341/

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

