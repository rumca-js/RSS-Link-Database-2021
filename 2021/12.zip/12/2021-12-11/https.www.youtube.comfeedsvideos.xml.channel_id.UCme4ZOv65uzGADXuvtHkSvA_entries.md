# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Atlas
 - [https://www.youtube.com/watch?v=L3hyY2V_nkE](https://www.youtube.com/watch?v=L3hyY2V_nkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-12 00:00:00+00:00

Cztery niedziele Adwentu i cztery piosenki na A. 
Zapraszamy w krainę SŁOWA, MUZYKI i OBRAZU. 

@Langustanapalmie @AgnieszkaMusiaYT 

tekst: Agnieszka Musiał
muzyka: Agnieszka Musiał II Jan Smoczyński 
zespół w składzie: Agnieszka Musiał || Jan Smoczyński || Kamil Siciak
produkcja serii, scenografia: Sylwia Smoczyńska 
realizacja i produkcja muzyki: Jan Smoczyński 
zdjęcia: Marcin Jończyk 
montaż: Marcin Kopiec 
realizacja światła: Bartek Borcz 
pomoc techniczna: Michał Blicharski 
make up: Zuza Górska 
Zdjęcia zrealizowano w Agroturystyce Modry Ganek


"Atlas"

zwr.1
Otwieram atlas nie widzę miejsca 
gdzie mogłabym uciec stąd
Odkąd nadszedł zimny front 
Spokój się rozpłynął 
Jest coraz dalej 
Chcę wyrazić myśli 
Zapominam słowa
Zdania się nie kleją 
Trudne doświadczenia 
Zgubiona nadzieja 

ref. 
Kto mi sklei serce?
Opatrzy rany, nauczy kochać 
Miłością zmieni, moją rzeczywistość
I w atlas wpisze moje imię 
Które da jednej z gwiazd 
I nie będę się bać 
Kto mi sklei serce
Opatrzy rany, nauczy kochać? 

zwr. 2
Czy jestem potrzebna 
Szukam ukojenia, czy spokój 
Jeszcze wróci? 
Wołam już ostatkiem sił 
Nadzieja gdzieś się z tyłu tli 

bridge

Porwałeś mnie w powietrze
Skleiłeś serce, zmiany front odszedł 
Nie muszę się bać 
Bez cła i odprawy 
Zimny front odszedł oby na zawsze 
Z Tobą nie muszę się bać 

ref.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Biblia od kuchni [#05] Kawa z lodami i młodymi orzechami
 - [https://www.youtube.com/watch?v=wfdwS75LVYA](https://www.youtube.com/watch?v=wfdwS75LVYA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-12 00:00:00+00:00

​ @Langustanapalmie 

Książkę "Biblia od kuchni" znajdziecie tu:
→ https://www.rtck.pl/sklep/ksiazki/biblia-od-kuchni/
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Sędziów || Rozdział 18
 - [https://www.youtube.com/watch?v=y26oHDJR1VY](https://www.youtube.com/watch?v=y26oHDJR1VY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-12 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno stronniczy [#48] Zbędni i przyszywani
 - [https://www.youtube.com/watch?v=CC4FZ02u0eQ](https://www.youtube.com/watch?v=CC4FZ02u0eQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-12 00:00:00+00:00

Mocno stronniczy powracają :)
Zapraszamy w niedzielę o godz: 10:oo 


zdjęcia, dźwięk, montaż: Marcin Jończyk
grafika, produkcja serii: Sylwia Smoczyńska


@Langustanapalmie @STREFAWODZA 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#264] I z czego się cieszyć?
 - [https://www.youtube.com/watch?v=aYdUvk-uHsQ](https://www.youtube.com/watch?v=aYdUvk-uHsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-11 00:00:00+00:00

#cnn #dobrewiadomości

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

III Niedziela Adwentu, Rok C

1. czytanie (So 3, 14-17)

Wyśpiewuj, Córo Syjońska! Podnieś radosny okrzyk, Izraelu! Ciesz się i wesel z całego serca, Córo Jeruzalem! Oddalił Pan wyroki na ciebie, usunął twego nieprzyjaciela; Król Izraela, Pan, jest pośród ciebie, nie będziesz już bała się złego.
Owego dnia powiedzą Jerozolimie: «Nie bój się, Syjonie! Niech nie słabną twe ręce!» Pan, twój Bóg, jest pośród ciebie, Mocarz, który zbawia, uniesie się weselem nad tobą, odnowi cię swoją miłością, wzniesie okrzyk radości.

2. czytanie (Flp 4, 4-7)

Radujcie się zawsze w Panu; jeszcze raz powtarzam: radujcie się! Niech będzie znana wszystkim ludziom wasza wyrozumiała łagodność: Pan jest blisko!
O nic się już nie martwcie, ale w każdej sprawie wasze prośby przedstawiajcie Bogu w modlitwie i błaganiu z dziękczynieniem. a pokój Boży, który przewyższa wszelki umysł, będzie strzegł waszych serc i myśli w Chrystusie Jezusie.

Ewangelia (Łk 3, 10-18)

Gdy Jan nauczał nad Jordanem, pytały go tłumy: «Cóż mamy czynić?» On im odpowiadał: «Kto ma dwie suknie, niech się podzieli z tym, który nie ma; a kto ma żywność, niech tak samo czyni».
Przyszli także celnicy, żeby przyjąć chrzest, i rzekli do niego: «Nauczycielu, co mamy czynić?» On im powiedział: «Nie pobierajcie nic więcej ponad to, co wam wyznaczono».
Pytali go też i żołnierze: «a my co mamy czynić?» On im odpowiedział: «Na nikim pieniędzy nie wymuszajcie i nikogo nie uciskajcie, lecz poprzestawajcie na waszym żołdzie».
Gdy więc lud oczekiwał z napięciem i wszyscy snuli domysły w swych sercach co do Jana, czy nie jest Mesjaszem, on tak przemówił do wszystkich: «Ja was chrzczę wodą; lecz idzie mocniejszy ode mnie, któremu nie jestem godzien rozwiązać rzemyka u sandałów. On będzie was chrzcił Duchem Świętym i ogniem. Ma on wiejadło w ręku dla oczyszczenia swego omłotu: pszenicę zbierze do spichlerza, a plewy spali w ogniu nieugaszonym».
Wiele też innych napomnień dawał ludowi i głosił dobrą nowinę.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Sędziów || Rozdział 17
 - [https://www.youtube.com/watch?v=pZCsqiFKQ3Y](https://www.youtube.com/watch?v=pZCsqiFKQ3Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-11 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Targ intencji || Grudzień 2021
 - [https://www.youtube.com/watch?v=W3a0_U_dJRI](https://www.youtube.com/watch?v=W3a0_U_dJRI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-11 00:00:00+00:00

#targintencji

Targ intencji na Grudzień 2021

@Langustanapalmie 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wyszynki [#965] Monolog
 - [https://www.youtube.com/watch?v=ARTyvfhgttQ](https://www.youtube.com/watch?v=ARTyvfhgttQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-11 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Zapraszamy Was do włączenia się w Adwentową Akcję Charytatywną:
→ https://charytatywnie.fundacjamalak.pl/  
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka cegiełka (w wersji papierowej) wyruszy do Was w drogę już 12 listopada.
Ebook - dostępny już dziś.

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

