# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Mistrzostwa Świata w Excelu!
 - [https://www.youtube.com/watch?v=PfCZx95JjIE](https://www.youtube.com/watch?v=PfCZx95JjIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-12-12 00:00:00+00:00

Czyli wreszcie esport dla twardzieli. Link do prezentoułatwiaczy Douglasa: https://bit.ly/3IHhCv6

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Wstęp
00:19 Małpa z chipem Elona
00:50 Finał w Excela
02:01 FAIRPHONE
04:49 Ściema z „Do not track”
06:20 DRIVE PILOT Mercedesa
07:03 Poradnik zakupowy
07:27 Reklama Douglasa
07:52 Przyszłość klaksonów
08:21 Przyszłość sztucznej inteligencji
09:42 Składak od Oppo
09:57 Słuchawki Nothing
10:30 Targi CES
10:46 Pożegnanko

Źródła:
Czipy w ludzkich mózgach w 2022: https://bit.ly/3ymod9n
Mistrzostwa Świata w Excelu: https://bit.ly/3lXR52Y
Fairphone: https://bit.ly/3DMzpxq
Aplikacje w iPhone'ach jednak śledzą: https://bit.ly/3lY8l8f
Autonomiczny Mercedes: https://bit.ly/3F10Ep6
Samochody przyszłości bez klaksonów: https://bit.ly/3m13ovl
Sztuczna inteligencja o sobie samej: https://bit.ly/3lZ7Xq6
Nowy składany Oppo: https://bit.ly/3dLRYqY
Czarne słuchawki Nothing: https://bit.ly/3GCjvHx

