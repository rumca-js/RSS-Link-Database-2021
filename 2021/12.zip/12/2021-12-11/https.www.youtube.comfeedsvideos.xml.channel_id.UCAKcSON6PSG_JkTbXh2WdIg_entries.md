# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Interview: JD McPherson talks about 'Socks' and playing with Robert Plant and Alison Krauss
 - [https://www.youtube.com/watch?v=FQ1bZq6INAY](https://www.youtube.com/watch?v=FQ1bZq6INAY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-12 00:00:00+00:00

JD McPherson talks to The Current's Bill DeVille about the upcoming "Socks" tour — and JD reveals that next year, he'll be playing in the band with Robert Plant & Alison Krauss on next year's "Raise the Roof" tour! 

Watch the complete interview above.

CREDITS:
Host - Bill DeVille
Guest - JD McPherson
Producers - Jesse Wiza, Luke Taylor
Technical Director - Eric Romani

FIND MORE:
2012 July studio session: https://www.thecurrent.org/feature/2012/07/06/jd-mcpherson-performs-in-the-current-studios
2012 November studio session:
https://www.thecurrent.org/feature/2012/11/29/jd-mcpherson-live
2014 studio session: https://www.thecurrent.org/feature/2014/09/14/jd-mcpherson-performs-in-the-current-studio
2015 studio session:
https://www.thecurrent.org/feature/2015/02/14/jd-mcpherson-performs-in-the-current-studio
2015 Rock the Garden set:
https://www.thecurrent.org/feature/2015/07/01/jd-mcpherson-live-at-rock-the-garden-2015
2018 studio session:
https://www.thecurrent.org/feature/2018/12/04/jd-mcpherson-and-band-pull-up-their-socks-in-the-current-studio
2021 interview with Bill DeVille:
https://www.thecurrent.org/feature/2021/12/12/jd-mcpherson-talks-joining-robert-plant-and-alison-krauss-band-and-rebuilding-his-own-lineup

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#jdmcpherson

