## How Cloudflare security responded to log4j2 vulnerability
 - [https://blog.cloudflare.com/how-cloudflare-security-responded-to-log4j2-vulnerability/](https://blog.cloudflare.com/how-cloudflare-security-responded-to-log4j2-vulnerability/)
 - RSS feed: https://blog.cloudflare.com
 - date published: 2021-12-11 15:17:39.281904+00:00

Yesterday, December 9, 2021, when a serious vulnerability in the popular Java-based logging package log4j was publicly disclosed, our security teams jumped into action to help respond to the first question and answer the second question. This post explores the second.

