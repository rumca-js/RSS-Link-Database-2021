# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Huawei P30 Pro Restoration - Fixing A Technicians Mistakes
 - [https://www.youtube.com/watch?v=zg_zryYcl-Q](https://www.youtube.com/watch?v=zg_zryYcl-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-12-11 00:00:00+00:00

--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Check out iFixit's holiday deals on parts and tools kits:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau

Tools I Use: https://www.hughjeffreys.com/tools
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

