# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The History of the Haradrim | Tolkien Explained
 - [https://www.youtube.com/watch?v=90LjRagJXs4](https://www.youtube.com/watch?v=90LjRagJXs4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-12-11 00:00:00+00:00

A great southern kingdom, tamers of the mighty Mûmakil, and a land caught between the opposing forces of Númenor and Sauron.  The Haradrim were divided between those who served the dark lord and those who opposed him.  Likely aided by the Blue Wizards, they would not only be enslaved by Sauron, but also the Númenóreans as their kingdom turns to darkness.  In the Third Age, Gandalf would visit the southern realm, and many Haradrim would aid Sauron in the War of the Ring.

Be sure to visit Lord of Maps to see their holiday specials, and use the code NERDOFMAPS at LordofMaps.com to save 15% on your order!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html

Market of Umbar - DireImpulse
Alatar and Pallando - Ralph Damiani
Haradrim Spear - Lucas Durham
Haradrim King - Kyle Anderson
Morgoth and Fingolfin - Joel Kilpatrick
Bor with his sons - Helena Stepanova
Serpent guard - Dvaler01
Elven smithy - Christina Kraus
Umbar Market Speed Paint, Harad - DireImpulse
Harad - Visions of Palantir
Southron Camp - Davis Engel
Umbar - Bengamey
The Blue Wizards Journeying East - Ted Nasmith
Alatar and Pallando - Ralph Damiani
The Blue Wizards - Turner Mohan
Fields of Emerie Looking into Meneltarma Numenor - izzi3bootz
Harad - Tomasz Jedruszek
Numenorean Armor - Turner Mohan
Numenorean Warrior - Jef Murray
Umbar - Turner Mohan
Herumor - Jovan Delic
The Evil Runs Deep in Numenor - Oznerol
Numenor's Legion of Armenelos - Sam McKinnon
Celebrimbor and Annatar - WETA
Lord of Mordor - Snow Monster
Umbar - Angelique Shelley
Arrival of Ar-Pharazon in Umbar - Ivana Lekseich
Sauron - Spartank42
Southron Soldier - Alexandr Elichev
Ar-Pharazon - Steamey
Ar-Pharazon - Niwa Jongkind
Sauron bows, submits to Ar-Pharazon - Kip Rasmussen
Harad - Lida Holubova
Sauron and Ar-Pharazon - Janka Lateckova
Ar-Pharazon at Umbar - Niwa Jongkind
Sauron Descending - The Brothers Hildebrandt
The Ships of the Faithful - Ted Nasmith
Fall of Numenor - Fox in Shadow
Haradrim Archer - CK Goksoy
Sauron - Johnnyslowhand
The Last Alliance - Jenny Dolfen
Wild Lands and Strange Visions - Fantasy Flight Games
Sauron Defeated - Hamfast Bryce
Haradrim - Amelie Hutt
Adunakhori - Tom Romain
Ten Cats of Queen Beruthiel - Steamey
The Gate of Umbar - DireImpulse
Minas Tirith Speed Paint - DireImpulse
Gondorian - Lasahido
Hyarmendacil - Matej Cadil
Osgiliath - Abe Papakhian
Corsairs of Umbar - Fantasy Flight Games
Corsairs of Umbar - Gammagrey
Corsairs of Umbar - John Howe
Umbar vs Minas Tirith - Angus McBride
Charge of the Mumakil - The Sethalonian
The great city of Umbar, LOTR - DireImpulse
Haradrim Soldier - Jon Bosco
Haradrim Captain - Herckeim
The Witch King - Wugrash
Ringwraiths - Anato Finnstark
Archer vs Mumakil - Robert Laskey
Oliphaunts - Ted Nasmith
Mumak - Turner Mohan
Mumakil - Piyas Studio
Haradrim Ambush - Inge Edelfeldt
The Mumakil - Visions of the Palantir
Dark Lands Made Darker - Fantasy Flight Games
The Fallen Southron - Anke Eissmann
The Fallen Southron - Tolman Cotton
Mumakil - Rostridge
Harad - Mietlik
Mumakil - PeepsBurgh
Kahliel - David Auden Nash
Sandy - Metat0209
Haradrim - Amelie Hutt
Southrons - John Howe
Southron - John Howe
Theoden's Last Ride - Porll
The Black Serpent founders - Anke Eissmann
Rohirrim - CG Warrior
Theoden vs the Captain of the Haradrim - Kip Rasmussen
Haradrim Cavalryman - Turner Mohan
Southern Support - CBsorgeArtworks
Theoden's charge - Rozolo Tolkien
Eomer finds Eowyn - Paula DiSante
Eomer and the Mumakil - Pyrrhic Illustration
Mumakil - Gellihana
Big Army - Sebastien Grenier
Thus Came Aragorn - Ted Nasmith
Forth Eorlingas - Valya Vande
Southron - Victor Manuel Lezamoreno
Battle of the Black Gate - Ted Nasmith
At the Cracks of Doom - Ted Nasmith
The Shadow of Sauron - Ted Nasmith
And the orcs fled before his face - Jenny Dolfen
Mordor, Gorgoroth - Rod Mendez
Easterling Skirmisher - Martin de Diego
The Gates of Umbar - DireImpulse
Haradrim Soldier - Leonard Gubeev
Easterling swordsman - Taurus Chaoslord
Elessar Coronation - Tim Hildebrandt
Eomer and Aragorn Ride to the Lands of the East - Kip Rasmussen
Minas Tirith - Ludovic Bourgeois
Haradrim Swordsman - Jan Pospisil

#haradrim #tolkien #lordoftherings

