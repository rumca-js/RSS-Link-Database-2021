# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## "They're Manipulating You!!!" Pentagon Insider EXPOSES Media's Agenda
 - [https://www.youtube.com/watch?v=CSpOItDxVuI](https://www.youtube.com/watch?v=CSpOItDxVuI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-12-14 00:00:00+00:00

What's causing the relentless division in society? I talk to Sarah Chayes, a former political advisor to the US Military and Pentagon. You can listen to the rest of my podcast with Sarah on Luminary here: luminary.link/russell
#Corruption #media #pentagon #military 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## 19 Years Clean & Sober!
 - [https://www.youtube.com/watch?v=5hfHNnhb7aU](https://www.youtube.com/watch?v=5hfHNnhb7aU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-12-13 00:00:00+00:00

Today I am 19 years clean and sober. Thank you to all the people ahead of me that showed me the way, beside me that hold my hand and behind me that remind me why we all walk this path. Stay Free!

If you need help with recovery, you can download my program here: https://www.russellbrand.com/wp-content/uploads/2020/03/russell-brand-recovery-the-program.pdf 

#recovery #12steps #sober #clean 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## “They’re Doing WHAT To The Weather?!!” Isn’t This SCIENCE FICTION?!
 - [https://www.youtube.com/watch?v=qRuaR_O2t-4](https://www.youtube.com/watch?v=qRuaR_O2t-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-12-13 00:00:00+00:00

Reports suggest that Chinese weather authorities have successfully managed to control the weather. Will this technology become a global tool for good, or are more politically nefarious uses on the horizon?  
#BillGates #China #WeatherManipulation

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

