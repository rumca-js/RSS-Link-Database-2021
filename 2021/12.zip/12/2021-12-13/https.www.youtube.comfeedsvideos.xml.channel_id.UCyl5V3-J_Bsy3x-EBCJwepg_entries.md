# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Alien DESTROYS Liberal Mob With Message Of Peace And Unity
 - [https://www.youtube.com/watch?v=t3n8McnmBGI](https://www.youtube.com/watch?v=t3n8McnmBGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-14 00:00:00+00:00

What does it take to achieve world peace? An alien knows the secret! Unfortunately, this liberal mob will do anything to stop him.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## How Democrats Cause Homelessness and Poop on the Street | A Bee Interview with Michael Shellenberger
 - [https://www.youtube.com/watch?v=d2abSFRKRZc](https://www.youtube.com/watch?v=d2abSFRKRZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-14 00:00:00+00:00

Micheal Shellenberger joins Ethan and Adam to talk about how Democrats are destroying cities with terrible policies, better ways for clean energy, and why there is so much poop on San Francisco's streets. Michael recently wrote the book SanFran-Sicko, where he details how Progressives are ruining major cities. He has written other books, including Apocalypse Never, where he details policies that can realistically give cleaner energy without all the wokeness attached.

This episode is brought to you by Issues, Etc. radio talk show and podcast which features expert guests, expansive topics, while extolling Christ. Go to http://issuesetc.org/babylonbee to see their special interview with Kyle Mann and Joel Berry today!

This episode is also brought to you by Faithful Counseling. Go to http://betterhelp.com/babylonbee for 10% off!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## 8 Ways To Win The War On Christmas
 - [https://www.youtube.com/watch?v=SmVv_cv8Cpo](https://www.youtube.com/watch?v=SmVv_cv8Cpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-13 00:00:00+00:00

As the war on Christmas rages on, it is your DUTY to follow these eight simple steps to land a blow for the spirit of Christmas.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

