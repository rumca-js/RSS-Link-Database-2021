# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## HALO Trailer!😇 Toei Update!😞Hunger of the Gods Cover🎨 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=gB4uC5HjPzg](https://www.youtube.com/watch?v=gB4uC5HjPzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-12-14 00:00:00+00:00

Let's jump into the Fantasy News! 
To try a variety pack, go to → https://magicspoon.thld.co/GOBLIN_1221 and use code GOBLIN to get $5 off today! Thanks to Magic Spoon for sponsoring today’s video
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 intro

00:55 The Hunger of the Gods: https://www.orbitbooks.net/2021/12/13/cover-launch-the-hunger-of-the-gods-by-john-gwynne/?utm_source=facebook&utm_campaign=social&utm_medium=Orbit+Books+UK&utm_content=TheHungerOfTheGods%2CJohnGwynne

01:36 Best Books of 2021: https://tinyurl.com/6yxyk5an

01:56 Red Rising Covers: https://nerdy.ink/products/red-rising-dust-jackets  

03:51 Cowboy Bebop canceled: https://twitter.com/DiscussingFilm/status/1469083031768113155?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet 

04:36 Totally Not Mark: https://www.youtube.com/watch?v=kSFIGHdtd_g&ab_channel=TotallyNotMark  

06:54 Fantastic Beasts: https://www.youtube.com/watch?v=Y9dr2zw-TXQ&ab_channel=ScreenRant 
 
07:33 Ciri clip: https://www.youtube.com/watch?v=3aNJYapXeEU&ab_channel=TheWitcherNetflix 

08:16 Elden Ring: https://www.youtube.com/watch?v=T6EcJ6Sv5Ns&ab_channel=GameSpot 

08:29 The Expanse Telltale: https://www.youtube.com/watch?v=c27FGhsT7kI&ab_channel=IGN 

09:05 Hunger ofHalo Teaser: https://www.youtube.com/watch?v=wONazm_2C3I&ab_channel=IGNMovieTrailers

