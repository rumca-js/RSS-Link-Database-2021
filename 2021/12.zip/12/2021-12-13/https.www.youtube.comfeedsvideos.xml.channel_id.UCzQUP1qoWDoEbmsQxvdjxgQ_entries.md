# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Beeple Gifts Joe an Elon Musk NFT
 - [https://www.youtube.com/watch?v=dZ0bYteaI2Q](https://www.youtube.com/watch?v=dZ0bYteaI2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-14 00:00:00+00:00

Taken from JRE #1748 w/Beeple:
https://open.spotify.com/episode/1v884aTc6iNDpUmtfUCuHd?si=97224b36db274d68

## Why Does Chris Pratt Get So Much Online Hate?
 - [https://www.youtube.com/watch?v=75C9grGZPxk](https://www.youtube.com/watch?v=75C9grGZPxk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-14 00:00:00+00:00

Taken from JRE #1748 w/Beeple:
https://open.spotify.com/episode/1v884aTc6iNDpUmtfUCuHd?si=97224b36db274d68

