# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Crypto is going to get regulated...
 - [https://www.youtube.com/watch?v=tWr1nGbKXd8](https://www.youtube.com/watch?v=tWr1nGbKXd8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-12-14 00:00:00+00:00

Crypto vs. Congress -- it's about time these boomers started regulating crypto. Whether you're pro or anti crypto, either way it's good that our lawmakers are setting the guidelines for how innovation can proceed. The wild west needs to calm down so that people can suffer fewer scams and enjoy more stable markets with crypto. 
Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryBagg96

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

## Keanu Reeves Doesn't Like NFTs
 - [https://www.youtube.com/watch?v=D92y0t04mNs](https://www.youtube.com/watch?v=D92y0t04mNs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-12-14 00:00:00+00:00

NFTs are not breaktaking
Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryBagg96

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

