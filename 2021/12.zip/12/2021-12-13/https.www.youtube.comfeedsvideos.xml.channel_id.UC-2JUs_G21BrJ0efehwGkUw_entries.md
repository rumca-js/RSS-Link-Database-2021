# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Blinded by the Light | Bruce Springsteen | funk cover ft. Swatkins & Therese Curatolo
 - [https://www.youtube.com/watch?v=QZMP_HrAwCg](https://www.youtube.com/watch?v=QZMP_HrAwCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-12-13 00:00:00+00:00

Get tickets to see us on tour!  https://www.scarypocketsfunk.com
March Tour presale for Patreon members begins Tuesday Dec 14 at 10am local time!! Not a patron yet? Join now: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Bruce Springsteen's "Blinded by the Light" by Scary Pockets, Swatkins & Therese Curatolo.

MUSICIAN CREDITS
Lead vocal: Swatkins & Therese Curatolo
Drums: Kyle Crane
Bass: Nick Campbell
Fender Rhodes: Misty Boyce
Organ: Swatkins
Guitar, Tambourine: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Chris Sorem
Mix: Caleb Parker
Master: Will Borza

VIDEO CREDITS
DP: Nate Cuboi 
Lighting: Michael Tomas
Editor: Adam Kritzberg

Recorded Live at The Nest in Los Angeles, CA.

#ScaryPockets #Funk #BruceSpringsteen #BlindedByTheLight #ThereseCuratolo #Swatkins

