# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Amos Lee - Into The Clearing (live performance for The Current)
 - [https://www.youtube.com/watch?v=9C9IsmJPflw](https://www.youtube.com/watch?v=9C9IsmJPflw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-14 00:00:00+00:00

Singer-songwriter Amos Lee performs "Into The Clearing" from his upcoming 2022 record "Dreamland" for The Current. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#AmosLee

## Amos Lee - Madison (live performance for The Current)
 - [https://www.youtube.com/watch?v=vl4wfuP4GT8](https://www.youtube.com/watch?v=vl4wfuP4GT8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-14 00:00:00+00:00

Singer-songwriter Amos Lee joins The Current to share a performance of "Madison," an unreleased track which will appear on a yet-to-be-announced album—Lee noted that he "got a good backlog of songs" written during the pandemic.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#AmosLee

## Amos Lee - Worry No More (live performance for The Current)
 - [https://www.youtube.com/watch?v=H_8ZeNCOcqQ](https://www.youtube.com/watch?v=H_8ZeNCOcqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-14 00:00:00+00:00

Singer-songwriter Amos Lee performs "Worry No More" from his upcoming 2022 record "Dreamland" for The Current. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#AmosLee

## Amos Lee plays songs from "Dreamland" & more (live performance for The Current)
 - [https://www.youtube.com/watch?v=MFD0BbRCjg4](https://www.youtube.com/watch?v=MFD0BbRCjg4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-14 00:00:00+00:00

Singer-songwriter Amos Lee joins The Current to play two new songs from his upcoming 2022 record "Dreamland," plus an unreleased track which will appear on a yet-to-be-announced album—Lee noted that he "got a good backlog of songs" written during the pandemic.

Songs Played:
00:01 Worry No More
03:11 Into The Clearing
06:51 Madison

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#AmosLee

