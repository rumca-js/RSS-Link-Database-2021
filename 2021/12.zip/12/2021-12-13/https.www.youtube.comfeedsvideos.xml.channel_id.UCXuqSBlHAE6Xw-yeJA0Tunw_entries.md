# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## We have some cultural differences - ROG Rig Reboot 2021
 - [https://www.youtube.com/watch?v=kUoXzdj201k](https://www.youtube.com/watch?v=kUoXzdj201k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-12-14 00:00:00+00:00

Thanks to ASUS ROG for sponsoring this video! Check out the PC list below and check out more great ASUS ROG products on BestBuy at: https://geni.us/U1tWW

He finally won after his 3rd attempt, but will he regret entering in the first place? We flew Jacob all the way from Hawaii to build a PC with Linus. Let's see if his laid-back attitude can withstand the master Tech Tip. 

Check out Jacob's winning entry at https://youtu.be/wmbF4YzEJFQ

Buy ASUS ROG Maximus Z690 Hero Motherboard
On Amazon: https://geni.us/aTLjk
On Best Buy: https://geni.us/srdPN

Buy Intel Core i9-12900K Desktop Processor
On Amazon: https://geni.us/xyfqgXm
On Best Buy: https://geni.us/Ca9UD

Buy ASUS ROG Strix NVIDIA GeForce RTX 3080 Graphics Card
On Lenovo (PAID LINK): https://howl.me/chSXRmE6ZVW
On Amazon: https://geni.us/NRNqUS
On Best Buy: https://geni.us/6f4An3o

Buy ASUS ROG STRIX 1000W Gold Power Supply
On Amazon: https://geni.us/YJJwaE
On Newegg: https://geni.us/PTk6

Buy ASUS ROG Strix LC 360 RGB All-In-One Liquid CPU Cooler
On Amazon: https://geni.us/HS7rFO6
On Newegg: https://geni.us/EkFaL

Buy ASUS ROG Swift 27" 1440P Gaming Monitor (PG279QM)
On Best Buy (PAID LINK): https://howl.me/chSXRm8Zz5R 
On Amazon:https://geni.us/e5MXJNh

Buy Fractal Design Meshify 2 Mid-Tower Case
On Amazon: https://geni.us/6eKB1q

Buy Crucial 64GB DDR5 4800 MHz UDIMM Memory Kit (2 x 32GB) On BHPhoto: https://geni.us/39J0O

Buy Crucial P5 Plus 1TB PCIe 4.0 3D NAND NVMe M.2 SSD
On Amazon: https://geni.us/Ym4RBQ
On Best Buy: https://geni.us/AJvRgA
On Newegg: https://geni.us/0qedsn

Buy Crucial - MX500 4TB SSD
On Best Buy: https://geni.us/A8BTo
On Newegg: https://geni.us/idBo

Buy ASUS ROG Spatha X Wireless Gaming Mouse
On Amazon: https://geni.us/BsDy
On Newegg: https://geni.us/jnZ9l5Z

Buy ASUS ROG Claymore II Wireless Modular Gaming Mechanical Keyboard
On Amazon: https://geni.us/JCHM8
On Newegg: https://geni.us/awhAb

Buy ASUS - ROG Delta RGB Wired Stereo Gaming Headset
On Amazon: https://geni.us/zwzA
On Best Buy: https://geni.us/kBaA
On Newegg: https://geni.us/PReKo

Buy ASUS ROG Sheath Gaming Mouse Pad (Black/Red)
On Best Buy (PAID LINK): https://howl.me/chSXRnvLFDd 
On Amazon: https://geni.us/NjhsxB


Buy Cablemod Cables On Amazon: https://geni.us/J0uxHBc

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1395945-we-have-some-cultural-differences-rog-rig-reboot-2021-sponsored/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 - Intro
1:23 - Part 1: The Motherboard - Processor - RAM - Storage
10:00 - Part 2: The Case - Motherboard install - PSU - Cables - AIO Cooler
18:25 - Part 3: Impromptu Unboxing Jacob Short Quickie Tips
19:13 - Part 4: The Cable Management - Storage - GPU
21:40 - Part 5: Will it boot?
22:29 - Part 6: GAMING and wardrobe change
24:07 - Conclusion!

## Your Old PC is Your New Server
 - [https://www.youtube.com/watch?v=zPmqbtKwtgw](https://www.youtube.com/watch?v=zPmqbtKwtgw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-12-13 00:00:00+00:00

Thanks to Pulseway for sponsoring this video! Try Pulseway for free to start monitoring and managing your server or PC, and get 20% off for a limited time at https://lmg.gg/Ktd7Z


Buy Seagate Ironwolf Pro 12TB on Amazon: https://geni.us/Wy83I

Buy Kingston 2.5" SSD: https://geni.us/yaklqN

Buy Windows 10: https://geni.us/NaKvY

Buy 5.25 to 3.5" Drive Adapter  on Amazon: https://geni.us/nFUMv

Get UnRAID: https://geni.us/lcfkgR

Winaero: https://winaero.com/winaero-tweaker/

Plex: https://www.plex.tv/en-ca/media-server-downloads/

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1395630-your-old-pc-is-your-new-server/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:51 Servers = Computers
2:33 Shocking reveal
3:30 Starting fresh
4:30 Software 
5:15 Network Share 
6:46 What's next?
8:17 DVD's are dead 
9:45 RAID: Shadow Copy
9:59 Storage Spaces

