# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Recommends... Arcane
 - [https://www.youtube.com/watch?v=W3h6Pszege4](https://www.youtube.com/watch?v=W3h6Pszege4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-12-14 00:00:00+00:00

Arcane on Netflix turned out to be one of the most pleasant surprises of the year. Join me as I review this excellent show. 

Want to help support this channel? Then consider buying a Critical Drinker plush: https://www.makeship.com/products/the-critical-drinker-plush

