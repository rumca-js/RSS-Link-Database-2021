# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## Why We Should NOT Look For Aliens - The Dark Forest
 - [https://www.youtube.com/watch?v=xAUJYP8tnRE](https://www.youtube.com/watch?v=xAUJYP8tnRE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2021-12-14 00:00:00+00:00

Getting something from the kurzgesagt shop is the best way to support us and to keep our videos free for everyone. Thank You!
►► https://kgs.link/shop-156 (Worldwide Shipping Available)

Sources & further reading:
https://sites.google.com/view/sources-darkforest/

The Universe is incredibly big and seems full of potential for life, with billions of habitable planets. If an advanced civilization had the technology to travel between the stars, at just 0.1% of the speed of light, It could colonize our galaxy in roughly 100 million years. Which is not that long given the billions of years the milky way has existed – so in principle any spacefaring civilization should be able to spread rapidly over huge sectors of the galaxy. And yet we see nothing, hear nothing, the universe seems empty. Devoid of others. This is the Fermi Paradox, which we have discussed in more detail in other videos.

Confronted with the seemingly empty universe, humanity faces a dilemma. We desperately want to know if we are alone in the Milky Way. We want to call out and reveal ourselves to anyone watching but that could be the last thing we ever do. Because maybe the universe is not empty. Maybe it’s full of civilizations but they are hiding from each other. Maybe the civilizations that attracted attention in the past were wiped away by invisible arrows. This is the Dark Forest solution to the Fermi paradox.

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ https://kgs.link/shop-156  
Join the Patreon Bird Army 🐧  https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:
Soundcloud: https://bit.ly/3pQJ4Oo
Bandcamp: https://bit.ly/3m0fDsc

If you want to help us caption this video, please send subtitles to subtitle@kurzgesagt.org
You can find info on what subtitle files work on YouTube here:
https://support.google.com/youtube/answer/2734698?hl=en-GB&ref_topic=7296214
Thank you!

🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons (from http://kgs.link/patreon) who support us every month and made this video possible:
Ibrahim Khan, gibraltar, Farago Adam, Rico Meinl, Krego Kim, dove, Quentin Le Guennec, CompileNix, Kitty Kuran, Harry Smith, Marc, Nick Vest, Adrian Plummer, Daniel P, William Refsland, Ugur Doga Sezgin, Alexander Dinkelacker, Tk Price, Digital Curio, Splintercat, Mario Müller, Stanley Thompson-Thorn, Nicholas Thaera, Dan Pritts, Josh Lewis!, OffBeatBunny, Christopher Yanac, Leo Espinoza, Amocin, Emily, John Vo, N. A., Pascal Rappolt, Logan Baker, Naiche, Josh, Frederik Ebert, steve young, Ganael D, Kai, Thomas Torrissen, Andrew Weir, Victoria Dewey, Niza Mar, Rajeev Lachmipersad, John Sheffield, French Today (Camille), Kirill Vlasov, Kamito Kazaha, Adam Kurzrok, Kity Bird, Jordan Casley, Jan Pavelka, ADRIAN, Garrett Agard, Martin Etnestad Johansen, Fernanda Scovino, Sébastien Lescos, Krishen Seegobin, maylia 313, Steve Robinson, Xsitsu, jesse jones, Andrija Nenin, Pascal Newman, luixo, Zachary Stiggelbout, Brandon Wolf

