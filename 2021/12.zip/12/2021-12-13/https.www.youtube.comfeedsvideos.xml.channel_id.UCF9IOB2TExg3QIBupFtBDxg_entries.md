# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Omicron emergency interview
 - [https://www.youtube.com/watch?v=dqx_0scwiRk](https://www.youtube.com/watch?v=dqx_0scwiRk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-12-13 00:00:00+00:00

Aspiration issue reaches main stream media

## UK, 50% omicron now
 - [https://www.youtube.com/watch?v=XzrG3Odgf28](https://www.youtube.com/watch?v=XzrG3Odgf28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-12-13 00:00:00+00:00

UK, majority of London cases omicron by tomorrow, Link to free download of my 2 textbooks
http://159.69.48.3/

Campbell's Pathophysiology Notes, Amazon orders for the UK, https://www.amazon.co.uk/dp/B012HWC8SU/ref=cm_sw_em_r_mt_dp_AYC5Q7G3H2B3T4BCHQY0

Campbell's Physiology Notes 
https://www.amazon.co.uk/dp/0955379725/ref=cm_sw_em_r_mt_dp_K0MXMAP26Y77TY4J90FB
https://www.youtube.com/watch?v=L9zDnYEgX-U

London

https://www.youtube.com/watch?v=L9zDnYEgX-U

Omicron, 40% of cases

Tomorrow, 50% + of cases

Boris Johnson

At least one UK Omicron death

I think the idea that this is somehow a milder version of the virus, 

I think that’s something we need to set on one side and just recognise the sheer pace at which it accelerates through the population. 

So the best thing we can do is all get our boosters.

Mr Javid

https://www.bbc.co.uk/news/live/uk-59632655

Hospitalisations due to large numbers

https://www.youtube.com/watch?v=VwyeCeTfiN8

https://www.lbc.co.uk/radio/presenters/tom-swarbrick/south-africa-top-doc-angelique-coetzee-stresses-omicron-mild/

https://www.youtube.com/watch?v=7T0Qiyy854w&t=33s

https://www.bbc.co.uk/news/av/uk-59450988

https://metro.co.uk/2021/12/13/south-african-doctor-who-found-omicron-variant-insists-its-mild-15761122/


South Africa

https://www.nicd.ac.za/diseases-a-z-index/disease-index-covid-19/surveillance-reports/daily-hospital-surveillance-datcov-report/

https://www.nicd.ac.za/diseases-a-z-index/disease-index-covid-19/surveillance-reports/covid-19-special-reports/the-initial-and-daily-covid-19-effective-reproductive-number-in-south-africa/

Cyril Ramaphosa, 69, tested positive, Sunday

Mild symptoms


Louise
I am in the Western Cape province in SA where we have just entered our fourth wave, behind other provinces like Gauteng, which seems to have just peaked. 

Even though our area hasn’t been hit badly by Omicron infections yet, cases are rising quite quickly. Compared to Delta, where you could feel people were very anxious about contracting that variant and almost everyone knew someone in hospital and most knew someone who had died, the mood is definitely different. 

We are just not hearing about mass hospitalisations like in the third wave and those that are testing positive are mainly feeling flu like symptoms for a few days and then recovering. We are really hopeful that Omicron is definitely much milder.

US

Cases

https://covid.cdc.gov/covid-data-tracker/#trends_dailydeaths

Hospitalizations

https://covid.cdc.gov/covid-data-tracker/#hospitalizations

Pakistan

NIH able to confirm … that a recently suspected sample from Karachi is indeed the Omicron variant

France

Current 5th wave is delta

Martin Hirsch, Paris’s AP-HP hospitals group

Omicron variant, next month

India

Very low rates of infection

Essential no social distancing

Big political rallies

Omicron variant, 36 cases

3% of the virus sequences

Thailand

3 months to booster after 2nd dose





Indonesia

Start vaccinations for 6- to 11-year-olds

Western Australia 

Fully reopen borders on 5 February

Expected to hit 90% fully vaccinated target

Norway

https://www.theguardian.com/world/live/2021/dec/13/covid-news-live-boris-johnson-warns-of-omicron-tidal-wave-south-african-president-tests-positive

Prime Minister Jonas Gahr Stoere

The situation is serious. The spread of infection is too high and we have to take action to limit this development

Denmark 

https://files.ssi.dk/covid19/omikron/statusrapport/rapport-omikronvarianten-12122021-k29d

22nd November to 12 December

A total of 2,471 B.1.1.529 (Omicron) SARS-CoV-2 cases in Denmark. 

Omicron cases are identified through variant PCR and whole-genome sequencing

