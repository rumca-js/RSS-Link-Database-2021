# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The Thames Barrier must never fail. Here's why it doesn't.
 - [https://www.youtube.com/watch?v=eY-XHAoVEeU](https://www.youtube.com/watch?v=eY-XHAoVEeU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-12-13 00:00:00+00:00

The Thames Barrier is a wonder of engineering. If it fails, then London floods. Here's how the engineers there make sure it doesn't fail. More about the Thames Barrier: https://www.gov.uk/guidance/the-thames-barrier

Producer/Director: Cambria Bailey-Jones
Editor: Michelle Martin
Camera Operator: Jamie MacLeod
Drone Director: Alex Glynn
Drone Team: Ian Hunter, Tim Hubbard
Runner: Rebecca Johnson
Colourist: Jamie MacLeod
Sound Design: Dan Pugsley
Executive Producer: Guy Larsen

A Penny4 Production: https://www.penny4.co.uk

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

