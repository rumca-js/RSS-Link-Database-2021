# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## VR is EXPLODING and the  Quest 2 has a new MASSIVE Competitor
 - [https://www.youtube.com/watch?v=Gq2udkCpRAo](https://www.youtube.com/watch?v=Gq2udkCpRAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-12-14 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news! Today I have a VERY fun VR industry analysis showing projections for the Virtual Reality market by 2025. Also, a news story regarding IQIYI, mirroring the EXACT moves as Facebook and Meta to make VR take off in China. Also some Quest 2 news and updates as well as some Valve news! This should be a fun one!

My links:
Discord.gg/Thrill
Twitch.tv/Thrilluwu
Patreon.com/Thrillseeker

Sources:
https://pandaily.com/iqiyi-adventure-dream-vr-launch-conference-scheduled-for-december-1st/
https://m.weibo.cn/search?containerid=231522type%3D1%26t%3D10%26q%3D%23%E5%A5%87%E9%81%87Dream%20%E5%BF%AB%E4%B9%90%E7%AE%80%E5%8D%95%23&extparam=%23%E5%A5%87%E9%81%87Dream%20%E5%BF%AB%E4%B9%90%E7%AE%80%E5%8D%95%23&luicode=20000061&lfid=4707738577799442
https://weibo.com/ttarticle/x/m/show/id/2309404709642545791123?_wb_client_=1
https://markets.businessinsider.com/news/stocks/metaverse-investing-wall-street-jefferies-land-sales-sandbox-crypto-nfts-2021-12
https://www.ccsinsight.com/blog/extended-reality-deserves-optimism/
https://questday.fb.com/
http://global.chinadaily.com.cn/a/202112/02/WS61a89035a310cdd39bc78fbc.html
https://skarredghost.com/2021/12/13/horizon-worlds-beta-apple-among-us-vr/

