# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Papers: UK race for boosters as NHS put on crisis footing
 - [https://www.bbc.co.uk/news/blogs-the-papers-59646281?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59646281?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 23:57:51+00:00

Many of Tuesday's papers show scenes of long queues as Britons rushed out to get Covid booster jabs.

## Ros Atkins on... the Lewis Hamilton and Max Verstappen F1 title drama
 - [https://www.bbc.co.uk/news/world-59645658?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-59645658?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 23:37:29+00:00

Max Verstappen was crowned F1 world champion, after winning the Abu Dhabi Grand Prix.

## Two detained after UK boat's fatal collision off Sweden
 - [https://www.bbc.co.uk/news/world-europe-59633882?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59633882?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 23:32:31+00:00

One person is dead and one missing after a Danish ship collides with a UK vessel in the Baltic Sea.

## The strangers sharing stories on Edinburgh's listening bench
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-59609662?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-59609662?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 23:00:33+00:00

BBC Scotland's Angie Brown takes a seat on an Edinburgh bench where people are urged to chat to tackle loneliness.

## Larry Nassar abuse survivors to receive $380m settlement
 - [https://www.bbc.co.uk/news/world-us-canada-59645647?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59645647?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 22:16:19+00:00

Hundreds of women abused by the ex-US gymnastics team doctor reach a settlement with USA Gymnastics.

## How much does the diplomatic boycott of Beijing 2022 matter?
 - [https://www.bbc.co.uk/news/world-59646231?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-59646231?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 22:11:36+00:00

The Winter Olympics have been hit by a flurry of protests from governments in the West.

## Formula 1: Where next for sport after Verstappen and Hamilton title drama?
 - [https://www.bbc.co.uk/sport/formula1/59643988?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/59643988?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 21:39:19+00:00

Formula 1's controversial title decider highlights a deeper discontent over the rules and consistency of penalties handed out.

## Harry Dunn crash: Anne Sacoolas case to go before UK court
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-59643750?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-59643750?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 21:18:01+00:00

Magistrates in London will hear the case concerning the death of motorcyclist Harry Dunn.

## Post Office scandal: Government to foot bill for postmasters' compensation
 - [https://www.bbc.co.uk/news/business-59629712?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59629712?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 19:50:10+00:00

The Department for Business said that the impact on postmasters' lives "cannot be overstated".

## Paris 2024 opening ceremony to break with tradition and take place on River Seine
 - [https://www.bbc.co.uk/sport/olympics/59641903?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/olympics/59641903?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 19:14:22+00:00

The 2024 Paris Olympics will break with tradition and hold the opening ceremony along the River Seine, with crowds of more than 600,000 expected.

## US tornadoes: Is climate change to blame?
 - [https://www.bbc.co.uk/news/59641376?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59641376?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 19:09:21+00:00

Are tornadoes becoming more frequent, dangerous or unpredictable - and is the changing climate to blame?

## NatWest fined £265m after bin bags of cash laundered
 - [https://www.bbc.co.uk/news/business-59629711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59629711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 18:08:31+00:00

The state-backed bank had pleaded guilty to failing to prevent money-laundering of nearly £400m.

## Verstappen reveals Hamilton and Mercedes boss Wolff both congratulated him on title
 - [https://www.bbc.co.uk/sport/formula1/59643983?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/59643983?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 16:52:59+00:00

Max Verstappen says he was congratulated by both Lewis Hamilton and Mercedes team boss Toto Wolff after winning the Formula 1 title.

## Covid passports: Where will I need a pass and how do I get one?
 - [https://www.bbc.co.uk/news/explainers-55718553?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-55718553?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 16:44:50+00:00

England has announced a Covid passport scheme for entry to some venues.

## Holders Chelsea face Lille in Champions League while Liverpool play Inter after last-16 draw chaos
 - [https://www.bbc.co.uk/sport/football/59637671?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59637671?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 15:12:27+00:00

Holders Chelsea will play Ligue 1 side Lille in the Champions League last 16 after the draw for the knockout stages took place for a second time.

## Raducanu withdraws from Abu Dhabi exhibition event after testing positive for Covid-19
 - [https://www.bbc.co.uk/sport/tennis/59640486?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/59640486?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 14:59:07+00:00

Emma Raducanu hopes to "get back soon" after testing positive for Covid-19 and withdrawing from the Mubadala World Tennis Championships.

## Cars written off by Watford road bollards caught on camera
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-59641534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-59641534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 14:14:36+00:00

A number of vehicles including a police van have been seen colliding with the width restriction.

## Tony's sorry for missing advent chocolate stunt
 - [https://www.bbc.co.uk/news/business-59636955?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59636955?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 13:32:40+00:00

Tony's Chocolonely apologises for leaving an advent calendar window empty to highlight inequality.

## Is a million boosters a day achievable? And other questions
 - [https://www.bbc.co.uk/news/world-asia-china-51176409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-51176409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 13:04:39+00:00

The government has announced an ambitious plan to offer boosters to all adults in England.

## Cabaret: Critics make song and dance over Eddie Redmayne musical
 - [https://www.bbc.co.uk/news/entertainment-arts-59635801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59635801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 12:06:26+00:00

The new West End production, starring Eddie Redmayne and Jessie Buckley, opened to rave reviews.

## First UK death recorded with Omicron variant
 - [https://www.bbc.co.uk/news/uk-59639007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59639007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 11:53:25+00:00

One person in the UK has died with Omicron variant of coronavirus, Prime Minister Boris Johnson confirms.

## Justin Herbert, Tom Brady & Jakeem Grant in NFL plays of the week
 - [https://www.bbc.co.uk/sport/av/american-football/59638388?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/59638388?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 11:52:20+00:00

Justin Herbert's incredible throw to Jalen Guyton for the LA Chargers is amongst a stellar selection of the best plays week from week 13 in the NFL.

## Sergio Aguero: Barcelona's former Man City striker set to announce retirement on Wednesday
 - [https://www.bbc.co.uk/sport/football/59636526?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59636526?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 11:50:27+00:00

Sergio Aguero is set to announce his retirement on Wednesday, less than six months after joining Barcelona, reports Guillem Balague.

## Hamilton 'a fantastic example on how to handle defeat' and will be back - Coulthard
 - [https://www.bbc.co.uk/sport/formula1/59588859?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/59588859?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 11:24:16+00:00

Seven-time champion Lewis Hamilton is a "fantastic example" on "how to handle defeat" and is "committed" to coming back stronger next season, says ex-Formula 1 driver David Coulthard.

## Covid: How does the alert level system work?
 - [https://www.bbc.co.uk/news/explainers-52634739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-52634739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 10:58:53+00:00

The rapid increase in Omicron cases in the UK has led to the alert level being raised.

## Buy now pay later: How does it work?
 - [https://www.bbc.co.uk/news/explainers-59582188?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-59582188?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 10:09:37+00:00

It is estimated about 15 million adults of all ages in the UK are actively using this form of credit.

## Trains: Crosskeys to Newport service is first since 1962
 - [https://www.bbc.co.uk/news/uk-wales-59578885?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59578885?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 09:20:31+00:00

A village that shares its name with a pub toasts a rail link restored after 60 years.

## Sports Personality 2021: Tom Daley, Tyson Fury, Adam Peaty, Emma Raducanu, Raheem Sterling and Sarah Storey up for award
 - [https://www.bbc.co.uk/sport/sports-personality/59607666?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/sports-personality/59607666?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 08:32:00+00:00

A shortlist of six contenders is announced for the 2021 BBC Sports Personality of the Year award.

## Omicron: Should I be working from home now?
 - [https://www.bbc.co.uk/news/business-52567567?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-52567567?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 08:28:50+00:00

People across the UK are now being advised to work at home where possible.

## Covid: Booster push to tackle Omicron and new working from home guidance
 - [https://www.bbc.co.uk/news/uk-59630565?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59630565?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 08:23:18+00:00

Five things you need to know about the coronavirus pandemic this Monday morning.

## Petra Srncova: Body found is missing hospital worker
 - [https://www.bbc.co.uk/news/uk-england-london-59631639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59631639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 08:21:57+00:00

The Czech foreign minister confirms Petra Srncova's body has been found in a park in south London.

## Nuclear fusion reactor experiment to produce clean energy
 - [https://www.bbc.co.uk/news/science-environment-59601560?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59601560?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 06:15:41+00:00

An experiment is taking place on an industrial estate just outside Didcot in the south of England.

## Andy Zaltzman column: Why Joe Root is 1,000 times better than the next England batter
 - [https://www.bbc.co.uk/sport/cricket/59626553?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59626553?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 06:12:46+00:00

Comedian and Test Match Special statistician Andy Zaltzman looks at some of the weird and wonderful stats emerging from the Ashes.

## Dog mutilation: Breeders cropping ears to follow social media trend
 - [https://www.bbc.co.uk/news/uk-wales-59491179?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59491179?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 06:08:43+00:00

Puppies are having their ears cut by breeders for a "striking" look, a BBC investigation finds.

## Kentucky tornadoes: Rebuilding lives from 'hell on Earth'
 - [https://www.bbc.co.uk/news/world-us-canada-59632356?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59632356?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 05:38:40+00:00

Residents in the US state are sifting through the rubble that was once a town.

## The papers: A million jabs a day, as PM declares 'emergency'
 - [https://www.bbc.co.uk/news/blogs-the-papers-59632045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59632045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 05:31:23+00:00

Boris Johnson's announcement on expanding the booster jab rollout makes the front of most of Monday's papers.

## Kentucky tornadoes: Death toll likely to pass 100, governor says
 - [https://www.bbc.co.uk/news/world-us-canada-59632403?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59632403?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 05:16:20+00:00

Rescue workers have continued to scour the rubble but hopes of finding survivors are waning.

## And Just Like That Peloton resurrects show character
 - [https://www.bbc.co.uk/news/business-59632383?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59632383?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 04:50:34+00:00

The exercise equipment maker released an online parody after a scene that sent its shares tumbling.

## Covid: Work-from-home guidance reintroduced in England
 - [https://www.bbc.co.uk/news/uk-59632424?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59632424?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 04:46:15+00:00

People should now work from home if they can to help curb the spread of Omicron, the government says.

## France resists US challenge to its values
 - [https://www.bbc.co.uk/news/world-europe-59584125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59584125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 00:20:39+00:00

The government is fighting back at what it sees as imported cultural ideas from the UK and US.

## The ultra-violent cult that became a global mafia
 - [https://www.bbc.co.uk/news/world-africa-59614595?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-59614595?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 00:01:43+00:00

A BBC investigation into Black Axe has unearthed new evidence of political infiltration, and a scamming and killing operation spanning the globe.

## Howard University: Why these students slept out in tents on campus for weeks
 - [https://www.bbc.co.uk/news/world-us-canada-59613217?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59613217?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 00:01:25+00:00

After reports of mould and rodents in dorms, protesters at Howard University took over a campus building.

## How hologram tech may soon replace video calls
 - [https://www.bbc.co.uk/news/business-59577341?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59577341?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-13 00:00:31+00:00

The coronavirus pandemic and travel bans have accelerated interest in holographic communication.

