# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Curtis Harding - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=3_6Ugy68upg](https://www.youtube.com/watch?v=3_6Ugy68upg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-14 00:00:00+00:00

http://KEXP.ORG presents Curtis Harding performing live, recorded exclusively for KEXP.

Songs:
Hopeful
Can't Hide It
With You
Explore
I Won't Let You Down

Recorded at Palomino Sound, Los Angeles, CA
Produced by Good Trouble Films
Directed by Hannah Welever
Shot by Hannah Welever, Alicia Afshar, Lance Williams
Edited by Priscilla Perez
Mixed by Sam Cohen

Curtis Harding - vocals
Aaron Stern - bass
Michael Villiers - drums
Tyler Morris - guitar
Jeremy Gill - keys / sax
Ludo Louis - trumpet 

https://curtisharding.com
http://kexp.org

## Curtis Harding - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=dRNkUJYPVFw](https://www.youtube.com/watch?v=dRNkUJYPVFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-13 00:00:00+00:00

http://KEXP.ORG presents Curtis Harding sharing a live performance recorded exclusively for KEXP and talking to DJ Troy Nelson. Recorded November 18, 2021.

Songs:
Hopeful
Can't Hide It
With You
Explore
I Won't Let You Down

Recorded at Palomino Sound, Los Angeles, CA
Produced by Good Trouble Films
Directed by Hannah Welever
Shot by Hannah Welever, Alicia Afshar, Lance Williams
Edited by Priscilla Perez
Mixed by Sam Cohen

Curtis Harding - vocals
Aaron Stern - bass
Michael Villiers - drums
Tyler Morris - guitar
Jeremy Gill - keys / sax
Ludo Louis - trumpet 

https://curtisharding.com
http://kexp.org

