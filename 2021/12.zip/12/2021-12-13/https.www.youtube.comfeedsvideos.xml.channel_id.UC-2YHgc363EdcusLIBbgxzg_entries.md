# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Venus Used To Be A Lot More Like Earth | Answers With Joe
 - [https://www.youtube.com/watch?v=QQOCidVdHJ0](https://www.youtube.com/watch?v=QQOCidVdHJ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-12-13 00:00:00+00:00

Use code JOESCOTT14 for up to 14 FREE MEALS + 3 Free Gifts across 5 HelloFresh boxes plus free shipping at https://bit.ly/3pkycbs
Venus has long been called Earth's twin, because our sizes are so similar. But as we learned in the early 60s, on our surface we couldn't be more different. This wasn't always the case though. It's thought that up until about 500 million years ago, our planets were very similar, in fact Venus may have supported life. So what happened?

Intro produced by Cooper Carr, edited by Nick Turnbow, with special makeup effects by Sara Bachmeyer

Thumbnail image attribution: Daein Ballard 
https://deviantart.com/ittiz/gallery

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.nasa.gov/feature/55-years-ago-mariner-2-first-to-venus

https://en.wikipedia.org/wiki/Venus_in_fiction

https://www.sciencealert.com/co2-is-only-a-tiny-part-of-our-atmosphere-but-it-has-a-huge-influence-here-s-why

https://www.aeronomie.be/en/encyclopedia/venus-backwards-rotation-and-orbital-period

The Mike Way and Anthony Del Genio study: https://arxiv.org/abs/2003.05704

https://www.scientificamerican.com/article/model-suggests-toxic-transformation-on-venus/

https://volcano.oregonstate.edu/venus

https://courses.lumenlearning.com/astronomy/chapter/the-geology-of-venus/

https://astronomy.com/news/2021/07/turns-out-venus-almost-has-tectonic-plates

https://news.climate.columbia.edu/2021/02/25/carbon-dioxide-cause-global-warming/

https://climate.nasa.gov/news/3105/earths-magnetosphere-protecting-our-planet-from-harmful-space-energy/

https://aasnova.org/2019/07/08/how-venus-reacts-when-the-sun-strikes/

https://www.universetoday.com/138021/earth-venus-size-doesnt-venus-magnetosphere-maybe-didnt-get-smashed-hard-enough/

