# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Sztuczna inteligencja sprawdzi czy nie kłamiesz. Tajny projekt Unii Europejskiej!
 - [https://www.youtube.com/watch?v=s_xvgvdEZIg](https://www.youtube.com/watch?v=s_xvgvdEZIg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-12-14 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/31W78re
2. https://bit.ly/3s4evYa
3. https://bit.ly/3IPOBxf
4. https://bit.ly/3GGwOH6
5. https://bit.ly/3zJeU2M
---------------------------------------------------------------
🎴 Wykorzystano grafikę: 
iborderctrl.eu - https://bit.ly/31W78re
---------------------------------------------------------------
💡 Tagi: #UE #AI
--------------------------------------------------------------

## Przodkowie Ursuli von der Leyen nie byli tak tolerancyjni jak ona. Trudna historia rodu Ladsonów
 - [https://www.youtube.com/watch?v=kX5S9U-D59s](https://www.youtube.com/watch?v=kX5S9U-D59s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-12-13 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3dSTlE1
2. https://bit.ly/3oPj9Y7
3. https://bit.ly/3DQBqZr
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę: 
Sandro Halank / Wikimedia Commons / CC-BY-SA 3.0
https://bit.ly/2RVDb5w
---------------------------------------------------------------
💡 Tagi: #UE #historia
--------------------------------------------------------------

