# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Thunder Tier One | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=VeTvM9KYYn8](https://www.youtube.com/watch?v=VeTvM9KYYn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-14 00:00:00+00:00

KC Nwosu reviews Thunder Tier One, developed by Krafton INC.

Thunder Tier One on Steam: https://store.steampowered.com/app/377300/Thunder_Tier_One/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Jack's Ultimate Gift Guide for Gamers | Slightly Something Else
 - [https://www.youtube.com/watch?v=TqHRqR9VEyI](https://www.youtube.com/watch?v=TqHRqR9VEyI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-14 00:00:00+00:00

This week on Slightly Something Else, Yahtzee and Jack create the ultimate gift guide for gamers...

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Is Dark Souls' Leveling System Useless?
 - [https://www.youtube.com/watch?v=fW0lAZaFuOA](https://www.youtube.com/watch?v=fW0lAZaFuOA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-13 00:00:00+00:00

In Part 2 of The Anatomy of Dark Souls J covers the progression cycle, leveling system & difficulty balance of this endlessly enticing series. Make sure to check out Part 1 here: https://youtu.be/ER1whpdrsvM

If you want to see more game design content a new Anatomy episode will release every other week, or you can subscribe to JM8s personal channel for similar content: https://www.youtube.com/c/JM8GameDesign

Timestamps:
Introduction - 00:00
Pacing Power - 00:30
Lost Through Leveling - 02:40
Character Building - 04:50
Soul Sacrifice - 05:52
Accessibility & Difficulty - 07:40

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Santa Claus in Battlefield 2042 Is All Fortnite's Fault | The Takeaway
 - [https://www.youtube.com/watch?v=75ya3Gu3AH4](https://www.youtube.com/watch?v=75ya3Gu3AH4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-13 00:00:00+00:00

A Christmas-themed set of skins recently leaked for Battlefield 2042 which had fans frustrated the game is already looking to release paid MTX before fixing many of the issues currently plaguing the game, while also lamenting the loss of the franchise's identity. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

