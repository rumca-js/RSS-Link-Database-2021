# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Delivery driver's gesture prompts homeowner to reach out to Amazon
 - [https://www.cnn.com/videos/business/2021/12/13/amazon-delivery-driver-holiday-decorations-affil-pkg-vpx.kptv](https://www.cnn.com/videos/business/2021/12/13/amazon-delivery-driver-holiday-decorations-affil-pkg-vpx.kptv)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 23:35:36+00:00

One Amazon delivery driver's nice gesture left an Oregon homeowner so thankful, she decided to reach out to the company so he could be recognized. CNN affiliate KPTV reports.

## Larry Nassar victims reach $380 million settlement with USA Gymnastics and US Olympic Committee
 - [https://www.cnn.com/2021/12/13/us/larry-nassar-gymnastics-settlement/index.html](https://www.cnn.com/2021/12/13/us/larry-nassar-gymnastics-settlement/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 23:17:00+00:00

USA Gymnastics, the US Olympic and Paralympic Committee and their insurers agreed to pay $380 million in a settlement with the victims of Larry Nassar, the former Olympic doctor who sexually abused girls for decades, according to an attorney for multiple victims.

## Derek Chauvin to change plea in federal civil rights case in death of George Floyd
 - [https://www.cnn.com/2021/12/13/us/derek-chauvin-federal-plea-change/index.html](https://www.cnn.com/2021/12/13/us/derek-chauvin-federal-plea-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 21:29:35+00:00



## The West's chorus of threats against Russia could work -- but it's a risky move
 - [https://www.cnn.com/2021/12/13/world/meanwhile-in-america-december-13-intl/index.html](https://www.cnn.com/2021/12/13/world/meanwhile-in-america-december-13-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 19:43:58+00:00

Tensions between the Kremlin and the West are locked in a worrying cycle, with no sign yet that Vladimir Putin has been moved by threats of economic retaliation if his troops invade neighboring Ukraine. The Russian President has expressed desire for an in-person meeting with US President Joe Biden -- but will the White House gamble on that?

## Watch moment Miss Universe 2021 was crowned
 - [https://www.cnn.com/videos/style/2021/12/13/harnaaz-sandhu-miss-universe-india-lon-orig-mrg.cnn](https://www.cnn.com/videos/style/2021/12/13/harnaaz-sandhu-miss-universe-india-lon-orig-mrg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 19:04:53+00:00

India's Harnaaz Sandhu became Miss Universe 2021 at the 70th edition of the pageant, held in Eilat, Israel.

## He killed some of Coke's most beloved brands. And he'd do it all over again
 - [https://www.cnn.com/2021/12/13/business/risk-takers-james-quincey/index.html](https://www.cnn.com/2021/12/13/business/risk-takers-james-quincey/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 17:23:08+00:00

Coca-Cola CEO James Quincey, a 25-year veteran of the company, has been hearing it from disgruntled niche beverage fans.

## Rand Paul called out for disaster relief hypocrisy
 - [https://www.cnn.com/videos/us/2021/12/13/rand-paul-federal-aid-reality-check-newday-vpx.cnn](https://www.cnn.com/videos/us/2021/12/13/rand-paul-federal-aid-reality-check-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 15:26:33+00:00

After deadly tornadoes devastated parts of Kentucky, Sen. Rand Paul (R-KY) asked President Biden for federal aid. However, the senator has a history of opposing aid for disaster victims.

## 'Parasite' actress diagnosed with thyroid cancer
 - [https://www.cnn.com/2021/12/13/entertainment/park-so-dam-thyroid-cancer-scli-intl/index.html](https://www.cnn.com/2021/12/13/entertainment/park-so-dam-thyroid-cancer-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 12:04:40+00:00

South Korean actress Park So Dam, who shot to fame at home and abroad thanks to her role in the Oscar-winning movie "Parasite," has been diagnosed with papillary thyroid cancer.

## Sri Lanka shows off giant natural blue sapphire
 - [https://www.cnn.com/style/article/sri-lanka-sapphire-horana/index.html](https://www.cnn.com/style/article/sri-lanka-sapphire-horana/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 09:45:29+00:00

Sri Lankan authorities on Sunday put on show what they said was the world's largest natural corundum blue sapphire, weighing 310 kilograms (683 pounds), which was found in a gem pit about three months ago.

## Hong Kong tycoon Jimmy Lai and 7 others sentenced to prison over banned Tiananmen vigil
 - [https://www.cnn.com/2021/12/13/asia/jimmy-lai-hong-kong-arrest-intl-hnk/index.html](https://www.cnn.com/2021/12/13/asia/jimmy-lai-hong-kong-arrest-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 08:29:31+00:00

A Hong Kong court has sentenced media tycoon Jimmy Lai and seven other pro-democracy figures to up to 14 months behind bars for participating in an unauthorized assembly last year to commemorate the Tiananmen Square crackdown.

## Popular tourist destination caught up in deadly violence
 - [https://www.cnn.com/videos/travel/2021/12/13/mexico-cancun-gang-violence-rivers-pkg-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/travel/2021/12/13/mexico-cancun-gang-violence-rivers-pkg-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-13 06:16:29+00:00

Tourists recently have been caught up in deadly violence taking place in Mexico's Quintana Roo state, a popular travel destination boasting Mayan ruins and scenic Cancun beaches. CNN's Matt Rivers reports.

