# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 DUMBEST Ways To Lose A Multiplayer Game
 - [https://www.youtube.com/watch?v=xuEWUu2gCJ0](https://www.youtube.com/watch?v=xuEWUu2gCJ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-14 00:00:00+00:00

Losing in a multiplayer game is common, but losing in an embarrassing way is the absolute worst. Here are some funny examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Best Christmas Gifts For Gamers [2021]
 - [https://www.youtube.com/watch?v=HXJUSd98as8](https://www.youtube.com/watch?v=HXJUSd98as8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-13 00:00:00+00:00

The 2021 Holiday season is well underway, and we're giving you some tips and recommendations to help you finish up your shopping. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10 Custom Gamertag/youtube/twitch
https://www.etsy.com/listing/888407311/personalised-gamer-tag-sign-gaming-name
https://www.etsy.com/listing/896679727/gamer-tag-sign-gamertag-light-streamer
https://www.etsy.com/listing/1126428544/personalised-gamer-tag-sign-table

Cool Neon Lightshttps://fanfitgaming.com/neon-lights

Custom Controllershttps://scufgaming.com/i
https://us.aimcontrollers.com/

9 Custom Coasters/Mug https://www.etsy.com/listing/879483682/gamer-inspired-coasters-with-optional?
https://www.etsy.com/listing/921394763/funny-gamer-definition-mug-made-in-us

8 Custom Headset Stand https://www.etsy.com/listing/472762708/after-christmas-delivery-custom
https://www.etsy.com/listing/823162492/personalized-headphone-standpersonalize

7 No Glare - Computer Monitor Light https://www.amazon.com/Computer-LOFTer-Adjustable-Brightness-Temperature/dp/B07TCYBQGK/

6 Beanie https://fanfitgaming.com/npc-winter-beaniehttps://www.etsy.com/in-en/listing/855329636/what-a-horrible-night-to-have-a-curse

5 RGB https://www.amazon.com/Corsair-LT100-Smart-Lighting-Starter/dp/B089QWBHB3/

https://www.amazon.com/VIVIFY-ARQUUS-Worlds-Console-Certified/dp/B0869BYN3F/
https://www.etsy.com/in-en/listing/1083515743/matrix-mathematics-lamp-matrix-green
https://www.etsy.com/listing/1027027601/custom-rgb-gaming-mouse-padcustom-rgb
4 Mobile Gamers https://www.razer.com/mobile-accessories/razer-phone-cooler-chroma/RC21-01790100-R3M1
https://www.amazon.com/Razer-Kishi-Controller-Android-Passthrough-Thumbsticks/dp/B086X8DHN2/ [Android/iPhone]

3 Gamepass/PSplus gift card/STEAM Gift Card

-------2 Gaming cook books https://delishably.com/cooking-equipment/video-game-cookbooks
------
1 ConsolesOculus Quest 2/SwitchOLED/PS5/Series S/X

