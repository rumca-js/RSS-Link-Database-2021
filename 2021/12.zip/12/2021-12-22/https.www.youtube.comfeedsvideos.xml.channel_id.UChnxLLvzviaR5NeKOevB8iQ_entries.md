# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Building Beats with Wave Alchemy TRIAZ
 - [https://www.youtube.com/watch?v=7xci8VFFS_8](https://www.youtube.com/watch?v=7xci8VFFS_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-12-22 00:00:00+00:00

Use the code "WABC2F7C49" at checkout and get 15% off: https://www.wavealchemy.co.uk/triaz/pid195/

Triaz is a Kontakt (and Kontakt Player) instrument that lets you quickly build cool drum patterns. Let's take a look at it and talk about drums!

00:00 intro
00:41 building a lo-fi beat
14:27 my presets
19:19 creating a randomized top-loop
20:38 building a chill-step beat
26:07 using custom samples
27:09 conclusion
29:14 can i kick it
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

