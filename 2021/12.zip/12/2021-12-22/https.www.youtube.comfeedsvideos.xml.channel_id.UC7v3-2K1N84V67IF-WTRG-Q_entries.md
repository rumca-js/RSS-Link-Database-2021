# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Matrix Resurrections - SPOILER Talk
 - [https://www.youtube.com/watch?v=LyZQeDsvRgM](https://www.youtube.com/watch?v=LyZQeDsvRgM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-12-23 00:00:00+00:00

Now that THE MATRIX RESURRECTIONS is on HBO Max, I watched it again. Here are my thoughts after a second viewing...

