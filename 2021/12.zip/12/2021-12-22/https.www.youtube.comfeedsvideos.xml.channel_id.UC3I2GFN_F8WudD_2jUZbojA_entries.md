# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Shaina Shepherd - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=bFRabHnkosk](https://www.youtube.com/watch?v=bFRabHnkosk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-22 00:00:00+00:00

http://KEXP.ORG presents Shaina Shepherd performing live in the KEXP studio. Recorded November 22, 2021.

Songs:
Never Be Another You
Something to Say
Lover
Hope

Shaina Shepherd - Vocals
Jeff Fielder - Guitar
Ty Bailie - Keys
Rebecca Young - Bass
Michael Musburger - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Scott Holpainen

https://www.shainashepherdmusic.com
http://kexp.org

## Shaina Shepherd - Hope (Live on KEXP)
 - [https://www.youtube.com/watch?v=ihGzloZ3DBQ](https://www.youtube.com/watch?v=ihGzloZ3DBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-22 00:00:00+00:00

http://KEXP.ORG presents Shaina Shepherd performing “Hope” live in the KEXP studio. Recorded November 22, 2021.

Shaina Shepherd - Vocals
Jeff Fielder - Guitar
Ty Bailie - Keys
Rebecca Young - Bass
Michael Musburger - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Scott Holpainen

https://www.shainashepherdmusic.com
http://kexp.org

## Shaina Shepherd - Lover (Live on KEXP)
 - [https://www.youtube.com/watch?v=n8SDbgxlkcE](https://www.youtube.com/watch?v=n8SDbgxlkcE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-22 00:00:00+00:00

http://KEXP.ORG presents Shaina Shepherd performing “Lover” live in the KEXP studio. Recorded November 22, 2021.

Shaina Shepherd - Vocals
Jeff Fielder - Guitar
Ty Bailie - Keys
Rebecca Young - Bass
Michael Musburger - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Scott Holpainen

https://www.shainashepherdmusic.com
http://kexp.org

## Shaina Shepherd - Never Be Another You (Live on KEXP)
 - [https://www.youtube.com/watch?v=5ukLf3_9L7I](https://www.youtube.com/watch?v=5ukLf3_9L7I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-22 00:00:00+00:00

http://KEXP.ORG presents Shaina Shepherd performing “Never Be Another You” live in the KEXP studio. Recorded November 22, 2021.

Shaina Shepherd - Vocals
Jeff Fielder - Guitar
Ty Bailie - Keys
Rebecca Young - Bass
Michael Musburger - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Scott Holpainen

https://www.shainashepherdmusic.com
http://kexp.org

## Shaina Shepherd - Something To Say (Live on KEXP)
 - [https://www.youtube.com/watch?v=FTuiUuxu5Zk](https://www.youtube.com/watch?v=FTuiUuxu5Zk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-22 00:00:00+00:00

http://KEXP.ORG presents Shaina Shepherd performing “Something To Say” live in the KEXP studio. Recorded November 22, 2021.

Shaina Shepherd - Vocals
Jeff Fielder - Guitar
Ty Bailie - Keys
Rebecca Young - Bass
Michael Musburger - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Scott Holpainen

https://www.shainashepherdmusic.com
http://kexp.org

