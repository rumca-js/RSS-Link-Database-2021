# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## 2021 Bloopers & Behind the Scenes!
 - [https://www.youtube.com/watch?v=mv4_RocY1Hc](https://www.youtube.com/watch?v=mv4_RocY1Hc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-12-23 00:00:00+00:00

Each week we make sketch comedy videos which inevitably come with hilarious behind the scenes moments. Please enjoy a highlight reel from 2021. Wishing you all a wonderful holiday season and a happy New Year. See you in 2022!!

Huge thank you to all the wonderful people who have been on the channel this year and who have helped behind the scenes.


#bloopers #bts

