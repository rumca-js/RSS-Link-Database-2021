# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## NFTs are Pointless
 - [https://www.youtube.com/watch?v=_noey_NmZV0](https://www.youtube.com/watch?v=_noey_NmZV0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-12-22 18:53:45+00:00

Go to Squarespace.com for a free trial, and when you’re ready to launch, go to http://www.squarespace.com/knowledgehub to save 10% off your first purchase of a website or domain.

Wow. A topic you all saw coming. And it's here. Congratulations. Good on you.

Twitter: https://twitter.com/WhimsuTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub

