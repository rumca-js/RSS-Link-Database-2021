# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Best Reads 0f 2021
 - [https://www.youtube.com/watch?v=jiGuOcrN9oc](https://www.youtube.com/watch?v=jiGuOcrN9oc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-12-23 00:00:00+00:00

The best books I read in 2021! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## Witcher (S2 Ep.1 Deep Dive) The Bad Kinda Bite!
 - [https://www.youtube.com/watch?v=ucqd3__FR-A](https://www.youtube.com/watch?v=ucqd3__FR-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-12-22 00:00:00+00:00

My thoughts on episode 1 of the second #Witcher season! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

