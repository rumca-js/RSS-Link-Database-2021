# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## All Your Favorite Covid Christmas Carols In One Place
 - [https://www.youtube.com/watch?v=fXWcOxl9EKI](https://www.youtube.com/watch?v=fXWcOxl9EKI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-23 00:00:00+00:00

Celebrate the season with these classic Covid Christmas Carols!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Elon Musk Sits Down With The Babylon Bee
 - [https://www.youtube.com/watch?v=jvGnw1sHh9M](https://www.youtube.com/watch?v=jvGnw1sHh9M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-22 00:00:00+00:00

RED ALERT: this is not a joke. Elon Musk sat down with Babylon Bee CEO Seth Dillon, EIC Kyle Mann, and Creative Director Ethan Nicolle for an in-depth interview on wokeness, Elizabeth Warren, taxing the rich, the Metaverse, which superhero Elon would be, and how the left is killing comedy.

This version contains the full interview with 45 additional minutes of content.

Go to http://ADFlegal.org/mandate and make a tax deductible donation to ADF’s Freedom Fund to ensure they have the resources necessary to continue their challenges in court, all the way to the U.S. Supreme Court, if necessary!

Back The DAVID Movie project by going to http://angel.com/david to help to help bring this incredible movie to life.

Go to http://TuttleTwins.com and use coupon "BEE" to get 50% off any of their book bundles.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Elon Musk Talks About How Wokeness Is Killing Comedy and Threatening Civilization
 - [https://www.youtube.com/watch?v=A00eGrw_c5Q](https://www.youtube.com/watch?v=A00eGrw_c5Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-22 00:00:00+00:00

In his interview with The Babylon Bee, Elon Musk warns about one of the biggest threats to modern civilization: the woke mind virus.

See the rest of the interview here: https://www.youtube.com/watch?v=jvGnw1sHh9M

## Watch As Elon Musk Completely Owns Elizabeth Warren
 - [https://www.youtube.com/watch?v=1XpSNgkmDMk](https://www.youtube.com/watch?v=1XpSNgkmDMk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-22 00:00:00+00:00

Elon Musk took Senator Elizabeth Warren to task in this interview with The Babylon Bee on whether he pays enough in taxes or if he is a freeloading bum.

See the rest of the interview here: https://www.youtube.com/watch?v=jvGnw1sHh9M

