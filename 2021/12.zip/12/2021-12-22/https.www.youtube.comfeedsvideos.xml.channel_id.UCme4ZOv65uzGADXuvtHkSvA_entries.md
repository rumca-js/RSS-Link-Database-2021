# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 Księga Samuela || Rozdział 04
 - [https://www.youtube.com/watch?v=k964i6pTviY](https://www.youtube.com/watch?v=k964i6pTviY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-23 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Kolędy dla radości [04] Północ już była
 - [https://www.youtube.com/watch?v=rRuR4FbBZkE](https://www.youtube.com/watch?v=rRuR4FbBZkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-23 00:00:00+00:00

Fundacja Malak wraz z Rafałem Maciejewskim postanowiła wyprodukować cztery świąteczne songi. Są wśród nich dwie tradycyjne kolędy, pastorałka i świąteczny hicior. Wszystko w nowoczesnej aranżacji, którą stworzył Mateusz Banasiuk. Zdecydowaliśmy się zagrać kolędy, bo chcemy wspólnie dać ludziom trochę radości i uśmiechu. Boże Narodzenie to czas kiedy znów przypominamy sobie, że Bóg w Jezusie stał się naszym bratem, bliskim, współczującym, rozumiejącym - opowiada - a to wszystko zdecydowanie powody do uśmiechu. 
Rafał zebrał swoich uczniów, przyjaciół, ludzi, z którymi śpiewa przy różnych okazjach, z którymi zna się od dominikanów i w ten sposób powstał nasz świąteczny boysband. 

Osiem męskich głosów zapowiadających nam Dobrą Nowinę. 

MUZYKA:

aranżacja: Mateusz Banasiuk
realizacja nagrania: Damian Posiła
edycja/mix/mastering: Mateusz Banasiuk

tenory: 
Tymoteusz Ekert
Mateusz Banasiuk

barytony: 
Rafał Maciejewski
Jakub Pokorski
Damian Posiła

basy:
Paweł Banach
Szymon Dębkowski
Kamil Gruszczyński
Michał Buczek

—

VIDEO:

zdjęcia: Michał Buczek, Emil Książczak
montaż: Michał Buczek
oświetlenie: Bartłomiej Borcz
produkcja i scenografia: Fundacja Malak

www.fundacjamalak.pl
@Langustanapalmie @FundacjamalakPl 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## NV[#435] Jeśli Bóg milczy, bądź jak Beethoven
 - [https://www.youtube.com/watch?v=CegQJUUi_7c](https://www.youtube.com/watch?v=CegQJUUi_7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-23 00:00:00+00:00

@langustanapalmie #niecodziennyvlog
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Zdjęcia i montaż: Adam Szustak OP
Muzyka: https://soundcloud.com/dcuttermusic/chocolate-box

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wyszynki [#975] Czas
 - [https://www.youtube.com/watch?v=2levw4ep1nY](https://www.youtube.com/watch?v=2levw4ep1nY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-23 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Zapraszamy Was do włączenia się w Adwentową Akcję Charytatywną:
→ https://charytatywnie.fundacjamalak.pl/  
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka cegiełka (w wersji papierowej) wyruszy do Was w drogę już 12 listopada.
Ebook - dostępny już dziś.

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 1 Księga Samuela || Rozdział 03
 - [https://www.youtube.com/watch?v=thjR50L20eI](https://www.youtube.com/watch?v=thjR50L20eI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-22 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Aloes || Agnieszka Musiał
 - [https://www.youtube.com/watch?v=DoAJD4ryVGw](https://www.youtube.com/watch?v=DoAJD4ryVGw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-22 00:00:00+00:00

Cztery niedziele Adwentu i cztery piosenki na A. 
Zapraszamy w krainę SŁOWA, MUZYKI i OBRAZU. 

@Langustanapalmie @AgnieszkaMusiaYT 

tekst: Agnieszka Musiał II Jan Smoczyński 
muzyka: Agnieszka Musiał II Jan Smoczyński 
zespół w składzie: Agnieszka Musiał || Jan Smoczyński || Kamil Siciak
produkcja serii, scenografia, stylizacja: Sylwia Smoczyńska 
realizacja i produkcja muzyki: Jan Smoczyński 
zdjęcia: Marcin Jończyk 
montaż: Marcin Kopiec 
realizacja światła: Bartek Borcz 
pomoc techniczna: Michał Blicharski 
make up: Zuza Górska 
Zdjęcia zrealizowano w Agroturystyce Modry Ganek

"Aloes"

zwr. 1
Mówią do mnie, ze nie warto 
Iść za głosem serca
Rezygnuję z moich pragnień 
Inni wiedzą lepiej
wciąż nie widzę 
Końca zmagań 
droga mnie wykańcza 
Nie chce dłużej się poddawać 
Nie chce walczyć sama 

ref.
Twoje słowa jak aloes
Łagodzą każdy ból
Jeszcze nie wszystko stracone 
Uuu
jak aloes łagodzisz 
Każdy mój trud 
Jeszcze nie wszystko stracone 
Aloes 

Zwr. 2 
Nie poddaję się naciskom 
Serce słyszy prawdę 
Gdzie nadzieja tam marzenia 
Nigdy nie jest za późno 

Ref.
Twoje słowa jak aloes
Łagodzą każdy ból
Jeszcze nie wszystko stracone 
Uuu
jak aloes łagodzisz 
Każdy mój trud 
z nadzieja Czekam na nowe 
Aloes 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Kolędy dla radości [03] Mizerna cicha
 - [https://www.youtube.com/watch?v=TBATInAMjIc](https://www.youtube.com/watch?v=TBATInAMjIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-22 00:00:00+00:00

Fundacja Malak wraz z Rafałem Maciejewskim postanowiła wyprodukować cztery świąteczne songi. Są wśród nich dwie tradycyjne kolędy, pastorałka i świąteczny hicior. Wszystko w nowoczesnej aranżacji, którą stworzył Mateusz Banasiuk. Zdecydowaliśmy się zagrać kolędy, bo chcemy wspólnie dać ludziom trochę radości i uśmiechu. Boże Narodzenie to czas kiedy znów przypominamy sobie, że Bóg w Jezusie stał się naszym bratem, bliskim, współczującym, rozumiejącym - opowiada - a to wszystko zdecydowanie powody do uśmiechu. 
Rafał zebrał swoich uczniów, przyjaciół, ludzi, z którymi śpiewa przy różnych okazjach, z którymi zna się od dominikanów i w ten sposób powstał nasz świąteczny boysband. 

Osiem męskich głosów zapowiadających nam Dobrą Nowinę. 

MUZYKA:

aranżacja: Mateusz Banasiuk
realizacja nagrania: Damian Posiła
edycja/mix/mastering: Mateusz Banasiuk

tenory: 
Tymoteusz Ekert
Mateusz Banasiuk

barytony: 
Rafał Maciejewski
Jakub Pokorski
Damian Posiła

basy:
Paweł Banach
Szymon Dębkowski
Kamil Gruszczyński
Michał Buczek

—

VIDEO:

zdjęcia: Michał Buczek, Emil Książczak
montaż: Michał Buczek
oświetlenie: Bartłomiej Borcz
produkcja i scenografia: Fundacja Malak

www.fundacjamalak.pl

@Langustanapalmie @FundacjamalakPl 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wyszynki [#974] Urabiać
 - [https://www.youtube.com/watch?v=W9zyWZC_-W0](https://www.youtube.com/watch?v=W9zyWZC_-W0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-22 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Zapraszamy Was do włączenia się w Adwentową Akcję Charytatywną:
→ https://charytatywnie.fundacjamalak.pl/  
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka cegiełka (w wersji papierowej) wyruszy do Was w drogę już 12 listopada.
Ebook - dostępny już dziś.

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

