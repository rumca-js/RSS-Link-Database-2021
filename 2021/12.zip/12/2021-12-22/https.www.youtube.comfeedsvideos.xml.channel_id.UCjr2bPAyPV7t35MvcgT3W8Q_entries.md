# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## The Internet Is Running Out of Water
 - [https://www.youtube.com/watch?v=Xo7V4PPHijs](https://www.youtube.com/watch?v=Xo7V4PPHijs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-12-22 00:00:00+00:00

Data centers are running out of water to cool their servers with. And they keep asking for more.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

In the United States, data centers are consuming 1.7 billion liters of water per day. Compared to the total daily water consumption of 1,218 billion liters, that’s less than 0.14%. Sounds like a negligible amount. Until it’s not. 

Because the reality is, only one third of data center operators are measuring their water consumption. And the water that gets measured is only the one used directly for cooling. But there is a much bigger hidden cost to running a data center than that.

Sources

Data center water consumption
https://www.nature.com/articles/s41545-021-00101-w
https://www.datacenterdynamics.com/en/analysis/data-center-water-usage-remains-hidden/
Water used on cooling vs electricity generation
https://www.datacenterdynamics.com/en/opinions/an-industry-in-transition-1-data-center-water-use/
Arizona, Texas and Google
https://time.com/5814276/google-data-centers-water/ 
Data centers water impact on dry regions
https://www.nbcnews.com/tech/internet/drought-stricken-communities-push-back-against-data-centers-n1271344
Arizona water concerns over data centers
https://www.datacenterdynamics.com/en/news/huge-data-center-moves-forward-in-mesa-despite-arizona-water-concerns/
Data center tax breaks
https://www.datacenterdynamics.com/en/news/arizona-passes-data-center-tax-breaks/
Apple in Arizona
https://appleinsider.com/articles/17/05/10/apple-plans-major-expansions-at-arizona-and-nevada-data-centers
https://www.datacenterdynamics.com/en/news/mesa-council-approves-1bn-google-arizona-data-center-16m-tax-breaks/
Chandler, Arizona
https://azcentral.com/story/news/local/chandler/2021/11/22/chandler-wants-ban-more-data-centers-after-years-complaints/8627569002/
Oregon
https://apnews.com/article/technology-business-the-dalles-oregon-droughts-62b3774442293497ceb2306a606471af 
https://apnews.com/article/technology-business-environment-and-nature-oregon-united-states-2385c62f1a87030d344261ef9c76ccda
South Carolina
https://www.postandcourier.com/news/google-s-controversial-groundwater-withdrawal-sparks-question-of-who-owns/article_bed9179c-1baa-11e7-983e-03d6b33a01e7.html
https://www.datacenterdynamics.com/en/news/after-aquifer-concerns-googles-600m-south-carolina-expansion-finds-new-water-supply/


Lake Mead Depleting
https://eu.usatoday.com/story/news/nation/2021/06/10/lake-mead-water-lowest-hoover-dam-built-colorado-river-shortage/7640437002/

Western U.S. drought
https://www.azcentral.com/story/news/local/arizona-environment/2020/05/06/western-megadrought-centuries-worsened-climate-change-global-warming/3036460001/
Water shortages in US West
https://www.latimes.com/world-nation/story/2021-04-20/us-west-prepares-for-possible-1st-water-shortage-declaration
Colorado River Declining
https://morrisoninstitute.asu.edu/sites/default/files/the_myth_of_safe-yield_0.pdf
https://www.nbcnews.com/news/weather/punishing-heat-west-could-smash-records-experts-sound-alarm-wildfire-n1270696

Growing Internet demands
https://www.cisco.com/c/dam/m/en_us/solutions/service-provider/vni-forecast-highlights/pdf/Middle_East_and_Africa_2021_Forecast_Highlights.pdf
Growth of HyperScale Data Centers
https://www.srgresearch.com/articles/microsoft-amazon-and-google-account-for-over-half-of-todays-600-hyperscale-data-centers

Data center locations (USA)
https://www.datacentermap.com/usa/

Data Center Energy Consumption
https://www.nrdc.org/resources/americas-data-centers-consuming-and-wasting-growing-amounts-energy
https://www.nytimes.com/2011/06/20/business/global/20green.html
https://www.independent.co.uk/climate-change/news/global-warming-data-centres-to-consume-three-times-as-much-energy-in-next-decade-experts-warn-a6830086.html
https://www.wired.com/story/data-centers-not-devouring-planet-electricity-yet/
Efficiency improvement
https://iopscience.iop.org/article/10.1088/1748-9326/abfba1


Microsoft Underwater Data Center
https://news.microsoft.com/innovation-stories/project-natick-underwater-datacenter/
https://www.allaboutcircuits.com/news/microsoft-brings-sea-to-servers-with-two-phase-liquid-immersion-cooling/

Replenishing 120% water consumed by data enters
https://blogs.microsoft.com/blog/2020/09/21/microsoft-will-replenish-more-water-than-it-consumes-by-2030/
https://www.theverge.com/2021/9/10/22665445/google-water-conservation-goal-drought-data-centers

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/

