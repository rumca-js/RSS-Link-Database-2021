# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Kryptowaluta za prywatność? #shorts
 - [https://www.youtube.com/watch?v=tPMGvG0XFw4](https://www.youtube.com/watch?v=tPMGvG0XFw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2021-12-23 00:00:00+00:00

Startup Worldcoin stawia sobie za cel szeroką popularyzację kryptowaluty. Aby to zrobić, chce ją rozdawać za darmo. Każdemu po równo. Jest jeden haczyk - użytkownicy mają być identyfikowani za pomocą skanu tęczówki.

Źródła:
Strona projektu Worldcoin
https://worldcoin.org/

Media na temat:
Vox https://bit.ly/3qj2hIW
Bloomberg https://bloom.bg/3Hbp3JB
CNBC https://cnb.cx/3Jdy6ez
Biometricupdate https://bit.ly/3qjzKD5

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na Instagramie - @mateuszemsi https://www.instagram.com/mateuszemsi/

