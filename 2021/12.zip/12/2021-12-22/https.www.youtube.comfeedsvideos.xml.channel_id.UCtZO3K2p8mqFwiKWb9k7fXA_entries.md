# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## The phone company tier list - 2021!
 - [https://www.youtube.com/watch?v=PcxRZ82NkLg](https://www.youtube.com/watch?v=PcxRZ82NkLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2021-12-23 00:00:00+00:00

The Nebula / CuriosityStream bundle is no longer active. Instead, you can sign up for Nebula directly with my discount now for about $2.5 a month with a yearly plan, which includes Nebula Originals AND the whole Nebula Classes platform, too, including my own class. Sign up here: https://go.nebula.tv/techaltar

Technorama: https://nebula.app/technorama 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

2021 was a busy year for phone companies, so I thought I'd make a tier list to rank them to show how well each one did.

This episode plus bonus footage on Nebula: https://nebula.app/videos/techaltar-the-phone-company-tier-list-2021

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  

Music by Edemski: https://soundcloud.com/edemski

