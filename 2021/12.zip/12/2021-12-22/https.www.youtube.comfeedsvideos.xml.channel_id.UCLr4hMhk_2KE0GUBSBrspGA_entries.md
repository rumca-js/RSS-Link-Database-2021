# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## AirCar -  latający samochód
 - [https://www.youtube.com/watch?v=T_0x_nCO5sg](https://www.youtube.com/watch?v=T_0x_nCO5sg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-12-23 00:00:00+00:00

W napisach jest tłumaczenie części anglojęzycznej filmu na polski :)
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Wstęp
00:15 Powitanie z Turcji
00:32 Prezentacja prototypu
00:42 Droga do AirCara oraz innowacyjnych mydelniczek z Turcji
01:48 W oczekiwaniu na start
02:22 Przewidywane koszty produkcji
03:07 Przygotowań do startu ciąg dalszy
03:27 Jak będzie wyglądać usługa?
03:55 Podobieństwo do drona i dążenie do autonomiczności
05:01 Start AirCara – finał i… wideo prezentujące start AirCara
06:48 Wytłumaczenie kwestii 8 silników w latającym samochodzie
07:11 Latający samochód czy duży dron?
07:57 Kiedy pojawią się latające samochody?
08:17 Podsumowanie
08:42 Pożegnanie

