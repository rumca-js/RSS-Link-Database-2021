# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: LMan feat. Sunflower - Summer Of Love (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=oT3T9dFdxSU](https://www.youtube.com/watch?v=oT3T9dFdxSU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-12-23 00:00:00+00:00

"Summer Of Love" by LMan (Markus Klein )& Sunflower, 3rd at Evoke 2016. Art "Vanishing Point" by Rendall/Mystic, 1st at Assembly 1997.

LMan's upload:
https://www.youtube.com/watch?v=992hvmEMII8

LMan's Studio Mix:
https://www.youtube.com/watch?v=5EGQMTerGGA

LMan on Bandcamp:
https://bandcamp.com/lman

...and on SoundCloud:
https://soundcloud.com/lmanic

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Infinite oversampling with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Standard 4 channel Protracker module

Visit my channel for more Amiga music.

## SID music: Jeroen Tel - Rubicon Load 1 (FPGASID 6581 pseudo-stereo bx_🎧)
 - [https://www.youtube.com/watch?v=t9vlSrw9axA](https://www.youtube.com/watch?v=t9vlSrw9axA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-12-23 00:00:00+00:00

"Rubicon Load 1" (1991) by Jeroen Tel/Maniacs Of Noise. Graphics from the game. The music is not used in the game, this is just something i found from HVSC.

Made using hardware emulated audio via FPGASID (left-right-center pseudo-stereo).

FPGASID:
http://www.fpgasid.de/

