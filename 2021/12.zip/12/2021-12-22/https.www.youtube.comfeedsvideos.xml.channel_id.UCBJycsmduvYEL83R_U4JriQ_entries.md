# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Smartphone Awards 2021!
 - [https://www.youtube.com/watch?v=IDcyXtweHCw](https://www.youtube.com/watch?v=IDcyXtweHCw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-12-22 00:00:00+00:00

The Best of Smartphones in 2021!
🏆 Show more for all links/phones 🏆

Discord: http://discord.gg/MKBHD

0:00 Intro
1:25 Best Big Smartphone
3:30 Best Small Smartphone
6:35 Best Camera Phone
9:24 Best Battery
11:34 The Design Award
14:45 The Value Award
16:26 Bust of the Year
18:25 Most Improved Award
20:55 Phone of the Year

Galaxy Z Fold 3 Review: https://youtu.be/iLLi02P1FN4
Galaxy S21 Ultra Review: https://youtu.be/tn2AgrwXpNQ
ROG Phone 5 Review: https://youtu.be/6pf2KJD5qf0
Samsung Z Flip 3 Review: https://youtu.be/1uu9VWBgcBU
Oppo Find N Review: https://youtu.be/_VAlGmtfDN0
iPhone 13 Review: https://youtu.be/g5ymJNLURRI
iPhone 13 Pro Review: https://youtu.be/TnkdoEZhTbc
Pixel 6 Review: https://youtu.be/9hvjBi4PKWA
Vivo Z70 PRo+: https://youtu.be/n0r2rENgvwY
Legion Gaming Phone Review: https://youtu.be/cW1KJf7JKgI
Surface Duo 2 Review: https://youtu.be/y72bAm4SvkE

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

