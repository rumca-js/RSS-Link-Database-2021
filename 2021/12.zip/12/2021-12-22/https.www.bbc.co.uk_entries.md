## MPs urge changes to 'outdated' gender recognition laws - BBC News
 - [https://www.bbc.co.uk/news/uk-politics-59735218](https://www.bbc.co.uk/news/uk-politics-59735218)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-12-22 08:35:29.336205+00:00

A committee says legally changing gender remains too difficult and risks entrenching stereotypes.

## McDonald's faces a French fries shortage in Japan - BBC News
 - [https://www.bbc.co.uk/news/business-59750613](https://www.bbc.co.uk/news/business-59750613)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-12-22 08:33:03.172804+00:00

The firm's potato deliveries from North America are being delayed by supply chain disruptions.

