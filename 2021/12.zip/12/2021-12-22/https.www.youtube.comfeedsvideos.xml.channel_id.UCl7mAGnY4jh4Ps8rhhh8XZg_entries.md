# Source:Serpentza, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg, language:en-US

## How China's Biggest Spies got CAUGHT in 2021
 - [https://www.youtube.com/watch?v=5yHIDOfd1x8](https://www.youtube.com/watch?v=5yHIDOfd1x8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg
 - date published: 2021-12-23 00:00:00+00:00

2021 has been a busy year for China's Spy agencies but an even bigger year for American Spy Hunters!....

For a deeper dive into China's Propaganda influence and soft power, watch our liveshow ADVPodcasts: https://www.youtube.com/advpodcasts

Support Sasha and I on Patreon: http://www.patreon.com/serpentza
Bitcoin - bc1qxfjp2t6x5dpslv59u0jl89m6k643hcn8h2jsvp
Ethereum - 0x6Da150a2A8529110017Ed4db68B3dF0084900280
Paypal: https://paypal.me/serpentza

Sources:

Charles Lieber:
https://www.justice.gov/usao-ma/pr/harvard-university-professor-convicted-making-false-statements-and-tax-offenses
The former Chair of Harvard University’s Chemistry and Chemical Biology Department was convicted by a federal jury today in connection with lying to federal authorities about his affiliation with People’s Republic of China’s Thousand Talents Program and the Wuhan University of Technology (WUT) in Wuhan, China, as well as failing to report income he received from WUT.

Meng Wanzhou:
https://www.justice.gov/opa/pr/huawei-cfo-wanzhou-meng-admits-misleading-global-financial-institution
The Chief Financial Officer of Huawei Technologies Co. Ltd., Wanzhou Meng, 49, of the People’s Republic of China (PRC), appeared in federal district court in Brooklyn, to enter into a deferred prosecution agreement (DPA) and was arraigned on charges of conspiracy to commit bank fraud and conspiracy to commit wire fraud, bank fraud and wire fraud.

Song Guo Zheng:
https://www.justice.gov/opa/pr/university-researcher-sentenced-prison-lying-grant-applications-develop-scientific-expertise
n Ohio man and rheumatology professor and researcher with strong ties to China was sentenced to 37 months in prison for making false statements to federal authorities as part of an immunology research fraud scheme. As part of his sentence, Zheng was also ordered to pay more than $3.4 million in restitution to the National Institute of Health (NIH) and approximately $413,000 to The Ohio State University.

Dr. Xiaorong You:
https://www.justice.gov/opa/pr/phd-chemist-convicted-conspiracy-steal-trade-secrets-economic-espionage-theft-trade-secrets
A federal jury in Greeneville, Tennessee, convicted a U.S. citizen today of conspiracy to steal trade secrets, economic espionage and wire fraud.

Lin Yang:
https://www.justice.gov/opa/pr/former-university-florida-researcher-indicted-scheme-defraud-national-institutes-health-and
A former University of Florida (UF) professor and researcher and resident of China has been indicted for fraudulently obtaining $1.75 million in federal grant money from the National Institutes of Health (NIH) by concealing support he received from the Chinese government and a company that he founded in China to profit from that research.

Gang Chen:
https://www.justice.gov/usao-ma/pr/mit-professor-indicted-charges-relating-grant-fraud
A professor and researcher at Massachusetts Institute of Technology (MIT) was indicted yesterday by a federal grand jury in connection with failing to disclose contracts, appointments and awards from various entities in the People’s Republic of China (PRC) to the U.S. Department of Energy.

DOCUMENTARY LINKS:
Conquering Southern China:
https://vimeo.com/ondemand/conqueringsouthernchina

Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

Stay Awesome China (my new documentary): https://vimeo.com/ondemand/stayawesomechina

For Motorcycle adventures around the world, and a talk-show on two wheels go to ADVChina every Monday 1pm EST
https://www.youtube.com/advchina

For a realistic perspective on China and world travel from an American father and a Chinese mother with two half-Chinese daughters go to Laowhy86 every Wednesday 1pm EST
https://youtu.be/mErixa-YIJE

For a no-nonsense on the street look at Chinese culture and beyond from China's original YouTuber, join SerpentZA on Friday at 1pm EST
https://www.youtube.com/serpentza

Join me on Facebook: http://www.facebook.com/winstoninchina
Twitter: @serpentza
Instagram: serpent_za

