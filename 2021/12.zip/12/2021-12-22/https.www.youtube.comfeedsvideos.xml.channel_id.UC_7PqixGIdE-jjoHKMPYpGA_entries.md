# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Ten film zamienia mowę w śpiew
 - [https://www.youtube.com/watch?v=SPK4HjKMIZw](https://www.youtube.com/watch?v=SPK4HjKMIZw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-12-23 00:00:00+00:00

👉 https://naukowybelkot.pl
👉 Patronite ► https://patronite.pl/NaukowyBelkot 

👕 Merch ► https://naukowybelkot.pl/sklep-belkotowy
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Z okazji świąt mam dla Was trwały prezent - niepowtarzalną okazję do "popsucia" sobie mózgów.

===
Rozkład jazdy:

0:00 Dla tych, którzy już mają popsute
1:44 Dla tych, co chcą sobie popsuć
6:02 Jak i gdzie?
8:08 Dlaczego?
13:54 Słowo podsumowania

===
Źródła (wybrane):

https://deutsch.ucsd.edu/psychology/pages.php?i=212
A. Tierney i in. - Speech versus Song: Multiple Pitch-Sensitive Areas Revealed by a Naturally Occurring Musical Illusion
M. Hymers i in. - Neural mechanisms underlying song and speech perception can be differentiated using an illusory percept
D. E. Callan i in. - Song and speech: Brain regions involved with perception and covert production
E. Margulis i in. - Pronunciation difficulty, temporal regularity, and the speech-to-song illusion
S. Falk i in. - When speech sounds like music.
K. Jaisin i in. - The Speech-to-Song Illusion Is Reduced in Speakers of Tonal (vs. Non-Tonal) Languages
E. Margulis i in. - Repetition Enhances the Musicality of Randomly Generated Tone Sequences

