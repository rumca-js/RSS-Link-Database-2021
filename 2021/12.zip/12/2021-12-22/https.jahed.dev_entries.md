## Hidden Networks in TP-Link Routers | Jahed Ahmed
 - [https://jahed.dev/2021/12/19/hidden-networks-in-tp-link-routers/](https://jahed.dev/2021/12/19/hidden-networks-in-tp-link-routers/)
 - RSS feed: https://jahed.dev
 - date published: 2021-12-22 08:25:07.609612+00:00

I was debugging my WiFi settings this week when I noticed something strange. WiFi Analyzer was showing two hidden networks coming from my router, one for each frequency: 2.4GHz and 5GHz. Networks whic

