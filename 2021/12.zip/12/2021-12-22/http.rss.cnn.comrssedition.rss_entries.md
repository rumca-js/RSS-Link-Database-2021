# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Michael Flynn loses legal challenge to House January 6 probe, one day after filing it
 - [https://www.cnn.com/2021/12/22/politics/michael-flynn-january-6-lawsuit/index.html](https://www.cnn.com/2021/12/22/politics/michael-flynn-january-6-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 23:21:58+00:00

Michael Flynn has swiftly lost his bid in court to block a possible House Select Committee subpoena for his phone records and to hold off demands he speak to the committee investigating January 6.

## World's first SMS sold as NFT for $150,000 at Paris auction house
 - [https://www.cnn.com/style/article/nft-paris-worlds-first-sms-sold-intl-scli/index.html](https://www.cnn.com/style/article/nft-paris-worlds-first-sms-sold-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 23:17:40+00:00

The world's first SMS has been sold as a non-fungible token (NFT) for $149,729 (132,680 euros) at auction in Paris, according to the auctioneer Aguttes.

## Early Omicron studies suggest reduced risk of hospitalization, but rapid spread could still overwhelm hospitals
 - [https://www.cnn.com/collections/intl-covid-1221/](https://www.cnn.com/collections/intl-covid-1221/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 22:40:29+00:00



## Two major US cities could see rare white Christmas as massive snowstorm expected
 - [https://www.cnn.com/2021/12/22/weather/atmospheric-river-california-snow-travel-forecast/index.html](https://www.cnn.com/2021/12/22/weather/atmospheric-river-california-snow-travel-forecast/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 22:35:06+00:00

Santa is bringing the gift of another atmospheric river event to the parched US West Coast this week, with heavy snow and rain and windy conditions predicted in spots from Canada to Mexico.

## Biden and Trump praise each other in rare moment
 - [https://www.cnn.com/videos/media/2021/12/22/biden-trump-booster-praise-fox-vpx.cnn](https://www.cnn.com/videos/media/2021/12/22/biden-trump-booster-praise-fox-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 22:13:11+00:00

Donald Trump reacts to President Biden offering rare praise of the former president during his Covid speech, marking a rare moment where the two men have found common ground since Inauguration Day.

## Russia aims for January talks with NATO, US on security guarantees
 - [https://www.cnn.com/2021/12/22/europe/moscow-nato-us-talks-intl/index.html](https://www.cnn.com/2021/12/22/europe/moscow-nato-us-talks-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 21:29:08+00:00

Russia hopes to hold bilateral talks with NATO and the United States in January over security guarantees it is seeking from both, state media RIA Novosti reported Wednesday, citing Russian Foreign Minister Sergei Lavrov.

## Boat accident kills 83, forces police chief to swim 12 hours to safety after helicopter crash
 - [https://www.cnn.com/2021/12/22/africa/madagascar-boat-accident-kills-64-intl/index.html](https://www.cnn.com/2021/12/22/africa/madagascar-boat-accident-kills-64-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 21:04:30+00:00

At least 64 people have died in a boat accident off the coast of northeastern Madagascar and searches were underway for 24 missing passengers, the maritime agency said on Wednesday.

## 2 dead after small plane and paraglider collide
 - [https://www.cnn.com/2021/12/22/us/texas-small-plane-paraglider-collision-deaths/index.html](https://www.cnn.com/2021/12/22/us/texas-small-plane-paraglider-collision-deaths/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 21:00:26+00:00

Two people died after a small plane collided with a paraglider outside of Houston on Tuesday, the Fort Bend County constable told CNN on Wednesday.

## Why air travel regulators are so afraid of 5G
 - [https://www.cnn.com/2021/12/22/tech/faa-5g-explained/index.html](https://www.cnn.com/2021/12/22/tech/faa-5g-explained/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 20:48:49+00:00

From mask requirements to waived change fees, the pandemic has dramatically changed what it's like to fly. But beginning early next year, even more changes could be coming to air travel — ones that have nothing to do with the coronavirus.

## Policing hate: In a big game like the Champions League final, abuse on social media channels can skyrocket by 800%
 - [https://www.cnn.com/2021/12/22/football/chelsea-say-no-to-hate-intl-spt/index.html](https://www.cnn.com/2021/12/22/football/chelsea-say-no-to-hate-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 19:37:42+00:00

The fight against discrimination in football is being fought on many fronts -- by individuals, teams and governing bodies. Premier League club Chelsea is no different.

## How can the US and Russia retreat from the brink?
 - [https://www.cnn.com/videos/tv/2021/12/22/amanpour-putin-nato-ukraine-invasion-us-alliance.cnn](https://www.cnn.com/videos/tv/2021/12/22/amanpour-putin-nato-ukraine-invasion-us-alliance.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 19:09:59+00:00

Mary Sarotte, whose new book "Not One Inch" dives into post-Cold War dynamics, says the situation is tense but avoiding a potential clash over Ukraine is possible.

## Video shows rare deep-sea encounter with a giant phantom jellyfish
 - [https://www.cnn.com/videos/us/2021/12/22/phantom-jelly-scn-travel-orig-jc.cnn](https://www.cnn.com/videos/us/2021/12/22/phantom-jelly-scn-travel-orig-jc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 19:09:43+00:00

The Monterey Bay Aquarium Research Institute captured rare footage of a giant phantom jelly. Watch this majestic deep-sea encounter.

## Bette Midler apologizes for calling West Virginians 'poor, illiterate, strung out'
 - [https://www.cnn.com/2021/12/22/entertainment/better-midler-west-virginia-apology/index.html](https://www.cnn.com/2021/12/22/entertainment/better-midler-west-virginia-apology/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 18:44:32+00:00

Bette Midler has apologized West Virginians after a tweet she posted regarding Senator Joe Manchin.

## France's $19 billion weapons deal is sweet revenge
 - [https://www.cnn.com/2021/12/22/opinions/france-uae-us-arms-deal-andelman/index.html](https://www.cnn.com/2021/12/22/opinions/france-uae-us-arms-deal-andelman/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 18:11:34+00:00

With Iran on the cusp of building a deliverable nuclear weapon and with a growing perception that the United States may no longer be the staunch and reliable ally that many, especially in Europe and the Middle East, had long welcomed, the beginning of a realignment of traditional allies is beginning to take shape.

## McDonald's limits french fry sales in Japan because of potato shortage
 - [https://www.cnn.com/2021/12/22/business-food/mcdonalds-japan-french-fries-potato-shortage-intl-scli/index.html](https://www.cnn.com/2021/12/22/business-food/mcdonalds-japan-french-fries-potato-shortage-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 17:04:21+00:00

McDonald's Japan is temporarily limiting the sale of french fries due to delays in shipments of potatoes to the country, the company said in a press release Tuesday.

## Watch the moment Tom Holland slings a web with young boy
 - [https://www.cnn.com/videos/business/2021/12/22/tom-holland-bridger-walkers-spider-man-jg-orig.cnn](https://www.cnn.com/videos/business/2021/12/22/tom-holland-bridger-walkers-spider-man-jg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 16:57:28+00:00

Tom Holland, who plays Spider-Man, made good on his promise to Bridger Walkers, a young boy who's received widespread praise for saving his sister from a dog attack. The two performed stunts and acted out Spidey moves on set.

## Bill Gates delivers Omicron warning
 - [https://www.cnn.com/2021/12/22/business/bill-gates-omicron/index.html](https://www.cnn.com/2021/12/22/business/bill-gates-omicron/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 16:38:20+00:00

In a series of tweets late Tuesday, Bill Gates says he plans to cancel most of his holiday plans and warned that that the United States "could be entering the worst part of the pandemic."

## A skullcap dating back more than 100,000 years could be from a new type of human
 - [https://www.cnn.com/2021/12/22/world/year-of-ancient-human-discoveries-scn/index.html](https://www.cnn.com/2021/12/22/world/year-of-ancient-human-discoveries-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 16:20:17+00:00

The human story -- where we come from and how we evolved -- got a new chapter in 2021.

## Woman walks over 1,400 miles to honor her late mother and raise awareness of pulmonary fibrosis
 - [https://www.cnn.com/2021/12/22/us/iyw-wellness-woman-walks-to-raise-funds-for-lung-disease/index.html](https://www.cnn.com/2021/12/22/us/iyw-wellness-woman-walks-to-raise-funds-for-lung-disease/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 16:17:50+00:00

Along a windy stretch of Texas highway, a woman walks with purpose. Mary Hesch is on a 1,439-mile pilgrimage from central Wisconsin to the Texas coast -- all of it on foot -- to honor her mother and raise awareness of the lung disease that took her life.

## World's oldest family tree reconstructed from Stone Age tomb
 - [https://www.cnn.com/2021/12/22/uk/worlds-oldest-family-tree-scli-scn-intl-gbr/index.html](https://www.cnn.com/2021/12/22/uk/worlds-oldest-family-tree-scli-scn-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 16:08:58+00:00

The oldest family tree in the world has been reconstructed through the analysis of ancient DNA taken from a Stone Age tomb in Britain, according to a new study published Wednesday.

## The nominees for quirkiest stories of 2021 are...
 - [https://www.cnn.com/videos/us/2021/12/17/quirky-yearender-moos-vpx.cnn](https://www.cnn.com/videos/us/2021/12/17/quirky-yearender-moos-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 15:49:58+00:00

The nominees for quirkiest stories of 2021 are ... CNN's Jeanne Moos has the envelope. From the guy who swallowed an airpod to the teen smacked by a seagull while on an amusement park ride we look back at some of the videos that won over the internet in 2021.

## Comet Leonard has been dazzling the night sky in a pre-Christmas show
 - [https://www.cnn.com/2021/12/22/world/christmas-comet-leonard-december-scn/index.html](https://www.cnn.com/2021/12/22/world/christmas-comet-leonard-december-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 15:08:47+00:00

Comet Leonard, which last passed by Earth 80,000 years ago, has been dazzling the night sky before Christmas, and there's only a few days left to see the celestial object before it disappears forever.

## Chrishell Stause and Jason Oppenheim of 'Selling Sunset' have split
 - [https://www.cnn.com/2021/12/22/entertainment/chrishell-stause-jason-oppenheim-split/index.html](https://www.cnn.com/2021/12/22/entertainment/chrishell-stause-jason-oppenheim-split/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 14:38:10+00:00

Chrishell Stause and Jason Oppenheim are opening up about their breakup.

## 'One of the few thing we agree on': President Biden offers rare praise of Trump
 - [https://www.cnn.com/videos/politics/2021/12/22/biden-trump-booster-agree-sot-vpx-newday.cnn](https://www.cnn.com/videos/politics/2021/12/22/biden-trump-booster-agree-sot-vpx-newday.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 13:49:18+00:00

President Joe Biden gave credit to the Trump administration for the development of the Covid-19 vaccine and praised his predecessor, Donald Trump, for getting a booster shot.

## Buy now, pay later is a huge hit with shoppers. Just how dangerous is it?
 - [https://www.cnn.com/2021/12/22/business/buy-now-pay-later-christmas/index.html](https://www.cnn.com/2021/12/22/business/buy-now-pay-later-christmas/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 13:26:32+00:00

Lissette Monzon still feels a little guilty about a "crazy" purchase she made three years ago.

## OnlyFans founder Tim Stokely steps down as CEO
 - [https://www.cnn.com/2021/12/22/tech/onlyfans-ceo-stokely-steps-down/index.html](https://www.cnn.com/2021/12/22/tech/onlyfans-ceo-stokely-steps-down/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 13:20:22+00:00

OnlyFans is getting a new CEO after a tumultuous year.

## Jennifer King makes NFL history as first Black female position coach
 - [https://www.cnn.com/2021/12/22/sport/jennifer-king-nfl-black-female-coach-spt-intl/index.html](https://www.cnn.com/2021/12/22/sport/jennifer-king-nfl-black-female-coach-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 13:16:50+00:00

Jennifer King stepped in as the running backs coach of the Washington Football Team on Tuesday, making her the first Black woman to be a lead position coach in an NFL game.

## This is your brain on inflation
 - [https://www.cnn.com/2021/12/22/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/12/22/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 12:40:49+00:00

Snarled supply chains, rising energy costs and skyrocketing commodity prices have caused inflation to spike. But what you think about prices will help determine whether inflation stays elevated or quickly drops.

## UN receives 13 allegations of rape by security forces during Sudan protests
 - [https://www.cnn.com/2021/12/22/africa/un-rape-allegations-sudan-intl/index.html](https://www.cnn.com/2021/12/22/africa/un-rape-allegations-sudan-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 12:24:16+00:00

The United Nations Human Rights Office said on Tuesday that it had received 13 allegations of rape and gang rape by security forces during protests in Sudan on Sunday, while opposition medics reported a second person killed.

## 'Makes me physically ill': SE Cupp reacts to Trump's January 6 anniversary plan
 - [https://www.cnn.com/videos/politics/2021/12/22/donald-trump-january-6-news-conference-se-cupp-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/12/22/donald-trump-january-6-news-conference-se-cupp-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 11:56:26+00:00

CNN political commentator SE Cupp reacts to former President Donald Trump's announcement that he will hold a press conference at Mar-a-Lago on the first anniversary of the attack on the US Capitol.

## Police bring in watchdog over their handling of alleged Downing Street Christmas party
 - [https://www.cnn.com/2021/12/22/uk/london-police-downing-street-christmas-party-intl-gbr/index.html](https://www.cnn.com/2021/12/22/uk/london-police-downing-street-christmas-party-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 11:49:40+00:00

• Photo appears to show Britain's Boris Johnson drinking wine with staff during coronavirus lockdown

## The gigantic luxury hotel in the middle of nowhere
 - [https://www.cnn.com/travel/article/qatar-hilton-salwa-resort/index.html](https://www.cnn.com/travel/article/qatar-hilton-salwa-resort/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 11:28:00+00:00

Nothing much lies on Qatar's border with Saudi Arabia. A few sunbaked outposts and miles and miles of vast, empty desert in all directions.

## Shelf-climbing robots are helping warehouses meet the holiday rush
 - [https://www.cnn.com/2021/12/22/europe/exotec-robots-warehouse-spc-intl/index.html](https://www.cnn.com/2021/12/22/europe/exotec-robots-warehouse-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 11:19:10+00:00

In a warehouse south of Paris, days before Christmas, Santa has a different kind of helper. Instead of Rudolph, Dasher and Dancer, there is Fylu, Lane and Ruqi -- to name just a few.

## Putin stands his ground over Ukraine
 - [https://www.cnn.com/2021/12/21/europe/russia-europe-us-nato-ukraine-intl/index.html](https://www.cnn.com/2021/12/21/europe/russia-europe-us-nato-ukraine-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 10:30:16+00:00

Russian President Vladimir Putin has said his country has "every right" to "react harshly to unfriendly steps" as the US and NATO continue to pressure Moscow over its aggression towards Ukraine.

## Nicholas Latifi speaks out after death threats following Abu Dhabi crash
 - [https://www.cnn.com/2021/12/22/motorsport/nicholas-latifi-death-threats-spt-intl/index.html](https://www.cnn.com/2021/12/22/motorsport/nicholas-latifi-death-threats-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 10:00:46+00:00

Canadian Nicholas Latifi spoke out on Tuesday after receiving death threats and online abuse over a crash at the Dec. 12 Abu Dhabi Grand Prix that led to Red Bull's Max Verstappen winning the Formula One title and Lewis Hamilton missing out.

## Senate hopefuls use frustration with Manchin to woo Democratic voters
 - [https://www.cnn.com/2021/12/22/politics/senate-democratic-candidates-manchin-2022/index.html](https://www.cnn.com/2021/12/22/politics/senate-democratic-candidates-manchin-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 10:00:45+00:00

To Democrats eager to become senators in 2023, the Senate is plainly broken and West Virginia Sen. Joe Manchin's power over President Joe Biden's Build Back Better plan is proof.

## 40 years of the official White House Christmas ornament
 - [https://www.cnn.com/style/article/white-house-christmas-ornaments/index.html](https://www.cnn.com/style/article/white-house-christmas-ornaments/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 09:45:24+00:00

In the 40-year history of the official White House Christmas ornament, produced annually by the White House Historical Association (WHHA), this year's design is among the most conventionally festive.

## More tinsel and less tension: How to get the best out of the holiday season
 - [https://www.cnn.com/2021/12/22/health/holiday-joy-wellness/index.html](https://www.cnn.com/2021/12/22/health/holiday-joy-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 09:38:46+00:00



## From floods and wildfires to inaction and urgency: These are the top climate and weather stories of 2021
 - [https://www.cnn.com/2021/12/22/us/top-climate-weather-stories-of-2021/index.html](https://www.cnn.com/2021/12/22/us/top-climate-weather-stories-of-2021/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 08:52:53+00:00

The climate crisis took a catastrophic toll across the globe in 2021. From the Arctic to Louisiana and to China's Henan province, signs that climate change is already altering our weather were everywhere.

## China's economic growth will slow sharply in 2022, World Bank says
 - [https://www.cnn.com/2021/12/22/business/world-bank-cuts-china-forecast-intl-hnk/index.html](https://www.cnn.com/2021/12/22/business/world-bank-cuts-china-forecast-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 08:47:45+00:00

The World Bank has cut its forecasts for China's economic growth this year and next, as the world's second largest economy faces mounting headwinds from the new Omicron variant to a severe property sector downturn.

## What can we expect from US-China relations in 2022?
 - [https://www.cnn.com/videos/world/2021/12/22/china-power-xi-jinping-2021-lookback-culver-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/12/22/china-power-xi-jinping-2021-lookback-culver-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 07:54:41+00:00

2021 saw the elevation of Chinese President Xi Jinping as the country grows stronger and richer but moves further away from western democracies in ideology. CNN's David Culver takes a tour around the city of Beijing and reflects on what 2022 may have in store for the country's relations with the US.

## Alleged 'koala massacre' prompts hundreds of animal cruelty charges
 - [https://www.cnn.com/2021/12/22/australia/australia-koala-killing-intl-hnk/index.html](https://www.cnn.com/2021/12/22/australia/australia-koala-killing-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 05:48:24+00:00

Australian authorities on Wednesday charged a landowner and two companies with more than 250 counts of animal cruelty over the deaths of dozens of koalas during a clearance operation last year.

## Librarians fight back against push to ban books from schools
 - [https://www.cnn.com/videos/us/2021/12/22/texas-schools-librarians-books-ban-ebof-mcmorris-santoro-pkg-vpx.cnn](https://www.cnn.com/videos/us/2021/12/22/texas-schools-librarians-books-ban-ebof-mcmorris-santoro-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 03:33:11+00:00

Librarians focused on making their collections more reflective of the increasingly diverse community in their schools are now under threat by parents who deem their book selections offensive. CNN's Evan McMorris-Santoro has the story.

## Thailand drops quarantine-free travel
 - [https://www.cnn.com/travel/article/thailand-travel-quarantine-exemption-suspended-intl-hnk/index.html](https://www.cnn.com/travel/article/thailand-travel-quarantine-exemption-suspended-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 02:53:13+00:00

Amid the new Omicron variant of the coronavirus, Thailand has announced some changes to its inbound quarantine-free travel status for some visitors.

## Fox News responds to Fauci's call to fire network host
 - [https://www.cnn.com/videos/media/2021/12/22/fauci-threats-ac360-kaye-dnt-vpx.cnn](https://www.cnn.com/videos/media/2021/12/22/fauci-threats-ac360-kaye-dnt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 02:37:10+00:00

Dr. Anthony Fauci is calling on Fox News to fire host Jesse Watters after he told a group of conservatives to "ambush" Fauci with questions and "go in for kill shot" - rhetorical language that the nation's top infectious disease doctor and President Biden's chief medical adviser believes goes too far. Fox News has responded to Fauci, who is no stranger to attacks. CNN's Randi Kaye reports.

## Malaysia warns of more floods as Prime Minister admits lapse in rescue efforts
 - [https://www.cnn.com/2021/12/21/asia/malaysia-floods-response-intl-hnk/index.html](https://www.cnn.com/2021/12/21/asia/malaysia-floods-response-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 01:47:30+00:00

Malaysia on Tuesday warned of more storms and heavy rainfall in the coming days as Prime Minister Ismail Sabri Yaakob admitted to weaknesses in the government's response to flooding that has led to more than a dozen deaths and the displacement of over 60,000 people.

## Cruelty debate over zoo exhibition highlights complexities of elephant tourism in Thailand
 - [https://www.cnn.com/travel/article/elephant-tourism-thailand-cmd/index.html](https://www.cnn.com/travel/article/elephant-tourism-thailand-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-22 00:53:10+00:00

An Asian elephant struts into the pool and dips its head beneath the surface, using the tip of its trunk like a snorkel.

