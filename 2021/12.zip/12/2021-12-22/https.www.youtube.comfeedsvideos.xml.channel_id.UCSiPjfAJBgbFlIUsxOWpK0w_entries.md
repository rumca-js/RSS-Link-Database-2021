# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Sam’s Idea (Official Music Video) // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=7jd_fGE9XtQ](https://www.youtube.com/watch?v=7jd_fGE9XtQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-12-23 00:00:00+00:00

Here’s one of the instrumental cuts off our album “Invisible People”!!! It’s called “Sam’s Idea,” because Sam Wilkes came up with the original bass riff. Then Jack took it and completely messed with it and made it virtually unrecognizable (even to Sam). But it was too late to change the name. It was, and will forever be known as “Sam’s Idea.”

Save this song on Spotify: https://open.spotify.com/track/2svSa3xBy6h3Liwl6t8BHf?si=600f53f2647a4c87
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Keys: Jack Conte
Bass: Sam Wilkes
Guitar: Ryan Lerman
Drums: Louis Cole

AUDIO CREDITS
Engineer: Chris Sorem
Mixing/Mastering: Jack Conte
Producer: Jack Conte

VIDEO CREDITS
Performed by Deepraj Singh, with Emma Richardson and Rachel Zegler
Written, Directed & Produced by Sammy Paul
Executive Producers: Dom Fera & Nazim Isma Benjamin
DP/Colorist: Jamie MacLeod
Sound Design: Dan Pugsley
Video Editor: Sammy Paul
Focus Puller: Oliver Pearson Pajitra
Production Assistants: Myles Wheeler & Emma Simpson
Special Thanks: Ryan Concannon, Jacob Trueman, Charis Entwistle, Edith Windle, Yasmine Paul Rath, Sean Rath

