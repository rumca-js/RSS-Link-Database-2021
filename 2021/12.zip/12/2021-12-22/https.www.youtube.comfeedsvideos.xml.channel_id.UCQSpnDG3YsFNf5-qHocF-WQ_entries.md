# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## My Anti-Spammer App Has Been UPGRADED (You Can Help Fight Too)
 - [https://www.youtube.com/watch?v=2tRppXW_aKo](https://www.youtube.com/watch?v=2tRppXW_aKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-12-22 00:00:00+00:00

The App ⇨ https://github.com/ThioJoe/YouTube-Spammer-Purge
API Setup Tutorial Video ⇨ https://www.youtube.com/watch?v=c6ebWvay8dE
▼ Time Stamps: ▼
0:00 - What's This Even About 🤔
1:51 - How YOU Can Help Report Spammers
2:33 - Moderator Mode
3:45 - Spread The Word
4:11 - Download & First-Time Setup
5:24 - Demo: Scanning Options Overview
6:21 - Demo: The Config File
8:05 - Demo: Other Options
9:25  - Demo: Scanning Recent Videos
10:01 - Demo: Filter Modes Overview
11:25 - Demo: Scanning With Auto-Smart Mode
12:36 - Demo: Scan Results
14:06 - Demo: Reporting the Spammers
15:07 - Demo: Recovery Mode
16:22 - Demo: Sensitive Smart Mode
17:01 - Demo: Exclude Feature
17:27 - Demo: Removal Options
18:15 - Demo: The Other Filtering Modes
19:36 - Demo: ASCII and NUKE Mode

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

