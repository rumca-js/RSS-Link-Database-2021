# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Charles Oliveira's Shocking Submission of Dustin Poirier
 - [https://www.youtube.com/watch?v=F8qt84kp6Rw](https://www.youtube.com/watch?v=F8qt84kp6Rw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-23 00:00:00+00:00

Taken from JRE #1751 w/Brian Simpson:
https://open.spotify.com/episode/4BsHnn5yaOS3WnTy5QCYJP?si=a80403a433834bd7

## Why Quitting Cigarettes is So Diifficult
 - [https://www.youtube.com/watch?v=H1AOXBv9voc](https://www.youtube.com/watch?v=H1AOXBv9voc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-23 00:00:00+00:00

Taken from JRE #1751 w/Brian Simpson:
https://open.spotify.com/episode/4BsHnn5yaOS3WnTy5QCYJP?si=a80403a433834bd7

## Joe Reflects on Conor McGregor's Jose Aldo KO, Reacts to His Muscle Gain
 - [https://www.youtube.com/watch?v=buZLpot1PkY](https://www.youtube.com/watch?v=buZLpot1PkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-22 00:00:00+00:00

Taken from JRE #1750 w/Ari Shaffir and Tony Hinchcliffe:
https://open.spotify.com/episode/2VqQTEv1sfbDIk3b54eLXy?si=bf098e593e8b4e12

## Nancy Pelosi's Strange Response to Insider Trading Question
 - [https://www.youtube.com/watch?v=j8TRVp-7l3Q](https://www.youtube.com/watch?v=j8TRVp-7l3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-22 00:00:00+00:00

Taken from JRE #1750 w/Ari Shaffir and Tony Hinchcliffe:
https://open.spotify.com/episode/2VqQTEv1sfbDIk3b54eLXy?si=bf098e593e8b4e12

