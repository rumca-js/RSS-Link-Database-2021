# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## 3 Minute Reviews' Favorite Games of 2021
 - [https://www.youtube.com/watch?v=uPEhR-7ATFI](https://www.youtube.com/watch?v=uPEhR-7ATFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-31 00:00:00+00:00

KC, Jesse, Amy, Will and Elise are here to provide you with their favorite games they reviewed on 3 Minute Reviews in 2021.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## F.I.S.T. - Forged in Shadow Torch is A Surprisingly Good Metroidvania
 - [https://www.youtube.com/watch?v=lJxgvJ7g-vA](https://www.youtube.com/watch?v=lJxgvJ7g-vA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-31 00:00:00+00:00

Sponsored by F.I.S.T. - Forged in Shadow Torch.

Marty takes a look at F.I.S.T. - Forged in Shadow Torch in this sponsored video, which actually happens to be a very a good metroidvania. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#Sponsored

## A Minimum Amount of Flair | Adventure is Nigh - The Jade Homunculus | EP 7
 - [https://www.youtube.com/watch?v=qnNg8G9RkwE](https://www.youtube.com/watch?v=qnNg8G9RkwE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-30 00:00:00+00:00

Welcome to Adventure Is Nigh: The Jade Homunculus episode 7, “A Minimum of Flair.” Join Jack Packard as Dungeon Master for an epic Dungeons & Dragons (D&D) campaign featuring Yahtzee Croshaw as Mortimer, KC Nwosu as Sigmar, Amy Campbell as Dabarella, and Jesse Galena as Grinderbin.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Dark Souls II - The Final Escapist Stream of 2021 | Today We Play with Jack and Nick
 - [https://www.youtube.com/watch?v=C6x7HW9S8Rs](https://www.youtube.com/watch?v=C6x7HW9S8Rs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-30 00:00:00+00:00

It's the final Escapist stream of 2021, so Jack and Nick will be playing Dark Souls II to send us out for the year.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5...​

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Why I Never Did A Zero Punctuation on Undertale | Extra Punctuation
 - [https://www.youtube.com/watch?v=La-qxB3HnaM](https://www.youtube.com/watch?v=La-qxB3HnaM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-12-30 00:00:00+00:00

This week on Extra Punctuation, Yahtzee discusses his thoughts on Undertale and why he never did a full Zero Punctuation episode on it.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ExtraPunctuation

