## Nancy Pelosi buys call options for Google, Disney stocks
 - [https://nypost.com/2021/12/30/nancy-pelosi-buys-call-options-for-google-disney-stocks/](https://nypost.com/2021/12/30/nancy-pelosi-buys-call-options-for-google-disney-stocks/)
 - RSS feed: https://nypost.com
 - date published: 2021-12-30 20:15:36+00:00

Nancy Pelosi buys call options for Google, Disney stocks

