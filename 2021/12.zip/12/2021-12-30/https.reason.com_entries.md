## Facebook Said My Article Was 'False Information.' Now the Fact-Checkers Admit They Were Wrong.
 - [https://reason.com/2021/12/29/facebook-masks-false-information-science-feedback-wrong-covid/](https://reason.com/2021/12/29/facebook-masks-false-information-science-feedback-wrong-covid/)
 - RSS feed: https://reason.com
 - date published: 2021-12-30 09:02:20.918611+00:00

While this is a problem, it's not one that scrapping Section 230 would solve.

