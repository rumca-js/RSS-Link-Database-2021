# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Alexa's Been NOT NICE - WAN Show December 31, 2021
 - [https://www.youtube.com/watch?v=U1rSxOSnMXY](https://www.youtube.com/watch?v=U1rSxOSnMXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-12-31 00:00:00+00:00

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Start your build today at https://www.buildredux.com/linus

Save 10% at Ridge Wallet with offer code WAN at https://www.ridge.com/WAN

Check out the WAN Show & Podcast Gear: https://lmg.gg/podcastgear
Check out the They're Just Movies Podcast: https://lmg.gg/tjmpodcast

Podcast Download: TBD

Timestamps (Courtesy of NoKi1119)
0:00 - Chapters
1:01 - Intro
1:26 - Anthony returns from flight
2:10 - Topic #1 - Alexa's "penny outlet" challenge
4:10 - Amazon's response, Linus & Luke past stories
12:31 - Topic #2 - Asus starts recalling Z690 Maximus Hero boards
15:48 - LTT's video on best used CPU to buy
18:07 - Merch Messages #1
19:56 - Topic #3 - TikTok is the world's most popular site
21:42 - Luke's & Linus's thoughts on TikTok
23:09 - Linus planning to collaborate with Kallmekris
26:58 - Merch Messages #2
46:33 - Sponsor - Squarespace
47:27 - Sponsor - BuildRedux
47:58 - Sponsor - Ridge Wallet
48:44 - Topic #4 - Asus's DDR5 to DDR4 memory convertor.
51:57 - Topic #5 - Samsung's PM1743 PCIe 5.0 SSD on 12th gen Intel
53:55 - XPG's USB-C mouse with an integrated 1 TB SSD
56:42 - Topic #6 - Samsung's leaked Galaxy S22 Ultra
1:04:23 - Merch Messages #3
1:30:10 - Outro
1:31:18 - LTTStore magnetic screwdriver

## I'm taking this into my own hands... - YouTube Dislike Button
 - [https://www.youtube.com/watch?v=Nz9b0oJw69I](https://www.youtube.com/watch?v=Nz9b0oJw69I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-12-30 00:00:00+00:00

Go to https://nordpass.com/linus and use code LINUS to get 70% off a 2-year NordPass Premium plan plus 1 free month!

Get 10% off all Jackery products with code LinusTechTips at https://www.jackery.com?aff=27

YouTube removed the Dislike counter from beside the thumbs-down button...but there's a way we can bring it back using a Chrome Extension and a little stick-to-itiveness

Buy a Gaming PC
On Amazon: https://geni.us/44nsLm
On Best Buy: https://geni.us/s5dHuw
On Newegg: https://geni.us/z3IE

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1400028-im-taking-this-into-my-own-hands/

►GET MERCH: lttstore.com
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 What YouTube did
1:58 What we can do about it
2:40 How well does it work?
4:30 What about new videos?
5:40 How YouTubers can help
6:20 Looking at the Numbers
7:40 What about Mobile?
9:15 Am I doing the right thing?
10:50 Why is YouTube doing this?
13:13 outro

