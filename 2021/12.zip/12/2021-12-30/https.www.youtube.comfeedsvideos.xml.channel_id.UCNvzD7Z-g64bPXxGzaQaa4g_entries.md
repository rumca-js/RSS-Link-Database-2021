# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## BIGGEST GAMING STORIES OF 2021
 - [https://www.youtube.com/watch?v=bC1PYxi7BOE](https://www.youtube.com/watch?v=bC1PYxi7BOE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-31 00:00:00+00:00

2021 gave us plenty of big news headlines in the video game news world. Here are some of the highlights from the year.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 BEST GRAPHICS of 2021 [4K]
 - [https://www.youtube.com/watch?v=yFyuoK-sZcY](https://www.youtube.com/watch?v=yFyuoK-sZcY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-30 00:00:00+00:00

Gameplay and fun are always the most important factors, but today we wanted to celebrate great graphics in 2021 games for PC, PS5, PS4, Xbox Series X/S/One, and beyond.
Subscribe for more: 
https://www.youtube.com/gameranxTV?sub_confirmation=1

10 Hitman 3 

Platform : PC PS4 PS5 Xbox One XSX|S Stadia Switch 

Release Date : 20 January 2021 



9 Kena: Bridge of Spirits 

Platform : PC PS4 PS5 

Release Date : September 21, 2021 



8 Far Cry 6

Platform : PC PS4 PS5 Xbox One XSX|S Stadia Luna 

Release Date : October 7, 2021 



7 Guardians of the galaxy

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release date : October 26, 2021



6 The Ascent

Platform : PC Xbox One XSX|S

Release date : 29 July 2021 



5 Bright Memory Infinite

Platform : PC PS5 XSX|S 

Release Date : November 11, 2021



4 Resident Evil Village 

Platform : PC PS4 PS5 Xbox One XSX|S Stadia 

Release Date : May 7, 2021 



3 Forza Horizon 5

Platform : PC Xbox One XSX|S

Release date : 9 November 2021



2 Ratchet and Clank: Rift Apart

Platform : PS5

Release Date : June 11, 2021 



1 RIDE 4 

Platform : PS5 XSX|S 

Release Date : January 21, 2021

