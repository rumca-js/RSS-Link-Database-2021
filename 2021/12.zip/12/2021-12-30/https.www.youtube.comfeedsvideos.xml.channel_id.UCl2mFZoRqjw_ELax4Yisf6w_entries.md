# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## CDC discourages FULLY VACCINATED people from cruises: WHAT?
 - [https://www.youtube.com/watch?v=HdvzvxQJhuo](https://www.youtube.com/watch?v=HdvzvxQJhuo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-31 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.bloomberg.com/news/articles/2021-12-30/cdc-says-avoid-cruise-travel-regardless-of-vaccination-status-kxt8rvd8
🔵 https://youtu.be/2uyFMWST6eM
🔵 https://broadwaynews.com/2021/12/16/hamilton-cancels-additional-broadway-performances-due-to-covid-19/

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## Tesla recalls over 300,000 cars because Apple engineering
 - [https://www.youtube.com/watch?v=z0qAhDQU74k](https://www.youtube.com/watch?v=z0qAhDQU74k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-31 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.nbcnews.com/business/consumer/tesla-recalls-nearly-half-million-cars-over-rear-camera-safety-n1286781
🔵 https://youtu.be/hiT81o-afu4
 
👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## drunk beyond wasted new year's eve stream this is a bad idea but let's do it anyway
 - [https://www.youtube.com/watch?v=vL2zHiLNLcA](https://www.youtube.com/watch?v=vL2zHiLNLcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-31 00:00:00+00:00

https://tinyurl.com/rossmatrix
Post a message on screen http://bit.ly/postamessage Or else I will read it in the normal chat if it is not swamped. I am sorry if I miss your message, I do my best to read as much stuff as I can that is somewhat interesting even if it is a normal unpaid message, but the chat sometimes moves way too fast for me to get things.

## happy holidays everyone ☺️
 - [https://www.youtube.com/watch?v=OgP3CJazD-g](https://www.youtube.com/watch?v=OgP3CJazD-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-31 00:00:00+00:00

https://tinyurl.com/rossmatrix

## CNBC covers right to repair with a video whose title is quality
 - [https://www.youtube.com/watch?v=ZeuK9ZBTQ7g](https://www.youtube.com/watch?v=ZeuK9ZBTQ7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-30 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.youtube.com/watch?v=xTCvux33sB0
https://www.youtube.com/watch?v=If0KfqDdfuY
https://www.ftc.gov/enforcement/statutes/magnuson-moss-warranty-federal-trade-commission-improvements-act
https://www.npr.org/sections/thetwo-way/2018/04/11/601582169/warranty-void-if-removed-as-it-turns-out-feds-say-those-warnings-are-illegal

