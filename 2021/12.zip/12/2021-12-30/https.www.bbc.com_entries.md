## 2021: The year of the mask - BBC Future
 - [https://www.bbc.com/future/article/20211210-the-ways-masks-defined-our-year](https://www.bbc.com/future/article/20211210-the-ways-masks-defined-our-year)
 - RSS feed: https://www.bbc.com
 - date published: 2021-12-30 10:19:26.443396+00:00

As the world entered its second full year of the coronavirus pandemic, masks became a ubiquitous sight, from sports stadiums to the highest political offices.

