# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Quiz of the week: Vinyl sales, Biden pranked and a dog's dinner
 - [https://www.bbc.co.uk/news/world-59819384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-59819384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 16:50:56+00:00

How closely have you been paying attention to what's been going on during the past seven days?

## Average house price hits record high of £255,000
 - [https://www.bbc.co.uk/news/business-59826341?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59826341?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 12:54:27+00:00

Typical prices leap almost £24,000 since January, making the strongest year since 2006, Nationwide says.

## Liverpool bomber made device with murderous intent, coroner says
 - [https://www.bbc.co.uk/news/uk-england-merseyside-59828610?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-59828610?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 12:44:08+00:00

Emad Al Swealmeen was killed when his homemade bomb went off outside Liverpool Women's Hospital.

## 'I genuinely thought we had a good chance' - Anderson on England's Ashes defeat
 - [https://www.bbc.co.uk/sport/cricket/59828791?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59828791?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 12:40:11+00:00

England pace bowler James Anderson says he believed the side "genuinely had a good chance" of beating Australia in the Ashes.

## Santander: Bank hands out £130m in Christmas blunder
 - [https://www.bbc.co.uk/news/business-59826345?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59826345?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 12:16:38+00:00

The error meant around 75,000 people woke up on Christmas morning to a surprise payment from Santander.

## Putin and Lukashenko team up for ice hockey match
 - [https://www.bbc.co.uk/news/world-europe-59828830?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59828830?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 11:29:06+00:00

The Russian and Belarusian leaders both made the scoreboard in a game following talks between the countries.

## South Africa collapse as India win first Test
 - [https://www.bbc.co.uk/sport/cricket/59827128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59827128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 11:18:47+00:00

India wrap up a comfortable 113-run win over South Africa just after lunch on day five of the first Test.

## What are the new Covid rules for the UK?
 - [https://www.bbc.co.uk/news/explainers-52530518?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-52530518?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 11:02:45+00:00

Covid rules have been strengthened in response to the Omicron variant.

## China bans footballers from getting tattoos
 - [https://www.bbc.co.uk/news/world-asia-china-59827047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-59827047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 10:40:13+00:00

Top players who already have body art are told to remove it, as a good example for society.

## MMA fights we want to see in 2022
 - [https://www.bbc.co.uk/sport/mixed-martial-arts/59756889?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/mixed-martial-arts/59756889?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 10:40:04+00:00

BBC Sport writers pick the MMA fights they want to see in 2022 - including Israel Adesanya v Kamaru Usman and Kayla Harrison v Cris Cyborg.

## Media coverage disrespects Africa Cup of Nations - Wright
 - [https://www.bbc.co.uk/sport/football/59825904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59825904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 10:27:57+00:00

The Africa Cup of Nations is being "disrespected" by some negative media coverage, says former England striker Ian Wright.

## Chelsea announce annual losses of £145m
 - [https://www.bbc.co.uk/sport/football/59827141?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59827141?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 10:20:25+00:00

Chelsea announce losses after tax of £145.6m for the year to 30 June 2021, despite their turnover increasing to £416.8m.

## Ashraf Ghani: Ex-Afghan president describes moment he fled the Taliban
 - [https://www.bbc.co.uk/news/world-asia-59807737?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59807737?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 10:02:29+00:00

Speaking to the BBC, Ashraf Ghani tackles criticism he left Afghanistan as the Taliban closed in.

## Ghislaine Maxwell guilty of helping Jeffrey Epstein abuse girls
 - [https://www.bbc.co.uk/news/world-us-canada-59824150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59824150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 09:12:26+00:00

A jury in New York convicts her of recruiting and trafficking teenagers in a "pyramid of abuse".

## Covid: Nightingale surge hubs to be set up in eight hospitals, NHS England says
 - [https://www.bbc.co.uk/news/uk-59823652?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59823652?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 08:40:46+00:00

It comes as the UK saw record daily case numbers of 183,000 on Wednesday.

## Ghislaine Maxwell: What the trial means for Prince Andrew
 - [https://www.bbc.co.uk/news/world-us-canada-59780323?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59780323?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 07:48:32+00:00

Ghislaine Maxwell has been convicted of grooming teenagers. What does this mean for her former friend?

## Covid: Surge hospital hubs in England and warning of 'tsunami' of global cases
 - [https://www.bbc.co.uk/news/uk-59825004?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59825004?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 07:47:04+00:00

Five things you need to know about the coronavirus pandemic this Thursday morning.

## The Papers: 'Guilty Ghislaine' and 'testing in tatters'
 - [https://www.bbc.co.uk/news/blogs-the-papers-59823692?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59823692?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 06:34:59+00:00

Thursday's front pages report Ghislaine Maxwell's conviction on sex trafficking charges in New York.

## MND: Northampton mum determined to beat the odds
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-59741897?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-59741897?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 02:05:09+00:00

Emma Moss is determined to beat the odds, having been diagnosed with a fatal disease three years ago.

## Digging for Britain: Secrets of Rutland Roman villa mosaic revealed
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-59668728?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-59668728?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 02:04:35+00:00

The stunning mosaic gives us clues to Britain's place in the wider Roman world, experts say.

## Brexit: How has pet travel to EU countries been affected?
 - [https://www.bbc.co.uk/news/59644699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59644699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 02:03:40+00:00

Changes to rules on travel to the EU with pets have led to higher bills and some problems for owners.

## The drama of Peru's Covid orphans
 - [https://www.bbc.co.uk/news/world-latin-america-59732686?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-59732686?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 01:57:21+00:00

A tragic effect of the pandemic is that thousands of children are now without a parent or guardian.

## What does future warfare look like? It's here already
 - [https://www.bbc.co.uk/news/world-59755100?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-59755100?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 01:55:44+00:00

There's one area where the West is falling dangerously behind Russia and China - hypersonic missiles.

## Your pictures of the year 2021
 - [https://www.bbc.co.uk/news/in-pictures-59653482?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-59653482?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 01:27:50+00:00

A selection of striking images from our readers around the world.

## Hong Kong: The last day of the Stand News pro-democracy website
 - [https://www.bbc.co.uk/news/world-asia-59815856?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59815856?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 01:19:14+00:00

From raids and arrests to the announcement of its closure, this is how its last day unfolded.

## Why I switched to eating grandma's food
 - [https://www.bbc.co.uk/news/world-asia-india-59650408?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-59650408?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 00:47:39+00:00

Many "forgotten foods" are returning to the farms and fields - and on our plates too.

## Princess Diana: Files reveal plea for Elton John to perform at funeral
 - [https://www.bbc.co.uk/news/uk-59822189?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59822189?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 00:24:04+00:00

A top clergyman said a performance by Sir Elton would be "generous" for millions who felt bereaved.

## The secret lives of Ghislaine Maxwell and Jeffrey Epstein
 - [https://www.bbc.co.uk/news/world-us-canada-59737125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59737125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 00:05:37+00:00

Never-before-seen photos released during her trial shed new light on their private lives.

## What went wrong with vaccinating the world?
 - [https://www.bbc.co.uk/news/health-59755743?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-59755743?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 00:04:37+00:00

Why developed countries have a surplus of vaccines while low-income ones are still struggling to battle Covid.

## Recycling the 'unrecyclable': How are hair salons going green?
 - [https://www.bbc.co.uk/news/science-environment-59755741?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59755741?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 00:03:46+00:00

Fry Taylor founded the Green Salon Collective which is encouraging sustainable working practices in the hairdressing industry.

## COP 26: The teenagers suing 33 countries
 - [https://www.bbc.co.uk/news/science-environment-59776108?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59776108?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 00:03:22+00:00

To ensure the promises of COP26 are kept, young campaigners are putting their faith in the courts.

## Syntropic agriculture: A new way of farming in dry climates?
 - [https://www.bbc.co.uk/news/world-latin-america-59775136?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-59775136?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-30 00:02:39+00:00

Ernst Gotsch's method of agriculture increases, rather than decreases, biodiversity and wildlife.

