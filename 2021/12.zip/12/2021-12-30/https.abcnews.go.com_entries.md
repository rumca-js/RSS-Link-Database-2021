## New York governor declares racism 'public health emergency' amid new anti-discrimination legislation  - ABC News
 - [https://abcnews.go.com/US/york-governor-declares-racism-public-health-emergency-amid/story?id=82002884](https://abcnews.go.com/US/york-governor-declares-racism-public-health-emergency-amid/story?id=82002884)
 - RSS feed: https://abcnews.go.com
 - date published: 2021-12-30 20:07:17+00:00

New York governor declares racism 'public health emergency' amid new anti-discrimination legislation  - ABC News

