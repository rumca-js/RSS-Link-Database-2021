# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Najciekawsze odkrycia A.D. 2021
 - [https://www.youtube.com/watch?v=1uGV4YWM_-c](https://www.youtube.com/watch?v=1uGV4YWM_-c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-12-30 00:00:00+00:00

👉 Nasz serwis popularnonaukowy ► https://naukowybelkot.pl 
👉 Patronite ► https://patronite.pl/NaukowyBelkot 

📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

To nie pierwszy raz - wiecie co będzie w filmie :)

===
Rozkład jazdy:

0:00 Wstęp
1:27 Wyróżnienie/a
4:22 Miejsce 7.
10:16 Miejsce 6.
12:30 Miejsce 5.
13:55 Miejsce 4.
17:05 Miejsce 3.
19:50 Miejsce 2.
21:59 Miejsce 1.

===
IPCC:
https://naukaoklimacie.pl/aktualnosci/bezdyskusyjne-nowy-raport-ipcc-o-spowodowanym-przez-czlowieka-ociepleniu-klimatu-488/
https://www.youtube.com/watch?v=qXqDj-5klOM

===
Moi goście:

Krzysztof 
🤜 https://www.youtube.com/c/KrzysztofMMaj
🤜 https://twitter.com/krzysztofmmaj
🤜 https://scholar.google.com/citations?user=CgG-eqMAAAAJ&hl=pl&oi=sra

Fanggotten 
🤜 https://www.youtube.com/c/Fanggotten0
🤜 https://www.instagram.com/fanggotteno/
🤜 https://www.facebook.com/Fanggotten666/
🤜 http://pagan-shop.pl/

Kasia B.
🤜 https://www.youtube.com/channel/UCG0NdlO9xadSCCtkcAlyWxw
🤜 https://www.facebook.com/groups/chlebtuba
🤜 https://www.patronite.pl/kasiababis
🤜 https://instagram.com/kasiababiscomics

Hed
🤜 https://www.youtube.com/c/hedasw
🤜 https://www.instagram.com/hedgamer/
🤜 https://twitter.com/hedgamer

Kasia W.
🤜 https://www.youtube.com/c/Mamaistetoskop
🤜 https://www.instagram.com/mama.i.stetoskop/
🤜 https://www.facebook.com/mama.i.stetoskop
🤜 https://mamaistetoskop.pl/

===
Źródła (wybrane):

*jak zapewne widzieliście ten odcinek był nieco luźniejszy, więc i w źródłach pojawiają się odnośniki bardziej popularnonaukowo traktujące o opisywanych wydarzeniach

https://www.sciencenews.org/article/xenotransplantation-pig-human-kidney-transplant
https://www.hhmi.org/news/brain-computer-interface-turns-mental-handwriting-into-text-on-screen
https://www.nature.com/articles/d41587-021-00026-2
https://www.bbc.co.uk/news/health-56858158
https://arstechnica.com/science/2021/03/nitrate-breathing-microorganism-offers-glimpse-into-evolutions-past/
https://physicsworld.com/a/spacecraft-in-a-warp-bubble-could-travel-faster-than-light-claims-physicist/
https://www.japantimes.co.jp/news/2021/12/12/national/science-health/aging-vaccine/
https://newatlas.com/science/microbiome-brain-aging-gut-bacteria-neuroscience/

