# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Premiere: Good Morning Bedlam - 'Lulu' (Official Music Video)
 - [https://www.youtube.com/watch?v=3p23kCx4q9U](https://www.youtube.com/watch?v=3p23kCx4q9U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-30 00:00:00+00:00

The Current and Radio Heartland are proud to debut the official music video for “Lulu” by Minneapolis folk trio Good Morning Bedlam. The song is the title track for Good Morning Bedlam's forthcoming album, releasing February 4, 2022.

The video was directed by Nathaniel Nelson of the Treedome group in Rochester, Minn. 

Good Morning Bedlam perform at Thesis Beer Project in Rochester, Minn., on Friday, Jan. 31, and will have their album-release show at the Amsterdam Bar & Hall in St. Paul, Minn., on Friday, Feb. 4.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

