# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## VR is getting ABSOLUTELY INSANE - Quest 2 STEALS CHRISTMAS
 - [https://www.youtube.com/watch?v=Zur_9zkXP2c](https://www.youtube.com/watch?v=Zur_9zkXP2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-12-30 00:00:00+00:00

Hello and Welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news. This week we talk all about the QUEST EFFECT. The Meta Quest 2 sold like crazy this christmas and according to many, the "metaverse" won christmas. Apple is ramping up their VR and AR operations, a boy gets rushed to the hospital from a reaction to his VR headset- this is a fun week of VR news and I hope everyone had a great holiday! 

My links: 
Discord.gg/Thrill
Twitch.tv/Thrilluwu
Twitter.com/Thrilluwu

TIMESTAMPS:
00:00 INTRO
00:50 HALF DIVE
02:28 APPLE
04:34 QUEST EFFECT
08:27 MEME BREAK
08:45 PROJECT CAMBRIA
10:11 QUEST ALLERGIC REACTION
11:21 TACTGLOVE
12:13 SANSAR 
13:12 OUTRO

Sources:
https://uploadvr.com/sansar-offline-without-explanation/
https://www.techradar.com/news/2021-sucked-so-im-spending-2022-in-vr
https://www.theverge.com/2021/12/28/22857159/quest-store-new-year-sale-2022
https://finance.yahoo.com/news/apple-might-be-the-only-company-that-can-take-vr-and-ar-mainstream-170246228.html
https://uploadvr.com/tactsuit-vr-gloves-bhaptics-announced/
https://www.linkedin.com/posts/chadwickmturner_augmentedreality-virtualreality-future-activity-6880650527571636224-bRt7/
https://www.roadtovr.com/sword-art-online-vr-halfdive-kickstarter/
https://www.kickstarter.com/projects/diver-x/halfdive-worlds-first-vr-system-optimized-for-use-in-bed
https://www.roadtovr.com/report-apple-hires-metas-xr-head-public-relations/
https://www.cnbc.com/2021/12/27/metas-oculus-virtual-reality-headsets-were-a-popular-holiday-gift.html
https://www.euronews.com/next/2021/12/28/the-metaverse-wins-christmas-as-meta-s-oculus-vr-app-is-the-most-downloaded-on-apple-store
https://content.techgig.com/tim-cook-reveals-plans-of-leaving-apple-here-are-the-details/articleshow/82033297.cms

