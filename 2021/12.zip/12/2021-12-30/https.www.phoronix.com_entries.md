## GCC 12 Adds Support For Using The Mold Linker - Phoronix
 - [https://www.phoronix.com/scan.php?page=news_item&px=GCC-12-Mold-Linker](https://www.phoronix.com/scan.php?page=news_item&px=GCC-12-Mold-Linker)
 - RSS feed: https://www.phoronix.com
 - date published: 2021-12-30 14:56:31.310956+00:00



