## Social Media Faces Privacy ‘Paradox’ in Spotting Underage Users
 - [https://news.bloomberglaw.com/privacy-and-data-security/social-media-faces-privacy-paradox-in-spotting-underage-users](https://news.bloomberglaw.com/privacy-and-data-security/social-media-faces-privacy-paradox-in-spotting-underage-users)
 - RSS feed: https://news.bloomberglaw.com
 - date published: 2021-12-30 14:29:45.698572+00:00

Social media platforms under pressure to shield children from harmful content face a dilemma: figuring out how old their users are without violating their privacy.

