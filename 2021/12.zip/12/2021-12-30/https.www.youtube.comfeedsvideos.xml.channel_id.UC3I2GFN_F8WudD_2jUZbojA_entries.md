# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Jessy Lanza - Anyone Around & Lick In Heaven (Live on KEXP)
 - [https://www.youtube.com/watch?v=vQ7Tti_JkoY](https://www.youtube.com/watch?v=vQ7Tti_JkoY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-31 00:00:00+00:00

http://KEXP.ORG presents Jessy Lanza performing “Anyone Around" and "Lick In Heaven” live in the KEXP studio. Recorded December 3, 2021.

Host: Larry Mizell, Jr.
Audio Engineers: John Rau & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann & Scott Holpainen
Editor: Jim Beckmann

https://jessylanza.com
http://kexp.org

## Jessy Lanza - Badly & Seven 55 (Live on KEXP)
 - [https://www.youtube.com/watch?v=aeIwJkK4oQ4](https://www.youtube.com/watch?v=aeIwJkK4oQ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-31 00:00:00+00:00

http://KEXP.ORG presents Jessy Lanza performing “Badly" and "Seven 55” live in the KEXP studio. Recorded December 3, 2021.

Host: Larry Mizell, Jr.
Audio Engineers: John Rau & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann & Scott Holpainen
Editor: Jim Beckmann

https://jessylanza.com
http://kexp.org

## Jessy Lanza - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=UpLbvSB8GkY](https://www.youtube.com/watch?v=UpLbvSB8GkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-31 00:00:00+00:00

http://KEXP.ORG presents Jessy Lanza performing live in the KEXP studio. Recorded December 3, 2021.

Songs:
Anyone Around
Lick In Heaven
Badly
Seven 55

Host: Larry Mizell, Jr.
Audio Engineers: John Rau & Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann & Scott Holpainen
Editor: Jim Beckmann

https://jessylanza.com
http://kexp.org

