# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Big Pharma's Role in the Opioid Crisis
 - [https://www.youtube.com/watch?v=yWrfEclkC_k](https://www.youtube.com/watch?v=yWrfEclkC_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-30 00:00:00+00:00

Taken from JRE #1756 w/John Abramson:
https://open.spotify.com/episode/64ZsPU8e2CHvWQM9lqnLEY?si=e5285dfd27d04e89

## The Troubling Story of Vioxx
 - [https://www.youtube.com/watch?v=wn1UwPSzTV4](https://www.youtube.com/watch?v=wn1UwPSzTV4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-30 00:00:00+00:00

Taken from JRE #1756 w/John Abramson:
https://open.spotify.com/episode/64ZsPU8e2CHvWQM9lqnLEY?si=e5285dfd27d04e89

