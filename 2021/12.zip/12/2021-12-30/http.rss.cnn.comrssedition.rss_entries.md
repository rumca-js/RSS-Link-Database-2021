# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## US Omicron surge 'unlike anything we've ever seen'
 - [https://www.cnn.com/collections/intl-covid-in-us-1230/](https://www.cnn.com/collections/intl-covid-in-us-1230/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 23:01:29+00:00



## Travelers infected one another across hallway in Covid quarantine facility, New Zealand research shows
 - [https://www.cnn.com/2021/12/30/health/new-zealand-covid-facility-transmission/index.html](https://www.cnn.com/2021/12/30/health/new-zealand-covid-facility-transmission/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 22:51:15+00:00

A traveler isolated for Covid-19 at a quarantine facility in New Zealand managed to infect three others across a hallway, researchers reported Thursday.

## Record Covid-19 case numbers are starting to overwhelm emergency rooms across the country
 - [https://www.cnn.com/2021/12/30/health/us-coronavirus-thursday/index.html](https://www.cnn.com/2021/12/30/health/us-coronavirus-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 22:50:47+00:00

• Mass gatherings in India spark Omicron fears

## Cities that are canceling their big New Year's Eve events -- and those still going forward
 - [https://www.cnn.com/travel/article/new-years-eve-2021-celebrations-cancellations-pandemic/index.html](https://www.cnn.com/travel/article/new-years-eve-2021-celebrations-cancellations-pandemic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 22:12:43+00:00

For awhile there, it appeared we might be able to ring in New Year's Eve in major cities across the planet with something resembling the huge celebrations of yore.

## New Zealand journalist is first person with Māori facial markings to present primetime news
 - [https://www.cnn.com/style/article/new-zealand-maori-news-journalist-tattoo-scli-intl/index.html](https://www.cnn.com/style/article/new-zealand-maori-news-journalist-tattoo-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 21:28:37+00:00

A Māori journalist has made history in New Zealand by becoming the first person with traditional facial markings to host a primetime news program on national television.

## Trump allies throw Hail Mary to stop Jan. 6 committee's subpoenas
 - [https://www.cnn.com/2021/12/30/politics/january-6-committee-subpoena-lawsuits-longshot/index.html](https://www.cnn.com/2021/12/30/politics/january-6-committee-subpoena-lawsuits-longshot/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 21:26:26+00:00

The flurry of lawsuits filed in recent weeks trying to stop the House January 6 committee's subpoenas are revealing, in many ways, the opposite: That the House has been largely successful at sweeping up documents for the probe and interviewing dozens of major witnesses.

## Skier gets completely buried in snow after backflip attempt goes wrong
 - [https://www.cnn.com/videos/us/2021/12/30/skier-buried-in-snow-after-flip-mxp-vpx.hln](https://www.cnn.com/videos/us/2021/12/30/skier-buried-in-snow-after-flip-mxp-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 20:53:11+00:00

A California skier had to be rescued by his friends after being trapped in deep snow upon landing a backflip.

## UK bank mistakenly pays out $175 million on Christmas Day
 - [https://www.cnn.com/2021/12/30/business/santander-bank-payment-error-scli-intl-gbr/index.html](https://www.cnn.com/2021/12/30/business/santander-bank-payment-error-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 20:44:55+00:00

UK bank Santander got into the Christmas spirit this year by paying out a total of £130 million ($175 million) to customers by mistake on December 25.

## ICU doctor warns of 'compassion fatigue' toward unvaccinated
 - [https://www.cnn.com/videos/health/2021/12/30/dr-daniela-lamas-omicron-compassion-fatigue-nr-vpx.cnn](https://www.cnn.com/videos/health/2021/12/30/dr-daniela-lamas-omicron-compassion-fatigue-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 20:02:29+00:00

In a recently published New York Times op-ed piece, Dr. Daniela Lamas warned of "compassion fatigue" amongst hospital healthcare workers toward unvaccinated patients.

## At least four anti-coup protesters shot dead in Sudan as security forces raid broadcasters
 - [https://www.cnn.com/2021/12/30/africa/sudan-anti-military-protests-intl/index.html](https://www.cnn.com/2021/12/30/africa/sudan-anti-military-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 19:36:48+00:00

At least four people were shot dead by Sudanese security forces during anti-coup demonstrations near the capital Khartoum on Thursday, the civilian-allied Sudanese Central Doctors Committee (SCDC) said.

## High-end Champagne shortage could ruin your New Year's Eve
 - [https://www.cnn.com/2021/12/30/business/champagne-shortage/index.html](https://www.cnn.com/2021/12/30/business/champagne-shortage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 18:51:45+00:00

Enough already! Can we call it a wrap on 2021?

## Tesla recalls 475,000 vehicles due to camera and front trunk issues
 - [https://www.cnn.com/2021/12/30/tech/tesla-recall-camera-frunk/index.html](https://www.cnn.com/2021/12/30/tech/tesla-recall-camera-frunk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 18:38:13+00:00

Over 475,000 Tesla (TSLA) cars have been recalled due to technical defects that may increase the risk of accidents. Two separate recalls are in place, one regarding the rear-view camera in the Tesla Model 3 and the other involves the frunk, or front trunk, latches in the Model S.

## Ryan Reynolds responds to Betty White saying he can't get over her
 - [https://www.cnn.com/2021/12/30/entertainment/ryan-reynolds-betty-white/index.html](https://www.cnn.com/2021/12/30/entertainment/ryan-reynolds-betty-white/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 18:24:23+00:00

Betty White says Ryan Reynolds just can't quit her.

## Dwayne 'The Rock' Johnson calls out Vin Diesel's 'manipulation'
 - [https://www.cnn.com/2021/12/29/entertainment/dwayne-the-rock-johnson-interview/index.html](https://www.cnn.com/2021/12/29/entertainment/dwayne-the-rock-johnson-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 18:22:49+00:00

Dwayne "The Rock" Johnson has plenty of reasons to toast 2021 with some Teremana.

## Business manager to Kardashians and other stars found dead inside her car
 - [https://www.cnn.com/2021/12/30/entertainment/angela-kukawski-kardashians-dead/index.html](https://www.cnn.com/2021/12/30/entertainment/angela-kukawski-kardashians-dead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 17:56:03+00:00

A business manager who had worked with several high-profile celebrities, including the Kardashian-Jenner family, was found dead this week, according to the Los Angeles Police Department's Valley Bureau Homicide division.

## Webb telescope will spend '29 days on the edge' as it comes to life in space
 - [https://www.cnn.com/2021/12/30/world/james-webb-space-telescope-updates-scn/index.html](https://www.cnn.com/2021/12/30/world/james-webb-space-telescope-updates-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 17:55:16+00:00

Heading to space was just the beginning for the James Webb Space Telescope.

## 'Harry Potter: Return to Hogwarts' takes a magic-filled trip down memory lane
 - [https://www.cnn.com/2021/12/30/entertainment/harry-potter-return-to-hogwarts-review/index.html](https://www.cnn.com/2021/12/30/entertainment/harry-potter-return-to-hogwarts-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 17:44:48+00:00

HBO Max has developed a fondness for reunions after that awkward "Friends" gathering and "The West Wing" voting special. Yet "Harry Potter 20th Anniversary: Return to Hogwarts" strikes just the right balance, looking back at the cinematic franchise with warmth and humor, while delicately capturing the impact on kids raised on a movie set over a formative decade.

## Ice Cube reveals Chris Tucker turned down $12M for role in 'Friday' sequel
 - [https://www.cnn.com/2021/12/30/entertainment/ice-cube-chris-tucker-friday-sequel/index.html](https://www.cnn.com/2021/12/30/entertainment/ice-cube-chris-tucker-friday-sequel/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 17:35:52+00:00

Ice Cube is explaining why his "Friday" costar Chris Tucker reportedly turned down a hefty paycheck to star in the movie's sequel.

## Mourners pay tribute to Archbishop Desmond Tutu as his body lies in state
 - [https://www.cnn.com/2021/12/30/africa/mourners-tribute-archbishop-desmond-tutu-intl/index.html](https://www.cnn.com/2021/12/30/africa/mourners-tribute-archbishop-desmond-tutu-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 17:07:51+00:00

Mourners flocked to St. George's Cathedral in Cape Town on Thursday to pay their respects to anti-apartheid hero Archbishop Desmond Tutu as he lay in state in a simple pine coffin.

## Calling Trump a terror movement leader is 'too kind', says analyst
 - [https://www.cnn.com/videos/politics/2021/12/30/january-6-donald-trump-terror-movement-kayyem-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/12/30/january-6-donald-trump-terror-movement-kayyem-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 16:18:25+00:00

Juliette Kayyem, Havard professor and National Security Analyst, joins New Day to discuss the first anniversary of the January 6 attack on the US Capitol and former President Donald Trump's role in it.

## Statue of soccer superstar Cristiano Ronaldo is dividing opinion in India
 - [https://www.cnn.com/2021/12/30/football/cristiano-ronaldo-statue-india-goa-spt-intl/index.html](https://www.cnn.com/2021/12/30/football/cristiano-ronaldo-statue-india-goa-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 16:03:33+00:00

Not for the first time a statue of soccer superstar Cristiano Ronaldo is getting people talking -- this time in India.

## Musfur sinkhole: The chasm in Qatar's desert
 - [https://www.cnn.com/travel/article/musfur-sinkhole-qatar/index.html](https://www.cnn.com/travel/article/musfur-sinkhole-qatar/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 14:59:10+00:00

Right in the middle of the Qatari peninsula, a large chasm suddenly yawns open from the rocky desert, plummeting some 100 meters down into the earth.

## Biden administration asks Supreme Court to let it end Trump-era 'Remain in Mexico' immigration policy
 - [https://www.cnn.com/2021/12/30/politics/remain-in-mexico-policy-supreme-court-biden-administration/index.html](https://www.cnn.com/2021/12/30/politics/remain-in-mexico-policy-supreme-court-biden-administration/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 13:51:22+00:00

The Biden administration on Wednesday asked the Supreme Court for permission to end the Trump-era "remain in Mexico" program, which requires non-Mexican migrants to stay in Mexico until their US immigration court dates.

## Former Afghan President was given 'no more than two minutes' to get ready to flee Kabul
 - [https://www.cnn.com/2021/12/30/asia/ashraf-ghani-flee-afghanistan-intl/index.html](https://www.cnn.com/2021/12/30/asia/ashraf-ghani-flee-afghanistan-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 13:38:59+00:00

The former President of Afghanistan Ashraf Ghani said he was given "no more than two minutes" to get ready to flee Kabul in August, during the Taliban's rapid takeover of the country's capital.

## Year in review: Recapping the royal family's tumultuous year
 - [https://www.cnn.com/videos/world/2021/12/30/royal-family-year-in-review-2021-max-foster-pkg-vpx.cnn](https://www.cnn.com/videos/world/2021/12/30/royal-family-year-in-review-2021-max-foster-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 13:18:26+00:00

From Prince Philip's death to the Duke and Duchess of Sussex's explosive interview with Oprah, CNN's Max Foster recaps a tumultuous year for the royal family.

## China bans footballers from getting tattoos
 - [https://www.cnn.com/2021/12/30/football/china-footballers-tattoo-ban-spt-intl/index.html](https://www.cnn.com/2021/12/30/football/china-footballers-tattoo-ban-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 12:06:37+00:00

China has banned footballers from getting tattoos and ordered those with existing ones to remove or cover them up to set a "good example for society," according to a directive issued by the General Administration of Sport of China (GAS).

## The European art and architecture that inspired iconic Disney films
 - [https://www.cnn.com/style/article/inspiring-walt-disney-metropolitan-museum-european-decorative-arts/index.html](https://www.cnn.com/style/article/inspiring-walt-disney-metropolitan-museum-european-decorative-arts/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 11:52:29+00:00

Each year, over one million people visit Neuschwanstein, a 19th-century castle in the Bavarian alps, famous for its Romanesque Revival style and Gothic details, including vertical limestone towers and turrets topped with deep blue pointed roofs.

## Plea for Elton John to play at Princess Diana funeral revealed in UK government files
 - [https://www.cnn.com/2021/12/30/uk/elton-john-princess-diana-funeral-scli-intl-gbr/index.html](https://www.cnn.com/2021/12/30/uk/elton-john-princess-diana-funeral-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 11:46:03+00:00

The Dean of Westminster personally appealed to Buckingham Palace to allow British star Elton John to sing a version of his hit song "Candle In The Wind" at the funeral of Princess Diana, according to newly released government files.

## Inside the upcoming Orient Express La Dolce Vita train
 - [https://www.cnn.com/travel/article/luxury-orient-express-train-to-debut-in-italy-in-2023/index.html](https://www.cnn.com/travel/article/luxury-orient-express-train-to-debut-in-italy-in-2023/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 10:26:34+00:00

The launch of the new Orient Express La Dolce Vita might still be a while off, but it seems as though the highly anticipated service will definitely be worth the wait.

## Man blew up Tesla over $22.6K repair bill
 - [https://www.cnn.com/videos/us/2021/12/30/tesla-exploded-dynamite-repair-costs-22k-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2021/12/30/tesla-exploded-dynamite-repair-costs-22k-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 10:20:43+00:00

What would make a driver mad enough to dynamite his own Tesla? How about a $22,600 repair bill. CNN's Jeanne Moos has the explosive report.

## Unvaccinated NBA star says he 'respected' being benched
 - [https://www.cnn.com/2021/12/30/sport/brooklyn-nets-kyrie-irving-speaks-to-media-spt-intl/index.html](https://www.cnn.com/2021/12/30/sport/brooklyn-nets-kyrie-irving-speaks-to-media-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 10:12:29+00:00

Kyrie Irving says he's "Incredibly grateful just to be back in the building" as he spoke to the media for the first time since it was announced he would rejoin the Brooklyn Nets after a mix of Covid-19 issues and injuries depleted the NBA team's roster, resulting in three postponements of their games.

## Lebanon's soul has been eviscerated. Not even children want to play
 - [https://www.cnn.com/2021/12/30/middleeast/lebanon-crisis-children-cmd-intl/index.html](https://www.cnn.com/2021/12/30/middleeast/lebanon-crisis-children-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 09:21:00+00:00

I'm crouched down in front of a 10-year-old boy sitting hunched over himself in the Beirut office of my charity INARA, the International Network for Aid, Relief and Assistance. His dark brown eyes, fringed with impossibly long eyelashes, peer over his facemask.

## Hong Kong authorities insist newsroom raids have 'nothing to do with media work'
 - [https://www.cnn.com/2021/12/30/media/hong-kong-stand-news-arrest-us-response-intl-hnk/index.html](https://www.cnn.com/2021/12/30/media/hong-kong-stand-news-arrest-us-response-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 09:16:23+00:00

Hong Kong authorities are defending the arrests of seven people linked to a pro-democracy publication in the face of growing international condemnation, with the city's leader insisting the police raids had "nothing to do with journalistic or media work."

## Hear the stories behind 4 iconic 2021 pictures
 - [https://www.cnn.com/videos/world/2021/12/29/as-equals-year-end-gallery-nat-pkg-tgb-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/12/29/as-equals-year-end-gallery-nat-pkg-tgb-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 08:34:17+00:00

Four female photographers share the behind-the-scene stories of the iconic moments they captured in 2021.

## The Korean War is not over, but it might soon be
 - [https://www.cnn.com/2021/12/30/asia/korean-war-armistice-peace-explained-intl-hnk-ml/index.html](https://www.cnn.com/2021/12/30/asia/korean-war-armistice-peace-explained-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 07:28:13+00:00

Is the Korean War about to come to an end?

## Kyrie Irving explains why he 'respected' team's decision to bench him
 - [https://www.cnn.com/videos/us/2021/12/30/kyrie-irving-vaccination-interview-mh-orig.cnn](https://www.cnn.com/videos/us/2021/12/30/kyrie-irving-vaccination-interview-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 03:16:12+00:00

Brooklyn Nets star Kyrie Irving spoke to the press about being barred from playing in NBA games because of his vaccination status.

## Maxwell faces up to 65 years in prison
 - [https://www.cnn.com/2021/12/29/us/ghislaine-maxwell-trial-wednesday/index.html](https://www.cnn.com/2021/12/29/us/ghislaine-maxwell-trial-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 00:36:15+00:00

A jury has reached a verdict in the sex trafficking trial of Ghislaine Maxwell, the former girlfriend and close associate of the late sex offender Jeffrey Epstein.

## 'Caspian Sea Monster' rises from the grave
 - [https://www.cnn.com/travel/article/caspian-sea-monster-ekranoplan/index.html](https://www.cnn.com/travel/article/caspian-sea-monster-ekranoplan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-30 00:13:29+00:00

Beached for over a year on the western shores of the Caspian Sea, it looks like a colossal aquatic beast -- something bizarre perhaps more at home beneath the water than in the air. It certainly doesn't look like something that could ever fly.

