# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Tacobell’s Canon | Scary Goldings ft. John Scofield, MonoNeon & Louis Cole
 - [https://www.youtube.com/watch?v=s-XRjZr96RM](https://www.youtube.com/watch?v=s-XRjZr96RM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-12-30 00:00:00+00:00

Get the Scary Goldings IV vinyl: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: https://tinyurl.com/yxk72gn4

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://instagram.com/scarygoldings
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

Tacobell's Canon is an original song by Scary Goldings featuring John Scofield.

MUSICIAN CREDITS
Guitar: John Scofield
Bass: MonoNeon
Drums: Louis Cole
Organ: Larry Goldings
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Asst. Engineer: Franky Fox
Mixed by: Craig Polasko
Mastered by: Eric Boulanger at the Bakery

VIDEO CREDITS 
DP: Merlin Showalter
Editor: Adam Kritzberg

Recorded Live at Valentine Studios in Los Angeles, CA.

#ScaryGoldings #Funk #JohnScofield #MonoNeon #LouisCole #TacobellsCanon

