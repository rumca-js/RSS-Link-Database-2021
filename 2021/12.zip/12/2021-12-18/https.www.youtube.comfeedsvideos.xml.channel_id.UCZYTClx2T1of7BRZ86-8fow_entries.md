# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Seeing the World In Color | Compilation
 - [https://www.youtube.com/watch?v=aqEwIP4ETeU](https://www.youtube.com/watch?v=aqEwIP4ETeU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-12-19 00:00:00+00:00

Paleontology's Technicolor Moment: https://www.youtube.com/watch?v=_xIAx1Y_bPU

Colors: you see them every day, and you probably have a favorite. Pigments, light, and even noise all color how we experience the world. 

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, Jason A Saslow, charles george, Christoph Schwanke, Ash, Bryan Cloer, Silas Emrys, Eric Jensen, Adam Brainard, Piya Shedden, Jeremy Mysliwiec, Alex Hackman, GrowingViolet, Sam Lutfi, Alisa Sherbow, Dr. Melvin Sanicas, Melida Williams, Tom Mosner

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Original Episodes:
How Many Colors Can We See?: https://www.youtube.com/watch?v=lgHm5TKBW54
3 Brand New Colors That Scientists Discovered: https://www.youtube.com/watch?v=ngd57zinWBU
Do Those Glasses Really Fix Colorblindness?: https://www.youtube.com/watch?v=BrEyOkNRzGI
Colorfully Camouflaging Cuttlefish Are Colorblind: https://www.youtube.com/watch?v=N564FjDwE5Y
Colored Noise, and How It Can Help You Focus: https://www.youtube.com/watch?v=9T978ES0LdQ
Are Colors Real?: https://www.youtube.com/watch?v=cGZJflerLZ4

#SciShow

## Personalized Cancer Treatment Just Got Harder
 - [https://www.youtube.com/watch?v=ABU9GvzDb7Q](https://www.youtube.com/watch?v=ABU9GvzDb7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-12-18 00:00:00+00:00

Go to https://NordPass.com/SCISHOW and use code SCISHOW to get 70% off a 2 year NordPass Premium plan plus 1 free month! It’s risk free with 30 day money-back guarantee!

Scientists are working to develop personalized cancer treatments, but one obstacle in the way is figuring out how different cells react to one another.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, Jason A Saslow, charles george, Christoph Schwanke, Ash, Bryan Cloer, Silas Emrys, Eric Jensen, Adam Brainard, Piya Shedden, Jeremy Mysliwiec, Alex Hackman, GrowingViolet, Sam Lutfi, Alisa Sherbow, Dr. Melvin Sanicas, Melida Williams, Tom Mosner

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:

https://www.nature.com/articles/s41586-021-04206-7
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5651054/
https://www.scimex.org/newsfeed/its-not-all-in-their-dna-cancer-cells-with-the-same-genome-can-behave-differently

https://www.eurekalert.org/news-releases/937554?
http://dx.doi.org/10.1016/j.celrep.2021.110115

https://www.istockphoto.com/photo/set-iv-drip-fluid-intravenous-drop-saline-drip-hospital-room-medical-concept-gm1227586908-362112204

https://commons.wikimedia.org/wiki/File:Myeloblast_with_Auer_rod_smear_2010-01-27.JPG

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6358780/

https://commons.wikimedia.org/wiki/File:Breast_cancer_cells.jpg

https://www.istockphoto.com/photo/cancer-cells-vis-gm1277229026-376503224

https://www.istockphoto.com/photo/cancer-treatment-in-a-modern-medical-private-clinic-or-hospital-with-a-linear-gm1314465741-402674729

https://www.istockphoto.com/photo/demotivated-students-in-a-lecture-hall-gm847311278-138908523

https://www.istockphoto.com/photo/drinking-mouse-gm173542353-7748355

https://www.istockphoto.com/photo/wild-mouse-sitting-on-hind-legs-gm531927696-94019573

https://www.istockphoto.com/photo/white-mouse-4-gm89327997-6312157

https://www.istockphoto.com/photo/the-girl-listens-attentively-with-her-palm-to-her-ear-close-up-on-pink-background-gm1266725568-371418329

