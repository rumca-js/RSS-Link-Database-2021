# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This GPU SLIDES into this Case! - Silverstone SUGO 16 ITX Case
 - [https://www.youtube.com/watch?v=-wJOUAuKZm8](https://www.youtube.com/watch?v=-wJOUAuKZm8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-12-19 00:00:00+00:00

New Customers Exclusive - Get a Free 240gb SSD at Micro Center: https://micro.center/d61a58

Get 30% off list price and 30% off onboarding at http://www.graphus.ai/linus

With GPUs getting bigger and bigger and cases smaller and smaller, will Silverstone be the one to save our space?


Buy Silverstone SUGO 16 (Black) on Amazon: https://geni.us/WfAh2qp

Buy Silverstone SUGO 16 (White): https://geni.us/P0aJ

Buy Zotac RTX 3070 Twin Edge Gaming OC: https://geni.us/0IhBj

Buy Silverstone 750w PSU: https://geni.us/AA3OmIv

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1397236-this-gpu-slides-into-this-case/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:49 The problem with Cases
1:25 Today's Build
3:30 Opening the Case
6:00 Cooling Plan
8:00 One Weird Thing...
8:25 GPU Time!
9:11 Will this work?
10:15 Benchmarks
12:30 More GPUs!
13:10 What if they changed it?
13:35 Conclulsion
14:40 Outro

## Upgrading This TERRIBLE Computer - ROG Rig Reboot 2021
 - [https://www.youtube.com/watch?v=4nJUuNx800U](https://www.youtube.com/watch?v=4nJUuNx800U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-12-18 00:00:00+00:00

Thanks to ASUS ROG for sponsoring this video! Check out the PC list below and check out more great ASUS ROG products on BestBuy at: https://geni.us/U1tWW

Tucker is interesting, he's not your typical know-nothing contestant, but he doesn't exactly have a good RIG either. Let's see how much he knows about building PCs against Linus. 

Check out Tucker's video entry at https://youtu.be/XEMoZZqRhys

Buy ProArt Z690-Creator WiFi On BHPhoto: https://geni.us/N7HL8

Buy Intel Core i9-12900KF Desktop Processor
On Amazon: https://geni.us/xyfqgXm
On Best Buy: https://geni.us/Ca9UD
On Newegg: https://geni.us/FzO8n

Buy ASUS GeForce RTX 3080 TUF Gaming V2 OC Graphics Card
On Amazon: https://geni.us/bKy6AD3
On Newegg: https://geni.us/cACR6e
On BHPhoto: https://geni.us/leE8Pa

Buy ASUS ROG STRIX 1000W Gold Power Supply
On Amazon: https://geni.us/YJJwaE
On Newegg: https://geni.us/PTk6
On BHPhoto: https://geni.us/XOxiv

Buy ASUS ROG Ryujin II 360 RGB AIO CPU cooler on Newegg: https://geni.us/wXlkIr

Buy ASUS ProArt Display 27" 1440P Monitor (PA278CV)
On Amazon: https://geni.us/j77KGXf
On Best Buy: https://geni.us/DvSmw4
On Newegg: https://geni.us/NnqN

Buy 64gb G.Skill DDR5
On Amazon: https://geni.us/DmUnn
On Newegg: https://geni.us/ghcya2

Buy Crucial P5 Plus 1TB PCIe 4.0 3D NAND NVMe M.2 SSD
On Amazon: https://geni.us/Ym4RBQ
On Best Buy: https://geni.us/AJvRgA
On Newegg: https://geni.us/0qedsn

Buy Crucial - MX500 4TB 3D NAND Internal SATA 2.5" Solid State Drive
On Best Buy: https://geni.us/A8BTo
On Newegg: https://geni.us/idBo
On BHPhoto: https://geni.us/JYYEkLQ

Buy Phanteks Eclipse P500A D-RGB Black Case
On Amazon: https://geni.us/EYlSe
On Newegg: https://geni.us/0ksbL
On Walmart: https://geni.us/WLoXi

Buy ASUS TUF M3 Wired Gaming Mouse
On Amazon: https://geni.us/5Mz00p8
On Newegg: https://geni.us/bdPMgYD
On BHPhoto: https://geni.us/MQxtpBQ

Buy ASUS TUF Gaming H3 Gaming Headset (Gunmetal)
On Amazon: https://geni.us/4A5nq
On Newegg: https://geni.us/qzeJ
On BHPhoto: https://geni.us/TJAnwM

Buy ASUS TUF Gaming K1 RGB Wired Keyboard
On Amazon: https://geni.us/hvYSr
On Newegg: https://geni.us/geCBbCk
On BHPhoto: https://geni.us/OdS7FY

Buy ASUS TUF Gaming P3 Mousepad
On Amazon: https://geni.us/QQHx8QK
On Newegg: https://geni.us/uKaxd
On BHPhoto: https://geni.us/mMVn

Buy Cablemod Cables On Amazon: https://geni.us/J0uxHBc

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1396985-upgrading-this-terrible-computer-rog-rig-reboot-2021-sponsored/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 - Intro
0:29 - Who is Tucker?
2:16 - Motherboard - Ram - Memory - CPU
7:12 - Case Install - PSU
7:59 - Intermission - Beat Sabre Break
8:58 - Storage install - Cablemod - AIO Cooler
10:54 - Cable Management
11:01 - GPU Install
11:59 - Mor stickers
12:25 - Powering on the Rig
14:10 - Outro

