# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Why Biden didn't mince his words to the unvaccinated
 - [https://www.cnn.com/2021/12/18/politics/white-house-omicron-warning-joe-biden/index.html](https://www.cnn.com/2021/12/18/politics/white-house-omicron-warning-joe-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 23:48:52+00:00



## The NFL has updated its Covid protocols as the virus disrupts game schedules
 - [https://www.cnn.com/2021/12/18/sport/nfl-updates-covid-protocols-after-disrupted-schedule-spt/index.html](https://www.cnn.com/2021/12/18/sport/nfl-updates-covid-protocols-after-disrupted-schedule-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 23:23:25+00:00

A day after the NFL was forced to postpone three Week 15 games as it grapples with a surge in Covid-19 cases among players, the league and the NFL Players Association updated the NFL's Covid-19 protocols, effective at the end of Week 15.

## Trump loyalists are knocking on voters' doors in the latest quest to find fraud in the 2020 election
 - [https://www.cnn.com/2021/12/18/politics/trump-supporters-knock-on-doors-in-search-for-2020-fraud/index.html](https://www.cnn.com/2021/12/18/politics/trump-supporters-knock-on-doors-in-search-for-2020-fraud/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 23:16:30+00:00

A few months ago, two women showed up at Steve Snell's home in southern Pennsylvania with questions for his 89-year-old mother-in-law.

## Singer Sir Rod Stewart and his son plead guilty to simple battery
 - [https://www.cnn.com/2021/12/18/us/rod-stewart-and-son-plead-guilty-simple-battery/index.html](https://www.cnn.com/2021/12/18/us/rod-stewart-and-son-plead-guilty-simple-battery/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 22:20:03+00:00

Singer Sir Rod Stewart and his son, Sean, each pleaded guilty Friday to one count of simple battery in relation to a 2019 incident outside a south Florida hotel.

## Brooklyn Nets bring back Kyrie Irving part time following controversy over his vaccination status
 - [https://www.cnn.com/2021/12/18/us/kyrie-irving-nba-nets-return/index.html](https://www.cnn.com/2021/12/18/us/kyrie-irving-nba-nets-return/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 18:47:45+00:00

The Brooklyn Nets will bring back star guard Kyrie Irving to play in road games after he was prohibited from playing this season due to his refusal to comply with a New York City vaccination mandate, Nets General Manager Sean Marks said on Friday.

## YouTube TV pulls Disney-owned channels after failing to reach deal
 - [https://www.cnn.com/2021/12/18/media/youtube-tv-disney-deal/index.html](https://www.cnn.com/2021/12/18/media/youtube-tv-disney-deal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 18:39:06+00:00

After failing to reach a deal with Disney, YouTube TV will not be able to distribute Disney-owned channels such as ESPN and ABC on its platform, and has dropped the monthly subscription price to its platform by $15, to $49.99.

## Michigan city gets ready to inaugurate all-Muslim government
 - [https://www.cnn.com/2021/12/18/us/michigan-hamtramck-all-muslim-council/index.html](https://www.cnn.com/2021/12/18/us/michigan-hamtramck-all-muslim-council/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 18:13:16+00:00

For decades, Hamtramck was known as Michigan's "Little Warsaw," a city of just two square miles of tightly-packed houses and factories, spitting distance from downtown Detroit.

## 2022 is the year of the big movie sequels
 - [https://www.cnn.com/videos/entertainment/2021/12/18/2022-movie-sequels-pop-life-pop-off-orig.cnn](https://www.cnn.com/videos/entertainment/2021/12/18/2022-movie-sequels-pop-life-pop-off-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 17:59:01+00:00

From "Black Panther" to "Avatar," 2022 is shaping up to be the year of the sequel as several franchises get a reboot in the new year. CNN's "Pop Off" hosts dish on the new releases they're most excited for and the ones they wish would remain rumors. Subscribe to Lisa's "Pop Life Chronicles" newsletter here.

## Humans just 'touched' the sun for the first time using a spacecraft
 - [https://www.cnn.com/2021/12/18/world/parker-solar-probe-wt-science-newsletter-scn/index.html](https://www.cnn.com/2021/12/18/world/parker-solar-probe-wt-science-newsletter-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 16:12:24+00:00

This week, touch the sun with a NASA spacecraft, meet an unknown population of ancient people on an isolated group of islands, try to escape some sprinting dinosaurs, discover the animal with the most legs on record, and more.

## Covid surges threaten festivities worldwide
 - [https://www.cnn.com/2021/12/18/world/covid-chinese-new-year-travel-restrictions-intl/index.html](https://www.cnn.com/2021/12/18/world/covid-chinese-new-year-travel-restrictions-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 15:08:53+00:00

As the rapid spread of the Omicron coronavirus variant looms across parts of the globe and the Delta variant remains dominant -- for now -- in others, the Covid-19 pandemic is again threatening holiday celebrations for millions.

## 'Spider-Man' throws movie theaters a lifeline as they swing into the unknown
 - [https://www.cnn.com/2021/12/18/entertainment/spiderman-box-office-column/index.html](https://www.cnn.com/2021/12/18/entertainment/spiderman-box-office-column/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 15:08:51+00:00

When they post a big rating these days, TV executives are often fond of saying, "The pipes still work." They mean that while the audience has scattered among hundreds of options, old-time broadcasters can deliver a level of mass reach that's hard to equal anywhere else.

## Wisconsin basketball player raises more than $150,000 for hometown after deadly tornadoes
 - [https://www.cnn.com/2021/12/18/sport/wisconsin-basketball-player-chris-vogt-raises-funds-spt-intl/index.html](https://www.cnn.com/2021/12/18/sport/wisconsin-basketball-player-chris-vogt-raises-funds-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 14:29:57+00:00

Wisconsin men's basketball player Chris Vogt was traveling to play in a crucial matchup against Ohio State last Saturday when devastation ripped through his hometown of Mayfield, Kentucky.

## Premier League match between Aston Villa and Burnley postponed hours before kickoff
 - [https://www.cnn.com/2021/12/18/football/aston-villa-burnley-postponed-covid-19-spt-intl/index.html](https://www.cnn.com/2021/12/18/football/aston-villa-burnley-postponed-covid-19-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 13:43:16+00:00

The English Premier League match between Aston Villa and Burnley has been postponed due to an increased amount of positive Covid-19 test results within Villa's squad, the club announced on Saturday.

## Robert Lewandowski breaks Gerd Muller's 49-year goalscoring record in Bayern Munich win
 - [https://www.cnn.com/2021/12/18/football/robert-lewandowski-gerd-muller-record-spt-intl/index.html](https://www.cnn.com/2021/12/18/football/robert-lewandowski-gerd-muller-record-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 12:11:02+00:00

Robert Lewandowski scored his 43rd Bundesliga goal of 2021 to break Gerd Muller's 49-year record of most goals scored in a calendar year.

## Richard Quest explores the Venetian costume's mysterious past
 - [https://www.cnn.com/videos/travel/2021/12/18/venetian-costume-wardrobe-richard-quest-world-of-wonder-venice-b-spc.cnn](https://www.cnn.com/videos/travel/2021/12/18/venetian-costume-wardrobe-richard-quest-world-of-wonder-venice-b-spc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 10:12:39+00:00

Under the cloak and mystery of mask and costume, Venice once made disguise a regular part of its wardrobe.

## Some call this Kentucky town the 'Heart of America.' Now its international community is picking up the pieces after a deadly tornado
 - [https://www.cnn.com/2021/12/18/us/bowling-green-kentucky-community-tornado-victims-damage/index.html](https://www.cnn.com/2021/12/18/us/bowling-green-kentucky-community-tornado-victims-damage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 10:00:15+00:00

When Leyda Becker heard a weather alert on her phone in the early morning hours of December 11, she wasn't surprised. Tornado alerts in Bowling Green are not uncommon and often don't amount to much.

## 20 astonishing facts about the A380 superjumbo
 - [https://www.cnn.com/travel/article/airbus-a380-superjumbo-astonishing-facts/index.html](https://www.cnn.com/travel/article/airbus-a380-superjumbo-astonishing-facts/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 09:42:35+00:00

Beloved by passengers for its spaciousness and comfort, but disliked by airlines because of its running costs, the Airbus A380 has already entered its sunset years, even though it debuted commercially just 14 years ago.

## From 6.2 million international visitors to 45. Thanks, 2021
 - [https://www.cnn.com/travel/article/pandemic-travel-news-omicron-uk-france-ghana/index.html](https://www.cnn.com/travel/article/pandemic-travel-news-omicron-uk-france-ghana/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 09:24:03+00:00

Omicron is sweeping through Europe. The United States is preparing for full-throttle winter holiday travel. And Australia and the Caribbean island-nation of St. Kitts and Nevis are relaxing visitor restrictions.

## Witness the cold micromoon — the last full moon of 2021 to shine in the night sky
 - [https://www.cnn.com/2021/12/18/world/full-moon-december-2021-scn/index.html](https://www.cnn.com/2021/12/18/world/full-moon-december-2021-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 09:00:15+00:00

Bundle up to enjoy the last full moon of the year.

## A professor hid a cash prize. All students had to do was read the syllabus
 - [https://www.cnn.com/2021/12/18/us/tennessee-professor-syllabus-money-trnd/index.html](https://www.cnn.com/2021/12/18/us/tennessee-professor-syllabus-money-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 06:00:48+00:00

With every new college semester, students are faced with multiple syllabuses outlining the subjects in their classes.

## Boris Johnson is fighting for his political life after stunning election defeat
 - [https://www.cnn.com/2021/12/18/uk/boris-johnson-by-election-loss-gbr-cmd/index.html](https://www.cnn.com/2021/12/18/uk/boris-johnson-by-election-loss-gbr-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 05:00:16+00:00

Has Boris Johnson lost his touch? That's the question the United Kingdom was asking itself on Friday morning, after the governing Conservative party lost a parliamentary seat in a by-election that it had held for nearly 200 years.

## Juno flyby reveals stunning new images of Jupiter, sounds of its moon Ganymede
 - [https://www.cnn.com/2021/12/17/world/juno-jupiter-ganymede-flyby-scn/index.html](https://www.cnn.com/2021/12/17/world/juno-jupiter-ganymede-flyby-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 04:23:22+00:00

Flybys of Jupiter and its moon Ganymede conducted by the NASA Juno mission have revealed new Van Gogh-like images of the gas giant, as well as the sounds made by one of its moons.

## Pfizer vaccine fails to produce expected immunity in young kids
 - [https://www.cnn.com/collections/intl-covid-1712/](https://www.cnn.com/collections/intl-covid-1712/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 03:56:58+00:00



## DC area police investigate 'shopping cart killer'
 - [https://www.cnn.com/2021/12/17/us/washington-dc-shopping-cart-killer/index.html](https://www.cnn.com/2021/12/17/us/washington-dc-shopping-cart-killer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 03:27:38+00:00

Authorities in the DC metro area said Friday a 35-year-old man who was charged last month in the killing of two women may be a serial killer and the prime suspect in the deaths of two more women, as a wide-ranging investigation is underway to determine if there are more victims.

## Suspects in assassination of Haiti's president say they're 'victims of a set up'
 - [https://www.cnn.com/videos/world/2021/12/18/suspects-haiti-assassination-colombian-prisoners-rivers-ac360-vpx.cnn](https://www.cnn.com/videos/world/2021/12/18/suspects-haiti-assassination-colombian-prisoners-rivers-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 02:17:45+00:00

CNN's Matt Rivers spoke with five of the Colombian suspects arrested in connection with the assassination of Haiti's president, who say they were beaten and made to sign testimonies in a foreign language.

## Sydney and Melbourne relax rules for vaccinated international travelers
 - [https://www.cnn.com/travel/article/australia-states-new-isolation-rules-vaccinated/index.html](https://www.cnn.com/travel/article/australia-states-new-isolation-rules-vaccinated/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 02:03:17+00:00

Fully vaccinated international travelers arriving in Sydney and Melbourne will no longer have to quarantine for 72 hours starting Tuesday, December 21, Australian government officials announced Thursday.

## Harris defends Biden when questioned whether he or Manchin is President
 - [https://www.cnn.com/2021/12/17/politics/harris-charlamagne-tha-god-interview-defends-biden/index.html](https://www.cnn.com/2021/12/17/politics/harris-charlamagne-tha-god-interview-defends-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 01:37:00+00:00

Vice President Kamala Harris forcefully defended President Joe Biden when recently asked whether he or Sen. Joe Manchin is the president of the United States, as Biden's agenda remains stalled in part because of the West Virginia Democrat.

## Marine Corps discharges 103 service members for refusing Covid-19 vaccine
 - [https://www.cnn.com/2021/12/17/politics/marine-corps-discharges-103-members-covid-19-vaccine/index.html](https://www.cnn.com/2021/12/17/politics/marine-corps-discharges-103-members-covid-19-vaccine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-18 00:40:13+00:00

The Marine Corps has discharged 103 service members for refusing to take the Covid-19 vaccine, as the military begins carrying out enforcement actions for its vaccine mandate.

