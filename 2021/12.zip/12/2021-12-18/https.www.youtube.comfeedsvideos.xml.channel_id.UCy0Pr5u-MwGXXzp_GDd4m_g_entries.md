# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Santa's Xmas Cream on Shark Tank
 - [https://www.youtube.com/watch?v=rQOh9ar51LM](https://www.youtube.com/watch?v=rQOh9ar51LM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-12-19 00:00:00+00:00

As seen in my previous SNL audition. Here's a look at my full Shark Tank experience. Merry Christmas you filthy animals. 

Also, check out my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

#snl #comedy

