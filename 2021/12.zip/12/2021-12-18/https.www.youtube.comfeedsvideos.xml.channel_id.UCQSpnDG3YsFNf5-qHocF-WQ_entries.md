# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Ultimate Guide to Fix Almost ANY Windows Corruption (Without Reinstalling)
 - [https://www.youtube.com/watch?v=yidWdy-Xwdk](https://www.youtube.com/watch?v=yidWdy-Xwdk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-12-18 00:00:00+00:00

Thanks to Micro Center for sponsoring! Check them out:
• New Customers Exclusive – Get a Free 240gb SSD at Micro Center ⇨ https://micro.center/65ed1d
• Browse Micro Center's business solutions ⇨ https://micro.center/df6f2f
• Micro Center’s custom workstation and server builder: https://micro.center/eee5ff

Commands mentioned:
• sfc /scannow
• DISM /Online /Cleanup-Image /RestoreHealth

Windows 10 Media Creation Tool: https://www.microsoft.com/en-us/software-download/windows10
Windows 11 Media Creation Tool: https://www.microsoft.com/software-download/windows11

▼ Time Stamps: ▼
0:00 - Intro
1:54 - Context to Get Ready
3:04 - Repairing With the Commands
5:08 - Corrupted Windows Profiles
6:43 - The 'Last Resort' Repair Upgrade
11:00 - If Repair Upgrade Didn't Work
11:21 - Migrating From Corrupted Profile
12:33 - If There's No Apparent Cause
12:59 - Fixing Corrupted Windows Updater
15:14 - Final Useful Mentions

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

