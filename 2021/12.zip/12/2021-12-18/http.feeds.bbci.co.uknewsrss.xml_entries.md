# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Brit Awards 2022: Full list of nominees
 - [https://www.bbc.co.uk/news/entertainment-arts-59711692?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59711692?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-18 18:00:07+00:00

A rundown of the artists who are nominated for a Brit Award in 2022.

