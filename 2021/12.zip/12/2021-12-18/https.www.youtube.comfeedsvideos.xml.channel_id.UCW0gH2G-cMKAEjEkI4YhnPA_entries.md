# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Fellowship of the Ring 20th Anniversary WATCH PARTY!
 - [https://www.youtube.com/watch?v=cNQIXfkoOJM](https://www.youtube.com/watch?v=cNQIXfkoOJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-12-19 00:00:00+00:00

Join me and some special guests as we watch The Fellowship of the Ring to celebrate the 20th anniversary of its theatrical release!

HOW IT WORKS:
1) Pull up your DVD, Bluray, or Digital Copy of The Fellowship of the Ring (EXTENDED EDITION)
2) Use a second screen, phone, tablet, or whatever to pull up this stream.
3) We all start playing the film at the same time, watching together.  I'll have special guests like Cliff from @TheOneRing and Yoystan from ​ @Men of the West  and we will read your comments, answer questions, and share thoughts of our own in kind of a running "Fan Commentary" with the film.

*If you are unaware, I cannot legally stream the actual film, which is why we will merely be syncing together in this watch party format.  I will have a running timer throughout, so if you come late or get interrupted, you can easily locate our position in the film!

To learn more about our holiday initiative to donate copies of The Hobbit to kids in need, check out this video: https://youtu.be/R_P8W1i8M98

#lotr20 #fellowshipofthering #lordoftherings

## The Watcher in the Water & the Nameless Things of Moria | Tolkien Explained
 - [https://www.youtube.com/watch?v=rZkUlv1VVnQ](https://www.youtube.com/watch?v=rZkUlv1VVnQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-12-18 00:00:00+00:00

They are among the most mysterious creatures in Tolkien's Middle-earth.  The Watcher in the Water and the Nameless Things of Moria are glimpsed and mentioned in passages, and are even said to be unknown to Sauron.  Likely a byproduct of the creation of the world, these creatures found refuge in the depths of Moria until one would escape to haunt the entrance to Khazad-dûm!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html

A Nameless Thing - Anthony Pilon
Vast Passages - Freja Gelii
Watcher in the Water - Ulla Thynell
Watcher in the Water - John Howe
Gollum and Bilbo - Alan Lee
Cave Temple - Aetharius
Nameless Thing - Heather Hudson
Rippling from Beneath - Fantasy Flight
Mines of Moria part 2 - Moondoodles
Mines of Moria part 1 - Moondoodles
Moria Throne Room - Moondoodles
Ainulindale - Anna Kulisz
The Music of the Gods - Kip Rasmussen
Ainulindale, Discord of Melkor - Anna Kulisz
The Bargain with Ungoliant - Morkard
Tom Bombadil - Borja Pindado
The Watcher Concept Art - WETA
The Watcher in the Water - Olanda Fong
West-door of Moria - Lida Holubova
The Watcher - Anke Eissmann
The Fellowship Approaches Moria - Ted Nasmith
The Walls of Moria - Donato Giancola
Moria Gate - John Howe
Moria - Alan Lee
Watcher in the Water - John Howe
Watcher in the Water - Andrea Piparo
Watcher in the Water - Ulla Thynell
Gandalf in Moria - Donato Giancola
Watcher in the Water - Kingovrats
The Death of Isildur - Anke Eissmann
Mines of Moria - Gellihana
In the Chamber of Mazarbul - Tulikoura
Chamber of Mazarbul - Alan Lee
The West gate of Moria - Manofaction42
Book of Mazarbul - Sara Biddle
The Watcher in the Water - Joona Kujanen
Last Moments - Tulijoura
West-door of Moria - Lida Holubova
Dream Sea Monster, Watcher in the Water - kingovrats
Gandalf and the Balrog - Evolvana
Slime Balrog - Max Haig
The Bridge of Khazad-dum - Anna Kulisz
Vast Passages - Freja Gelii
Zirakzagil - Deagol
Gandalf vs Balrog - Elbardo
Dagon - Andrea Guardino

#namelessthings #moria #tolkien

