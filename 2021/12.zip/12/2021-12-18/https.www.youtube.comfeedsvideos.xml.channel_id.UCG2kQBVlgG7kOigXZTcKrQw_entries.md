# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Relaksująca wędrówka przez Maderę 🌍 Silent Hiking 2/2
 - [https://www.youtube.com/watch?v=tkHOWi03deg](https://www.youtube.com/watch?v=tkHOWi03deg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-12-19 00:00:00+00:00

Rok 2021 był zdecydowanie rokiem "Madery" na tym kanale. Z żadnej wyspy, z żadnego miejsca na świecie nie przywiozłem tyle materiału i też w żadnym innym miejscu tak bardzo mi się nie podobało. Dlatego też kończąc tę maderską sagę zapraszam do drugiego filmu z Madery w klimacie "Poczuj" czyli nowej serii Silent Hikingowej na tym kanale. W przyszłym roku będą kolejne, chyba, że nie chcecie :D
Pozdro!

#zamiastKevina

Muzyka:
Artlist
Soundcloud - Navaeh

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

