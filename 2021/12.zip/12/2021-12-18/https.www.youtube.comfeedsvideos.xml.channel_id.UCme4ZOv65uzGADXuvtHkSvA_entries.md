# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Aloes
 - [https://www.youtube.com/watch?v=Wbv36qQ5xkU](https://www.youtube.com/watch?v=Wbv36qQ5xkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-19 00:00:00+00:00

Cztery niedziele Adwentu i cztery piosenki na A. 
Zapraszamy w krainę SŁOWA, MUZYKI i OBRAZU. 

@Langustanapalmie  @AgnieszkaMusiaYT 

tekst: Agnieszka Musiał II Jan Smoczyński 
muzyka: Agnieszka Musiał II Jan Smoczyński 
zespół w składzie: Agnieszka Musiał || Jan Smoczyński || Kamil Siciak
produkcja serii, scenografia, stylizacja: Sylwia Smoczyńska 
realizacja i produkcja muzyki: Jan Smoczyński 
zdjęcia: Marcin Jończyk 
montaż: Marcin Kopiec 
realizacja światła: Bartek Borcz 
pomoc techniczna: Michał Blicharski 
make up: Zuza Górska 
Zdjęcia zrealizowano w Agroturystyce Modry Ganek

"Aloes"

zwr. 1
Mówią do mnie, ze nie warto 
Iść za głosem serca
Rezygnuję z moich pragnień 
Inni wiedzą lepiej
wciąż nie widzę 
Końca zmagań 
droga mnie wykańcza 
Nie chce dłużej się poddawać 
Nie chce walczyć sama 

ref.
Twoje słowa jak aloes
Łagodzą każdy ból
Jeszcze nie wszystko stracone 
Uuu
jak aloes łagodzisz 
Każdy mój trud 
Jeszcze nie wszystko stracone 
Aloes 

Zwr. 2 
Nie poddaję się naciskom 
Serce słyszy prawdę 
Gdzie nadzieja tam marzenia 
Nigdy nie jest za późno 

Ref.
Twoje słowa jak aloes
Łagodzą każdy ból
Jeszcze nie wszystko stracone 
Uuu
jak aloes łagodzisz 
Każdy mój trud 
z nadzieja Czekam na nowe 
Aloes 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Rut || Rozdział 04
 - [https://www.youtube.com/watch?v=JHcE2gN0VHY](https://www.youtube.com/watch?v=JHcE2gN0VHY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-19 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocnostronniczy [#49] Metafizyczna codzienność
 - [https://www.youtube.com/watch?v=od95U8s1i7A](https://www.youtube.com/watch?v=od95U8s1i7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-19 00:00:00+00:00

Takich dwóch, jak Ci to nie ma.
Zapraszamy w niedzielę o godz: 10:oo.


zdjęcia, dźwięk, montaż: Marcin Jończyk
grafika, produkcja serii: Sylwia Smoczyńska


 @Langustanapalmie @STREFAWODZA 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#265] A co z Twoim ciałem?
 - [https://www.youtube.com/watch?v=w5IeV8S-Uy8](https://www.youtube.com/watch?v=w5IeV8S-Uy8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-18 00:00:00+00:00

#cnn #dobrewiadomości

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

IV Niedziela Adwentu, Rok C

1. czytanie (Mi 5, 1-4a)

Tak mówi Pan:
A ty, Betlejem Efrata, najmniejsze jesteś wśród plemion judzkich! z ciebie wyjdzie dla mnie Ten, który będzie władał w Izraelu, a pochodzenie Jego od początku, od dni wieczności. Przeto Pan porzuci ich aż do czasu, kiedy porodzi mająca porodzić. Wtedy reszta braci Jego powróci do synów Izraela.
Powstanie on i paść będzie mocą Pańską, w majestacie imienia Pana, Boga swego. osiądą wtedy, bo odtąd rozciągnie swą potęgę aż po krańce ziemi. a on będzie pokojem.

2. czytanie (Hbr 10, 5-10)

Bracia:
Chrystus, przychodząc na świat, mówi: «ofiary ani daru nie chciałeś, ale Mi utworzyłeś ciało; całopalenia i ofiary za grzech nie podobały się Tobie. Wtedy rzekłem: oto idę – w zwoju księgi napisano o Mnie – aby spełnić wolę Twoją, Boże».
Wyżej powiedział: «ofiar, darów, całopaleń i ofiar za grzech nie chciałeś i nie podobały się Tobie», choć składane są zgodnie z Prawem. Następnie powiedział: «oto idę, aby spełnić wolę Twoją». Usuwa jedną ofiarę, aby ustanowić inną. Na mocy tej woli uświęceni jesteśmy przez ofiarę ciała Jezusa Chrystusa raz na zawsze.

Ewangelia (Łk 1, 39-45)

W tym czasie Maryja wybrała się i poszła z pośpiechem w góry do pewnego miasta w ziemi Judy. Weszła do domu Zachariasza i pozdrowiła Elżbietę.
Gdy Elżbieta usłyszała pozdrowienie Maryi, poruszyło się dzieciątko w jej łonie, a Duch Święty napełnił Elżbietę. Wydała ona głośny okrzyk i powiedziała: «Błogosławiona jesteś między niewiastami i błogosławiony jest owoc Twojego łona. A skądże mi to, że Matka mojego Pana przychodzi do mnie? Oto bowiem, skoro głos Twego pozdrowienia zabrzmiał w moich uszach, poruszyło się z radości dzieciątko w moim łonie. Błogosławiona jest, która uwierzyła, że spełnią się słowa powiedziane Jej od Pana».
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Rut || Rozdział 03
 - [https://www.youtube.com/watch?v=OHrKwax_ajY](https://www.youtube.com/watch?v=OHrKwax_ajY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-18 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wyszynki [#971] Cena
 - [https://www.youtube.com/watch?v=Tov16gdKjmo](https://www.youtube.com/watch?v=Tov16gdKjmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-18 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Zapraszamy Was do włączenia się w Adwentową Akcję Charytatywną:
→ https://charytatywnie.fundacjamalak.pl/  
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka cegiełka (w wersji papierowej) wyruszy do Was w drogę już 12 listopada.
Ebook - dostępny już dziś.

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

