## A380: Last of the superjumbos handed to new owner - BBC News
 - [https://www.bbc.co.uk/news/business-59667835](https://www.bbc.co.uk/news/business-59667835)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-12-18 09:55:52.784733+00:00

Emirates has taken ownership of the final A380 to be built. What does the future hold for the plane?

