# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Ruszamy w podróż po Kubie - #9 @vlogcasha
 - [https://www.youtube.com/watch?v=gk6hw68AQ8E](https://www.youtube.com/watch?v=gk6hw68AQ8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2021-12-19 00:00:00+00:00

Vlogi z Kuby (chronologicznie z obydwu kanałów): 
https://youtube.com/playlist?list=PLxvi52O0l5Y2JFYHV17f28uBAi64GkbFt

Kanał Casha: @vlogcasha 

Wspomniany vlog Kuba #7 o tancerce Duni: https://www.youtube.com/watch?v=OHFQBNZYP2Q

Sklep: https://bezplanu.com

Wszystkie odcinki BezPlanu chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv
Wsparcie na Patronite: http://bit.ly/2KsFTZk 

Dźwięk: Mateusz Czerniakowski
Mapka: Jarek Męcina https://www.youtube.com/channel/UC3JXkGiuGxQHARkEHOMvDmw

Czas akcji: grudzień 2021r.

