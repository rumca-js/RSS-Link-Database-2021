# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Games of 2022 [FIRST HALF]
 - [https://www.youtube.com/watch?v=kq20AgoVta8](https://www.youtube.com/watch?v=kq20AgoVta8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-19 00:00:00+00:00

2022 looks to have a promising amount of great games for PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch. Here's a round up of all the big games for the first half of the year.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10-Tiny Tina's Wonderlands 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : March 25, 2022 



9-Gran Turismo 7 

Platform : PS4 PS5

Release Date : March 4, 2022 



8-Pokémon Legends: Arceus 

Platform : Switch

Release Date : January 28, 2022 



7-Sons of the Forest 

Platform : PC

Release Date : May 20, 2022



6-Sifu 

Platform : PC PS4 PS5

Release Date : February 8, 2022 



5-Forspoken 

Platform : PS5 PC

Release Date : May 24, 2022 



4-S.T.A.L.K.E.R. 2: Heart of Chernobyl

Platform : PC XSX|S 

Release Date : April 28, 2022 



3-Dying Light 2 Stay Human 

Platform : PC Switch PS4 PS5 Xbox One XSX|S 

Release Date : February 4, 2022



2-Horizon Forbidden West 

Platform : PS4 PS5

Release Date : February 18, 2022



1-Elden Ring 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : February 25, 2022 



BONUS

Destiny 2: The Witch Queen 

Platform : PC PS4 PS5 XSX|S Stadia Xbox One 

Release Date : February 22, 2022 



CrossfireX 

Platform : Xbox One XSX|S 

Release Date : February 10, 2022 



The King of Fighters XV 

Platform : PS5 XSX|S PS4 PC



Elex II 

Platform : PS5 XSX|S PS4 Xbox One PC

Release Date : March 1, 2022

## 10 Games That SUCKED in 2021
 - [https://www.youtube.com/watch?v=OMwsECSyzic](https://www.youtube.com/watch?v=OMwsECSyzic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-18 00:00:00+00:00

2021 gave us a handful of disappointing and bad games on PC, PS5, PS4, Xbox Series X/S/One, Switch, and beyond.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

