# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## How Games Get Shotguns Wrong - Loadout
 - [https://www.youtube.com/watch?v=EYdqsgijJI4](https://www.youtube.com/watch?v=EYdqsgijJI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-12-19 00:00:00+00:00

From DOOM’s iconic Super Shotgun through to Gears of War’s Gnasher, the shotgun is one of the most popular and versatile weapons in video games - a trusty firearm that packs a devastating punch, particularly in close encounters. But the gaming shotgun that we’ve come to know and love takes a fair few liberties from its real world counterpart.

In this episode of Loadout, Dave Jewitt visits the Royal Armouries to talk to Keeper of Firearms & Artillery Jonathan Ferguson, to chart the vast differences between real shotguns and their gaming counterparts.

You can check out more episodes of Loadout right here. - https://www.youtube.com/watch?v=yzSrmGkpWKk&list=PLpg6WLs8kxGMzIemU1gyyLmg5VlKI2UvC

You can check out our Firearms Expert Reacts series here. - https://www.youtube.com/watch?v=5FVzcoRjoN4&list=PLpg6WLs8kxGMgYb13XjPgOKbm5O-CDq7R

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

## Firearms Expert Reacts To Call Of Duty: Warzone’s Guns
 - [https://www.youtube.com/watch?v=QLNWal-8fv8](https://www.youtube.com/watch?v=QLNWal-8fv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-12-18 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the weaponry of Call Of Duty: Warzone, including a gold sniper rifle, a variety of MP5s, and the British EM-2 assault rifle.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down the guns of Call Of Duty: Warzone and compares them to their real-life counterparts.

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can either purchase Jonathan's book here. - https://www.headstamppublishing.com/bullpup-rifle-book

Or at the Royal Armouries shop here. - https://shop.royalarmouries.org/collections/thorneycroft-to-sa80-british-bullpup-firearms-1901-2020

You can subscribe to the Armax Journal that Jonathan Associate Edited here: https://www.armaxjournal.org/

