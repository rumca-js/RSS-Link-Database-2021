# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Rudolph finally gets to smash
 - [https://www.youtube.com/watch?v=NpxlqT6Ol6A](https://www.youtube.com/watch?v=NpxlqT6Ol6A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-12-19 00:00:00+00:00

Holiday Season Deal! Go to https://NordVPN.com/gitz to get a 2-year plan plus 1 additional month with a huge discount.

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

MudRoom CG Team ►
https://www.youtube.com/c/Mudroom ►
Jack G - Modeling, Animation, Texturing - https://www.youtube.com/c/PotatoManng/
Anthony S - Modeling, Surfacing, Lighting - https://www.youtube.com/c/cusey 
Lucas S - Rigging, Animation - https://www.instagram.com/lm.santos/  
Zack M - Modeling, Lighting - https://www.instagram.com/mini0h/ 
Ray K - Animation, Modeling - https://twitter.com/Techno_Tiki
Jacob T - Animation - https://twitter.com/Jazzmasta_J 
Geoff R - Animation - https://twitter.com/houndkidz 
Natalie J - Animation
Gui V - Animation -  https://gui-at.tumblr.com/anim 
Emily G - Animation

Music ►
Zach Heyde https://youtube.com/playlist?list=PLXtP4ANq7nIUYo6VZEEHtd8H3HP_MthUC

Sound ► 
Justin Greger

VO ► 
Clarice - Monica Franco
Rudolph - Jack Gatto
Donner - Ricepirate
Clarice’s Dad, Reindeer Kid  - Don 
Reindeer Coach, Fireball - Tom

Ad-Compositing ►
Oddest of the Odd

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

