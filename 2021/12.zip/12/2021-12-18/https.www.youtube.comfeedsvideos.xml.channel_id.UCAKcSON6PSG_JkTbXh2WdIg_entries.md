# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Sara Watkins - three live performances (2019; 2018)
 - [https://www.youtube.com/watch?v=Re6ccYi4ocU](https://www.youtube.com/watch?v=Re6ccYi4ocU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-18 00:00:00+00:00

On Saturday, Dec. 18, Watkins Family Hour — the sibling duo of Sean and Sara Watkins — are set to perform a concert at the Hopkins Center for the Arts in Hopkins, Minnesota, west of Minneapolis. In anticipation of that show, here are three live performances by 50 percent of that duo, Sara Watkins, recorded as part of Live From Here.

SONGS PERFORMED
0:00 "You And Me"
3:35 "Move Me"
7:48 "Jefferson"

PERSONNEL
On "You And Me"
Sara Watkins – vocals
Chris Thile – mandolin 
Shaun Martin – piano 
Brittany Haas – fiddle 
Noam Pikelny – banjo 
Bryan Sutton – guitar 
Eric Doob – percussion 

On "Move Me"
Sara Watkins – vocals, guitar
Chris Thile – mandolin, backing vocals
Jenny Lewis – backing vocals
Madison Cunningham – backing vocals
Jeff Babko – piano
Gabe Witcher – fiddle
Chris Eldridge – guitar
Trevor Lawrence Jr. – percussion

On "Jefferson"
Sara Watkins – fiddle
Brittany Haas – fiddle

CREDITS
Video & Photo: Ben Miller; American Public Media
Audio: Sam Hudson; American Public Media
Production: Jeffy Hnilicka; Tom Campbell; American Public Media

FIND MORE:
2012 studio session: https://www.thecurrent.org/feature/2012/04/22/sara-watkins
2016 studio session: https://www.thecurrent.org/feature/2016/09/29/sara-watkins-performs-in-the-studio
2016 Guitar Collection interview:
https://www.thecurrent.org/feature/2016/09/21/the-currents-guitar-collection-sara-watkins-bourgeois-piccolo-parlor

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#sarawatkins

