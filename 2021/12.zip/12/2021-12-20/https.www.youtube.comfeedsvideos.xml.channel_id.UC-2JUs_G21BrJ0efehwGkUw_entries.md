# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## STARBLASTER /// 1am Funk Dance Party
 - [https://www.youtube.com/watch?v=ZI9SDVEe-ks](https://www.youtube.com/watch?v=ZI9SDVEe-ks)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-12-20 00:00:00+00:00

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

1am Funk Dance Party is an original song by Scary Pockets.

MUSICIAN CREDITS
Drums: Joey Waronker
Bass: Tim Lefebvre
Guitar: Lyle Workman
Guitar: Ryan Lerman
Keys: Jack Conte

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
DP: Kenzo Le
Camera Op: Ryan Blewett 
Editor: Adam Kritzberg

Recorded Live at Valentine Studios in Los Angeles, CA.

#ScaryPockets #Funk #DanceParty #1amfunkdanceparty

