# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Cuffed Up -  Canaries (Live on KEXP)
 - [https://www.youtube.com/watch?v=_zJIJrthprg](https://www.youtube.com/watch?v=_zJIJrthprg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-20 00:00:00+00:00

http://KEXP.ORG presents Cuffed Up performing "Canaries" live in the KEXP studio. Recorded November 24, 2021.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

Ralph Torrefranca - Guitar/Vocals
Sapphire Jewell - Guitar/Vocals
Joe Liptock - Drums
Vic Ordonez - Bass

https://cuffedupmusic.com/
http://kexp.org

## Cuffed Up - Bonnie (Live on KEXP)
 - [https://www.youtube.com/watch?v=4WUQ6EPD_aQ](https://www.youtube.com/watch?v=4WUQ6EPD_aQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-20 00:00:00+00:00

http://KEXP.ORG presents Cuffed Up performing "Bonnie" live in the KEXP studio. Recorded November 24, 2021.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

Ralph Torrefranca - Guitar/Vocals
Sapphire Jewell - Guitar/Vocals
Joe Liptock - Drums
Vic Ordonez - Bass

https://cuffedupmusic.com/
http://kexp.org

## Cuffed Up - French Exit (Live on KEXP)
 - [https://www.youtube.com/watch?v=CeC_4r_WnAg](https://www.youtube.com/watch?v=CeC_4r_WnAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-20 00:00:00+00:00

http://KEXP.ORG presents Cuffed Up performing "French Exit" live in the KEXP studio. Recorded November 24, 2021.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

Ralph Torrefranca - Guitar/Vocals
Sapphire Jewell - Guitar/Vocals
Joe Liptock - Drums
Vic Ordonez - Bass

https://cuffedupmusic.com/
http://kexp.org

## Cuffed Up - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=DqKlJ74tdgw](https://www.youtube.com/watch?v=DqKlJ74tdgw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-20 00:00:00+00:00

http://KEXP.ORG presents Cuffed Up performing live in the KEXP studio. Recorded November 24, 2021.

Songs:
Bonnie
Small Town Kid
French Exit
Canaries

Ralph Torrefranca - Guitar/Vocals
Sapphire Jewell - Guitar/Vocals
Joe Liptock - Drums
Vic Ordonez - Bass

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://cuffedupmusic.com
http://kexp.org

## Cuffed Up - Small Town Kid (Live on KEXP)
 - [https://www.youtube.com/watch?v=7qiR6sir-1o](https://www.youtube.com/watch?v=7qiR6sir-1o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-12-20 00:00:00+00:00

http://KEXP.ORG presents Cuffed Up performing "Small Town Kid" live in the KEXP studio. Recorded November 24, 2021.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro & Scott Holpainen
Editor: Scott Holpainen

Ralph Torrefranca - Guitar/Vocals
Sapphire Jewell - Guitar/Vocals
Joe Liptock - Drums
Vic Ordonez - Bass

https://cuffedupmusic.com/
http://kexp.org

