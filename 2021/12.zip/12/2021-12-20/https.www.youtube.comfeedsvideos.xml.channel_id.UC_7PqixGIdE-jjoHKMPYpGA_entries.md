# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy możesz ufać filmom Naukowego Bełkotu?
 - [https://www.youtube.com/watch?v=Avq9X0SSiLU](https://www.youtube.com/watch?v=Avq9X0SSiLU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-12-20 00:00:00+00:00

👉 https://naukowybelkot.pl
👉 Patronite ► https://patronite.pl/NaukowyBelkot 

👕 Merch ► https://naukowybelkot.pl/sklep-belkotowy
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Po siedmiu latach robienia filmów na YT musimy porozmawiać o ważnej kwestii. Czy można ufać filmom Naukowego Bełkotu?

===
Rozkład jazdy:

0:00 Czy możesz ufać temu człowiekowi?
3:22 Recenzje
11:17 Gatunki naukowych prac
16:10 IF
19:55 Prace wycofane

===
Źródła (wybrane):

W zasadzie wszystkie wnioski z tej pracy to opis mojej niedługiej i niekrótkiej przygody z pisaniem prac naukowych. Stąd źródłem jest głównie moja biografia.

J. Ioannidis - Why Most Published Research Findings Are False

