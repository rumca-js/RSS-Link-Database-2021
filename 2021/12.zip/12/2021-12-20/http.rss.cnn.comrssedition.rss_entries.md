# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 'Spider-Man: No Way Home' was the second-biggest box office opening ever
 - [https://www.cnn.com/2021/12/20/media/spider-man-no-way-home-box-office/index.html](https://www.cnn.com/2021/12/20/media/spider-man-no-way-home-box-office/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 17:24:21+00:00

Spider-Man made even more money than originally projected.

## Why Elon Musk will end up with an $11 billion tax bill this year
 - [https://www.cnn.com/2021/12/20/investing/elon-musk-11-billion-dollars-taxes/index.html](https://www.cnn.com/2021/12/20/investing/elon-musk-11-billion-dollars-taxes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 17:23:01+00:00

Elon Musk says his tax bill this year will be $11 billion, and he's probably right: The filings he has made with the Securities and Exchange Commission about his recent stock trades back up that massive number.

## Closing arguments begin in Kim Potter trial for Daunte Wright's death
 - [https://www.cnn.com/2021/12/20/us/kim-potter-trial-monday/index.html](https://www.cnn.com/2021/12/20/us/kim-potter-trial-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 17:02:33+00:00

Closing arguments are scheduled to begin Monday morning in the trial of Kim Potter, a former Minnesota police officer who says she mistook her firearm for her Taser and accidentally killed Daunte Wright, a 20-year-old Black man.

## Supreme Court receives appeals asking Kavanaugh to block large employer vaccine mandate
 - [https://www.cnn.com/2021/12/20/politics/supreme-court-kavanaugh-osha-vaccine-mandate-omicron/index.html](https://www.cnn.com/2021/12/20/politics/supreme-court-kavanaugh-osha-vaccine-mandate-omicron/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 17:01:02+00:00

The Supreme Court Monday said it has received several appeals asking Justice Brett Kavanaugh to consider the Biden administration's requirement that large employers mandate their employees obtain a Covid-19 vaccine or submit to weekly testing.

## CNBC show co-host shows positive tests on-air: 'I have Covid'
 - [https://www.cnn.com/videos/business/2021/12/20/jim-cramer-covid-orig.cnn-business](https://www.cnn.com/videos/business/2021/12/20/jim-cramer-covid-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 16:52:32+00:00

"Squawk on the Street" co-host Jim Cramer anchored his CNBC show from his home office today, explaining that he tested positive for Covid last week.

## Maryland Gov. Larry Hogan tests positive for Covid-19
 - [https://www.cnn.com/2021/12/20/politics/larry-hogan-covid-19/index.html](https://www.cnn.com/2021/12/20/politics/larry-hogan-covid-19/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 16:25:19+00:00

Maryland Gov. Larry Hogan tested positive for Covid-19, he tweeted Monday.

## Data shows that Moderna's current dose can increase antibody levels 37 times higher than pre-boost levels
 - [https://www.cnn.com/2021/12/20/health/moderna-booster-omicron-bn/index.html](https://www.cnn.com/2021/12/20/health/moderna-booster-omicron-bn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 16:20:53+00:00

Biotechnology company Moderna announced Monday that preliminary data suggests its half-dose booster shot increased antibody levels against Omicron compared with the levels seen when a fully vaccinated person does not receive a booster -- and a larger-sized dose of the booster increases antibody levels even more.

## Poppy Harlow and her kids make grandma's apple crisp
 - [https://www.cnn.com/videos/us/2021/12/18/poppy-harlow-apple-crisp-recipe-orig-cnnhosts.cnn](https://www.cnn.com/videos/us/2021/12/18/poppy-harlow-apple-crisp-recipe-orig-cnnhosts.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 16:14:13+00:00

Poppy Harlow teaches her kids how to make her mom's apple crisp. Click here for the full recipe.

## Storm clouds gather over the global economy
 - [https://www.cnn.com/2021/12/20/investing/markets-stocks-oil/index.html](https://www.cnn.com/2021/12/20/investing/markets-stocks-oil/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 16:07:16+00:00

Investors hoping for an easy Christmas week could be sorely disappointed as stocks and oil prices tumble in the face of growing threats to the global economy.

## This asteroid sample could reveal our solar system's origin story
 - [https://www.cnn.com/2021/12/20/world/ryugu-asteroid-sample-study-scn/index.html](https://www.cnn.com/2021/12/20/world/ryugu-asteroid-sample-study-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 16:06:34+00:00

Just over a year after Japan's Hayabusa2 mission returned the first subsurface sample of an asteroid to Earth, scientists have determined that the near-Earth asteroid Ryugu is a pristine remnant from the formation of our solar system.

## CNN's Poppy Harlow shares a simple apple crisp recipe passed down from her mother
 - [https://www.cnn.com/2021/12/20/health/apple-crisp-recipe-poppy-harlow-wellness-cnnhosts/index.html](https://www.cnn.com/2021/12/20/health/apple-crisp-recipe-poppy-harlow-wellness-cnnhosts/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 15:54:21+00:00

CNN's Poppy Harlow shares an apple crisp that's easy to make and easy to eat -- and fun for kids helping in the kitchen.

## Trump sues NY attorney general, seeking to stop investigation into his company
 - [https://www.cnn.com/collections/intl-trump-ny-investigation-1220/](https://www.cnn.com/collections/intl-trump-ny-investigation-1220/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 15:42:37+00:00



## Trevor Noah files suit against New York hospital claiming negligence
 - [https://www.cnn.com/2021/12/20/entertainment/trevor-noah-hospital-suit/index.html](https://www.cnn.com/2021/12/20/entertainment/trevor-noah-hospital-suit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 15:30:18+00:00

Comedian and late night host Trevor Noah has filed a lawsuit against his doctor and a New York City hospital alleging that their negligence caused him to "sustain permanent, severe and grievous injuries," according to the complaint obtained by CNN.

## Moderna booster shot increases antibody levels against Omicron, company says
 - [https://www.cnn.com/collections/intl-covid-1219/](https://www.cnn.com/collections/intl-covid-1219/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 15:20:53+00:00



## Stocks tumble and oil sinks as storm clouds gather over global economy
 - [https://www.cnn.com/collections/intl-economy-covid/](https://www.cnn.com/collections/intl-economy-covid/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 15:17:16+00:00



## NBA to allow teams with Covid-19 issues to sign replacement players, memo says
 - [https://www.cnn.com/2021/12/20/sport/nba-replacement-players-covid-19-spt-intl/index.html](https://www.cnn.com/2021/12/20/sport/nba-replacement-players-covid-19-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 15:07:13+00:00

The National Basketball Association (NBA) will allow teams dealing with Covid-19 issues to add replacement players due to the rising number of cases, according to a memo dated Sunday and obtained by CNN on Monday.

## Tashkent: Surprising street food and underground art in Uzbekistan's capital
 - [https://www.cnn.com/travel/article/tashkent-uzbekistan-street-food-undergound-spc-intl/index.html](https://www.cnn.com/travel/article/tashkent-uzbekistan-street-food-undergound-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 15:01:48+00:00

It is a little peculiar in this day and age to visit places very few Westerners have any knowledge of. Uzbekistan, and its capital city Tashkent, seem to fit into that category.

## This woman wants more female coders in Uzbekistan
 - [https://www.cnn.com/2021/12/20/world/female-coders-uzbekistan-spc-intl/index.html](https://www.cnn.com/2021/12/20/world/female-coders-uzbekistan-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 14:59:54+00:00

In a state-of-the art communal workspace in the Uzbekistan capital of Tashkent, Durdona Bakhronova sits surrounded by women and young students.

## Closing arguments are set to begin today in the Ghislaine Maxwell trial
 - [https://www.cnn.com/2021/12/20/us/ghislaine-maxwell-trial-monday-closing-arguments/index.html](https://www.cnn.com/2021/12/20/us/ghislaine-maxwell-trial-monday-closing-arguments/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 14:58:42+00:00

Closing arguments are set to begin Monday morning in Manhattan in the federal trial of Ghislaine Maxwell, the longtime confidante of Jeffrey Epstein.

## Metallica plays 1997 song live for first time at 40th anniversary concert
 - [https://www.cnn.com/2021/12/20/entertainment/metallica-fixxxer-40th-anniversary-concert/index.html](https://www.cnn.com/2021/12/20/entertainment/metallica-fixxxer-40th-anniversary-concert/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 14:47:34+00:00

Metallica went for the rare and deep cuts as they celebrated their 40th anniversary over the weekend.

## Carlos Marín, Il Divo singer, dead at 53
 - [https://www.cnn.com/2021/12/20/entertainment/il-divo-carlos-marin-dead-intl-scli/index.html](https://www.cnn.com/2021/12/20/entertainment/il-divo-carlos-marin-dead-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 14:39:15+00:00

Carlos Marín, one quarter of the pop-opera group Il Divo, has died at the age of 53.

## The island where Venice began
 - [https://www.cnn.com/travel/article/torcello-venice-island/index.html](https://www.cnn.com/travel/article/torcello-venice-island/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 14:30:23+00:00

Flying into Venice, on the right hand side of the airplane, you'll see the city unfurl beneath you: a mass of terracotta roofs, brick bell towers and those canals, knitting the 118 islands of Venice together.

## Doctor treating Omicron in South Africa: 'We are over the curve'
 - [https://www.cnn.com/videos/health/2021/12/20/south-african-doctor-omicron-coronavirus-cases-decline-newday-vpx.cnn](https://www.cnn.com/videos/health/2021/12/20/south-african-doctor-omicron-coronavirus-cases-decline-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 14:22:15+00:00

Dr. Angelique Coetzee, one of the first doctors in South Africa to treat patients infected with the Omicron variant, joins CNN New Day to share information on the decline in cases in the country where Omicron was first detected.

## Lil Durk proposes during concert
 - [https://www.cnn.com/2021/12/20/entertainment/lil-durk-india-royale-engaged/index.html](https://www.cnn.com/2021/12/20/entertainment/lil-durk-india-royale-engaged/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 14:14:33+00:00

Lil Durk and his girlfriend of four years, India Royale, are engaged.

## 'The world's best place to be a woman' is being sued for misogyny
 - [https://www.cnn.com/2021/12/20/europe/iceland-domestic-violence-intl-cmd/index.html](https://www.cnn.com/2021/12/20/europe/iceland-domestic-violence-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 13:54:13+00:00

The bruises on Maria Árnadóttir's body were numerous, ranging in color from pale yellow to deep purple.

## Hong Kong sees record low voter turnout in first 'China patriots only' election
 - [https://www.cnn.com/2021/12/19/asia/hong-kong-election-turnout-intl-hnk/index.html](https://www.cnn.com/2021/12/19/asia/hong-kong-election-turnout-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 13:52:51+00:00

Hong Kong's first "patriots only" legislative election witnessed a record low turnout on Sunday, reflecting a steep decline in civic and political engagement following Beijing's overhaul of the city's electoral processes.

## Rapper Wiz Khalifa says it's time for musicians to stop beefing
 - [https://www.cnn.com/2021/12/20/entertainment/wiz-khalifa-peace-intl-scli/index.html](https://www.cnn.com/2021/12/20/entertainment/wiz-khalifa-peace-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 13:29:55+00:00

Hip-hop star Wiz Khalifa is calling for peace in the entertainment industry following the violent deaths of fellow rappers Drakeo the Ruler and Young Dolph.

## Rafael Nadal tests positive for Covid following Abu Dhabi comeback
 - [https://www.cnn.com/2021/12/20/tennis/rafael-nadal-covid-19-positive-test-spt-intl/index.html](https://www.cnn.com/2021/12/20/tennis/rafael-nadal-covid-19-positive-test-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 12:57:53+00:00

Rafael Nadal has tested positive for Covid-19 after arriving back in Spain from Abu Dhabi, the 20-time grand slam champion said on Monday.

## Fearing torture and possible execution, Iranian powerlifter quit team in Norway and ran for his life
 - [https://www.cnn.com/2021/12/20/sport/amir-assadollahzadeh-powerlifter-iran-cmd-spt-intl/index.html](https://www.cnn.com/2021/12/20/sport/amir-assadollahzadeh-powerlifter-iran-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 12:29:22+00:00

Athletes who are good enough to compete in the world championships are among the very best in their field. They dedicate their lives to the pursuit of their craft, they are proud to represent their countries, and they all dream of returning home with medals around their necks.

## Quidditch leagues to change name, citing J.K. Rowling's 'anti-trans positions'
 - [https://www.cnn.com/2021/12/20/sport/quidditch-league-name-change-scli-intl-spt/index.html](https://www.cnn.com/2021/12/20/sport/quidditch-league-name-change-scli-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 12:02:58+00:00

Two US quidditch leagues are set to choose a new name for the "Harry Potter"-inspired sport, due to trademark issues and concerns over the "anti-trans positions" of the series' author, J.K. Rowling.

## Pope Francis says domestic violence against women is 'almost satanic'
 - [https://www.cnn.com/2021/12/20/world/pope-francis-domestic-violence-intl-scli/index.html](https://www.cnn.com/2021/12/20/world/pope-francis-domestic-violence-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 11:01:05+00:00

Pope Francis has said that men who commit violence against women engage in something that is "almost satanic."

## Julia Ducournau explains the crippling love beneath her beautiful dark twisted fantasy 'Titane'
 - [https://www.cnn.com/style/article/julia-ducournau-titane-interview-palme-dor-oscars-intl/index.html](https://www.cnn.com/style/article/julia-ducournau-titane-interview-palme-dor-oscars-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 10:39:27+00:00

Julia Ducournau lights a cigarette, as if to punctuate her point. The French writer-director had been musing about love in her film "Titane," a through line buried beneath much hysteria since it won the Palme d'Or at the Cannes Film Festival earlier this year. Love, she insisted, is the foundation of the whole movie -- though it's intractable.

## How this fitness gear startup made a name for itself
 - [https://www.cnn.com/2021/12/20/middleeast/squatwolf-social-influencers-spc-intl/index.html](https://www.cnn.com/2021/12/20/middleeast/squatwolf-social-influencers-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 10:31:22+00:00

In just a few years, a Dubai fitness-gear startup has gone from a local to a global brand.

## Emma Raducanu voted BBC Sports Personality of the Year
 - [https://www.cnn.com/2021/12/20/tennis/raducanu-bbc-sports-personality-of-the-year-spti-intl/index.html](https://www.cnn.com/2021/12/20/tennis/raducanu-bbc-sports-personality-of-the-year-spti-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 10:13:12+00:00

Tennis player Emma Raducanu was voted BBC Sports Personality of the Year on Sunday, receiving British sport's annual individual accolade as a reward for her remarkable U.S. Open triumph.

## The Ashes: Australia beat England by 275 runs in Adelaide test
 - [https://www.cnn.com/2021/12/20/sport/ashes-england-australia-second-test-adelaide-spt-intl/index.html](https://www.cnn.com/2021/12/20/sport/ashes-england-australia-second-test-adelaide-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 10:02:06+00:00

Australia beat England by 275 runs in the day-night second Ashes test at the Adelaide Oval on Monday to go 2-0 up in the five-match series.

## Leftist becomes Chile's youngest-ever President after beating right-wing rival
 - [https://www.cnn.com/2021/12/19/americas/chile-election-gabriel-boric-intl-nk/index.html](https://www.cnn.com/2021/12/19/americas/chile-election-gabriel-boric-intl-nk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 09:28:49+00:00

Leftist and former student leader Gabriel Boric, 35, will become Chile's youngest President since its return to democracy in 1990, after he won a presidential runoff election on Sunday.

## Photo appears to show Boris Johnson drinking wine with staff during Covid lockdown
 - [https://www.cnn.com/2021/12/20/uk/boris-johnson-garden-drinking-photo-intl-hnk/index.html](https://www.cnn.com/2021/12/20/uk/boris-johnson-garden-drinking-photo-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 09:20:19+00:00

A photo has emerged that appears to show British Prime Minister Boris Johnson drinking wine with Downing Street staff during the country's first coronavirus lockdown last year.

## Why gender-neutral holiday presents matter for your children
 - [https://www.cnn.com/2021/12/20/health/gender-neutral-presents-wellness/index.html](https://www.cnn.com/2021/12/20/health/gender-neutral-presents-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 09:09:07+00:00

Irina Gonzalez found the perfect Christmas gift: a Mega Bloks wagon with lavender wheels and a pink basket. She was delighted to buy it — for her 20-month-old son.

## This 'lounging leopard' photo changed the life of a teen
 - [https://www.cnn.com/travel/article/skye-meaker-young-wildlife-photographer-south-africa-spc/index.html](https://www.cnn.com/travel/article/skye-meaker-young-wildlife-photographer-south-africa-spc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 08:40:24+00:00

If you were to ask a photographer the recipe for the perfect shot, you'll likely get a list of ingredients that include time of day, lighting, framing and a dash of luck. South African wildlife photographer Skye Meaker sees things differently.

## Xi Jinping has been taking on China's capitalists. Here's why that will change in 2022
 - [https://www.cnn.com/2021/12/19/economy/china-2022-economic-priorities-mic-intl-hnk/index.html](https://www.cnn.com/2021/12/19/economy/china-2022-economic-priorities-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 07:18:49+00:00

One year ago, Chinese leader Xi Jinping pledged to spend 2021 reining in "disorderly" private businesses that were growing too powerful and taking on too much risk.

## How close is the US to civil war? Closer than you think, study says
 - [https://www.cnn.com/videos/politics/2021/12/20/us-civil-war-study-barbara-walter-intvu-intl-ovn-vpx.cnn](https://www.cnn.com/videos/politics/2021/12/20/us-civil-war-study-barbara-walter-intvu-intl-ovn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 06:39:39+00:00

CNN's Michael Holmes talks with Professor Barbara Walter of the University of California San Diego about her work on a task force that tries to predict where outside the US a civil war is likely to break out. Walter says the two best predictors of whether violence is likely to occur currently exist in the US and have emerged at a "surprisingly fast rate."

## Peng Shuai denies making sexual assault allegation against retired Communist Party leader, but WTA concerns persist
 - [https://www.cnn.com/2021/12/20/tennis/peng-shuai-retracts-sexual-assault-allegations-intl-hnk/index.html](https://www.cnn.com/2021/12/20/tennis/peng-shuai-retracts-sexual-assault-allegations-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 06:14:11+00:00

Chinese tennis star Peng Shuai has denied making sexual assault allegations against a retired Communist Party leader, following more than a month of growing concern about her safety and whereabouts that led to the Women's Tennis Association pulling out of China.

## Death toll from Super Typhoon Rai climbs to at least 208 people in the Philippines
 - [https://www.cnn.com/2021/12/19/asia/super-typhoon-rai-philippines-75-dead-intl/index.html](https://www.cnn.com/2021/12/19/asia/super-typhoon-rai-philippines-75-dead-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-20 05:43:37+00:00

The death toll from Super Typhoon Rai has climbed to at least 75 people, local officials reported Saturday, after the storm wreaked havoc across the Philippines late last week.

