## Tesla allegedly remotely unlocks Model 3 owner's car, uses smart summon to help repo agent - Alt Car news
 - [https://tiremeetsroad.com/2021/03/18/tesla-allegedly-remotely-unlocks-model-3-owners-car-uses-smart-summon-to-help-repo-agent/](https://tiremeetsroad.com/2021/03/18/tesla-allegedly-remotely-unlocks-model-3-owners-car-uses-smart-summon-to-help-repo-agent/)
 - RSS feed: https://tiremeetsroad.com
 - date published: 2021-12-20 16:34:29+00:00

Tesla remotely activated smart summon, locate, and unlock to help a repo agent reposess a car after an owner fell behind on payments.

