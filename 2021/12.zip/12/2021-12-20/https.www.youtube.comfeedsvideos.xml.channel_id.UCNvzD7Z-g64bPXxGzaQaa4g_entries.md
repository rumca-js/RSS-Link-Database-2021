# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 20 Best PC Games of 2021
 - [https://www.youtube.com/watch?v=gmtZS0brRH4](https://www.youtube.com/watch?v=gmtZS0brRH4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-21 00:00:00+00:00

2021 had a metric ton of great games for PC. Here are all of the games that we think are worth your time.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

20-Forza Horizon 5 

Platform : PC Xbox One XSX|S

Release date : 9 November 2021



19-Hell Let Loose 

Platform : PC PS5 XSX|S

Release date : July 27, 2021



18- Pathfinder: Wrath of the Righteous

Platform : PC

Release date : 2 September 2021



17-Ready or Not 

Platform : PC

Release date : 18 Dec, 2021



16-Back 4 Blood 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release date : October 12, 2021 



15-Scarlet Nexus

Platform : PC PS4 PS5 Xbox One XSX|S 

Release date : June 25, 2021 

 

14-MARVEL'S Guardians of the Galaxy 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release date : October 26, 2021 



13-Humankind

Platform : PC Stadia 

Release date : 17 August 2021 



12-It Takes Two

Platform : PC PS4 PS5 Xbox One XSX|S 

Release date : March 26, 2021 



11-The Ascent

Platform : PC Xbox One XSX|S

Release date : 29 July 2021 



10-Hitman 3

Platform : PC PS4 PS5 Xbox One XSX|S Switch Stadia 

Release date : 20 January 2021 



9-Deathloop

Platform : PC PS5 

Release date : 14 September 2021 



8-Tales of Arise 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release date : September 10, 2021 



7-DEATH'S DOOR 

Platform : PC XBOX ONE XSX|S PS4 PS5 Switch 

Release date : July 20, 2021 



6-The Forgotten City 

Platform : PC XBOX ONE XSX|S PS4 PS5 Switch 

Release date : Standalone game 28 July 2021



5-Chivalry 2 

Platform : PC XBOX ONE XSX|S PS4 PS5 

Release date : June 8, 2021



4-Halo Infinite 

Platform : PC Xbox One XSX|S  

Release date : December 8, 2021 



3-Eastward 

Platform : PC Switch 

Release date : September 16, 2021 



2-Resident Evil Village 

Platform : Stadia PC XBOX ONE XSX|S PS4 PS5 

Release date : May 7, 2021 



1-AGE OF EMPIRES IV 

Platform : PC 

Release date : October 28, 2021 



BONUS

WilderMyth

Platform : PC

Release date : 15 Jun, 2021 



LONE ECHO II

Platform : Oculus Rift, Oculus Rift S 

Release date : October 12, 2021 



Kena: Bridge of Spirits

Platform : PC PS4 PS5 

Release date : September 21, 2021 



Hot wheels Unleashed

Platform : PC PS4 PS5 Xbox One XSX|S Switch  

Release date : September 30, 2021 



Little Nightmares 2 

Platform : PC PS4 Stadia Xbox One Switch PS5 XSX|S  

Release date :  11 February 2021 



ENDER LILIES: Quietus of the Knights 

Platform : PC Switch PS4 XBOX ONE XSX|S 

Release date : June 22, 2021 



Mass Effect Legendary Edition 

Platform : PC PS4 Xbox one 

Release date : May 14, 2021 



CHICORY: A COLORFUL TALE 

Platform : PC PS4 PS5 

Release date : June 10, 2021 



GRIME 

Platform : PC Stadia 

Release date : August 2, 2021 

                                                                       

Psychonauts 2

Platform : PC PS4 Xbox One XSX|S

Release date : August 25, 2021

0:00 Intro 
0:13 Forza Horizon 5 
0:45 Hell Let Loose 
1:30 Pathfinder: Wrath of the Righteous
2:06 Ready or Not  
3:10 Back 4 Blood 
3:43 Scarlet Nexus
4:24 MARVEL'S Guardians of the Galaxy 
5:20 Humankind
6:07 It Takes Two
7:04 The Ascent
7:43 Hitman 3
8:26 Deathloop
9:07 Tales of Arise 
9:45 DEATH'S DOOR 
10:28 The Forgotten City 
11:01 Chivalry 2 
11:51 Halo Infinite 
12:49 Eastward 
13:33 Resident Evil Village 
14:36 AGE OF EMPIRES IV 
15:29 BONUS

## 10 MIND BLOWING Opening Levels in Video Games
 - [https://www.youtube.com/watch?v=J77s9uZ0EaE](https://www.youtube.com/watch?v=J77s9uZ0EaE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-12-20 00:00:00+00:00

Some video games really kick off with a bang. Here are some of favorite crazy openings and starting twists in video games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

