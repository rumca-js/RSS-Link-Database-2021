# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Scientists Have Discovered The Largest Structure In The Universe | Lightning Round
 - [https://www.youtube.com/watch?v=7-xK54HRm20](https://www.youtube.com/watch?v=7-xK54HRm20)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-12-20 00:00:00+00:00

Get a year of Nebula and CuriosityStream for only $11.59 if you sign up at http://www.curiositystream.com/joescott before December 24th!
In today's Lightning Round video, I answer questions from Patreon supporters on topics such as the Giant Arc - possibly the largest structure ever discovered in the universe, how autonomous cars will change industries, geopolitical instability, and whether phones can actually disrupt commercial aircraft.

Listen to my conversation with Neil Degrasse Tyson here:
https://answerswithjoe.com/dropping-science-neil-degrasse-tyson/

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.mic.com/life/do-airplane-rules-like-turning-off-your-phone-during-takeoff-really-matter-pilots-reveal-the-truth-18207261

https://www.fool.com/investing/2018/06/11/driverless-cars-will-impact-these-5-industries.aspx

http://www.sci-news.com/astronomy/giant-arc-09768.html

https://www.sciencenews.org/article/galaxy-giant-arc-3-billion-light-years-long-cosmology-space/amp

