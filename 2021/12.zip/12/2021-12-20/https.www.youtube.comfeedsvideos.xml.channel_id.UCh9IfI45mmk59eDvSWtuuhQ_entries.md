# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## When You Need A YouTube Video To Fix Something
 - [https://www.youtube.com/watch?v=d8fJPvXyfc0](https://www.youtube.com/watch?v=d8fJPvXyfc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-12-20 00:00:00+00:00

Get 50% OFF your first 6-bottle box http://bit.ly/BrightCellarsRyanGeorge3 for $53 plus taxes. Bright Cellars is the monthly wine club that matches you with wine that you’ll love. Get started by taking the taste palate quiz to see your personalized matches.

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

