# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## How Do We Know We’re Tired?
 - [https://www.youtube.com/watch?v=VXFCQtyAV-E](https://www.youtube.com/watch?v=VXFCQtyAV-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-12-21 00:00:00+00:00

Go to http://Brilliant.org/SciShow to try their Applied Probability course. Sign up now and get 20% off an annual Premium subscription.

Sleep is complicated. And there's still a lot we don't know about it, but zebrafish larvae are a surprisingly good place to look to learn more about what makes us sleepy.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, Jason A Saslow, charles george, Christoph Schwanke, Ash, Bryan Cloer, Silas Emrys, Eric Jensen, Adam Brainard, Piya Shedden, Jeremy Mysliwiec, Alex Hackman, GrowingViolet, Sam Lutfi, Alisa Sherbow, Dr. Melvin Sanicas, Melida Williams, Tom Mosner

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.sciencedirect.com/science/article/abs/pii/S1097276521009333?via%3Dihub
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5465131/
https://www.sciencedirect.com/science/article/pii/S2451994417300068
https://journals.plos.org/plosbiology/article?id=10.1371/journal.pbio.0050277

Images:
https://www.istockphoto.com/photo/man-snores-at-night-gm1225328904-360616144
https://www.storyblocks.com/video/stock/extremely-tired-overworked-woman-yawning-and-expressing-exhaustion-inside-during-the-day-h6qbv2eqwj7ckwpm7
https://www.istockphoto.com/vector/circadian-rhythm-human-biological-clock-gm1267110107-371661187
https://www.cdc.gov/niosh/work-hour-training-for-nurses/longhours/mod2/11.html
https://commons.wikimedia.org/wiki/File:DNA_UV_mutation.svg
https://www.istockphoto.com/photo/tired-young-woman-sleeping-on-couch-at-home-gm1258280097-368967365
https://commons.wikimedia.org/wiki/File:CSIRO_ScienceImage_7598_larval_zebra.jpg
https://commons.wikimedia.org/wiki/File:Protein_PARP1_PDB_1uk0.png
https://www.flickr.com/photos/nichd/17104754320
https://journals.plos.org/plosbiology/article?id=10.1371/journal.pbio.0020148
https://www.istockphoto.com/vector/seamless-black-dice-isolated-on-white-gm1307376965-397661859
https://www.istockphoto.com/vector/dna-molecular-break-gm472349465-26385996

