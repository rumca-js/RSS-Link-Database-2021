## New York bill would create literal internment camps for the unvaccinated at the Governor's whim – HotAir
 - [https://hotair.com/jazz-shaw/2021/12/20/new-york-bill-would-create-literal-internment-camps-for-the-unvaccinated-at-the-governors-whim-n436568](https://hotair.com/jazz-shaw/2021/12/20/new-york-bill-would-create-literal-internment-camps-for-the-unvaccinated-at-the-governors-whim-n436568)
 - RSS feed: https://hotair.com
 - date published: 2021-12-20 21:00:56+00:00

New York bill would create literal internment camps for the unvaccinated at the Governor's whim – HotAir

