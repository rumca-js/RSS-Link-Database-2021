# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Poliça - two songs at The Current (2011)
 - [https://www.youtube.com/watch?v=u11HID4tfD4](https://www.youtube.com/watch?v=u11HID4tfD4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-21 00:00:00+00:00

Ten years ago, Poliça visited The Current studio to record a session in advance of releasing their debut album "Give You the Ghost." At the time, frontwoman Channy Leaneagh said "The Maker" is her favorite song on the record. Watch two performances from that 2011 session.

SONGS PERFORMED
0:00 "The Maker"
4:08 "Wandering Star"

PERSONNEL
Channy Leaneagh - vocals, synth
Chris Bierden – bass
Drew Christopherson – drums
Ben Ivascu – drums
Ryan Olson – production 

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Jon Schober; David Campbell

FIND MORE:
2011 studio session: https://www.thecurrent.org/feature/2011/11/30/polica-live
2013 session in the MPR Forum: https://www.thecurrent.org/feature/2013/10/09/polica-ubs-forum-live
2016 studio session:
https://www.thecurrent.org/feature/2016/02/01/polica-perform-in-the-current-studio
2020 studio session: 
https://www.thecurrent.org/feature/2020/02/04/polica-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#polica #thisispolica #thecurrent

