# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Fake Covid passes advertised for sale online
 - [https://www.bbc.co.uk/news/business-59725531?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59725531?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 22:12:56+00:00

The BBC found Facebook posts claiming to sell Covid vaccine passes to people who hadn't been jabbed.

## Quiz of the Year, part one: Are you a 2021 news expert?
 - [https://www.bbc.co.uk/news/world-59634182?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-59634182?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 16:56:33+00:00

How well do you remember the news of the past 12 months?

## 'Astonishingly dangerous' pursuit at 80mph in Cambridge
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-59731083?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-59731083?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 13:18:05+00:00

Police dashcam shows a driver narrowly avoiding other cars and bikes while trying to evade officers.

## In pictures: Mountain summits 'float' above the clouds
 - [https://www.bbc.co.uk/news/uk-scotland-highlands-islands-59727407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-highlands-islands-59727407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 12:35:50+00:00

A weather phenomenon called a temperature inversion leads to some striking images on Scotland's hills.

## Strictly: Rose Ayling-Ellis on her historic Strictly win
 - [https://www.bbc.co.uk/news/entertainment-arts-59725698?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59725698?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 11:33:05+00:00

Watch the first interview the actor and her dance partner Giovanni Pernice gave after their victory.

## The Ashes: Australia beat England in second Test despite Jos Buttler resistance
 - [https://www.bbc.co.uk/sport/cricket/59723826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59723826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 10:27:53+00:00

Australia complete a 275-run victory over England in the final session of the second Ashes Test to take a 2-0 lead in the series.

## Spurs out of Europa Conference League after Uefa rules forfeit of Rennes match
 - [https://www.bbc.co.uk/sport/football/59725177?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59725177?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 10:26:26+00:00

Tottenham are out of the Europa Conference League after Uefa rules they forfeited their final match against Rennes.

## Leftist Gabriel Boric to become Chile's youngest ever president
 - [https://www.bbc.co.uk/news/world-latin-america-59715941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-59715941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 10:21:26+00:00

Gabriel Boric, 35, says he will look after democracy after a convincing win over his far-right rival.

## The Ashes: Australia win second Test as James Anderson is dismissed for two
 - [https://www.bbc.co.uk/sport/av/cricket/59724689?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/59724689?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 10:21:25+00:00

Australia win the second Ashes Test dismissing James Anderson for the final wicket off the bowling of Jhye Richardson.

## Covid: No guarantees over Christmas lockdown, says Dominic Raab
 - [https://www.bbc.co.uk/news/uk-59725266?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59725266?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 10:18:21+00:00

Ministers will keep reviewing the data "hour by hour" as they consider three options of Covid measures.

## Covid: Pubs and restaurants call for urgent help
 - [https://www.bbc.co.uk/news/business-59725527?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59725527?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 10:11:26+00:00

Hospitality firms say action is needed "in the next 24 hours" as they struggle with the Omicron impact.

## Covid-19: No 10 says garden photo shows work meeting
 - [https://www.bbc.co.uk/news/uk-politics-59722081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-59722081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 09:58:42+00:00

An image shows the PM, his wife and 17 staff members with wine in the No 10 garden allegedly during lockdown.

## Peng Shuai: Chinese tennis star denies making assault claim as concerns persist
 - [https://www.bbc.co.uk/news/world-asia-china-59723676?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-59723676?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 09:49:53+00:00

The Chinese tennis star says her post was misunderstood, but the WTA continues to demand an inquiry.

## The Ashes: Jos Buttler stands on his own stumps after long resistance
 - [https://www.bbc.co.uk/sport/av/cricket/59724688?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/59724688?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 09:46:37+00:00

England's Jos Buttler is out hit wicket after facing 207 balls for 26 in attempting to save the second Ashes Test in Adelaide.

## Tortured to death: Myanmar mass killings revealed
 - [https://www.bbc.co.uk/news/world-asia-59699556?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59699556?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 09:13:23+00:00

A BBC investigation finds evidence Myanmar's military killed 40 villagers in July, torturing some to death.

## Carlos Marin: Simon Cowell 'devastated' at death of Il Divo singer at 53
 - [https://www.bbc.co.uk/news/entertainment-arts-59722285?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59722285?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 08:41:09+00:00

The classical group's Carlos Marin died at the age of 53 after going into hospital during a UK tour.

## Covid: Vulnerable NHS patients to be offered new drug
 - [https://www.bbc.co.uk/news/health-59721240?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-59721240?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 08:01:23+00:00

The drug - sotrovimab - is given as an infusion to high-risk patients who have caught the virus.

## Covid: Garden photo shows 'work meeting' and shoppers avoid High Streets
 - [https://www.bbc.co.uk/news/uk-59721477?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59721477?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 07:53:39+00:00

Five things you need to know about the coronavirus pandemic this Monday morning.

## The Papers: PM at 'No 10 event in lockdown' and hints at curbs
 - [https://www.bbc.co.uk/news/blogs-the-papers-59722462?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59722462?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 05:22:07+00:00

Most front pages focus on potential tougher Covid restrictions by Christmas, amid a surge in cases.

## Chile election: Laser shone at Gabriel Boric during victory speech
 - [https://www.bbc.co.uk/news/world-latin-america-59722801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-59722801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 04:36:53+00:00

The bouncing green light did not seem to faze Gabriel Boric as he spoke to supporters in Santiago.

## The world's first octopus farm - should it go ahead?
 - [https://www.bbc.co.uk/news/science-environment-59667645?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59667645?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:59:28+00:00

The world’s first commercial octopus farm is closer to becoming reality - but scientists are up in arms.

## How to avoid gadget frustration on Christmas Day
 - [https://www.bbc.co.uk/news/technology-59699296?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-59699296?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:50:31+00:00

Modern tech gifts might not be ready to work straight away - are you ready for Christmas morning?

## Three decades of Brit: How the school was born
 - [https://www.bbc.co.uk/news/uk-england-london-59699274?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-59699274?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:49:28+00:00

More than 30 years after an "awe-inspiring" gig, how did one concert shape the music industry's future?

## Coronavirus: Is Christmas the time to lay off the daily diet of stats?
 - [https://www.bbc.co.uk/news/health-59704282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-59704282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:48:27+00:00

Should we be watching our daily data intake along with the Christmas chocolates this year?

## Pen Farthing: 'I was called disgusting over Kabul animal rescue'
 - [https://www.bbc.co.uk/news/uk-england-essex-59652240?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-59652240?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:43:21+00:00

Pen Farthing says he wants the truth to be known after being accused of putting pets above people.

## Pret A Manger customers complain over drinks subscription deal
 - [https://www.bbc.co.uk/news/business-59634846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59634846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:30:32+00:00

Thousands of customers have complained about the coffee and sandwich chain's drinks subscription service.

## Virtual reality worship: What carols at home looks like this Christmas
 - [https://www.bbc.co.uk/news/uk-59702426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59702426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:17:03+00:00

The Church of England has released a series of virtual reality carols

## What is the metaverse?
 - [https://www.bbc.co.uk/news/technology-59674930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-59674930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:16:05+00:00

From virtual versions of ourselves to augmented reality, we break down what the metaverse is.

## How to read your weather app
 - [https://www.bbc.co.uk/news/59638765?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59638765?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:13:35+00:00

What you need to know about weather forecasts on your phone

## Australia bouncy castle fall: Sixth child dies in hospital
 - [https://www.bbc.co.uk/news/world-australia-59722770?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-59722770?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:02:34+00:00

Chace Harrison, 11, died in hospital three days after falling from a castle blown into the air.

## The robot chefs that can cook your Christmas dinner
 - [https://www.bbc.co.uk/news/business-59651334?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59651334?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-12-20 00:00:38+00:00

If you fancy not having to do the cooking on 25 December then a robotic chef might be the solution.

