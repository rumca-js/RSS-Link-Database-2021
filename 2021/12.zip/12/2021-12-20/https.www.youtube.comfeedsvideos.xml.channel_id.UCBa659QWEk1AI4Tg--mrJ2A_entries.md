# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The hidden background noise that can catch criminals
 - [https://www.youtube.com/watch?v=e0elNU0iOMY](https://www.youtube.com/watch?v=e0elNU0iOMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-12-20 00:00:00+00:00

Electrical Network Frequency analysis, ENF analysis, matches background hum against power grid logs. I talked to one of the researchers who works on it, and also set them a challenge. Thanks to @answerinprogress, @hannahwitton and @SteveMould! 

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

