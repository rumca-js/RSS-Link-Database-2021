# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Omicron is now dominant Covid-19 variant in US, officials say
 - [https://www.theguardian.com/world/2021/dec/20/us-covid-omicron-coronavirus](https://www.theguardian.com/world/2021/dec/20/us-covid-omicron-coronavirus)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 23:50:24+00:00

<p>Variant accounted for 73% of new infections last week, nearly a six-fold increase within a week</p><p>Omicron is now the dominant version of the coronavirus in the US, federal health officials said on Monday, racing ahead of Delta and other variants and accounting for 73% of new infections last week.</p><p>The Centers for Disease Control and Prevention numbers showed nearly a six-fold increase in Omicron’s share of infections in only one week.</p> <a href="https://www.theguardian.com/world/2021/dec/20/us-covid-omicron-coronavirus">Continue reading...</a>

## PGA Tour gives players green light to play in Saudi International
 - [https://www.theguardian.com/sport/2021/dec/20/golf-pga-tour-allows-players-saudi-international](https://www.theguardian.com/sport/2021/dec/20/golf-pga-tour-allows-players-saudi-international)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 23:44:41+00:00

<ul><li>Dustin Johnson and Tommy Fleetwood among those set to play</li><li>£3.7m event in Jeddah clashes with AT&amp;T Pebble Beach Pro-Am</li></ul><p>The PGA Tour has announced it has given permission for players to compete in the Saudi International, which is due to take place from 3-6 February 2022.</p><p>Releases were granted with conditions related to the AT&amp;T Pebble Beach Pro-Am in California that is scheduled to take place in the same week.</p> <a href="https://www.theguardian.com/sport/2021/dec/20/golf-pga-tour-allows-players-saudi-international">Continue reading...</a>

## Raymond van Barneveld makes winning return to PDC world championship
 - [https://www.theguardian.com/sport/2021/dec/20/pdc-world-darts-championship-van-barneveld-wade](https://www.theguardian.com/sport/2021/dec/20/pdc-world-darts-championship-van-barneveld-wade)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 23:41:26+00:00

<ul><li>Dutchman beats Lourence Ilagan 3-0 after absence last year</li><li>James Wade punishes Maik Kuivenhoven misses in 3-1 win</li></ul><p>Raymond van Barneveld made a winning return to Alexandra Palace, beating Lourence Ilagan 3-0 to set up an intriguing second-round meeting with Rob Cross.</p><p>Van Barneveld, the 2007 PDC world champion, retired from darts after losing to Darin Young in the first round here in 2020, but quickly decided to return to the oche. The Dutchman, who missed the 2021 event, won the first set 3-1 and broke Ilagan early in the second before taking out 121 to go 2-0 up.</p> <a href="https://www.theguardian.com/sport/2021/dec/20/pdc-world-darts-championship-van-barneveld-wade">Continue reading...</a>

## Walmart illegally dumps 1m toxic items in landfills yearly, lawsuit claims
 - [https://www.theguardian.com/business/2021/dec/20/walmart-waste-california-lawsuit-dumping](https://www.theguardian.com/business/2021/dec/20/walmart-waste-california-lawsuit-dumping)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 23:35:05+00:00

<p>California attorney general accuses retail giant of failing to properly dispose of items including batteries, cleaning supplies and electronic waste</p><p>Walmart illegally dumps more than 1 million batteries, aerosol cans of insect killer and other products, toxic cleaning supplies, electronic waste, latex paints and other hazardous waste into California landfills each year, state prosecutors have alleged. </p><p>In a lawsuit announced on Monday, the California attorney general, Rob Bonta, accused the retail giant of failing to properly dispose of discarded or returned goods.</p> <a href="https://www.theguardian.com/business/2021/dec/20/walmart-waste-california-lawsuit-dumping">Continue reading...</a>

## Tornadoes and storms that hit US were a derecho, says National Weather Service
 - [https://www.theguardian.com/us-news/2021/dec/20/us-tornadoes-storms-derecho-national-weather-service](https://www.theguardian.com/us-news/2021/dec/20/us-tornadoes-storms-derecho-national-weather-service)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 23:22:06+00:00

<p>Derecho, often described as an inland hurricane, hit the north-central US on 15 December, separately from Kentucky tornadoes</p><p>The National Weather Service’s (NWS) <a href="https://www.weather.gov/lmk/derecho">storm prediction center</a> has described the multiple tornadoes and thunderstorms that struck the Great Plains and upper midwest last week as the result of a rare event called a derecho.</p><p>A derecho, often described as an inland hurricane, is derived from the Spanish word “derechos”, which means to “direct” or “straight ahead” and was first used in 1888 by a chemist and professor of physical sciences.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/us-tornadoes-storms-derecho-national-weather-service">Continue reading...</a>

## Primary school teacher sacked after being caught on film kicking horse
 - [https://www.theguardian.com/world/2021/dec/20/primary-school-teacher-sacked-after-being-caught-on-film-kicking-horse](https://www.theguardian.com/world/2021/dec/20/primary-school-teacher-sacked-after-being-caught-on-film-kicking-horse)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 23:05:46+00:00

<p>Footage of Sarah Moulds shared online by Hertfordshire Hunt Saboteurs viewed by millions in November</p><p>A primary school teacher has been sacked after footage of a horse being kicked and slapped sparked outrage on social media.</p><p>Sarah Moulds, 37, was initially suspended from her position after the video showed a horse being kicked in the torso, slapped repeatedly in the face and dragged back to a trailer.</p> <a href="https://www.theguardian.com/world/2021/dec/20/primary-school-teacher-sacked-after-being-caught-on-film-kicking-horse">Continue reading...</a>

## We Wish You a Mandy Christmas review – Diane Morgan does proper belly laughs
 - [https://www.theguardian.com/tv-and-radio/2021/dec/20/we-wish-you-a-mandy-christmas-review-diane-morgan-does-proper-belly-laughs](https://www.theguardian.com/tv-and-radio/2021/dec/20/we-wish-you-a-mandy-christmas-review-diane-morgan-does-proper-belly-laughs)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 22:16:06+00:00

<p>Camp, retro and enjoyable for a glass or two, this Christmas Carol revamp is full of surreal gags, with Johnny Vegas and John Cooper Clarke offering ghostly support</p><p>Mandy (BBC Two) is a curious creation, and this is a curious Christmas special. Diane Morgan’s short, tart comedy series arrived in the middle of 2020 with a sideways pout, an outstanding roster of northern royalty guest stars and six episodes that barely stretched to 15 minutes each. The first series was best watched in one sitting: lumping it all together gave it more heft than watching it in short snatches. By the end of the series, I started to feel as if I got the tone and had locked on to the dry, edge-of-surreal mood of it.</p><p>Morgan is, of course, a brilliant comedy performer. From Philomena Cunk half-arsing her way around Britain, to Liz puncturing the middle-class uppityness of her fellow parents in Motherland, her characters possess the ability to turn a deadpan line or a withering putdown into a lethal weapon. Mandy isn’t dry or droll, as such. She flops around town getting herself into scrapes, while smoking and ensuring her beehive remains perfectly perched. That is about the extent of it, although if you see each episode as an extended run-up to an outrageous, over-the-top gag, then its pace starts to make more sense. Whether Mandy is killing several members of the public due to negligent banana processing, watching a death by glitter ball or taking part in a wedding with a Shaun Ryder cameo, you mostly watch to see how bizarre the ending will be.</p> <a href="https://www.theguardian.com/tv-and-radio/2021/dec/20/we-wish-you-a-mandy-christmas-review-diane-morgan-does-proper-belly-laughs">Continue reading...</a>

## Ghislaine Maxwell’s sex-trafficking trial: jury begins deliberations
 - [https://www.theguardian.com/us-news/2021/dec/20/ghislaine-maxwell-trial-closing-arguments-jeffrey-epstein](https://www.theguardian.com/us-news/2021/dec/20/ghislaine-maxwell-trial-closing-arguments-jeffrey-epstein)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 22:06:20+00:00

<p>Prosecutors say Maxwell, who has pleaded not guilty to all charges, manipulated victims and groomed them for sexual abuse</p><ul><li><em>This article contains depictions of sexual abuse</em></li></ul><p>The jury began deliberating late on Monday afternoon in <a href="https://www.theguardian.com/us-news/ghislaine-maxwell">Ghislaine Maxwell</a>’s sex-trafficking trial in New York.</p><p>Closing arguments had wrapped up in federal court in Manhattan earlier on Monday with a simple, chilling message.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/ghislaine-maxwell-trial-closing-arguments-jeffrey-epstein">Continue reading...</a>

## Gun purchases accelerated in the US from 2020 to 2021, study reveals
 - [https://www.theguardian.com/us-news/2021/dec/20/us-gun-purchases-2020-2021-study](https://www.theguardian.com/us-news/2021/dec/20/us-gun-purchases-2020-2021-study)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 22:00:06+00:00

<p>More than 5 million adults became first-time gun owners between January 2020 and April 2021 compared to 2.4 million in 2019</p><p>Gun purchases accelerated in the US during 2020-2021 compared to 2019, with more than 5 million adults becoming first-time gun owners between January 2020 and April 2021 compared to 2.4 million adults in 2019, a study on new gun ownership reveals.</p><p>The survey, conducted by Professor Matt Miller at Northeastern University and published today in the <a href="https://www.acpjournals.org/journal/aim">Annals of Internal Medicine,</a> shows that between January 2019 and April this year, around 7.5m people, or 2.9% of all US adults who had not previously owned guns, purchased them.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/us-gun-purchases-2020-2021-study">Continue reading...</a>

## Unite launches inquiry into building costs of Birmingham project
 - [https://www.theguardian.com/uk-news/2021/dec/20/unite-launches-inquiry-into-building-costs-of-birmingham-project](https://www.theguardian.com/uk-news/2021/dec/20/unite-launches-inquiry-into-building-costs-of-birmingham-project)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 21:50:31+00:00

<p>Following leaked accounts, union’s new general secretary says possible ‘significant loss’ must be investigated</p><p>Unite is launching an independent inquiry into how the building costs of a hotel and conference centre in Birmingham spiralled into a “potentially significant loss” for the trade union.</p><p>The inquiry follows reports at the beginning of the year of <a href="https://www.theguardian.com/uk-news/2021/jan/26/unite-union-apparently-doubles-expenditure-hotel-project">leaked accounts</a> seeming to indicate that the union had overspent on the 170-room hotel and 1,000-person conference centre.</p> <a href="https://www.theguardian.com/uk-news/2021/dec/20/unite-launches-inquiry-into-building-costs-of-birmingham-project">Continue reading...</a>

## Mother and son guilty of killing boy, 17, in machete attack in London
 - [https://www.theguardian.com/uk-news/2021/dec/20/mother-and-son-guilty-of-killing-boy-17-in-machete-attack-in-london](https://www.theguardian.com/uk-news/2021/dec/20/mother-and-son-guilty-of-killing-boy-17-in-machete-attack-in-london)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 21:26:07+00:00

<p>Nichola Leighton and Tyreese Ulysses convicted over death of Levi Ernest-Morrison in Sydenham after she said he was ‘bothering’ her </p><p>A mother and her teenage son have been found guilty of killing a 17-year-old boy in a machete attack in south London.</p><p>Nichola Leighton, 36, and her son Tyreese Ulysses, 19, had been on trial along with three teenagers over the death of Levi Ernest-Morrison.</p> <a href="https://www.theguardian.com/uk-news/2021/dec/20/mother-and-son-guilty-of-killing-boy-17-in-machete-attack-in-london">Continue reading...</a>

## Covid restrictions unlikely before Christmas but PM watching data ‘hour by hour’
 - [https://www.theguardian.com/world/2021/dec/20/boris-johnson-avoids-more-covid-measures-for-now-but-rules-nothing-out](https://www.theguardian.com/world/2021/dec/20/boris-johnson-avoids-more-covid-measures-for-now-but-rules-nothing-out)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 21:06:15+00:00

<p>Boris Johnson caught between scientific advisers and his sceptical cabinet over action on Omicron</p><ul><li><a href="https://viewer.gutools.co.uk/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://viewer.gutools.co.uk/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>New Covid restrictions are unlikely to be imposed before Christmas amid deep cabinet divisions but Boris Johnson warned further measures remain on the table, with data on the threat of Omicron monitored “hour by hour”.</p><p>The prime minister was accused of failing to follow scientists’ advice on the need for immediate restrictions while leaving millions of people and businesses in limbo after a two-hour cabinet meeting ended with no decision on Monday.</p> <a href="https://www.theguardian.com/world/2021/dec/20/boris-johnson-avoids-more-covid-measures-for-now-but-rules-nothing-out">Continue reading...</a>

## Martin Rowson on the two faces of Boris Johnson — cartoon
 - [https://www.theguardian.com/commentisfree/picture/2021/dec/20/martin-rowson-on-the-two-faces-of-boris-johnson-cartoon](https://www.theguardian.com/commentisfree/picture/2021/dec/20/martin-rowson-on-the-two-faces-of-boris-johnson-cartoon)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:43:08+00:00

<a href="https://www.theguardian.com/commentisfree/picture/2021/dec/20/martin-rowson-on-the-two-faces-of-boris-johnson-cartoon">Continue reading...</a>

## Climate lawyer loses supreme court appeal over Heathrow leak
 - [https://www.theguardian.com/environment/2021/dec/20/climate-lawyer-loses-supreme-court-appeal-over-heathrow-leak](https://www.theguardian.com/environment/2021/dec/20/climate-lawyer-loses-supreme-court-appeal-over-heathrow-leak)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:36:24+00:00

<p>Tim Crosland was found in contempt for prematurely revealing court’s decision on third runway</p><p>A lawyer and climate campaigner who leaked the result of a supreme court ruling on the Heathrow airport expansion has lost an appeal against a contempt of court finding.</p><p>Tim Crosland, the director of environmental campaign group Plan B Earth, was found in contempt of court for prematurely revealing the court’s decision on Heathrow’s third runway 22 hours before it was made public in December 2020.</p> <a href="https://www.theguardian.com/environment/2021/dec/20/climate-lawyer-loses-supreme-court-appeal-over-heathrow-leak">Continue reading...</a>

## George Osborne’s family firm reports jump in costs in wake of Brexit
 - [https://www.theguardian.com/business/2021/dec/20/george-osborne-little-family-firm-costs-brexit](https://www.theguardian.com/business/2021/dec/20/george-osborne-little-family-firm-costs-brexit)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:29:03+00:00

<p>Osborne &amp; Little experienced ‘immediate adverse effect’ in January – but files pre-tax profit of £558,000 after cuts</p><p>The former chancellor <a href="https://www.theguardian.com/politics/georgeosborne">George Osborne</a>’s family wallpaper business has said that Brexit added £400,000 to its costs, as the company’s sales slid more than 16% during the Covid-19 pandemic.</p><p>Osborne &amp; Little, which is controlled by Osborne’s father, Sir Peter Osborne, said the UK’s exit from the EU had “an immediate adverse effect on profits” from January 2021, with unforeseen costs such as increased shipping payments and taxes on EU goods imported to the UK before being exported back to Europe.</p> <a href="https://www.theguardian.com/business/2021/dec/20/george-osborne-little-family-firm-costs-brexit">Continue reading...</a>

## The Guardian view on Boris Johnson’s Covid plan: decided by Tory rebels | Editorial
 - [https://www.theguardian.com/commentisfree/2021/dec/20/the-guardian-view-on-boris-johnsons-covid-plan-decided-by-tory-rebels](https://www.theguardian.com/commentisfree/2021/dec/20/the-guardian-view-on-boris-johnsons-covid-plan-decided-by-tory-rebels)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:27:45+00:00

<p>The prime minister’s behaviour, and the suggestion that he is beholden to no one, has provoked a crisis of government</p><p>A public that feels cheated by its prime minister knows that the holiday season will be cut short for the good of the NHS. The only question is when. Boris Johnson isn’t prepared to say what his plans are – for fear of a backlash, not from voters but from a mutinous party. Ordinary people want to, and will, do the right thing – perhaps only grudgingly in the reasonable belief that they have been deceived. The Guardian obtained a <a href="https://www.theguardian.com/politics/2021/dec/19/boris-johnson-and-staff-pictured-with-wine-in-downing-street-garden-in-may-2020" title="">picture</a> that showed Boris Johnson drinking wine with staff in the Downing Street garden. This looked like a social gathering, not a meeting – one which, by some accounts, turned into a late evening party. It took place when Covid rules meant that <a href="https://twitter.com/nazirafzal/status/1472655158911942662?s=20" title="">funerals were kept so small</a> that some family members could not attend. People tweeted to say that they were fined for breaking the lockdown at the time. The No 10 gathering appears, to the wider public, confirmation that Mr Johnson wants people to do as he says, not as he does.</p><p>Mr Johnson’s behaviour, and the suggestion that he is beholden to no one, has provoked a crisis of government. Caught between the spread of a highly infectious Omicron variant and a Tory revolt, the prime minister <a href="https://www.theguardian.com/politics/live/2021/dec/20/uk-covid-news-labour-picture-staff-meeting-christmas-cases-restrictions-lockdown-coronavirus-omicron-latest-updates?page=with:block-61c0b9b98f08d89d380f7338#block-61c0b9b98f08d89d380f7338" title="">dithered and delayed</a>. His own scientific advisers say that there are likely to be between 1,000 and 2,000 Covid hospital admissions a day in England by the end of the year. The case for more Covid restrictions, they say, is <a href="https://www.theguardian.com/politics/2021/dec/19/science-clear-case-more-covid-restrictions-overwhelming" title="">overwhelming</a>. Yet cabinet ministers dismiss the modelling – signalling to backbench rebels that they are with them. Others are perhaps afraid of being blamed for cancelling Christmas when people begin travelling around the country. Mr Johnson calculated that he was too weak in office to risk a Commons showdown with his party over new restrictions. Policy is being decided by Tory MPs, many of whom have no plan beyond “let Omicron rip”.</p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/the-guardian-view-on-boris-johnsons-covid-plan-decided-by-tory-rebels">Continue reading...</a>

## The Guardian view on Russia’s Nato demands: upping the ante | Editorial
 - [https://www.theguardian.com/commentisfree/2021/dec/20/the-guardian-view-on-russias-nato-demands-upping-the-ante](https://www.theguardian.com/commentisfree/2021/dec/20/the-guardian-view-on-russias-nato-demands-upping-the-ante)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:27:18+00:00

<p>The Kremlin’s demands that the western alliance withdraw troops from eastern Europe may be a prelude to military action in Ukraine</p><p>In a documentary broadcast this month to mark the 30th anniversary of the collapse of the Soviet Union, Vladimir Putin told interviewers that during the subsequent economic chaos, he had to supplement his KGB income by <a href="https://www.theguardian.com/world/2021/dec/13/vladimir-putin-says-he-resorted-to-taxi-driving-after-fall-of-soviet-union" title="">moonlighting</a> as a taxi driver. The personal struggles of Russia’s president in the 1990s were offered as a poignant vignette, symbolising the humiliating consequences of what Mr Putin has called “the greatest geopolitical disaster of the 20th century”.</p><p>In different circumstances, western leaders might be tempted to roll their eyes at the pretensions of one of the world’s most powerful bullies to victimhood. But Mr Putin’s 30th anniversary reminiscences were of a piece with an aggressively revanchist mood in Moscow, as tensions on Russia’s border with Ukraine continue to grow. About 100,000 Russian troops remain <a href="https://www.reuters.com/world/europe/ukraine-says-russia-has-nearly-100000-troops-near-its-border-2021-11-13/" title="">massed</a> close to eastern Ukraine, along with heavy weaponry and other hardware transported across thousands of miles. Western intelligence officials believe that no final decision has been taken by the Kremlin on whether to launch a military operation, after having backed separatist pro-Russian rebels in the Donbass region since 2014. But it seems clear that the sabre-rattling reflects a new determination to reassert Moscow’s eroded authority in what Mr Putin <a href="https://www.washingtonpost.com/world/2021/12/17/ukraine-russia-military/" title="">considers</a> Russia’s legitimate “sphere of influence”.</p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/the-guardian-view-on-russias-nato-demands-upping-the-ante">Continue reading...</a>

## Premier League in talks over rules for unvaccinated players amid 90 new Covid cases
 - [https://www.theguardian.com/football/2021/dec/20/liverpool-call-rejected-as-premier-league-presses-on-with-all-festive-fixtures](https://www.theguardian.com/football/2021/dec/20/liverpool-call-rejected-as-premier-league-presses-on-with-all-festive-fixtures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:17:42+00:00

<ul><li>No festive fixtures postponed yet despite surge in Covid cases</li><li>Separate travel among proposals for 16% who are still unjabbed</li></ul><p>Premier League clubs have discussed driving up vaccination rates in their squads by creating separate rules for players yet to get a Covid-19 jab. On a day when it emerged that 16% of top-flight players are unvaccinated and a record 90 positive tests had been recorded among players and staff in the week up to last Sunday, a two-tier system was raised at an emergency meeting.</p><p>Proposals include unvaccinated players travelling separately to games, facing an additional check to get into stadiums and having meals away from vaccinated teammates. The moves are designed to guard against more fixtures being cancelled as the clubs decided to press on with the season.</p> <a href="https://www.theguardian.com/football/2021/dec/20/liverpool-call-rejected-as-premier-league-presses-on-with-all-festive-fixtures">Continue reading...</a>

## Queen cancels Sandringham plans and will celebrate Christmas at Windsor
 - [https://www.theguardian.com/uk-news/2021/dec/20/queen-cancels-sandringham-plans-and-will-celebrate-christmas-at-windsor](https://www.theguardian.com/uk-news/2021/dec/20/queen-cancels-sandringham-plans-and-will-celebrate-christmas-at-windsor)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:15:27+00:00

<p>Monarch moves traditional festivities for second year in succession due to concerns over Covid </p><ul><li><a href="https://viewer.gutools.co.uk/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://viewer.gutools.co.uk/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>The Queen is to celebrate Christmas at Windsor Castle, breaking with the tradition of spending festivities at Sandringham in Norfolk for a second year.</p><p>Sources said the decision was a personal one taken after careful consideration and that it reflected her precautionary approach during the pandemic. Downing Street has been informed of her decision.</p> <a href="https://www.theguardian.com/uk-news/2021/dec/20/queen-cancels-sandringham-plans-and-will-celebrate-christmas-at-windsor">Continue reading...</a>

## Hostages held in Haiti escaped by slipping past armed guards in the night
 - [https://www.theguardian.com/world/2021/dec/20/hostages-haiti-escape](https://www.theguardian.com/world/2021/dec/20/hostages-haiti-escape)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:13:36+00:00

<p>Twelve kidnapped in October, including an infant and small child, walked hours by moonlight to safety</p><p>Kidnapped missionaries in Haiti <a href="https://www.theguardian.com/world/2021/dec/16/haiti-missionaries-released-gang-kidnapped">found freedom last week</a> by making a daring overnight escape, eluding their kidnappers and walking for miles over difficult, moonlit terrain with an infant and other children in tow, according to the agency they work for.</p><p>Ransom money was raised to pay for the release of the missionaries who were abducted on 16 October, but a dozen of them managed to flee, navigating by the stars to reach safety, Christian Aid Ministries said on Monday</p> <a href="https://www.theguardian.com/world/2021/dec/20/hostages-haiti-escape">Continue reading...</a>

## Basic failures at UK banks prompt much-needed zeal from regulators | Nils Pratley
 - [https://www.theguardian.com/business/nils-pratley-on-finance/2021/dec/20/basic-failures-at-natwest-and-stanchart-prompt-much-needed-zeal-from-regulators](https://www.theguardian.com/business/nils-pratley-on-finance/2021/dec/20/basic-failures-at-natwest-and-stanchart-prompt-much-needed-zeal-from-regulators)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:08:40+00:00

<p>Egregious oversight lapses at NatWest and Standard Chartered suggests boards are not earning their lavish pay</p><p>Last week’s £264m penalty and criminal conviction for NatWest for money-laundering failures still takes the prize for the most spectacular collapse we’ve seen in years in a bank’s controls department. The saga, almost unbelievably, involved <a href="https://www.theguardian.com/business/2021/dec/13/natwest-fined-264m-after-admitting-breaching-anti-money-laundering-rules">black bin bags, stuffed with as much as £700,000</a>, getting through the system.</p><p>But more mundane control failures also count, and Standard Chartered, the Asian-focused but London-listed bank, limped into view on Monday with a <a href="https://www.theguardian.com/business/2021/dec/20/standard-chartered-fined-bank-of-england-pra">£46.5m fine from the Bank of England’s Prudential Regulation Authority</a>.</p> <a href="https://www.theguardian.com/business/nils-pratley-on-finance/2021/dec/20/basic-failures-at-natwest-and-stanchart-prompt-much-needed-zeal-from-regulators">Continue reading...</a>

## Boy whose case inspired The Exorcist is named by US magazine
 - [https://www.theguardian.com/us-news/2021/dec/20/the-exorcist-boy-named-magazine](https://www.theguardian.com/us-news/2021/dec/20/the-exorcist-boy-named-magazine)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:06:05+00:00

<p>The boy, previously known as Roland Doe, underwent exorcisms in Cottage City, Maryland, and St Louis, Missouri, in 1949</p><p>The boy whose case inspired the portrayal of a demon-possessed child in the 1973 horror movie classic <a href="https://www.theguardian.com/film/the-exorcist">The Exorcist</a> has been named.</p><p>The US magazine the Skeptical Inquirer <a href="https://skepticalinquirer.org/2021/10/demoniac-who-is-roland-doe-the-boy-who-inspired-the-exorcist/">named</a> the then 14-year-old boy, previously known as Roland Doe, who underwent exorcisms in Cottage City, Maryland, and St Louis, Missouri, in 1949.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/the-exorcist-boy-named-magazine">Continue reading...</a>

## Calls for rerun of selection process to find next head of Charity Commission
 - [https://www.theguardian.com/society/2021/dec/20/calls-for-re-run-of-selection-process-to-find-next-head-of-charity-commission](https://www.theguardian.com/society/2021/dec/20/calls-for-re-run-of-selection-process-to-find-next-head-of-charity-commission)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 19:05:58+00:00

<p>Voluntary sector leaders say they have no confidence in appointments system after resignation of new watchdog chair</p><p>Voluntary sector leaders have called for a rerun of the process for choosing the next head of the charities regulator, saying they have no confidence in the appointments system after the <a href="https://www.theguardian.com/society/2021/dec/17/new-chair-of-charities-watchdog-resigns-week-after-his-appointment-to-role">shock resignation</a> of the new watchdog chair.</p><p>Martin Thomas, whose appointment as chair of the Charity Commission was <a href="https://www.theguardian.com/politics/2021/dec/10/mps-approve-new-charities-watchdog-chair-criticism-ministers">approved by a committee of MPs</a> this month, quit last Friday, just days before he was due to take up the job, over allegations he had acted inappropriately while chair of a women’s charity.</p> <a href="https://www.theguardian.com/society/2021/dec/20/calls-for-re-run-of-selection-process-to-find-next-head-of-charity-commission">Continue reading...</a>

## Who could replace Laura Kuenssberg as BBC political editor?
 - [https://www.theguardian.com/media/2021/dec/20/who-could-replace-laura-kuenssberg-as-bbc-political-editor](https://www.theguardian.com/media/2021/dec/20/who-could-replace-laura-kuenssberg-as-bbc-political-editor)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:53:52+00:00

<p>Kuenssberg will step down next year – but which journalists are ready to step into the hot seat?</p><p>Laura Kuenssberg has confirmed she will <a href="https://www.theguardian.com/media/2021/dec/20/laura-kuenssberg-step-down-bbc-political-editor-easter">step down as the BBC’s political editor at Easter</a> but will remain with the corporation in “a senior presenting and reporting role”. Here are the BBC journalists tipped to be possible replacements.</p> <a href="https://www.theguardian.com/media/2021/dec/20/who-could-replace-laura-kuenssberg-as-bbc-political-editor">Continue reading...</a>

## A routine morning for psycho Raab: 50 press-ups and a fumbled interview | John Crace
 - [https://www.theguardian.com/politics/2021/dec/20/a-routine-morning-for-psycho-raab-50-press-ups-and-a-fumbled-interview](https://www.theguardian.com/politics/2021/dec/20/a-routine-morning-for-psycho-raab-50-press-ups-and-a-fumbled-interview)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:53:51+00:00

<p>The justice secretary was in a broadcast studio again explaining why yet another party wasn’t one</p><p>It’s 5.30am. The alarm goes off. Dominic Raab is awake almost immediately. He’s always been a light sleeper. Dom gets out of bed and cranks out 50 press ups, the veins on his arms bulging pleasingly. He’s always prided himself on having the best guns in cabinet.</p><p>Raab strips off and wanders naked towards the bathroom. There’s nothing he likes more than an ice-cold shower. As the water pounds his body, he checks for tell-tale signs. Sure enough, there are traces of blood under his finger nails. He must have been on another killing spree the night before. The anger management course really is proving worse than useless. He tries to remember where he had been so he could retrace his steps and remove the evidence, but his mind is a blank. More bodies to add to the cold case count. Just as well the police now only investigate crimes that have yet to be committed. Psycho Killer. <em>Qu’est-ce que c’est</em>?</p> <a href="https://www.theguardian.com/politics/2021/dec/20/a-routine-morning-for-psycho-raab-50-press-ups-and-a-fumbled-interview">Continue reading...</a>

## Approval of new Covid jab raises hopes of persuading Germany’s unvaccinated
 - [https://www.theguardian.com/world/2021/dec/20/approval-new-covid-jab-germany-unvaccinated-novavax-nuvaxovid](https://www.theguardian.com/world/2021/dec/20/approval-new-covid-jab-germany-unvaccinated-novavax-nuvaxovid)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:34:11+00:00

<p>First doses of protein-based Nuvaxovid are expected to be used in new year after European Medicines Agency gives go-ahead</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>The approval of a new protein-based Covid-19 vaccine by the European Medicines Agency (EMA) has led to hopes that it could play an important role in persuading millions of Germans who have refused jabs from existing vaccines to get protection against the disease this winter.</p><p>The EMA approved the two-dose Novavax vaccine on Monday afternoon. The German government’s vaccination advisory board is expected to follow suit and allow for its use soon, a move that would be welcomed by health experts who are bracing for a huge and imminent wave of infections caused by the new Omicron variant. The first doses of Novavax are expected to be administered in Germany in the new year.</p> <a href="https://www.theguardian.com/world/2021/dec/20/approval-new-covid-jab-germany-unvaccinated-novavax-nuvaxovid">Continue reading...</a>

## Leading activist in Egypt’s 2011 uprising and two others jailed
 - [https://www.theguardian.com/world/2021/dec/20/leading-activist-in-egypts-2011-uprising-and-two-others-jailed](https://www.theguardian.com/world/2021/dec/20/leading-activist-in-egypts-2011-uprising-and-two-others-jailed)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:31:31+00:00

<p>Alaa Abd El-Fattah gets five years for ‘spreading false news’ and lawyer and blogger get four-year terms</p><p>A leading figure in Egypt’s 2011 uprising, his lawyer and a blogger have been served lengthy prison sentences in a Cairo court, in a move that observers have branded a further blow to human rights.</p><p>An emergency court on Monday sentenced activist Alaa Abd El-Fattah to five years in prison on charges of “spreading false news”. Human rights lawyer Mohamed El-Baqer, formerly Abd El-Fattah’s counsel, and blogger Mohamed “Oxygen” Ibrahim were both sentenced to four years in detention on the same charges.</p> <a href="https://www.theguardian.com/world/2021/dec/20/leading-activist-in-egypts-2011-uprising-and-two-others-jailed">Continue reading...</a>

## No 10 party is a slap in the face for those of us who lost loved ones | Letters
 - [https://www.theguardian.com/politics/2021/dec/20/no-10-party-is-a-slap-in-the-face-for-those-of-us-who-lost-loved-ones](https://www.theguardian.com/politics/2021/dec/20/no-10-party-is-a-slap-in-the-face-for-those-of-us-who-lost-loved-ones)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:20:40+00:00

<p>One reader recalls her son’s heartbreaking funeral on the day of a gathering in the Downing Street garden. Plus letters from <strong>Stephanie Gaunt, Keith Flett, Catherine Wykes, William Moloney, Maureen Vilar and Dr Paul Somerfield</strong></p><p>Today, 20 December, would have been my son’s 47th birthday. On 19 May 2020, four days after the picture was taken of the prime minister partying in the Downing Street garden (<a href="https://www.theguardian.com/politics/2021/dec/19/boris-johnson-and-staff-pictured-with-wine-in-downing-street-garden-in-may-2020" title="">Report, 19 December</a>), my son’s funeral took place. The number of people allowed to attend funerals was limited. In normal times the place would have been full. Church services were not allowed. No singing was allowed. You couldn’t even have an order of service printed. You could only have one floral arrangement, no other flowers. We had to sit at a two-metre distance from each other and wear masks throughout. We all had to leave and go straight home, as holding even a small socially distanced gathering was illegal. You were not allowed to meet indoors or in gardens and pubs, and restaurants were closed. Looking at the picture of a man with no moral compass justifying this as a work meeting is truly insulting.<br /><strong>Name and address supplied</strong></p><p>• As a human resources consultant with considerable experience, it concerns me greatly that according to your recent picture, 10 Downing Street apparently has no “alcohol at work” policy in force. No 10 may be a home, but it is also a workplace, and we have been assured that the photo shows a work meeting. A typical policy states: “The company requires all employees to report for duty free from the effects of alcohol and drugs. It is not acceptable to be under the influence of alcohol or drugs at work or consume alcohol or drugs during hours of work – this includes paid and unpaid breaks.”</p> <a href="https://www.theguardian.com/politics/2021/dec/20/no-10-party-is-a-slap-in-the-face-for-those-of-us-who-lost-loved-ones">Continue reading...</a>

## Wanted: former teachers who don’t mind risking their lives | Letter
 - [https://www.theguardian.com/education/2021/dec/20/wanted-former-teachers-who-dont-mind-risking-their-lives](https://www.theguardian.com/education/2021/dec/20/wanted-former-teachers-who-dont-mind-risking-their-lives)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:18:11+00:00

<p>Zero-hours contracts and exposure to Covid – <strong>Doreen Worthington </strong>on the delights of education policy under the Conservatives </p><p>You report that Nadhim Zahawi plans to encourage former teachers to help fill the gaps left by staff shortages (<a href="https://www.theguardian.com/education/2021/dec/16/omicron-covid-uk-schools-close-early-christmas" title="">Omicron leads many UK schools to close early for Christmas, 16 December</a>). How will that encouragement read? Might I suggest:</p><p>“Dear former teacher, we have made such a complete mess of protecting our vulnerable children and adults in schools, with no masks, distancing, air filtration or adequate ventilation, that many teachers are now absent from school suffering from Covid after repeated exposure to both the Delta and Omicron variants. Please would you, as a former teacher, sacrifice your own health to replace them, even though you probably left the job you loved because of our government’s educational mismanagement and contempt for your professionalism since 2010?</p> <a href="https://www.theguardian.com/education/2021/dec/20/wanted-former-teachers-who-dont-mind-risking-their-lives">Continue reading...</a>

## Talking Horses 2021 review: brilliant Blackmore shines in year of scandals
 - [https://www.theguardian.com/sport/2021/dec/20/talking-horses-2021-review-brilliant-blackmore-shines-in-year-of-scandals](https://www.theguardian.com/sport/2021/dec/20/talking-horses-2021-review-brilliant-blackmore-shines-in-year-of-scandals)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:06:00+00:00

<p>Covid and a number of scandals hit racing off the track, but on it history being made at Aintree took some beating</p><p>As recently as 2005, less than a year after saddling his fourth Grand National winner, the late trainer Ginger McCain, of Red Rum fame, made a confident prediction that a female jockey would never win the world’s most famous steeplechase.</p><p>At the time, it had been a decade since a woman had even taken part and only two of the 15 female jockeys who had ridden in the National managed to complete the race. </p> <a href="https://www.theguardian.com/sport/2021/dec/20/talking-horses-2021-review-brilliant-blackmore-shines-in-year-of-scandals">Continue reading...</a>

## Natural History Museum and Edinburgh Castle closed by Covid
 - [https://www.theguardian.com/culture/2021/dec/20/natural-history-museum-and-edinburgh-castle-closed-by-covid](https://www.theguardian.com/culture/2021/dec/20/natural-history-museum-and-edinburgh-castle-closed-by-covid)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 18:04:44+00:00

<p>Surge in cases among staff causes closure of several museums during busy school holiday period</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li></ul><p>At least five national attractions including the Natural History Museum and Edinburgh Castle have closed because of the surge in Covid cases.</p><p>The start of the Christmas school holidays is usually one of the busiest times at the Natural History Museum but it will be closed from Tuesday “due to an unforeseen staff shortage”.</p> <a href="https://www.theguardian.com/culture/2021/dec/20/natural-history-museum-and-edinburgh-castle-closed-by-covid">Continue reading...</a>

## Pity a public that has so many questions about Covid. Who should be believed? | Simon Jenkins
 - [https://www.theguardian.com/commentisfree/2021/dec/20/public-questions-about-covid-evidence](https://www.theguardian.com/commentisfree/2021/dec/20/public-questions-about-covid-evidence)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 17:50:01+00:00

<p>People need evidence if they are to accept more curbs on their liberties, but all we get are bland, unqualified statistics</p><p>British politics this week faces an intellectual crisis. It is one of whom to believe. With yet another <a href="https://www.theguardian.com/world/2021/dec/18/uk-scientists-curbs-covid-infections-omicron-deaths-restrictions-sage">wave of Covid</a> at full throttle, the cabinet is reportedly split on whether to rely on its one “winner” from the pandemic, vaccination, or whether to return to mass lockdown. There is no disputing that the Omicron variant is highly infectious. There is bitter argument about how to contain it.</p><p>On one side is a prime minister, Boris Johnson, and much of his party, pleading for no lockdown. Vaccination, they say, is the one sure defence against this disease. What matters is hospitalisations and, at <a href="https://coronavirus.data.gov.uk/details/healthcare">about 1,000 a day</a>, they are <a href="https://www.theguardian.com/world/2021/dec/16/omicron-could-lead-to-record-daily-covid-hospitalisations-chris-whitty-mps-told">far behind the 4,200</a> of January this year. Deaths are still further behind. Lockdown would savage the economy, even if relieved by state subsidy. It would bring back social and psychological isolation and devastate not just elderly people but often young people, too. The costs would be enormous.</p><p>Simon Jenkins is a Guardian columnist</p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/public-questions-about-covid-evidence">Continue reading...</a>

## UK train services hit ahead of Christmas as Covid causes staff shortages
 - [https://www.theguardian.com/uk-news/2021/dec/20/uk-train-services-hit-ahead-of-christmas-as-covid-causes-staff-shortages](https://www.theguardian.com/uk-news/2021/dec/20/uk-train-services-hit-ahead-of-christmas-as-covid-causes-staff-shortages)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 17:46:32+00:00

<p>Operators across the country announce cancellations and reduced capacity amid Omicron surge</p><ul><li><a href="https://viewer.gutools.co.uk/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://viewer.gutools.co.uk/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Staff shortages caused by a jump in Covid cases have started to impact UK train services ahead of the annual festive getaway, with rail operators across the country announcing cancellations for the rest of the week until Christmas.</p><p>Britain’s major long-distance operators are among the most affected by employees having to isolate at home because they or someone close to them has the virus.</p> <a href="https://www.theguardian.com/uk-news/2021/dec/20/uk-train-services-hit-ahead-of-christmas-as-covid-causes-staff-shortages">Continue reading...</a>

## May lockdown drinks: death and despair as No 10 staff mingled in the sunshine
 - [https://www.theguardian.com/society/2021/dec/20/death-and-despair-while-downing-street-nibbled-in-the-sunshine](https://www.theguardian.com/society/2021/dec/20/death-and-despair-while-downing-street-nibbled-in-the-sunshine)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 17:32:37+00:00

<p>Family and friends of those who died that day express anger over apparent breaking of rules</p><ul><li><strong><a href="https://www.theguardian.com/politics/2021/dec/19/chatting-over-cheese-and-wine-anatomy-downing-street-lockdown-gathering-picture">Anatomy of a lockdown gathering</a></strong></li><li><strong><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></strong></li></ul><p>On Friday 15 May 2020, NHS healthcare assistant Carlos Sia was one of 314 people who died after contracting Covid, passing away in the Worcestershire Royal hospital where he worked.</p><p>On the same day at the Lister hospital, Stevenage, 98-year-old Marjorie Bourke died of pneumonia and heart failure, alone, her relatives unable to be with her at the time of her passing.</p> <a href="https://www.theguardian.com/society/2021/dec/20/death-and-despair-while-downing-street-nibbled-in-the-sunshine">Continue reading...</a>

## England founder but even on a sinking ship the chairs can be arranged correctly | Barney Ronay
 - [https://www.theguardian.com/sport/blog/2021/dec/20/time-for-root-and-silverwood-to-abandon-doomed-company-policies-ashes](https://www.theguardian.com/sport/blog/2021/dec/20/time-for-root-and-silverwood-to-abandon-doomed-company-policies-ashes)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 17:30:13+00:00

<p>England’s Ashes campaign may have been doomed from the off but there are still objective standards of competence</p><p>Clang. Bring out your dead. There was something a little ghoulish about the spectacle down the wires from Adelaide as England’s last-wicket pair attempted to push the second Ashes Test into its final knockings on day five.</p><p>An Australian Ashes summer always has a strangeness about it seen from 10,000 miles away: those bleached-out greens and blues bounced around the world and beamed into the depths of a northern winter. Watching James Anderson and Stuart Broad fence and fend at the teeth-and-toes assault of the 6ft 6in, 92mph Mitchell Starc, it was hard to avoid the feeling of something hollow-eyed and ghostly; an emblem of the ill health of this tour but also of the wider entropy of English red-ball cricket, a grief that really is going to have to be processed at some point.</p> <a href="https://www.theguardian.com/sport/blog/2021/dec/20/time-for-root-and-silverwood-to-abandon-doomed-company-policies-ashes">Continue reading...</a>

## Pub landlord, caretaker and monarch sought for isolated Piel Island
 - [https://www.theguardian.com/uk-news/2021/dec/20/landlord-monarch-isolated-piel-island-cumbria-ship-inn](https://www.theguardian.com/uk-news/2021/dec/20/landlord-monarch-isolated-piel-island-cumbria-ship-inn)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 17:11:56+00:00

<p>New manager of the Ship Inn on small Cumbrian island will need to accept a few odd conditions</p><p>Wanted: someone with experience running a pub, a love of isolation and a willingness to mark their appointment by sitting on a throne and having beer poured over their head.</p><p>A council has begun one of the UK’s most unusual local government recruitment processes while seeking someone to run <a href="https://www.pielisland.co.uk/">the Ship Inn on Piel Island</a>, off the coast near Barrow-in-Furness. The downside might be the uncertain weather, or the isolation, or the long hours. On the upside, you can watch seals and birds, enjoy stunning sunsets and, if you have self-esteem issues, know you really will be a king or queen. It would sort of be official.</p> <a href="https://www.theguardian.com/uk-news/2021/dec/20/landlord-monarch-isolated-piel-island-cumbria-ship-inn">Continue reading...</a>

## New York attorney general vows Trump investigation will proceed ‘undeterred’
 - [https://www.theguardian.com/us-news/2021/dec/20/trump-new-york-state-attorney-general-letitia-james](https://www.theguardian.com/us-news/2021/dec/20/trump-new-york-state-attorney-general-letitia-james)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 17:01:21+00:00

<p>Former president sues Letitia James on grounds of political bias in effort to halt inquiry into his business affairs</p><ul><li><a href="https://www.theguardian.com/us-news/2021/dec/20/capitol-attack-investigation-closes-in-trump">Trump unnerved as Capitol attack investigation closes in</a></li></ul><p>The New York attorney general, <a href="https://www.theguardian.com/us-news/2019/may/07/the-thorn-in-trumps-side-new-york-attorney-general-leads-barrage-of-investigations">Letitia James</a>, said on Monday her investigation of Donald Trump’s business affairs would continue “undeterred”, despite Trump suing to stop it on grounds of political bias, “because no one is above the law, not even someone with the name Trump”.</p><p>The New York Times first <a href="https://www.nytimes.com/2021/12/20/nyregion/trump-lawsuit-letitia-james.html?campaign_id=60&amp;emc=edit_na_20211220&amp;instance_id=0&amp;nl=breaking-news&amp;ref=cta&amp;regi_id=70059035&amp;segment_id=77487&amp;user_id=40608e3f7e716b627f2eb1551778d56d">reported</a> Trump’s lawsuit, filed in federal court in Syracuse, New York. It alleges that James, a Democrat, “is guided solely by political animus and a desire to harass, intimidate and retaliate against a private citizen who she views as a political opponent”.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/trump-new-york-state-attorney-general-letitia-james">Continue reading...</a>

## Women’s Champions League quarter-finals: tie-by-tie analysis and verdicts | Suzanne Wrack
 - [https://www.theguardian.com/football/2021/dec/20/womens-champions-league-quarter-finals-tie-by-tie-analysis-and-verdicts](https://www.theguardian.com/football/2021/dec/20/womens-champions-league-quarter-finals-tie-by-tie-analysis-and-verdicts)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 16:58:56+00:00

<p>Arsenal face a difficult task to overcome Wolfsburg with Lyon and Barcelona expected to challenge for European success</p><p>The reigning German and French champions have met once in the Champions League with Paris Saint-Germain securing a 4-1 aggregate win, after a 1-0 first‑leg defeat, in the last eight of the 2016‑17 competition. Both teams look very different today. PSG were eliminated by Barcelona in the semi-finals last season, having beaten Lyon 2-1 away after a 1-0 home defeat to progress on away goals. They also got the better of the seven-times Champions League winners domestically, beating them to the title and ending Lyon’s 14-year dominance of the league. PSG got here by topping Group B without conceding while scoring 25 times in six games., with six goals coming from the Canada forward Jordyn Huitema. Bayern returned to the summit of the Frauen Bundesliga last season after losing out to Wolfsburg for four consecutive seasons. They, too, reached the semi-finals last season but bowed out with a 4-1 defeat by Chelsea at Kingsmeadow after a 2-1 home win. This time they finished runners up in Group D behind Lyon after a surprise 0-0 draw with Benfica in their opening game and a 2-1 defeat at Lyon.</p> <a href="https://www.theguardian.com/football/2021/dec/20/womens-champions-league-quarter-finals-tie-by-tie-analysis-and-verdicts">Continue reading...</a>

## Psychiatrists warn of problem gambling rise among over-65s
 - [https://www.theguardian.com/society/2021/dec/20/psychiatrists-warn-problem-gambling-rise-over-60s-great-britain](https://www.theguardian.com/society/2021/dec/20/psychiatrists-warn-problem-gambling-rise-over-60s-great-britain)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 16:47:29+00:00

<p>About 620,000 more in age group are gambling online at least once a month than two years ago in Great Britain</p><p>Psychiatrists are warning of a surprise rise in problem gambling among the over-65s after the largest increase in online betting since before the pandemic was recorded among the age group.</p><p>About 620,000 more over-65s are gambling online at least once a month than in 2019 – a bigger increase than any other age group, according to analysis of Gambling Commission data by the Royal College of Psychiatrists (RCP).</p> <a href="https://www.theguardian.com/society/2021/dec/20/psychiatrists-warn-problem-gambling-rise-over-60s-great-britain">Continue reading...</a>

## US quidditch leagues to change name in effort to break from JK Rowling
 - [https://www.theguardian.com/us-news/2021/dec/20/us-quidditch-leagues-change-name-jk-rowling](https://www.theguardian.com/us-news/2021/dec/20/us-quidditch-leagues-change-name-jk-rowling)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 16:40:59+00:00

<p>Leaders of the sport criticize the Harry Potter creator’s trans views as leagues also cite trademark issues</p><p>Harry Potter’s favorite sport, quidditch, is to receive a new name in the US, in part because its leaders are critical of the controversial views of the fictional wizard’s creator <a href="https://www.theguardian.com/books/jkrowling">JK Rowling</a>, which the US leagues have called “anti-trans”.</p><p>Two leagues that operate the sport in the US also cite trademark issues for their decision for the rebranding.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/us-quidditch-leagues-change-name-jk-rowling">Continue reading...</a>

## Gabriel Boric’s triumph puts wind in the sails of Latin America’s resurgent left
 - [https://www.theguardian.com/world/2021/dec/20/gabriel-boric-election-triumph-latin-america-resurgent-left](https://www.theguardian.com/world/2021/dec/20/gabriel-boric-election-triumph-latin-america-resurgent-left)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 16:28:02+00:00

<p>The decisive victory reflects Chileans’ revolt against a threadbare welfare system and a society systematically stacked in the favour of the rich</p><p>At the age of 14, Gabriel Boric – the great-grandson of a Croatian migrant and an <a href="https://web.archive.org/web/20160304211103/http:/www.latercera.com/contenido/680_140759_9.shtml">avid reader</a> of Marx and Hegel – formed a city-wide student union in the Chilean city of Punta Arenas.</p><p>At 21, and by then a law student, he led a campus sit-in for 44 days in Santiago, Chile’s capital, to oust a senior professor accused of plagiarism and corruption. Two years later, in 2011, he was <a href="http://www.lasegunda.com/Noticias/Nacional/2011/12/702829/Gabriel-Boric-el-nuevo-presidente-de-la-FECh-vencio-por-189-votos-a-Camila-Vallejo">elected</a> figurehead of a massive student rebellion against profiteering private universities, and in 2013 became a congressman for his remote home region.</p> <a href="https://www.theguardian.com/world/2021/dec/20/gabriel-boric-election-triumph-latin-america-resurgent-left">Continue reading...</a>

## Look at the lauding of David Frost and see a government deranged by the poison of Brexit | Polly Toynbee
 - [https://www.theguardian.com/commentisfree/2021/dec/20/david-frost-poison-brexit-johnson](https://www.theguardian.com/commentisfree/2021/dec/20/david-frost-poison-brexit-johnson)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 16:00:05+00:00

<p>A once great election-winning machine is in freefall, brutally exposed by the exit of Johnson’s guru, and the mess left behind</p><p>Off he stomps in his union jack socks, the pantomime John Bull who caused so much damage by doing his master’s bidding. As David Frost, the former Brexit minister, departs in a self-important huff, his reasons for going illuminate the strange decline of a once great election-winning machine.</p><p>Frost’s resignation letter – which takes aim at Covid restrictions – usefully captures the Tory party’s deranged state of mind. Its call for “a lightly regulated, low-tax, entrepreneurial economy” brims with a primal yearning to liberalise health, safety and food regulations, and workers’ rights. Recently he <a href="https://www.briefingsforbritain.co.uk/if-we-cant-persuade-people-that-freedom-is-the-best-way-forward-we-lose/">warned</a> that Brexit will fail if “all we do is import the European social model”. Of all the airily out-of-touch Conservative party conference speeches, his was the wildest: “The British renaissance has begun!”</p><p>Polly Toynbee is a Guardian columnist </p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/david-frost-poison-brexit-johnson">Continue reading...</a>

## Toppling Colston statue was act of ‘allyship and solidarity’, says accused
 - [https://www.theguardian.com/uk-news/2021/dec/20/toppling-colston-statue-act-allyship-solidarity-accused](https://www.theguardian.com/uk-news/2021/dec/20/toppling-colston-statue-act-allyship-solidarity-accused)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 15:56:10+00:00

<p>Rhian Graham tells Bristol court she was standing with people of colour against ‘a symbol of great harm’</p><p>A woman accused of helping to pull down the statue of Edward Colston in Bristol said she was acting out of “allyship and solidarity” with people of colour, a court has heard.</p><p>Rhian Graham told Bristol crown court on Monday she knew the bronze memorial to the slave trader was a source of offence for many Bristolians and that the council had not responded to calls for it to be removed before the Black Lives Matter protest she attended last year.</p> <a href="https://www.theguardian.com/uk-news/2021/dec/20/toppling-colston-statue-act-allyship-solidarity-accused">Continue reading...</a>

## NHS drug pledge broken for asthma sufferers and smokers, report reveals
 - [https://www.theguardian.com/society/2021/dec/20/nhs-drug-pledge-broken-for-asthma-sufferers-and-smokers-report-reveals](https://www.theguardian.com/society/2021/dec/20/nhs-drug-pledge-broken-for-asthma-sufferers-and-smokers-report-reveals)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 15:35:35+00:00

<p>Exclusive: Charities critical of failure to meet health plan for England, despite 2019 agreement</p><p>A promise to ensure that people with severe asthma and smokers who want to quit can get the drugs they need has been broken by ministers and the NHS, a health service report reveals.</p><p>Health charities criticised the persistent lack of access to vital medications for patients in England as very worrying and warned that it could damage the health of those affected.</p> <a href="https://www.theguardian.com/society/2021/dec/20/nhs-drug-pledge-broken-for-asthma-sufferers-and-smokers-report-reveals">Continue reading...</a>

## Chilean celebrations and Amsterdam in lockdown: Monday’s best photos
 - [https://www.theguardian.com/news/gallery/2021/dec/20/chilean-celebrations-and-amsterdam-in-lockdown-mondays-best-photographs](https://www.theguardian.com/news/gallery/2021/dec/20/chilean-celebrations-and-amsterdam-in-lockdown-mondays-best-photographs)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 15:18:19+00:00

<p>The Guardian’s picture editors select photo highlights from around the world</p> <a href="https://www.theguardian.com/news/gallery/2021/dec/20/chilean-celebrations-and-amsterdam-in-lockdown-mondays-best-photographs">Continue reading...</a>

## China riveted by public row between pop star and former wife
 - [https://www.theguardian.com/world/2021/dec/20/wang-leehom-lee-jinglei-china-taiwan](https://www.theguardian.com/world/2021/dec/20/wang-leehom-lee-jinglei-china-taiwan)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 15:08:06+00:00

<p>US-born singer-songwriter Wang Leehom accused of infidelity and emotional abuse by Lee Jinglei</p><p>The highly successful Mandarin-speaking singer-songwriter Wang Leehom has issued <a href="https://weibo.com/1793285524/L6U097QmW?pagetype=profilefeed">a public apology</a> to his ex-wife after a high-profile family row that has gripped the Chinese-speaking world.</p><p>In <a href="https://weibo.com/5977512966/L6w2sfDXb?pagetype=profilefeed">a lengthy social media post</a> on Friday, Lee Jinglei accused Wang of emotional abuse, lack of care for his family, infidelity and solicitation of sex workers.</p> <a href="https://www.theguardian.com/world/2021/dec/20/wang-leehom-lee-jinglei-china-taiwan">Continue reading...</a>

## The person who got me through 2021: Fleabag helped me survive my mother’s death
 - [https://www.theguardian.com/lifeandstyle/2021/dec/20/the-person-who-got-me-through-2021-fleabag-helped-me-survive-my-mothers-death](https://www.theguardian.com/lifeandstyle/2021/dec/20/the-person-who-got-me-through-2021-fleabag-helped-me-survive-my-mothers-death)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 15:00:04+00:00

<p>I rewatched Phoebe Waller-Bridge’s monstrous and lovable creation after my mother died in lockdown. The show gave me space to live and grieve</p><p>Fleabag isn’t really the person who got me through 2021. To confess the truth (and now the Hot Priest is saying “Kneel!” in your head, isn’t he?), she also got me through 2020, 2019, 2018, 2017 and half of 2016, when the show first aired. It’s been an intense few years. Which is precisely why only a show about a self-sabotaging, black-humoured, grief-stricken, sex-obsessed, charismatic and broken nihilist would do.</p><p>However, 2021 has been different. It’s the first year I’ve rewatched Fleabag since my mum’s death. She died last June in the midst of lockdown. She had breast cancer, just like Fleabag’s mum, whose farts sounded either like “a door opening” or a “suspicious duck”, and who also died. My mum was ill – with a remission in the middle that was like the sun coming out – for eight long years. Phoebe Waller-Bridge’s monstrous/lovable creation (whom she plays with such startling acuity that I actually felt betrayed when I discovered her own mother was alive) was my (evil) spirit guide through much of the darkness. Now she walks with me on this newly laid, even longer road through the wilderness of grief. I can think of no better companion.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/dec/20/the-person-who-got-me-through-2021-fleabag-helped-me-survive-my-mothers-death">Continue reading...</a>

## EU has ‘limited’ appetite for post-Brexit migration deal with UK
 - [https://www.theguardian.com/politics/2021/dec/20/eu-has-limited-appetite-for-post-brexit-migration-deal-with-uk](https://www.theguardian.com/politics/2021/dec/20/eu-has-limited-appetite-for-post-brexit-migration-deal-with-uk)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 14:55:54+00:00

<p>Commissioner’s stance underlines difficulty of task facing Liz Truss as she steps into David Frost’s brief</p><p>A senior EU official has said she does not expect the bloc to strike a migration deal with the UK because of disputes over the Brexit agreement.</p><p>Ylva Johansson, the European commissioner for home affairs, said EU member states had “limited” appetite for an agreement with the UK to manage asylum seekers and migrants, citing concerns over the post-Brexit trade deal and the <a href="https://www.theguardian.com/politics/2021/dec/17/northern-ireland-what-are-the-eu-and-uk-proposing-and-will-deal-be-done">Northern Ireland protocol.</a></p> <a href="https://www.theguardian.com/politics/2021/dec/20/eu-has-limited-appetite-for-post-brexit-migration-deal-with-uk">Continue reading...</a>

## Have we witnessed the death of the Hollywood remake?
 - [https://www.theguardian.com/film/2021/dec/20/west-side-story-hollywood-remake-spielberg](https://www.theguardian.com/film/2021/dec/20/west-side-story-hollywood-remake-spielberg)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 14:52:29+00:00

<p>Meagre turnout for West Side Story shows that these days, the way to cash in on intellectual property is via sequels and reboots</p><p>So far, Steven Spielberg’s West Side Story hasn’t had audiences pirouetting and finger-clicking their way to cinemas. There are plenty of reasons why; the main one relating to a certain global pandemic. But one explanation that keeps being proffered is that viewers are simply sick of remakes – and it’s not entirely wrong. Hollywood still has no qualms about bringing back its vintage franchises, of course. But as the imminent returns of <a href="https://www.theguardian.com/film/2021/sep/09/the-matrix-resurrections-trailer-neo">The Matrix</a>, <a href="https://www.theguardian.com/film/2021/oct/12/scream-returns-first-trailer-slasher-neve-campbell-courteney-cox">Scream</a>, <a href="https://www.theguardian.com/film/2019/jul/18/tom-cruise-top-gun-maverick-trailer">Top Gun</a>, <a href="https://www.theguardian.com/film/2021/oct/22/next-indiana-jones-harrison-ford-movie-time-travel-week-in-geek">Indiana Jones</a>, Hocus Pocus and Legally Blonde demonstrate, the fashionable way to cash in on a venerable intellectual property is to hire as many of the original cast members as you can and to pick up where you left off. Sequels are in; remakes are out.</p><p>Remakes, lest we forget, were once central to the cinematic landscape – hardly more remarkable or disreputable than a new theatrical production of an old play. When The Maltese Falcon came out in 1940, it was the third adaptation of the same book within a decade. Some Like It Hot? Pinched from a 1951 German farce, which was in turn pinched from a 1935 French one. Hitchcock’s 1956 classic <a href="https://www.theguardian.com/film/2012/jun/17/favourite-hitchcock-film-man-who-knew-too-much">The Man Who Knew Too Much</a>? A total rip-off of Hitchcock’s 1934 classic, The Man Who Knew Too Much.</p> <a href="https://www.theguardian.com/film/2021/dec/20/west-side-story-hollywood-remake-spielberg">Continue reading...</a>

## ‘Serious failings’ during rescue may have contributed to Channel deaths
 - [https://www.theguardian.com/uk-news/2021/dec/20/channel-deaths-report-finds-failings-in-rescue-effort-as-legal-action-begins](https://www.theguardian.com/uk-news/2021/dec/20/channel-deaths-report-finds-failings-in-rescue-effort-as-legal-action-begins)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 14:33:07+00:00

<p>Cases launched in UK and France over deaths of 27 people amid call for a public inquiry in Britain</p><p>“Serious failings” in a rescue operation may have contributed to the deaths of 27 refugees in the Channel last month, according to lawyers representing bereaved family members.</p><p><strong> </strong>Calls for a public inquiry to determine whether “acts or omissions” by British agencies resulted in human rights breaches came alongside separate legal cases against UK and French authorities involved in the operation.</p> <a href="https://www.theguardian.com/uk-news/2021/dec/20/channel-deaths-report-finds-failings-in-rescue-effort-as-legal-action-begins">Continue reading...</a>

## A bold plan saved the world economy in 2009. With this new plan, we can control Covid | Gordon Brown
 - [https://www.theguardian.com/commentisfree/2021/dec/20/money-medicines-vaccinate-world-rich-countries-gordon-brown](https://www.theguardian.com/commentisfree/2021/dec/20/money-medicines-vaccinate-world-rich-countries-gordon-brown)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 14:30:03+00:00

<p>If rich countries are willing to act decisively, I have a strategy that will allow us to work together and vaccinate the world</p><p>Time and again throughout history, perpetrators of injustice have absolved themselves and justified miserliness and inaction by blaming the victim. Amid allegations of African culpability for the <a href="https://www.theguardian.com/world/2021/dec/09/south-african-covid-cases-up-255-in-a-week-as-omicron-spreads">Omicron outbreak</a> and complaints from the global north about vaccine hesitancy and low take-up in the global south, 2021 has seen this shameful story being told anew.</p><p>But the new variant is not Africa’s fault. Responsibility starts with the governments of wealthy nations that <a href="https://www.theguardian.com/commentisfree/2021/nov/26/new-covid-variant-rich-countries-hoarding-vaccines">stockpiled hundreds of millions of vaccine doses</a> and that, even when warned about the failure to vaccinate more vulnerable parts of the world, did too little as the virus mutated.</p><p>Gordon Brown is the WHO ambassador for global health financing, and was UK prime minister from 2007 to 2010</p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/money-medicines-vaccinate-world-rich-countries-gordon-brown">Continue reading...</a>

## The Fortress review – football-obsessed road movie slogs its way across Colombia
 - [https://www.theguardian.com/film/2021/dec/20/the-fortress-review-football-obsessed-road-movie-slogs-its-way-across-colombia](https://www.theguardian.com/film/2021/dec/20/the-fortress-review-football-obsessed-road-movie-slogs-its-way-across-colombia)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 14:00:03+00:00

<p>Andres Torres’ documentary faithfully tracks three “hooligans” as they trailer-hop around Colombia, but captures little of the lives behind the machismo</p><p>Shot on a couple of handheld cameras, this documentary follows three young men – El Loco, Lechero and Carlitos – from north-eastern Colombia as they traverse a thousand miles of rough road, mostly by stealthily leaping on to moving lorries, and scrounging food from strangers along the way. It’s a dangerous journey, but the guys don’t have much to lose given the hardscrabble poverty of their daily lives. The purpose, apart from the fact that it’s just something to do, is to see their football team Atlético<a href="https://en.wikipedia.org/wiki/Atl%C3%A9tico_Bucaramanga"> </a>Bucaramanga, AKA the Leopards, play for a chance of promotion to division A after eight long years in division B.</p><p>Self-styled “hooligans,” it’s clear they see this pilgrimage as an act of honour to the club they love as well as something they do in the name of fallen friends. Before setting off for the key game they visit the tomb of one deceased comrade and blow spliff smoke in his direction as an offering. Once on the road, they meet other supporters – a fight nearly breaks out on the sliproad until they realise they are fellow Leopards fans – and survive on the kindness of strangers. Director Andres Torres doesn’t show that much football-stadium violence, but it’s alluded to throughout and the closing credits pay tribute to some of the dead.</p> <a href="https://www.theguardian.com/film/2021/dec/20/the-fortress-review-football-obsessed-road-movie-slogs-its-way-across-colombia">Continue reading...</a>

## Martha Wells continues run of female Hugo award winners
 - [https://www.theguardian.com/books/2021/dec/20/martha-wells-continues-run-of-female-hugo-award-winners](https://www.theguardian.com/books/2021/dec/20/martha-wells-continues-run-of-female-hugo-award-winners)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 13:57:12+00:00

<p>Wells’s novel Network Effect takes top science fiction award, the sixth successive win for a woman in what was once an almost exclusively male honour roll</p><p>The Hugo awards for science fiction and fantasy have been dominated once again by women, with American writer Martha Wells taking the top prize for best novel.</p><p>Wells took two accolades at what is considered the most prestigious awards ceremony in the science fiction calendar, winning best novel for Network Effect and best series for The Murderbot Diaries. Network Effect and its predecessors follow the adventures of a sentient killing machine known as Murderbot, which develops human traits and would rather make friends and watch TV soaps than fulfil its programming. <a href="https://www.marthawells.com/">Wells’ latest novel</a> sees Murderbot intervening between warring factions of alien-controlled humans on a distant colony world.</p> <a href="https://www.theguardian.com/books/2021/dec/20/martha-wells-continues-run-of-female-hugo-award-winners">Continue reading...</a>

## We love: fashion fixes for the week ahead – in pictures
 - [https://www.theguardian.com/fashion/gallery/2021/dec/20/we-love-fashion-fixes-for-the-week-ahead-in-pictures](https://www.theguardian.com/fashion/gallery/2021/dec/20/we-love-fashion-fixes-for-the-week-ahead-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 13:30:02+00:00

<p>An artist’s Christmas socks, decadent loungewear and upcycled bags</p> <a href="https://www.theguardian.com/fashion/gallery/2021/dec/20/we-love-fashion-fixes-for-the-week-ahead-in-pictures">Continue reading...</a>

## Thomasina Miers’ recipe for honey-roast quince salad with blue cheese, radicchio and seared venison | The new flexitarian
 - [https://www.theguardian.com/food/2021/dec/20/thomasina-miers-recipe-for-honey-roast-quince-salad-with-blue-cheese-radicchio-and-seared-venison](https://www.theguardian.com/food/2021/dec/20/thomasina-miers-recipe-for-honey-roast-quince-salad-with-blue-cheese-radicchio-and-seared-venison)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 13:00:01+00:00

<p>This warm salad of sweet quince, sharp blue cheese and pink leaves contrasts beautifully with the clean, rich flavour of venison. Just add chips</p><p>Venison is one of my favourite meats, with a clean, rich flavour and beautifully tender when cooked either very quickly or very slowly; it’s also packed with nutrients and low in fat. Here, I give it a touch of sweetness with some honey-roast quince in a stunning-looking salad featuring pink leaves, toasted nuts and blue cheese.</p><p>UK readers: <a href="https://www.ocado.com/search?entry=10000096071&amp;utm_source=guardian-feast&amp;utm_medium=referral&amp;utm_campaign=guardian-feast-recipe">click to buy these ingredients</a> from Ocado</p> <a href="https://www.theguardian.com/food/2021/dec/20/thomasina-miers-recipe-for-honey-roast-quince-salad-with-blue-cheese-radicchio-and-seared-venison">Continue reading...</a>

## ‘We are strongmen’: Polish workers help bring UK its Christmas turkeys
 - [https://www.theguardian.com/business/2021/dec/20/polish-workers-uk-christmas-turkeys-brexit-covid](https://www.theguardian.com/business/2021/dec/20/polish-workers-uk-christmas-turkeys-brexit-covid)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 12:38:43+00:00

<p>Despite Brexit and Covid, foreign workers take up government’s emergency visa scheme</p><p>“We are Polish strongmen,” laughs Piotr Zabiec, taking a break from another busy day processing turkeys on a farm near Chelmsford in Essex. “Without us, maybe you won’t have a turkey on your table at Christmas time.”</p><p>The 41-year-old has left his fiancee and two children at home in the central city of Włocławek, trading his usual work as a health and safety inspector and taxi driver for a month removing giblets from thousands of birds for the turkey producer KellyBronze. It is the first time he has come to the UK to work, encouraged to make the trip by friends who have spent the past few Decembers in Britain.</p> <a href="https://www.theguardian.com/business/2021/dec/20/polish-workers-uk-christmas-turkeys-brexit-covid">Continue reading...</a>

## Tell us: are you a former teacher returning to school during the pandemic?
 - [https://www.theguardian.com/education/2021/dec/20/tell-us-are-you-a-former-teacher-returning-to-school-during-the-pandemic](https://www.theguardian.com/education/2021/dec/20/tell-us-are-you-a-former-teacher-returning-to-school-during-the-pandemic)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 12:24:04+00:00

<p>We would like to hear from former teachers planning to help at schools hit by staff absences during the pandemic</p><p>The Department for Education has asked former teachers to <a href="https://twitter.com/educationgovuk/status/1472824123042766851">temporarily return to the classroom</a> to assist schools hit by staff absences during the pandemic.</p><p>We would like to hear from former teachers who are planning to return to the classroom. Why have you decided to return? Have you experienced any issues with the recruitment process?</p> <a href="https://www.theguardian.com/education/2021/dec/20/tell-us-are-you-a-former-teacher-returning-to-school-during-the-pandemic">Continue reading...</a>

## Laura Kuenssberg to step down as BBC political editor at Easter
 - [https://www.theguardian.com/media/2021/dec/20/laura-kuenssberg-step-down-bbc-political-editor-easter](https://www.theguardian.com/media/2021/dec/20/laura-kuenssberg-step-down-bbc-political-editor-easter)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 12:20:47+00:00

<p>Kuenssberg says she will ‘miss daily drama’ as BBC confirms she will take a senior presenting and reporting role</p><p>Laura Kuenssberg has confirmed she will step down as the BBC’s political editor at Easter but will remain with the corporation in “a senior presenting and reporting role”.</p><p>As first <a href="https://www.theguardian.com/media/2021/oct/21/laura-kuenssberg-talks-step-down-bbc-political-editor">revealed by the Guardian in October</a>, she has been in talks about taking up a presenting role on Radio 4’s Today programme as part of a reshuffle of the broadcaster’s on-air staff. She has also been tipped as a possible replacement for the recently departed Andrew Marr as host of the corporation’s flagship Sunday morning political interview programme.</p> <a href="https://www.theguardian.com/media/2021/dec/20/laura-kuenssberg-step-down-bbc-political-editor-easter">Continue reading...</a>

## The book I got for Christmas: ‘This genius anthology probably set the course of my life’
 - [https://www.theguardian.com/books/2021/dec/20/the-book-i-got-for-christmas-this-genius-anthology-probably-set-the-course-of-my-life](https://www.theguardian.com/books/2021/dec/20/the-book-i-got-for-christmas-this-genius-anthology-probably-set-the-course-of-my-life)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 12:05:43+00:00

<p>In a short series for the festive season, Guardian writers reveal the most memorable books they have been given for Christmas. Alison Flood kicks off, revealing how Kaye Webb’s I Like This Poem introduced her to the joys of poetry</p><ul><li>Please share your most memorable gift books below and we will publish a selection later this week<br /></li></ul><p>I can’t remember if I was six or seven years old when my grandma gave me a book for Christmas which, I now realise, probably set the course for my life – an English literature degree, a job in literary journalism. The book was I Like This Poem, edited by the legendary Kaye Webb of Puffin, and it absolutely, entirely delighted me.</p><p>The genius of this poetry anthology for children – along with Webb’s incomparably appealing selection of poems – is the way it is divided into ages, starting with six and seven-year-olds, and the way each poem comes with an explanation from a real child about why they love it.</p> <a href="https://www.theguardian.com/books/2021/dec/20/the-book-i-got-for-christmas-this-genius-anthology-probably-set-the-course-of-my-life">Continue reading...</a>

## I was all set to fly to Ghana for Christmas. Then came an unexpected offer
 - [https://www.theguardian.com/lifeandstyle/2021/dec/20/i-was-all-set-to-fly-to-ghana-for-christmas-then-came-an-unexpected-offer](https://www.theguardian.com/lifeandstyle/2021/dec/20/i-was-all-set-to-fly-to-ghana-for-christmas-then-came-an-unexpected-offer)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 12:00:01+00:00

<p>When you are an actor, you never say no to great work. But when I finally reached Accra, and walked on its red earth, I knew I would be back there soon</p><p>My Christmas memory begins in early summer 2004, on day two of rehearsals for Stuff Happens, David Hare’s brilliantly funny, heartbreaking excoriation of what took us to war with Iraq in 2003. I get to play Condoleezza Rice in Nick Hytner’s stunning production; Shostakovich, elegantly pointed chair action and top-of-the-range acting!</p><p>Of-the-moment politics, while playing the thrillingly enigmatic “Condi” on the National Theatre’s Olivier stage, with an audience hungry for answers … heaven.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/dec/20/i-was-all-set-to-fly-to-ghana-for-christmas-then-came-an-unexpected-offer">Continue reading...</a>

## Gritt review – intriguing, subversive drama about the perils of creativity
 - [https://www.theguardian.com/film/2021/dec/20/gritt-review-itonje-soimer-guttormsen](https://www.theguardian.com/film/2021/dec/20/gritt-review-itonje-soimer-guttormsen)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 12:00:00+00:00

<p>Itonje Søimer Guttormsen’s feature debut traces the story of a troubled young woman on the outside of outsider art</p><p>Before it dissolves out into a watery sort of nothingness, this feature debut from Norwegian director Itonje Søimer Guttormsen is an intriguing and subversive docu-type drama about the nature of creativity and how modern-day equivalents of the avant gardist Antonin Artaud might expect to be treated. Birgitte Larsen plays Gry-Jeanette Dahl, who goes by the name “Gritt”. She is a troubled, intense young woman, trying to break into experimental theatre and radical performance artforms, and basically in the unhappy position of being on the outside of outsider art.</p><p>As the film begins, Gritt has managed to fluke her way to New York, part of a grant-funded Norwegian theatre company; she is employed as the emotional support person for Marte (Marte Wexelsen Goksøyr), a writer-performer with Down’s. Gritt affects a bland sort of insincere friendship with Marte, asking her questions about her career with a listless envy and resentment. Her own grant application for a gigantic installation performance piece called The White Inflammation is turned down and Gritt is angrily devastated, but doesn’t summon up the smallest inclination to attempt a smaller-scale version or to try funding it by some other means.</p><p>Gritt is available on 22 December on Mubi.</p> <a href="https://www.theguardian.com/film/2021/dec/20/gritt-review-itonje-soimer-guttormsen">Continue reading...</a>

## It's Rishi Sunak, not the Bank of England, who needs to act to get the UK's economy firing again | Carys Roberts
 - [https://www.theguardian.com/commentisfree/2021/dec/20/rishi-sunak-bank-of-england-uk-economy](https://www.theguardian.com/commentisfree/2021/dec/20/rishi-sunak-bank-of-england-uk-economy)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 12:00:00+00:00

<p>The questions which will determine whether families feel the pinch this Christmas and beyond are all up to the chancellor</p><p>Economic commentators and investors all have their eyes on inflation, and the unexpected decision by the Bank of England to <a href="https://www.theguardian.com/business/2021/dec/16/bank-of-england-raises-interest-rates-to-025">raise interest rates</a>, for the first time in three years, to 0.25% – in spite of the disruption and uncertainty of <a href="https://www.theguardian.com/world/2021/dec/18/who-says-omicron-in-89-countries-and-spreading-rapidly">Omicron</a>. But behind the headlines and the focus on the Bank, the biggest macroeconomic questions facing the UK – which will determine whether families feel the pinch this Christmas and beyond – are all up to the chancellor.</p><p>Inflation has reached its highest level in a decade, at 5.1%. Yet this isn’t inflation of the 1970s kind, still raised as an economic bogeyman to stoke fear of “wage-price spirals”. The governor of the Bank of England <a href="https://www.independent.co.uk/news/business/uk-inflation-rate-wage-increase-b1959195.html">has said</a> there is little risk of this. Inflation is, in fact, outstripping pay rises – so <a href="https://www.resolutionfoundation.org/comment/labour-market-diagnosis-jobs-market-healthy-and-doesnt-have-a-temperature-but-pay-packets-shrinking-not-surging/">average pay packets are shrinking</a> in real terms.</p><p>Carys Roberts is executive director of the Institute for Public Policy Research</p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/rishi-sunak-bank-of-england-uk-economy">Continue reading...</a>

## 17 ways with vol au vents
 - [https://www.theguardian.com/food/2021/dec/20/pastry-perfection-17-delicious-ways-with-vol-au-vents-from-smoked-aubergine-to-sweet-custard](https://www.theguardian.com/food/2021/dec/20/pastry-perfection-17-delicious-ways-with-vol-au-vents-from-smoked-aubergine-to-sweet-custard)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 11:30:53+00:00

<p>No longer a ‘naff snack’, the pastry cases are very much back. Their versatility is boundless, whether you prefer smoked trout, sausage, seafood or strawberries and cream</p><p>The humble vol-au-vent, a canapé long compromised by memories of <a href="https://www.theguardian.com/media/2007/oct/14/television.bbc">Abigail’s Party</a> and <a href="https://en.wikipedia.org/wiki/Three-Day_Week">the three-day week</a>, is staging a bold comeback this Christmas: <a href="https://www.standard.co.uk/news/uk/vol-au-vent-snack-sold-out-waitrose-sales-up-b971036.html">sales are up 25% year-on-year at Waitrose</a>, with stocks of their party packs of 12 running low. This resurgent interest in what the Sun describes as “the naff snack” has been attributed to a nostalgic obsession with bygone foodstuffs triggered by the pandemic, but the revival could have just as much to do with the emergence of an entire generation for whom vol-au-vents hold no unpleasant associations, because they’ve never eaten any and barely know what they are.</p><p>Here’s what they are: small pastry cases loaded with a variety of savoury fillings – ham, chicken and mushroom being among the most common. The vol-au-vent originated in France around the start of the 19th century as a larger, pie-like affair; the bite-size cocktail party version is more properly known as a bouchée. By the 1990s, they were tragically unfashionable and remained so for decades, although classy, updated vol-au-vents started appearing in smart restaurants a year or two before the pandemic erupted. Now it’s the retro hors d’oeuvre of the season, and the shops have been picked clean.</p> <a href="https://www.theguardian.com/food/2021/dec/20/pastry-perfection-17-delicious-ways-with-vol-au-vents-from-smoked-aubergine-to-sweet-custard">Continue reading...</a>

## Gabriel Boric vows to ‘fight privileges of the few’ as Chile’s premier
 - [https://www.theguardian.com/world/2021/dec/20/gabriel-boric-vows-to-fight-privileges-of-the-few-as-chiles-premier](https://www.theguardian.com/world/2021/dec/20/gabriel-boric-vows-to-fight-privileges-of-the-few-as-chiles-premier)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 11:25:57+00:00

<p>Leftwing former student pledges to unite country and tackle poverty and inequality</p><p>Gabriel Boric has vowed to unite Chile, fight “the privileges of the few” and tackle poverty and inequality after <a href="https://www.theguardian.com/world/2021/dec/19/leftist-gabriel-boric-elected-as-chiles-president">winning a decisive victory</a> over his far-right opponent to become the South American country’s youngest premier.</p><p>The 35-year-old leftwing former student leader won 56% of the vote in Sunday’s second-round presidential election, cruising past his ultra-conservative opponent, José Antonio Kast, who took 44.2%.</p> <a href="https://www.theguardian.com/world/2021/dec/20/gabriel-boric-vows-to-fight-privileges-of-the-few-as-chiles-premier">Continue reading...</a>

## 106.5 FM: the prison radio station giving Texas men on death row a voice
 - [https://www.theguardian.com/us-news/2021/dec/20/1065-fm-prison-radio-station-texas](https://www.theguardian.com/us-news/2021/dec/20/1065-fm-prison-radio-station-texas)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 11:00:52+00:00

<p>The Tank at Allan B Polunsky Unit allows the most isolated men a rare chance to be part of the prison community</p><p>As soon as I drive past the East Tempe Church on the outskirts of Livingston, Texas, I can hear the laugh track on my radio. It’s from “Martin,” a three-decade-old television sitcom. The fictional Detroiters’ racy wisecracks seem incongruous crackling through my car speakers on a winding country road.</p><p>When the laughter dies down, the slight Southern lilt of a DJ named “Megamind” cuts in to introduce the next segment.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/1065-fm-prison-radio-station-texas">Continue reading...</a>

## Attacking Stonewall for defending trans rights is a slippery slope | Finn Mackay
 - [https://www.theguardian.com/commentisfree/2021/dec/20/stonewall-trans-rights-gender-wars-tory-lgbtq](https://www.theguardian.com/commentisfree/2021/dec/20/stonewall-trans-rights-gender-wars-tory-lgbtq)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 10:35:52+00:00

<p>The gender wars are being fuelled by a Tory government – don’t let infighting destroy the LGBTQ+ community’s greatest champion</p><p>The UK’s national LGBTQ+ charity, Stonewall, <a href="https://www.theguardian.com/society/2021/jun/05/stonewall-trans-debate-toxic-gender-identity">has recently been accused</a> of advocating for trans rights. Six years ago, there was another “Stonewall question”, but the issue wasn’t whether the organisation should be advocating for trans rights, but instead why it wasn’t.</p><p>For those of us who remember these fights, it’s discombobulating to witness a reframing of Stonewall as a sinister organisation that sneaked trans rights on to its agenda when nobody was looking. The very opposite was the case: it was hard won. Many petitions were circulated, letters written and debates had. The inclusion of trans men, trans women and all transgender people eventually followed in 2015.</p><p>Finn Mackay is the author of <a href="https://guardianbookshop.com/female-masculinities-and-the-gender-wars-9780755606634">Female Masculinities and the Gender Wars</a> and is a senior lecturer in sociology at the University of the West of England in Bristol<br /></p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/stonewall-trans-rights-gender-wars-tory-lgbtq">Continue reading...</a>

## ‘This thing was trying to dismantle me’: Mark Lanegan on nearly dying of Covid
 - [https://www.theguardian.com/music/2021/dec/20/this-thing-was-trying-to-dismantle-me-mark-lanegan-on-nearly-dying-of-covid](https://www.theguardian.com/music/2021/dec/20/this-thing-was-trying-to-dismantle-me-mark-lanegan-on-nearly-dying-of-covid)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 10:00:52+00:00

<p>In this extract from his new memoir Devil in a Coma, the alt-rocker recalls how Covid-19 put him in hospital for months this year – and gave him a series of hallucinogenic visions</p><p>I had been feeling weak and sick for a few days and then woke up one morning completely deaf. My equilibrium shaky, and my mind in a surreal, psychedelic dream state, I lost my footing at the top of the stairs. Head over heels over head, I knocked myself out on the windowsill as I crashed down the narrow staircase at my house. Bang. My wife was out horseback riding for the day, and I came to hours later still unable to hear a thing, unable to move, two huge opened welts on my head and my knee not supporting any weight.</p><p>For two days I tried to get from stairwell to couch, with no success. I could not move, nor could my wife support my 200lb body, so I lay suffering on some blankets on the hard floor. My ribs were cracked, my spine bruised, battered and sore, and my already chronically messed-up knee gone again, as if some tendons were ripped or a ligament severed. My leg was useless. Every attempted breath was a battle, no matter how hard I tried to take a natural one. Though I refused to go to hospital my wife finally called an ambulance behind my back and I was wheeled out of my yard on a gurney. I eventually ended up in intensive care, unable to draw oxygen, and was diagnosed with some exotic new strain of the coronavirus for which there was no cure, of course. I was put into a medically induced coma, none of which I remembered.</p> <a href="https://www.theguardian.com/music/2021/dec/20/this-thing-was-trying-to-dismantle-me-mark-lanegan-on-nearly-dying-of-covid">Continue reading...</a>

## Tell us: what were you doing on 15 May 2020?
 - [https://www.theguardian.com/world/2021/dec/20/tell-us-what-were-you-doing-on-15-may-2020](https://www.theguardian.com/world/2021/dec/20/tell-us-what-were-you-doing-on-15-may-2020)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 09:32:20+00:00

<p>Whatever you were doing or not doing, we would like to hear your experiences of what 15 May last year was like for you</p><p>Questions have been raised once more after <a href="https://www.theguardian.com/politics/2021/dec/19/boris-johnson-and-staff-pictured-with-wine-in-downing-street-garden-in-may-2020">Boris Johnson was pictured with wine and cheese during a Downing Street garden gathering</a>, with up to 17 staff on 15 May 2020. No 10 has insisted a “work meeting’ was taking place.</p><p>Last year on <a href="https://www.theguardian.com/world/2020/may/10/uk-coronavirus-lockdown-what-has-boris-johnson-announced">13 May</a>, only two people from different households in England could meet outdoors socially distanced. In workplaces, guidance said in-person meetings should only take place if “absolutely necessary”. Similar easing of restrictions were introduced in Wales, Scotland and Northern Ireland later in May.</p> <a href="https://www.theguardian.com/world/2021/dec/20/tell-us-what-were-you-doing-on-15-may-2020">Continue reading...</a>

## The big news quiz of 2021 – do you know your Jackie Weavers from your German leaders?
 - [https://www.theguardian.com/world/2021/dec/20/big-news-quiz-of-2021-jackie-weaver-german-leaders](https://www.theguardian.com/world/2021/dec/20/big-news-quiz-of-2021-jackie-weaver-german-leaders)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 09:00:51+00:00

<p>A Catholic president, a cake, an inconvenient ship and a very clever tennis player: all this and more in trivia expert Bobby Seagull’s news quiz of the year</p><p>• Try our <a href="https://www.theguardian.com/lifeandstyle/2021/dec/18/reindeers-north-pole-bumper-christmas-kids-quiz">kids’ quiz</a> and <a href="https://www.theguardian.com/lifeandstyle/2021/dec/18/first-line-of-christmas-song-bumper-edition-of-saturday-quiz">bumper Saturday quiz</a>, too</p> <a href="https://www.theguardian.com/world/2021/dec/20/big-news-quiz-of-2021-jackie-weaver-german-leaders">Continue reading...</a>

## As a nurse I see people worried about vaccines: that doesn’t mean they’re anti-vaxxers | Heather Randle
 - [https://www.theguardian.com/commentisfree/2021/dec/20/nurse-covid-vaccination-centre-proud-fix-pandemic](https://www.theguardian.com/commentisfree/2021/dec/20/nurse-covid-vaccination-centre-proud-fix-pandemic)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 08:00:50+00:00

<p>We help everyone at our vaccination centre – a kind word can make all the difference</p><p>I started working as a nurse in 1987. I’m coming up for my 35th year: I knew it was an anniversary, but I had to count which one. Sometimes I feel I’ve been doing this for too long. But the Covid vaccination programme has been amazing. We have seen how, when we want to do something, we can pull it off. I work as a vaccinator at a centre in Coventry where we get through 440 a people a day, usually between five vaccinators; about 80 people each.</p><p>The mobilisation of this workforce and the rollout has been outstanding. The camaraderie is the best bit of the job for me – that we’re working together and it’s positive when so much is <a href="https://www.theguardian.com/world/2021/dec/17/covid-uk-reports-another-daily-record-cases">doom and gloom</a>. We’re doing something to fix the pandemic, and fixing things is what nursing is about. I find myself smiling under my mask; I’ve realised people can see it in my eyes, even if they can’t see my mouth.</p><p>Heather Randle is a general practice nurse and a professional lead for primary care at the Royal College of Nursing</p> <a href="https://www.theguardian.com/commentisfree/2021/dec/20/nurse-covid-vaccination-centre-proud-fix-pandemic">Continue reading...</a>

## ‘We’re not backing down’: The Texas church fighting for abortion rights
 - [https://www.theguardian.com/us-news/2021/dec/20/texas-church-fighting-abortion-rights](https://www.theguardian.com/us-news/2021/dec/20/texas-church-fighting-abortion-rights)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 08:00:50+00:00

<p>In the face of a draconian abortion ban in effect for more than three months, the mission has only grown stronger for a progressive congregation</p><p>In the late 60s, the burgeoning movement to legalize US abortion state by state found an unlikely yet loyal ally – a contingent of women at the First Unitarian Universalist church in Dallas, Texas.</p><p>In lieu of knitting sessions and bake sales, the church’s Women’s Alliance advocated for abortion rights and even had a hand in legally supporting Roe v Wade, the pivotal US supreme court case that protects abortion care in the US as a constitutional right.</p> <a href="https://www.theguardian.com/us-news/2021/dec/20/texas-church-fighting-abortion-rights">Continue reading...</a>

## SpaceX’s towering Starship aims to get humans to Mars
 - [https://www.theguardian.com/technology/2021/dec/20/spacex-starship-humans-moon-next-year](https://www.theguardian.com/technology/2021/dec/20/spacex-starship-humans-moon-next-year)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 08:00:49+00:00

<p>The largest and most powerful rocket ship ever is fully recyclable and may be the first vehicle to land humans on Mars</p><p>It’s been an eventful month for Elon Musk. The world’s richest man and founder of Tesla and SpaceX was, controversially, named Time’s <a href="https://www.theguardian.com/technology/2021/dec/14/elon-musk-time-person-of-the-year-worst-ever-choice-say-critics">person of the year</a>; became embroiled in a <a href="https://www.cnn.com/2021/12/15/investing/elon-musk-elizabeth-warren-taxes/index.html">Twitter spat</a> over his taxes with a politician he branded “Senator Karen” and got a <a href="https://news.knowyourmeme.com/news/elon-musk-roasted-for-villain-esque-haircut">bizarre new haircut</a> after <a href="https://www.theguardian.com/commentisfree/2021/dec/08/elon-musk-is-learning-a-hard-lesson-never-date-a-musician">splitting with his girlfriend</a>, the pop singer Grimes.</p><p>Next month, however, or perhaps a few weeks beyond if the attendant gremlins of spaceflight choose to play with the launch schedule, could come an achievement to surpass anything Musk has done before.</p> <a href="https://www.theguardian.com/technology/2021/dec/20/spacex-starship-humans-moon-next-year">Continue reading...</a>

## One pay packet away from the streets: the workers who became homeless in the pandemic
 - [https://www.theguardian.com/society/2021/dec/20/one-pay-packet-away-from-the-streets-the-workers-who-became-homeless-in-the-pandemic](https://www.theguardian.com/society/2021/dec/20/one-pay-packet-away-from-the-streets-the-workers-who-became-homeless-in-the-pandemic)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 07:00:51+00:00

<p>Over the last two years, homelessness has rocketed – and for many people a job has not been enough to maintain a roof over their head</p><p>Heavy rain soaked Grace’s clothes as she huddled in the doorway of an empty building in Derbyshire. Just weeks before, the 57-year-old had been a care worker, looking after vulnerable adults with severe learning disabilities. But she had lost her home, and then her job after her boyfriend’s violence escalated.</p><p>The pair had been together for five years. “I was in love,” she says. “I thought this was it. But then things changed, and I think it was because he didn’t want me there any more.”</p> <a href="https://www.theguardian.com/society/2021/dec/20/one-pay-packet-away-from-the-streets-the-workers-who-became-homeless-in-the-pandemic">Continue reading...</a>

## Phi Phi islands’ sustainable tourism renaissance – in pictures
 - [https://www.theguardian.com/artanddesign/gallery/2021/dec/20/phi-phi-islands-thailand-sustainable-tourism-renaissance](https://www.theguardian.com/artanddesign/gallery/2021/dec/20/phi-phi-islands-thailand-sustainable-tourism-renaissance)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 07:00:51+00:00

<p>Mass tourism had brought the archipelago to the brink of ecological catastrophe. Now Thailand hopes to make it the standard bearer for a sustainable tourism model as the country reopens to visitors after the Covid shutdown</p> <a href="https://www.theguardian.com/artanddesign/gallery/2021/dec/20/phi-phi-islands-thailand-sustainable-tourism-renaissance">Continue reading...</a>

## Do they know it’s Christmas? Santa events around the world – in pictures
 - [https://www.theguardian.com/lifeandstyle/gallery/2021/dec/20/do-they-know-its-christmas-santa-events-around-the-world-in-pictures](https://www.theguardian.com/lifeandstyle/gallery/2021/dec/20/do-they-know-its-christmas-santa-events-around-the-world-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 07:00:49+00:00

<p>From the Madrid Santa run to the Weymouth Chase the Pudding race, people don Father Christmas outfits to mark the festive season</p> <a href="https://www.theguardian.com/lifeandstyle/gallery/2021/dec/20/do-they-know-its-christmas-santa-events-around-the-world-in-pictures">Continue reading...</a>

## Inside the Guardian: six years of candour, courage, and craft
 - [https://www.theguardian.com/membership/2021/dec/20/inside-the-guardian-six-years-of-candour-courage-and-craft](https://www.theguardian.com/membership/2021/dec/20/inside-the-guardian-six-years-of-candour-courage-and-craft)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 07:00:49+00:00

<p>We revisit favourite contributions as our series on life behind the news agenda comes to an end</p><p>After six years and more than 250 pieces, our Inside the Guardian series is drawing to a close. Born originally out of reader curiosity about newsroom life, the series has gone behind the scenes to reveal how we uncover major news stories, devise different editions and products, and harness new technology.</p><p>The <a href="https://www.theguardian.com/membership/2015/jul/04/simon-hattenstone-the-unpredictable-and-the-unpublishable">first piece</a>, which dates back to July 2015, arrived courtesy of features writer Simon Hattenstone, who admitted to getting thrown out of an interview with Leonardo DiCaprio for suggesting some of his movies were a “bag of shite”. From there, the only way was up.</p> <a href="https://www.theguardian.com/membership/2021/dec/20/inside-the-guardian-six-years-of-candour-courage-and-craft">Continue reading...</a>

## My winter of love: I had three exciting dates that Christmas – one ended with an accusation of armed burglary
 - [https://www.theguardian.com/lifeandstyle/2021/dec/20/my-winter-of-love-three-exciting-dates-one-charge-of-armed-burglary](https://www.theguardian.com/lifeandstyle/2021/dec/20/my-winter-of-love-three-exciting-dates-one-charge-of-armed-burglary)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 06:00:49+00:00

<p>I was drunkenly eating a kebab outside Halfords when I was mistaken for a master criminal. It wasn’t the only thing that went wrong that lovely, eventful winter</p><p>No one, my friends decided, should be alone at <a href="https://www.theguardian.com/lifeandstyle/christmas" title="">Christmas</a>. Especially no one as desperately, soul-searchingly, what’s-wrong-with-me single as me. In the late 00s, when internet dating was for nerds, meeting people wasn’t easy – unless you got talking to someone at a party or something, which I never did, because I was too busy banging on to my mates about why I was so achingly single.</p><p>Thus, a plan was hatched. Three friends would each set me up on a <a href="https://www.theguardian.com/lifeandstyle/series/blind-date" title="">blind date</a>. I’m good-looking (with a squint), charming (after a few drinks) and a good catch, they assured me. What could go wrong?</p> <a href="https://www.theguardian.com/lifeandstyle/2021/dec/20/my-winter-of-love-three-exciting-dates-one-charge-of-armed-burglary">Continue reading...</a>

## ‘It makes me cry with laughter!’: readers recommend 15 fabulous Christmas films
 - [https://www.theguardian.com/film/2021/dec/20/it-makes-me-cry-with-laughter-readers-recommend-15-fabulous-christmas-films](https://www.theguardian.com/film/2021/dec/20/it-makes-me-cry-with-laughter-readers-recommend-15-fabulous-christmas-films)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 06:00:49+00:00

<p>Festive movies have never been more popular – and there’s nothing like a classic. Here are some to enjoy now, from Scrooged to Paddington to You’ve Got Mail</p><p>The original Ebenezer is, of course, Alastair Sim. Ideally, I like to watch this on an old videotape with the early 1980s BBC logo and announcer before the film starts. Every Christmas, we would watch Mr Sim transform from a hard, cold, pastry-faced man into a very huggable uncle. Just thinking about it makes my eyes well. I sit down with my kids to watch Scrooge as often as I can get away with it, and I’m always moved by this wonderful film. <br /><strong>Cait Hurley</strong><strong>, trainee Alexander </strong><strong>technique teacher and domiciliary carer, Mitcham</strong></p> <a href="https://www.theguardian.com/film/2021/dec/20/it-makes-me-cry-with-laughter-readers-recommend-15-fabulous-christmas-films">Continue reading...</a>

## Standing up to Putin: how Russian threat has toughened up Ukraine’s Zelenskiy
 - [https://www.theguardian.com/world/2021/dec/20/standing-up-to-putin-ukraine-president-volodymyr-zelenskiy-russian-threat](https://www.theguardian.com/world/2021/dec/20/standing-up-to-putin-ukraine-president-volodymyr-zelenskiy-russian-threat)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 05:00:45+00:00

<p>Actor turned president has undergone profound political transformation in the face of Russian aggression</p><p>In 2019, Volodymyr Zelenskiy rode a protest vote to victory in Ukraine, telling his supporters he would jail corrupt politicians and negotiate directly with Vladimir Putin to end Russia’s war in east Ukraine. Nearly three years later, Zelenskiy is staring down the <a href="https://www.theguardian.com/world/2021/dec/06/us-says-it-will-send-troops-to-eastern-europe-if-russia-invades-ukraine">threat of a Russian invasion</a>, while he rallies western powers to his side and calls for aid. “We know what it means to defend one’s own state and land with weapons in hand,” he said during an address last week to the Kyiv Jewish Forum.</p><p>Under pressure from Putin, Zelenskiy has undergone a profound political transformation. One thing is clear: he is no longer the same dove that he was on the campaign trail. Russia is pushing Ukraine toward Nato, he says<strong>, </strong>and a membership action plan is now central to his foreign policy. This month, Zelenskiy toured the frontline outside Donetsk. Wearing a flak jacket and helmet, he chatted with service personnel who will be the first line of Ukraine’s defence should tanks from Russia begin to roll.</p> <a href="https://www.theguardian.com/world/2021/dec/20/standing-up-to-putin-ukraine-president-volodymyr-zelenskiy-russian-threat">Continue reading...</a>

## Countdown to attack: inside a simulation that mimics nuclear conflict
 - [https://www.theguardian.com/news/audio/2021/dec/20/countdown-to-attack-inside-a-simulation-that-mimics-nuclear-conflict](https://www.theguardian.com/news/audio/2021/dec/20/countdown-to-attack-inside-a-simulation-that-mimics-nuclear-conflict)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-12-20 03:00:43+00:00

<p>World affairs editor Julian Borger tries out a VR simulation designed to model a real-life nuclear exchange, and reports on the terrifying outcome</p><p>Guardian world affairs editor <strong>Julian Borger </strong>recently found himself wearing a new title: president of the United States. He took on the new role while taking part in a VR simulation designed by researchers from Princeton, American, and Hamburg universities.</p><p>The project, called <a href="https://www.theguardian.com/technology/2021/dec/14/vr-game-simulating-nuclear-attack-tests-decision-making-skills">the Nuclear Biscuit</a> in honour of the small card bearing the president’s launch authorisation code, was built using insights from interviews with former government officials about what might happen if the US appeared to be under nuclear attack. It’s designed to help lawmakers better understand the realities of nuclear armament.</p> <a href="https://www.theguardian.com/news/audio/2021/dec/20/countdown-to-attack-inside-a-simulation-that-mimics-nuclear-conflict">Continue reading...</a>

