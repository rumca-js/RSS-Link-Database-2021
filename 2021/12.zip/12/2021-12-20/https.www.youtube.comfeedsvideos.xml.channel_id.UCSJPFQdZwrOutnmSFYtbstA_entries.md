# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Recommends... Spider-Man: No Way Home
 - [https://www.youtube.com/watch?v=ZQwGqKwELh8](https://www.youtube.com/watch?v=ZQwGqKwELh8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-12-20 00:00:00+00:00

Did Spider-Man: No Way Home live up to everyone's expectations? Yes. Yes, it did. In fact, it puts every other superhero movie this year to shame. Join me for my (mostly) spoiler free review.

