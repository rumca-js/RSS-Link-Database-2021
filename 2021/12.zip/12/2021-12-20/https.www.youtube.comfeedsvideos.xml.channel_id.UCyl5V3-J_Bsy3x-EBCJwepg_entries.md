# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## (Trailer) The Babylon Bee Interviews Elon Musk
 - [https://www.youtube.com/watch?v=bvXkNrlDk1M](https://www.youtube.com/watch?v=bvXkNrlDk1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-20 00:00:00+00:00

See the interview here: https://www.youtube.com/watch?v=jvGnw1sHh9M

Subscribe to the Babylon Bee YouTube channel to get notified.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Santa’s Naughty And Nice List Revised To Right Side Of History List
 - [https://www.youtube.com/watch?v=uKFOAjBc1dw](https://www.youtube.com/watch?v=uKFOAjBc1dw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-12-20 00:00:00+00:00

Are you a horrible person but on the right side of history? Santa is shocked to discover that’s all it takes to be on the nice list.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

