# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 Księga Samuela || Rozdział 02
 - [https://www.youtube.com/watch?v=7dbtSi5Qx00](https://www.youtube.com/watch?v=7dbtSi5Qx00)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-21 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Kolędy dla radości [02] Gdy się Chrystus rodzi
 - [https://www.youtube.com/watch?v=fjpZYE58iro](https://www.youtube.com/watch?v=fjpZYE58iro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-21 00:00:00+00:00

Fundacja Malak wraz z Rafałem Maciejewskim postanowiła wyprodukować cztery świąteczne songi. Są wśród nich dwie tradycyjne kolędy, pastorałka i świąteczny hicior. Wszystko w nowoczesnej aranżacji, którą stworzył Mateusz Banasiuk. Zdecydowaliśmy się zagrać kolędy, bo chcemy wspólnie dać ludziom trochę radości i uśmiechu. Boże Narodzenie to czas kiedy znów przypominamy sobie, że Bóg w Jezusie stał się naszym bratem, bliskim, współczującym, rozumiejącym - opowiada - a to wszystko zdecydowanie powody do uśmiechu. 
Rafał zebrał swoich uczniów, przyjaciół, ludzi, z którymi śpiewa przy różnych okazjach, z którymi zna się od dominikanów i w ten sposób powstał nasz świąteczny boysband. 

Osiem męskich głosów zapowiadających nam Dobrą Nowinę. 

MUZYKA:

aranżacja: Mateusz Banasiuk
realizacja nagrania: Damian Posiła
edycja/mix/mastering: Mateusz Banasiuk

tenory: 
Tymoteusz Ekert
Mateusz Banasiuk

barytony: 
Rafał Maciejewski
Jakub Pokorski
Damian Posiła

basy:
Paweł Banach
Szymon Dębkowski
Kamil Gruszczyński
Michał Buczek

—

VIDEO:

zdjęcia: Michał Buczek, Emil Książczak
montaż: Michał Buczek
oświetlenie: Bartłomiej Borcz
produkcja i scenografia: Fundacja Malak

www.fundacjamalak.pl

​@Langustanapalmie @FundacjamalakPl 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wyszynki [#973] Smutek
 - [https://www.youtube.com/watch?v=tYb7lOoM5o8](https://www.youtube.com/watch?v=tYb7lOoM5o8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-21 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Zapraszamy Was do włączenia się w Adwentową Akcję Charytatywną:
→ https://charytatywnie.fundacjamalak.pl/  
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka cegiełka (w wersji papierowej) wyruszy do Was w drogę już 12 listopada.
Ebook - dostępny już dziś.

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 1 Księga Samuela || Rozdział 01
 - [https://www.youtube.com/watch?v=zDS6iKyHnBQ](https://www.youtube.com/watch?v=zDS6iKyHnBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Już się nie wstydzę | Premiera 25 grudnia!
 - [https://www.youtube.com/watch?v=ofc8wLEEp80](https://www.youtube.com/watch?v=ofc8wLEEp80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-20 00:00:00+00:00

Trasa "Już się nie wstydzę" to wyjątkowe spotkania, które odbyły się tej jesieni, w ponad dwudziestu miastach w Polsce. Treść, emocje i wzruszenie, które nam towarzyszyły podczas ich trwania, postanowiliśmy zarejestrować tak żeby móc przeżyć je jeszcze niejeden raz... wspólnie z Wami! Kliknij przycisk: ustaw przypomnienie i widzimy się tutaj pierwszego dnia Świąt Bożego Narodzenia ⭐️.  Nie możemy się doczekać, a TY? 🤍 

⭐️⭐️⭐️
LINK do premiery:

→ https://youtu.be/cE5sqiHeaK8

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Kolędy dla radości [01] Jest taki dzień
 - [https://www.youtube.com/watch?v=1mL-1I-WOFc](https://www.youtube.com/watch?v=1mL-1I-WOFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-20 00:00:00+00:00

Fundacja Malak wraz z Rafałem Maciejewskim postanowiła wyprodukować cztery świąteczne songi. Są wśród nich dwie tradycyjne kolędy, pastorałka i świąteczny hicior. Wszystko w nowoczesnej aranżacji, którą stworzył Mateusz Banasiuk. Zdecydowaliśmy się zagrać kolędy, bo chcemy wspólnie dać ludziom trochę radości i uśmiechu. Boże Narodzenie to czas kiedy znów przypominamy sobie, że Bóg w Jezusie stał się naszym bratem, bliskim, współczującym, rozumiejącym - opowiada - a to wszystko zdecydowanie powody do uśmiechu. 
Rafał zebrał swoich uczniów, przyjaciół, ludzi, z którymi śpiewa przy różnych okazjach, z którymi zna się od dominikanów i w ten sposób powstał nasz świąteczny boysband. 

Osiem męskich głosów zapowiadających nam Dobrą Nowinę. 

MUZYKA:

aranżacja: Mateusz Banasiuk
realizacja nagrania: Damian Posiła
edycja/mix/mastering: Mateusz Banasiuk

tenory: 
Tymoteusz Ekert
Mateusz Banasiuk

barytony: 
Rafał Maciejewski
Jakub Pokorski
Damian Posiła

basy:
Paweł Banach
Szymon Dębkowski
Kamil Gruszczyński
Michał Buczek

—

VIDEO:

zdjęcia: Michał Buczek, Emil Książczak
montaż: Michał Buczek
oświetlenie: Bartłomiej Borcz
produkcja i scenografia: Fundacja Malak

www.fundacjamalak.pl

@Langustanapalmie @FundacjamalakPl 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wyszynki [#972] Obrona
 - [https://www.youtube.com/watch?v=iXGGzWJxKjc](https://www.youtube.com/watch?v=iXGGzWJxKjc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-12-20 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Zapraszamy Was do włączenia się w Adwentową Akcję Charytatywną:
→ https://charytatywnie.fundacjamalak.pl/  
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka cegiełka (w wersji papierowej) wyruszy do Was w drogę już 12 listopada.
Ebook - dostępny już dziś.

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

