# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: 'Spencer' imagines a gloomy Christmas for Princess Diana
 - [https://www.youtube.com/watch?v=Nodrj_D72-s](https://www.youtube.com/watch?v=Nodrj_D72-s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-22 00:00:00+00:00

This week, Mary Lucia talks about "Spencer," a film that imagines a Christmas with the Royal Family in the 1980s. Kristen Stewart delivers a fascinating portrait of Princess Diana while Radiohead’s Jonny Greenwood provides a haunting soundtrack.

"The acting is amazing," Mary says. "You will be questioning, did this really happen? Or is this just the possible imaginings of a woman trapped in a loveless marriage, with the monarchy as in-laws, and all the protocol and all of the restrictions?"

The film is directed by Pablo Larrain and written by Steven Knight. "It's probably not what you think," Mary says, "but it's really well worth a look."

"Spencer" is available through Amazon Prime, iTunes, Google Play, Vudu and Microsoft Store.

WATCH MORE LISTEN TO LOOCH:
https://youtube.com/playlist?list=PLYClJc3TpV5J_sXyCfes-p6vCgOpCmleh

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#spencerfilm #marylucia

## The Jayhawks - three live songs (2019)
 - [https://www.youtube.com/watch?v=9_iwFE_FX80](https://www.youtube.com/watch?v=9_iwFE_FX80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-22 00:00:00+00:00

Two years ago tonight, The Current streamed live video of the Jayhawks in concert from the Palace Theatre in St. Paul. Watch three performances from that 2019 homecoming concert. 

SONGS PERFORMED
0:00 "I'm Gonna Make You Love Me"
3:45 "Quiet Corners & Empty Spaces"
7:00 "I'd Run Away"

PERSONNEL
Gary Louris –  guitar, lead vocals, backing vocals
Tim O'Reagan –  drums, backing vocals, lead vocals
Karen Grotberg –  keyboards, backing vocals
Kraig Johnson –  guitars, bass
Marc Perlman –  bass, acoustic guitar
John Jackson –  acoustic guitar, violin, mandolin

CREDITS
Video & Photo: Nate Ryan, Helen Teague, John Miller, Josh Voelker
Audio: Michael DeMark
Production: Erik Stromstad

FIND MORE:
2009 studio session:
https://www.thecurrent.org/feature/2009/07/17/the_jayhawks
2010 studio session: https://www.thecurrent.org/feature/2010/06/18/the-jayhawks-live-performance
2014 studio session: https://www.thecurrent.org/feature/2014/09/04/the-jayhawks-perform-live-in-the-current-studio
2016 studio session:
https://www.thecurrent.org/feature/2016/05/31/the-jayhawks-perform-in-the-current-studio
2018 studio session:
https://www.thecurrent.org/feature/2018/07/16/the-jayhawks-perform-in-the-current-studio
2019 Palace Theatre concert:
https://www.thecurrent.org/feature/2019/12/21/watch-the-jayhawks-live-in-concert-at-the-palace-theatre
2020 virtual session:
https://www.thecurrent.org/feature/2020/07/10/live-virtual-session-the-jayhawks

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#thejayhawks

## Poliça - two songs at The Current (2011)
 - [https://www.youtube.com/watch?v=u11HID4tfD4](https://www.youtube.com/watch?v=u11HID4tfD4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-12-21 00:00:00+00:00

Ten years ago, Poliça visited The Current studio to record a session in advance of releasing their debut album "Give You the Ghost." At the time, frontwoman Channy Leaneagh said "The Maker" is her favorite song on the record. Watch two performances from that 2011 session.

SONGS PERFORMED
0:00 "The Maker"
4:08 "Wandering Star"

PERSONNEL
Channy Leaneagh - vocals, synth
Chris Bierden – bass
Drew Christopherson – drums
Ben Ivascu – drums
Ryan Olson – production 

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Jon Schober; David Campbell

FIND MORE:
2011 studio session: https://www.thecurrent.org/feature/2011/11/30/polica-live
2013 session in the MPR Forum: https://www.thecurrent.org/feature/2013/10/09/polica-ubs-forum-live
2016 studio session:
https://www.thecurrent.org/feature/2016/02/01/polica-perform-in-the-current-studio
2020 studio session: 
https://www.thecurrent.org/feature/2020/02/04/polica-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#polica #thisispolica #thecurrent

