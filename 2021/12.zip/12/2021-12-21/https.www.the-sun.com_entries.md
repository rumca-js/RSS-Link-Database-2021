## Donald Trump flew on Epstein's Lolita Express private jet SEVEN TIMES, new Ghislaine Maxwell trial docs reveal | The US Sun
 - [https://www.the-sun.com/news/4315751/donald-trump-epstein-lolita-express-ghislaine-maxwell/](https://www.the-sun.com/news/4315751/donald-trump-epstein-lolita-express-ghislaine-maxwell/)
 - RSS feed: https://www.the-sun.com
 - date published: 2021-12-21 11:50:07+00:00

Donald Trump flew on Epstein's Lolita Express private jet SEVEN TIMES, new Ghislaine Maxwell trial docs reveal | The US Sun

