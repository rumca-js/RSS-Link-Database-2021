# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Reflects on Conor McGregor's Jose Aldo KO, Reacts to His Muscle Gain
 - [https://www.youtube.com/watch?v=buZLpot1PkY](https://www.youtube.com/watch?v=buZLpot1PkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-22 00:00:00+00:00

Taken from JRE #1750 w/Ari Shaffir and Tony Hinchcliffe:
https://open.spotify.com/episode/2VqQTEv1sfbDIk3b54eLXy?si=bf098e593e8b4e12

## Nancy Pelosi's Strange Response to Insider Trading Question
 - [https://www.youtube.com/watch?v=j8TRVp-7l3Q](https://www.youtube.com/watch?v=j8TRVp-7l3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-22 00:00:00+00:00

Taken from JRE #1750 w/Ari Shaffir and Tony Hinchcliffe:
https://open.spotify.com/episode/2VqQTEv1sfbDIk3b54eLXy?si=bf098e593e8b4e12

## How Shane Dorian Trained for Wipeouts on Big Waves
 - [https://www.youtube.com/watch?v=NNHgcEGDF5Q](https://www.youtube.com/watch?v=NNHgcEGDF5Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-21 00:00:00+00:00

Taken from JRE #1749 w/Shane Dorian:
https://open.spotify.com/episode/5MN9ygZmciChOZZv9kQu5L?si=0cd4eea6f5ed41d2

## Shane Dorian's Friend Survived a Shark Attack
 - [https://www.youtube.com/watch?v=1N2vIHYnsIw](https://www.youtube.com/watch?v=1N2vIHYnsIw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-12-21 00:00:00+00:00

Taken from JRE #1749 w/Shane Dorian:
https://open.spotify.com/episode/5MN9ygZmciChOZZv9kQu5L?si=0cd4eea6f5ed41d2

