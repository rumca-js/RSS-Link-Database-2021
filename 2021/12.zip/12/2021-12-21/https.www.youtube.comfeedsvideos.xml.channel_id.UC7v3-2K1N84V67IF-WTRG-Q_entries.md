# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Matrix Resurrections - Movie Review
 - [https://www.youtube.com/watch?v=YupBooxKaVE](https://www.youtube.com/watch?v=YupBooxKaVE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-12-21 00:00:00+00:00

Nearly 2 decades later, we return to the world of The Matrix. But is it a worthy sequel, or blatant nostalgia bait? Here's my review for THE MATRIX RESURRECTIONS!

