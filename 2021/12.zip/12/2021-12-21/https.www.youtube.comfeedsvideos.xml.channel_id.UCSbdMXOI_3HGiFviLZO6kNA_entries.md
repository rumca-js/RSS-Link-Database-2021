# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## These NEW VR Headsets look INSANE!
 - [https://www.youtube.com/watch?v=yKKLfEHMU0Q](https://www.youtube.com/watch?v=yKKLfEHMU0Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-12-21 00:00:00+00:00

Lets take a look at the promising future of the next generation of VR headsets set to release just next year! 

Hello and welcome to TUESDAY NEWSDAY! Today we talk about the most recent probe by the FTC into Meta and Oculus studio acquisitions as well as a BUNCH of hardware news. There’s actually a lot this time around- a new Linux based VR Computer Headset, Somnium’s very interesting new open source modular high resolution headset and VRGineer’s newest XTAL 3. This next year is going to be more interesting than I thought for VR hardware. That and so much more, I hope you enjoy!

My Links: 
Twitch.tv/Thrilluwu
Discord.gg/Thrill
Twitter.com/Thrilluwu

TIMESTAMPS:
00:00 INTRO
00:51 REC ROOM 3.4 BILLION
02:03 FACEBOOK FTC LAWSUITE
03:59 SIMULA LINUX HEADSET
07:01 MEME BREAK
07:24 SOMNIUM OPEN SOURCE HEADSET
10:05 XTAL 3 HEADSET
10:58 AFTER THE FALL 1.4 MILLION
11:39 BIGSCREEN UPDATE
12:11 QOTW
13:08 OUTRO

Sources:
https://vrgineers.com/xtal-3-virtual-reality/
https://www.roadtovr.com/rec-room-vr-funding-145-m-valuation/
https://www.macrumors.com/2021/12/18/apple-headset-less-than-a-year-away/
https://www.tomshardware.com/news/linux-producitivty-vr-headset-straps-nuc-on-head
https://simulavr.com/blog/technical-overview/
https://www.theverge.com/2021/12/16/22840635/ftc-opens-antitrust-probe-meta-deal-vr-fitness-app-supernatural
https://www.theverge.com/2021/6/16/22537795/is-facebook-cornering-the-vr-market
https://www.theinformation.com/articles/ftc-slows-meta-platforms-metaverse-strategy-by-extending-antitrust-probe-of-vr-deal?utm_source=ti_app
https://somniumspace.com/
https://www.roadtovr.com/vrchat-80m-series-d-funding/
https://www.nytimes.com/2021/11/04/technology/facebook-antitrust-lawsuit-phhhoto.html
https://www.npr.org/2020/12/09/944073889/48-attorneys-general-sue-facebook-alleging-illegal-power-grabs-to-neutralize-riv
https://twitter.com/SadlyItsBradley/status/1472915191876759559

https://www.vrfocus.com/2021/12/standalone-modular-open-source-define-somnium-spaces-first-vr-headset/

