# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Meet Commander, the Biden's new presidential pup
 - [https://www.cnn.com/videos/tv/2021/12/21/bidens-welcome-new-puppy-commander-cabrera-nr-vpx.cnn](https://www.cnn.com/videos/tv/2021/12/21/bidens-welcome-new-puppy-commander-cabrera-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 23:03:49+00:00

President Joe Biden and first lady Jill Biden have added a new a pure-bred German Shepherd puppy named Commander to the family. A cat will also be joining the first family in 2022.

## US Special Envoy for Iran warns of 'escalating crisis' if talks fail to revive Iran nuclear deal
 - [https://www.cnn.com/2021/12/21/politics/iran-nuclear-deal-rob-malley/index.html](https://www.cnn.com/2021/12/21/politics/iran-nuclear-deal-rob-malley/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 18:15:05+00:00

The time left to revive the 2015 nuclear deal with Iran is running out and raising the risk of an "escalating crisis," the United States Special Envoy for Iran, Rob Malley, told CNN's Becky Anderson on Tuesday.

## What it looks like to land on Mars and other space discoveries in 2021
 - [https://www.cnn.com/2021/12/21/world/space-discoveries-2021-scn/index.html](https://www.cnn.com/2021/12/21/world/space-discoveries-2021-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 18:02:36+00:00

This year, we got to know our universe a little bit better.

## US diplomat: Iran using nuclear expansion for more leverage won't work
 - [https://www.cnn.com/videos/politics/2021/12/21/iran-nuclear-deal-robert-malley-us-envoy-ctw-vpx.cnn](https://www.cnn.com/videos/politics/2021/12/21/iran-nuclear-deal-robert-malley-us-envoy-ctw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 17:57:24+00:00

US Special Envoy to Iran Robert Malley tells CNN's Becky Anderson the time left to revive the 2015 nuclear deal with Iran is running out and raises the risk of an "escalating crisis," which could potentially lead to negotiating a different deal.

## Fauci calls for Fox News host to be fired 'on the spot' for 'kill shot' comments
 - [https://www.cnn.com/2021/12/21/media/fauci-fox-jesse-watters/index.html](https://www.cnn.com/2021/12/21/media/fauci-fox-jesse-watters/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 17:51:55+00:00

Dr. Anthony Fauci on Tuesday said that Fox News host Jesse Watters should be fired for using violent language at a conservative conference to encourage attendees to ambush him in hopes of creating a viral moment.

## Checkmate. Putin has the West cornered
 - [https://www.cnn.com/collections/putin-intl-122121/](https://www.cnn.com/collections/putin-intl-122121/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 17:25:19+00:00



## Tom Holland makes good on his promise to boy who saved his sister from dog attack
 - [https://www.cnn.com/2021/12/21/entertainment/bridger-walker-spider-man-set-tom-holland/index.html](https://www.cnn.com/2021/12/21/entertainment/bridger-walker-spider-man-set-tom-holland/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 17:23:56+00:00

Tom Holland is a man of his word.

## Biden to announce plan for free at-home tests
 - [https://www.cnn.com/2021/12/21/politics/biden-covid-omicron-free-at-home-tests/index.html](https://www.cnn.com/2021/12/21/politics/biden-covid-omicron-free-at-home-tests/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 16:59:59+00:00

President Joe Biden will announce Tuesday a purchase of a half-billion at-home rapid Covid-19 tests and a plan to distribute them free to Americans who request them through a website, one of a series of new steps he'll unveil as the country faces a potentially crippling wintertime surge of infections.

## Tigrayan forces to withdraw from neighboring Ethiopian regions with 'immediate effect'
 - [https://www.cnn.com/2021/12/20/africa/tigray-withdrawal-rebel-forces-ethiopia-intl/index.html](https://www.cnn.com/2021/12/20/africa/tigray-withdrawal-rebel-forces-ethiopia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 16:29:43+00:00

The leader of Ethiopia's northern Tigray region announced a withdrawal of rebel forces from neighboring areas in the country on Sunday, a move that could signal the possibility of a ceasefire after 13 months of war.

## Vaccine rules Russian out of Australian Open bid
 - [https://www.cnn.com/collections/intl-covid-sports-1221/](https://www.cnn.com/collections/intl-covid-sports-1221/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 16:08:11+00:00



## 'The Matrix Resurrections' takes the red pill, but works more like a sleeping pill
 - [https://www.cnn.com/2021/12/21/entertainment/the-matrix-resurrections-review/index.html](https://www.cnn.com/2021/12/21/entertainment/the-matrix-resurrections-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 16:03:02+00:00

Complicated in the best of times, "The Matrix Resurrections" is simply convoluted, a collection of flashy digits that don't add up to much of anything. Although director/co-writer Lana Wachowski slyly comments on the commercial nature of the undertaking and it's nice seeing Keanu Reeves and Carrie-Anne Moss reunited, the better plan in hindsight might have been to completely reboot the system.

## Perfectly preserved baby dinosaur discovered curled up inside its egg
 - [https://www.cnn.com/2021/12/21/asia/baby-dinosaur-inside-egg-scn/index.html](https://www.cnn.com/2021/12/21/asia/baby-dinosaur-inside-egg-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 16:00:33+00:00

An unprecedented fossil of a baby dinosaur curled up perfectly inside its egg is shedding more light on the links between dinosaurs and birds.

## Ryan Reynolds repeatedly mistaken for Ben Affleck at New York pizza place
 - [https://www.cnn.com/2021/12/21/entertainment/ryan-reynolds-ben-affleck/index.html](https://www.cnn.com/2021/12/21/entertainment/ryan-reynolds-ben-affleck/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 15:44:06+00:00

Ryan Reynolds keeps getting mistaken for Ben Affleck and he's totally fine with it.

## Republican candidates across the country refuse to acknowledge Biden won legitimately
 - [https://www.cnn.com/collections/intl-biden-1221/](https://www.cnn.com/collections/intl-biden-1221/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 15:38:50+00:00



## Court orders Dubai ruler to pay ex-wife $728m -- one of the UK's largest ever divorce settlements
 - [https://www.cnn.com/2021/12/21/uk/princess-haya-divorce-settlement-intl/index.html](https://www.cnn.com/2021/12/21/uk/princess-haya-divorce-settlement-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 15:37:30+00:00

The ruler of Dubai Sheikh Mohammed bin Rashid al-Maktoum has been ordered to pay his ex-wife Princess Haya bint al-Hussein more than $728 million (£500 million), in one of the largest divorce settlements ever handed down by a UK court.

## The Turkish lira swings wildly as Erdogan's big gamble continues
 - [https://www.cnn.com/2021/12/21/investing/turkish-lira-erdogan-policy/index.html](https://www.cnn.com/2021/12/21/investing/turkish-lira-erdogan-policy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 15:31:49+00:00

Turkey's experiment in cutting interest rates to fight inflation has sent its currency crashing to record lows this year. Now, President Recep Tayyip Erdogan is trying to prop up the lira with a raft of new unorthodox economic measures.

## Nicole Kidman considered dropping out of 'Being the Ricardos'
 - [https://www.cnn.com/2021/12/21/entertainment/nicole-kidman-being-ricardos/index.html](https://www.cnn.com/2021/12/21/entertainment/nicole-kidman-being-ricardos/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 15:31:12+00:00

According to Nicole Kidman, internet backlash over her casting as Lucille Ball in "Being the Ricardos" almost made her step away from the project.

## China fines 'live-streaming queen' Viya $210 million for tax evasion
 - [https://www.cnn.com/2021/12/21/tech/china-livestreamer-viya-fine-tax-evasion/index.html](https://www.cnn.com/2021/12/21/tech/china-livestreamer-viya-fine-tax-evasion/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 15:09:11+00:00

Chinese live-stream shopping influencer Huang Wei, known as Viya, has been hit with a whopping $210 million penalty for tax evasion and kicked off social media.

## A son's obituary paid tribute to his 'plus-sized Jewish redneck' mom. Social media loved it
 - [https://www.cnn.com/2021/12/21/us/renay-mandel-corren-obituary-cec/index.html](https://www.cnn.com/2021/12/21/us/renay-mandel-corren-obituary-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 15:07:29+00:00

Andy Corren could not bring his mother's far-flung friends and family together for a funeral after her death this month.

## Fauci: Crowd booing Trump for booster 'doesn't make sense'
 - [https://www.cnn.com/videos/media/2021/12/21/fauci-trump-covid-19-booster-jesse-watters-john-berman-intv-newday-vpx.cnn](https://www.cnn.com/videos/media/2021/12/21/fauci-trump-covid-19-booster-jesse-watters-john-berman-intv-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 14:56:05+00:00

Dr. Fauci says he was happy to hear that former President Trump had received a Covid-19 booster, but that the crowd responding in boos highlights the divisiveness of the pandemic in American society. Fauci also responded to comments made by Fox News' Jesse Watters.

## Brian May details 'horrendous' Covid-19 battle as he begs fans to get vaccinated
 - [https://www.cnn.com/2021/12/21/entertainment/brian-may-covid-intl-scli/index.html](https://www.cnn.com/2021/12/21/entertainment/brian-may-covid-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 14:34:09+00:00

Rock music icon Brian May has urged the public to get the Covid-19 vaccine, after telling fans on Instagram he's been having a "truly horrible" time since testing positive for the virus last week.

## Penélope Cruz doesn't allow her kids on social media
 - [https://www.cnn.com/2021/12/21/entertainment/penelope-cruz-kids-social-media/index.html](https://www.cnn.com/2021/12/21/entertainment/penelope-cruz-kids-social-media/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 14:28:48+00:00

Don't look for Penélope Cruz's kids on TikTok.

## Jury set to resume deliberations in Ghislaine Maxwell's sex trafficking trial
 - [https://www.cnn.com/collections/intl-ghislaine-maxwell-trial-2120/](https://www.cnn.com/collections/intl-ghislaine-maxwell-trial-2120/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 14:14:02+00:00



## Zombies, laser tag and confusion: Here's what it's like inside Meta's virtual world
 - [https://www.cnn.com/2021/12/21/tech/meta-horizon-worlds-vr-review/index.html](https://www.cnn.com/2021/12/21/tech/meta-horizon-worlds-vr-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 14:10:41+00:00

On a chilly December afternoon I played a heart-pounding game of laser tag, flew across town on a magical broom, killed zombies in an abandoned mall, and hung out with an old friend who lives roughly 2,000 miles away — all without leaving my home or, in fact, my living room.

## Is it time to cancel your holiday plans?
 - [https://www.cnn.com/2021/12/21/health/omicron-holiday-plans-wen-wellness/index.html](https://www.cnn.com/2021/12/21/health/omicron-holiday-plans-wen-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 14:08:42+00:00

CNN Medical Analyst Dr. Leana Wen updates her advice on travel and attending holiday events as Omicron spreads rapidly throughout the United States.

## Marathon running left him 'totally depleted'. Then he became a strongman
 - [https://www.cnn.com/2021/12/21/sport/ryan-hall-marathon-running-weightlifting-spt-intl-cmd/index.html](https://www.cnn.com/2021/12/21/sport/ryan-hall-marathon-running-weightlifting-spt-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 14:03:49+00:00

Ryan Hall may hold the fastest marathon and half marathon times for a US athlete, but these days he admits that running doesn't feel like it used to.

## See the world's largest population of manta rays
 - [https://www.cnn.com/travel/article/manta-ray-maldives-spc-intl/index.html](https://www.cnn.com/travel/article/manta-ray-maldives-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 13:54:17+00:00

As Beth Faulkner bobbed up and down in the Maldives' Hanifaru Bay, she did some quick mental math.

## The tourist attractions you can't visit in 2022
 - [https://www.cnn.com/travel/article/tourist-attractions-closed-2022/index.html](https://www.cnn.com/travel/article/tourist-attractions-closed-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 13:49:19+00:00

While many of the world's most popular tourist destinations are expected to reopen to travelers in 2022, there are still some places that will be off-limits.

## 'Enormous': Secret Service reveals scope of Covid-19 fraud
 - [https://www.cnn.com/videos/politics/2021/12/21/roy-dotson-us-secret-service-covid-fraud-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/12/21/roy-dotson-us-secret-service-covid-fraud-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 13:23:56+00:00

CNN's Erica Hill speaks to special agent Roy Dotson of the US Secret Service, who has been tapped to lead an investigation into the billions of dollars of Covid-19-related fraud.

## The Ursid meteor shower is the last celestial event of the year. Here's how to watch
 - [https://www.cnn.com/2021/12/21/world/ursid-meteor-shower-2021-scn/index.html](https://www.cnn.com/2021/12/21/world/ursid-meteor-shower-2021-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 13:14:17+00:00

A crisp wind blew off the Gulf of Mexico as photojournalist and commercial photographer Mark Wallheiser set up his camera on a tripod near the edge of the water. He unfolded his camping chair, opened a cold beer and settled in for a long evening of stargazing.

## This cake may change your mind on critical race theory
 - [https://www.cnn.com/videos/opinions/2021/12/20/critical-race-theory-elliot-williams-kneads-to-know.cnn](https://www.cnn.com/videos/opinions/2021/12/20/critical-race-theory-elliot-williams-kneads-to-know.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 12:46:34+00:00

Elliot Williams, CNN legal commentator and baker extraordinaire, breaks down why so many perceive critical race theory as a threat, and why they should be "cutting into" it, like a rainbow cake, instead. This video is part of CNN Opinion's "Elliot Williams Kneads to Know" series, where Williams tries to get the internet to pay attention to important issues by discussing them while baking.

## Biennial World Cup would generate extra $4.4 billion in revenue over four years, FIFA says
 - [https://www.cnn.com/2021/12/21/football/biennial-world-cup-intl-spt/index.html](https://www.cnn.com/2021/12/21/football/biennial-world-cup-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 12:39:35+00:00

A biennial World Cup would generate in excess of $4.4 billion in revenue over a four-year cycle, delegates at FIFA's global summit have been told.

## In Dubai, city of skyscrapers, a company is building modular homes
 - [https://www.cnn.com/2021/12/21/middleeast/linq-modular-housing-dubai-spc-intl/index.html](https://www.cnn.com/2021/12/21/middleeast/linq-modular-housing-dubai-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 12:37:42+00:00

Dubai is a city known for its superlative architecture. Home to record-breakers like the world's tallest building and the world's largest shopping mall, construction is also a big part of Dubai's economy.

## Nike is trying to outrun supply chain problems
 - [https://www.cnn.com/2021/12/21/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/12/21/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 12:36:39+00:00

Plenty of people want to buy Nike clothes and sneakers. But nearly two years into the coronavirus pandemic, supply chain issues mean the company is struggling to meet that demand and grow its business.

## HBO Max releases teaser for Harry Potter reunion
 - [https://www.cnn.com/videos/media/2021/12/21/harry-potter-reunion-trailer-ovn-vpx.cnn](https://www.cnn.com/videos/media/2021/12/21/harry-potter-reunion-trailer-ovn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 12:07:37+00:00

HBO Max has released another trailer previewing the Harry Potter reunion scheduled to debut on New Year's Day 2022. (CNN, HLN and HBO are all part of WarnerMedia).

## Boeing and Airbus want Biden administration to delay rollout of 5G cell service, citing safety concerns
 - [https://www.cnn.com/2021/12/21/business/boeing-airbus-5g-biden-administration/index.html](https://www.cnn.com/2021/12/21/business/boeing-airbus-5g-biden-administration/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 11:29:48+00:00

The world's biggest commercial airplane manufacturers are telling the Biden Administration to delay the rollout of 5G cell service next month.

## Dr. Sanjay Gupta explains how Omicron compares to other variants
 - [https://www.cnn.com/videos/health/2021/11/30/covid-19-variants-mutations-explainer-orig-jk-me.cnn](https://www.cnn.com/videos/health/2021/11/30/covid-19-variants-mutations-explainer-orig-jk-me.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 10:44:54+00:00

Dr. Sanjay Gupta explains the difference between four coronavirus variants the CDC has at one point described as "Variants of Concern."

## China Mobile plans to raise up to $8.8 billion by listing shares in Shanghai
 - [https://www.cnn.com/2021/12/21/investing/china-mobile-listing-price-shanghai-intl-hnk/index.html](https://www.cnn.com/2021/12/21/investing/china-mobile-listing-price-shanghai-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 10:01:51+00:00

China Mobile is ending the year with a bang.

## Winter's wisdom: In the heart of darkness, there is a light
 - [https://www.cnn.com/2021/12/21/health/winter-christmas-new-years-wisdom-project-wellness/index.html](https://www.cnn.com/2021/12/21/health/winter-christmas-new-years-wisdom-project-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 09:18:13+00:00

Let us beat a hasty retreat. Jump into a hole, down to a cozy warren, deep below the surface.

## Japan hangs 3 death row inmates in first executions since 2019
 - [https://www.cnn.com/2021/12/21/asia/japan-executions-death-row-intl-hnk/index.html](https://www.cnn.com/2021/12/21/asia/japan-executions-death-row-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 09:12:29+00:00

Japan executed three death row inmates by hanging on Tuesday, marking the first executions the country has carried out since 2019 and the first under Prime Minister Fumio Kishida.

## Philippines' Typhoon Rai death toll rises further as some areas remain cut off from help
 - [https://www.cnn.com/2021/12/21/asia/typhoon-rai-philippines-deaths-intl-hnk/index.html](https://www.cnn.com/2021/12/21/asia/typhoon-rai-philippines-deaths-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 08:59:55+00:00

The death toll from the strongest typhoon to hit the Philippines this year surpassed 300 on Tuesday as humanitarian agencies warned the true scale of destruction remains unknown, partly because rescue workers are unable to access some disaster-hit areas.

## Flooding in Malaysia leaves 8 dead and 41,000 displaced
 - [https://www.cnn.com/2021/12/21/asia/malaysia-floods-dead-displaced-intl-hnk/index.html](https://www.cnn.com/2021/12/21/asia/malaysia-floods-dead-displaced-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 08:13:39+00:00

At least eight people have died in floods that ravaged Malaysia over the weekend, authorities said on Monday, as the government faced criticism from the public and opposition lawmakers over its rescue efforts.

## Sweden's famous 'Yule Goat' set on fire ... again
 - [https://www.cnn.com/travel/article/sweden-yule-goat-julbocken-fire/index.html](https://www.cnn.com/travel/article/sweden-yule-goat-julbocken-fire/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 07:38:40+00:00

A giant straw Yule goat in the Swedish town of Gavle, 200 miles northwest of Stockholm, was set ablaze on December 17 for the first time in five years, reviving a long-running tradition of locals illegally attempting to torch it and authorities scrambling to stop them.

## A cozy history of the ugly Christmas sweater
 - [https://www.cnn.com/style/article/ugly-christmas-jumpers/index.html](https://www.cnn.com/style/article/ugly-christmas-jumpers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 07:01:20+00:00

Move over twinkling fir trees and wreaths, eggnog, stockings and the office secret Santa -- there's a new kid in town. Over the last decade the ugly Christmas sweater has firmly embedded itself in yuletide culture.

## Remember when Bruce Willis' 'Die Hard' character fought terrorists at a Christmas party in a tank top?
 - [https://www.cnn.com/style/article/die-hard-costume-bruce-willis/index.html](https://www.cnn.com/style/article/die-hard-costume-bruce-willis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 06:30:50+00:00

Remember when Bruce Willis' character in "Die Hard" fought a group of terrorists at an office Christmas party, barefooted and wearing a tank top?

## 'She lied a lot and left me nothing': Son explains obituary for his mom that went viral
 - [https://www.cnn.com/videos/us/2021/12/21/sons-obituary-for-mom-goes-viral-smerconish-intv-ctn-vpx.cnn](https://www.cnn.com/videos/us/2021/12/21/sons-obituary-for-mom-goes-viral-smerconish-intv-ctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 04:48:41+00:00

CNN's Michael Smerconish sits down with Andy Corren, who wrote a hilarious and heartfelt obituary for his mother that ended up going viral.

## 'I'm very uncomfortable talking like this': Retired general speaks out about ominous op-ed
 - [https://www.cnn.com/videos/politics/2021/12/20/retired-generals-wapo-op-ep-2024-insurrection-anderson-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2021/12/20/retired-generals-wapo-op-ep-2024-insurrection-anderson-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 03:41:46+00:00

Retired Brig. Gen. Steven Anderson speaks with CNN's Kate Bolduan about his op-ed in the Washington Post in which he and two other retired generals warn that the US military must work to quell unrest within the armed forces to prevent another insurrection from occurring in 2024.

## 'I'm like a PhD at litigation': Looking into Trump's long history of lawsuits
 - [https://www.cnn.com/videos/politics/2021/12/21/trump-long-lawsuits-history-ac360-kaye-pkg-vpx.cnn](https://www.cnn.com/videos/politics/2021/12/21/trump-long-lawsuits-history-ac360-kaye-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-12-21 03:08:17+00:00

States, politicians, media companies, journalists and women are some of the many targets of Donald Trump's past lawsuits that date as back to 1973. CNN's Randi Kaye delves into the litigious history of the former President.

