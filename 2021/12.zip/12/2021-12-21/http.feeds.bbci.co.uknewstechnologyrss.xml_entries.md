# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Miners experiment with hydrogen to power giant trucks
 - [https://www.bbc.co.uk/news/business-59576867?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59576867?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2021-12-21 01:36:11+00:00

Anglo American is testing a hydrogen-powered giant truck in a bid to make its business greener.

