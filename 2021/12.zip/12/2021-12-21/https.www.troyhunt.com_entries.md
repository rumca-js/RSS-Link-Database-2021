## Troy Hunt: Open Source Pwned Passwords with FBI Feed and 225M New NCA Passwords is Now Live!
 - [https://www.troyhunt.com/open-source-pwned-passwords-with-fbi-feed-and-225m-new-nca-passwords-is-now-live/](https://www.troyhunt.com/open-source-pwned-passwords-with-fbi-feed-and-225m-new-nca-passwords-is-now-live/)
 - RSS feed: https://www.troyhunt.com
 - date published: 2021-12-21 08:44:20.965498+00:00

In the last month, there were 1,260,000,000 occasions where a service somewhere checked a password against Have I Been Pwned's (HIBP's) Pwned Password API. 99.7% of the time, that check went no further than one of hundreds of Cloudflare edge nodes spread around the world (95%

