# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Boston Globe covers Right to Repair featuring the chad Nathan Proctor
 - [https://www.youtube.com/watch?v=MwRdHadkHm8](https://www.youtube.com/watch?v=MwRdHadkHm8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.bostonglobe.com/2021/12/17/metro/should-massachusetts-adopt-right-repair-law-electronics/
🔵  https://www.youtube.com/watch?v=IVgUir3mwDk
🔵 https://www.youtube.com/watch?v=ZKALUEoRd7E
🔵 https://www.telegraph.co.uk/business/2021/06/06/apple-pays-millions-woman-explicit-photos-posted-online/
 
👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## NYC urban decay FOLLOWUP: 5 months later, it's still VACANT!
 - [https://www.youtube.com/watch?v=bGBr32DSu1E](https://www.youtube.com/watch?v=bGBr32DSu1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.youtube.com/watch?v=Zjd1WNhGliY

## People trust Google over Apple with their data: WTF
 - [https://www.youtube.com/watch?v=lZCXfWPtY78](https://www.youtube.com/watch?v=lZCXfWPtY78)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-12-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://youtu.be/_vWAF13KigI
🔵 https://www.washingtonpost.com/technology/2021/12/22/tech-trust-survey/

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

