# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Witcher (S2 Ep.1 Deep Dive) The Bad Kinda Bite!
 - [https://www.youtube.com/watch?v=ucqd3__FR-A](https://www.youtube.com/watch?v=ucqd3__FR-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-12-22 00:00:00+00:00

My thoughts on episode 1 of the second #Witcher season! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## DOORS OF STONE PROLOGUE!🪨Wheel of Time Prime Success📈New Malazan🪄-FANTASY NEWS
 - [https://www.youtube.com/watch?v=sfhfDXQCg18](https://www.youtube.com/watch?v=sfhfDXQCg18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-12-21 00:00:00+00:00

Let’s jump into the Fantasy News! 
Check out Campfire here today: https://www.campfirewriting.com/write/for-novelists?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q4_21  
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Intro

00:35 Doors Of Stone Prologue: https://www.reddit.com/r/KingkillerChronicle/comments/rgfyv3/the_prologue_of_the_doors_of_stone/ 

02:11 New Stephen Erikson: https://twitter.com/erikson_steven/status/1472357178551902220?t=9wcGx0ZIt_QGcl5-9P5-Rw&s=19 

02:58 Babel: https://twitter.com/kuangrf/status/1472974547569754117 

03:10 Black Sun Adaptation: https://twitter.com/roanhorsebex/status/1472031116769042435?s=21 

03:55 The Atlas Six: https://deadline.com/2021/12/the-atlas-six-amazon-viral-fantasy-novel-series-1234891233/ 

04:24 Dragonlance: https://thewertzone.blogspot.com/2021/12/new-dragonlance-novel-confirmed-for-2022.html 

07:01 Wheel Of Time success: https://thewertzone.blogspot.com/2021/12/wheel-of-time-become-amazons-most.html 

08:15 Wheel of Time New World: https://www.pcgamesn.com/new-world/wheel-of-time-event 

09:16 Spiderman Box Office: https://twitter.com/DiscussingFilm/status/1472611219425181709?t=Xp21sELbEjJ3NQPbswILmg&s=19

