## Carbon Footprint Factsheet
 - [https://css.umich.edu/publications/factsheets/sustainability-indicators/carbon-footprint-factsheet](https://css.umich.edu/publications/factsheets/sustainability-indicators/carbon-footprint-factsheet)
 - RSS feed: https://css.umich.edu
 - date published: 2021-12-21 14:30:59+00:00

Carbon Footprint Factsheet

