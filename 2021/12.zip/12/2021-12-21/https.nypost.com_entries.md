## Omicron coverage reveals how the establishment, media keep us scared
 - [https://nypost.com/2021/12/21/omicron-coverage-reveals-how-the-establishment-media-keep-us-scared/](https://nypost.com/2021/12/21/omicron-coverage-reveals-how-the-establishment-media-keep-us-scared/)
 - RSS feed: https://nypost.com
 - date published: 2021-12-21 11:43:45+00:00

Omicron coverage reveals how the establishment, media keep us scared

