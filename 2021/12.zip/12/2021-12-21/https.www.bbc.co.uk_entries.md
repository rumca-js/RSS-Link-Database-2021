## Boeing and Airbus warn US over 5G safety concerns - BBC News
 - [https://www.bbc.co.uk/news/business-59737194](https://www.bbc.co.uk/news/business-59737194)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-12-21 12:40:48.353648+00:00

The world's two biggest plane makers say the technology could have a negative impact on the aviation industry.

