## The TikTok Couch Guy on what it’s like to be investigated on the internet.
 - [https://slate.com/technology/2021/12/tiktok-couch-guy-internet-sleuths.html](https://slate.com/technology/2021/12/tiktok-couch-guy-internet-sleuths.html)
 - RSS feed: https://slate.com
 - date published: 2021-12-21 00:52:57.166721+00:00

The invasive TikTok sleuthing I experienced was not an isolated instance, but rather the latest manifestation of a large-scale sleuthing culture. 

