## The wisdom of the shaman don Juan. Quotes and aphorisms from the work of Carlos Castaneda
 - [https://www.youtube.com/watch?v=7kWVuabom54](https://www.youtube.com/watch?v=7kWVuabom54)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCEw4OujUZBaB33O1IZX5Wkg
 - date published: 2021-12-21 00:00:00+00:00

Quotes by Carlos Castaneda

