# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga (PC) music: Karsten Koch - Rollin music 9 (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=0C_tpkwDPq8](https://www.youtube.com/watch?v=0C_tpkwDPq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-02-06 00:00:00+00:00

Ingame music 9 from "Rollin" (PC, 1995) by Karsten Koch. "(Rollin DFC)Rollin-Music9 (KK)" from AMP to be exact.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 4 channel module
- 14-bit calibrated Paula output
- Infinite oversampling with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled

Visit my channel for more Amiga music.

## Amiga Paula does S3M: Karsten Koch & SchweineElf - Movements (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=et0DyYs1ko8](https://www.youtube.com/watch?v=et0DyYs1ko8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-02-06 00:00:00+00:00

"Movements" (1994) by Karsten Koch & SchweineElf/Anoxer. Art "Concorde" (1992) by Manta/X-Trade.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 16 channels
- 100% flawless playback not guaranteed (the S3M replayer might not be perfect).

Visit my channel for more Amiga music.

