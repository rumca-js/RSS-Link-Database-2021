# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## 'Free Speech Warrior' Brian Blocked My Video
 - [https://www.youtube.com/watch?v=PaOouND_p2k](https://www.youtube.com/watch?v=PaOouND_p2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-06 00:00:00+00:00

Brian Rose of London Real may not agree with you, but he'll defend to the death your right to say it. 
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Let's Talk About VLAD The Stock Impaler (RobinHood's CEO)
 - [https://www.youtube.com/watch?v=Ggpk7VrSmR0](https://www.youtube.com/watch?v=Ggpk7VrSmR0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-06 00:00:00+00:00

Y'all forget about when Robinhood lied only a month ago? I sure didn't. 
SEC Order: https://www.sec.gov/litigation/admin/2020/33-10906.pdf
Pressrelease https://www.sec.gov/news/press-release/2020-321
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

