# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Samochód Apple od Kia. Hyundai, Xiaomi Mi Air Charge, Hyperloop, smart deska klozetowa
 - [https://www.youtube.com/watch?v=4bvsA_n2NQ0](https://www.youtube.com/watch?v=4bvsA_n2NQ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-02-07 00:00:00+00:00

Czyli od Hyundaia. Tylko jak poprawnie wymówić nazwie Hyundai? To wcale nie jest takie proste. Podobnie jak niełatwe są zmagania Huaweia z przeciwnościami losu, USA, Polski i Belgii. To ładowanie bezprzewodowe od Xiaomi też ma pewne koncepcyjne wady, a to dopiero czubek góry lodowej newsów, które dla Was dziś przygotowałem.

W odcinku:
00:00 Tak się zakłada buty – Nike
00:39 Dobry wieczór!
00:44 Nowe logo Kia
01:49 Kia i Hyudai wyprodukują samochód dla Apple
03:09 Xiaomi Mi Air Charge zrewolucjonizuje ładowanie?
06:56 Kolejny koncept od Xiaomi
07:56 Podcasty medytacyjne na Spotify popularne w Polsce
08:23 Spotify będzie podsłuchiwać?
08:59 Huawei nadal zbanowany w USA
09:27 Nowy system od Huaweia jest Androidem 10
10:58 Raport Huaweia o stratach dla Polski
12:14 Akcja dot. Huaweia w Belgi
13:21 Ludzie chodzą jak pingwiny...po badaniu na covid
13:56 Smart deska klozetowa
14:48 Nowe możliwości psa robota
15:23 Życzenia dla widzów
15:43 Znośnego tygodnia!

Źródła:
Tak się zakłada buty (Nike): http://swoo.sh/3a25Uw1
SN9 wybucha przy lądowaniu: https://bit.ly/39VzIKs
Samochód od Apple: http://bit.ly/3oYH9EQ
Wyprodukowany przez Kia: http://cnet.co/3cQtfCk
Jak wymawiać Hyundai po koreańsku: https://bit.ly/3rvsUJE
Krytyka Mi Air Charge od Xiaomi: https://youtu.be/X6JDOXjvKAI
Jak to jest z tym Hyperloopem: http://bit.ly/3jrnufE
Xiaomi z rozlanym ekranem: https://youtu.be/fB-66gTRFcc
Ile osób słucha podcastów na Spotify: http://engt.co/3cQivny
Podkasty medytacyjne bardzo popularne w Polsce: http://bit.ly/3rwCnjE
Spotify będzie podsłuchiwać?: http://bit.ly/39TxhIq
Ban Huawei się utrzyma: http://bit.ly/3p0aOxD
Huawei spada z miejsca 1 na 6: http://bit.ly/36QCzCA
Nowy system Huaweia to android 10: http://bit.ly/3rw9Rih
Raport Huaweia o stratach dla Polski: http://bit.ly/3pX9kW8
Akcja dot. Huaweia w Belgii: https://bit.ly/36TG8I2
Ludzie chodzą jak pingwiny po badaniu na Covid: http://bit.ly/3typAz3
Smart deska klozetowa: http://bit.ly/36QDnr6
Nowe możliwości psa robota: https://youtu.be/WvTdNwyADZc

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

