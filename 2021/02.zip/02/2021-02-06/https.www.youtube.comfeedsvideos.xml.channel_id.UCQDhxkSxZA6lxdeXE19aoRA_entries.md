# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Destroyed Samsung Z Flip Folding Phone Restoration - Most Expensive Phone To Repair
 - [https://www.youtube.com/watch?v=Tljb-vvZ8cM](https://www.youtube.com/watch?v=Tljb-vvZ8cM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-02-06 00:00:00+00:00

This very broken folding phone gets restored.
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
Z-Flip Parts Used In This Video: https://shop.headlane.co.uk/shop/category/samsung-sm-f-series-samsung-sm-f700-galaxy-z-flip-558
(I have no affiliation with HeadLane nor did I receive any payment for putting this link here or using their parts)


Get parts, tools, and thousands of free repair guides from iFixit at: 
    https://iFixit.com/hughjeffreys
Australia Store: https://ifix.gd/2FPxhKy
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

