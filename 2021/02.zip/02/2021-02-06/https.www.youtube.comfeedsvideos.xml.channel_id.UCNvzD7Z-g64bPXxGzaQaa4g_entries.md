# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 SHADY Gamers Who Paid A HEAVY PRICE
 - [https://www.youtube.com/watch?v=m9bBx-_GWmo](https://www.youtube.com/watch?v=m9bBx-_GWmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-07 00:00:00+00:00

Some gamers have pulled off schemes, tricks, and other bad things you would never believe. Here are some crazy examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Best Unlockables You CAN'T PAY TO UNLOCK [Part 3]
 - [https://www.youtube.com/watch?v=9GDAQuT2tYU](https://www.youtube.com/watch?v=9GDAQuT2tYU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-06 00:00:00+00:00

Some video game unlockables and secrets are still only attainable the old fashioned way. Here are more of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

