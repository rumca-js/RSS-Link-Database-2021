# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Hussein zrzucił na nich bombę chemiczną, dziś odbywa się tu festiwal granatów.
 - [https://www.youtube.com/watch?v=LshGFNUh9qY](https://www.youtube.com/watch?v=LshGFNUh9qY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2021-02-06 00:00:00+00:00

🗺️ Irak #5. Dziś Baderkhan zabrał nas do Halabdży. Miasta, na które w 1988 roku została zrzucona bomba biologiczna. Dziś jest to miejsce, w którym odbywa się coroczny festiwal... granatów.

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

We vlogu wystąpili:  @BaderkhanAmerBadran i @GdzieśTyBył

IG Baderkhana: https://www.instagram.com/baderkhanamerbadran/
YT Baderkhana:  @Baderkhan Amer Badran  
IG Pawła: https://www.instagram.com/gdziestybyl/
YT Pawła: http://bit.ly/3nJfoAF

💵 Zniżka do 250 zł na nocleg z Airbnb: https://bit.ly/2U7dVqY

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
▸ "Grupa Casha" na FB: https://bit.ly/2N1a6wX

#PodróżeCasha #Kurdystan #Irak

