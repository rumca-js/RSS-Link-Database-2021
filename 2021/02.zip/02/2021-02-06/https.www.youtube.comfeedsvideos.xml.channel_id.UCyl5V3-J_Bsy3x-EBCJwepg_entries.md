# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Babylon Bee Apologizes For Offensive Article About AOC
 - [https://www.youtube.com/watch?v=kvYLBuyGn6s](https://www.youtube.com/watch?v=kvYLBuyGn6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-06 00:00:00+00:00

Any comedy writer has to be willing to admit when he took things too far, and we at The Babylon Bee are no exception. We are formally clarifying and apologizing for this offensive Alexandria Ocasio-Cortez article, which many people took the wrong way. We will do better.

## The Bee Reads LOTR Episode 6: A Conspiracy and an Old Forest
 - [https://www.youtube.com/watch?v=6p46WtAHCys](https://www.youtube.com/watch?v=6p46WtAHCys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-06 00:00:00+00:00

Kyle, Dan, and Jonathan Watson, of TheOneRing.Com, guide you to Crickhollow, where Samwise Gamgee’s conspiracy is unmasked, and then on to a spooky ancient forest that tries to kill the hobbits. Then, as Kyle puts it, a “cracked out hobo” comes to rescue them. It’s two chapters this week on The Babylon Bee Reads The Lord of the Rings!

