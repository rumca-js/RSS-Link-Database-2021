# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - THE GREAT DEVOURER [1] - TYRANID BIOFORMS & MAGOS BIOLOGIS | Warhammer 40,000 Lore/History
 - [https://www.youtube.com/watch?v=SVQmMmB1fPA](https://www.youtube.com/watch?v=SVQmMmB1fPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2021-02-06 00:00:00+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Patreon: https://www.patreon.com/Luetin 
► Siege Studios: https://siegestudios.co.uk/
► Crystal Fortress Premium Storage: http://bit.ly/3oFuDf7
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Timestamps
0:00 Intros
1:06 The Eternal Threat
4:31 Genetors - Xenobiologists
13:48 Tyranid Bioforms
20:33 Norn Queens
26:11 Synaptic Web
33:14 Tyranid Spores
42:13 Rippers
46:13 Gaunts
48:14 Termagants
49:50 Hormagaunts
53:00 Gaunt Weaponry
59:29 Tyranid Mind Slaves
1:05:59 Stage [2]

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

