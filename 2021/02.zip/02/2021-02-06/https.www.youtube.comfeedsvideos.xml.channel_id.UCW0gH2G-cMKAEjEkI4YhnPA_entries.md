# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Morgoth: Battles for Beleriand | Tolkien Explained
 - [https://www.youtube.com/watch?v=pfzxItidGms](https://www.youtube.com/watch?v=pfzxItidGms)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-02-06 00:00:00+00:00

In part two, the vala Melkor as he seeks to conquer Middle-earth!  We will track from his early moves against the elves through the Nirnaeth Arnoediad - The Battle of Unnumbered Tears.  Along the way, Morgoth creates the dragons, faces the High King Fingolfin in single combat, and has a theft for the Silmarils by Beren and Luthien.  In Part 3, we will cover his conquest, the War of Wrath, and his downfall.

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

The Killing of the Trees - John Howe
The Throne of Morgoth - Daniel Pilla
Morgoth - Dymond Starr Austin
The Oath of Feanor - Jenny Dolfen
Alqualonde - Ted Nasmith
Feanor's Last Stand - Jenny Dolfen
Death of Feanor - Jenny Dolfen
Medhros - Bella Burgolts
Humiliation - Jenny Dolfen
Melkor - Thomas Rouillard
Maedhros - A Song of Valinor - Teradiam
The Coming of Fingolfin - Jenny Dolfen
Fingon to the Rescue - Kurai Geijutsu
There Will Be Blood - Jenny Dolfen
Gondolin - Alan Lee
The Siege of Angband - John Howe
Melkor - Fox In Shadow
Then Fingon Rose Against Him - Jenny Dolfen
The Coming of Glaurung - Alan Lee
The Oath of Finrod and Barahir - Anke Eissman
The Oath of Felagund - Antti Autio
Fingolfin Rides to Angband - Kenneth Sofia
Fingolfin Challenges Morgoth at the Gates of Angband - Pete Amachree
Fingolfin's Wrath - Ted Nasmith
The High King and the Dark Lord - Rinthcog
The Gates of Angband - CK Goksoy
Morgoth - Kenneth Sofia
Morgoth and Fingolfin - JM Kilpatrick
Morgoth and Fingolfin - Helge C Balzer
Fingolfin and Morgoth - Fancisco Ramirez
Fingolfin - Michael Howe
Melkor - Mehmet Yilmazturk
Angband Unleashed - Spartank42
Spirit of Fire - CK Goksoy
Fingolfin's Challenge - John Howe
Death of Fingolfin - Abe Papkin
Morgoth and the High King of the Noldor - Ted Nasmith
The Death of Fingolfin - MySilverGreen
Melkor and Fingolfin - Vihola
Gwaihir - WETA
The Great Eagles over Gondolin - Ted Nasmith
Turgon at Fingolfin's Cairn - Ted Nasmith
Beren and Luthien in Menegroth - Donato Giancola
Luthien in the Court of Morgoth - Pete Amachree
Beren with Silmaril - Anke Eissman
Lalaith - Ted Nasmith
Silmarillion - Fumeres Art
Angband - Samice
Azaghal - Alexis Facque
Azaghal and Glaurung - Artigas
Balrog - Sander Agelink
Aure Entuluva - Jenny Dolfen
Gondolin - Ted Nasmith
Hurin - Steamey
Hill of the Slain - Ted Nasmith
Hurin in His Chair - Alan Lee
Melkor - Thomas Rouillard
Turin and Glaurung - Quentin Champion

#tolkien #morgoth #silmarillion

