# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Life or Death Farts: How Animals Use Passed Gas
 - [https://www.youtube.com/watch?v=m1unLwp0opc](https://www.youtube.com/watch?v=m1unLwp0opc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-02-07 00:00:00+00:00

We aren’t the only animals that pass gas, but other animals have found some much more creative ways to harness the power of their farts!

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Charles Copley, Jb Taishoff, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, LehelKovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.popsci.com/environment/article/2009-05/it-true-birds-cant-fart/
http://www.anapsid.org/snakefart.html
https://www.jstor.org/stable/1565572
https://doi.org/10.1016/S0990-7440(03)00017-2
http://europepmc.org/backend/ptpmcrender.fcgi?accid=PMC1809969&blobtype=pdf
https://research.ufl.edu/publications/explore/v07n2/manatees.html
https://academic.oup.com/ee/article/48/1/193/5208271#130673854
https://digitalcommons.unl.edu/cgi/viewcontent.cgi?article=1319&context=usdafsfacpub
https://doi.org/10.1016/j.jinsphys.2005.06.005
https://jhr.pensoft.net/article/1649/
https://www.pnas.org/content/106/24/9755.full
https://www.jstor.org/stable/40483140?seq=1
https://www.sciencedirect.com/science/article/abs/pii/0305049174900212
https://jeb.biologists.org/content/jexbio/201/16/2349.full.pdf
https://www.nature.com/articles/228873a0
https://blog.nature.org/science/2017/10/17/millipede-protects-itself-cyanide-yellow-spotted-bugs/
http://entnemdept.ufl.edu/creatures/trees/southern_pine_beetle.htm 
https://digitalcommons.unl.edu/usdafsfacpub/315 
https://projects.ncsu.edu/cals/course/ent525/close/SlaveAnt.html
https://www.sciencedirect.com/science/article/abs/pii/0305049174900212 
https://cymitquimica.com/search/6232-19-5/ 

Images:
https://www.flickr.com/photos/137489154@N02/22777052502
https://commons.wikimedia.org/wiki/File:Micruroides_euryxanthus.jpg
https://commons.wikimedia.org/w/index.php?curid=47396329
https://commons.wikimedia.org/wiki/File:Heringsschwarm.gif
https://commons.wikimedia.org/wiki/File:Sperm_whale_head_anatomy_(transverse_%2B_sagittal).svg
https://commons.wikimedia.org/wiki/File:Southern_Pine_Beetle_(Dendroctonus_frontalis).jpg
https://www.flickr.com/photos/99341324@N00/2570977879
https://www.eurekalert.org/multimedia/pub/40679.php
https://commons.wikimedia.org/wiki/File:Rossomyrmex_minuchae_casent0102381_profile_1.jpg
https://commons.wikimedia.org/wiki/File:Polyergus_lucidus_returning_from_raid_on_Formica_incerta.jpg
https://commons.wikimedia.org/wiki/File:Photomicrograph_of_sting_apparatus_components_journal.pone.0050400.png
https://commons.wikimedia.org/wiki/File:Polyergus_lucidus_with_host_Formica_archboldi.jpg
https://commons.wikimedia.org/wiki/File:Apheloria_virginiensis_corrugata_2014-06-24.jpg
https://commons.wikimedia.org/wiki/File:Martensodesmus_cattienensis_ozopore.jpg
https://www.flickr.com/photos/81565156@N00/3530936350

## The Science of Why Bacon and Eggs Are the Perfect Match
 - [https://www.youtube.com/watch?v=6xEum2KHCyg](https://www.youtube.com/watch?v=6xEum2KHCyg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-02-06 00:00:00+00:00

Bacon and eggs aren’t a classic flavor combo for no reason, and the science behind why they taste so good together could help us make healthier foods more appealing to our palates. 



Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://pubmed.ncbi.nlm.nih.gov/10736353/ 
https://www.sciencedirect.com/topics/nursing-and-health-professions/umami 
https://www.pnas.org/content/105/52/20930.full 
https://academic.oup.com/ajcn/article/100/2/532/4576469 
https://www.nature.com/articles/s41598-020-77107-w 
https://www.tandfonline.com/doi/abs/10.1080/10408398.2012.678422 
https://www.nature.com/articles/s41386-018-0044-6 
https://www.google.com/books/edition/Mouthfeel/4WTYDQAAQBAJ 
https://journals.sagepub.com/doi/pdf/10.1177/1934578X1601101040
https://pubmed.ncbi.nlm.nih.gov/22544776/

Image Sources:
https://www.istockphoto.com/photo/prepared-bacon-gm162454194-22084312
https://www.istockphoto.com/photo/fried-egg-gm155358881-19332971
https://www.istockphoto.com/photo/smiling-and-positive-face-made-from-fried-eggs-and-bacon-on-plate-gm919919376-252870404
https://www.istockphoto.com/photo/sweet-and-sticky-chicken-wings-gm1221948697-358384548
https://www.istockphoto.com/photo/salmon-sashimi-freshness-fish-favorite-menu-of-japanese-food-gm1186556500-334829006
https://www.istockphoto.com/photo/sun-dried-tomatoes-fresh-champignons-mozzarella-and-basil-on-a-light-yellow-background-gm905438918-249659753
https://commons.wikimedia.org/wiki/File:L-Glutamate_Structural_Formulae.png
https://www.istockphoto.com/photo/miso-ramen-noodles-with-egg-enoki-and-pak-choi-gm479542154-68069433
https://www.istockphoto.com/vector/oysters-in-the-half-shell-icon-set-gm464423952-59019314
https://www.istockphoto.com/vector/champagne-bottle-and-champagne-glass-watercolor-painting-on-white-background-gm1254662727-366799716
https://www.istockphoto.com/photo/3d-rendering-of-a-luxury-restaurant-interior-at-night-gm1248298343-363558484
https://www.istockphoto.com/photo/woman-eating-a-delicacy-oyster-close-up-at-a-restaurant-gm1147404674-309492419
https://www.storyblocks.com/video/stock/bubbles-going-up-in-thin-flute-champagne-glasses-on-a-holiday-table-with-a-bottle-of-champagne-in-ice-basket-bnqfpnpazj9nhuvki
https://www.istockphoto.com/photo/monosodium-glutamate-known-in-europe-as-the-food-supplement-e621-crystals-close-up-gm1250098627-364499041
https://www.istockphoto.com/photo/dash-flexitarian-mediterranean-diet-to-stop-hypertension-low-blood-pressure-gm1181461877-331378726
https://www.istockphoto.com/photo/fried-bacon-and-eggs-in-iron-skillet-gm507519094-84776979

