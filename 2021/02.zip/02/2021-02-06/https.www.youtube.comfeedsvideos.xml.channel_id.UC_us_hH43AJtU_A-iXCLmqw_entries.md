## Facebook blocked in Myanmar: The war for Disinformation
 - [https://www.youtube.com/watch?v=90EFjsG-nws](https://www.youtube.com/watch?v=90EFjsG-nws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_us_hH43AJtU_A-iXCLmqw
 - date published: 2021-02-06 00:00:00+00:00

Ex-Google Techlead on Myanmar's blocking of Facebook, Twitter, and Instagram, and shutting down internet access. Get 2 FREE Stocks on WeBull (Deposit $100 and get 2 stocks valued up to $1600): https://act.webull.com/k/S4oOH2yGOtHk/main
Join ex-Google/ex-Facebook engineers for my coding interview training: https://techinterviewpro.com/
💻 Videos of 100+ programming interview problems explained:  https://coderpro.com/
💻 Sign up for FREE daily coding interview practice: http://dailyinterviewpro.com/
📷 Learn how I built a $1,000,000+ business on YouTube: http://youtubebackstage.com/

💵 [LIMITED TIME] Get 2 FREE Stocks on WeBull (Deposit $100 and get 2 stocks valued up to $1600): https://act.webull.com/k/S4oOH2yGOtHk/main
🛒 My computer/camera gear: http://amazon.com/shop/techlead
🎉 Party up:
https://discord.gg/pFUBUtE
https://instagram.com/techleadhd/
https://twitter.com/techleadhd/
https://www.linkedin.com/in/techleadhd/

Disclosure: Some links are affiliate links to products. I may receive a small commission for purchases made through these links. #techlead

