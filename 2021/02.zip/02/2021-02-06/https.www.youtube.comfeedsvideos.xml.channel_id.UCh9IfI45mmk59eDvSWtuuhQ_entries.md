# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## The First Guy To Ever Open A School
 - [https://www.youtube.com/watch?v=W7yI486gaOE](https://www.youtube.com/watch?v=W7yI486gaOE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-02-06 00:00:00+00:00

Head over to http://SheetsGiggles.com/RyanGeorge and use the coupon code RYANLOVE for 14% off your Sheets & Giggles order! Get it? It's 14% because of Valentine's Day! February 14th!

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

