# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Intel - From Inventors of the CPU to Laughing Stock [Part 2]
 - [https://www.youtube.com/watch?v=LoTx9LQIKEA](https://www.youtube.com/watch?v=LoTx9LQIKEA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-02-23 00:00:00+00:00

Become smarter in 5 minutes by signing up for free today: http://cen.yt/mbcoldfusion6 - Thanks to Morning Brew for sponsoring today’s video.

Tech Society Podcast: youtu.be/aGi1tE1NO-E

Part 1: https://youtu.be/JH2nXMv6yZI

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.vox.com/2016/4/20/11463818/intel-iphone-mobile-revolution

https://wccftech.com/amd-5nm-next-generation-zen-4-ryzen-epyc-cpus-to-feature-over-25-ipc-increase/

https://www.crn.com.au/news/intel-challenges-a18-billion-fine-over-antitrust-behavior-539168

https://www.networkworld.com/article/2239461/intel-and-antitrust--a-brief-history.html

https://www.bnnbloomberg.ca/intel-talks-with-tsmc-samsung-to-outsource-some-chip-production-1.1545867

https://www.extremetech.com/extreme/227720-how-intel-lost-10-billion-and-the-mobile-market

https://www.extremetech.com/computing/227816-how-intel-lost-the-mobile-market-part-2-the-rise-and-neglect-of-atom

https://www.pcgamer.com/au/intel-to-begin-shifting-cpu-production-to-tsmc-later-this-year/

https://edition.cnn.com/2020/03/27/tech/lisa-su-amd-risk-takers/index.html

https://www.extremetech.com/computing/307409-intel-is-still-fighting-the-eu-over-its-anti-competitive-actions-against-amd

https://www.crn.com.au/news/intel-may-outsource-production-of-some-top-chips-559593

https://www.engadget.com/2012-06-15-engadget-primed-nanometers.html

https://www.digitaltrends.com/computing/intel-vs-amd-ces-2021/

https://9to5mac.com/2021/01/08/bloomberg-intel-considering-outsourcing-some-production-to-apple-chip-maker-tsmc/

https://www.pcworld.com/article/3481627/amd-ascending-how-ryzen-laptop-desktop-cpus-snatched-computing-crown-intel.html

https://www.pcworld.com/article/3519554/amds-pc-market-share-soars-during-the-fourth-quarter-thanks-to-ryzen.html

https://seekingalpha.com/article/4340807-advanced-micro-devices-inc-amd-ceo-lisa-su-on-q1-2020-results-earnings-call-transcript?part=single

https://www.bloomberg.com/news/articles/2020-12-18/microsoft-is-designing-its-own-chips-for-servers-surface-pcs?source=content_type%3Areact%7Cfirst_level_url%3Aarticle%7Csection%3Amain_content%7Cbutton%3Abody_link&sref=SvwPxqpB

https://www.pcgamer.com/au/best-cpu-for-gaming/

https://www.pcworld.com/article/3176191/ryzen-review-amd-is-back.html

https://www.pcworld.com/article/2887275/intel-moores-law-will-continue-through-7nm-chips.html

https://www.pcworld.com/article/2025758/5-pc-industry-omens-hidden-in-intels-financial-statements.html

https://www.vox.com/2016/5/2/11634168/intel-10-billion-on-mobile-before-giving-up

Greg Salazar: https://www.youtube.com/watch?v=E4ry9UOzRFE

JayzTwoCents: https://www.youtube.com/watch?v=t8PWZmY2PkA

Linus Tech Tips: https://www.youtube.com/watch?v=vuaiqcjf0bs


//Soundtrack//

**coming soon**

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

