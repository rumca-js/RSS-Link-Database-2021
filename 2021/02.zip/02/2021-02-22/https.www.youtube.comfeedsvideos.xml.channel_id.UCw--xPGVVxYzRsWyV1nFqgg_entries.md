# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Diablo 2 Remastered😈 NASA Red Rising Tweet🧑‍🚀 Wheel of Time Dagger Clip🗡️-FANTASY NEWS
 - [https://www.youtube.com/watch?v=oAnigyGOYH0](https://www.youtube.com/watch?v=oAnigyGOYH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-02-23 00:00:00+00:00

Let's jump into the fantasy news of the day! 
Checkout Campfire here today: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20 

Unraveling the pattern: https://www.youtube.com/channel/UCtQ4ZscQ-2stjM1JdcBzLxA 
The Dusty Wheel: https://www.youtube.com/channel/UCJR9kuOpT0TRh1deUl-zQqw 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 

00:00 Intro 

00:19 Wheel of Time Dagger: https://twitter.com/WOTonPrime/status/1362099497791348745   

01:13 Rosamund Pike Wheel Of Time Comments: https://screenrant.com/wheel-time-show-seasons-future-rosamund-pike/ 

01:50 We Hunt The Flame Adaptation: https://deadline.com/2021/02/stxtv-we-hunt-the-flame-hafsah-faizal-1234696511/ 

02:15 Fury of a Demon: https://fantasy-hive.co.uk/2021/02/fury-of-a-demon-by-brian-naslund-cover-reveal-and-interview/ 

02:26 NASA Tweet: https://twitter.com/christopherpong/status/1362421518874013705?s=21 

04:14 Elder Race: https://www.tor.com/2021/02/22/cover-reveals-elder-race-adrian-tchaikovsky/ 

05:02 City Of Songs: https://subterraneanpress.com/news/announcing-city-of-songs-by-anthony-ryan/ 

05:28 Diablo 2 Remastered: https://www.youtube.com/watch?v=DRP62MGOrUo 

Diablo 4 Rogue: https://www.youtube.com/watch?v=LvrLZ4yETHI 

06:34 Crunchy Roll Awards: https://www.crunchyroll.com/en-gb/anime-news/2021/02/19-1/rewatch-the-2021-anime-awards-here-and-find-out-who-won 

06:57 Mortal Combat Trailer: https://www.youtube.com/watch?v=gMZl3OYW6IU 

07:28 Daisy Ridley Spider-Woman: https://comicbook.com/movies/news/daisy-ridley-wants-play-spider-woman-sony-marvel-extended-spider-man-universe/ 

08:40  JJ Abram’s Stephen King Anthology: https://www.thewrap.com/stephen-king-jj-abrams-are-developing-an-anthology-series-of-tiny-horrors/

