# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Biden’s Town Hall DISASTER
 - [https://www.youtube.com/watch?v=EbIExhuwpu8](https://www.youtube.com/watch?v=EbIExhuwpu8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-02-23 00:00:00+00:00

Grab your Sleep Remedy Here - https://docparsley.com/jp

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here are the highlights in some commentary on President Joe Biden‘s recent Wisconsin Townhall disaster! Or their lies? Was the race schism? Was there a weakness? Tune in as you’ll see the beautiful mess to watch.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

