# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Cruella - Everything Wrong With Disney
 - [https://www.youtube.com/watch?v=HRcD-62Tsn4](https://www.youtube.com/watch?v=HRcD-62Tsn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-02-22 00:00:00+00:00

The recent trailer for Disney's Cruella pretty much highlights everything wrong with this company. Let's take a closer look.

