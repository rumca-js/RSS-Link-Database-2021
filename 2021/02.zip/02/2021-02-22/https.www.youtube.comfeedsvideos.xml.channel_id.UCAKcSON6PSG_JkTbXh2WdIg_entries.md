# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Dessa - three live performances (2018)
 - [https://www.youtube.com/watch?v=eM26SoPrkto](https://www.youtube.com/watch?v=eM26SoPrkto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-02-23 00:00:00+00:00

Three years ago this week, Dessa visited The Current to deconstruct songs from her album, "Chime." Watch three live performances of songs from "Chime" that Dessa did for Live From Here, recorded in April of 2018 at the State Theatre in Minneapolis.

SONGS PERFORMED
0:00 "Velodrome"
2:53 "Fire Drills"
6:25 "Half of You"

PERSONNEL
Dessa – vocals
Saam Hagshenas – guitar, keys, backing vocals
Kara Laudon – keys, loops, backing vocals
Jonathan Marks – drums
Matthew Santos – keys, backing vocals

CREDITS
Video & Photo: Ben Miller; American Public Media
Audio: Sam Hudson; Thomas Scheuzger
Production: Jeffy Hnilicka; Tom Campbell; American Public Media

FIND MORE:
2011 Fitzgerald Theater concert: https://www.thecurrent.org/feature/2011/11/08/dessa-live-fitz
2013 Fitzgerald Theater concert: https://www.thecurrent.org/feature/2013/07/10/dessa-fitzgerald-theater-performance-broadcast
2018 MPR Forum session:
https://www.thecurrent.org/feature/2018/02/21/dessa-the-making-of-chime

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#dessa

## Julien Baker - Virtual Session Interview
 - [https://www.youtube.com/watch?v=4V13TNoOnnk](https://www.youtube.com/watch?v=4V13TNoOnnk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-02-22 00:00:00+00:00

Julien Baker connects with The Current's Jill Riley to discuss her upcoming third studio record, Little Oblivions. In addition to the new record, Julien discusses the sense of communal creation that was instilled in her while growing up in Memphis, the tediousness of waiting to release a record, and the challenges of articulating highly personal work. Watch Julien play songs from her new record here: https://youtu.be/iefaqsiNW2I

FIND MORE: 
2018 boygenius studio session: https://www.thecurrent.org/feature/2018/11/17/boygenius-perform-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Julien Baker - Virtual Session Performance
 - [https://www.youtube.com/watch?v=iefaqsiNW2I](https://www.youtube.com/watch?v=iefaqsiNW2I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-02-22 00:00:00+00:00

Julien Baker performs two songs from her upcoming third studio album, Little Oblivions, coming out February 26, 2021 on Matador Records. Watch Julian's conversation with The Current's Jill Riley here: https://www.youtube.com/watch?v=4V13TNoOnnk&ab_channel=TheCurrent 

SONGS PERFORMED
00:00 Faith Healer
03:00 Favor

FIND MORE: 
2018 boygenius studio session: https://www.thecurrent.org/feature/2018/11/17/boygenius-perform-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

