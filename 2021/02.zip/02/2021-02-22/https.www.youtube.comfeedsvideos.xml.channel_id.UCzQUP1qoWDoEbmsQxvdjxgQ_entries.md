# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Analyzing R. Kelly
 - [https://www.youtube.com/watch?v=EvSJAANX3pE](https://www.youtube.com/watch?v=EvSJAANX3pE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-23 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1611 with Freddie Gibbs & Brian Moses. https://open.spotify.com/episode/19nLWZSUUSij0KYU6xwFmh?si=AQE0b1MqRfycStj_6iv8TA

## Freddie Gibbs Talks Cocaine with Joe Rogan
 - [https://www.youtube.com/watch?v=tlHbnW1KmQc](https://www.youtube.com/watch?v=tlHbnW1KmQc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-23 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1611 with Freddie Gibbs & Brian Moses. https://open.spotify.com/episode/19nLWZSUUSij0KYU6xwFmh?si=AQE0b1MqRfycStj_6iv8TA

## The Story of Former DC Mayor Marion Barry Getting Caught Smoking Crack
 - [https://www.youtube.com/watch?v=mZyNfKyzDHU](https://www.youtube.com/watch?v=mZyNfKyzDHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-23 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1611 with Freddie Gibbs & Brian Moses. https://open.spotify.com/episode/19nLWZSUUSij0KYU6xwFmh?si=AQE0b1MqRfycStj_6iv8TA

