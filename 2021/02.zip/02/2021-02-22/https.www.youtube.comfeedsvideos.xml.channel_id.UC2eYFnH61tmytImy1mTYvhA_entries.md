# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## A Demonstration of Modern Web Bloat
 - [https://www.youtube.com/watch?v=cvDyQUpaFf4](https://www.youtube.com/watch?v=cvDyQUpaFf4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-02-23 00:00:00+00:00

Soydevs are destroying the internet and now preventing me from eating. The internet is becoming so prohibitively bloated that doing very basic normie life things has become a huge affair and inconvenience. I just want to consooom informational content on the internet without being overburdened by trackers, ads, server-side scripting and other trash.

My website: https://lukesmith.xyz
Please donate: https://lukesmith.xyz/donate
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

BTC: bc1qk2dz5x6m3sjnkzf0mhlz9pmsz4xfjtjmfrgm9d
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinex.com/register?refer_code=ndf87 Get crypto-rich on Coinex. Get reduced exchange fees for 3 months.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

