# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Call Of Duty Should Be Afraid Of Battlefield Again
 - [https://www.youtube.com/watch?v=6QaV-IqIvhg](https://www.youtube.com/watch?v=6QaV-IqIvhg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-02-23 00:00:00+00:00

Modern Warfare 2019 attracted lapsed Battlefield players but now with the problematic integration and takeover of Call Of Duty by Cold War, it’s time to see if the door is open for Battlefield 6 to take the big team battle crown back.  

Modern Warfare 2019 attracted lapsed Battlefield players by breaking from Call Of Duty’s formula using mil-sim-inspired weapon handling, big team battle modes, and Warzone. Modern Warfare executed on an extensive year-long content plan that included new weapons, special events, and experimental modes. That all ended around the time Call Of Duty: Black Ops Cold War launched and took over the season pass, buried Modern Warfare in Warzone’s launcher, dumped around 30 weapons into Warzone, created balance issues, and gave Modern Warfare players rewards for a game they might not own. Recent investor calls by both Activision and EA have confirmed new Call of Duty and Battlefield games targeted to release in late 2021. Not only that, but Battlefield 6 is being worked on by DICE LA, now run by Vince Zampella, an original Call of Duty developer.

In this video, Aaron and Richie talk about what was so groundbreaking about Modern Warfare, why Battlefield fans loved it, and what made them leave Battlefield in the first place. This video also looks at the studios rumored to be developing both games and what advantages they might have over each other. 

The next Call of Duty and Battlefield titles are targeted to release in 2021. Battlefield 6 will have a reveal this spring. No further information has been announced on the next Call Of Duty game, however, initial trailers often drop in April or May.

## Valheim First-Person Mod Gameplay
 - [https://www.youtube.com/watch?v=72m7fcrJ1cg](https://www.youtube.com/watch?v=72m7fcrJ1cg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-02-23 00:00:00+00:00

Ever wanted to play Valheim in first-person? Well, this mod from Nexus Mods user kailen37 lets you do just that.
https://www.nexusmods.com/valheim/mods/44?tab=description

Valheim is an incredibly popular survival sim set in the Viking era. While most players are continuing to come craft and build to ensure survival, others have focused on creative ways to push the bounds of the game by developing special mods that can alter the experience in some surprising ways. One such mod--posted on the NexusMods by user kailen37--changes the camera to a third-person view, similar to games like The Elder Scrolls V: Skyrim.

In this video, GameSpot video producer Dave Jewitt took some time to play with kailen37's first-person mod in order to see how much the game changes. While the game itself was designed for the third-person perspective, the altered POV is surprisingly playable, and even adds a sense of immersion that benefits the game in a noticeable way. As Dave noted, it adds a greater sense of atmosphere to Valheim's world, potentially making for a more immersive experience for those trying to survive in the dangerous land.

With the growing popularity of Valheim, the developers have stated they will continue supporting the game for the long haul. Perhaps in the game's future we'll see official support for first-person gameplay, but until then, check out this clever mod that adds a fresh perspective to the game.

## Guilty Gear Strive Beta - Crazy Combos For EVERY Character
 - [https://www.youtube.com/watch?v=AmmynGWgZEg](https://www.youtube.com/watch?v=AmmynGWgZEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-02-22 00:00:00+00:00

We go through the entire Guilty Gear Strive Beta roster and perform a flashy combo with every single character.

Guilty Gear Strive Beta released for the public February 18th, giving players the chance to try out the famed fighting game before its release on April 6th, 2021. Notable characters such as Ky, Sol, May, and more make a return in Guilty Gear Strive.

We perform a multitude of combos, one for each character in the initial Guilty Gear Strive Beta roster. Using Roman Cancels, Overdrives, and interesting combo strings we push the combo system as far as we can. Our personal favorite's are Axl's and Ky's combo.

We have more on our site including the premiere of Ky Kikse's Dragon Install and a showcase of all the Overdrives in the Guilty Gear Strive Beta.

Timestamps
0:00 - Chipp Zanuff
0:16 - Axl Low
0:29 - May
0:42 - Potemkin
1:01 - Millia Rage
1:16 - Zato-1
1:28 - Ky Kikse
1:42 - Sol Badguy
1:58 - Faust
2:14 - Ramlethal Valentine
2:28 - Leo Whitefang
2:43 - Giovanna
2:57 - Nagoriyuki

## OUTBREAK Trailer | Season Two | Call of Duty: Black Ops Cold War & Warzone
 - [https://www.youtube.com/watch?v=j0BIVar-iSg](https://www.youtube.com/watch?v=j0BIVar-iSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-02-22 00:00:00+00:00

Check out the all new OUTBREAK Trailer for Call of Duty: Black Ops Cold War  & Warzone! This is the all new Zombies trailer for Season 2!

## What To Know About Watch Dogs: Legion Online
 - [https://www.youtube.com/watch?v=um4GFiKSjro](https://www.youtube.com/watch?v=um4GFiKSjro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-02-22 00:00:00+00:00

Watch Dogs: Legion Online has free roam, co-op, and endgame activities--here’s what you should be aware of before playing with friends. 

Watch Dogs: Legion Online brings a multiplayer component to Ubisoft's most recent open-world action-adventure game. In the online mode, players can recruit new characters, take on daily and weekly challenges, level their seasonal ranking, find collectibles such as new masks, and generally cause mayhem with friends. 

In this video, we talk about our hands-on experience playing free roam, solo and co-op missions, world events, and endgame activities. We talk over which activities are best for casual players versus coordinated teams that will need to be on mic and able to tackle complex mechanics. We also cover some of the difficulty challenges solo players might face with activities requiring simultaneous actions or fail states that kick players back several checkpoints. 

Watch Dogs: Legion is the third game in the series and is available for PlayStation 4, PlayStation 5, Xbox One, Xbox Series X/S, Google Stadia, and PC.

