# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## High School Dropout Drives Lambo To School To Flex On Classmates
 - [https://www.youtube.com/watch?v=M82GZdA28fc](https://www.youtube.com/watch?v=M82GZdA28fc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-23 00:00:00+00:00

Millionaire High School Dropout Drives Lambo To Flex On Their Old Classmates

BTW I have no problem with High School Dropouts in general. life happens, it's fine. You're not better or worse b/c of your education, but to flex your wealth on your old high school is cringe at a level hard to explain. 
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## wake up and smell the coffee (Coffeezilla's Outro) - anton pax
 - [https://www.youtube.com/watch?v=nMSQ1yoPT2c](https://www.youtube.com/watch?v=nMSQ1yoPT2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-23 00:00:00+00:00

official outro of the internet detective.  anton pax prod. gcbeats
Check out the incredibly talented Anton Pax here: https://soundcloud.com/antonpax
Check out GCBEATS here: https://www.gcbeats.net/

## A Masterclass on How To Mess Up Your Brand.
 - [https://www.youtube.com/watch?v=kBr7LEUV6iA](https://www.youtube.com/watch?v=kBr7LEUV6iA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-22 00:00:00+00:00

The best Brand Failures ever
https://www.amazon.co.uk/Brand-Failures-Biggest-Branding-Mistakes/dp/0749439270
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Day in the life of a 19 year old Millionaire
 - [https://www.youtube.com/watch?v=5A-fFF571F8](https://www.youtube.com/watch?v=5A-fFF571F8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-22 00:00:00+00:00

Next up, the 12 yr old millionaire. 
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

