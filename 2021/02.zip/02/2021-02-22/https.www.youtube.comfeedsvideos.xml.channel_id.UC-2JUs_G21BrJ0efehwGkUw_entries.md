# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## 1234 | Feist | FUNK cover ft. Madelyn Grant
 - [https://www.youtube.com/watch?v=0nI4DnR_Chg](https://www.youtube.com/watch?v=0nI4DnR_Chg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-02-22 00:00:00+00:00

CHECK OUT MADELYN'S NEW SINGLE HERE: https://www.youtube.com/watch?v=aXxbHF2gZig
Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of "1234" by Scary Pockets & Madelyn Grant.

MUSICIAN CREDITS
Lead vocal: Madelyn Grant
Drums: Lemar Carter
Bass: Anna Butterss
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Cinematography: Ricky Chavez
Director: Mike Dempsey
Camera Operators: Sammy Rothman, Alex Humphrey, Ricky Chavez
Editor: Adam Kritzberg

Recorded Live at EastWest Studios in Los Angeles, CA.

#ScaryPockets #Funk #Feist #1234 #MadelynGrant

