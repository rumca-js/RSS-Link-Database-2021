# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Sony Announces NEW PSVR 2 and Upgrades
 - [https://www.youtube.com/watch?v=3PHo8fOGup0](https://www.youtube.com/watch?v=3PHo8fOGup0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-02-23 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news. Sony drops a huge announcement this morning for a brand new VR system for the PS5 soming within the next few years. Not much is known, but here is everything we know so far! By the way I should also mention that this thumbnail is certainly NOT what the new PSVR looks like, this is just a concept render that I found on google and spruced up a little bit. A ton of other stuff happened this week as well including new full body trackers from Manus and a couple other enterprise headset updates as well. 
#tuesdaynewsday #VR #PSVR

My links-

2nd Channel:
https://youtu.be/Xp-p5RGoGpM
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill
Ridge Wallet
ridge.com/THRILL + 10% of



sources-
https://www.engadget.com/apple-vr-ar-headset-rumors-141606384.html?guccounter=1&guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAAIjyi3Xo7Ra5qcxZ0zdo9StAlf9A56jGR7XliGbSDpGd2RnMjWrZ9crdZGOkW_pL6FjU7q5VtRAZH_316AGJzudhZeGk22wuYTpuZezqQ-fOzLlcz0e28k_IoyULG6455DFUFTlNBW9-A_VSN0wpm3V7IBHXEBMMKIAYGEbFgpJm
https://www.roadtovr.com/jvc-enterprise-xr-120-fov-5k-resolution/
https://www.roadtovr.com/lynx-reveals-first-through-the-lens-footage-of-r-1-mr-headset/
https://www.roadtovr.com/leak-samsung-ar-glasses-smart-concept/
https://www.roadtovr.com/manus-pro-steamvr-tracker/
https://vrscout.com/news/manus-pro-tracker-pro-tracking-steamvr/
https://www.manus-vr.com/steamvr-tracker
https://blog.playstation.com/2021/02/23/introducing-the-next-generation-of-vr-on-playstation/
https://www.reddit.com/r/VR_memes/comments/ljzx9v/oh_childbless_your_sweet_little_heart/



Ben Langs Wingman in VR-
https://www.roadtovr.com/what-i-learned-from-building-an-iconic-weapon-from-apex-legends-in-vr/

Music- Outro Protostar: Overdrive Instrumental

