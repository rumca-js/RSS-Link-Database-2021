# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Do We Need To Get WEIRD To Reawaken DEAD POLITICS? | Russell Brand & Adam Curtis
 - [https://www.youtube.com/watch?v=OTbctiVgMHo](https://www.youtube.com/watch?v=OTbctiVgMHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-02-23 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

This from Part #2 of Under The Skin with the genius documentary filmmaker #AdamCurtis. You can listen to Part 1 and 2 of this podcast with Adam over on Luminary: https://luminary.link/russell

Adam's latest documentary, Can't Get You Out Of My Head: An Emotional History of the Modern World, is a 6-part series that you can now watch on the BBC.  

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

