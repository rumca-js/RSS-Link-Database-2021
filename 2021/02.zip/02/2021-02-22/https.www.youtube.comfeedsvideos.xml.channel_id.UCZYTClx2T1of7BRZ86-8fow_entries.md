# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Pandas LOVE Rolling in Horse Manure
 - [https://www.youtube.com/watch?v=jntKiLabHMU](https://www.youtube.com/watch?v=jntKiLabHMU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-02-23 00:00:00+00:00

If you’re lucky enough to witness a panda applying a ripe layer of horse poop body paint to itself, you might assume it is a similar behavior to a dog frolicking in the stink of a dead animal. But in actuality, these pandas are reducing the bitter sting of the cold. 

SciShow is supported by Brilliant.org. Go to https://Brilliant.org/SciShow to get 20% off of an annual Premium subscription

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Charles Copley, Jb Taishoff, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, LehelKovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.pnas.org/content/117/51/32493
https://www.sciencedirect.com/topics/medicine-and-dentistry/caryophyllene
https://www.sciencedirect.com/topics/medicine-and-dentistry/caryophyllene-oxide
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3119154/
https://www.ncbi.nlm.nih.gov/books/NBK5238/

Image Sources:
https://www.istockphoto.com/photo/panda-bear-gm1156418364-315156918
https://www.istockphoto.com/photo/green-bamboo-background-gm1253804985-366269640
https://www.istockphoto.com/photo/fresh-horse-manure-gm988314964-267985376
https://www.istockphoto.com/photo/male-hand-gesture-and-sign-collection-isolated-on-white-background-with-clipping-path-gm1215126305-353808417
https://www.istockphoto.com/photo/cub-of-giant-panda-bear-playing-on-tree-chengdu-china-gm469451158-27617515
https://www.istockphoto.com/vector/winter-background-with-snow-gm1180480242-330734900
https://www.storyblocks.com/video/stock/cartoon-panda-bear-bbebzkyc8ka5fln0i
https://www.istockphoto.com/photo/group-of-giant-panda-eating-bamboo-chengdu-china-gm158559762-22523589
https://www.istockphoto.com/vector/thermometer-simple-gm1160427702-317639891
https://www.istockphoto.com/vector/panda-logo-gm1182998099-332434828
https://www.istockphoto.com/vector/green-sprout-in-pile-of-ground-gm924159350-253641458
https://www.istockphoto.com/vector/nose-gm511979556-86911137
https://www.istockphoto.com/photo/peppercorn-melange-background-gm170051555-19370393
https://www.istockphoto.com/photo/melissa-officinalis-leaves-isolated-on-white-background-gm119239621-14119906
https://www.istockphoto.com/photo/background-texture-made-of-green-eucalyptus-leaves-with-raindrop-dew-flat-lay-top-gm1273345401-375253727
https://www.istockphoto.com/photo/haystack-rolls-in-agricultural-field-gm1256751436-368088905
https://www.istockphoto.com/photo/close-up-of-cute-panda-pulling-a-face-gm184154276-16961638
https://www.istockphoto.com/photo/lab-mouse-gm172289011-3710874
https://www.istockphoto.com/vector/set-of-medical-inforgraphic-elements-gm166681402-23634153
https://www.istockphoto.com/vector/papercut-christmas-scene-with-night-sky-and-fir-trees-gm1272200332-374538940
https://www.istockphoto.com/vector/exclamation-mark-in-cartoon-style-alarm-vector-icon-gm1139629486-304663998
https://www.istockphoto.com/photo/peppermint-candy-gm174787065-22190581
https://www.istockphoto.com/photo/giant-panda-in-snow-gm849728086-139490013

## The 22 Year-Old Chemist Who Changed Leprosy Treatment | Great Minds
 - [https://www.youtube.com/watch?v=dymJcBkGlbs](https://www.youtube.com/watch?v=dymJcBkGlbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-02-22 00:00:00+00:00

A cure for leprosy eluded humans for thousands of years, until the pioneering chemistry work of Alice Ball. With her treatment, patients recovered enough to be discharged from the hospital by the hundreds.

Go to http://Brilliant.org/SciShow to try their new Statistics course. Sign up now and get 20% off an annual Premium subscription.

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org


----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Charles Copley, Jb Taishoff, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, LehelKovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2682583/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC444418/
https://www.researchgate.net/profile/John_Parascandola/publication/277597573_Chaulmoogra_Oil_and_the_Treatment_of_Leprosy/links/58eb9e430f7e9b6b274b9200/Chaulmoogra-Oil-and-the-Treatment-of-Leprosy.pdf
https://www.nationalgeographic.com/news/2018/02/alice-ball-leprosy-hansens-disease-hawaii-womens-history-science/
https://www.uhfoundation.org/impact/students/woman-who-changed-world
https://www.thoughtco.com/definition-of-saponification-605959
https://www.chemistryworld.com/culture/alice-balls-treatment-for-leprosy/4011313.article?adredir=1 
https://www.chemguide.co.uk/organicprops/esters/background.html
https://zenodo.org/record/1496183#.X7Y2QWhKiUm
http://www.northwesthawaiitimes.com/hnsept07.htm
https://books.google.de/books?id=uomdpaHWaC0C&pg=PA178&lpg=PA178&dq=alice+augusta+ball&redir_esc=y&hl=de#v=onepage&q=alice%20ball&f=false
https://www.hawaii.edu/offices/bor/distinction.php?person=ball
https://www.imdb.com/title/tt10318550/

Images:
https://en.wikipedia.org/wiki/File:Leprosorium.jpg
https://commons.wikimedia.org/wiki/File:M_leprae_ziehl_nielsen2.jpg
https://en.wikipedia.org/wiki/File:Alicia_Augusta_Ball.jpg
https://commons.wikimedia.org/wiki/File:James_Presley_Ball_(1825-1904)_from_Willis_1993_from_Mumford_1980.jpg
https://commons.wikimedia.org/wiki/File:Colleges_and_Universities_-_Cornell_University_-_one_of_the_dark_rooms_-_NARA_-_26425820.jpg
https://en.wikipedia.org/wiki/File:Image-Hydnocarpus_annamensis_Flacourtiaceae.JPG
https://commons.wikimedia.org/wiki/File:Chaulmoogra_oil_factory_of_Prasana_Kumar_Sen,_Chittagong._Ph_Wellcome_V0027698.jpg
https://en.wikipedia.org/wiki/File:Pouring_lye_into_water_to_make_soap.jpg
https://en.wikipedia.org/wiki/File:Dr_Isabel_Kerr_European_missionary_vaccinating_a_child_Wellcome_L0069838.jpg
https://commons.wikimedia.org/wiki/File:Marotti.jpg

