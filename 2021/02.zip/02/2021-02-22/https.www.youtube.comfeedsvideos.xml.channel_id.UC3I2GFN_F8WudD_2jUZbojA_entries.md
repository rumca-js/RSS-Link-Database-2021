# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Yves Jarvis - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=cz6nBoVyx9c](https://www.youtube.com/watch?v=cz6nBoVyx9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-23 00:00:00+00:00

http://KEXP.ORG presents Yves Jarvis performing live, recorded exclusively for KEXP.

Songs:
In Every Mountain
Semula 
For Props
Fact Almighty
Victim 

https://www.yvesjarvis.com
http://kexp.org

## Yves Jarvis - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=bEkC-ew9G5o](https://www.youtube.com/watch?v=bEkC-ew9G5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-22 00:00:00+00:00

http://KEXP.ORG presents Yves Jarvis sharing a live performance recorded exclusively for KEXP and talking to Larry Mizell, Jr., host of The Afternoon Show. Recorded February 11, 2021.

Songs:
In Every Mountain
Semula 
For Props
Fact Almighty
Victim 

https://www.yvesjarvis.com
http://kexp.org

