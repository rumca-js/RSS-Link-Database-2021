# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## The Insane Lies About The Texas Blackouts
 - [https://www.youtube.com/watch?v=PmYvkCXXI4E](https://www.youtube.com/watch?v=PmYvkCXXI4E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2021-02-22 17:57:16+00:00

Subscribe to Climate Town: https://www.youtube.com/c/climatetown?sub_confirmation=1
PATREON PAGE: https://www.patreon.com/ClimateTown
Instagram: https://www.instagram.com/climatetown


Shot and cowritten by the incredibly talented Matt Nelsen: https://mattofnewyork.com/
Hire him for writing, videography, punch ups, editing, basically anything that involves video.

Austin Mutual Aid: https://www.gofundme.com/f/kick-the-cold-austin-mutal-aid
Houston Mutual Aid: https://www.gofundme.com/f/mutualaidhou
Dallas Mutual Aid: https://feedthepeopledallas.com/
Austin Disaster Relief: https://adrn.org/

Groups to Join:
Sunrise Movement: https://www.sunrisemovement.org/volunteer/
Extinction Rebellion: https://extinctionrebellion.us/get-involved
Climate Action Network: http://www.climatenetwork.org/

Things to read:
The Merchants of Doubt: https://www.merchantsofdoubt.org/
All We Can Save: https://www.allwecansave.earth/
The Uninhabitable Earth: https://www.penguinrandomhouse.com/books/586541/the-uninhabitable-earth-by-david-wallace-wells/
This Changes Everything: Capitalism vs. The Climate: https://thischangeseverything.org/book/

Sources:
https://www.ferc.gov/sites/default/files/2020-04/08-16-11-report.pdf
https://www.eia.gov/todayinenergy/detail.php?id=45476
http://www.ercot.com/content/wcm/lists/200196/Wind_One_Pager_June_2020.pdf
http://www.ercot.com/content/meetings/ros/keydocs/2014/0306/ROS_Jan_6_EEA_Report.pdf
https://abcnews.go.com/Business/wireStory/texas-governors-biggest-donors-energy-industry-failed-75997821
https://go.icf.com/rs/072-WJX-782/images/ICF%20-%20Winter%20Storms%20Wreak%20Havoc%20on%20ERCOT%20Grid.pdf
https://www.texastribune.org/2021/02/16/natural-gas-power-storm/
https://www.texastribune.org/2021/02/16/texas-wind-turbines-frozen/
https://www.statesman.com/story/news/2021/02/17/texas-energy-wind-power-outage-natural-gas-renewable-green-new-deal/6780546002/
https://www.nytimes.com/2021/02/17/climate/texas-blackouts-disinformation.html
https://insideclimatenews.org/news/18022021/inside-clean-energy-texas-power-crisis/
https://www.curbed.com/2021/02/texas-blackouts-energy-grid-failure.html
https://www.wltx.com/article/weather/polar-vortex-brings-extreme-cold-and-winter-weather-to-central-us/101-939e7de5-0e4d-419b-b3fb-c76a6d78ae91
Tucker's very fun 9-minute video: https://www.youtube.com/watch?v=lA46v_aMidQ

