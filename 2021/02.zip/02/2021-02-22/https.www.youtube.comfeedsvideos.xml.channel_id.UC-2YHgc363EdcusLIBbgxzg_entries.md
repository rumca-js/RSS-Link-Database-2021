# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Nebula Original Series Mysteries Of The Human Body - Teaser
 - [https://www.youtube.com/watch?v=pCL1Uqei1YQ](https://www.youtube.com/watch?v=pCL1Uqei1YQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-02-22 00:00:00+00:00

It's a 6-part series launching in March only on Nebula. To see it, sign up for the Nebula/CuriosityStream bundle for only $14.79 at http://www.curiositystream.com/joescott 



Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

## The Crazy Science Behind Insect Plagues | Answers With Joe
 - [https://www.youtube.com/watch?v=wtE9Mkodi48](https://www.youtube.com/watch?v=wtE9Mkodi48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-02-22 00:00:00+00:00

Get Nebula and CuriosityStream for only $14.79 when you sign up at http://www.curiositystream.com/joescott
Plagues of locusts have been a pestilence since biblical times. But swarm behavior is a fascinating survival tool that many species engage in, and as scientists are learning, they have a lot to teach us about intelligence. 


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

