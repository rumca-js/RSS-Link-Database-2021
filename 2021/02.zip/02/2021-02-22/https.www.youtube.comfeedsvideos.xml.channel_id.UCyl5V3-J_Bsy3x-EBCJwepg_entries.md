# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Fighting The Left As A Libertarian: Jeff Deist Interview
 - [https://www.youtube.com/watch?v=PiEefj4xSIQ](https://www.youtube.com/watch?v=PiEefj4xSIQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-23 00:00:00+00:00

In this episode of The Babylon Bee Podcast, Kyle and Dan talk to Jeff Deist. They talk about economics, Covid, and Disneyland security. Jeff is the president of the Mises Institute, where he serves as a writer, public speaker, and advocate for property, markets, and civil society. He is the host of The Human Action Podcast. He previously worked as a longtime advisor and chief of staff to former Congressman Dr. Ron Paul. 

Be sure to check out The Babylon Bee YouTube Channel for more podcasts, podcast shorts, animation, and more.

To watch or listen to the full podcast, become a subscriber at https://babylonbee.com/plans.

## The Babylon Bee Randomly Generates A Christian Movie Script -- And It's Hilarious
 - [https://www.youtube.com/watch?v=ON_nlaz6tHU](https://www.youtube.com/watch?v=ON_nlaz6tHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-22 00:00:00+00:00

On The Babylon Bee Podcast, Kyle and Ethan use a plot generator website to create the next hit Christian movie starring Kirk Cameron and Kevin Sorbo. Read along at the link below.

Award-Winning Christian Movie Script 
https://www.plot-generator.org.uk/gndx1r0/evil-satan.html 

See the full show here:
https://youtu.be/Z_oD3bpBiLQ

Subscribe to The Babylon Bee to help this movie get made. 

Hit the bell to get your daily dose of fake news that you can trust.

