# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Unboxing Counterfeit LTT Merch!
 - [https://www.youtube.com/watch?v=GT3Cg7dmWxE](https://www.youtube.com/watch?v=GT3Cg7dmWxE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-23 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Linus unboxes fake merchandise from aliexpress, Amazon, and other wacky sites. Spoiler alert: none of them are as good as lttstore.com

Products shown from https://lttstore.com:
LTT Underwear
LTT Sweatband
LTT Beanie
LTT Desk Pad
LTT GPU Shirt
LTT Crewneck Sweater
LTT CPU Pillow

Discuss on the forum: https://linustechtips.com/topic/1309035-unboxing-counterfeit-ltt-merch/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Just How Bad is Mixing Memory?
 - [https://www.youtube.com/watch?v=bTS0ybQ3lCI](https://www.youtube.com/watch?v=bTS0ybQ3lCI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-22 00:00:00+00:00

Atari 3/4 Size Arcade Cabinet - Full Kit: https://micro.center/96a0b
Atari Bartop Arcade Cabinet - Full Kit: https://micro.center/a1180
Micro Center Retro Arcade Builder: https://micro.center/70da0

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

See what happens when you mix RAM DIMMS from different manufacturers!


Buy AMD Ryzen 5 3600X CPU: https://geni.us/TlVqO

Buy ASUS B550 Plus TUF Gaming: https://geni.us/yANC32

Buy Nvidia RTX 2060 Super: https://geni.us/ljCdaC

Buy Cooler Master Hyper 212 LED CPU Cooler: https://geni.us/CTEo

Buy Corsair Vengeance LPX 2x8GB DDR4 RAM: https://geni.us/fWCeoA

Buy Corsair Vengeance RGB Pro 8x8GB DDR4 RAM: https://geni.us/JkAO

Buy Crucial Ballistix 2x16GB DDR4 RAM: https://geni.us/b5HzHJ3

Buy Crucial Ballistix RGB 2x8GB DDR4 RAM: https://geni.us/woqL4

Buy G.Skill Sniper X 2x8GB DDR4 RAM: https://geni.us/2GRwy

Buy G.Skill Trident Z RGB 2x8GB DDR4 RAM: https://geni.us/Ct9LrxA

Buy G.Skill Trident Z Neo 2x8GB: https://geni.us/N477Zt

Purchases made through some store links may provide some compensation to Linus Media Group.

Memory Kit Info:
  Corsair Vengeance LPX 2x8GB 3000MHz
  Corsair Vengeance RGB 8x8GB 2666MHz
  Crucial Ballistix 2x16GB 3200MHz
  Crucial Ballistix RGB 2x8GB 3200MHz
  G.Skill Sniper X 2x8GB 3400MHz
  G.Skill Trident Z RGB 2x8GB 4000MHz
  G.Skill Trident Z Neo 2x8GB 3600MHz

Discuss on the forum: https://linustechtips.com/topic/1308636-just-how-bad-is-mixing-memory/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

