# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## wallstreetbets investor roaringkitty sued over DUMB premise
 - [https://www.youtube.com/watch?v=WYTQUc7VcNc](https://www.youtube.com/watch?v=WYTQUc7VcNc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-02-17 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.bloomberg.com/news/articles/2021-02-17/-roaring-kitty-sued-for-securities-fraud-over-gamestop-rise

https://www.reddit.com/user/DeepFuckingValue/

https://www.youtube.com/watch?v=YCtzBJMRlCA

We are not financial services or investment professionals and this is not investment advice. Do your own Research
Our content is intended to be used and must be used for entertainment purposes only. It is very important to do your own analysis before making any investment based on your own personal circumstances. You should take independent financial advice from a professional in connection with, or independently research and verify, any information that you find in these videos and wish to rely upon, whether for the purpose of making an investment decision or otherwise.

No Investment Advice
Our Youtube channel is an opinion/podcast platform. We are not a broker/dealer, we are not an investment advisor, we have no access to non-public information about publicly traded companies, and this is not a place for the giving or receiving of financial advice, advice concerning investment decisions or tax or legal advice. We are not regulated by the Financial Services Authority.

The value of shares and investments and the income derived from them can go down as well as up;
Investors may not get back the amount they invested - losing one's shirt is a real risk;
Past performance is not a guide to future performance.

