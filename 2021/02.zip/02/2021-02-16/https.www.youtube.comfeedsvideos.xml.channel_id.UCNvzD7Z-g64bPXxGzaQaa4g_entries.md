# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 35 NEW PC Games of 2021
 - [https://www.youtube.com/watch?v=Vl-MZXYvjhw](https://www.youtube.com/watch?v=Vl-MZXYvjhw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-17 00:00:00+00:00

Looking for games to play on PC? Here are all of the new PC games to pay attention to throughout 2021.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


35 The Day Before

Platform : PC

Release Date : TBA



34 Manor Lords

Platform : PC

Release Date : TBA



33 OUTRIDERS

Platform : PC PS4 PS5 Xbox One XSX|S April 1, 2021

Release Date : Stadia 2021



32 LEGO STAR WARS: THE SKYWALKER SAGA

Platform : PC PS4 PS5 Xbox One XSX|S Switch

Release Date : Q1/Q2 2021



31 HUMANKIND

Platform : PC Stadia 

Release Date : April 22, 2021



30 CHIVALRY 2

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : June 9, 2021



29 GHOSTWIRE: TOKYO

Platform : PC PS5

Release Date : October 2021



28 STARFIELD

Platform : PC

Release Date : TBA



27 Senua's Saga: Hellblade II

Platform : PC XSX|S

Release Date : TBA 2021



26 Everspace 2

Platform : PC PS4 Xbox One

Release Date : January 2021



25 Evil Genius 2

Platform : PC

Release Date : March 31, 2021



24 The Ascent

Platform : PC Xbox One XSX|S

Release Date : TBA 2021



23 Outlast Trials

Platform : PC

Release Date : 2021



22 Scorn

Platform : PC XSX|S

Release Date : TBA 2021



21 Prince of Persia: The Sands of Time Remake 

Platform : PC PS4 Xbox One

Release Date : TBA 2021



20 Little Nightmares 2

Platform : PC PS4 PS5 Xbox One XSX|S Switch Stadia

Release Date : February 11, 2021



19 State of decay 3

Platform : PC XSX|S

Release Date : TBA



18 Everwild

Platform : PC XSX|S

Release Date : TBA



17 S.T.A.L.K.E.R. 2

Platform : PC XSX|S

Release Date : TBA



16 Atomic Heart

Platform : PC PS4 PS5 Xbox one XSX|S

Release Date : TBA



15 Biomutant 

Platform : PC PS4 Xbox One

Release Date : May 25, 2021



14 Age of Empires 4  

Platform : PC

Release Date : TBA



13 Ruined King | LoL RPG

Platform : PC

Release Date : 2021



12 Vampire: The Masquerade - Bloodlines 2 

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : TBA 2021



11 Resident Evil Village 

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : May 7, 2021



10 New World

Platform : PC

Release Date : Q2 2021



9 Gotham Knights 

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : TBA 2021



8 Elden Ring 

Platform : PC PS4 Xbox One

Release Date : TBA



7 Halo Infinite 

Platform : PC XSX|S Xbox One

Release Date : Q3 2021



6 Back 4 Blood 

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : June 22, 2021



5 Deathloop 

Platform : PC PS5

Release Date : May 21, 2021



4 Hitman 3

Platform : PC PS4 PS5 Xbox One XSX|S Stadia 

Release Date : January 20, 2021



3 Far Cry 6 

Platform : PC PS4 PS5 Xbox One XSX|S Stadia

Release Date : Q2 2021



2 Dying light 2 

Platform : PC PS4 Xbox One

Release Date : TBA





1 Valheim 

Platform : PC 

Release Date : feb 02, 2021





BONUS



MASS EFFECT LEGENDARY EDITION

Platform : PC PS4 Xbox One

Release Date : May 14, 2021



NieR Replicant ver.1.22474487139…

Platform : PC PS4 Xbox One

Release Date : April 22, 2021

## 7 NEAR IMPOSSIBLE QUESTS in Video Games
 - [https://www.youtube.com/watch?v=uTG5O6KJdlk](https://www.youtube.com/watch?v=uTG5O6KJdlk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-16 00:00:00+00:00

Some video games ask you to do ridiculously challenging, frustrating, or tedious tasks for completion's sake. Here are the most demanding in-game quests we've hated.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

