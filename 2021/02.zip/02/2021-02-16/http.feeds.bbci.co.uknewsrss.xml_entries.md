# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'The alpha dog in football' - Mbappe's magic upstages Messi at Nou Camp
 - [https://www.bbc.co.uk/sport/football/56092819](https://www.bbc.co.uk/sport/football/56092819)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 23:47:08+00:00

Kylian Mbappe nets a sublime Champions League hat-trick for Paris St-Germain to upstage Barcelona's Lionel Messi on his own turf and draw comparisons with Brazilian Ronaldo.

## Murmurations above supermarket 'wow' shoppers
 - [https://www.bbc.co.uk/news/uk-england-norfolk-56084376](https://www.bbc.co.uk/news/uk-england-norfolk-56084376)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 16:41:53+00:00

The flock started to settle in trees near Asda, on Hall Road, Norwich at the weekend.

## Asda: How to buy a £6.8bn supermarket for £780m
 - [https://www.bbc.co.uk/news/business-56085128](https://www.bbc.co.uk/news/business-56085128)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 13:36:25+00:00

Asda has new owners - but they are borrowing £4bn to finance the deal. Will the debt burden be too great?

## In pictures: The carnival that wasn't
 - [https://www.bbc.co.uk/news/world-latin-america-56083525](https://www.bbc.co.uk/news/world-latin-america-56083525)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 12:20:11+00:00

Rio would normally be a riot of colour at this time of year, but carnival had to be postponed.

## Zahawi: Domestic vaccine passports 'not in our planning'
 - [https://www.bbc.co.uk/news/uk-56082530](https://www.bbc.co.uk/news/uk-56082530)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 09:00:20+00:00

But the UK's vaccine minister says certificates will be provided if people need them for international travel.

## Burgh Island statue 'should be pilchards not pirates'
 - [https://www.bbc.co.uk/news/uk-england-devon-56016080](https://www.bbc.co.uk/news/uk-england-devon-56016080)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 06:57:03+00:00

Pirates Anne Bonny and Mary Read broke gender boundaries - but "do not belong" on Burgh Island.

## What to look out for in Champions League knockout stages
 - [https://www.bbc.co.uk/sport/football/56014998](https://www.bbc.co.uk/sport/football/56014998)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 06:06:34+00:00

Home games being moved thousands of miles and former champions finding form as others enter a crisis, what you need to know about the Champions League knockout stages.

## Myanmar coup: UN warns Myanmar junta of 'severe consequences'
 - [https://www.bbc.co.uk/news/world-asia-56074429](https://www.bbc.co.uk/news/world-asia-56074429)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 05:50:39+00:00

The UN envoy says "the right of peaceful assembly must fully be respected", as protests continue.

## The papers: 'Final lockdown?' and 'Royal soap Oprah'
 - [https://www.bbc.co.uk/news/blogs-the-papers-56078537](https://www.bbc.co.uk/news/blogs-the-papers-56078537)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 05:31:22+00:00

Tuesday's papers report Boris Johnson's warning that England's current lockdown must be the last.

## Covid in Scotland: Sturgeon set to confirm phased return to schools
 - [https://www.bbc.co.uk/news/uk-scotland-56072396](https://www.bbc.co.uk/news/uk-scotland-56072396)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 04:24:08+00:00

The first minister has said she is "very keen" to proceed with a phased return to more normal schooling.

## GB's Hewett & Reid win Australian Open wheelchair doubles title
 - [https://www.bbc.co.uk/sport/tennis/56080238](https://www.bbc.co.uk/sport/tennis/56080238)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 04:23:05+00:00

Britons Alfie Hewett and Gordon Reid beat Stephane Houdet and Nicolas Peifer to defend their Australian Open men's wheelchair doubles title.

## Osaka cruises into Australian Open semi-finals
 - [https://www.bbc.co.uk/sport/tennis/56080232](https://www.bbc.co.uk/sport/tennis/56080232)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 03:59:55+00:00

Three-time Grand Slam champion Naomi Osaka cruises past Hsieh Su-wei in just 66 minutes to reach the semi-finals of the Australian Open.

## Students 'see the beauty in the ordinary'
 - [https://www.bbc.co.uk/news/in-pictures-55995748](https://www.bbc.co.uk/news/in-pictures-55995748)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 02:22:18+00:00

First-year photography students at the University for the Creative Arts show off their work.

## Covid: Rapid tests could help reopen nightclubs, PM suggests
 - [https://www.bbc.co.uk/news/business-56077372](https://www.bbc.co.uk/news/business-56077372)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 02:16:30+00:00

Boris Johnson suggests testing clubbers and theatregoers to reopen venues that have been closed since March.

## Sacked LGBT veterans can reclaim removed medals
 - [https://www.bbc.co.uk/news/uk-56079009](https://www.bbc.co.uk/news/uk-56079009)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 02:13:07+00:00

Former military personnel dismissed because of their sexuality may apply to restore honours.

## Free speech plan to tackle 'silencing' views on campus
 - [https://www.bbc.co.uk/news/education-55995979](https://www.bbc.co.uk/news/education-55995979)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 01:25:25+00:00

New post is among proposals aimed at strengthening academic freedom in England's universities.

## Could churches do more to fight climate change?
 - [https://www.bbc.co.uk/news/science-environment-56001191](https://www.bbc.co.uk/news/science-environment-56001191)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:34:28+00:00

Some young Christians in the UK say they want to see more action in their own churches.

## Yemen: The boy who saved his sister from a sniper
 - [https://www.bbc.co.uk/news/world-middle-east-56072279](https://www.bbc.co.uk/news/world-middle-east-56072279)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:25:51+00:00

Ten-year-old Amri risked his life to save his sibling, but in Yemen others are not so lucky.

## Full-face hot-wax TikTok videos prompt warnings
 - [https://www.bbc.co.uk/news/technology-56071436](https://www.bbc.co.uk/news/technology-56071436)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:20:17+00:00

Skin experts raise health-and-safety concerns about the videos, which do not carry a warning.

## Without music, will New Orleans survive?
 - [https://www.bbc.co.uk/news/world-us-canada-56048807](https://www.bbc.co.uk/news/world-us-canada-56048807)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:16:09+00:00

Known as the birthplace of Jazz, New Orleans has thousands of musicians that rely on gigs to survive.

## How Congo-Brazzaville's shark population came under threat
 - [https://www.bbc.co.uk/news/world-africa-56040716](https://www.bbc.co.uk/news/world-africa-56040716)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:12:37+00:00

The shark population off Congo-Brazzaville is threatened as desperate fishermen search deeper waters.

## Covid: Father and daughter to leave quarantine hotel after 'error'
 - [https://www.bbc.co.uk/news/uk-scotland-56078511](https://www.bbc.co.uk/news/uk-scotland-56078511)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:07:51+00:00

The father and young daughter are told they can isolate at home, instead of staying in a hotel for 10 days.

## The hypercar maker who was told to give up his dream
 - [https://www.bbc.co.uk/news/business-55938754](https://www.bbc.co.uk/news/business-55938754)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:04:39+00:00

Mate Rimac struggled to get anyone to believe that cutting edge sportscars could be made in Croatia.

## Covid: Ardrossan care worker caught virus twice and fears it could happen again
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-56049680](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-56049680)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:03:19+00:00

Care worker Michelle Lamont tested positive for coronavirus last April and then again in November.

## Fake Amazon reviews 'being sold in bulk' online
 - [https://www.bbc.co.uk/news/business-56069472](https://www.bbc.co.uk/news/business-56069472)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:02:47+00:00

A Which? investigation found 10 sites offering fake Amazon Marketplace reviews from as little as £5 each.

## Optimism as Cuba set to test its own Covid vaccine
 - [https://www.bbc.co.uk/news/world-latin-america-56069577](https://www.bbc.co.uk/news/world-latin-america-56069577)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:02:26+00:00

The first trials of the Cuban-produced Soberana 2 are "encouraging", Cuban scientists say.

## 450,000 families ‘behind on rent because of Covid’
 - [https://www.bbc.co.uk/news/business-56075518](https://www.bbc.co.uk/news/business-56075518)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:02:17+00:00

One in 20 private renters say they have been refused rent reductions, a report says.

## 'My mum was an alcoholic and it was a massive secret'
 - [https://www.bbc.co.uk/news/stories-56001534](https://www.bbc.co.uk/news/stories-56001534)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-16 00:01:34+00:00

Becky Ellis Hamilton's mum had an alcohol problem but no-one talked about it - and this had tragic consequences.

