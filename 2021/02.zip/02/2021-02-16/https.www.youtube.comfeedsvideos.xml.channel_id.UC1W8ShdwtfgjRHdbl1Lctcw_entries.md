# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## New York & Chicago (1930s-1940s) in color, Driving Downtown [60fps, Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=z_D8H0WzMHk](https://www.youtube.com/watch?v=z_D8H0WzMHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2021-02-17 00:00:00+00:00

I colorized, restored and created a sound design for this video of New York & Chicago (1930s-1940s), We can see what life was like in this era 

0:05-1:12 Michigan Avenue (Chicago 1930s)
1:12 The ride is north on Eighth Avenue from about 39th Street.(New York  1940s)

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

Thanks to A/V Geeks for share the amazing B&W Video Source

B&W Video Source from: A/V Geeks on archive.org
B&W Video Source: https://archive.org/details/ia35000021001

Rights to the black and white 35mm Video Source are held by Internet Archive. under the Creative Commons Attribution License

📨 Contact :nassthegoodman@gmail.com
- - - - - - - - - - - - - - - - - - - -
For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page! Please consider "fair use" before filing a claim. Thank You!

