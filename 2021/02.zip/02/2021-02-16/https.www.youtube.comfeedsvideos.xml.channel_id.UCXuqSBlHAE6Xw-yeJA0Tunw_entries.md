# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I REALLY Love Building Computers!!
 - [https://www.youtube.com/watch?v=XmD9tUWbAV8](https://www.youtube.com/watch?v=XmD9tUWbAV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-17 00:00:00+00:00

Check out the MSI Mag CORELIQUID 240R
At Amazon: https://geni.us/f7N4
At Newegg: https://geni.us/AZELA9v

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

Build List:

Buy AMD Threadripper 3960X CPU: https://geni.us/y5RpmV

Buy Noctua NH-U14S TR4-SP3 CPU Cooler: https://geni.us/AZsb

Buy ASUS ROG ZENITH II EXTREME ALPHA: https://geni.us/rQxCcd

Buy G.Skill Trident Z Neo 128 GB DDR4 RAM: https://geni.us/rWQ0d

Buy Intel Optane 905p NVMe SSD: https://geni.us/urfBwZ4

Buy NVIDIA RTX 2080 SUPER GPU: https://geni.us/nA2an

Buy Phanteks Eclipse P600S Case: https://geni.us/KMYw

Buy SeaSonic PRIME Ultra Titanium 1000w PSU: https://geni.us/XGtGiM

Buy ASUS ProArt PA32UCX Monitor: https://geni.us/sTZCepI

## The 15 Terabyte SSD is TINY!!
 - [https://www.youtube.com/watch?v=N3BUiUOpuPA](https://www.youtube.com/watch?v=N3BUiUOpuPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-16 00:00:00+00:00

Go to https://privacy.com/linus ​to get $5 off your first purchase!

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

15TB of raw storage on one SSD. How many games, songs, or other large files can we fit into a drive this big?


Buy Team Group QX 15.3TB SSD on Amazon: https://geni.us/dVjwKJ

Check out the NimbusData ExaDrive: https://lmg.gg/LayDS

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1306529-the-biggest-consumer-ssd-is-so-small/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

