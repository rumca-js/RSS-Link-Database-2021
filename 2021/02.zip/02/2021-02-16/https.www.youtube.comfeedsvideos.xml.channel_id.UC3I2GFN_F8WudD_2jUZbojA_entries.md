# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Adia Victoria - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=wuRmx_Ywvzk](https://www.youtube.com/watch?v=wuRmx_Ywvzk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-17 00:00:00+00:00

http://KEXP.ORG presents Adia Victoria sharing a live performance recorded exclusively for KEXP and talking to Cheryl Waters. Recorded February 10, 2021.

Songs:
Mortimer’s Blues
South Gotta Change
There, There (Radiohead cover)
Mexico Blues
Carolina Bound (new, unreleased song)

https://www.adiavictoria.com
http://kexp.org

## Amaarae - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=etkQuTWAE6w](https://www.youtube.com/watch?v=etkQuTWAE6w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-16 00:00:00+00:00

http://KEXP.ORG presents Amaarae performing live, recorded exclusively for KEXP, from Accra, Ghana.

Songs:
LEAVE ME ALONE
SAD, U BROKE MY HEART
JUMPING SHIP
You'll find a way (Santigold) / CRAZY WURLD
HELLZ ANGEL

Session recorded at Nanoff Gallery, Accra, Ghana
Director & DOP - Fotombo 
Guitarist - Joshua Moszi 

http://amaaraemusic.com
http://kexp.org

