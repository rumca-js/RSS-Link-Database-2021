# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Vivo X60 Pro+ ma całkiem niezły aparat!
 - [https://www.youtube.com/watch?v=2PmVpQqtFOc](https://www.youtube.com/watch?v=2PmVpQqtFOc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-02-16 00:00:00+00:00

Ten smartfon naprawdę mi się spodobał. Nie jest jednak wolny od wad, a największa z nich to fakt, że w tej formie raczej nie pojawi się na polskim rynku. Można go kupić na przykład tu: https://bit.ly/3jMNFO6 (Trading Shenzhen), ale domyślam się, że nie każdy ma na takie eksperymenty ochotę. Porównałem Vivo w kilku aspektach do Xiaomi Mi11, wrzucam link do tego samego sklepu, gdyż w PL jeszcze niedostępny: https://bit.ly/39PvHpL

W odcinku:
00:00 Pudełka smartfonów
00:30 Zawartość pudełka Vivo X60 Pro+
00:51 Szybka recenzja słuchawek
00:59 Skórzane plecki a ładowanie
01:49 Wodoodporność i wejścia na karty SIM i microSD
01:54 Głośnik
02:04 Czy ten smartfon jest ładny?
02:39 Obiektyw z gimbalową stabilizacją
03:16 Stabilizacja: Xiaomi Mi11 vs Vivo X60 Pro+
04:13 Zdjęcia: Xiaomi Mi11 vs Vivo X60 Pro+
05:10 Przednia kamera i mikrofony: Xiaomi Mi11 vs Vivo X60 Pro+
05:38 Double Exposure
05:57 Posumowanie porównania Xiaomi Mi11 i Vivo X60 Pro+
06:18 Nakładka Androida
06:33 Czy Vivo X60 Pro+ będzie dostępny w Europie?
07:40 Snapdargon 888, RAM i system
07:52 Podsumowanie i opinia
08:23 Pożegnanie

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

