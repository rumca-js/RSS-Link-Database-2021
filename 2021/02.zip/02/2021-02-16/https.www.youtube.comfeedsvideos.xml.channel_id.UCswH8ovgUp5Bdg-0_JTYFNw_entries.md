# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## QAnon: How Did It Hit Home? And WHAT NEXT?!
 - [https://www.youtube.com/watch?v=ic2C30ElCSY](https://www.youtube.com/watch?v=ic2C30ElCSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-02-17 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Followers of QAnon have been divided since the inauguration confounded their predictions that Donald Trump would remain in power. What does the future hold for QAnon and what does its popularity signify? 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Listen to my Under The Skin podcast here: 
https://luminarypodcasts.com

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

## Building A Better Society: Have we run out of new ideas? | Adam Curtis & Russell Brand
 - [https://www.youtube.com/watch?v=aN7UCUDzXGA](https://www.youtube.com/watch?v=aN7UCUDzXGA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-02-16 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

This from Part #1 of Under The Skin with the genius documentary filmmaker #AdamCurtis. You can listen to the full episode over on Luminary: https://luminary.link/russell

Adam's latest documentary, Can't Get You Out Of My Head: An Emotional History of the Modern World, is a 6-part series that you can now watch on the BBC.  

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

