# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Brooke Baldwin's emotional announcement that she's leaving CNN
 - [https://www.cnn.com/videos/media/2021/02/16/brooke-baldwin-leaving-cnn-vpx.cnn](https://www.cnn.com/videos/media/2021/02/16/brooke-baldwin-leaving-cnn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 20:15:29+00:00

CNN's Brooke Baldwin says she is leaving CNN after 13 years in mid-April.

## Historian corrects Nikki Haley's tweet
 - [https://www.cnn.com/videos/politics/2021/02/16/nikki-haley-tweet-george-washington-historian-keilar-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/02/16/nikki-haley-tweet-george-washington-historian-keilar-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 20:11:31+00:00

Presidential historian Alexis Coe breaks down the falsehoods in tweet by former Gov. Nikki Haley (R-SC) about George Washington.

## CNN's Keilar calls out Fox News for misrepresenting Trump parade
 - [https://www.cnn.com/videos/media/2021/02/16/fox-news-trump-parade-brianna-keilar-nr-sot-vpx.cnn](https://www.cnn.com/videos/media/2021/02/16/fox-news-trump-parade-brianna-keilar-nr-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 19:48:50+00:00

CNN's Brianna Keilar calls out Fox News host Sean Hannity for saying that a President's Day Parade in Florida for former President Donald Trump was spontaneous, despite evidence it was planned.

## Serena Williams overcomes Simona Halep to set up blockbuster Australian Open semifinal with Naomi Osaka
 - [https://www.cnn.com/collections/intl-austrailan-open-0216/](https://www.cnn.com/collections/intl-austrailan-open-0216/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 19:17:16+00:00



## Meghan Markle and Prince Harry to appear in Oprah Winfrey primetime special
 - [https://www.cnn.com/2021/02/16/entertainment/oprah-winfrey-meghan-markle-prince-harry-interview/index.html](https://www.cnn.com/2021/02/16/entertainment/oprah-winfrey-meghan-markle-prince-harry-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 19:12:57+00:00

Oprah Winfrey has landed the first major interview with Meghan Markle and Prince Harry since the duo announced they were expecting their second child.

## Citibank can't get back $500 million it wired by mistake, judge rules
 - [https://www.cnn.com/2021/02/16/business/citibank-revlon-lawsuit-ruling/index.html](https://www.cnn.com/2021/02/16/business/citibank-revlon-lawsuit-ruling/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 18:58:30+00:00

After committing one of the "biggest blunders in banking history," a US District Court judge ruled that Citibank cannot recover the almost half a billion dollars it accidentally wired to Revlon's lenders.

## The US just saw its lowest Covid-19 daily case count since October. But here's why experts are still worried
 - [https://www.cnn.com/2021/02/16/health/us-coronavirus-tuesday/index.html](https://www.cnn.com/2021/02/16/health/us-coronavirus-tuesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 18:53:35+00:00

The US on Monday reported more than 53,800 new Covid-19 infections: its lowest daily case count since October and a vastly different number from those plaguing the country just last month, when infections were topping 200,000 a day.

## Federal judge blocks last-minute Trump rule limiting asylum claims
 - [https://www.cnn.com/2021/02/16/politics/immigration-asylum-trump-rule/index.html](https://www.cnn.com/2021/02/16/politics/immigration-asylum-trump-rule/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 18:38:14+00:00

A federal judge in California blocked a Trump-era rule that went into effect just a day before Joe Biden took office and sought to dramatically limit the ability of Central American migrants to claim asylum in the United States

## Revelers attempt rooftop escape after illegal nightclub is shut down
 - [https://www.cnn.com/2021/02/16/uk/illegal-nightclub-crack-down-scli-intl-gbr/index.html](https://www.cnn.com/2021/02/16/uk/illegal-nightclub-crack-down-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 18:34:51+00:00

Police in England have raided a "packed nightclub" where about 150 revelers were partying, with footage of the moment dozens fled via the roof released.

## Dubai princess claims she is being held 'hostage' in secret video recordings
 - [https://www.cnn.com/2021/02/16/middleeast/dubai-princess-latifa-hostage-claim-intl/index.html](https://www.cnn.com/2021/02/16/middleeast/dubai-princess-latifa-hostage-claim-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 18:30:48+00:00

The daughter of Dubai's billionaire ruler, who attempted to flee abroad in 2018, has appeared in secret recordings claiming she is being held hostage in a "villa converted into a jail" with no access to medical help, according to a BBC documentary.

## Leading House Democrat sues Trump for conspiracy to incite US Capitol riot
 - [https://www.cnn.com/2021/02/16/politics/capitol-lawsuit-trump-giuliani-proud-boys-oath-keepers/index.html](https://www.cnn.com/2021/02/16/politics/capitol-lawsuit-trump-giuliani-proud-boys-oath-keepers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 17:56:28+00:00

• Republican senator: January 6 wasn't an 'armed insurrection'
• NYT: House Republican shunned by family members over Trump criticism
• Cillizza: Trump has a lot of money problems

## City hit hard by Covid-19 sees drastic drop in cases
 - [https://www.cnn.com/collections/intl-coronavirus-02162021/](https://www.cnn.com/collections/intl-coronavirus-02162021/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 17:23:46+00:00



## Charge against Amy Cooper dropped after completing racial bias education program
 - [https://www.cnn.com/2021/02/16/us/amy-cooper-birdwatching-charge/index.html](https://www.cnn.com/2021/02/16/us/amy-cooper-birdwatching-charge/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 17:21:11+00:00

The Manhattan District Attorney's Office on Monday dropped the misdemeanor criminal charge against Amy Cooper, the White woman who called police on a Black man in Central Park last May, after she completed education and therapy classes on racial equity.

## Fauci wins $1 million prize for his work on infectious diseases
 - [https://www.cnn.com/2021/02/16/us/fauci-wins-dan-david-prize-trnd/index.html](https://www.cnn.com/2021/02/16/us/fauci-wins-dan-david-prize-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 17:20:28+00:00

Dr. Anthony Fauci has been honored with a top international prize for his work combating the coronavirus and other infectious diseases.

## Forget fingerprints -- AI may soon use your veins to identify you
 - [https://www.cnn.com/2021/02/16/world/vein-hands-identify-intl-scli-scn/index.html](https://www.cnn.com/2021/02/16/world/vein-hands-identify-intl-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 17:17:18+00:00

Forget facial recognition technology -- researchers say they can identify you from the veins on the backs of your hands.

## Why the Republican Party is poised to tear itself apart
 - [https://www.cnn.com/2021/02/16/politics/gop-republican-party-quinnipiac-poll/index.html](https://www.cnn.com/2021/02/16/politics/gop-republican-party-quinnipiac-poll/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 17:11:45+00:00

In the last 48 hours, two things have happened that suggest the Republican Party is likely headed to an all-out civil war:

## China's box office is having a better Lunar New Year than before Covid
 - [https://www.cnn.com/2021/02/16/media/china-box-office-lunar-new-year-intl-hnk/index.html](https://www.cnn.com/2021/02/16/media/china-box-office-lunar-new-year-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 17:07:59+00:00

Chinese cinemas are back in business and selling even more tickets than before the pandemic.

## At least 60 killed after passenger barge crashes on Congo river
 - [https://www.cnn.com/2021/02/16/africa/60-killed-congo-river-intl/index.html](https://www.cnn.com/2021/02/16/africa/60-killed-congo-river-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 16:59:57+00:00

At least 60 people died when a passenger barge carrying more than 700 people became shipwrecked on the Congo river at night, Democratic Republic of Congo's humanitarian affairs minister said on Monday.

## Adidas is selling Reebok to focus on its own brand
 - [https://www.cnn.com/2021/02/16/business/adidas-selling-reebok/index.html](https://www.cnn.com/2021/02/16/business/adidas-selling-reebok/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 16:26:15+00:00

Adidas says it will offload struggling US fitness brand Reebok as part of a strategic overhaul.

## Georgia state bar proceeds with inquiry into pro-Trump attorney
 - [https://www.cnn.com/2021/02/16/politics/lin-wood-georgia-state-bar-inquiry/index.html](https://www.cnn.com/2021/02/16/politics/lin-wood-georgia-state-bar-inquiry/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 16:25:58+00:00

The State Bar of Georgia is "proceeding with an inquiry" into attorney Lin Wood, one of the lawyers who unsuccessfully pushed a handful of suits to block Georgia's election results after alleging unfounded claims of fraud, the organization told CNN in a statement Tuesday.

## Aung San Suu Kyi hit with new charge as military junta pledges new election
 - [https://www.cnn.com/2021/02/16/asia/myanmar-aung-san-suu-kyi-coup-charges-intl/index.html](https://www.cnn.com/2021/02/16/asia/myanmar-aung-san-suu-kyi-coup-charges-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 16:15:38+00:00

Police in Myanmar have filed a new charge against deposed leader Aung San Suu Kyi, her lawyer said Tuesday, as the military leaders who took control of the country in a coup attempted to defend their actions.

## Leading House Democrat sues Trump under a post-Civil War law for conspiracy to incite US Capitol riot
 - [https://www.cnn.com/collections/intl-capitol-hill-violence-02162021/](https://www.cnn.com/collections/intl-capitol-hill-violence-02162021/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 16:05:16+00:00



## Congress is about to bring back its secret weapon
 - [https://www.cnn.com/2021/02/16/politics/congress-earmarks-house-senate/index.html](https://www.cnn.com/2021/02/16/politics/congress-earmarks-house-senate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:58:23+00:00

Earmarks are back.

## Maxence Muzaton recalls miracle save from crash at skiing world championships
 - [https://www.cnn.com/2021/02/16/sport/maxence-muzaton-ski-crash-spt-intl/index.html](https://www.cnn.com/2021/02/16/sport/maxence-muzaton-ski-crash-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:52:32+00:00

It might be one of the luckiest escapes in skiing, but it's not the moment Maxence Muzaton wants to be remembered for.

## Anger is falling on China amidst growing tensions in Myanmar
 - [https://www.cnn.com/videos/world/2021/02/16/china-myanmar-relations-coup-robertson-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/02/16/china-myanmar-relations-coup-robertson-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:52:12+00:00

CNN's Nic Robertson decodes the relationship between China and Myanmar as the Southeast Asian country is gripped by continuing protests following a military takeover in February 2021.

## New York Times: House Republican shunned by family members over Trump criticism
 - [https://www.cnn.com/2021/02/15/politics/kinzinger-impeachment-family-letter/index.html](https://www.cnn.com/2021/02/15/politics/kinzinger-impeachment-family-letter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:51:10+00:00

Eleven members of Republican Rep. Adam Kinzinger's family sent him a vitriolic letter accusing him of being a member of the "devil's army" in light of his criticism of then-President Donald Trump after the January 6 insurrection, The New York Times reported Monday.

## 'Bridgerton' casts Simone Ashley as Lord Anthony's love interest
 - [https://www.cnn.com/2021/02/16/entertainment/bridgerton-simone-ashley-season-2-trnd/index.html](https://www.cnn.com/2021/02/16/entertainment/bridgerton-simone-ashley-season-2-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:43:08+00:00

Lord Anthony Bridgerton officially has his love interest for Season 2 of the hit Netflix series "Bridgerton."

## NC Republicans censures Sen. Burr over vote to convict Trump
 - [https://www.cnn.com/videos/politics/2021/02/16/north-carolina-gop-censures-sen-burr-for-trump-conviction-vote-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/02/16/north-carolina-gop-censures-sen-burr-for-trump-conviction-vote-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:40:31+00:00

North Carolina GOP Chairman Michael Watley joins CNN's John Berman to discuss their vote to censure Sen. Richard Burr over his vote to convict former President Donald Trump.

## Bitcoin soars past $50,000 for the first time
 - [https://www.cnn.com/2021/02/16/investing/bitcoin-50000-price-record/index.html](https://www.cnn.com/2021/02/16/investing/bitcoin-50000-price-record/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:39:12+00:00

Bitcoin topped $50,000 Tuesday, continuing a stunning rise that has sent it soaring about $20,000 this year.

## Marriott CEO Arne Sorenson has died after pancreatic cancer fight
 - [https://www.cnn.com/2021/02/16/business/marriott-ceo-arne-sorenson-death/index.html](https://www.cnn.com/2021/02/16/business/marriott-ceo-arne-sorenson-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:37:49+00:00

Marriott International's president and CEO Arne Sorenson died Monday following a nearly two-year battle with pancreatic cancer, the hotel chain announced Tuesday.

## Ex-President Trump has a *lot* of money problems
 - [https://www.cnn.com/videos/politics/2021/02/16/trumps-money-problems-cillizza-the-point.cnn](https://www.cnn.com/videos/politics/2021/02/16/trumps-money-problems-cillizza-the-point.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:08:40+00:00

Donald Trump officially left the White House on January 20. Immediately, he came face-to-face with a whole bunch of financial issues and crumbling business ventures. In this latest episode of The Point, CNN's Chris Cillizza ticks through the trouble the former president now faces.

## Border delays could force Germany's car plants to close
 - [https://www.cnn.com/2021/02/16/business/germany-border-checks-manufacturing/index.html](https://www.cnn.com/2021/02/16/business/germany-border-checks-manufacturing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 14:02:30+00:00

The carmakers at the heart of Germany's huge manufacturing industry are facing a new threat: border checks that could delay crucial parts deliveries and force their factories to close.

## Goldman Sachs' investment advice is no longer just for the super rich
 - [https://www.cnn.com/2021/02/16/investing/goldman-sachs-marcus-invest/index.html](https://www.cnn.com/2021/02/16/investing/goldman-sachs-marcus-invest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 13:47:59+00:00

Move over, Robinhood, here comes Goldman Sachs.

## Analysis: This could be Biden's biggest task as a leader yet
 - [https://www.cnn.com/2021/02/16/politics/joe-biden-coronavirus-vaccine-schools/index.html](https://www.cnn.com/2021/02/16/politics/joe-biden-coronavirus-vaccine-schools/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 13:38:07+00:00

An exhausted and impatient nation needs the kind of clarity and leadership only a president can provide as the coronavirus pandemic reaches a potentially decisive stage.

## Common genetic test often wrong when identifying rare disease-causing variants such as BRCA1 and BRCA2, study says
 - [https://www.cnn.com/2021/02/16/health/genetic-tests-wrong-brca1-brca2-wellness-trnd/index.html](https://www.cnn.com/2021/02/16/health/genetic-tests-wrong-brca1-brca2-wellness-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 13:06:25+00:00

A genetic test used to detect common traits many people share is not reliable in identifying rare disease-causing variations, such as those that can predict breast and ovarian cancer, a new study has found.

## Nestlé's newest KitKat is missing a key ingredient
 - [https://www.cnn.com/2021/02/16/business/vegan-kitkat-launch-trnd/index.html](https://www.cnn.com/2021/02/16/business/vegan-kitkat-launch-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 12:58:22+00:00

Breaking off a piece of that vegan KitKat bar is now a reality.

## British veterans, discharged for being gay under historic law, allowed to get their medals back
 - [https://www.cnn.com/2021/02/16/uk/discharged-gay-veterans-medals-scli-gbr-intl/index.html](https://www.cnn.com/2021/02/16/uk/discharged-gay-veterans-medals-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 12:40:31+00:00

Gay and bisexual British veterans who were stripped of their medals because of their sexuality will now be able to reclaim them, the UK government has said, as it admitted the pre-2000 policy was an "historical wrong."

## This 'critical' component for Covid-19 vaccines is in short supply
 - [https://www.cnn.com/videos/business/2021/02/16/coronavirus-vaccine-production-challenges-stewart-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/business/2021/02/16/coronavirus-vaccine-production-challenges-stewart-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 12:23:34+00:00

Vaccinating the world against Covid-19 could take years. Even with several successful vaccines on the market and many more in the pipeline, there simply aren't enough facilities around the world to make them. CNN's Anna Stewart takes a look at what's being done to boost vaccine production.

## The destinations open to travelers vaccinated against Covid-19
 - [https://www.cnn.com/travel/article/countries-open-to-vaccinated-travelers/index.html](https://www.cnn.com/travel/article/countries-open-to-vaccinated-travelers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 12:01:42+00:00

As the Covid-19 pandemic continues to wreak havoc on the travel industry, countless destinations around the world are rolling out vaccines to their most vulnerable citizens.

## Video shows rocket attack on US and coalition forces in Iraq
 - [https://www.cnn.com/videos/politics/2021/02/16/erbil-iraq-rocket-attacks-us-coalition-forces-ldn-vpx.cnn](https://www.cnn.com/videos/politics/2021/02/16/erbil-iraq-rocket-attacks-us-coalition-forces-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 10:59:15+00:00

A civilian contractor was killed and a US service member was injured along with five other contractors when rocket fire landed on coalition forces near Erbil International Airport in Iraq, according to Col. Wayne Marotto, the spokesman for Operation Inherent Resolve. CNN's Oren Liebermann reports.

## Australian Prime Minister apologizes to former staffer allegedly raped in Parliament office
 - [https://www.cnn.com/2021/02/16/australia/australia-canberra-rape-allegations-intl-hnk/index.html](https://www.cnn.com/2021/02/16/australia/australia-canberra-rape-allegations-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 10:21:41+00:00

Australian Prime Minister Scott Morrison apologized Tuesday to a former government staffer who alleged that she was raped by a colleague in Parliament House two years ago.

## Olympic swimming medalist charged with running alleged Australia drugs syndicate
 - [https://www.cnn.com/2021/02/16/sport/scott-miller-meth-arrest-intl-hnk-scli/index.html](https://www.cnn.com/2021/02/16/sport/scott-miller-meth-arrest-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 09:57:17+00:00

Former Australian swimming star Scott Miller was arrested on drugs charges in a dawn raid at his home Tuesday, with Sydney police alleging the Olympic medalist heads a gang supplying methamphetamine across New South Wales state, CNN affiliate Nine News reported.

## White violence and Black protests during the 1918 flu have a lesson for today
 - [https://www.cnn.com/2021/02/16/health/1918-flu-lessons-philadelphia-race-riots-wellness/index.html](https://www.cnn.com/2021/02/16/health/1918-flu-lessons-philadelphia-race-riots-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 08:19:30+00:00

Adella Bond fired her revolver outside her window into the South Philadelphia air, hoping to attract police as a mob of Irish American people gathered around her home to tell her she wasn't welcome.

## Explore Jezero Crater, the future home of NASA's Perseverance rover
 - [https://www.cnn.com/2021/02/16/world/mars-jezero-crater-rover-landing-site-scn/index.html](https://www.cnn.com/2021/02/16/world/mars-jezero-crater-rover-landing-site-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 08:19:02+00:00

The Perseverance rover is the fifth robotic explorer sent by NASA to journey across the Martian surface, but it's going to land in a spot that has never been attempted by the agency: Jezero Crater.

## 'I was shocked': Former 'Bachelorette' reacts to Chris Harrison's comments
 - [https://www.cnn.com/videos/entertainment/2021/02/16/rachel-lindsay-chris-harrison-bachelor-racism-sot-ctn-vpx.cnn](https://www.cnn.com/videos/entertainment/2021/02/16/rachel-lindsay-chris-harrison-bachelor-racism-sot-ctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 07:41:14+00:00

Former "Bachelorette" star and "Extra" correspondent Rachel Lindsay speaks out on her interview with "Bachelor" host Chris Harrison, in which he defended current contestant Rachael Kirkconnell after she came under scrutiny for photos that have surfaced of her at an antebellum plantation-themed fraternity formal in 2018.

## What history's bathing rituals reveal about status, purity and power
 - [https://www.cnn.com/style/article/cultural-history-of-bathing-rituals/index.html](https://www.cnn.com/style/article/cultural-history-of-bathing-rituals/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 07:33:58+00:00

In many parts of the world, cleansing one's body has become an individual, daily ritual -- a quick, steamy shower in the morning or a longer bath to unwind at night. But historically, our bathing habits have been imbued with deeper meanings.

## Ambulance crews wonder why there have been very few coronavirus emergency calls in the past few days
 - [https://www.cnn.com/2021/02/16/world/cardiff-ambulance-covid-19-gbr-intl/index.html](https://www.cnn.com/2021/02/16/world/cardiff-ambulance-covid-19-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 07:19:26+00:00



## Stop everything and watch this polar bear play in the snow
 - [https://www.cnn.com/videos/travel/2021/02/16/snow-play-zoo-animals-winter-storm-eg-orig.cnn](https://www.cnn.com/videos/travel/2021/02/16/snow-play-zoo-animals-winter-storm-eg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 05:18:49+00:00

The Point Defiance Zoo & Aquarium and the Oregon Zoo released videos showing some of the animals having a blast after snow fell across the Northwest.

## Navarro on Republican party: What party penalizes officials who vote their conscience?
 - [https://www.cnn.com/videos/politics/2021/02/16/mcconnell-trump-impeachment-vote-republican-party-stewart-navarro-ctn-vpx.cnn](https://www.cnn.com/videos/politics/2021/02/16/mcconnell-trump-impeachment-vote-republican-party-stewart-navarro-ctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 05:00:03+00:00

CNN's Alice Stewart and Ana Navarro discuss Senate Minority Leader Mitch McConnell's rebuke of former President Donald Trump's actions on January 6th, despite his vote to acquit the former President of the charge.

## The syrupy treat that helped China's Manchu Army conquer the Ming Dynasty
 - [https://www.cnn.com/travel/article/singapore-sachima-hawker-stall-pan-ki/index.html](https://www.cnn.com/travel/article/singapore-sachima-hawker-stall-pan-ki/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 02:19:15+00:00

Poon Sun Hay awakes in the early morning, ready to return to Singapore's Chinatown Complex Hawker Centre and finish up the work he started the night before.

## Watch a billion years of tectonic plates moving in one minute
 - [https://www.cnn.com/videos/world/2021/02/16/earth-history-tectonic-plates-movement-eg-orig.cnn](https://www.cnn.com/videos/world/2021/02/16/earth-history-tectonic-plates-movement-eg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-16 01:51:58+00:00

Scientists researching the interactions between tectonic plates built an animated model of what the Earth may have looked like one billion years ago.

