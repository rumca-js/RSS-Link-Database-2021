# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Why AOC Exaggerated Her Trauma From the Capitol Riot?
 - [https://www.youtube.com/watch?v=v9-5QPqDAfI](https://www.youtube.com/watch?v=v9-5QPqDAfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-02-16 00:00:00+00:00

Grab your Sleep Remedy Here - https://docparsley.com/jp

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

In this video you’ll learn why AOC exaggerated her trauma from the capital riot. There’s a perfectly good explanation... Even though she wasn’t in the capital building while the riots were happening, she still deserves to be the most traumatized from it all.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

