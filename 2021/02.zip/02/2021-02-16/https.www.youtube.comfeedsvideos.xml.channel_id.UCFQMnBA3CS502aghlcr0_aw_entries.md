# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Grant Cardone & Daymond John Want Your Last $1,000 💵💵💵
 - [https://www.youtube.com/watch?v=zO6kQbYZJjk](https://www.youtube.com/watch?v=zO6kQbYZJjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-16 00:00:00+00:00

Shark Tank Daymond John and Grant Cardone explain why you should spend your last $1,000 with them. 
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

