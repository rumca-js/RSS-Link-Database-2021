# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## MAGIC IS OUTDATED!
 - [https://www.youtube.com/watch?v=h7FvlsLktdM](https://www.youtube.com/watch?v=h7FvlsLktdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-02-17 00:00:00+00:00

Magic outdone by the pew pews. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Daniel Radcliffe & Elijah Wood Empire📰 Breach of Peace Cover Reveal🎉 Fractalverse🚀-FANTASY NEWS
 - [https://www.youtube.com/watch?v=yR0qCaBoSBI](https://www.youtube.com/watch?v=yR0qCaBoSBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-02-16 00:00:00+00:00

LET'S TALK THE FANTASY NEWS…. And Breach of Peace 
Checkout campfire here: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20


Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

NEWS:

00:00 Intro

00:25 Fairytales from Verania: https://twitter.com/tjklune/status/1360962602248060935?s=20 

00:54 The Righteous: https://twitter.com/HarperVoyagerUK/status/1360212560474222593?s=19 

01:24 Naomi Novik Last Graduate: https://discord.com/channels/480406622028431373/500315229666934795 

02:11 Fractalverse: https://fractalverse.net/ 

02:42 WandaVision and AoT Numbers success: https://www.forbes.com/sites/carlymayberry/2021/02/11/disneys-wandavision-cast-into-top-viewing-spot-worldwide/?__twitter_impression=true&sh=56cf42096133
https://www.parrotanalytics.com/insights/tv-series-demand-across-all-television-platforms-for-the-us-31-january-6-february-2021/  

04:00 Empire LotR HP edition: https://www.empireonline.com/movies/news/empire-elijah-wood-daniel-radcliffe-harry-potter-lord-rings-anniversary-issue/ 

05:54 BREACH OF PEACE Cover: https://imgur.com/a/SVj6BzQ

