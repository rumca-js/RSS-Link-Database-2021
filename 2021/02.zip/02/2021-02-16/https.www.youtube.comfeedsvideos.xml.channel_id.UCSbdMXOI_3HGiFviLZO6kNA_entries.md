# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Oculus Quest 2 HUGE Update Revealed During AMA
 - [https://www.youtube.com/watch?v=4W-11m5M_MI](https://www.youtube.com/watch?v=4W-11m5M_MI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-02-16 00:00:00+00:00

Hello welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news.  Today we'll be covering a chilling Wired article on the topic of a dystopian VR future as well as break down the recent AMA from Facebook Reality Lab's Vice President. That and so much more, I hope you enjoy!

My links-
Here are my links
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill



Sources-
https://www.roadtovr.com/oculus-quest-2-update-facebook-messenger/
https://vrscout.com/news/ar-prescription-glasses-arriving-later-this-year/
https://vrscout.com/news/population-one-season-one-battle-royale/#
https://uploadvr.com/vr-cover-oculus-quest-2-carrying-case/
https://uploadvr.com/facebook-bcis-bosworth/
https://uploadvr.com/facebook-store-virtual-desktop/
https://www.wired.com/story/billionaires-use-vr-avoid-social-change/
https://www.roadtovr.com/facebook-hints-oculus-quest-2-120hz-refresh-rate/
https://www.roadtovr.com/striker-vr-4-million-investment-haptic-vr-gun-consumer/

Outro-
Protostar- Overdrive

