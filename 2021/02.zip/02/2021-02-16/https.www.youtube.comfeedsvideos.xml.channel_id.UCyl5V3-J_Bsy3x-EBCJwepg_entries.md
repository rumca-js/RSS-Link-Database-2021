# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Dr. Fauci Spins His Handy Wheel Of Science!
 - [https://www.youtube.com/watch?v=tDHj3sNsSwU](https://www.youtube.com/watch?v=tDHj3sNsSwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-16 00:00:00+00:00

Using his Wheel of Science, Dr. Fauci's latest press conference reveals the latest virus safety measures according to the science... WHEEL!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Finding Purpose Without Wokeness: Spencer Klavan Interview
 - [https://www.youtube.com/watch?v=eRQZLwT5Y_o](https://www.youtube.com/watch?v=eRQZLwT5Y_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-16 00:00:00+00:00

In this episode of The Babylon Bee Podcast, Kyle and Ethan talk to Spencer Klavan. They talk about the current woke culture, essence of talent, and shadowboxing with Freud. Spencer Klavan is an Associate Editor  ClaremontInstitute and Host of Young Heretics Podcast. Spencer received his Doctorate in Greek and Roman literature, eventually writing the book Music in Ancient Greece: Melody, Rhythm, and Life based on his research. 

Be sure to check out The Babylon Bee YouTube Channel for more podcasts, podcast shorts, animation, and more.

To watch or listen to the full podcast, become a subscriber at https://babylonbee.com/plans

## Nation Prepares To Celebrate 1st Anniversary Of Two Weeks To Flatten The Curve
 - [https://www.youtube.com/watch?v=UB88bLKnBok](https://www.youtube.com/watch?v=UB88bLKnBok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-16 00:00:00+00:00

The nation is preparing to celebrate what is expected to become a beloved annual holiday: the anniversary of "two weeks to flatten the curve," to be held in March every year. Happy Two Weeks to Slow the Spread Day!

