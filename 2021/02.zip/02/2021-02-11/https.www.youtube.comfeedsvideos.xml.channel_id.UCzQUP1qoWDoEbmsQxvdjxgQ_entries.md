# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Cody Garbrandt Looks Back on TJ Dillashaw Fights
 - [https://www.youtube.com/watch?v=P6BchqCbHdM](https://www.youtube.com/watch?v=P6BchqCbHdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-12 00:00:00+00:00

This clip is taken from the JRE MMA Show #100 with Cody Garbrandt. https://open.spotify.com/episode/7mOQXQUA6PRyXhB4VsDSy8?si=JvRooapRR5OKJqTsASuFfg

## Cody Garbrandt's COVID Battle
 - [https://www.youtube.com/watch?v=su5iiYGLZLM](https://www.youtube.com/watch?v=su5iiYGLZLM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-12 00:00:00+00:00

This clip is taken from the JRE MMA Show #100 with Cody Garbrandt. https://open.spotify.com/episode/7mOQXQUA6PRyXhB4VsDSy8?si=JvRooapRR5OKJqTsASuFfg

## Cody Garbrandt's Comeback
 - [https://www.youtube.com/watch?v=G5UwqmZ_LYI](https://www.youtube.com/watch?v=G5UwqmZ_LYI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-12 00:00:00+00:00

This clip is taken from the JRE MMA Show #100 with Cody Garbrandt. https://open.spotify.com/episode/7mOQXQUA6PRyXhB4VsDSy8?si=JvRooapRR5OKJqTsASuFfg

## Does Joe Rogan Think the DMT Elves Are Real?
 - [https://www.youtube.com/watch?v=6DQSIzJ9J-g](https://www.youtube.com/watch?v=6DQSIzJ9J-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1608 with Michael Malice. https://open.spotify.com/episode/3EukYb1XzWD2G19WS5gAHe?si=PIpjnrWVQbWQSlmy0ZIk9A

## Elon Musk Says SpaceX Will Be Making Regular Flights by 2023
 - [https://www.youtube.com/watch?v=gZ_tFEuhaJo](https://www.youtube.com/watch?v=gZ_tFEuhaJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1609 with Elon Musk. https://open.spotify.com/episode/2aB2swgyXqbFA06AxPlFmr?si=_8doDtUvSn-kkUNFE9Kp7w

## Elon Musk Talks About Colonizing the Galaxy
 - [https://www.youtube.com/watch?v=cDQa40B9Lxo](https://www.youtube.com/watch?v=cDQa40B9Lxo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1609 with Elon Musk. https://open.spotify.com/episode/2aB2swgyXqbFA06AxPlFmr?si=_8doDtUvSn-kkUNFE9Kp7w

## Elon Musk on "Shocking" Moment He Broke Window on Cybertruck
 - [https://www.youtube.com/watch?v=RCD-vXumMIs](https://www.youtube.com/watch?v=RCD-vXumMIs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1609 with Elon Musk. https://open.spotify.com/episode/2aB2swgyXqbFA06AxPlFmr?si=_8doDtUvSn-kkUNFE9Kp7w

## Michael Malice is Worried About the Response to the Virus
 - [https://www.youtube.com/watch?v=yYsEgwD-5Og](https://www.youtube.com/watch?v=yYsEgwD-5Og)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1608 with Michael Malice. https://open.spotify.com/episode/3EukYb1XzWD2G19WS5gAHe?si=PIpjnrWVQbWQSlmy0ZIk9A

## The Atrocities That Nobody Knows About
 - [https://www.youtube.com/watch?v=t9xrmJ3UX9w](https://www.youtube.com/watch?v=t9xrmJ3UX9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-02-11 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1608 with Michael Malice. https://open.spotify.com/episode/3EukYb1XzWD2G19WS5gAHe?si=PIpjnrWVQbWQSlmy0ZIk9A

