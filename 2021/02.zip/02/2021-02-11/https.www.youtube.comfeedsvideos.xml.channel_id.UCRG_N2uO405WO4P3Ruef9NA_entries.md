# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Let's chat about Nothing
 - [https://www.youtube.com/watch?v=SKjtFbC8wfM](https://www.youtube.com/watch?v=SKjtFbC8wfM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-02-12 00:00:00+00:00

Sponsored by Skillshare. The first 1000 to sign up with this link can try Skillshare Premium for free: https://skl.sh/thefridaycheckout02211

This week, cryptocurrencies, and especially Bitcoin had a huge week, Nothing, the company founder by OnePlus co-founder Carl Pei, announced they will launch wireless headphone as well as an ecosystem of smart consumer devices soon, and Facebook plus Twitter are launching their Clubhouse clones. 

The Friday Checkout - Episode 35

On Nebula: https://watchnebula.com/videos/the-friday-checkout-more-news-about-nothing

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄

Our Weekly Tech Knowledge Quiz is available:

In the Crrowd app: https://play.google.com/store/apps/details?id=com.crrowd
On the web: https://crrowd.com/quiz

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:36 Crypto boom
3:02 The Nothing strategy
5:27 Clubhouse craze

