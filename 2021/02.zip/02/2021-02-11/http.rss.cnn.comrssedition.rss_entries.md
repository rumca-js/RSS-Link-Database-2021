# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Hear what Republican senators told Tapper after Graham's claim
 - [https://www.cnn.com/videos/politics/2021/02/11/lindsey-graham-impeachment-trial-jake-tapper-vpx.cnn](https://www.cnn.com/videos/politics/2021/02/11/lindsey-graham-impeachment-trial-jake-tapper-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 19:34:16+00:00

Sen. Lindsey Graham (R-SC) claimed there were less votes to convict former President Trump at his second impeachment trial after hearing House managers' arguments and presentations of surveillance videos.

## CNN reporter reflects on the Arab Spring 10 years later
 - [https://www.cnn.com/videos/world/2021/02/11/arab-spring-10-year-anniversary-wedeman-dnt-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/02/11/arab-spring-10-year-anniversary-wedeman-dnt-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 18:40:30+00:00

Ten years ago, mass protests demanding freedom and dignity rocked the Arab World and for a while, hope soared that decades of decay and dictatorship were coming to an end. But internal divisions, foreign intervention, war and authoritarians who stopped at nothing to seize or cling to power dashed much of that hope. CNN's Ben Wedeman covered most of the uprisings and reflects on the meaning of these events.

## Trump's defense team expected to finish its arguments in one day
 - [https://www.cnn.com/2021/02/11/politics/donald-trump-impeachment-defense-team-arguments/index.html](https://www.cnn.com/2021/02/11/politics/donald-trump-impeachment-defense-team-arguments/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 17:02:54+00:00

Former President Donald Trump's defense team expects to finish its arguments in the Senate's impeachment trial by Friday night, two sources tell CNN.

## If you're fully vaccinated, you can skip quarantine for at least three months
 - [https://www.cnn.com/collections/intl-covid-global-1002/](https://www.cnn.com/collections/intl-covid-global-1002/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 16:59:42+00:00



## Meghan, Duchess of Sussex, wins privacy claim against tabloid over letter to her father
 - [https://www.cnn.com/2021/02/11/uk/uk-meghan-court-gbr-intl/index.html](https://www.cnn.com/2021/02/11/uk/uk-meghan-court-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 16:51:52+00:00

Meghan, Duchess of Sussex, has won a privacy claim in her case against a tabloid newspaper that published a handwritten letter to her estranged father, Thomas Markle.

## Biden speaks with Chinese President Xi Jinping for first time as President
 - [https://www.cnn.com/2021/02/10/politics/biden-xi-call/index.html](https://www.cnn.com/2021/02/10/politics/biden-xi-call/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 16:19:40+00:00

President Joe Biden spoke with China's President Xi Jinping late Wednesday, according to a senior administration official, their first call since Biden took office.

## Driver plunges off icy overpass. He shares what happened
 - [https://www.cnn.com/videos/us/2021/02/11/wisconsin-car-fall-overpass-gma-reaction-mxp-sot-vpx.hln](https://www.cnn.com/videos/us/2021/02/11/wisconsin-car-fall-overpass-gma-reaction-mxp-sot-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 16:11:53+00:00

After his car plunged 70 feet from an icy overpass in Wisconsin, Richard Lee Oliver spoke to "Good Morning America" about the terrifying experience.

## Bumble to make Wall Street debut in a milestone moment for female founders
 - [https://www.cnn.com/2021/02/11/tech/bumble-wall-street-debut/index.html](https://www.cnn.com/2021/02/11/tech/bumble-wall-street-debut/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 16:06:39+00:00

Whitney Wolfe Herd isn't based in Silicon Valley. She doesn't have a STEM degree and she didn't raise billions in venture capital. But Wolfe Herd's company, Bumble, is set to have one of the most high-profile technology IPOs of the year so far, in what will be a milestone moment not just for her business but for female founders generally.

## Inside a key Israeli vaccine distribution center
 - [https://www.cnn.com/videos/world/2021/02/11/israel-coronavirus-vaccine-distribution-center-kiley-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/02/11/israel-coronavirus-vaccine-distribution-center-kiley-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 16:00:49+00:00

Israel has a world-beating coronavirus vaccine program: where other countries have struggled, the country has given at least one dose of the vaccine to almost 50 percent of the target population of over 16-year-olds. CNN's Sam Kiley visits a vaccine distribution center to show how Israel is achieving this.

## Senior aides say impeachment managers will go further into the ex-President's role in the Capitol attack
 - [https://www.cnn.com/politics/live-news/trump-impeachment-trial-02-11-2021/index.html](https://www.cnn.com/politics/live-news/trump-impeachment-trial-02-11-2021/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:59:45+00:00



## How risky is it to buy a Tesla using bitcoin?
 - [https://www.cnn.com/2021/02/11/success/buying-tesla-with-bitcoin-feseries/index.html](https://www.cnn.com/2021/02/11/success/buying-tesla-with-bitcoin-feseries/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:54:58+00:00

Tesla revealed in a securities filing this week that it will soon begin accepting bitcoin as payment for its electric vehicles.

## Biden administration seeks a pause on TikTok court fight
 - [https://www.cnn.com/2021/02/11/tech/biden-admin-tiktok/index.html](https://www.cnn.com/2021/02/11/tech/biden-admin-tiktok/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:52:12+00:00

The Biden administration has asked a federal judge to pause litigation over former President Donald Trump's attempt to ban TikTok from the United States.

## The Senate is trying Trump for impeachment. This Senate candidate is insisting the election was stolen.
 - [https://www.cnn.com/2021/02/11/politics/josh-mandel-senate-ohio-trump/index.html](https://www.cnn.com/2021/02/11/politics/josh-mandel-senate-ohio-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:46:48+00:00

The juxtaposition was striking.

## Justice Department says an Oath Keepers leader waited for Trump's direction before Capitol attack
 - [https://www.cnn.com/2021/02/11/politics/oath-keeper-justice-trump-capitol/index.html](https://www.cnn.com/2021/02/11/politics/oath-keeper-justice-trump-capitol/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:45:46+00:00

The Justice Department is now making clear that a leader among the Oath Keepers paramilitary group -- who planned and led others in the US Capitol siege to attempt to stop the Biden presidency -- believed she was responding to the call from then-President Donald Trump himself.

## Parents detail son's desperate attempts to contact Robinhood before he killed himself
 - [https://www.cnn.com/2021/02/11/investing/robinhood-lawsuit-suicide-alex-kearns/index.html](https://www.cnn.com/2021/02/11/investing/robinhood-lawsuit-suicide-alex-kearns/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:39:47+00:00

After their son's death, Dan and Dorothy Kearns said they were horrified to learn that their panicked child repeatedly tried and failed to get in touch with Robinhood about his negative account balance of $730,000.

## Elon Musk, the world's richest man, is about to get a whole lot richer
 - [https://www.cnn.com/2021/02/11/investing/elon-musk-pay-wealth-tesla-stock-options/index.html](https://www.cnn.com/2021/02/11/investing/elon-musk-pay-wealth-tesla-stock-options/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:29:42+00:00

For a CEO who receives no salary, Elon Musk's 2020 payday reached sky-high levels.

## At least 3 dead in 70-vehicle wreck due to weather in Fort Worth, Texas, police say
 - [https://www.cnn.com/2021/02/11/us/texas-fort-worth-crash/index.html](https://www.cnn.com/2021/02/11/us/texas-fort-worth-crash/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:28:02+00:00

At least 70 vehicles were involved in a crash in the Texas city of Fort Worth on Thursday morning, leaving at least three people dead -- and poor weather was a factor -- police said.

## Analysis: Senators confront reality of violent insurrection
 - [https://www.cnn.com/2021/02/11/politics/video-footage-capitol-insurrection-impeachment-trial/index.html](https://www.cnn.com/2021/02/11/politics/video-footage-capitol-insurrection-impeachment-trial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:14:55+00:00

Before former President Donald Trump's impeachment trial, many Capitol Hill Republicans had argued it was futile to force them to relive the January 6 insurrection because they were already witnesses who knew the facts.

## Building the big one: Behind the scenes of Biden's $1.9 trillion bet
 - [https://www.cnn.com/2021/02/11/politics/biden-1-9-trillion-bet/index.html](https://www.cnn.com/2021/02/11/politics/biden-1-9-trillion-bet/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:10:01+00:00

On January 5, as results came in from the Senate runoff election in Georgia, the texts between President-elect Joe Biden's senior staff went late into the night and into the next morning. With the Senate majority on the line, and full control of Washington in their grasp, the outcome of the two Georgia races would determine the fate of what they all agreed was their top priority for the new administration — passing a massive Covid relief package in the opening weeks.

## Lindsey Graham has a very bad take on the Senate impeachment trial
 - [https://www.cnn.com/2021/02/11/politics/lindsey-graham-senate-impeachment-trial/index.html](https://www.cnn.com/2021/02/11/politics/lindsey-graham-senate-impeachment-trial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 15:08:32+00:00

Minutes after the second day of former President Donald Trump's impeachment trial concluded Wednesday night, South Carolina Sen. Lindsey Graham tweeted this:

## 'Bachelor' host Chris Harrison apologizes after defending controversial contestant
 - [https://www.cnn.com/2021/02/11/entertainment/bachelor-chris-harrison-controversy/index.html](https://www.cnn.com/2021/02/11/entertainment/bachelor-chris-harrison-controversy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 14:48:10+00:00

"Bachelor" host Chris Harrison is apologizing after defending a frontrunner on the current season of the show who has come under scrutiny for photos that have surfaced from her past on social media.

## Former Republican officials float possibility of forming conservative party
 - [https://www.cnn.com/2021/02/11/politics/republican-officials-discuss-forming-party/index.html](https://www.cnn.com/2021/02/11/politics/republican-officials-discuss-forming-party/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 14:36:46+00:00

A group of more than 100 former Republican officials have discussed the possibility of forming a conservative party due to their unhappiness with the direction of the GOP under former President Donald Trump and the likelihood he'll be acquitted at the end of his second impeachment trial, according to Republicans who participated in the conversation.

## Shell says its oil production has peaked and will fall every year
 - [https://www.cnn.com/2021/02/11/business/shell-oil-production-peak/index.html](https://www.cnn.com/2021/02/11/business/shell-oil-production-peak/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 14:19:07+00:00

Royal Dutch Shell says its oil production peaked in 2019 and that its carbon emissions are in decline, as it detailed plans to wean itself off fossil fuels.

## Human beings can't grieve alone. The cost of trying will be staggering
 - [https://www.cnn.com/2021/02/11/opinions/covid-19-grief-wave-is-coming-perry/index.html](https://www.cnn.com/2021/02/11/opinions/covid-19-grief-wave-is-coming-perry/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 14:15:39+00:00

My father-in-law died last week. He didn't have Covid. He had terminal lung cancer that spread through his body, and at the end experienced severe delirium and fluid in his lungs.

## Afrobeat star Fela Kuti joins Jay-Z, Mary J. Blige, others on nominees list for Rock and Roll Hall of Fame
 - [https://www.cnn.com/2021/02/11/africa/fela-kuti-hall-of-fame-intl/index.html](https://www.cnn.com/2021/02/11/africa/fela-kuti-hall-of-fame-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 14:14:04+00:00

Afrobeat pioneer, Fela Kuti has been nominated for induction into the Rock and Roll Hall of Fame for 2021.

## Avlon: We saw Trump supporters turn patriotism into hate
 - [https://www.cnn.com/videos/politics/2021/02/11/reality-check-capitol-rioters-trump-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/02/11/reality-check-capitol-rioters-trump-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 14:13:40+00:00

CNN's John Avlon looks at how violent rhetoric about storming the US Capitol and harming politicians was posted online in the days leading up to the insurrection on January 6th.

## The man crossing the world on a highline
 - [https://www.cnn.com/travel/article/ryan-robinson-highline-adventurer/index.html](https://www.cnn.com/travel/article/ryan-robinson-highline-adventurer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 14:13:24+00:00

With calloused bare feet and toes nearly numb, Ryan Robinson carefully rappels his way down the sheer cliff face. A daring feat, no doubt.

## What Lincoln and a 156-year-old question can tell us about America's path forward
 - [https://www.cnn.com/2021/02/11/politics/lincoln-citizenship-americas-path-forward/index.html](https://www.cnn.com/2021/02/11/politics/lincoln-citizenship-americas-path-forward/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 13:39:49+00:00

The stark divide between Republicans and Democrats has mirrored divisions among Americans for many years, but political observers have likened this current period to the Civil War era.

## See how religious leaders and tackling vaccine misinformation
 - [https://www.cnn.com/videos/world/2021/02/11/uk-coronavirus-minority-vaccine-misinformation-covid-19-abdelaziz-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/02/11/uk-coronavirus-minority-vaccine-misinformation-covid-19-abdelaziz-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 13:21:27+00:00

The UK's Vaccination Program is moving at a breakneck speed, but vaccine disinformation and online conspiracy theories still poise a threat, particularly among people of color who are disproportionately affected by Covid-19. CNN's Salma Abdelaziz reports.

## Ten years ago I watched as protesters toppled Egypt's brutal regime. Now their hopes are in tatters
 - [https://www.cnn.com/2021/02/11/middleeast/arab-spring-egypt-memories-10-years-on-hala-gorani-intl/index.html](https://www.cnn.com/2021/02/11/middleeast/arab-spring-egypt-memories-10-years-on-hala-gorani-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 13:16:31+00:00

"They're going room to room, we have to get out."

## Double-masking offers more than double the protection, research shows
 - [https://www.cnn.com/2021/02/11/world/coronavirus-newsletter-02-11-21-intl/index.html](https://www.cnn.com/2021/02/11/world/coronavirus-newsletter-02-11-21-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 12:48:28+00:00

Less than a year ago, there was much debate on the effectiveness of wearing masks in preventing the transmission of Covid-19. Now, not only have masks been scientifically proven to work, new research says wearing TWO is even better. That is, at least, better than wearing a simple disposable surgical mask.

## China's clampdown on harmful emissions puts ozone layer rescue back on track
 - [https://www.cnn.com/2021/02/11/world/ozone-layer-china-emissions-intl-scn/index.html](https://www.cnn.com/2021/02/11/world/ozone-layer-china-emissions-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 12:33:02+00:00

Here's some good news: when people put their mind to it, they can act on climate.

## Stunning NASA photo shows 'gold' Peruvian Amazon rivers -- but there's a dark backstory
 - [https://www.cnn.com/2021/02/11/americas/rivers-gold-peru-amazon-scli-intl-scn/index.html](https://www.cnn.com/2021/02/11/americas/rivers-gold-peru-amazon-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 11:59:06+00:00

All that glitters is not gold, the saying goes, as proven by a new photo taken from the International Space Station (ISS).

## Nigeria's Central Bank ordered to unfreeze bank accounts of #EndSARS protesters
 - [https://www.cnn.com/2021/02/11/africa/nigeria-protests-acounts-unblocked-intl/index.html](https://www.cnn.com/2021/02/11/africa/nigeria-protests-acounts-unblocked-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 11:34:11+00:00

A court in Nigeria's capital city Abuja has ordered the Central Bank to unblock the accounts of 20 people who were involved in the #EndSARS protests which rocked the country last October.

## The people rushing to buy cheap Italian homes
 - [https://www.cnn.com/travel/article/people-cheap-italian-houses/index.html](https://www.cnn.com/travel/article/people-cheap-italian-houses/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 11:06:34+00:00

When the mayor of a sleepy Italian town announced it was selling houses that people can move into for less than the price of a used car, he thought he might get one or two offers.

## With coronavirus variants here, should I still get the vaccine? Dr. Wen weighs in
 - [https://www.cnn.com/2021/02/11/health/dr-wen-coronavirus-variants-vaccine/index.html](https://www.cnn.com/2021/02/11/health/dr-wen-coronavirus-variants-vaccine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 10:42:49+00:00

While vaccinations are ramping up across the United States and many parts of the world, some preliminary studies have suggested the current vaccines may not be as effective with emerging coronavirus variants.

## Dallas Mavericks play national anthem for first time this season after NBA reiterate anthem policy
 - [https://www.cnn.com/2021/02/11/sport/dallas-mavericks-play-national-anthem-nba-atlanta-hawks-spt-intl/index.html](https://www.cnn.com/2021/02/11/sport/dallas-mavericks-play-national-anthem-nba-atlanta-hawks-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 10:22:28+00:00

The Dallas Mavericks played the US national anthem before the team's game on Wednesday for the first time this season.

## Couples everywhere: Here's why you (or they) can't ever find anything. It's not your fault
 - [https://www.cnn.com/2021/02/11/health/home-organization-for-couples-wellness/index.html](https://www.cnn.com/2021/02/11/health/home-organization-for-couples-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 10:10:42+00:00

"Where are the stamps?" I asked my wife.

## Defending champion Sofia Kenin moved to tears after Australian Open defeat
 - [https://www.cnn.com/2021/02/11/tennis/sofia-kenin-australian-opem-defeat-spt-intl/index.html](https://www.cnn.com/2021/02/11/tennis/sofia-kenin-australian-opem-defeat-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 09:41:15+00:00

Sofia Kenin's bid to defend her Australian Open title ended in disappointment on Thursday after she was knocked out of the tournament by world No. 65 Kaia Kanepi.

## Tokyo 2020 Olympics president to resign following sexist remarks
 - [https://www.cnn.com/2021/02/11/sport/yoshiro-mori-resignation-intl-hnk/index.html](https://www.cnn.com/2021/02/11/sport/yoshiro-mori-resignation-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 05:52:59+00:00

Tokyo 2020 Olympics chief Yoshiro Mori will step down after sexist remarks he made about women were leaked to Japanese media last week, Japanese public broadcaster NHK reported Thursday, citing sources.

## New Zealand parliament drops tie requirement after Māori lawmaker ejected for refusing to wear one
 - [https://www.cnn.com/2021/02/10/asia/new-zealand-maori-necktie-intl-scli/index.html](https://www.cnn.com/2021/02/10/asia/new-zealand-maori-necktie-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 03:42:07+00:00

A New Zealand Māori leader who was ejected from parliament this week for refusing to wear a necktie in the chamber said forcing him to a Western dress code was a breach of his rights and an attempt to suppress indigenous culture.

## Japan has the most beds per capita in the world. So why is its health system crashing?
 - [https://www.cnn.com/2021/02/10/asia/japan-healthcare-coronavirus-dst-intl-hnk/index.html](https://www.cnn.com/2021/02/10/asia/japan-healthcare-coronavirus-dst-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 03:07:15+00:00

In late December, Su became sick with Covid-19.

## 'Harry Potter' actor reveals secret cameo while rewatching film
 - [https://www.cnn.com/videos/business/2021/02/11/harry-potter-tom-felton-cameo-instagram-eg-orig.cnn](https://www.cnn.com/videos/business/2021/02/11/harry-potter-tom-felton-cameo-instagram-eg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-11 02:43:26+00:00

Actor Tom Felton, best known for playing Draco Malfoy in the "Harry Potter" film series, revealed his grandfather had a small role in the first film.

