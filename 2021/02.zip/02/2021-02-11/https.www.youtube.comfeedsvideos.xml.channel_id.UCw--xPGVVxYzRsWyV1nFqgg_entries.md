# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## LAST OF US CAST!🎥 Gina Corano Fired🥾 WoT Casting🎞️ -FANTASY NEWS
 - [https://www.youtube.com/watch?v=z-lhmd8q5FQ](https://www.youtube.com/watch?v=z-lhmd8q5FQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-02-12 00:00:00+00:00

LETS TALK ABOUT THE FANTASY NEWS!
The first 1000 people to use the link will get a free trial of Skillshare Premium Membership: https://skl.sh/danielgreene02211

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

NEWS: 

00:00 Mistake

01:07 The Broken God: https://twitter.com/orbitbooks/status/1359121132281073667?s=19 

01:40 REDWALL ADAPTATION: https://nerdist.com/article/redwall-netflix-movie-series-over-garden-wall/?amp 

02:58 LAST OF US CASTING: https://deadline.com/2021/02/pedro-pascal-star-joel-the-last-of-us-hbo-series-video-game-playstation-1234691935/ 
LAST OF US CASTING: https://twitter.com/IGN/status/751848983199420416?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E751848983199420416%7Ctwgr%5E%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fwww.ign.com%2Farticles%2Fhbos-last-of-us-show-casts-game-of-thrones-star-as-ellie 

06:52 Ingtar Casting: https://www.wotseries.com/2021/02/10/scoop-amer-chadha-patels-role-revealed/ 

07:35 Witcher Board game: https://www.instagram.com/p/CLHUPG6rQnD/?igshid=1dzbbmfe65xjh 

08:36 Avatar Breakdown: https://www.youtube.com/watch?v=MgV9vymLIdQ 

09:07 Game of Thrones spinoff begins production: https://tvline.com/2021/02/10/game-of-thrones-prequel-spinoff-starting-production-house-of-the-dragon-hbo/ 

09:17 Mandalorian Actress dropped: https://deadline.com/2021/02/mandalorian-gina-carano-lucas-film-responds-to-controversial-statement-1234691898/ 

09:58   The MetaHumans: https://www.youtube.com/watch?v=6mAF5dWZXcI

## ONE PIECE Vol.1,2,3 - REVIEW
 - [https://www.youtube.com/watch?v=HAKxGE3TkMc](https://www.youtube.com/watch?v=HAKxGE3TkMc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-02-11 00:00:00+00:00

Let's talk about Volumes 1 2 and 3 of the anime/manga One Piece! 
Be sure to check out Curiosity Stream here: https://curiositystream.com/Greene

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

