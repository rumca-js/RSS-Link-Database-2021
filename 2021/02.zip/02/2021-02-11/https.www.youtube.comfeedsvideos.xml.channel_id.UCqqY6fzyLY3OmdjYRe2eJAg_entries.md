# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt - Lovers (Official Audio)
 - [https://www.youtube.com/watch?v=Vjifk3hrSY8](https://www.youtube.com/watch?v=Vjifk3hrSY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2021-02-12 00:00:00+00:00

'POLYDANS' - my new album - out now! Stream / Purchase here: https://roosevelt.lnk.to/Polydans

FOLLOW Roosevelt on Facebook, Instagram and more https://roosevelt.lnk.to/follow​
Website : https://roosevelt.lnk.to/website​ 

This is the Official Youtube Channel for Roosevelt. 
SUBSCRIBE NOW to be kept up to date with the latest music, videos, tour dates, behind the scenes footage and more https://roosevelt.lnk.to/subscribe​

MUSIC CREDITS
Written, Performed, Recorded and Produced by Marius Lauber
Mixed by Marius Lauber
Mastered by Heba Kadry 

LYRICS

Here I go again 
I never wanted anybody else 
Now I realize 
Another year's gone to waste 
 
Give yourself a chance 
And leave your broken heart right at the door 
Comes with no surprise 
That you keep running away 
 
You know the world keeps turning around 
Just take me home nowhere to be found 
We're lovers tonight 
We're lovers tonight 
 
I'll take you high again 
Yeah you're the one who's talking in my sleep 
We can just pretend 
And walk away out of sight 
 
It's our only chance 
I'll take you on a trip you've never been 
Just hold me till the end 
And let me guide through the night 
 
You know the world keeps turning around 
Just take me home nowhere to be found 
 
We're lovers tonight 
We're lovers tonight 
We're lovers tonight 
We're lovers tonight

