# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## WandaVision - Episode 6 (My Thoughts)
 - [https://www.youtube.com/watch?v=obJuw7iRJhU](https://www.youtube.com/watch?v=obJuw7iRJhU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-02-12 00:00:00+00:00

Go to https://buyraycon.com/jahns for 15% off your order!
Thank you Raycon for sponsoring!

As the questions grow, I delve into my theory on who Agnes is. Here are my thoughts on #Wandavision episode 6!

