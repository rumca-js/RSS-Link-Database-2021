# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Big Oontz Oontz Live Modular Rig Walkthrough
 - [https://www.youtube.com/watch?v=Hwn6Yu_cJTI](https://www.youtube.com/watch?v=Hwn6Yu_cJTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-02-12 00:00:00+00:00

This rig was inspired by the dub techno work of Stewart Walker's "Live Extracts" album. I've used it for a few performances, and I'd like to talk to you about how it works.
Written walkthrough: https://www.patreon.com/posts/let-me-tell-you-46839588
Watch my Seattle Modular Nights performance with this rig: https://youtu.be/6tmdiVgtheM
Catch me on New York Modular with this rig (March 13th): https://nyms.love/events-directory/
Glow cables by Modbang: https://www.modbang.com/
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

## Seattle Modular Nights - Full Performance (February 2021)
 - [https://www.youtube.com/watch?v=6tmdiVgtheM](https://www.youtube.com/watch?v=6tmdiVgtheM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-02-12 00:00:00+00:00

My performance for Seattle Modular Nights, February 2021
https://www.modularseattle.com/events/modular-nights-4
Video walkthrough here: https://youtu.be/Hwn6Yu_cJTI
Written walkthrough here: https://www.patreon.com/posts/let-me-tell-you-46839588
Watch another performance with this rig: https://youtu.be/8bIme3GHRq8
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

