# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## A history of violence: Senate hears how Trump stoked Capitol assault over years | David Smith's sketch
 - [https://www.theguardian.com/us-news/2021/feb/11/trump-impeachment-trial-third-day-senate](https://www.theguardian.com/us-news/2021/feb/11/trump-impeachment-trial-third-day-senate)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 23:53:35+00:00

<p>At third day of impeachment trial, House managers focused on how Trump manipulated the emotions of Americans who were then willing to walk on hot coals on his behalf</p><p>It was “a little terrifying”, Eleanor Roosevelt <a href="https://bangordailynews.com/2009/01/16/uncategorized/eleanor-roosevelt-and-the-weight-of-her-world">told the Associated Press</a> about her husband Franklin’s inauguration as US president in 1933. “The crowds were so tremendous. And you felt that they would do anything – if only someone would tell them what to do.”</p><p>The ability of leaders to turns crowds into mobs and bend them to their will has been a constant in history was a focus of <a href="https://www.theguardian.com/us-news/2021/feb/11/trump-impeachment-trial-democrats-senate">the third day</a> of former US president Donald Trump’s impeachment trial in the Senate on Thursday.</p> <a href="https://www.theguardian.com/us-news/2021/feb/11/trump-impeachment-trial-third-day-senate">Continue reading...</a>

## Fernando Alonso's F1 return plunged into doubt after cycling accident
 - [https://www.theguardian.com/sport/2021/feb/11/f1-speeds-towards-100km-sprint-races-replacing-grand-prix-qualifying-motor-sport](https://www.theguardian.com/sport/2021/feb/11/f1-speeds-towards-100km-sprint-races-replacing-grand-prix-qualifying-motor-sport)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 23:28:12+00:00

<ul><li>Double world champion reported to have sustained fractures</li><li>His Alpine team says: ‘Fernando is conscious and well in himself’</li></ul><p>Fernando Alonso’s Formula One comeback has been jeopardised after his Alpine team confirmed he has been involved in a road accident while cycling in Switzerland.</p><p>The team made an announcement on Thursday that gave no details of the incident but stated: “Fernando is conscious and well in himself and is awaiting further medical examinations tomorrow morning.”</p> <a href="https://www.theguardian.com/sport/2021/feb/11/f1-speeds-towards-100km-sprint-races-replacing-grand-prix-qualifying-motor-sport">Continue reading...</a>

## English football hopes for US sports link-up in fight against online abuse
 - [https://www.theguardian.com/football/2021/feb/11/football-unites-to-demand-social-media-racism-crackdown-facebook-twitter](https://www.theguardian.com/football/2021/feb/11/football-unites-to-demand-social-media-racism-crackdown-facebook-twitter)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 22:34:54+00:00

<ul><li>Open letter written to heads of Twitter and Facebook</li><li>FA wants to work with NBA and NFL to force change<br /></li></ul><p>English football authorities are set to reach out to US sports in a global push against racist abuse on social media.</p><p>On the day the Newcastle manager, Steve Bruce, revealed he had <a href="https://www.theguardian.com/football/2021/feb/11/steve-bruce-reveals-he-has-received-online-death-threats" title="">received death threats online</a>, and the publication of a letter from leaders across the English game calling on Facebook’s Mark Zuckerberg and Twitter’s Jack Dorsey to take personal responsibility for the spread of abusive content on their platform, the FA’s director for equality, diversity and inclusion, Edleen John, said it was time for an international approach in attempting to force change.</p> <a href="https://www.theguardian.com/football/2021/feb/11/football-unites-to-demand-social-media-racism-crackdown-facebook-twitter">Continue reading...</a>

## Chick Corea, Grammy-winning jazz musician, dies at 79
 - [https://www.theguardian.com/music/2021/feb/11/chick-corea-grammy-winning-jazz-musician-dies](https://www.theguardian.com/music/2021/feb/11/chick-corea-grammy-winning-jazz-musician-dies)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 22:25:33+00:00

<p>The composer, keyboardist and bandleader, who won 23 Grammy awards, has died of a rare form of cancer</p><p>The jazz pioneer Chick Corea has died at the age of 79.</p><p>According to <a href="https://www.facebook.com/chickcorea/posts/10158422599898924">a post on his Facebook page</a>, the musician died from “a rare form of cancer which was only discovered very recently”. In his career, Corea won 23 Grammys and was the fourth most-nominated artist in Grammys history.</p> <a href="https://www.theguardian.com/music/2021/feb/11/chick-corea-grammy-winning-jazz-musician-dies">Continue reading...</a>

## England's Jofra Archer to miss second Test against India after injection
 - [https://www.theguardian.com/sport/2021/feb/11/jofra-archer-set-to-miss-second-test-in-blow-to-england-hopes-india-cricket](https://www.theguardian.com/sport/2021/feb/11/jofra-archer-set-to-miss-second-test-in-blow-to-england-hopes-india-cricket)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 22:05:31+00:00

<ul><li>Jimmy Anderson may feature alongside Stuart Broad<br /></li><li>Joe Root demands more game-defining contributions</li></ul><p>Jofra Archer has been ruled out of the second Test against India in Chennai, with Joe Root telling his England players to follow the example set by himself and Jimmy Anderson as they look to go 2-0 up in the series.</p><p>Archer impressed with three wickets and hostile speeds during <a href="https://www.theguardian.com/sport/2021/feb/09/james-anderson-leads-england-to-227-run-victory-over-india-in-first-test#:~:text=Jimmy%20Anderson%20leads%20England%20to,over%20India%20in%20first%20Test&amp;text=England%20in%20India%202020%2D21&amp;text=The%20Guardian" title="">the 227-run victory</a> in the first Test but, along with illness on the final day, the fast bowler has since received an injection to a “niggle” in his right elbow after the Guardian learned that he had missed nets on Thursday.</p> <a href="https://www.theguardian.com/sport/2021/feb/11/jofra-archer-set-to-miss-second-test-in-blow-to-england-hopes-india-cricket">Continue reading...</a>

## Tammy Abraham pops up to help Chelsea break Barnsley resistance
 - [https://www.theguardian.com/football/2021/feb/11/barnsley-chelsea-fa-cup-fifth-round-match-report](https://www.theguardian.com/football/2021/feb/11/barnsley-chelsea-fa-cup-fifth-round-match-report)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 22:00:48+00:00

<p>Chelsea are into the quarter-finals of the FA Cup after an edgy victory over a Barnsley side who made proceedings awkward for Thomas Tuchel’s team. If the eight-times winners hardly convinced the bottom line is that they next host Sheffield United and will fancy their chances of sealing a semi-final outing at Wembley.</p><p> <span>Related: </span><a href="https://www.theguardian.com/football/2021/feb/11/wolves-southampton-fa-cup-fifth-round-match-report">Southampton's Danny Ings enjoys stroke of luck to lead win over Wolves</a> </p> <a href="https://www.theguardian.com/football/2021/feb/11/barnsley-chelsea-fa-cup-fifth-round-match-report">Continue reading...</a>

## Eddie Jones plays it safe for Italy game and Ollie Lawrence pays the price
 - [https://www.theguardian.com/sport/2021/feb/11/eddie-jones-with-england-six-nations-italy-lawrence](https://www.theguardian.com/sport/2021/feb/11/eddie-jones-with-england-six-nations-italy-lawrence)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 22:00:25+00:00

<p>The conservative selection is a missed opportunity with a glaring lack of faith shown in England’s young squad members</p><p>There are two ways of looking at <a href="https://www.theguardian.com/sport/2021/feb/11/owen-farrell-george-ford-partnership-back-for-england-v-italy-six-nations-clash-eddie-jones-rugby-union" title="">England’s starting selection against Italy </a>on Saturday. The first is to note the renewed physical intent, the souped-up pack and the ominous smoke signals from the visitors’ perspective. The second is to bemoan the glaring lack of faith shown in young squad members for whom this fixture was a perfect chance to impress. A cold week for everyone has become even chillier for some.</p><p> <span>Related: </span><a href="https://www.theguardian.com/sport/2021/feb/11/owen-farrell-george-ford-partnership-back-for-england-v-italy-six-nations-clash-eddie-jones-rugby-union">Farrell-Ford partnership back for England v Italy Six Nations clash</a> </p> <a href="https://www.theguardian.com/sport/2021/feb/11/eddie-jones-with-england-six-nations-italy-lawrence">Continue reading...</a>

## Firefighters struggle to contain large blaze on Dartmoor
 - [https://www.theguardian.com/uk-news/2021/feb/11/firefighters-struggle-contain-large-blaze-dartmoor](https://www.theguardian.com/uk-news/2021/feb/11/firefighters-struggle-contain-large-blaze-dartmoor)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 21:54:47+00:00

<p>No people or livestock are yet believed to have been harmed, but remote location has made tackling fire difficult</p><p>A large fire has broken out on Dartmoor near Tavy Cleave in Devon, a few miles north east of Tavistock.</p><p>Devon and Somerset fire and rescue service has deployed five pumps and other units to the area, but has struggled to tackle the fire because its location is difficult to access.</p> <a href="https://www.theguardian.com/uk-news/2021/feb/11/firefighters-struggle-contain-large-blaze-dartmoor">Continue reading...</a>

## Police killed baby when shooting at father's truck, Canada watchdog finds
 - [https://www.theguardian.com/world/2021/feb/11/canada-police-killed-baby-ontario-investigation](https://www.theguardian.com/world/2021/feb/11/canada-police-killed-baby-ontario-investigation)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 21:13:11+00:00

<p>Ontario’s special investigations unit concludes gunfire was cause of one-year-old’s death in Kawartha Lakes</p><p>Nearly three months after an armed confrontation in rural Canada, a police watchdog has concluded that a police bullet killed a one-year-old baby when officers <a href="https://www.theguardian.com/world/2020/nov/27/one-year-old-boy-shot-dead-during-alleged-kidnapping-in-canada">opened fire on his father’s truck</a>.</p><p>In its first public finding on Thursday, Ontario’s <a href="https://www.siu.on.ca/en/news_template.php?nrid=6355">special investigations unit</a> said that a review of evidence indicated police gunfire was the cause of the child’s death on 26 November.</p> <a href="https://www.theguardian.com/world/2021/feb/11/canada-police-killed-baby-ontario-investigation">Continue reading...</a>

## Brazil: missionaries 'turning tribes against coronavirus vaccine'
 - [https://www.theguardian.com/world/2021/feb/11/brazil-missionaries-turning-tribes-against-coronavirus-vaccine](https://www.theguardian.com/world/2021/feb/11/brazil-missionaries-turning-tribes-against-coronavirus-vaccine)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:48:14+00:00

<p>Health workers were reportedly attacked with bows and arrows after visiting an indigenous community in Amazonas</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Medical teams working to immunise Brazil’s remote indigenous villages against the coronavirus have encountered fierce resistance in some communities where evangelical missionaries are stoking fears of the vaccine, say tribal leaders and advocates.</p><p>On the São Francisco reservation in the state of Amazonas, Jamamadi villagers sent health workers packing with bows and arrows when they visited by helicopter this month, said Claudemir da Silva, an Apurinã leader representing indigenous communities on the Purus river, a tributary of the Xingú.</p> <a href="https://www.theguardian.com/world/2021/feb/11/brazil-missionaries-turning-tribes-against-coronavirus-vaccine">Continue reading...</a>

## Matt Hancock lays out plan for reorganisation of NHS in England
 - [https://www.theguardian.com/society/2021/feb/11/matt-hancock-lays-out-his-plan-for-wholesale-reorganisation-of-nhs](https://www.theguardian.com/society/2021/feb/11/matt-hancock-lays-out-his-plan-for-wholesale-reorganisation-of-nhs)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:44:05+00:00

<p>Latest shake-up, centralising power in minister’s hands, undoes much put in place under David Cameron</p><p>Matt Hancock has laid out his plan for a wholesale reorganisation of the NHS in England which will centralise power in ministerial hands.</p><p>The plan has broad Tory support but Labour questioned the timing of the move, with the health service still reeling from coronavirus.</p> <a href="https://www.theguardian.com/society/2021/feb/11/matt-hancock-lays-out-his-plan-for-wholesale-reorganisation-of-nhs">Continue reading...</a>

## Margaret Snyder obituary
 - [https://www.theguardian.com/world/2021/feb/11/margaret-snyder-obituary](https://www.theguardian.com/world/2021/feb/11/margaret-snyder-obituary)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:27:51+00:00

<p>Founding director of Unifem, the United Nations development fund for women</p><p>When Margaret Snyder first started working for the UN in Addis Ababa in 1971, programmes for African women centred around healthcare and support for children. Snyder, who has died aged 91, established the first UN regional women’s programme to change that perception. She went on to launch the UN’s development fund for women (Unifem) and became affectionately known as the “UN’s first feminist”.</p><p>Her job in Ethiopia was to help establish a women’s programme at the UN Economic Commission for Africa (ECA) to support women in their roles as farmers, entrepreneurs and often family breadwinners. The programme evolved into the African Training and Research Centre for Women (ATRCW).</p> <a href="https://www.theguardian.com/world/2021/feb/11/margaret-snyder-obituary">Continue reading...</a>

## Texas interstate crash: at least five killed in pileup of up to 100 vehicles
 - [https://www.theguardian.com/us-news/2021/feb/11/texas-interstate-crash-fort-worth](https://www.theguardian.com/us-news/2021/feb/11/texas-interstate-crash-fort-worth)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:07:43+00:00

<p>Overnight freezing rain caused the pileup near Fort Worth which left a nearly mile-long wreckage and injured dozens of people</p><p>At least five people were killed and dozens injured on Thursday in a crash involving up to 100 vehicles on an icy Texas interstate highway, police said, as a winter storm dropped freezing rain, sleet and snow on parts of the US.</p><p>At the scene of the crash on Interstate 35 near Fort Worth, a tangle of semitrailers, cars and trucks had crashed into each other and had turned every which way, with some vehicles on top of others.</p> <a href="https://www.theguardian.com/us-news/2021/feb/11/texas-interstate-crash-fort-worth">Continue reading...</a>

## Parkland activists divided over David Hogg’s pillow venture as anniversary nears
 - [https://www.theguardian.com/us-news/2021/feb/11/parkland-david-hogg-good-pillow-cameron-kasky](https://www.theguardian.com/us-news/2021/feb/11/parkland-david-hogg-good-pillow-cameron-kasky)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:05:53+00:00

<p>Cameron Kasky tweets ‘everything ends up a grift’ after Hogg launches Good Pillow to challenge Trump ally Mike Lindell</p><p>The prominent gun control movement founded by survivors of the 2018 Parkland high school shooting in Florida has splintered after one member set up his own commercial venture to challenge Donald Trump ally Mike Lindell and his My Pillow company.</p><p>David Hogg has been accused of “grift” by other leaders of the March for Our Lives group for his new <a href="https://goodpillow.co/">Good Pillow</a> venture, which the former Marjory Stoneman Douglas high school student launched this week just days before the 14 February anniversary of the <a href="https://www.theguardian.com/us-news/florida-school-shooting">massacre</a> that took 17 lives.</p> <a href="https://www.theguardian.com/us-news/2021/feb/11/parkland-david-hogg-good-pillow-cameron-kasky">Continue reading...</a>

## China bans BBC World News in retaliation for UK licence blow
 - [https://www.theguardian.com/world/2021/feb/11/china-bans-bbc-world-news](https://www.theguardian.com/world/2021/feb/11/china-bans-bbc-world-news)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:03:03+00:00

<p>China has been critical of BBC reports on Xinjiang, while Ofcom recently revoked CGTN licence</p><p>BBC World News has been banned from airing in China, a week after Beijing threatened to retaliate for the <a href="https://www.theguardian.com/world/2021/feb/04/chinese-news-network-cgtn-loses-uk-licence-after-ofcom-ruling">recent revocation of the British broadcasting licence</a> for China’s state-owned CGTN.</p><p>In a statement published at midnight Beijing time on Friday, China’s National Radio and Television Administration said BBC World News’s coverage of China had violated requirements that news reporting be true and impartial and undermined China’s national interests and ethnic solidarity.</p> <a href="https://www.theguardian.com/world/2021/feb/11/china-bans-bbc-world-news">Continue reading...</a>

## Gareth Bale caught in a sad cycle as his Spurs story turns sour | David Hytner
 - [https://www.theguardian.com/football/2021/feb/11/gareth-bale-caught-in-a-sad-cycle-as-his-spurs-story-turns-sour-mourinho](https://www.theguardian.com/football/2021/feb/11/gareth-bale-caught-in-a-sad-cycle-as-his-spurs-story-turns-sour-mourinho)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:00:22+00:00

<p>Forward needs games for rhythm but has looked too fragile and one-paced to merit them and Mourinho’s barbs are multiplying</p><p>‘Good session today,” wrote Gareth Bale on Instagram, accompanying the photograph of him from Tottenham’s training pitches on Tuesday with a bicep curl emoji. When the post went live that evening, the Spurs squad were at their hotel on Merseyside and looking forward to Wednesday’s FA Cup fifth-round tie at Everton. Except that Bale was not with them.</p><p>“Good session today?” thought José Mourinho. Bale had made clear to him that he was not feeling 100% and would not be able to travel but the tone of his public messaging was different. Taken to the extreme, it stood to back Mourinho into a corner at Goodison Park when Bale’s absence came to light.</p> <a href="https://www.theguardian.com/football/2021/feb/11/gareth-bale-caught-in-a-sad-cycle-as-his-spurs-story-turns-sour-mourinho">Continue reading...</a>

## Henny Beaumont on parenting in a pandemic – cartoon
 - [https://www.theguardian.com/commentisfree/picture/2021/feb/11/henny-beaumont-on-parenting-in-a-pandemic-cartoon](https://www.theguardian.com/commentisfree/picture/2021/feb/11/henny-beaumont-on-parenting-in-a-pandemic-cartoon)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 20:00:22+00:00

<a href="https://www.theguardian.com/commentisfree/picture/2021/feb/11/henny-beaumont-on-parenting-in-a-pandemic-cartoon">Continue reading...</a>

## Shell strategy looking like a bundle of compromises | Nils Pratley
 - [https://www.theguardian.com/business/nils-pratley-on-finance/2021/feb/11/shell-strategy-looking-like-a-bundle-of-compromises](https://www.theguardian.com/business/nils-pratley-on-finance/2021/feb/11/shell-strategy-looking-like-a-bundle-of-compromises)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 19:55:45+00:00

<p>Investors will get a vote on oil company’s plan to cruise down the middle lane</p><p>Shell billed its <a href="https://www.theguardian.com/business/2021/feb/11/shell-grow-gas-business-energy-net-zero-carbon">net zero by 2050 plan</a> as an “acceleration” of strategy, which was a generous self-assessment. In today’s big oil terms, the approach is a cruise down the middle lane – a tweak here and there, but nothing to frighten those shareholders still scarred by last year’s cut of two-thirds in the dividend.</p><p>The company plans to reduce oil output by only 1%-2% a year until 2030, which compounds to an overall reduction of about 15% in the period. BP opted for 40% cut in oil and gas by 2030. Including gas, Shell’s production may be flat.</p> <a href="https://www.theguardian.com/business/nils-pratley-on-finance/2021/feb/11/shell-strategy-looking-like-a-bundle-of-compromises">Continue reading...</a>

## UK government accused of 'dragging heels' on racism
 - [https://www.theguardian.com/world/2021/feb/11/uk-government-accused-of-dragging-heels-in-response-to-racism-report](https://www.theguardian.com/world/2021/feb/11/uk-government-accused-of-dragging-heels-in-response-to-racism-report)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 19:55:00+00:00

<p>Rejection of select committee’s recommendations on Black people and human rights prompts criticism</p><p>The government is still “dragging its heels” on racism, according to MPs and race equality campaigners critical of its response to a damning <a href="https://committees.parliament.uk/publications/3376/documents/32359/default/">parliamentary report</a> on Black people and human rights.</p><p>The government’s <a href="https://file///Volumes/Downloads/Internet%20Downloads/Government%20Response%20Black%20people%20racism%20and%20human%20rights%20(1).pdf">official response</a> to the human rights select committee’s report was published on Thursday and rejected the majority of the parliamentarians’ 22 recommendations.</p> <a href="https://www.theguardian.com/world/2021/feb/11/uk-government-accused-of-dragging-heels-in-response-to-racism-report">Continue reading...</a>

## Shares in dating app Bumble soar in first day of trading on Nasdaq
 - [https://www.theguardian.com/business/2021/feb/11/shares-in-dating-app-bumble-soar-in-first-day-of-trading-on-nasdaq](https://www.theguardian.com/business/2021/feb/11/shares-in-dating-app-bumble-soar-in-first-day-of-trading-on-nasdaq)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 19:46:24+00:00

<p>Texas-based company valued at $14bn after shares open at $76, far above the IPO price of $43</p><p>Shares in the dating app Bumble have soared by more than 76% in its stock market debut in New York, giving the company a $14bn (£10bn) valuation.</p><p>The shares opened at $76 (£55) on the Nasdaq on Thursday, well above the initial public offering price of $43.</p> <a href="https://www.theguardian.com/business/2021/feb/11/shares-in-dating-app-bumble-soar-in-first-day-of-trading-on-nasdaq">Continue reading...</a>

## Who might replace Simon Stevens as the NHS England boss?
 - [https://www.theguardian.com/society/2021/feb/11/who-might-replace-simon-stevens-as-the-nhs-england-boss](https://www.theguardian.com/society/2021/feb/11/who-might-replace-simon-stevens-as-the-nhs-england-boss)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 19:39:58+00:00

<p>As insiders suggest chief executive’s seven-year stint is coming to an end, we look at who might take over</p><p>Simon Stevens’ eventful seven-year stint as the high-profile, independent-minded boss of the NHS in England is coming to an end, NHS insiders and Whitehall sources have confirmed.</p><p>Attention is now falling on who might replace him whenever he does stand down. Formally NHS England’s board will select his successor, but Boris Johnson will also play a key role in the appointment.</p> <a href="https://www.theguardian.com/society/2021/feb/11/who-might-replace-simon-stevens-as-the-nhs-england-boss">Continue reading...</a>

## NHS figures show scale of January surge in Covid admissions
 - [https://www.theguardian.com/world/2021/feb/11/almost-a-third-of-all-patients-hospitalised-in-england-by-covid-admitted-in-january](https://www.theguardian.com/world/2021/feb/11/almost-a-third-of-all-patients-hospitalised-in-england-by-covid-admitted-in-january)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 19:35:09+00:00

<p>First month of year accounted for nearly a third of all hospital admissions in pandemic to date</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Boris Johnson is facing fresh questions about whether he acted too slowly in the run up to Christmas, after it emerged that almost a third of all the patients hospitalised with Covid in England to date were admitted in January.</p><p>NHS England statistics show there were 101,956 new Covid-19 admissions last month, accounting for 29% of all admissions between March 2020 and the end of January, underlining the severity of the latest wave of the virus.</p> <a href="https://www.theguardian.com/world/2021/feb/11/almost-a-third-of-all-patients-hospitalised-in-england-by-covid-admitted-in-january">Continue reading...</a>

## Libby Squire's family still in dark about how she died after murder conviction
 - [https://www.theguardian.com/uk-news/2021/feb/11/libby-squire-family-still-in-dark-about-how-she-died-after-conviction](https://www.theguardian.com/uk-news/2021/feb/11/libby-squire-family-still-in-dark-about-how-she-died-after-conviction)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 19:16:40+00:00

<p>Pawel Relowicz disclosed no details during trial and pathologist was unable to determine cause of death </p><p>More than two years after their daughter’s murder, Libby Squire’s parents are still in the dark. They don’t know how she was killed or whether she was alive when she entered the River Hull. What they do now know, however, is that Pawel Relowicz, a 26-year-old butcher, is the man who killed her.</p><p>Relowicz, who was convicted of murdering the 21-year-old on Thursday, is still the only person who knows what happened in the early hours of 1 February 2019. A Home Office pathologist, Dr Matthew Lyall, told jurors that Squire’s cause of death could not be determined because of the amount of time her body had been in the water. By the time it was recovered, it had spent seven weeks in the Humber Estuary.</p> <a href="https://www.theguardian.com/uk-news/2021/feb/11/libby-squire-family-still-in-dark-about-how-she-died-after-conviction">Continue reading...</a>

## Review casts doubt on London fire brigade's high-rise capabilities
 - [https://www.theguardian.com/uk-news/2021/feb/11/review-casts-doubt-london-fire-brigade-high-rise-capabilities-grenfell](https://www.theguardian.com/uk-news/2021/feb/11/review-casts-doubt-london-fire-brigade-high-rise-capabilities-grenfell)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:42:08+00:00

<p>Inspectors find LFB cannot assure itself that response to a Grenfell-like fire would be vastly improved</p><p>The London fire brigade’s ability to cope with a second high-rise fire on the scale of Grenfell Tower has been cast into doubt by government inspectors who found the brigade could not assure itself that its response would be vastly improved.</p><p>In a conclusion likely to unnerve high-rise residents in the capital, Her Majesty’s Inspectorate of Constabulary and Fire and Rescue Services found that 44 months after the disaster the LFB had failed to sufficiently retrain incident commanders or update policy on telling residents to <a href="https://www.theguardian.com/uk-news/2019/oct/16/london-fire-chief-calls-review-stay-put-advice-during-blazes-grenfell-tower">stay put</a> or evacuate burning buildings. Both issues were raised in a <a href="https://www.theguardian.com/uk-news/2019/oct/28/grenfell-inquiry-finds-fire-brigade-gravely-ill-prepared-for-blaze">highly critical assessment</a> by the Grenfell inquiry of the LFB’s handling of the fire, which claimed 72 lives.</p> <a href="https://www.theguardian.com/uk-news/2021/feb/11/review-casts-doubt-london-fire-brigade-high-rise-capabilities-grenfell">Continue reading...</a>

## The Guardian view on NHS reorganisation: the need to integrate | Editorial
 - [https://www.theguardian.com/commentisfree/2021/feb/11/the-guardian-view-on-nhs-reorganisation-the-need-to-integrate](https://www.theguardian.com/commentisfree/2021/feb/11/the-guardian-view-on-nhs-reorganisation-the-need-to-integrate)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:39:08+00:00

<p>Amid the pandemic, Matt Hancock needs to display the humility that his tin-eared predecessor Andrew Lansley lacked</p><p>Few would dispute that the <a href="https://www.theguardian.com/commentisfree/2020/jul/17/government-doctors-boris-johnson-nhs-covid-19-central-power" title="">Lansley reforms</a> of the National Health Service in England, embodied in the Health and Social Care Act 2012, failed. More than 500 pages long, and often opaquely expressed, the legislation stripped control of the NHS from national and local government, and thus from the public, creating a large new bureaucracy to manage healthcare, drive competition and build a regulated internal market. Coming amid fierce spending austerity, the reforms were often seen as the enabler of a programme of cuts and privatisation. “I could and should have stepped in earlier,” David Cameron admitted in his <a href="https://www.theguardian.com/books/2019/sep/22/for-the-record-david-cameron-review" title="">memoir</a>.</p><p>Disastrous though the reforms have been, and clear though the case is for replacing them, a new attempt at reorganisation would be destabilising, mid-pandemic, without strong support within the NHS that it can be implemented sympathetically. Matt Hancock embarked on such an attempt on Thursday, in his Integration and Innovation <a href="https://www.gov.uk/government/publications/working-together-to-improve-health-and-social-care-for-all" title="">white paper</a>. His proposals unquestionably cut with the grain of much that <a href="https://www.england.nhs.uk/wp-content/uploads/2021/02/legislating-for-integrated-care-systems-five-recommendations.pdf" title="">NHS England</a> has been advocating to improve integrated care in the past two years. But Mr Hancock will have to make a strong case over the coming weeks if the public is to be persuaded that this reorganisation is the right priority in health policy.</p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/the-guardian-view-on-nhs-reorganisation-the-need-to-integrate">Continue reading...</a>

## The Guardian view on two-tone nostalgia: the pride of Coventry | Editorial
 - [https://www.theguardian.com/commentisfree/2021/feb/11/the-guardian-view-on-two-tone-nostalgia-the-pride-of-coventry](https://www.theguardian.com/commentisfree/2021/feb/11/the-guardian-view-on-two-tone-nostalgia-the-pride-of-coventry)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:38:33+00:00

<p>Britain’s city of culture for 2021 is rightly celebrating a musical movement that still carries a potent message</p><p>Interviewed a couple of years ago, the lead singer of The Specials, Terry Hall, was <a href="https://www.theguardian.com/music/2019/feb/03/specials-terry-hall-horace-panter-lynval-golding-hope-what-else-have-we-got-encore-interview" title="">asked</a> what he remembered most fondly about the two-tone era, when the band’s home city of Coventry hosted the most innovative music scene in Britain. “We were doing something that wasn’t in London,” responded Mr Hall who, rather shockingly, is now in his 60s. “It was a sense of pride in where we were.”</p><p>Fittingly then, one of the most inspiring periods in postwar youth culture is to be given pride of place during Coventry’s <a href="https://coventry2021.co.uk/?gclid=Cj0KCQiAyJOBBhDCARIsAJG2h5elEi80_9-OzfxEQ_JsNSh3yHwnAoC7cf8QktGpeeIHgEsyP-9En50aAt5dEALw_wcB" title="">forthcoming</a> city of culture 2021 celebrations. Covid has delayed festivities until May. But when they do begin, it was <a href="https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-55937935" title="">revealed</a> this month that the programme of events will include the first major exhibition on the lives and legacies of the two-tone era. There will also be a three-day music event curated by Mr Hall.</p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/the-guardian-view-on-two-tone-nostalgia-the-pride-of-coventry">Continue reading...</a>

## MPs pass 'long overdue' bill for ministers' paid maternity leave
 - [https://www.theguardian.com/politics/2021/feb/11/mps-pass-long-overdue-bill-for-ministers-paid-maternity-leave](https://www.theguardian.com/politics/2021/feb/11/mps-pass-long-overdue-bill-for-ministers-paid-maternity-leave)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:17:25+00:00

<p>Government says it will bring forward more protections amid accusations of double standards<br /></p><p>MPs have voted to give ministers formal paid maternity leave for the first time, hailed as an “important and long overdue change” as the government pledged to bring forward more sweeping maternity protections before the summer recess.</p><p>However, the move to give the attorney general, Suella Braverman, six months’ paid leave drew accusations of double standards during the parliamentary debate, including over the omission of any reference to paternity leave and the failure to extend similar benefits to backbenchers.</p> <a href="https://www.theguardian.com/politics/2021/feb/11/mps-pass-long-overdue-bill-for-ministers-paid-maternity-leave">Continue reading...</a>

## Spectator wins challenge to court order in Alex Salmond case
 - [https://www.theguardian.com/politics/2021/feb/11/spectator-wins-challenge-to-court-order-in-alex-salmond-case](https://www.theguardian.com/politics/2021/feb/11/spectator-wins-challenge-to-court-order-in-alex-salmond-case)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:14:31+00:00

<p>Ruling could clear way for former first minister to give evidence to Holyrood committee</p><p>The Spectator has won a legal action that could clear the way for Alex Salmond to give evidence to Holyrood about a botched Scottish government inquiry into allegations of sexual misconduct against him.</p><p>A senior Scottish judge, Lady Dorrian, has agreed to amend a court order she imposed on what could be reported about Salmond’s criminal trial on 14 counts of alleged sexual assault, including an attempted rape, of which he was <a href="https://www.theguardian.com/politics/2020/mar/23/alex-salmond-acquitted-of-all-charges-in-sexual-assault-trial">acquitted last year</a>.</p> <a href="https://www.theguardian.com/politics/2021/feb/11/spectator-wins-challenge-to-court-order-in-alex-salmond-case">Continue reading...</a>

## Misreading the mood on Scottish independence | Letters
 - [https://www.theguardian.com/politics/2021/feb/11/misreading-the-mood-on-scottish-independence](https://www.theguardian.com/politics/2021/feb/11/misreading-the-mood-on-scottish-independence)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:11:47+00:00

<p><strong>Roger Read, </strong><strong>Val Machin, </strong><strong>Fiona Raffaelli</strong> and <strong>Alastair McLeish </strong>respond to an article by Rafael Behr </p><p>Rafael Behr asserts that the case for Scottish independence is as “flaky and dishonest” as the Tory Brexit prospectus once was (<a href="https://www.theguardian.com/commentisfree/2021/feb/09/sturgeon-johnson-scottish-exit-snp-brexit" title="">Sturgeon and Johnson have made Scottish independence seem inevitable. It isn’t</a>, 9 February). By flaky, he seems to refer to issues of currency, national debt, a budget black hole, a customs border with England and how much it would all cost. By dishonest, he seems to mean that Scots are being deceived about these issues. If Covid has proved anything, it is that it is long-term, not short-term, economics that count.</p><p>Scotland’s future includes self-sufficiency in the essentials of renewable energy, water supply and food production at a time of climate crisis. It can become an exporter of products based on such resources, for example, of hydrogen as a key fuel of tomorrow. It has a green future, which has the potential to bring with it a way of life that is of the community and at a distance from the exploitative global economy. It is clear that automation will diminish the value of cheap-labour economies and that the future lies with human services and production at regional and local levels.</p> <a href="https://www.theguardian.com/politics/2021/feb/11/misreading-the-mood-on-scottish-independence">Continue reading...</a>

## Covid-19 has put a major strain on mental health | Letters
 - [https://www.theguardian.com/society/2021/feb/11/covid-19-has-put-a-major-strain-on-mental-health](https://www.theguardian.com/society/2021/feb/11/covid-19-has-put-a-major-strain-on-mental-health)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:11:07+00:00

<p>The pandemic is entrenching and exacerbating pre-existing inequalities, write <strong>Dr Antonis Kousoulis, </strong><strong>Prof Tine Van Bortel </strong>and<strong> </strong><strong>Prof Ann John. </strong>Plus letters from <strong>Dr </strong><strong>Graham Ash</strong> and<strong> </strong><strong>John Culley</strong></p><p>Richard Bentall’s thoughtful piece (<a href="https://www.theguardian.com/commentisfree/2021/feb/09/pandemic-mental-health-problems-research-coronavirus" title="">Has the pandemic really caused a ‘tsunami’ of mental health problems?</a>, 9 February) resonates with our own <a href="https://www.mentalhealth.org.uk/our-work/research/coronavirus-mental-health-pandemic" title="">Mental Health in the Pandemic</a> study. Since March 2020, we have found similar evidence of how unequally UK adults are being affected by the pandemic, which is entrenching and exacerbating pre-existing inequalities. Our data also supports Prof Bentall’s point that economic threats are particularly harmful to people’s mental health.</p><p>Our studies of the pandemic are the latest in a vast body of evidence showing that poverty and unemployment are emotionally devastating. They have long-term, intergenerational effects on individual, family and community wellbeing, and on the functioning of whole societies and economies.</p> <a href="https://www.theguardian.com/society/2021/feb/11/covid-19-has-put-a-major-strain-on-mental-health">Continue reading...</a>

## Businesses offered £20m Brexit fund after border trade disruption
 - [https://www.theguardian.com/politics/2021/feb/11/businesses-offered-20m-brexit-fund-after-border-trade-disruption](https://www.theguardian.com/politics/2021/feb/11/businesses-offered-20m-brexit-fund-after-border-trade-disruption)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:09:16+00:00

<p>Traders offered grant of up to £2,000 each to pay for practical support for importing and exporting</p><p>Small British businesses are being offered access to a £20m <a href="https://www.theguardian.com/politics/eu-referendum">Brexit</a> support fund from the government to help them with new trade rules <a href="https://www.theguardian.com/business/2021/feb/11/half-of-uk-exporters-to-eu-are-having-brexit-difficulties-survey-finds">following border disruption</a> in the first few weeks since the UK left the EU.</p><p>In response to mounting criticism from business leaders over the impact of the new arrangements, the Cabinet Office minister, <a href="https://www.theguardian.com/politics/michaelgove">Michael Gove</a>, said the funding would help businesses adapt to the changes.</p> <a href="https://www.theguardian.com/politics/2021/feb/11/businesses-offered-20m-brexit-fund-after-border-trade-disruption">Continue reading...</a>

## Ten years in jail – Matt Hancock's threat is the distress call of a minister losing his grip | Simon Jenkins
 - [https://www.theguardian.com/commentisfree/2021/feb/11/ten-years-in-jail-matt-hancocks-threat-is-the-distress-call-of-a-minister-losing-his-grip](https://www.theguardian.com/commentisfree/2021/feb/11/ten-years-in-jail-matt-hancocks-threat-is-the-distress-call-of-a-minister-losing-his-grip)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:07:26+00:00

<p>This wild gesture toward would-be holidaymakers has drawn strong criticism from the right. But where is Labour?</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>For the health secretary, Matt Hancock, this week to threaten returning holidaymakers with 10 years in jail was an abuse of office. He was wielding weapons of personal destruction to glamorise his role in the pandemic and to cover his political flank for past mistakes. This is not what the criminal law is for. Hancock’s self-appointed status as Covid’s hysteric-in-chief has gone to his head. Yet when he announced the punishment <a href="https://www.theguardian.com/world/2021/feb/09/covid-travel-rule-breakers-could-face-10-year-jail-term-says-hancock">in the Commons on Tuesday</a>, not a single politician on the left dared call him to account.</p><p>Hancock’s <a href="https://news.sky.com/story/covid-19-10-year-jail-sentences-appropriate-for-lying-at-uk-border-says-transport-secretary-grant-shapps-12213998">actual threat was</a> that “anyone who lies on a passenger locator form … will face a prison sentence of up to 10 years”. To make this seem not a new crime, he apparently introduced it under the 1981 Forgery and Counterfeiting Act. This act was directed at forged banknotes and passports, and its use here would rely on a judge forming the broadest possible definition of “forgery”, as in putting a tick in a wrong box. I am told that this would almost certainly require an order placed before parliament that would be vulnerable to scrutiny and possible delay. Hence Whitehall now saying Hancock was “not creating a new offence”. In that case, why did he announce it as if he was?</p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/ten-years-in-jail-matt-hancocks-threat-is-the-distress-call-of-a-minister-losing-his-grip">Continue reading...</a>

## Saudi Arabia: Loujain al-Hathloul release sparks calls for 'real justice'
 - [https://www.theguardian.com/world/2021/feb/11/saudi-arabia-loujain-al-hathloul-release-sparks-calls-for-real-justice](https://www.theguardian.com/world/2021/feb/11/saudi-arabia-loujain-al-hathloul-release-sparks-calls-for-real-justice)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:06:45+00:00

<p>Sisters of women’s rights activist step up pressure on Saudi leaders a day after her release from prison</p><p>The sisters of the women’s rights activist Loujain al-Hathloul have stepped up pressure on Saudi Arabia’s leaders after <a href="https://www.theguardian.com/world/2021/feb/10/saudi-womens-rights-activist-loujain-al-hathloul-released-from-prison">her release from prison</a>, demanding “real justice” and insisting the human rights campaigner will fight a year travel ban.</p><p>One day after Hathloul’s release from custody – widely billed as a peace offering from Riyadh to the administration of the new US president, Joe Biden – Lina al-Hathloul said her sister would take legal action in the kingdom to overturn restrictions imposed on her as part of her probation.</p> <a href="https://www.theguardian.com/world/2021/feb/11/saudi-arabia-loujain-al-hathloul-release-sparks-calls-for-real-justice">Continue reading...</a>

## Arthritis drug that helps Covid ICU patients has wider benefits, trial finds
 - [https://www.theguardian.com/world/2021/feb/11/arthritis-drug-tocilizumab-found-to-help-covid-icu-patients-has-wider-benefits-trial-finds](https://www.theguardian.com/world/2021/feb/11/arthritis-drug-tocilizumab-found-to-help-covid-icu-patients-has-wider-benefits-trial-finds)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:06:22+00:00

<p>Researchers say tocilizumab could also help patients on general wards and relieve pressure on NHS</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>A rheumatoid arthritis drug previously found to save lives among intensive care patients with Covid could also help those receiving oxygen on general wards and reduce pressure on the NHS, researchers have found.</p><p>A trial called <a href="https://www.icnarc.org/Our-Research/Studies/Remap-Cap/About">Remap-Cap</a> revealed last month that the anti-inflammatory drug <a href="https://www.theguardian.com/world/2021/jan/07/covid-arthritis-drugs-could-help-save-lives-of-seriously-ill--patients-research-finds">tocilizumab cut both the risk of death among Covid patients in intensive care</a> and the length of time patients spent in such units.</p> <a href="https://www.theguardian.com/world/2021/feb/11/arthritis-drug-tocilizumab-found-to-help-covid-icu-patients-has-wider-benefits-trial-finds">Continue reading...</a>

## Meghan wins privacy case against Mail on Sunday
 - [https://www.theguardian.com/uk-news/2021/feb/11/meghan-markle-father-duchess-sussex-mail-on-sunday-wins](https://www.theguardian.com/uk-news/2021/feb/11/meghan-markle-father-duchess-sussex-mail-on-sunday-wins)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:01:25+00:00

<p>Judge gives summary judgment in favour of royal over extracts of letter to estranged father, Thomas Markle</p><ul><li><a href="https://www.theguardian.com/uk-news/2021/feb/11/could-meghan-ruling-stop-the-media-using-leaked-documents">Analysis: could ruling stop media using leaked documents?</a></li></ul><p>The Duchess of Sussex has won her high court privacy case against the Mail on Sunday, hailing her victory as a “comprehensive win” over the newspaper’s “illegal and dehumanising practices”.</p><p>After a two-year legal battle, a judge granted summary judgment in Meghan’s favour over the newspaper’s publication of extracts of a “personal and private” handwritten letter to her estranged father, Thomas Markle.</p> <a href="https://www.theguardian.com/uk-news/2021/feb/11/meghan-markle-father-duchess-sussex-mail-on-sunday-wins">Continue reading...</a>

## UK government's own climate laws may halt roadbuilding plans
 - [https://www.theguardian.com/politics/2021/feb/11/uk-government-own-climate-laws-may-halt-roadbuilding-plans](https://www.theguardian.com/politics/2021/feb/11/uk-government-own-climate-laws-may-halt-roadbuilding-plans)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:00:20+00:00

<p>Analysis: campaigners argue that, as with Heathrow, climate obligations should make £27bn scheme unviable</p><ul><li><a href="https://www.theguardian.com/uk-news/2021/feb/11/27bn-roads-plan-doubt-shapps-overrode-official-advice">£27bn roads plan in doubt after Shapps overrode official advice</a></li></ul><p>The first sign that the government was in serious trouble over the long-mooted expansion of Heathrow airport came in a <a href="https://www.theguardian.com/environment/2019/may/11/climate-emergency-edict-in-uk-to-shape-decision-on-heathrow-expansion-review">little-noticed letter</a> from the Department for Transport in May 2019. In it, a government official acknowledged for the first time that the UK’s obligations under the Paris agreement, and its carbon budgets, would have to be taken into account in infrastructure planning decisions.</p><p>At that point the government had publicly vowed to press ahead with the airport expansion following a <a href="https://www.theguardian.com/environment/2018/jun/25/boris-johnson-criticised-over-decision-to-miss-crunch-heathrow-expansion-vote">parliamentary vote in favour</a> in June 2018. But the letter, to the green campaign group Plan B, showed its decision was vulnerable, as the official wrote: “I can confirm that the department will carefully consider this request [for a review of the airports national policy statement]. As well as giving careful consideration to the net zero report and the declaration of environment and climate emergency … it may be necessary to consider the Committee on Climate Change’s recommended policy approach for aviation … and any relevant decisions taken by the government in the coming months as a result.”</p> <a href="https://www.theguardian.com/politics/2021/feb/11/uk-government-own-climate-laws-may-halt-roadbuilding-plans">Continue reading...</a>

## £27bn roads plan in doubt after Shapps overrode official advice
 - [https://www.theguardian.com/uk-news/2021/feb/11/27bn-roads-plan-doubt-shapps-overrode-official-advice](https://www.theguardian.com/uk-news/2021/feb/11/27bn-roads-plan-doubt-shapps-overrode-official-advice)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 18:00:20+00:00

<p>Exclusive: transport secretary dismissed guidance calling for review of environmental impact</p><ul><li><a href="https://www.theguardian.com/politics/2021/feb/11/uk-government-own-climate-laws-may-halt-roadbuilding-plans">UK government’s own climate laws may halt roadbuilding plans </a></li></ul><p>A £27bn expansion of England’s road network has been thrown into doubt after documents showed the transport secretary, Grant Shapps, overrode official advice to review the policy on environmental grounds, the Guardian can reveal.</p><p>It has been a legal requirement to take into account the environmental impact of such projects since 2014. Shapps appears to have pressed ahead despite the advice of civil servants in his own department.</p> <a href="https://www.theguardian.com/uk-news/2021/feb/11/27bn-roads-plan-doubt-shapps-overrode-official-advice">Continue reading...</a>

## 'Unconscious bias is utter crap': KPMG staff share shock at UK chair's Zoom comments
 - [https://www.theguardian.com/business/2021/feb/11/unconscious-bias-is-utter-crap-kpmg-staff-shock-uk-chair-zoom-comments-bill-michael](https://www.theguardian.com/business/2021/feb/11/unconscious-bias-is-utter-crap-kpmg-staff-shock-uk-chair-zoom-comments-bill-michael)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:58:32+00:00

<p>Accounting firm investigates as more details emerge of meeting where Bill Michael told staff to stop moaning</p><p>New details have emerged of controversial comments by the UK chair of <a href="https://www.theguardian.com/business/kpmg">KPMG</a>, who <a href="https://www.theguardian.com/business/2021/feb/10/kpmg-chair-steps-aside-after-telling-staff-to-stop-moaning-about-covid">has stepped aside</a> while the accounting firm investigates what he said to staff during a virtual meeting.</p><p>A video of the Zoom meeting was published on Thursday in which Bill Michael describes the concept of unconscious bias as being “complete and utter crap for years”.</p> <a href="https://www.theguardian.com/business/2021/feb/11/unconscious-bias-is-utter-crap-kpmg-staff-shock-uk-chair-zoom-comments-bill-michael">Continue reading...</a>

## 'We cannot live like this for ever': readers on booking summer holidays
 - [https://www.theguardian.com/travel/2021/feb/11/we-cannot-live-like-this-forever-readers-on-booking-summer-holidays](https://www.theguardian.com/travel/2021/feb/11/we-cannot-live-like-this-forever-readers-on-booking-summer-holidays)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:56:13+00:00

<p>Four Britons on the pros and cons of taking trips in the UK amid conflicting government advice</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Amid confusing messaging from the government on whether or not to book summer holidays in the UK, Matt Hancock on Thursday asked people to be “patient”, warning that there was still “a lot of uncertainty”. On Tuesday, Hancock <a href="https://www.theguardian.com/world/2021/feb/11/matt-hancock-goes-cool-on-prospects-for-summer-holidays-for-britons">said he had booked a family holiday to Cornwall</a>.</p><p>The Guardian spoke to four Britons about their plans to attempt at least a UK getaway this summer.</p> <a href="https://www.theguardian.com/travel/2021/feb/11/we-cannot-live-like-this-forever-readers-on-booking-summer-holidays">Continue reading...</a>

## Tell us: what are your favourite funny podcasts?
 - [https://www.theguardian.com/tv-and-radio/2021/feb/11/tell-us-what-are-your-favourite-funny-podcasts](https://www.theguardian.com/tv-and-radio/2021/feb/11/tell-us-what-are-your-favourite-funny-podcasts)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:50:34+00:00

<p>We’d like to hear which podcasts have made you laugh during lockdown</p><p>The popularity of podcasts has <a href="https://www.theguardian.com/technology/2021/feb/03/spotify-podcast-popularity-24-percent-growth-subscribers">surged during the pandemic</a>, as listeners look to combat feelings of boredom and isolation. Many of us have also searched for podcasts to make us laugh – from those hosted by comedians, to humorous storytelling series.</p><p>With this in mind, we’d love to hear about your favourite funny podcasts, and why they make you laugh.</p> <a href="https://www.theguardian.com/tv-and-radio/2021/feb/11/tell-us-what-are-your-favourite-funny-podcasts">Continue reading...</a>

## Pfizer vaccine found to give strong immune response to new Covid variants
 - [https://www.theguardian.com/world/2021/feb/11/pfizer-vaccine-strong-response-new-covid-variants](https://www.theguardian.com/world/2021/feb/11/pfizer-vaccine-strong-response-new-covid-variants)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:46:24+00:00

<p>Study finds patients have strong T-cell response after one jab, and second boosts antibody response</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>People who have received two doses of the Pfizer vaccine have been found to have strong T-cell responses against the Kent and South African variants of Covid, suggesting that the vaccine will continue to protect against serious disease in the coming months.</p><p>In the first study to test immune responses against the variants circulating in populations, researchers found that although antibody responses against the new variants were blunted, they may still be high enough to protect most people from becoming infected, after a second dose of vaccine has been given.</p> <a href="https://www.theguardian.com/world/2021/feb/11/pfizer-vaccine-strong-response-new-covid-variants">Continue reading...</a>

## Tell us: how has your pet helped you through lockdown?
 - [https://www.theguardian.com/lifeandstyle/2021/feb/11/tell-us-how-has-your-pet-helped-you-through-lockdown](https://www.theguardian.com/lifeandstyle/2021/feb/11/tell-us-how-has-your-pet-helped-you-through-lockdown)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:45:56+00:00

<p>We would like to hear from you if you have found your pet or pets to be an emotional support during the lockdowns</p><p>Our pets have <a href="https://www.theguardian.com/lifeandstyle/shortcuts/2019/sep/24/he-brought-me-a-tissue-when-i-was-ill-the-moment-readers-realised-their-cat-loves-them">always been a source of comfort</a>: as companions, reasons to go out and exercise, a friendly face to come home to. But in the pandemic, pets have come to mean more to us than ever.</p><p>We would like to hear from you if you have found your pet or pets to be an emotional support during the lockdowns.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/feb/11/tell-us-how-has-your-pet-helped-you-through-lockdown">Continue reading...</a>

## Is the new Wizard of Oz reboot doomed to fail like all the others?
 - [https://www.theguardian.com/film/2021/feb/11/is-the-new-wizard-of-oz-reboot-doomed-to-fail-like-all-the-others](https://www.theguardian.com/film/2021/feb/11/is-the-new-wizard-of-oz-reboot-doomed-to-fail-like-all-the-others)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:43:46+00:00

<p>Numerous film-makers have attempted to recapture the magic of the 1939 musical starring Judy Garland – can Watchmen director Nicole Kassell pull it off?</p><p>News comes this week that Nicole Kassell, award-winning director of the dazzling Watchmen TV show, <a href="https://variety.com/2021/film/news/wonderful-wizard-of-oz-remake-1234904194/">is to oversee a remake of The Wizard of Oz</a>, the classic 1939 musical starring Judy Garland, for New Line Cinema. Well, good luck with that.</p><p>Myriad film-makers have attempted to recapture the magic of Metro-Goldwyn-Mayer’s pioneering movie, but none has really been successful. Sam Raimi is perhaps the most notable recent director to take on the challenge, with Disney’s Oz the Great and Powerful, in 2013. Raimi is an accomplished director of <a href="https://www.youtube.com/watch?v=UHZQEtG8xYo">brutally silly cult fantasy films</a>, but his attempt to present a prequel featuring James Franco as the titular wizard lacked sparkle. <a href="https://www.youtube.com/watch?v=uNKmKOjGUbw">The 1978 musical The Wiz</a> was intended to capitalise on the popularity of Blaxploitation movies and featured a high-profile, all-black cast including Michael Jackson, Diana Ross and Richard Pryor, with music by Luther Vandross and Quincy Jones. Yet it was a critical and commercial bomb, eventually helping to signal the downfall of the very subgenre it had hoped to propel to greater heights.</p> <a href="https://www.theguardian.com/film/2021/feb/11/is-the-new-wizard-of-oz-reboot-doomed-to-fail-like-all-the-others">Continue reading...</a>

## Saudi Arabia's release of Loujain al-Hathloul an overture to Biden
 - [https://www.theguardian.com/world/2021/feb/11/saudi-arabias-release-of-loujain-al-hathloul-an-overture-to-biden](https://www.theguardian.com/world/2021/feb/11/saudi-arabias-release-of-loujain-al-hathloul-an-overture-to-biden)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:42:56+00:00

<p><strong>Analysis: </strong>Mohammed bin Salman views the move as an attempt to engage the new US administration</p><p>As Loujain al-Hathloul <a href="https://www.theguardian.com/world/2021/feb/10/saudi-womens-rights-activist-loujain-al-hathloul-released-from-prison">marked her first day outside prison in nearly three years</a>, Saudi Arabia’s de facto leader, Mohammed bin Salman, was bracing for a reaction from Washington to what amounts to a peace offering on his part.</p><p>Prince Mohammed views the decision to release the women’s rights activist as an attempt to belatedly engage the new administration, whose strident tone on human rights issues in its early weeks of office has all but conditioned a working relationship with Riyadh on righting the wrongs of the Trump years.</p> <a href="https://www.theguardian.com/world/2021/feb/11/saudi-arabias-release-of-loujain-al-hathloul-an-overture-to-biden">Continue reading...</a>

## New prostate cancer scan 'could replace invasive exam and save lives'
 - [https://www.theguardian.com/society/2021/feb/11/new-prostate-cancer-scan-could-replace-invasive-exam-and-save-lives](https://www.theguardian.com/society/2021/feb/11/new-prostate-cancer-scan-could-replace-invasive-exam-and-save-lives)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:41:56+00:00

<p>Prostagram found to be almost twice as effective at detection as standard blood test in trials</p><p>Scientists say they have developed a <a href="https://www.theguardian.com/society/prostate-cancer">prostate cancer</a> scan accurate enough to potentially replace current invasive examination techniques and save thousands of lives each year.</p><p>Prostagram, developed by experts at Imperial College London, employs MRI scanning and is modelled on breast cancer screening, where women are routinely offered a mammogram scan every three years as part of a national programme.</p> <a href="https://www.theguardian.com/society/2021/feb/11/new-prostate-cancer-scan-could-replace-invasive-exam-and-save-lives">Continue reading...</a>

## Google apps feel strain as firm's privacy standoff with Apple drags on
 - [https://www.theguardian.com/technology/2021/feb/11/google-apps-feel-strain-as-firms-privacy-standoff-with-apple-drags-on](https://www.theguardian.com/technology/2021/feb/11/google-apps-feel-strain-as-firms-privacy-standoff-with-apple-drags-on)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:25:40+00:00

<p>Google failure to update more than 80 apps to comply with Apple’s ‘nutrition label’ requirement means users are being told apps are out of date</p><p>Google’s privacy standoff with Apple has lasted so long that even the company’s own apps are complaining about it.</p><p>Since early December, Apple has required any iOS app to include a privacy “nutrition label”, listing all the ways the app uses personal data.</p> <a href="https://www.theguardian.com/technology/2021/feb/11/google-apps-feel-strain-as-firms-privacy-standoff-with-apple-drags-on">Continue reading...</a>

## You can’t fault Matt Hancock’s work ethic, just everything else | John Crace
 - [https://www.theguardian.com/commentisfree/2021/feb/11/you-cant-fault-matt-hancocks-work-ethic-just-everything-else](https://www.theguardian.com/commentisfree/2021/feb/11/you-cant-fault-matt-hancocks-work-ethic-just-everything-else)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:18:30+00:00

<p>The health secretary talks in tongues while explaining why a pandemic is the time to reorganise the NHS </p><p>You can’t fault Matt Hancock’s work ethic. While most of his cabinet colleagues have used the pandemic as an excuse to slide beneath the radar, the health secretary has been front of stage almost every day. Whether it’s been taking Downing Street press conferences, giving coronavirus updates to the Commons, threatening <a href="https://www.theguardian.com/world/2021/feb/09/covid-travel-rule-breakers-could-face-10-year-jail-term-says-hancock">to bang up serial liars for 10 years</a> – Boris Johnson and Michael Gove need to watch out – or freelancing as a spokesperson for tourism in the south-west of England, Hancock has been your man.</p><p>But it turns out that even that workload isn’t enough to keep him fully occupied, as on Thursday he was back in parliament to outline his <a href="https://www.theguardian.com/society/2021/feb/11/matt-hancock-to-publish-plans-to-give-ministers-more-power-over-nhs">plans to completely reorganise the NHS</a>. Perhaps anticipating what was in store, only three backbenchers were in the chamber to hear the statement, but Matt was profoundly unbothered by the lack of an audience. His eyes, which for so long have looked like hollow sockets, regained their sparkle because he was back in his element, living his best life as a junior account executive in a management consultancy. KPMG’s loss has been parliament’s gain. Or possibly vice versa.</p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/you-cant-fault-matt-hancocks-work-ethic-just-everything-else">Continue reading...</a>

## Redwall is coming to Netflix: where to start for kids (and adults)
 - [https://www.theguardian.com/books/booksblog/2021/feb/11/redwall-is-coming-to-netflix-where-to-start-for-kids-and-adults](https://www.theguardian.com/books/booksblog/2021/feb/11/redwall-is-coming-to-netflix-where-to-start-for-kids-and-adults)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 17:15:55+00:00

<p>Brian Jacques’ tale of valiant mice and no-good rats introduced me to fantasy fiction. My daughters love it too, and here are some reasons why everyone should<br /></p><p>If, like me, you are a fan of Brian Jacques, then the news that <a href="https://twitter.com/NXOnNetflix/status/1359492313081393153">Netflix is working on an adaptation of Redwall</a> will have you setting the abbey bells a-ringing in joy. Jacques’ bestselling stories of talking mice, squirrels and otters (the goodies) and rats, foxes and wildcats (the baddies) gave me so much happiness as a child. The first novel, 1986’s Redwall, was my introduction to fantasy: Matthias, a young orphan mouse, seeks a lost sword to see off an evil rat army led by Cluny the Scourge. (“Cluny was a God of War! Cluny was coming nearer!”) Heroism and sacrifice, comedy and evil – all of life is contained in Jacques’ anthropomorphic world.</p><p>After Redwall, Jacques told the story of how Redwall Abbey came to be, in the sequel Mossflower, as Martin the Warrior (another mouse, of course) arrives to save the creatures of the forest from the grip of the wildcats (Tsarmina Greeneyes is a particularly wonderful villain). Mattimeo continued the saga, following Matthias’s son as he is kidnapped by the slaver fox Slagar the Cruel (another excellent baddie; Jacques does villainous animals very well). </p> <a href="https://www.theguardian.com/books/booksblog/2021/feb/11/redwall-is-coming-to-netflix-where-to-start-for-kids-and-adults">Continue reading...</a>

## Doctors warn of ‘tsunami’ of pandemic eating disorders
 - [https://www.theguardian.com/society/2021/feb/11/doctors-warn-of-tsunami-of-pandemic-eating-disorders](https://www.theguardian.com/society/2021/feb/11/doctors-warn-of-tsunami-of-pandemic-eating-disorders)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 16:58:30+00:00

<p>Covid-19 isolation blamed as number of children with anorexia and bulimia in England soars amid fears for similar rise among adults </p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Psychiatrists have warned of a “tsunami” of eating disorder patients amid data showing soaring numbers of people experiencing anorexia and bulimia in England during the pandemic.<br /><br />Dr Agnes Ayton, the chair of the Eating Disorder Faculty at the Royal College of Psychiatrists, said the number of people experiencing problems had risen sharply with conditions such as anorexia thriving in the <a href="https://www.theguardian.com/society/2020/dec/27/covid-poses-greatest-threat-to-mental-health-since-second-world-war">isolation of lockdown</a>.</p><p>She said: “We expect the tsunami [of patients] is still coming. We don’t think it has been and gone.” </p> <a href="https://www.theguardian.com/society/2021/feb/11/doctors-warn-of-tsunami-of-pandemic-eating-disorders">Continue reading...</a>

## One in five going into workplace unnecessarily amid UK Covid crisis
 - [https://www.theguardian.com/world/2021/feb/11/one-in-five-britons-going-into-workplace-unnecessarily-covid](https://www.theguardian.com/world/2021/feb/11/one-in-five-britons-going-into-workplace-unnecessarily-covid)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 16:44:23+00:00

<p>Exclusive: employers are putting workers at risk and increasing infection rates in communities, unions say</p><ul><li><a href="https://www.theguardian.com/world/2021/feb/11/safety-is-very-lax-staff-tell-of-being-forced-into-the-office-during-uks-third-lockdown">‘Safety is very lax’: workers on being called in</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Employers are putting workers at risk and increasing Covid infection rates in communities, unions have said, as research found that as many as one in five people have been going into their workplace unnecessarily.</p><p>The alarming findings came as the government’s outgoing employment adviser, Matthew Taylor, said employers breaking Covid rules should be named, shamed and fined.</p> <a href="https://www.theguardian.com/world/2021/feb/11/one-in-five-britons-going-into-workplace-unnecessarily-covid">Continue reading...</a>

## 'No queen is a loser': why RuPaul's Drag Race is a tender balm in lockdown
 - [https://www.theguardian.com/tv-and-radio/2021/feb/11/rupauls-drag-race-is-a-tender-balm-lockdown-bbc](https://www.theguardian.com/tv-and-radio/2021/feb/11/rupauls-drag-race-is-a-tender-balm-lockdown-bbc)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 16:30:18+00:00

<p>The hit contest transports viewers into a world of big hair, bigger heels and even bigger hearts, and has made me feel less fearful about the world we live in</p><p>When Boris Johnson announced England would be entering its third lockdown in January, I wasn’t entirely sure how I’d get through it. The news hit harder than it had previously. It was colder and darker. Any sliver of novelty in this sad, strange set of circumstances was well and truly gone.</p><p>“At least Drag Race will be back on,” my sister offered at the end of the briefing. And, instantly, I saw a bright pink light at the end of the tunnel. The news that the 13th series of the US show and the second series of the UK edition would be streaming simultaneously felt heaven-sent; a personalised, hand-delivered care package sent from RuPaul Charles to his squirrel friends during their time of need.</p> <a href="https://www.theguardian.com/tv-and-radio/2021/feb/11/rupauls-drag-race-is-a-tender-balm-lockdown-bbc">Continue reading...</a>

## Think bigger: that's the message for Starmer from Biden's bold beginning
 - [https://www.theguardian.com/commentisfree/2021/feb/11/keir-starmer-joe-biden-centrist-policies-us-president](https://www.theguardian.com/commentisfree/2021/feb/11/keir-starmer-joe-biden-centrist-policies-us-president)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 16:09:12+00:00

<p>Centrist policies are unequal to the crises we face, and the new US president’s ambitious priorities acknowledge that </p><p>If you’re on the British left, the last few months in American politics have provided some cheer during a grim period. Trump lost, despite the widespread fear that he would not. The Democrats captured the Senate, despite the system for electing it being biased against them. The American right, so influential around the world, <a href="https://www.theguardian.com/us-news/2021/feb/11/dozens-former-republican-officials-talks-form-anti-trump-party">seems in some disarray</a>.</p><p>More startling still, the American left appears to be exerting an influence on Joe Biden. Its two best-known figures, Bernie Sanders and Alexandria Ocasio-Cortez, are seeing some of their ideas, such as doubling the minimum wage and a <a href="https://www.theguardian.com/us-news/2019/feb/11/green-new-deal-alexandria-ocasio-cortez-ed-markey">Green New Deal</a>, shape Biden’s presidential priorities and possibly his actual policies. Former Sanders advisers have been hired by the administration. And Ocasio-Cortez – <a href="https://www.theguardian.com/us-news/2020/apr/19/joe-biden-alexandria-ocasio-cortez-democrats">who said last year</a> that “in any other country, Joe Biden and I would not be in the same party” – said last month that she was “extraordinarily encouraged” by his government, for its “openness” to the views of radical climate activists.</p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/keir-starmer-joe-biden-centrist-policies-us-president">Continue reading...</a>

## Belinda Carlisle's teenage obsessions: 'I was going to be Anita Ekberg in Rome, but ended up in a band'
 - [https://www.theguardian.com/music/2021/feb/11/belinda-carlisles-teenage-obsessions-i-was-going-to-be-anita-ekberg-in-rome-but-ended-up-in-a-band](https://www.theguardian.com/music/2021/feb/11/belinda-carlisles-teenage-obsessions-i-was-going-to-be-anita-ekberg-in-rome-but-ended-up-in-a-band)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 16:00:18+00:00

<p>The singer recalls the joy of 60s California pop, being enthralled by Fellini’s La Dolce Vita and the Go-Go’s first gig</p><p>I grew up in Burbank in southern California. Music played a huge part in my life. I loved California radio – every summer, I would lie in front of the big speakers at my friend’s house. Her mother would go off to work and we would just sing along to the radio from 9am to 6pm every single day, every summer. When I was about 10, I saved up my babysitting and chore money to buy Aquarius/Let the Sunshine In by the 5th Dimension on 45rpm. It was so joyous and still sounds fresh to this day.</p> <a href="https://www.theguardian.com/music/2021/feb/11/belinda-carlisles-teenage-obsessions-i-was-going-to-be-anita-ekberg-in-rome-but-ended-up-in-a-band">Continue reading...</a>

## Meaty meals and play stop cats killing wildlife, study finds
 - [https://www.theguardian.com/science/2021/feb/11/meaty-meals-and-play-stop-cats-killing-wildlife-study-finds](https://www.theguardian.com/science/2021/feb/11/meaty-meals-and-play-stop-cats-killing-wildlife-study-finds)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 16:00:17+00:00

<p>Millions of pet cats are estimated to kill billions of animals a year but grain-free food can change cat behaviour</p><p>Feeding pet cats meaty food and playing with them to simulate hunting stops them killing wildlife, according to a study.</p><p>Eating grain-free food led to the cats depositing a third fewer mouse and bird corpses on doorsteps, while just five to 10 minutes of play with a toy mouse cut the killing by a quarter.</p> <a href="https://www.theguardian.com/science/2021/feb/11/meaty-meals-and-play-stop-cats-killing-wildlife-study-finds">Continue reading...</a>

## Framing Britney Spears exposes the contradictions of American womanhood | Moira Donegan
 - [https://www.theguardian.com/commentisfree/2021/feb/11/framing-britney-spears-documentary](https://www.theguardian.com/commentisfree/2021/feb/11/framing-britney-spears-documentary)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 15:06:56+00:00

<p>The documentary makes it clear Britney Spears had a real enthusiasm for performing – and that any woman who became that famous would have been treated that badly</p><p>“It’s something that would not have happened to a man in America,” a blond fan says in the opening moments of Framing Britney Spears, a New York Times documentary about Britney Spears. The woman is talking about Spears’ conservatorship, an elaborate legal arrangement, in place since 2009, in which the singer has been declared unfit to manage her own affairs. The conservatorship means that Spears’ life – and her money – are largely under the control of her father, Jamie Spears, who has been appointed conservator by the court. That arrangement has come under scrutiny as fans speculate that Spears’ independence has been needlessly curtailed by a greedy father and a misogynist court system, and that the singer has been trapped in a literal, court-ordained patriarchy. Spears herself has petitioned for the court appoint a different conservator, saying that she is afraid of her father.</p><p> <span>Related: </span><a href="https://www.theguardian.com/commentisfree/2020/aug/26/the-time-has-come-im-joining-team-freebritney-heres-why-you-should-too">The time has come – I’m joining team #FreeBritney. Here’s why you should, too | Arwa Mahdawi</a> </p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/framing-britney-spears-documentary">Continue reading...</a>

## 'My father and I disagree on the purpose of cinema': Anders and Nicolas Winding Refn on film-making
 - [https://www.theguardian.com/film/2021/feb/11/my-father-and-i-disagree-on-the-purpose-of-cinema-anders-and-nicolas-winding-refn-on-film-making](https://www.theguardian.com/film/2021/feb/11/my-father-and-i-disagree-on-the-purpose-of-cinema-anders-and-nicolas-winding-refn-on-film-making)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 15:00:16+00:00

<p>The two Danish directors have known the joy of success and the pain of failure in their respective careers. Just don’t expect them to see eye to eye on anything else</p><p>Nicolas Winding Refn and his father, Anders, are the chalk and cheese of Danish cinema; bound by blood, separated by the movies. Here they are, sat side-by-side in their little Zoom windows, each dialling in from their homes in Copenhagen. “But we are not close at all,” Nicolas explains by way of introduction. “He’s in the suburbs and I’m in the city.” Physically, spiritually, the two are poles apart.</p><p>I have known Refn Jr’s work for years. He is the upstart talent behind <a href="https://www.theguardian.com/film/2011/sep/22/drive-ryan-gosling-film-review">Drive</a>, <a href="https://www.theguardian.com/film/2016/jul/07/neon-demon-review-film-nicolas-winding-refn-elle-fanning-fashion-horror">The Neon Demon</a> and the <a href="https://www.theguardian.com/film/2012/oct/11/pusher-review">Pusher</a> trilogy. He is beguiling, exasperating, almost endlessly watchable. But I am less familiar with 76-year-old Anders, who has steered a quieter course as a <a href="https://www.dfi.dk/en/viden-om-film/filmdatabasen/person/anders-refn">sometime director </a>and a prolific film editor; the sort of safe pair of hands that cleans up the mess made by others. At one stage he explains that he shot his debut feature, Copper, way back in 1976. “My first film was about a policeman. Nicolas’s first film was about a criminal.” He chuckles at the comparison. “So we are like two sides of the same coin.”</p> <a href="https://www.theguardian.com/film/2021/feb/11/my-father-and-i-disagree-on-the-purpose-of-cinema-anders-and-nicolas-winding-refn-on-film-making">Continue reading...</a>

## The impeachment managers reflect a diverse US – unlike the senators they seek to persuade
 - [https://www.theguardian.com/us-news/2021/feb/11/trump-impeachment-managers-diverse-democrats](https://www.theguardian.com/us-news/2021/feb/11/trump-impeachment-managers-diverse-democrats)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 14:44:32+00:00

<p>The nine Democratic prosecutors are men and women with multiple racial and religious identities, compared to a Republican caucus dominated by ageing white men</p><ul><li><a href="https://www.theguardian.com/us-news/series/us-politics-live/latest">US politics – live updates</a></li></ul><p>One side holds up a mirror to America in 2021. The other, not so much.</p><p><a href="https://www.speaker.gov/newsroom/11221-0">The nine Democratic prosecutors</a> at Donald Trump’s second impeachment trial are made up of men and women young and old with multiple racial and religious identities.</p> <a href="https://www.theguardian.com/us-news/2021/feb/11/trump-impeachment-managers-diverse-democrats">Continue reading...</a>

## UK woman who killed disabled son detained in hospital indefinitely
 - [https://www.theguardian.com/uk-news/2021/feb/11/olga-freeman-uk-woman-who-killed-disabled-son-detained-in-hospital-indefinitely](https://www.theguardian.com/uk-news/2021/feb/11/olga-freeman-uk-woman-who-killed-disabled-son-detained-in-hospital-indefinitely)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 14:19:15+00:00

<p>Olga Freeman sentenced at Old Bailey after admitting manslaughter of Dylan, 10, in August 2020</p><p>A woman who killed her disabled 10-year-old son after undergoing a breakdown during the UK’s coronavirus lockdown has been detained in hospital indefinitely.</p><p>Dylan Freeman had been “an indirect victim” of the interruption caused by Covid-19 to normal life, said Mrs Justice Cheema-Grubb as she sentenced his mother, Olga Freeman, 40, at the Old Bailey.</p> <a href="https://www.theguardian.com/uk-news/2021/feb/11/olga-freeman-uk-woman-who-killed-disabled-son-detained-in-hospital-indefinitely">Continue reading...</a>

## What does Covid mean for the future of pandemic movies?
 - [https://www.theguardian.com/film/2021/feb/11/what-does-covid-mean-for-the-future-of-pandemic-movies](https://www.theguardian.com/film/2021/feb/11/what-does-covid-mean-for-the-future-of-pandemic-movies)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 14:00:15+00:00

<p>A year of coronavirus may have dented Hollywood’s enthusiasm for films about deadly outbreaks, but the genre has a history of mutating and returning</p><p>Of all the things this wretched disease has taken from us, the pandemic movie ranks among the least essential. But, for a few years at least, we should brace ourselves to elbow-bump the genre goodbye.</p><p>In 2021, we all know exactly what a pandemic is. And, for the most part, it is nothing like the movies. The undead do not roam the streets. Infected monkeys are not leaping from host to host. The vaccine was created without Brad Pitt having to tiptoe gingerly through a zombie-infested laboratory. As tragic as Covid has been, it has manifested itself mainly in the form of endless drudgery, with everyone stuck at home or following arrows around supermarkets. Unless there emerges a bizarre public hunger for films in which tired parents try to connect their tablets to Google Classroom during a phone call with their boss, it is hard to think that anyone will want to watch the reality of this pandemic reflected back at them.</p> <a href="https://www.theguardian.com/film/2021/feb/11/what-does-covid-mean-for-the-future-of-pandemic-movies">Continue reading...</a>

## The Capitol attack film was brutal. That's why it must be watched | Francine Prose
 - [https://www.theguardian.com/commentisfree/2021/feb/11/the-capitol-attack-film-was-brutal-thats-why-it-must-be-watched](https://www.theguardian.com/commentisfree/2021/feb/11/the-capitol-attack-film-was-brutal-thats-why-it-must-be-watched)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 13:42:06+00:00

<p>We had been spared the most graphic moments, and those scenes are a clear reminder of the Donald Trump presidency</p><p>When the film of the 6 January Capitol insurrection was shown to the US Senate on the first day of Donald Trump’s second impeachment trial, the TV station I watched ran a warning in the upper right-hand corner. <em>Explicit video</em>. After a few minutes, I began to think that <em>explicit</em> was an understatement, that we should have been warned that what we’d be seeing was brutal.</p><p>In the aftermath of the 6 January riot, I – like many Americans, I imagine –watched plenty of footage of the riot. It was horrifying, for obvious reasons, and also mysterious, because I found it hard to understand exactly what, in addition to Donald Trump’s urging and the fake claims of a stolen election, had unleashed such murderous rage in so many people.</p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/the-capitol-attack-film-was-brutal-thats-why-it-must-be-watched">Continue reading...</a>

## Ghetts: Conflict of Interest review | Alexis Petridis's album of the week
 - [https://www.theguardian.com/music/2021/feb/11/ghetts-conflict-of-interest-review](https://www.theguardian.com/music/2021/feb/11/ghetts-conflict-of-interest-review)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 13:32:16+00:00

<p><strong>(Warner Records)</strong><br />Big-label backing and unusual, beautiful arrangements should finally propel Ghetts, long a critic’s favourite, into the big time<br /></p><p>The third album by Ghetts is a marathon listen – digesting it in one sitting takes well over an hour – but barely three minutes pass before he mentions that it’s being released by Warner, the venerable major-label home of Madonna, Stevie Nicks and one of Conflict of Interest’s umpteen guest stars, <a href="https://www.theguardian.com/music/ed-sheeran">Ed Sheeran</a>. The question of whether UK hip-hop needs major labels to succeed is an intriguing one – a few tracks in, you hear Skepta, on particularly fierce form, proudly explaining how he told the established music industry to do one. But Ghetts flaunting his new deal is understandable. It comes, as he puts it, after “15 years’ hard work, no breaks”.</p> <a href="https://www.theguardian.com/music/2021/feb/11/ghetts-conflict-of-interest-review">Continue reading...</a>

## Taylor Swift to start releasing new versions of her first six albums
 - [https://www.theguardian.com/music/2021/feb/11/taylor-swift-releases-new-versions-of--first-six-albums](https://www.theguardian.com/music/2021/feb/11/taylor-swift-releases-new-versions-of--first-six-albums)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 13:23:04+00:00

<p>Rerecordings follow a battle over the sale of the master tapes and will be preceded by the single Love Story (Taylor’s Version)</p><p><a href="https://www.theguardian.com/music/taylor-swift">Taylor Swift</a> has begun her long-teased plan to release rerecorded versions of her first six albums after the master recordings were sold by her former record label. Love Story (Taylor’s Version) will be released on 12 February. The original single, which reached No 2 in the UK in 2008, was featured on Swift’s second album, Fearless.</p><p><a href="https://twitter.com/GMA/status/1359853262384553986">Appearing on Good Morning America</a>, Swift said she had finished re-recording a new version of the album, to be known as Fearless (Taylor’s Version). It will contain 26 songs, including six previously unreleased songs that she wrote between the ages of 16 and 18.</p> <a href="https://www.theguardian.com/music/2021/feb/11/taylor-swift-releases-new-versions-of--first-six-albums">Continue reading...</a>

## HMS Cavalier and a rainbow pool: Thursday's best photos
 - [https://www.theguardian.com/uk-news/gallery/2021/feb/11/indias-missing-and-a-rainbow-pool-thursdays-best-photos](https://www.theguardian.com/uk-news/gallery/2021/feb/11/indias-missing-and-a-rainbow-pool-thursdays-best-photos)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 13:08:43+00:00

<p>The Guardian’s picture editors select photo highlights from around the world</p> <a href="https://www.theguardian.com/uk-news/gallery/2021/feb/11/indias-missing-and-a-rainbow-pool-thursdays-best-photos">Continue reading...</a>

## Empire shaped Ireland's past. A century after partition, it still shapes our present | Michael D Higgins
 - [https://www.theguardian.com/commentisfree/2021/feb/11/empire-ireland-century-partition-present-britain-history](https://www.theguardian.com/commentisfree/2021/feb/11/empire-ireland-century-partition-present-britain-history)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 13:00:21+00:00

<p>Only by remembering complex, uncomfortable aspects of Britain and Ireland’s shared history can we forge a better future<br /><br /></p><ul><li>Michael D Higgins is president of Ireland</li></ul><p>Ireland is currently engaged in a process of recalling the transformative events of a century ago that culminated in partition of the island. Six of the nine Ulster counties remained in the United Kingdom and the rest of the island opted for self-determination and what would become an independent republic.</p><p>As president of Ireland, I have been engaging with our citizens in an exercise of ethical remembering of this period. This is not only to allow us to understand more fully the complexities of those times. It is also to allow us to recognise the reverberations of that past for our societies today and for our relationships with each other and our neighbours.</p> <a href="https://www.theguardian.com/commentisfree/2021/feb/11/empire-ireland-century-partition-present-britain-history">Continue reading...</a>

## Can’t Get You Out of My Head review – Adam Curtis's 'emotional history' is dazzling
 - [https://www.theguardian.com/tv-and-radio/2021/feb/11/cant-get-you-out-of-my-head-review-adam-curtis-bbc](https://www.theguardian.com/tv-and-radio/2021/feb/11/cant-get-you-out-of-my-head-review-adam-curtis-bbc)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 13:00:14+00:00

<p>Examining the power structures and political intrigue that have shaped our world, the filmmaker’s new BBC documentary series is a dense, ambitious triumph </p><p>Can’t Get You Out of My Head: An Emotional History of the Modern World did – sorry – leave me quite emotional. I cannot – sorry, very sorry, again – get it out of my head.</p><p>Adam Curtis’s new series of films (released en masse today on BBC iPlayer) are a dazzling, overwhelming experience. The six hour-and-bit long documentaries set out to tell no more and no less than how we got from there to here. “We” being largely the west, both under our own political, industrial and sociocultural steam and as influenced and inextricably linked to China and Russia, “there” being roughly the mid-20th century and “here” being the polarised, tech-crunched, fragile, teetering edifice we call “now”.</p> <a href="https://www.theguardian.com/tv-and-radio/2021/feb/11/cant-get-you-out-of-my-head-review-adam-curtis-bbc">Continue reading...</a>

## Irish president attacks 'feigned amnesia' over British imperialism
 - [https://www.theguardian.com/world/2021/feb/11/irish-president-michael-d-higgins-critiques-feigned-amnesia-over-british-imperialism](https://www.theguardian.com/world/2021/feb/11/irish-president-michael-d-higgins-critiques-feigned-amnesia-over-british-imperialism)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 13:00:14+00:00

<p>Michael D Higgins accuses academics and journalists of turning blind eye to impact of colonialism</p><ul><li><a href="https://www.theguardian.com/commentisfree/2021/feb/11/empire-ireland-century-partition-present-britain-history">Michael D Higgins: Empire shapes our present</a></li></ul><p><a href="https://www.theguardian.com/world/ireland">Ireland</a>’s president, Michael D Higgins, has made a sharp critique of British imperialism and the “feigned amnesia” of academics and journalists who refuse to address its legacy.</p><p><a href="https://www.theguardian.com/commentisfree/2021/feb/11/empire-ireland-century-partition-present-britain-history">Writing in the Guardian, Higgins accuses</a> unnamed academic and media organisations of turning a blind eye to the devastating impact of colonialism not just in Ireland but across the world.</p> <a href="https://www.theguardian.com/world/2021/feb/11/irish-president-michael-d-higgins-critiques-feigned-amnesia-over-british-imperialism">Continue reading...</a>

## 'Love’s labours should be lost': Maria Stepanova, Russia's next great writer
 - [https://www.theguardian.com/books/2021/feb/11/maria-stepanova-russia-in-memory-of-memory](https://www.theguardian.com/books/2021/feb/11/maria-stepanova-russia-in-memory-of-memory)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 12:25:18+00:00

<p>The Muscovite’s work is arriving in English this year in three books of remarkable memoir, poems and essays that, she explains, reach for ‘the truth of the past’<br /></p><p>Years ago, Maria Stepanova visited the United States Holocaust Memorial Museum in Washington DC to do research for a book she would end up working on for 30 years. After telling him of her plan, the museum adviser replied: “Ah. One of those books where the author travels around the world in search of his or her roots – there are plenty of those now.” “Yes,” replied Stepanova. “And now there will be one more.”</p><p><a href="https://guardianbookshop.com/in-memory-of-memory-9781913097530.html">In Memory of Memory</a> is an astounding collision of personal and cultural history, and Stepanova’s first full-length book published in English, translated by Sasha Dugdale. It is a remarkable work from a writer who has won Russia’s most prestigious honours (including the Big Book award for In Memory of Memory, the NOS literary prize, the Andrei Bely prize and a Joseph Brodsky fellowship); a writer who will likely be spoken about in the same breath as Poland’s <a href="https://www.theguardian.com/books/2019/oct/10/olga-tokarczuk-the-dreadlocked-feminist-winner-the-nobel-needed">Olga Tokarczuk</a> and Belarus’s <a href="https://www.theguardian.com/books/2019/oct/12/svetlana-alexievich-interview-last-witnesses">Svetlana Alexievich</a> in years to come. But 2021 is the year of Stepanova: in addition to In Memory of Memory, her poetry collection <a href="https://www.bloodaxebooks.com/ecs/product/war-of-the-beasts-and-the-animals-1241">War of the Beasts and the Animals</a>, and a collection of essays and poems titled <a href="http://cup.columbia.edu/book/the-voice-over/9780231196178">The Voice Over</a>, will also be published in English this year. “I feel a bit funny about it,” she jokes, from her dacha outside Moscow. “Isn’t it a bit of an overkill?”</p> <a href="https://www.theguardian.com/books/2021/feb/11/maria-stepanova-russia-in-memory-of-memory">Continue reading...</a>

## The 20 best Frankenstein films – ranked!
 - [https://www.theguardian.com/film/2021/feb/11/the-20-best-frankenstein-films-ranked](https://www.theguardian.com/film/2021/feb/11/the-20-best-frankenstein-films-ranked)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 12:02:35+00:00

<p>With Emma Stone lined up to play a female version of the monster in Poor Things, we rate a century’s worth of cinema inspired by Shelley’s novel</p><p>Doctor Stein injects “DNA solution” into an African American multiple amputee (he is a Vietnam veteran), but there is an “RNA problem” and things go horribly wrong. This <a href="https://www.theguardian.com/film/2018/jan/11/blaxploitation-shaft-foxy-brown-film">Blaxploitation</a> attempt to do for Frankenstein what Blacula did for Dracula edges into this list only because its sheer ineptitude entertained me more than competently filmed snoozefests such as Victor Frankenstein and I, Frankenstein.</p> <a href="https://www.theguardian.com/film/2021/feb/11/the-20-best-frankenstein-films-ranked">Continue reading...</a>

## Valentine’s feasts: 12 romantic meal ideas – recommended by readers
 - [https://www.theguardian.com/lifeandstyle/2021/feb/11/valentines-feasts-12-romantic-meal-ideas-recommended-by-readers](https://www.theguardian.com/lifeandstyle/2021/feb/11/valentines-feasts-12-romantic-meal-ideas-recommended-by-readers)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 11:30:12+00:00

<p>Trying to impress your partner? Get organised in the kitchen. From scallops with chorizo to lemon posset, via molten chocolate cake, here are some great treats to try</p><p>I love to make prawn linguine for a special night in. After frying chopped garlic and chilli, add a pack or two of fresh tomatoes and cook them down into a thick, fresh sauce. While doing this, marinate raw prawns in chilli, lemon juice, garlic and olive oil and leave to rest. Once the sauce is thick, fry the prawns in a hot griddle pan and cook the linguine until al dente. Mix it all together with fresh parsley and lemon juice – <em>voilà</em>! <strong>Sally Dickens, </strong><strong>economic development officer, London </strong></p> <a href="https://www.theguardian.com/lifeandstyle/2021/feb/11/valentines-feasts-12-romantic-meal-ideas-recommended-by-readers">Continue reading...</a>

## Tell us: what is it like working for your company under lockdown?
 - [https://www.theguardian.com/business/2021/feb/11/tell-us-what-is-it-like-working-for-your-company-under-lockdown](https://www.theguardian.com/business/2021/feb/11/tell-us-what-is-it-like-working-for-your-company-under-lockdown)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 11:29:43+00:00

<p>A KPMG chairman has resigned after telling staff to ‘stop moaning’ about Covid. We would like to hear workers’ views and experiences at their own companies</p><p>Bill Michael, chairman of the accounting giant KPMG, is to step aside after <a href="https://www.theguardian.com/business/2021/feb/10/kpmg-chair-steps-aside-after-telling-staff-to-stop-moaning-about-covid">making controversial remarks to his staff</a> in a virtual meeting, telling them to “stop moaning” about Covid and not to play the “victim card”.</p><p>We would like to hear from staff about their experiences working for their own firms in recent months.</p> <a href="https://www.theguardian.com/business/2021/feb/11/tell-us-what-is-it-like-working-for-your-company-under-lockdown">Continue reading...</a>

## Family lockdown activities for half-term: chosen by readers
 - [https://www.theguardian.com/travel/2021/feb/11/family-lockdown-activities-for-half-term-chosen-by-readers](https://www.theguardian.com/travel/2021/feb/11/family-lockdown-activities-for-half-term-chosen-by-readers)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 11:00:13+00:00

<p>Travelling the world one dinner at a time is proving popular, but readers also have outdoor ideas involving oaks, fairies and common-or-garden weeds</p><p>Noticing the enormous oak trees in the local woods started a conversation about how old they were. Arm-spanning the trunks to measure the girth (your arm span is the same as your height), we used <a href="http://www.wbrc.org.uk/atp/Estimating%20Age%20of%20Oaks%20-%20Woodland%20Trust.pdf">this table</a> from the Woodland Trust to work out their age. We began to talk about the events these trees had lived through and created stories about their lives. The planes that flew over in the second world war; the disappearance of the red squirrel and the arrival of the grey; how fashions and land use have changed since they were an acorn. Fuel for inquisitive imaginations!<br /><strong>Vanessa Wright</strong></p> <a href="https://www.theguardian.com/travel/2021/feb/11/family-lockdown-activities-for-half-term-chosen-by-readers">Continue reading...</a>

## 'It makes me feel like a kid': readers' pictures of the Storm Darcy snow
 - [https://www.theguardian.com/world/2021/feb/10/it-makes-me-feel-like-a-kid-readers-pictures-of-the-storm-darcy-snow](https://www.theguardian.com/world/2021/feb/10/it-makes-me-feel-like-a-kid-readers-pictures-of-the-storm-darcy-snow)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 10:41:39+00:00

<p>We asked UK readers to send in photos of snow brought by Storm Darcy </p><p>Heavy snowfall, as a result of <a href="https://www.theguardian.com/uk-news/gallery/2021/feb/08/storm-darcy-hits-england-in-pictures">Storm Darcy</a>, has led to picturesque scenes across the UK. We asked readers to get in touch to show us how they’ve been enjoying the snowy weather. We’ve featured some of them here. </p><p>If you would like to share your photos, you can do so by clicking <a href="https://guardiannewsandmedia.formstack.com/forms/snow_in_the_uk_feb_21">here</a>.</p> <a href="https://www.theguardian.com/world/2021/feb/10/it-makes-me-feel-like-a-kid-readers-pictures-of-the-storm-darcy-snow">Continue reading...</a>

## Tell us: have you booked a summer holiday in the UK?
 - [https://www.theguardian.com/world/2021/feb/11/tell-us-have-you-booked-a-summer-holiday-in-the-uk](https://www.theguardian.com/world/2021/feb/11/tell-us-have-you-booked-a-summer-holiday-in-the-uk)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 10:00:58+00:00

<p>We would like to hear what you think about the change in travel advice from the government</p><p>More than a week ago Matt Hancock revealed that he has already booked a family break in Cornwall and hoped we would have a “<a href="https://www.theguardian.com/politics/video/2021/jan/18/great-british-summer-matt-hancock-cautions-against-booking-holidays-abroad-video">happy and free great British summer</a>”. On Wednesday, Boris Johnson warned that it was <a href="https://www.theguardian.com/world/2021/feb/10/too-early-to-book-summer-holidays-even-in-uk-says-boris-johnson">too early</a> to be thinking about booking a summer holiday, even in the UK. </p><p><a href="https://www.theguardian.com/world/live/2021/feb/11/coronavirus-live-news-two-masks-substantially-reduce-exposure-italy-to-reopen-ski-resorts?page=with:block-6024e1bc8f08833364512f00#block-6024e1bc8f08833364512f00">On Thursday morning</a>, Hancock told Sky News: “We are doing everything we can to make sure people can have that holiday in the summer.” He added: “I do understand the yearning for certainty, but certainty is hard in a pandemic.”</p> <a href="https://www.theguardian.com/world/2021/feb/11/tell-us-have-you-booked-a-summer-holiday-in-the-uk">Continue reading...</a>

## 'We are desperate for human contact': people breaking lockdown for sex
 - [https://www.theguardian.com/lifeandstyle/2021/feb/11/we-are-desperate-for-human-contact-the-people-breaking-lockdown-to-have-sex](https://www.theguardian.com/lifeandstyle/2021/feb/11/we-are-desperate-for-human-contact-the-people-breaking-lockdown-to-have-sex)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 10:00:45+00:00

<p>For nearly 12 months, single people have been unable to form new relationships. With their chances to start a family or find love slipping away, many are now ignoring the rules</p><p>Last summer, shortly after the first lockdown was relaxed enough to allow strangers to meet outdoors, Rosie, 35, an editor based in London, joined a man for a first date on Hampstead Heath. “He said: ‘I brought some wine with me, but the glasses are in my flat, round the corner.’ I’d only met him for an hour. Even in normal times, I wouldn’t be up for that.” She can’t be entirely sure if he was suggesting an illicit drink or a very quick-off-the-bat shag, but it wasn’t a dilemma, at least. “Maybe people’s pheromones have gone funny,” Rosie says, “or maybe I secretly have Covid and can’t smell anyone properly, but I’ve had more smouldering frisson at the supermarket than I have on a date. I’ve had sex just four times since March.”</p><p>For nearly a year, give or take the odd month, the rules introduced to fight the spread of coronavirus mean that, in England, sex between single people, or established couples who don’t cohabit, has in effect been either illegal, or against regulations, or only allowed outdoors. To give that a sense of scale, 40% of people – rising to 71% among 16- to 29-year-olds – <a href="https://www.ons.gov.uk/peoplepopulationandcommunity/populationandmigration/populationestimates/bulletins/populationestimatesbymaritalstatusandlivingarrangements/2019">don’t live in a couple</a>.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/feb/11/we-are-desperate-for-human-contact-the-people-breaking-lockdown-to-have-sex">Continue reading...</a>

## Bulldoze the high street and build a giant park: is Stockton the future of Britain?
 - [https://www.theguardian.com/artanddesign/2021/feb/11/is-this-the-future-for-britain-stockton-on-tees-park-high-street](https://www.theguardian.com/artanddesign/2021/feb/11/is-this-the-future-for-britain-stockton-on-tees-park-high-street)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 08:00:07+00:00

<p>What do you do when M&amp;S, Debenhams and New Look are all gone? Knock down the shopping centre and replace it with a riverside oasis. Could the ‘visionary’ plan of Stockton-on-Tees spark a revolution?</p><p>An empty Debenhams, a shuttered Marks &amp; Spencer, an abandoned New Look: the <a href="https://www.theguardian.com/business/2020/jan/16/stockton-on-tees-high-street-online-as-debenhams-closes">town centre of Stockton-on-Tees</a> has suffered a similar fate to countless high streets up and down the UK, struggling to survive in the online shopping, Covid-stricken era. But, while some towns scramble to convert empty department stores into flats, or fill vacant shops with community pop-ups and urban farms, Stockton Council has come up with an altogether bolder proposition for the post-retail age. It plans to demolish half the high street and replace it with a park.</p><p>“The government asked for ‘transformational’ proposals for our high streets,” says councillor Nigel Cooke, cabinet member for regeneration. “If this is not transformational, I don’t know what is.” If the plans go ahead, the project will see an ailing shopping arcade ripped up and replaced with a riverside park three times the size of Trafalgar Square, providing grandstand views across a bucolic scene of rowing, sailing and waterside promenading along the Tees. As retail continues to retreat, might our future high streets embrace the great outdoors?</p> <a href="https://www.theguardian.com/artanddesign/2021/feb/11/is-this-the-future-for-britain-stockton-on-tees-park-high-street">Continue reading...</a>

## I found peace in an unexpected corner of the internet: nun Twitter
 - [https://www.theguardian.com/lifeandstyle/2021/feb/10/religious-twitter-nuns-monks-bishops-rabbis](https://www.theguardian.com/lifeandstyle/2021/feb/10/religious-twitter-nuns-monks-bishops-rabbis)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 07:00:05+00:00

<p>Religious Twitter brings together nuns, monks, bishops and rabbis, and it may have something to teach us, too</p><p>There is a Rumi poem – it is my favourite. “Out beyond ideas of wrongdoing and rightdoing,” <a href="https://onbeing.org/poetry/a-great-wagon/">writes the 13th-century mystic</a>, “there is a field. I’ll meet you there.”</p><p>I feel this way about religious Twitter.</p> <a href="https://www.theguardian.com/lifeandstyle/2021/feb/10/religious-twitter-nuns-monks-bishops-rabbis">Continue reading...</a>

## Some people are on the pitch! Sports photos with a twist – in pictures
 - [https://www.theguardian.com/artanddesign/gallery/2021/feb/11/some-people-are-on-the-pitch-sports-photos-with-a-twist-in-pictures-pelle-cass](https://www.theguardian.com/artanddesign/gallery/2021/feb/11/some-people-are-on-the-pitch-sports-photos-with-a-twist-in-pictures-pelle-cass)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 07:00:05+00:00

<p>Combining thousands of images, Pelle Cass’s photographs of tennis, basketball and more perfectly evoke the chaos and physicality of sport </p> <a href="https://www.theguardian.com/artanddesign/gallery/2021/feb/11/some-people-are-on-the-pitch-sports-photos-with-a-twist-in-pictures-pelle-cass">Continue reading...</a>

## London's Chinatown gets ready for the year of the ox – in pictures
 - [https://www.theguardian.com/uk-news/gallery/2021/feb/11/londons-chinatown-gets-ready-for-the-year-of-the-ox-in-pictures](https://www.theguardian.com/uk-news/gallery/2021/feb/11/londons-chinatown-gets-ready-for-the-year-of-the-ox-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 07:00:04+00:00

<p>The Chinese lunar new year falls on Friday, but with the parade and festivities cancelled this year because of coronavirus, London’s Chinatown is deserted. Martin Godwin takes a look around the quiet streets</p> <a href="https://www.theguardian.com/uk-news/gallery/2021/feb/11/londons-chinatown-gets-ready-for-the-year-of-the-ox-in-pictures">Continue reading...</a>

## 10 songs that bring back memories of my travels: Tom Ravenscroft's playlist
 - [https://www.theguardian.com/travel/2021/feb/11/tom-ravenscroft-playlist-10-songs-that-bring-back-memories-of-my-travels](https://www.theguardian.com/travel/2021/feb/11/tom-ravenscroft-playlist-10-songs-that-bring-back-memories-of-my-travels)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 06:30:04+00:00

<p>From Sheffield to Tokyo via New York and rural France, the DJ recalls his adventures with friends and family – and the music that accompanied them</p><p>We didn’t travel as kids, partly because my dad hated flying and also because it was festival season and his job meant our summer holidays were spent being dragged off to muddy fields. It sounds like I’m complaining. I am a bit. This was long before it was commonplace to see kids at festival: we got cold, and drunk people pointed at us. On the odd occasion we went on “holiday”, we were squashed into a car and driven around Europe with seemingly no real destination. We once drove all the way to Germany to see where our lawnmower was made. The only joy in these journeys were the mixtapes my dad would spend weeks painstakingly preparing for the journey. A few records for the kids and lots for him. Lonnie Donegan was one of the few tracks on there we all loved. Many years later we got to see him play the Glastonbury festival. I stood in awe. He did a weird amount of encores, double figures.</p> <a href="https://www.theguardian.com/travel/2021/feb/11/tom-ravenscroft-playlist-10-songs-that-bring-back-memories-of-my-travels">Continue reading...</a>

## 'Pure, liquid hope': what the vaccine means to me as a GP
 - [https://www.theguardian.com/society/2021/feb/11/pure-liquid-hope-what-coronavirus-covid-vaccine-means-to-a-gp-doctor](https://www.theguardian.com/society/2021/feb/11/pure-liquid-hope-what-coronavirus-covid-vaccine-means-to-a-gp-doctor)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 06:00:04+00:00

<p>For almost a year our small clinic has been struggling with the horrors of the coronavirus pandemic. So being able to give our staff and most vulnerable patients their first doses of the vaccine has been a real turning point</p><p>During the week I work in a small, inner-city GP practice in Edinburgh with 14 staff, caring for almost 4,000 patients. Before the pandemic, I used to see 25-30 people in face-to-face appointments every day. A year into the pandemic, the need out there is the same, but my GP colleagues and I manage more like five or six face-to-face (or mask-to-mask) consultations, a home visit or two, and the remainder on the phone or through video calls. It’s not the best way to practise medicine, but for the moment, it’s the best we have.</p><p>The first I heard of the vaccine rollout was back in October, when our practice manager received an email from the health board asking if we would have capacity to vaccinate the over-80s among our patients. We said yes, of course: in the past year we’ve had four patients die of Covid-19, three of them over 80.</p> <a href="https://www.theguardian.com/society/2021/feb/11/pure-liquid-hope-what-coronavirus-covid-vaccine-means-to-a-gp-doctor">Continue reading...</a>

## The coup in Myanmar and a fight for democracy – podcast
 - [https://www.theguardian.com/news/audio/2021/feb/11/the-coup-in-myanmar-and-a-fight-for-democracy-podcast](https://www.theguardian.com/news/audio/2021/feb/11/the-coup-in-myanmar-and-a-fight-for-democracy-podcast)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-02-11 03:00:00+00:00

<p>A military coup in Myanmar has removed civilian leader Aung San Suu Kyi and sent tens of thousands of protesters onto the streets. Rebecca Ratcliffe describes how the country risks turning back the clock to the decades of military dictatorship and economic isolation</p><p>Protesters in Myanmar have taken to the streets in huge numbers this week following a <a href="https://www.theguardian.com/world/2021/feb/01/aung-san-suu-kyi-and-other-figures-detained-in-myanmar-raids-says-ruling-party">military coup</a> that removed the civilian leader, Aung San Suu Kyi. An estimated 100,000 people gathered in Yangon on Wednesday, a day after police instigated the <a href="https://www.theguardian.com/global-development/2021/feb/09/myanmar-protesters-curfew-junta-demonstrators-army">most violent scenes yet</a>. </p><p>The Guardian’s south-east Asia correspondent, <strong>Rebecca Ratcliffe</strong>,<strong> </strong>tells <strong>Rachel Humphreys </strong>that the coup once again returns Myanmar to military rule, a decade after it began withdrawing to civilian politics. The most recent elections in November 2020 had given the party of Aung San Suu Kyi a mandate to continue ruling but the military disputed them, without evidence, as fraudulent. </p> <a href="https://www.theguardian.com/news/audio/2021/feb/11/the-coup-in-myanmar-and-a-fight-for-democracy-podcast">Continue reading...</a>

