# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What All Liberals Are Like - According To Conservatives
 - [https://www.youtube.com/watch?v=4l1UPmrRyI4](https://www.youtube.com/watch?v=4l1UPmrRyI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-02-11 00:00:00+00:00

Grab your Cognibiotics at https://cognibiotics.com/jp
Use code "JPDEAL10" for 10% off

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

In this video you’ll see what all liberals are like, according to conservatives. Everyone on the right knows that everyone on the left is exactly like this. Being able to accurately assess a whole group without individual new ones is the key to intelligence.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

