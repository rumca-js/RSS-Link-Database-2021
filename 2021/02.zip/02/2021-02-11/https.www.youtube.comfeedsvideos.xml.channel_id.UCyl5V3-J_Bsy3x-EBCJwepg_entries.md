# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Breaking: GINA CARANO HAS A MIND OF HER OWN AND MUST BE STOPPED!!!
 - [https://www.youtube.com/watch?v=98m3_ysn7PY](https://www.youtube.com/watch?v=98m3_ysn7PY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-11 00:00:00+00:00

Gina Carano has been fired from Lucasfilm for an incredibly justifiable and not at all ridiculous reason: MEMES WE DON'T LIKE!

