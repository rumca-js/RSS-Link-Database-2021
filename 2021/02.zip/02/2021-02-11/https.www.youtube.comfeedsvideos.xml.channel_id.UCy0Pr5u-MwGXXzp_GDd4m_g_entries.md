# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## I have a sore throat
 - [https://www.youtube.com/watch?v=6owucn6yQ0k](https://www.youtube.com/watch?v=6owucn6yQ0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-02-11 00:00:00+00:00

Don't mean to panic any one but my throat is a little sore. Thank you to Honey for sponsoring this video! Get it for free today ▸ https://www.joinhoney.com/julie

Also! Consider checking out my Patreon for a look at behind the scenes videos, bloopers as well as Q&As with yours truly: https://www.patreon.com/julienolke

Written by: Sam Larson
Acting: Julie Nolke
Editing: Alec Mckay

