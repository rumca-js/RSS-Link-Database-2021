# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Niemieccy politycy i naukowcy naginali fakty, by przedłużyć lockdown!
 - [https://www.youtube.com/watch?v=PYOdukSjqFI](https://www.youtube.com/watch?v=PYOdukSjqFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-02-12 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze strony: 
wikipedia.org / Freud - http://bit.ly/3qmKnnu
---------------------------------------------------------------
🎥Wideo - wykorzystano fragmenty ze strony
eswi.org - http://bit.ly/3tVKuZ2
---------------------------------------------------------------
✅źródła:
1. https://bit.ly/3rNz9Zs
2. http://bit.ly/2OprQIQ
3. https://bit.ly/3pk9gOZ
4. http://bit.ly/3rT1f5z
5. http://bit.ly/3tVKuZ2
-------------------------------------------------------------
💡 Tagi: #Niemcy #lockdown
--------------------------------------------------------------

## Dr Zbigniew Dylewski: Krytyka Wielkiego Resetu jest kołtuństwem! Polemika
 - [https://www.youtube.com/watch?v=gQCBx8zNAlM](https://www.youtube.com/watch?v=gQCBx8zNAlM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-02-11 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
wikipedia.org / Światowe Forum Ekonomiczne
http://bit.ly/3aaZMl7
---
wikipedia.org / Andrzej Błaszczak
http://bit.ly/3aausTe
---------------------------------------------------------------
✅źródła:
1. https://bit.ly/371NYiR
2. https://bit.ly/35R3IoE
3. https://bit.ly/2Yo7Bx7
4. https://bit.ly/3d1DbsM
-------------------------------------------------------------
💡 Tagi: #Schwab #Reset
--------------------------------------------------------------

