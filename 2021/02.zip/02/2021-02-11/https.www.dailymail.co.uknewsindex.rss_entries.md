# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Clarifications and corrections
 - [https://www.dailymail.co.uk/home/article-9240107/Clarifications-corrections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/article-9240107/Clarifications-corrections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2021-02-11 02:56:33+00:00

To report an inaccuracy, please email corrections @mailonline.co.uk. To make a formal complaint under IPSO rules please go to www.mailonline .co.uk/readerseditor.

