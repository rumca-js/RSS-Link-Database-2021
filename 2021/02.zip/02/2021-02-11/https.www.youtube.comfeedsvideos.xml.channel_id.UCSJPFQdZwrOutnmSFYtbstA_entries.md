# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Girl Who Wouldn't Back Down
 - [https://www.youtube.com/watch?v=ha9gO_i8B-g](https://www.youtube.com/watch?v=ha9gO_i8B-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-02-11 00:00:00+00:00

Let me tell you a story about a woman who stood up to the mob.

(This is not an endorsement of anything she has said on social media, it's simply an observation on how she's been treated.)

