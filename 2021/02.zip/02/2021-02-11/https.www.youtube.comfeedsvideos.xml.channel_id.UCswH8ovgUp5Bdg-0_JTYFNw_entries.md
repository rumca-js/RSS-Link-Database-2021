# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Before you use a DATING APP - WATCH THIS!!!
 - [https://www.youtube.com/watch?v=x_-dmPUf7Fk](https://www.youtube.com/watch?v=x_-dmPUf7Fk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-02-12 00:00:00+00:00

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Dating apps have reported a surge in activity as more and more people turn to online dating during the pandemic. But is our need for connection part of a bigger problem? 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

## How To Break Your Lockdown Habits | Russell Brand
 - [https://www.youtube.com/watch?v=nzd2SBi41ps](https://www.youtube.com/watch?v=nzd2SBi41ps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-02-11 00:00:00+00:00

Have you picked up any habits during lockdown that are no longer serving you? Try this simple, 5 minute Kundalini exercise! Make a note of how you feel BEFORE and AFTER the practice - how did you get on?

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

