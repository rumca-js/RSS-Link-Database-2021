# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Why The Human Body Sucks, and How To Fix It
 - [https://www.youtube.com/watch?v=GBsXSYRF6UE](https://www.youtube.com/watch?v=GBsXSYRF6UE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-02-12 00:00:00+00:00

What if our bodies kept evolving? And are there body parts that will disappear one day?
The First 1000 people to click this link get a FREE SKILLSHARE PREMIUM MEMBERSHIP: https://skl.sh/asapscience01211

Join our mailing list: https://bit.ly/34fWU27

Our backs hurt, ankles break and feet are busted! Not to mention having a baby is dangerous and our eyes are built backwards. There is a lot that doesn't work in our bodies, so today we are going to explain the perfectly evolved human. Evolutionary biologists have been battling this scenario for years so we explain it all. Including the need for ostrich feet, bipedal bodies, bilateral symmetry, rewiring neurons in the eye and having dog ears! Let us know if you would want this body!?

References:
Metazoa: Animal Life and the Birth of the Mind - by Peter Godfrey Smith
https://leakeyfoundation.org/2015why-walk-on-two-legs/#:~:text=The%20toes%20are%20reduced%20in,stable%2C%20rigid%20base%20for%20propulsion.
https://www.earthdate.org/node/131
https://pubmed.ncbi.nlm.nih.gov/30772945/
https://pubmed.ncbi.nlm.nih.gov/31163155/
https://pubmed.ncbi.nlm.nih.gov/30482358/
https://pubmed.ncbi.nlm.nih.gov/29787621/
https://pubmed.ncbi.nlm.nih.gov/28406563/

