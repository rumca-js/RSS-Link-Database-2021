# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## UNREAL SHOWS THE BEST CHARACTER CREATOR EVER, NEW NEXT-GEN RPG GAMEPLAY, & MORE
 - [https://www.youtube.com/watch?v=nSUYbLN3PKY](https://www.youtube.com/watch?v=nSUYbLN3PKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-12 00:00:00+00:00

An insane new next-generation graphical tech demo, a PS5 exclusive gets a release date, pigs can play video games(?) and more in a week full of gaming news.
Subscribe for more: https://www.youtube.com/gameranxTV?su​​...


Follow:
 Instagram: https://goo.gl/HH6mTW​​

Twitter: https://bit.ly/3deMHW7​​


 ~~~~STORIES~~~~

Epic Games Unreal character creator
https://youtu.be/1tjkSpoa7V8
https://youtu.be/6mAF5dWZXcI


Black Myth Wukong
https://youtu.be/uT6RZBz9ueM


E3 2021 digital
https://www.videogameschronicle.com/news/e3-pushes-forward-with-plans-for-a-digital-2021-event/

Ratchet and Clank release date! (Not all delays!)
https://youtu.be/zafv1b1qG2Y

PIGS PLAY GAMES
https://techraptor.net/gaming/news/four-pigs-play-video-games-in-new-study

Cyberpunk hack
https://www.theverge.com/2021/2/11/22278121/cd-projekt-red-ransomware-hack-cyberpunk-2077-the-witcher-3-auction-sale

6 Days in Fallujah returns:
https://youtu.be/BUewHj5VowU

Little Nightmares:
https://youtu.be/5zBbMWRgFyg

Little Nightmares reading: https://www.gamesradar.com/ahead-of-little-nightmares-2-tarsier-studios-reveals-the-stories-and-secrets-behind-its-most-monstrous-creations/?utm_campaign=socialflow&utm_medium=social&utm_content=gamesradar&utm_source=facebook.com&fbclid=IwAR20xtoD5ZhkwNSj7SxHlhwPD226125ZU7mX4bg20Ti1ykD869rcEOcHN9s

Joel confirmed for Last of Us HBO show
https://deadline.com/2021/02/pedro-pascal-star-joel-the-last-of-us-hbo-series-video-game-playstation-1234691935/
(And Jack Black is claptrap)
https://www.theverge.com/2021/2/11/22278513/jack-black-claptrap-borderlands-movie

## Why Valheim Might Be The BIGGEST SURVIVAL Game of 2021
 - [https://www.youtube.com/watch?v=l36IAbnqdYs](https://www.youtube.com/watch?v=l36IAbnqdYs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-11 00:00:00+00:00

Valheim (PC) is an open world survival game taking Steam by storm. What exactly is it? Let's dive in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

