# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Old Video Cards are ALL You Can Get - WAN Show February 12, 2021
 - [https://www.youtube.com/watch?v=RnVXqajXok8](https://www.youtube.com/watch?v=RnVXqajXok8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-12 00:00:00+00:00

Check out Seasonic's PRIME 850 W Titanium on Amazon at https://lmg.gg/seasonicprime

Get Private Internet Access VPN at https://lmg.gg/piawan

Get a 15-day free trial for unlimited backup at https://backblaze.com/WAN

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Old-Video-Cards-are-ALL-You-Can-Get---WAN-Show-February-12--2021-eqga8t

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of MattDog_222)
0:22 Why the show is late (Painting)
1:42 Andy, an employee, wanted Linus to paint during Intel Extreme Tech Upgrade
3:16 Andy's setup and how Linus broke the bed
6:16 Further explanation/reactions to the bed story
7:31 Topic Previews
9:22 Roll that intro!
9:41 Linus getting Rick-rolled
10:51 Headline: NVIDIA (supposedly) Restarting production of 1050TIs
 12:29 Explaining GPU 'wafers' during production
 13:58 The reason they are remaking it
 16:25 Digression to RTX not being popular
 18:09 Valve's user hardware related data
19:17 Intel caught 'fudging' benchmarks:
 21:29 The "Fun part" (Luke). 
 23:07 Watching the video together with Linus
 24:51 Pausing and discussing Intel Evo Branding
 26:32 Evo: What is it?
 28:06 Jon (Rettinger) should not be the the spokesperson (Linus)
 30:47 You don't market your product by crapping on the other (Linus)
 33:22 Evo standard doesn't even include USB Type A ports (Luke)
 35:02 Linus's AMD story about product marketing issues
 37:10 LTT responsible for canning an agency
 38:51 The nature of the industry with marketing agencies
 41:07 Luke's favorite marketing people to work with
 41:58 Asking Jon about the video
43:48 Sponsor: Backblaze
44:42 Sponsor: Private Internet Access (PIA)
45:25 Sponsor: Seasonic
46:37 Plugging Jon's channel
47:31 CD Projekt Red Source Code Leaks
49:59 Related cyber threats
51:49 Linus suspects someone actually bought it
52:50 Twitter explores payed subscriptions
 53:05 Facebook's ad implementation by comparison
 55:09 Twitter's homefeed (and ads)
 56:58 Twitter subscription model discussion
 58:19 What you get from it (Including editing tweets)
 59:55 Ability to tip users
 1:01:12 Art
1:02:05 Affordable Intel CPUs
1:03:37 Interesting how this + 1050TI is happening at the the same time (Luke)
1:04:50 Replying to chats
1:07:41 Linus upgrading Luke's PC + the catch
1:09:09 Conclusion + LTT Store
1:09:54 Outro

## Never seen one of these before... - Samsung M7 Smart Monitor Showcase
 - [https://www.youtube.com/watch?v=qGs9H2cd-sI](https://www.youtube.com/watch?v=qGs9H2cd-sI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-11 00:00:00+00:00

Thanks to Samsung for sponsoring today's video! Check out the 32M70A at https://lmg.gg/UsVAM

Samsung monitors and Samsung TVs are about to get a whole lot more similar! The “Smart Monitor” UHD 32M70A is a 4K monitor with smartTV apps built-in, plus screen sharing, mirroring, and remote desktop functionality. Pretty neat!

If you're looking for a more affordable version of with most the features, check out the M5 series at https://lmg.gg/wmslo

Buy Logitech MX Master 2S Wireless Mouse (PAID LINK): https://geni.us/D2KuvK

Buy Logitech G915 TKL Keyboard (PAID LINK): https://geni.us/GxR1

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1304869-never-seen-one-of-these-before-sponsored/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

