# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Grant Cardone's Crazy Billionaire Advice
 - [https://www.youtube.com/watch?v=bCRj22g5sVc](https://www.youtube.com/watch?v=bCRj22g5sVc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-12 00:00:00+00:00

Grant Cardone's Billionaire advice is... terrible.
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

## Coffeezilla VS Billy Gene Debate! Fake Gurus, Fake News and Paid Courses
 - [https://www.youtube.com/watch?v=q4GDD0WoXXw](https://www.youtube.com/watch?v=q4GDD0WoXXw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-11 00:00:00+00:00

Billy Gene and Coffeezilla sit down to hash out our differences and talk about everything from Fake Gurus to Fake News, Paid courses and even Astrology!
Billy Gene now has uploaded a video claiming he won this debate, as well as the other.  Part 3 of the debate between Billy Gene and Coffeezilla is available on the Drip
NOTE: iHeart Radio copyright claimed a couple minutes of the hour stream so we had to totally reupload it. Sorry about the missing minute and a half or so. 
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.
#coffeezilla #billygene

