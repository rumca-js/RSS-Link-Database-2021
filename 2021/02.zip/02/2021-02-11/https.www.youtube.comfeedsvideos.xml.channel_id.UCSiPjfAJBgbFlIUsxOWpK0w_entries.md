# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Faut Oublier // -M- // POMPLAMOOSE ft. Cyrille Aimée
 - [https://www.youtube.com/watch?v=9xzzM_JezbM](https://www.youtube.com/watch?v=9xzzM_JezbM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-02-11 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Matthieu Chedid aka -M- is a phenomenal songwriter and guitarist. "Faut Oublier" was one of the first songs of his that I fell in love with. Thanks to Cyrille Aimée for joining us on this upright-bass-reinterpretation of one of my favorite French songs!

Support Cyrille Aimée on Patreon! https://www.patreon.com/cyrilleaimee

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Vocals: Cyrille Aimée & Nataly Dawn
Rhodes: Jack Conte
Acoustic Guitar: John Schroeder
Upright Bass: Eliana Athayde
Drums: Ben Rose
Clarinet: John Tegmeyer
Acoustic Guitar: Erik Miron
Diatonic harmonica, synths, sound design: Ross Garren

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Branko Presley
Mixing/Mastering: Caleb Parker
Producer: John Schroeder

VIDEO CREDITS
Video Production/Direction: Ricky Chavez
Camera Operators: Merlin Showalter, Sammy Rothman, Dijon Herron, Brad Davis
Art Design: Brad Davis, Susannah Honey
Video Editor: Dominic Mercurio

Recorded at The Village in Los Angeles and Marigny Studios in New Orleans.

#Pomplamoose #FrenchJazz #CyrilleAimee #MatthieuChedid #FautOublier

LYRICS

Dans les oubliettes
De ma sombre pensée
Comme un antidote
Pour me protéger
Faut oublier

J'oublie les mensonges
Et les actes manqués
Parfois certains songes
Trahissent mes pensées
Faut oublier

J'mitraille en automatic
Dans ma tête ça va très, très vite
Mais ma mémoire est sélective
Les souvenirs qui dérangent dérivent
Vers je ne sais où

Dans les oubliettes
De ma triste pensée
J'évite toutes ces guêpes
Qui pourraient bien me tuer
Faut oublier

J'mitraille en automatic
Dans ma tête ça va très, très vite
Mais ma mémoire est sélective
Les souvenirs qui dérangent dérivent
Vers je ne sais où
Vers je ne sais où

