# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Logan - The Perfect X-Men Movie
 - [https://www.youtube.com/watch?v=2i6WT4QTfic](https://www.youtube.com/watch?v=2i6WT4QTfic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-02-24 00:00:00+00:00

Logan is the perfect send-off for Wolverine, and my favourite X-Men movie of all time, and I want to talk about it.

