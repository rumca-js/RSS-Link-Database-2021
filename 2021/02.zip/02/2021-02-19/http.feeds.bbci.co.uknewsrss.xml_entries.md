# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Mars landing: Photo shows Perseverance about to touch down
 - [https://www.bbc.co.uk/news/science-environment-56133281](https://www.bbc.co.uk/news/science-environment-56133281)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 19:08:49+00:00

Nasa releases an astonishing image of its new Mars robot taken just moments before touchdown.

## Myanmar: Protesting against a military coup... with shallots
 - [https://www.bbc.co.uk/news/world-asia-56128244](https://www.bbc.co.uk/news/world-asia-56128244)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 17:34:47+00:00

People are showing their opposition to Myanmar's military coup with shallots, shoe-tying and bicycle repairs.

## Human damage done to more than half of all rivers worldwide
 - [https://www.bbc.co.uk/news/newsbeat-56101167](https://www.bbc.co.uk/news/newsbeat-56101167)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 15:07:24+00:00

New research analysed almost 2,500 rivers and has found human activity has had an impact on rivers.

## Ben Boulos: ‘Why I changed my name from Bland’
 - [https://www.bbc.co.uk/news/uk-56125775](https://www.bbc.co.uk/news/uk-56125775)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 11:47:47+00:00

The name helped his family escape prejudice. But for the BBC’s Ben Boulos, it is time for a change.

## It's A Sin: The real women who cared
 - [https://www.bbc.co.uk/news/uk-55928870](https://www.bbc.co.uk/news/uk-55928870)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 09:37:08+00:00

The women who helped friends and relations in the Aids crisis when the disease was still a taboo.

## Swansea blitz: Childhood memories of 'bombing horror', 80 years on
 - [https://www.bbc.co.uk/news/uk-wales-56115198](https://www.bbc.co.uk/news/uk-wales-56115198)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 06:07:19+00:00

The Three Nights' Blitz began on 19 February 1941, killing 230 and injuring nearly 400.

## What does Princess Latifa case mean for British sport?
 - [https://www.bbc.co.uk/news/uk-56119788](https://www.bbc.co.uk/news/uk-56119788)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 03:19:59+00:00

The accusations against Dubai's ruler leaves British horse racing facing some uncomfortable questions.

## How Norway is offering drug-free treatment to people with psychosis
 - [https://www.bbc.co.uk/news/stories-56097028](https://www.bbc.co.uk/news/stories-56097028)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-02-19 00:57:33+00:00

People with psychosis are usually given powerful medication - in Norway they can now choose to go drug-free.

