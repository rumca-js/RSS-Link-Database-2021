# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## The First Guy To Ever Wear Contact Lenses
 - [https://www.youtube.com/watch?v=ZHAqhZi69LY](https://www.youtube.com/watch?v=ZHAqhZi69LY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-02-19 00:00:00+00:00

PSA: The chart in back says "HI THERE HELLO" and not "HIT HER" 🤦 I went too hard on the blur effect and shouldn't have followed the traditional eye chart layout. That's my bad for trying to rush an easter egg in and not double-checking how it could be misread (especially on mobile.) I also misspelled HELLLO with three L's --- so yeah. This went great.

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

