# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Dead & Stuck Pixels: Causes and How to Fix Them
 - [https://www.youtube.com/watch?v=5pvtiV3B_nE](https://www.youtube.com/watch?v=5pvtiV3B_nE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-02-20 00:00:00+00:00

Got a dead or stuck pixel? There may be hope!
Timestamps:
0:00 - Intro
0:41 - Types of Defects
1:46 - How LCD Panels Work
8:38 - Manufacturer Policies
11:13 - Methods to Fixing Pixels
14:46 - What NOT to do
17:24 - Final Thoughts

▼ UPDATES ON THE DARK SPOT ▼
1 Week - About 50% as bad as original
2 Weeks - About 25% as bad as original
3 Weeks - Maybe ~20%
4 Weeks - Still at about 20%
5 Weeks - Hard to tell if different, 15% at best, still noticeable mostly just on white backgrounds

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Tech #ThioJoe

