# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## A Guide to Tolkien's Elves | Tolkien Explained
 - [https://www.youtube.com/watch?v=nuK3LuRbyrU](https://www.youtube.com/watch?v=nuK3LuRbyrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-02-20 00:00:00+00:00

Explaining the clans of the elves - not only the Vanyar, Noldor, & Teleri, but all the subgroups like the Sindar, Silvan, Laiquendi, Falmari, Falathrim, Avari and more.  We'll cover the elves from their awakening at Cuiviénen through their travels west to Valinor, highlighting every departure (or sundering) along the way, resulting in new groups of elves!

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

At Lake Cuivienen - Ted Nasmith
Haven of the Eldar - Frederic Bennett
Avari - Jenny Dolfen
Under the Stars - Liga Klavina
Osse and the Teleri - Steamey
Glorfindel and Ecthelion - Jenny Dolfen

Check out these resources for more info on the elves of Middle-earth:
The Hobbit
The Lord of the Rings
The Silmarillion
Unfinished Tales
The Atlas of Middle-earth
The Encyclopedia of Arda
Tolkien Gateway

#tolkien #lordoftherings #silmarillion

