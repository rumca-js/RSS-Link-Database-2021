## Zawodowiec (2002) - polski film dokumentalny
 - [https://www.youtube.com/watch?v=a6AVCDMHWfg](https://www.youtube.com/watch?v=a6AVCDMHWfg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCALXymrV7GfQ74g0E2XIAQg
 - date published: 2021-02-19 09:42:45+00:00

Zawodowiec (2002) - polski film dokumentalny

