# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Rare Bosses Locked in HARD Difficulty Modes
 - [https://www.youtube.com/watch?v=N9CbzJxO0Co](https://www.youtube.com/watch?v=N9CbzJxO0Co)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-20 00:00:00+00:00

Some video game bosses are hard - others are EXCLUSIVELY super hard. Here are some crazy examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## ROCKSTAR'S NEXT GAME PRIORITIES HAVE BEEN SET, PS5 CONTROLLER PROBLEMS, & MORE
 - [https://www.youtube.com/watch?v=gbkVUih7rqs](https://www.youtube.com/watch?v=gbkVUih7rqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-19 00:00:00+00:00

Go to https://expressvpn.com/gameranx and find out how you can get 3 months of ExpressVPN free! Thanks to ExpressVPN for sponsoring our videos.

Subscribe for more: https://www.youtube.com/gameranxTV?su​​​...


Follow:
 Instagram: https://goo.gl/HH6mTW​​​

Twitter: https://bit.ly/3deMHW7​​​


 ~~~~STORIES~~~~


Some good words from Rockstar Games' parent company, PS5 DualSense lawsuits, a long awaited Nintendo Direct, crypto affecting gaming, and more in a week full of gaming news.


T2 Explains Future Project Priorities, doubles down on Rockstar single player:
https://www.gamesradar.com/take-two-ceo-says-rockstar-will-continue-to-focus-on-both-single-player-and-multiplayer-experiences/

PS5 controllers
https://www.eurogamer.net/articles/2021-02-13-law-firm-files-ps5-dualsense-drift-class-action-against-sony



Konami Silent Hill/MGS rumors
https://www.videogameschronicle.com/news/bloober-team-hints-it-could-be-working-on-silent-hill-but-its-not-the-only-one/
https://techraptor.net/gaming/news/keiichiro-toyama-left-sony-to-keep-making-games-in-his-own-style

Nintendo Direct
https://youtu.be/IVHbzcr1-D8

MK movie trailer
https://youtu.be/jBa_aHwCbC4
(Jake's full reaction) https://youtu.be/euL-x0xdFac

Shovel Knight for Honor 
https://www.youtube.com/watch?v=TrjAtnNsq8k


Nvidia crypto
https://blogs.nvidia.com/blog/2021/02/18/geforce-cmp/

Stubbs The Zombie
https://youtu.be/mwqu_WVICu8

