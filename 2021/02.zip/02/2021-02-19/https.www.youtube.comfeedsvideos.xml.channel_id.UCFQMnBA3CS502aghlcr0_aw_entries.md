# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Where I've Been For The Past Few Days... 🥶🥶🥶
 - [https://www.youtube.com/watch?v=X-0KeEgfKp8](https://www.youtube.com/watch?v=X-0KeEgfKp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-20 00:00:00+00:00

Coffeezilla takes a mandatory vacation via the Texas Blackout. We talk about Ted Cruz, power, ERCOT, and desperate times. 
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.
#txblackout #cancun #coffeezilla

