# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## bees
 - [https://www.youtube.com/watch?v=pahOqf1Ldk4](https://www.youtube.com/watch?v=pahOqf1Ldk4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-02-19 00:00:00+00:00

a song about eurorack modules made on the native instrument maschine +

i wanted to challenge myself to make something completely on the maschine. i used the perform ve vocal pedal to record vocals into the maschine. i wrote lyrics about eurorack modules. and bees. and then this is what happened. bees. so yeah. bees. ok. 

bees.

lyrics: 

U 2 vca
U fold zeroscope
tip top dsp
Quick scope megaslope

This is not rocket science
This is revolution
Rising like a fenix
Bro check the resolution

Like my cereal fruitable
Loops same, tunable
Like my patch game like my instruments
Mutable

Two bits on my qu-bit
Wave Rocket polyphonic
Five12 vector unify Desmodus

Pressure rising pressure points
Pico pico pass the joint
Get ready for the monsoon
Bout to make it rainmaker

it's bees

Ramp core after later v9a
Microburst, microdose, mia

Smarter than a turing bot, BIA
Rawer than a wavetable, no decay

Tidal waves, tides, function generator afterthought
more maths than a phd, demigod

Resonating spectral, put a rings on it, cloudburst
Call me queen of pentacles, the quadigy, my net worth

Speaking in tongues like memetic digitalis
Got the antimatter launch codes, you can call me alice
My holographic solum is about to go plastic
Bring back the drop, yo that shit is morgasmic

its bees
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

