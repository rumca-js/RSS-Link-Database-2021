# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## 12 PCI Express M.2 Slots on a Raspberry Pi!?
 - [https://www.youtube.com/watch?v=Ozwyh_Pfe6g](https://www.youtube.com/watch?v=Ozwyh_Pfe6g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2021-02-19 00:00:00+00:00

I take Alftel Systems' 12-slot PCI Express M.2 carrier board for a spin on my Raspberry Pi Compute Module 4, and mention their soon-to-be-announced 'Seaberry' Mini ITX board for the Compute Module!

Check out all the neat stuff Alftel makes: https://www.alftel.com

Follow all the PCI Express cards I'm testing with the Compute Module 4: https://pipci.jeffgeerling.com

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy

#RaspberryPi #Seaberry #ComputeModule4

