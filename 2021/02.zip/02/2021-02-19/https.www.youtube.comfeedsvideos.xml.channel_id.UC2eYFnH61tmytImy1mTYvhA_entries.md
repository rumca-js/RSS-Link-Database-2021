# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Bitcoin will be regulated to hell (Monero Chads report in!)
 - [https://www.youtube.com/watch?v=ak5TFr26BaE](https://www.youtube.com/watch?v=ak5TFr26BaE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-02-19 00:00:00+00:00

MUH DIGITAL GOLD except for it is highly monitorable and taxable. There is no such thing as an "under the table" Bitcoin transaction and everything is eternally stored on the blockchain. Privacy coins like Monero give privacy to individuals, but even more importantly make minuscule taxation and regulation impossible in the way that Bitcoin is taxed. This is one of the reasons that I prefer Monero long-term. More cryptocurrency regulation means a greater importance of privacy coins like it.

My website: https://lukesmith.xyz
Please donate: https://lukesmith.xyz/donate
Get all my videos off YouTube: https://videos.lukesmith.xyz

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinex.com/register?refer_code=ndf87 Get crypto-rich on Coinex. Get reduced exchange fees for 3 months.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

