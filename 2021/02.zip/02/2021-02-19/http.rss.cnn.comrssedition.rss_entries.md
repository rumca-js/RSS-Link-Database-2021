# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Jack Ma's Ant Group was the next big thing. Now it may become just a boring bank
 - [https://www.cnn.com/2021/02/19/tech/ant-group-analysis-intl-hnk/index.html](https://www.cnn.com/2021/02/19/tech/ant-group-analysis-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 23:57:01+00:00

Jack Ma's Ant Group quickly became one of China's most powerful companies, and its plans for bridging the worlds of tech and finance were growing ever more ambitious by the day.

## Florida gov. proposes voting restrictions
 - [https://www.cnn.com/2021/02/19/politics/desantis-florida-election-proposals/index.html](https://www.cnn.com/2021/02/19/politics/desantis-florida-election-proposals/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 21:28:23+00:00

Florida Gov. Ron DeSantis unveiled a slate of voting proposals Friday that he wants lawmakers to pass in their upcoming legislative session, including restricting the mass mailing of mail-in ballots and access to ballot drop boxes.

## Saharan dust hits Europe this weekend
 - [https://www.cnn.com/videos/weather/2021/02/19/europe-sahara-dust-air-quality.cnn](https://www.cnn.com/videos/weather/2021/02/19/europe-sahara-dust-air-quality.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 20:21:52+00:00

Southerly winds from Africa will bring Saharan dust into Europe this weekend.  The increase in dust can bring beautiful sunsets, but also poor air quality.

## Biden used 3 key stats to make a point. Except they weren't true
 - [https://www.cnn.com/videos/politics/2021/02/19/fact-check-minimum-wage-immigration-china-joe-biden-orig-me.cnn](https://www.cnn.com/videos/politics/2021/02/19/fact-check-minimum-wage-immigration-china-joe-biden-orig-me.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 19:49:30+00:00

During President Joe Biden's CNN town hall, he made several false statistical claims. Here's what you need to know.

## Bitcoin's market value tops $1 trillion
 - [https://www.cnn.com/2021/02/19/investing/bitcoin-trillion-dollar-market-value/index.html](https://www.cnn.com/2021/02/19/investing/bitcoin-trillion-dollar-market-value/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 19:48:02+00:00

The trillion-dollar market value has a new member: bitcoin. The total number of bitcoins trading are now collectively worth more than $1 trillion.

## The joy of celebrating a rover landing on Mars
 - [https://www.cnn.com/2021/02/19/world/perseverance-rover-landing-joy-scn-trnd/index.html](https://www.cnn.com/2021/02/19/world/perseverance-rover-landing-joy-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 19:31:18+00:00

We needed this moment.

## Why these European countries are scrambling for Chinese and Russian vaccines
 - [https://www.cnn.com/collections/covid-intl-022120/](https://www.cnn.com/collections/covid-intl-022120/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 18:59:20+00:00



## Cameron Diaz reveals why she 'couldn't imagine' returning to acting
 - [https://www.cnn.com/2021/02/19/entertainment/cameron-diaz-return-acting-intl-scli/index.html](https://www.cnn.com/2021/02/19/entertainment/cameron-diaz-return-acting-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 18:27:47+00:00

It has been seven years since Cameron Diaz appeared on the big screen, but the former Hollywood actress has said she is in no rush to return to acting.

## 'America is back': Biden breaks from Trump on foreign policy
 - [https://www.cnn.com/videos/world/2021/02/19/biden-foreign-policy-transatlantic-partnerships-nr-vpx.cnn](https://www.cnn.com/videos/world/2021/02/19/biden-foreign-policy-transatlantic-partnerships-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 18:14:47+00:00

Seeking a sharp break from the "America First" policies of his predecessor, President Joe Biden reaffirmed the US position of global leadership, the power of its alliances and the resilience of democracy in the United States and abroad.

## US President vows to undo damage to European alliances and rebukes Russia in first major foreign policy speech
 - [https://www.cnn.com/2021/02/19/politics/joe-biden-foreign-policy-speech/index.html](https://www.cnn.com/2021/02/19/politics/joe-biden-foreign-policy-speech/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:53:06+00:00

Seeking a sharp break from the "America First" policies of his predecessor -- which often manifested in bitter disagreements, escalating trade wars and rejection of the systems established to prevent conflict -- President Joe Biden on Friday reaffirmed the US position of global leadership, the power of its alliances and the resilience of democracy in the United States and abroad.

## America's top governors under fire as three big states reckon with deadly crises
 - [https://www.cnn.com/2021/02/19/politics/texas-governor-abbott-cuomo-newsom/index.html](https://www.cnn.com/2021/02/19/politics/texas-governor-abbott-cuomo-newsom/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:52:54+00:00

The multiple crises gripping the US -- from a once-in-a-lifetime pandemic to a deadly winter storm that left millions of Texans without heat and potable water -- have jeopardized the once-bright futures of three of the nation's most prominent governors who are trying to defend their judgment, preparedness and oversight to furious residents in three of the biggest states in the country.

## Report reveals details about brain injuries suffered by US diplomats in Cuba
 - [https://www.cnn.com/2021/02/19/americas/us-cuba-biden-intl/index.html](https://www.cnn.com/2021/02/19/americas/us-cuba-biden-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:52:50+00:00

As the State Department reviews the changes made to US policy during the Trump administration, whether to restaff the US embassy in Havana is emerging as a key question and challenge.

## FBI and intel agencies hand over first documents to lawmakers ahead of Capitol attack hearings next week
 - [https://www.cnn.com/2021/02/19/politics/congressional-committee-investigations-capitol-attack-fbi-documents/index.html](https://www.cnn.com/2021/02/19/politics/congressional-committee-investigations-capitol-attack-fbi-documents/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:43:00+00:00

House investigators have received the first batch of documents they requested from the FBI and intelligence agencies as part of their ongoing probe into security failures around the January 6 US Capitol attack, according to an official from one of the committees investigating the matter.

## Royal romance: Harry and Meghan
 - [https://www.cnn.com/2018/03/12/world/gallery/prince-harry-meghan-markle-relationship/index.html](https://www.cnn.com/2018/03/12/world/gallery/prince-harry-meghan-markle-relationship/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:39:06+00:00

Britain's Prince Harry and his wife Meghan, the Duchess of Sussex, are among the most famous couples in the world.

## Hear why this expert is optimistic about vaccines' efficacy
 - [https://www.cnn.com/videos/world/2021/02/19/coronavirus-vaccine-efficacy-variants-peacock-intv-anderson-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/02/19/coronavirus-vaccine-efficacy-variants-peacock-intv-anderson-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:28:35+00:00

CNN's Becky Anderson speaks with Sharon Peacock, Executive Director and Chair of the Covid-19 Genomics UK Consortium, about the efficacy of the different vaccines against the new coronavirus variants.

## The new slang teens use to insult boys who are 'too nice' to girls
 - [https://www.cnn.com/2021/02/19/health/what-is-simp-teen-slang-wellness/index.html](https://www.cnn.com/2021/02/19/health/what-is-simp-teen-slang-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:11:23+00:00

Many parents might be unfamiliar with the word "simp," but chances are your tween or teen has used or at least heard the term. Simp is slang for a person (typically a man) who is desperate for the attention and affection of someone else (typically a woman).

## Biden sweeps aside Trump's legacy in plotting out foreign policy reset
 - [https://www.cnn.com/collections/intl-biden-0219/](https://www.cnn.com/collections/intl-biden-0219/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:11:12+00:00



## The bizarre and totally scientific way that alligators breathe in icy water
 - [https://www.cnn.com/2021/02/19/us/alligator-snout-freeze-icing-trnd/index.html](https://www.cnn.com/2021/02/19/us/alligator-snout-freeze-icing-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 17:08:58+00:00

Winter storms have battered the US this week, and many animals are struggling in the cold.

## Prince Philip to stay in London hospital over the weekend
 - [https://www.cnn.com/2021/02/19/uk/prince-philip-hospital-stay-gbr-intl-scli/index.html](https://www.cnn.com/2021/02/19/uk/prince-philip-hospital-stay-gbr-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 16:58:16+00:00

Britain's Prince Philip is likely to remain in the hospital for observation and rest over the weekend and into next week, a royal source told CNN on Friday.

## The face of the rover landing was an Indian American woman
 - [https://www.cnn.com/2021/02/19/world/swati-mohan-nasa-perseverance-landing-scn-trnd/index.html](https://www.cnn.com/2021/02/19/world/swati-mohan-nasa-perseverance-landing-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 16:54:15+00:00



## Ted Cruz's explanation for his Cancun trip made things worse
 - [https://www.cnn.com/collections/cruz-intl-021921/](https://www.cnn.com/collections/cruz-intl-021921/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 16:31:36+00:00



## As Trump's latest intra-party feud rages, Sen. Graham heads to Mar-a-Lago on a peace mission
 - [https://www.cnn.com/collections/intl-trump-problems-0218/](https://www.cnn.com/collections/intl-trump-problems-0218/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 16:28:08+00:00



## Prince Harry and Meghan will not return as working members of royal family
 - [https://www.cnn.com/2021/02/19/uk/prince-harry-meghan-queen-intl-scli-gbr/index.html](https://www.cnn.com/2021/02/19/uk/prince-harry-meghan-queen-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 16:25:02+00:00

Prince Harry and Meghan, the Duchess of Sussex, have told Queen Elizabeth that they will not return as working members of the royal family.

## Facebook faces a global backlash over its bid to 'bully' Australia
 - [https://www.cnn.com/collections/intl-tech-1902/](https://www.cnn.com/collections/intl-tech-1902/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 16:07:01+00:00



## This ballerina alleged racism at her company. Now, Chloé Lopes Gomes says it's time for change
 - [https://www.cnn.com/style/article/chloe-lopes-gomes-ballet-racism-personal-essay/index.html](https://www.cnn.com/style/article/chloe-lopes-gomes-ballet-racism-personal-essay/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 16:01:35+00:00

In 2018 I became the first Black ballet dancer to join Berlin's principal ballet company, the Staatsballett. Joining this kind of ballet institution was my dream -- it's one of the best in the world.

## Reversal of Earth's magnetic poles may have triggered Neanderthal extinction -- and it could happen again
 - [https://www.cnn.com/2021/02/19/world/magnetic-fields-earth-intl-scli-scn/index.html](https://www.cnn.com/2021/02/19/world/magnetic-fields-earth-intl-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 15:49:10+00:00

The reversal of Earth's magnetic poles, along with a temporary breakdown of the world's magnetic field about 42,000 years ago, could have triggered a raft of environmental changes, solar storms and the extinction of the Neanderthals, according to a new study.

## Allegations of shackled students and gang rape inside China's detention camps
 - [https://www.cnn.com/2021/02/18/asia/china-xinjiang-teacher-abuse-allegations-intl-hnk-dst/index.html](https://www.cnn.com/2021/02/18/asia/china-xinjiang-teacher-abuse-allegations-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 15:14:35+00:00

On the first day of her new teaching job at a Chinese government-run detention center in Xinjiang, Qelbinur Sidik said she saw two soldiers carry a young Uyghur woman out of the building on a stretcher.

## UK Supreme Court rules that Uber drivers are 'workers,' not independent contractors
 - [https://www.cnn.com/2021/02/19/tech/uber-uk-workers/index.html](https://www.cnn.com/2021/02/19/tech/uber-uk-workers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 14:56:12+00:00

The UK Supreme Court has ruled that Uber must classify its drivers as workers and not independent contractors, a decision that could deliver a major blow to the company's business model in one of its most important markets.

## Analysis: Biden team is finding promises hard to make -- let alone keep
 - [https://www.cnn.com/2021/02/19/politics/biden-promises-coronavirus/index.html](https://www.cnn.com/2021/02/19/politics/biden-promises-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 14:47:36+00:00

Speaking on television last week, Dr. Anthony Fauci predicted April would be "open season" for receiving the coronavirus vaccine, welcome news for a nation entering its second year under pandemic-forced lockdowns and ever-lingering fear of disease.

## Iranian judoka Saeid Mollaei says he'll never forget kindness of Israeli team ahead of Tel Aviv tournament
 - [https://www.cnn.com/2021/02/19/sport/saeid-mollaei-iran-judo-israel-spt-intl/index.html](https://www.cnn.com/2021/02/19/sport/saeid-mollaei-iran-judo-israel-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 14:31:39+00:00

Iranian judoka Saeid Mollaei, who refused to return home after being ordered to withdraw from the 2019 World Judo Championships to avoid facing an Israeli opponent, says he will never forget the kindness he's been shown by the Israeli judo team as he prepares to compete in a major tournament in Tel Aviv.

## A Texas family lost their dad to Covid-19 three weeks ago. Now they lost their home to a fire while trying to stay warm
 - [https://www.cnn.com/collections/intl-texas-weather-02182021/](https://www.cnn.com/collections/intl-texas-weather-02182021/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 14:15:04+00:00



## Opinion: What to know about the Paris climate agreement now that the US has rejoined
 - [https://www.cnn.com/2021/02/19/opinions/us-paris-agreement-climate-change-sharma/index.html](https://www.cnn.com/2021/02/19/opinions/us-paris-agreement-climate-change-sharma/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 13:01:17+00:00

America, welcome back to the frontline of the global fight against climate change. On Friday, President Joe Biden delivered on a key climate campaign pledge by re-joining the Paris Agreement -- the international climate accord agreed in 2015 by world nations to tackle global warming.

## New coronavirus variants make these activities higher risk
 - [https://www.cnn.com/videos/health/2021/02/18/covid-variants-low-high-risk-activities-orig-mg.cnn](https://www.cnn.com/videos/health/2021/02/18/covid-variants-low-high-risk-activities-orig-mg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 12:55:23+00:00

New, more contagious variants of the novel coronavirus can spread easier, making some activities we thought were low risk, higher risk.

## Why these European countries are scrambling for Chinese and Russian vaccines
 - [https://www.cnn.com/2021/02/19/europe/western-balkans-vaccines-russia-china-eu-intl/index.html](https://www.cnn.com/2021/02/19/europe/western-balkans-vaccines-russia-china-eu-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 12:41:13+00:00

• Live updates: This could be the first fully vaccinated territory in the world

## Israeli opposition horrified by Netanyahu deal with homophobic party
 - [https://www.cnn.com/videos/world/2021/02/19/israel-netanyahu-likud-lgbtq-kiley-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/02/19/israel-netanyahu-likud-lgbtq-kiley-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 12:38:47+00:00

Israeli Prime Minister Benjamin Netanyahu likes to talk about Israel's thriving gay scene as a sign of the country's tolerance on social issues but, as the country faces another election in March, is aligning himself with far-right parties, some with explicitly homophobic platforms. CNN's Sam Kiley reports.

## Meet Elizabeth Ann the ferret: The first endangered American animal to be cloned
 - [https://www.cnn.com/2021/02/19/us/elizabeth-ann-ferret-cloned-scli-intl-scn/index.html](https://www.cnn.com/2021/02/19/us/elizabeth-ann-ferret-cloned-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 12:37:30+00:00

Scientists have cloned an endangered US animal for the first time, creating a black-footed ferret named Elizabeth Ann from the frozen cells of an ancestor in a landmark achievement that boosts conservation efforts.

## Far-right personalities burrow deeper into the web amid scrutiny
 - [https://www.cnn.com/2021/02/19/us/extremism-cryptocurrency-profiting-off-hate-invs/index.html](https://www.cnn.com/2021/02/19/us/extremism-cryptocurrency-profiting-off-hate-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 12:27:25+00:00

Weeks before the Unite the Right rally in Charlottesville, Virginia, in 2017, a burly and bearded neo-Nazi told a CNN reporter on camera that "Jews are terrorists."

## Kicked out of the men's basketball league, Sarah Thomas set her sights on the Super Bowl
 - [https://www.cnn.com/2021/02/19/sport/super-bowl-nfl-official-sarah-thomas-cmd-spt-intl/index.html](https://www.cnn.com/2021/02/19/sport/super-bowl-nfl-official-sarah-thomas-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 11:49:39+00:00

The lyrics are soaring and defiant: "And I'll rise up. I'll rise like the day! I'll rise up. I'll rise unafraid!"

## LeBron James becomes the third NBA player to reach 35,000 career points
 - [https://www.cnn.com/2021/02/19/sport/lebron-james-35000-points-spt-intl/index.html](https://www.cnn.com/2021/02/19/sport/lebron-james-35000-points-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 10:37:34+00:00

LeBron James reached a career milestone Thursday as he passed 35,000 points, making him the third and youngest NBA player to do so after Kareem Abdul-Jabbar and Karl Malone.

## Japan's ruling party has a problem and it doesn't want women to speak in meetings
 - [https://www.cnn.com/videos/world/2021/02/19/japan-sexism-politics-selina-wang-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/02/19/japan-sexism-politics-selina-wang-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 10:31:24+00:00

Japan's governing party has decided to invite women to meetings but with one stipulation -- they are only there to observe. CNN's Selina Wang reports on the state of sexism in Japanese politics.

## 4 Chinese soldiers died in bloody India border clash last year, China reveals
 - [https://www.cnn.com/2021/02/19/asia/china-indian-border-casualty-intl-hnk/index.html](https://www.cnn.com/2021/02/19/asia/china-indian-border-casualty-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 09:29:12+00:00

China has revealed that four of its People's Liberation Army (PLA) soldiers were killed during a bloody hand-to-hand battle with Indian troops on the two countries' disputed border high in the Himalayas in June 2020.

## Alpine skiing: Race director received death threats after parallel events
 - [https://www.cnn.com/2021/02/19/sport/markus-waldner-cortina-dampezzo-alpine-skiing-world-championships-spt-intl/index.html](https://www.cnn.com/2021/02/19/sport/markus-waldner-cortina-dampezzo-alpine-skiing-world-championships-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 09:13:36+00:00

Men's race director Markus Waldner received death threats following the parallel giant slaloms at the Cortina d'Ampezzo Alpine skiing world championships, the organising committee said on Thursday.

## Woman shot in the head during Myanmar coup protest dies, the first known fatality of the ongoing unrest
 - [https://www.cnn.com/2021/02/19/asia/myanmar-protester-shot-dies-intl-hnk/index.html](https://www.cnn.com/2021/02/19/asia/myanmar-protester-shot-dies-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 08:20:14+00:00

A young woman shot in the head last week during an anti-coup protest in the Myanmar capital died on Friday, a family member told CNN.

## New UN report calls out humanity's 'war' on the planet
 - [https://www.cnn.com/2021/02/18/americas/un-report-climate-making-peace-intl/index.html](https://www.cnn.com/2021/02/18/americas/un-report-climate-making-peace-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 05:01:23+00:00

The United Nations released a report Thursday on the health of the planet that proposes a radical shift in the way mankind thinks about it.

## Hotel apologizes after honeymooners discover people can see into mirrored sauna
 - [https://www.cnn.com/travel/article/south-korea-hotel-see-through-sauna-apology-intl-hnk/index.html](https://www.cnn.com/travel/article/south-korea-hotel-see-through-sauna-apology-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 02:57:57+00:00

An upscale hotel in South Korea has issued an apology for a mistake that may have enabled outsiders to see into their sauna.

## Hear what Heidi Cruz was texting neighbors before trip
 - [https://www.cnn.com/videos/politics/2021/02/19/goldmacher-intv-ted-cruz-cancun-vacation-texas-power-snow-ice-heidi-text-nyt-sot-ac360-vpx.cnn](https://www.cnn.com/videos/politics/2021/02/19/goldmacher-intv-ted-cruz-cancun-vacation-texas-power-snow-ice-heidi-text-nyt-sot-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 01:57:57+00:00

New York Times reporter Shane Goldmacher tells CNN's Anderson Cooper that despite Sen. Ted Cruz claiming he traveled to Cancun, Mexico, to drop his children off for a vacation, the text messages his wife, Heidi Cruz, sent to neighbors and friends before the trip reveal otherwise.

## Fans awed by Dolly Parton's humble response to a statue
 - [https://www.cnn.com/videos/entertainment/2021/02/19/dolly-parton-turns-down-statue-tennessee-moos-pkg-ebof-vpx.cnn](https://www.cnn.com/videos/entertainment/2021/02/19/dolly-parton-turns-down-statue-tennessee-moos-pkg-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 01:26:54+00:00

Fans swoon when legendary musician Dolly Parton says "thanks, but no thanks" to a statue in her likeness at the Tennessee Capitol. CNN's Jeanne Moos reports on the statuesque national treasure.

## NASA scientist on Mars rover landing: 'A dream come true'
 - [https://www.cnn.com/videos/tech/2021/02/18/nasa-mars-2020-rover-perseverance-scientist-mission-williford-intv-tsr-vpx.cnn](https://www.cnn.com/videos/tech/2021/02/18/nasa-mars-2020-rover-perseverance-scientist-mission-williford-intv-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 00:36:13+00:00

Deputy project scientist for NASA's Mars 2020 mission Ken Williford joins CNN's Wolf Blitzer to share what "big unanswered questions" the Perseverance rover could answer.

## Beijing faces abuse claims from Xinjiang
 - [https://www.cnn.com/videos/world/2021/02/18/china-xinjiang-abuse-allegations-watson-pkg-lead-intl-vpx.cnn](https://www.cnn.com/videos/world/2021/02/18/china-xinjiang-abuse-allegations-watson-pkg-lead-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-02-19 00:14:25+00:00

A former teacher and ex-detainee allege gang rape and torture of women inside China's vast network of detention camps. CNN's Ivan Watson reports.

