# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How To Go Completely KETO
 - [https://www.youtube.com/watch?v=Ibs8Bss3kyw](https://www.youtube.com/watch?v=Ibs8Bss3kyw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-02-20 00:00:00+00:00

Grab your Sleep Remedy Here - https://docparsley.com/jp

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

In this video you’ll learn how to go completely keto! The key to a ketogenic diet is to be as extreme as possible. A high fat diet is more balanced when it’s all fat. Going completely keto means you go into ketosis and you never come back!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## Texas Snowpocalypse Freezing News Update!
 - [https://www.youtube.com/watch?v=UyEWREHxjJQ](https://www.youtube.com/watch?v=UyEWREHxjJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-02-19 00:00:00+00:00

Grab your BluBlox Glasses Here - https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Reporting to you from Texas for a Snowpocalypse freezing news update! Get all the updates on the Texas power outage, freezing temperatures, water outages, and food shortages! You’ll learn everything you need to know about the unprecedented Texas winter storm.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

