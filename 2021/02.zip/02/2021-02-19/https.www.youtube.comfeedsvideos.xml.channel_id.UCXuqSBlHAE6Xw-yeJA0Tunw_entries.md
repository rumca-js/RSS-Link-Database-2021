# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## NVIDIA pretends to care about gamers. - CMP Announcement
 - [https://www.youtube.com/watch?v=XfIibTBaoMM](https://www.youtube.com/watch?v=XfIibTBaoMM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-20 00:00:00+00:00

Get 20% OFF + Free Shipping @manscaped with code TECH at https://manscaped.com/TECH

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus1

Nvidia thinks they can pull a fast one on gamers looking to grab an RTX 3060, but we know you're smarter than that - Let's dig deeper and see if we can figure out why they're launching cryptocurrency mining cards...

Discuss on the forum: https://linustechtips.com/topic/1307801-nvidia-pretends-to-care-about-gamers/


► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## If Pixar made a robot - ClicBot Robot Showcase
 - [https://www.youtube.com/watch?v=XCYM_k-y4uY](https://www.youtube.com/watch?v=XCYM_k-y4uY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-19 00:00:00+00:00

Thanks to Keyi Tech for sponsoring today’s showcase of their ClicBot! Get your own ClicBot and use code LINUSSPECIAL for an extra 5% off on Amazon + a 10% discount that they're running for a limited time.
Amazon: https://lmg.gg/ngNyw
Official Keyi Website: https://bit.ly/ClicBotLTT  

We got our hands on the new ClicBot 1000 Robots in One from Keyi and surprise surprise, it’s actually pretty neat.

Discuss on the forum: https://linustechtips.com/topic/1307673-if-pixar-made-a-robot-clicbot-robot-showcase/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## What a TRAIN WRECK! - xQc PC Build Stream Reaction
 - [https://www.youtube.com/watch?v=A0WzLguGLOo](https://www.youtube.com/watch?v=A0WzLguGLOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-19 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

In our first ever reaction video, Linus reacts to Twitch streamer xQc's gaming PC build log.


Buy an ASUS ROG Strix RTX 3090 on Amazon: https://geni.us/8B6IZKw

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1307425-reacting-to-xqcs-fail-pc-build/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Your Memory is Getting its OWN CPU?? - WAN Show February 19, 2021
 - [https://www.youtube.com/watch?v=SjR1E7rNujQ](https://www.youtube.com/watch?v=SjR1E7rNujQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-19 00:00:00+00:00

Check out RemoteHQ at http://remotehq.co/wan and use code WAN

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Your-Memory-is-Getting-its-OWN-CPU-----WAN-Show-February-19--2021-eqp8nn

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of AD)
Topics: 0:06
Intro: 1:57
Sponsors: 2:20
Samsung calming 1st high bandwidth memory and AI processing: 2:30
Nvidia slows the mining performance of up coming 3060: 13:37
New floatplane video (Buying counterfeit LTT Merch): 19:35
Sponsors: 24:35
Reacting to xQc’s reaction to Linus’s reaction of xQc building his PC : 28:56
Linus drawing: 49:05
Linus confession: 1:09:38
Linus talks about his “bone-head move”: 1:11:08
Linus “overall response” to the reaction: 1:13:28
Linus talk about Twitch streaming and streamers: 1:14:17
Return to other topics :
Facebook: 1:16:31
Xbox series x got an update: 1:21:56
SuperChats: 1:26:04
Outro: 1:28:46

