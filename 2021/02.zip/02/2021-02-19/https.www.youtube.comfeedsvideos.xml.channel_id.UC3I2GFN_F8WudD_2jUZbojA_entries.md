# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Anjimile - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=83kPvjwe59o](https://www.youtube.com/watch?v=83kPvjwe59o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-20 00:00:00+00:00

http://KEXP.ORG presents Anjimile performing live, recorded exclusively for KEXP.

Songs:
Your Tree
Baby No More 
1978
Maker
Soothing (Laura Marling cover)

Filming by Rachel Rimm
Recording and Editing by Anjimile

http://www.anjimile.com
http://kexp.org

## Anjimile - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=brYFBegbAQg](https://www.youtube.com/watch?v=brYFBegbAQg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-19 00:00:00+00:00

http://KEXP.ORG presents Anjimile sharing a live performance recorded exclusively for KEXP and talking to Gabriel Teodros, host of Early. Recorded February 8, 2021.

Songs:
Your Tree
Baby No More 
1978
Maker
Soothing (Laura Marling cover)

Session Filming by Rachel Rimm
Recording and Editing by Anjimile

http://www.anjimile.com
http://kexp.org

