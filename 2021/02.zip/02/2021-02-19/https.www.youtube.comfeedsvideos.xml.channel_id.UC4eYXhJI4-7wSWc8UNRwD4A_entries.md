# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## 'Louder Than A Riot' Remixed: The State of Rhyme & Punishment
 - [https://www.youtube.com/watch?v=k4O0NfwHmK4](https://www.youtube.com/watch?v=k4O0NfwHmK4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-02-19 00:00:00+00:00

Season one of Louder Than A Riot—NPR Music's podcast tracing the interconnected rise of hip-hop and mass-incarceration—has ended, but the conversation is just getting started. Join hosts Sidney Madden and Rodney Carmichael for Louder Than A Riot Remixed: The State of Rhyme and Punishment. It's a discussion about topics touched on in the podcast—hip-hop music, fame, racism, and injustice—but also the current state of affairs, and the bigger picture they reveal.

A conversation as big as this one couldn't happen with just two people, so Sidney and Rodney tapped a few special guests to join them: platinum-selling rapper Maino, award-winning artist Isis Tha Saviour, co-host of the Justice in America podcast Josie Duffy Rice, and music journalist Lawrence Burney.

