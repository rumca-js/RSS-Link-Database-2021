# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## GameStop: One Final Ride and the Road Ahead
 - [https://www.youtube.com/watch?v=m6gJX5so65c](https://www.youtube.com/watch?v=m6gJX5so65c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-02-19 00:00:00+00:00

GameStop was kinda cool I guess. Then it wasn’t for a while. And then, ya know, it was cool again for a bit. But now, well.

That’s the vid. That’s it.

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

Additional Footage Credits:
Push Square

And I think it's gonna be a long, long time
'Til touchdown brings me 'round again to find
I'm not the man they think I am at home
Oh, no, no, no
I'm a rocket man

