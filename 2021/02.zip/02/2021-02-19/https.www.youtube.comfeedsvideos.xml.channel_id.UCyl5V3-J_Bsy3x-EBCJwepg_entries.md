# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## New Disney Movie Tells Feminist Origin Story Of Xenomorph Queen
 - [https://www.youtube.com/watch?v=2VBGVmNUo5A](https://www.youtube.com/watch?v=2VBGVmNUo5A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-20 00:00:00+00:00

Wow! Disney just announced a new standalone Alien prequel that tells the sympathetic feminist origin story of the Xenomorph Queen -- along with five other feminist movies! Kyle and Ethan report from The Babylon Bee Entertainment Desk.

## The Bee Reads LOTR Episode 8: Fog on the Barrow-Downs
 - [https://www.youtube.com/watch?v=p6sMHgM9Cb4](https://www.youtube.com/watch?v=p6sMHgM9Cb4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-20 00:00:00+00:00

Kyle and Dan from The Babylon Bee are joined by Jonathan Watson of TheOneRing.Com as they catch up with Frodo, Sam, Merry, and Pippin as they make it to the barrow-downs and immediately run into trouble. There’s some ghosties, ancient evil stirring, and newfound courage found in a dark place. 

The subscriber portion is where all the best content is, so head over to BabylonBee.Com/Plans and sign up to enjoy full-length podcasts!

## Hobo Elon Musk Ep. 1 - Tunnels!
 - [https://www.youtube.com/watch?v=IfpfBmhqGw8](https://www.youtube.com/watch?v=IfpfBmhqGw8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-19 00:00:00+00:00

What if Elon Musk were a penniless hobo? Would Elon still care about tunnels? Or would Musk just sound crazy?

## “LOL, JK” and Prospects for Conservative Movies
 - [https://www.youtube.com/watch?v=LWNz7QrnauU](https://www.youtube.com/watch?v=LWNz7QrnauU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-19 00:00:00+00:00

Kyle and Ethan, from The Babylon Bee, are joined by Wes Halula, a writer and producer on Church People, to talk about the prospects of conservative and Christian films and also how the Babylon Bee gets away with spreading disinformation by putting “LOL, JK” at the end of every article according to Wikipedia editors. The guys also discuss the sad news of contemporary Christian music pioneer Carman and radio giant Rush Limbaugh passing away. There’s weird news, stuff that’s good, and glorious hate mail!

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

