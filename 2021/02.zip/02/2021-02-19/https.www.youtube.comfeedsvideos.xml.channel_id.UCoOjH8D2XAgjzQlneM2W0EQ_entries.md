# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Meet America's Hedge Fund Billionaires
 - [https://www.youtube.com/watch?v=PiLZSTBIjO8](https://www.youtube.com/watch?v=PiLZSTBIjO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-02-19 00:00:00+00:00

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join

Check out the website platform I use and love: http://bit.ly/37wJDo8
📈 The most in-depth documentary on the Gamestop Short Squeeze: https://youtu.be/GkvRWzz1Rkk 
🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub

🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use: https://jake.yt/benchd 
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3s5KRPe

Music by Erang: https://erang.bandcamp.com 

-----------------------
Long-Term Capital Management was a very non conspicuous name for the biggest hedge fund during the 1990’s. September 1998, LTCM was out of options, everyone on Wall Street thought if they fell, the entire system would collapse. The hedge fund managers collected their sweet fees and profits this entire time, and when it came time to pay, they left the bag for the other banks to hold.

Steve Cohen runs Point72 Asset Management. His name may sound familiar after the whole Gamestop mania. He walked away from one of the biggest insider trading scandals on Wall Street: In 2013, his original hedge fund, S.A.C. Capital Advisors plead guilty to insider trading

Gabriel Plotkin was one of the traders who received insider information. After S.A.C Capital pled guilty to insider trading and closed shop, Gabriel Plotkin would go on to create Melvin Capital, raising $1 billion, with a focus on short selling! After the Gamestop Short Squeeze, Melvin Capital lost 53%.

Ken Griffin founded Citadel, an American multinational hedge fund, the world’s 9th largest hedge fund with over $34 billion under management and Citadel Securities, which is what’s called a Market Maker. During the first half of 2020 alone, they doubled their profits to $4 billion in revenue thanks to increased trading and volatility. This makes Ken Griffin a powerful billionaire in the world of high finance.

When you imagine a young, hyper successful, shark of an American Hedge Fund Billionaire - that’s Chase Coleman. He was born into New York aristocracy and trained under a legendary hedge fund billionaire, Julian Robertson. At 25, his mentor handed him $25 million to start his own fund, Tiger Global Management.

George Soros became known as the man who broke the Bank of England and made a billion dollars in the process. In 1992, Soros started building his position against the British pound by borrowing pounds from British banks and hedge funds.

You know Jim Cramer? He used to be a hedge fund manager that was an expert at these dirty tactics, especially with short selling.  He used to be a hedge fund manager that was an expert at these dirty tactics, especially with short selling.
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

