# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 2 List do Tesaloniczan || Rozdział 02
 - [https://www.youtube.com/watch?v=uadIVnaNgxw](https://www.youtube.com/watch?v=uadIVnaNgxw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-02-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#222] Bóg z Ciebie nie zrezygnuje
 - [https://www.youtube.com/watch?v=Qh3t9UJcVHw](https://www.youtube.com/watch?v=Qh3t9UJcVHw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-02-20 00:00:00+00:00

@Langustanapalmie #dobrewiadomości #kazankodookienka

I Niedziela Wielkiego Postu, Rok B

1. czytanie (Rdz 9, 8-15)

Tak rzekł Bóg do Noego i do jego synów: «Oto Ja zawieram przymierze z wami i z waszym potomstwem, które po was będzie; z wszelką istotą żywą, która jest z wami: z ptactwem, ze zwierzętami domowymi i polnymi, jakie są przy was, ze wszystkimi, które wyszły z arki, z wszelkim zwierzęciem na ziemi. Zawieram z wami przymierze, tak iż nigdy już nie zostanie zgładzona wodami potopu żadna istota żywa i już nigdy nie będzie potopu niszczącego ziemię». Po czym Bóg dodał: «A to jest znak przymierza, które Ja zawieram z wami i każdą istotą żywą, jaka jest z wami, na wieczne czasy: Łuk mój kładę na obłoki, aby był znakiem przymierza między Mną a ziemią. A gdy rozciągnę obłoki nad ziemią i gdy ukaże się ten łuk na obłokach, wtedy wspomnę na moje przymierze, które zawarłem z wami i z wszelką istotą żywą, z każdym człowiekiem; i nie będzie już nigdy wód potopu na zniszczenie żadnego istnienia».

2. czytanie (1 P 3, 18-22)

Najdrożsi: Chrystus raz jeden umarł za grzechy, sprawiedliwy za niesprawiedliwych, aby was do Boga przyprowadzić; zabity wprawdzie na ciele, ale powołany do życia przez Ducha. W Nim poszedł ogłosić zbawienie nawet duchom zamkniętym w więzieniu, niegdyś nieposłusznym, gdy za dni Noego cierpliwość Boża naczekiwała, a budowana była arka, w której niewielu, to jest osiem dusz, zostało uratowanych przez wodę. Teraz również zgodnie z tym wzorem ratuje was ona we chrzcie nie przez obmycie brudu cielesnego, ale przez zobowiązanie dobrego sumienia wobec Boga – dzięki zmartwychwstaniu Jezusa Chrystusa. On jest po prawicy Bożej, gdyż poszedł do nieba, gdzie poddani Mu zostali aniołowie i Władze, i Moce.

Ewangelia (Mk 1, 12-15)

Duch wyprowadził Jezusa na pustynię. A przebywał na pustyni czterdzieści dni, kuszony przez Szatana, i był ze zwierzętami, aniołowie zaś Mu służyli.
Gdy Jan został uwięziony, Jezus przyszedł do Galilei i głosił Ewangelię Bożą. Mówił: «Czas się wypełnił i bliskie jest królestwo Boże. Nawracajcie się i wierzcie w Ewangelię!»

________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Na żywo [#04] Okruchy 2 [PL/SK]
 - [https://www.youtube.com/watch?v=6pkH9SVwJ_8](https://www.youtube.com/watch?v=6pkH9SVwJ_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-02-20 00:00:00+00:00

@Langustanapalmie @Stacja7pl 

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#716] Oddalenie
 - [https://www.youtube.com/watch?v=bsQFCKX1JRI](https://www.youtube.com/watch?v=bsQFCKX1JRI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-02-20 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 20.02 → https://youtu.be/dh6czmzWsQE

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 2 List do Tesaloniczan || Rozdział 01
 - [https://www.youtube.com/watch?v=NfX-MKIT7F8](https://www.youtube.com/watch?v=NfX-MKIT7F8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-02-19 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miotła [#03] Okruchy 2 [PL/SK]
 - [https://www.youtube.com/watch?v=VIjPt-iX6qA](https://www.youtube.com/watch?v=VIjPt-iX6qA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-02-19 00:00:00+00:00

​ @Langustanapalmie @Stacja7pl 

Tytułowe “Okruchy” to propozycja 40 konkretnych ćwiczeń duchowych od o. Adama Szustaka do wykonania w czasie Wielkiego Postu. W kolejnych zadaniach ojciec Adam zaprasza by zrezygnować ze zbędnych czynności, którym poświęcamy większość naszego czasu, ale także zachęca do konkretnych uczynków i modlitwy, która powinna stanowić fundament naszego codziennego życia. Proponowane przez niego zadania nie są po to, by coś „odhaczyć”, lecz aby stworzyć wolną przestrzeń i czas do naprawienia relacji z Panem Jezusem i drugim człowiekiem, lub po prostu podarować komuś odrobinę dobra.

Zapraszamy od poniedziałku do soboty o godz. 18:00
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#715] Uniżenie
 - [https://www.youtube.com/watch?v=tqKD7nJv3PI](https://www.youtube.com/watch?v=tqKD7nJv3PI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-02-19 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

WSTAWAKI WIELKOPOSNE startują! W tym roku przejdziemy Wielki Post z mistykami Karmelitańskimi, a do tego wraz POGŁĘBIARKĄ zapraszamy do Medytacji Ignacjańskich.

Rozważanie na 19.02 → https://youtu.be/-fsBL2CkeoA 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

