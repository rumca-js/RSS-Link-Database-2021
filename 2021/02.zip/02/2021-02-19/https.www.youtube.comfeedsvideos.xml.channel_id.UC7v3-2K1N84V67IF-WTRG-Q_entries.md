# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Mortal Kombat - Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=Ui4_qLrYLzw](https://www.youtube.com/watch?v=Ui4_qLrYLzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-02-19 00:00:00+00:00

Thanks to Skillshare for sponsoring. The first 1000 people to use the link will get a free trial of Skillshare Premium Membership: https://skl.sh/jeremyjahns02211

We have a trailer to 2021's #MortalKombat !!! ...I was starting to think we were being punked. Here are my thoughts on the trailer!

Watch the trailer here: https://www.youtube.com/watch?v=jBa_aHwCbC4&t=1s&ab_channel=WarnerBros.Pictures

## WandaVision - Episode 7 (My Thoughts)
 - [https://www.youtube.com/watch?v=moyMas8beoQ](https://www.youtube.com/watch?v=moyMas8beoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-02-19 00:00:00+00:00

Get up to 65% OFF a Babbel subscription! Limited time only. HERE: https://go.babbel.com/6m50-youtube-jeremyjahns-feb-2021/default
Thank you Babbel for sponsoring!

The reveals continue as we get a big answer! Here are my thoughts on #WandaVision Episode 7!

