# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "Pickle Homer" - Remixing Homer Turning Himself Into A Pickle
 - [https://www.youtube.com/watch?v=3nhsNkPbffA](https://www.youtube.com/watch?v=3nhsNkPbffA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-02-20 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong I remixed Pickle Rick. Now I remix Pickle Homer. The payoff is huge!
Watch the original Pickle Homer clip from the amazing channel Speaking of AI: https://youtu.be/Fdsomv-dYAc

