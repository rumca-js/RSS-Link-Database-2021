# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The Great Reset: Bill Gates & Farming - WHAT'S GOING ON?
 - [https://www.youtube.com/watch?v=fg0c2x74mgU](https://www.youtube.com/watch?v=fg0c2x74mgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-02-19 00:00:00+00:00

Indian farmers are protesting over new laws that could leave them at the mercy of giant corporations, while Big Tech companies are capturing their data. With Facebook and Bill Gates involved, what does it mean for you?  

See Vandana Shiva's full FRANCE 24 interview here: https://www.youtube.com/watch?v=MNM833K22LM&t=35s&ab_channel=FRANCE24English

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

___________________________________
Click the link below to subscribe below to my Youtube Channel:

http://www.youtube.com/c/RussellBrand?sub_confirmation=1


For meditation and breath work, subscribe to my side-channel: 

http://www.youtube.com/c/AwakeningWithRussell?sub_confirmation=1
___________________________________

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

