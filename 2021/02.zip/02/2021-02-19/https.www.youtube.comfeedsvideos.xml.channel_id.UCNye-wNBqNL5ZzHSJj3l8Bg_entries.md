## Yanis Varoufakis: Capitalism has become 'techno-feudalism' | UpFront
 - [https://www.youtube.com/watch?v=_jW0xUmUaUc](https://www.youtube.com/watch?v=_jW0xUmUaUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNye-wNBqNL5ZzHSJj3l8Bg
 - date published: 2021-02-19 21:05:32+00:00

Yanis Varoufakis: Capitalism has become 'techno-feudalism' | UpFront

