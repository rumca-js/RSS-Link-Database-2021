# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Na czym tak naprawdę zarabiają influencerzy?
 - [https://www.youtube.com/watch?v=3aqh52OP0xQ](https://www.youtube.com/watch?v=3aqh52OP0xQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2021-02-19 00:00:00+00:00

W dzisiejszym filmie chcę Wam powiedzieć o tym, dzięki komu moje życie w ostatnich latach zmieniło się na lepsze oraz jakie mam dalsze plany na prowadzenie tego kanału. Przy okazji mam nadzieję, że wyniesiecie z tego vloga trochę pożytecznych informacji :)

Zostań Patronem kanału!
https://patronite.pl/vlogcasha

YT Eweliny: @evelinaross7004 
IG Eweliny: https://www.instagram.com/evelinaross_

YT Adriana: @mowikamera 
IG Adriana: https://www.instagram.com/adriankilar/

