# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## New Jersey 1920's in Color! [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=qF-FwYJJWSI](https://www.youtube.com/watch?v=qF-FwYJJWSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2021-02-20 00:00:00+00:00

I colorized, restored and created a sound design for this video of New Jersey 1920's, has a rich and fascinating history,clip contain footage from around the state, while focusing on cityscapes.take note of the fashion (so many hats), architecture (many of the buildings still exist today), and transportation.  busses, streetcars, trolleys, automobiles, and a few horse-drawn carriages. Streets are wide and people seem to cross without fear,
the 1920s were a time of prosperity for many New Jerseyans. Cities were thriving at the time and we had several – Newark, Camden, and Jersey City, for example. The Holland Tunnel and Benjamin Franklin bridge were both completed during this decade, making transportation to New York and Philadelphia.

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance
✔added sound only for the ambiance
✔Frames restoration:(stabilisation,denoise,deblur)

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.
 black and white Source video: https://archive.org/details/6221_Sightseeing_in_Newark_N_J_01_42_49_21

For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page!  Thank You!

#1920s #Upscale #old #NJ #NewJersey

