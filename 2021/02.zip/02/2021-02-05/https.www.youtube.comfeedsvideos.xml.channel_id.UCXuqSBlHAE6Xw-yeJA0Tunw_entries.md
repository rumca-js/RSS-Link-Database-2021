# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## We can FINALLY Test This!! - Capture card latency
 - [https://www.youtube.com/watch?v=ZX7HnNd5PB4](https://www.youtube.com/watch?v=ZX7HnNd5PB4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-06 00:00:00+00:00

Shout out to VIZIO for sponsoring this video! Purchase the VIZIO M-Series Quantum 7 here: http://vizio.ink/BestBuy_MQ7
For all of VIZIO’s Top Deals, click here: https://www.vizio.com/en/shop/top-deals

Don’t forget to follow VIZIO on
Facebook: https://www.facebook.com/vizio/
Instagram: https://www.instagram.com/vizio/
and Twitter:  https://twitter.com/VIZIO

For all of their latest giveaways and sweepstakes!

VIZIO always recommends that you plug your gaming console directly into the display to achieve the best gaming experience.

What happens to your gaming experience when you add a capture card, a sound bar, or another video device between your gaming PC and your TV? Let’s find out…

Buy Elgato 4K60 PRO Capture Card (PAID LINK): https://geni.us/e82s
Buy Elgato HD60 S+ Capture Card (PAID LINK): https://geni.us/ySWNx
Buy Logitech G203 Lightsync Mouse (PAID LINK): https://geni.us/YHPfq
Buy AMD Ryzen 9 3900XT CPU (PAID LINK): https://geni.us/QmpH5
Buy Nvidia RTX 2080 Super (PAID LINK): https://geni.us/pGJpr

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1302823-we-can-finally-test-this/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## The DEATH of Cloud Gaming - WAN Show February 5, 2021
 - [https://www.youtube.com/watch?v=vKcnQQa2p1s](https://www.youtube.com/watch?v=vKcnQQa2p1s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-02-05 00:00:00+00:00

Start your build today at https://www.buildredux.com/linus

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus

Honey automatically applies the best coupon codes to save you money at 
different online checkouts, try it now at https://www.joinhoney.com/linus

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/The-DEATH-of-Cloud-Gaming---WAN-Show-February-5--2021-eq4bl1

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of MattDog_222)
0:00 Intro with Google Stadia changing 
1:49 Luke's take about Stadia
3:34 Linus's problem with what Google was doing
4:56 Talking about acquisition opportunities
6:38 Linus: The bigger problem with Stadia
8:24 One of the holy grail's of gaming: Fully destructible environments
9:50 Linus's prison escape simulator game idea
11:02 Game called "Teardown" discussion
11:53 The core idea of cloud gaming + Google lacking patience
13:26 Google's confusing mindset hypothetical example
14:22 Everyone knows games take a long time to develop (except Google)
16:05 GeForce Now has reached 6 Million members
16:48 Luke: Nvidia & Microsoft have good approaches
17:45 Xbox Series X example
18:40 Comparing to Nintendo Wii/Switch controller/accessory costs
19:59 Luke singing the song again + Linus trying to censor it live
20:26 Nvidia requiring companies to be transparent about RTX3000 specifications
21:57 Linus calling one of the writers about RTX3000 spec requirement
23:02 TDP not making much difference, but boost clocks are
25:01 Currently don't know much about the 80W vs. 150W (price, power usage, performance)
26:40 Luke enjoys Nvidia shooting themselves in the foot
27:44 What Linus thinks Nvidia needs (Intel like naming approach)
28:32 Is Linus still holding GME (Gamestop) stocks? (skip to 42:24)
29:05 Sponsor: Build Redux
30:28 Sponsor: Ridge Wallet
31:13 Sponsor: Honey
31:57 Luke tells us a story from his mom
34:18 Comparing old and current YouTube comments
36:23 Other people responding to comments for you
37:33 (Rumor) Apple VR Headset could cost $3,000
39:22 Linus worried about Apple's approach + How it might impact VR market
40:27 The Valve Index's VR problems comparison
42:24 Linus GME (Gamestop) stock update
44:34 (Floatplane chat) GPD video question
44:57 How Yvonne (wife) handled the GME stocks
47:28 Not LTT Store
48:14 LTTStore.com (New scarves)
49:54 Valve fined $4,000,000 on Steam controller
52:10 Linus: Gaming patents shouldn't last as long
54:18 NZXT Apologizes for safety issue on H1 case
56:30 Superchats
59:46 Linus's lifetime investments summary
1:02:17 Conclusion
1:02:41 Outro

