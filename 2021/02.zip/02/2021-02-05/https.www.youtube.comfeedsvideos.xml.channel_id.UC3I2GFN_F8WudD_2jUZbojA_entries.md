# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Shelter Fest Seattle 2020
 - [https://www.youtube.com/watch?v=rr7zISqX1S8](https://www.youtube.com/watch?v=rr7zISqX1S8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-06 00:00:00+00:00

http://KEXP.ORG presents a rebroadcast of selections from the livestream for Shelter Fest Seattle 2020, featuring Grace Love, Rell Be Free, Maya Marie, Gifted Gab, Da Qween, Black Stax and Clinton Fearon

Shelter Fest Seattle (https://www.shelterfestseattle.com/) is a community-driven, live-streamed benefit music festival providing direct support to Black artists and restaurant owners in the greater Seattle area during the pandemic.

While COVID-19 and the statewide shelter-in-place mandate disproportionately impact the arts and food service industries, Black artists and restaurant owners are some of the hardest hit. With the lack of support from the government, we believe that mutual aid and joint community efforts are some of the most critical ways we can show up for our community.

Support the Seattle Artists Relief Fund through this video or visit https://www.shelterfestseattle.com

## BEARAXE – Shelter Fest Seattle Performance
 - [https://www.youtube.com/watch?v=6VlNgzgM_Fg](https://www.youtube.com/watch?v=6VlNgzgM_Fg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-02-05 00:00:00+00:00

http://KEXP.ORG presents a rebroadcast of BEARAXE performing during Shelter Fest 2020. 

Shelter Fest Seattle (https://www.shelterfestseattle.com/) is a community-driven, live-streamed benefit music festival providing direct support to Black artists and restaurant owners in the greater Seattle area during the pandemic.

While COVID-19 and the statewide shelter-in-place mandate disproportionately impact the arts and food service industries, Black artists and restaurant owners are some of the hardest hit. With the lack of support from the government, we believe that mutual aid and joint community efforts are some of the most critical ways we can show up for our community.

Support the Seattle Artists Relief Fund through this video or visit https://www.shelterfestseattle.com

