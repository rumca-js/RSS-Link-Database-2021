# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Science of Why Bacon and Eggs Are the Perfect Match
 - [https://www.youtube.com/watch?v=6xEum2KHCyg](https://www.youtube.com/watch?v=6xEum2KHCyg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-02-06 00:00:00+00:00

Bacon and eggs aren’t a classic flavor combo for no reason, and the science behind why they taste so good together could help us make healthier foods more appealing to our palates. 



Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://pubmed.ncbi.nlm.nih.gov/10736353/ 
https://www.sciencedirect.com/topics/nursing-and-health-professions/umami 
https://www.pnas.org/content/105/52/20930.full 
https://academic.oup.com/ajcn/article/100/2/532/4576469 
https://www.nature.com/articles/s41598-020-77107-w 
https://www.tandfonline.com/doi/abs/10.1080/10408398.2012.678422 
https://www.nature.com/articles/s41386-018-0044-6 
https://www.google.com/books/edition/Mouthfeel/4WTYDQAAQBAJ 
https://journals.sagepub.com/doi/pdf/10.1177/1934578X1601101040
https://pubmed.ncbi.nlm.nih.gov/22544776/

Image Sources:
https://www.istockphoto.com/photo/prepared-bacon-gm162454194-22084312
https://www.istockphoto.com/photo/fried-egg-gm155358881-19332971
https://www.istockphoto.com/photo/smiling-and-positive-face-made-from-fried-eggs-and-bacon-on-plate-gm919919376-252870404
https://www.istockphoto.com/photo/sweet-and-sticky-chicken-wings-gm1221948697-358384548
https://www.istockphoto.com/photo/salmon-sashimi-freshness-fish-favorite-menu-of-japanese-food-gm1186556500-334829006
https://www.istockphoto.com/photo/sun-dried-tomatoes-fresh-champignons-mozzarella-and-basil-on-a-light-yellow-background-gm905438918-249659753
https://commons.wikimedia.org/wiki/File:L-Glutamate_Structural_Formulae.png
https://www.istockphoto.com/photo/miso-ramen-noodles-with-egg-enoki-and-pak-choi-gm479542154-68069433
https://www.istockphoto.com/vector/oysters-in-the-half-shell-icon-set-gm464423952-59019314
https://www.istockphoto.com/vector/champagne-bottle-and-champagne-glass-watercolor-painting-on-white-background-gm1254662727-366799716
https://www.istockphoto.com/photo/3d-rendering-of-a-luxury-restaurant-interior-at-night-gm1248298343-363558484
https://www.istockphoto.com/photo/woman-eating-a-delicacy-oyster-close-up-at-a-restaurant-gm1147404674-309492419
https://www.storyblocks.com/video/stock/bubbles-going-up-in-thin-flute-champagne-glasses-on-a-holiday-table-with-a-bottle-of-champagne-in-ice-basket-bnqfpnpazj9nhuvki
https://www.istockphoto.com/photo/monosodium-glutamate-known-in-europe-as-the-food-supplement-e621-crystals-close-up-gm1250098627-364499041
https://www.istockphoto.com/photo/dash-flexitarian-mediterranean-diet-to-stop-hypertension-low-blood-pressure-gm1181461877-331378726
https://www.istockphoto.com/photo/fried-bacon-and-eggs-in-iron-skillet-gm507519094-84776979

