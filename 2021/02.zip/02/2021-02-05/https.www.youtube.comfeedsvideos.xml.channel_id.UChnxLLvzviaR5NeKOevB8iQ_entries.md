# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Let's Talk About Ambient Ok? (Holohome SAW XXI Release)
 - [https://www.youtube.com/watch?v=2nUBTa1CqHg](https://www.youtube.com/watch?v=2nUBTa1CqHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-02-05 00:00:00+00:00

Here's my track, as a performance, on my second channel: https://youtu.be/KSL2QS_BpWI

All proceeds from the sale of the music will go to the ACLU - with intentions of preserving and protecting the liberties and privileges guaranteed to each individual by the Bill of Rights.

If you like this ambient music collection and want to support the ACLU, please visit the link below and pre-order a limited double tape or support with a digital edition purchase:

https://sawxxi.bandcamp.com/

Youtube Playlist:
https://www.youtube.com/playlist?list=PLjDR4lVhXMWeyQlifNh9mfEQV64FppKpf

Bandcamp for Compilation:
https://sawxxi.bandcamp.com/

Bandcamp for Holohome Label:
https://holohome.bandcamp.com/
--------------------------------
"Enabling artists to help others through music".

About Holohome Records: 
https://holohome.bandcamp.com

In 2020 we had an idea that we could self-fund and crowd-fund great music releases with the goal of the entirety of proceeds going directly to a charity of the artists choosing.
This is the first such release on this imprint - such an amazing community act. The art, the Bandcamp design, the videos, the music and the funding all came from members of the EZBOT Discord: 

https://discord.gg/a4X72Q8N
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

