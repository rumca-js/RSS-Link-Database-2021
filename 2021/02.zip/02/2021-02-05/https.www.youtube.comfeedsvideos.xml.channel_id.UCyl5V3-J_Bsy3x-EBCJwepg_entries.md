# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Babylon Bee Apologizes For Offensive Article About AOC
 - [https://www.youtube.com/watch?v=kvYLBuyGn6s](https://www.youtube.com/watch?v=kvYLBuyGn6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-06 00:00:00+00:00

Any comedy writer has to be willing to admit when he took things too far, and we at The Babylon Bee are no exception. We are formally clarifying and apologizing for this offensive Alexandria Ocasio-Cortez article, which many people took the wrong way. We will do better.

## The Bee Reads LOTR Episode 6: A Conspiracy and an Old Forest
 - [https://www.youtube.com/watch?v=6p46WtAHCys](https://www.youtube.com/watch?v=6p46WtAHCys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-06 00:00:00+00:00

Kyle, Dan, and Jonathan Watson, of TheOneRing.Com, guide you to Crickhollow, where Samwise Gamgee’s conspiracy is unmasked, and then on to a spooky ancient forest that tries to kill the hobbits. Then, as Kyle puts it, a “cracked out hobo” comes to rescue them. It’s two chapters this week on The Babylon Bee Reads The Lord of the Rings!

## Detective Andrew Cuomo Investigates NY Senior Deaths
 - [https://www.youtube.com/watch?v=khW1LDQcEfE](https://www.youtube.com/watch?v=khW1LDQcEfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-05 00:00:00+00:00

New York governor Andrew Cuomo investigates the sudden uptick in senior citizen deaths in the state of New York during 2020. Will he find the culprit?

See more Babylon Bee animation at: https://bit.ly/BeeAnimation

## Using The Internet To Make a Christian Movie And Bears Like Techno
 - [https://www.youtube.com/watch?v=Z_oD3bpBiLQ](https://www.youtube.com/watch?v=Z_oD3bpBiLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-05 00:00:00+00:00

Kyle and Ethan from The Babylon Bee talk about bears crashing a techno jam, spinach is now sending e-mails,  and how to generate a Christian movie using the internet. There’s weird news, stuff that’s good, and glorious hate mail.

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

