# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is There A CONSPIRACY Between Wall St & The Establishment?
 - [https://www.youtube.com/watch?v=IQXFDa3cYc0](https://www.youtube.com/watch?v=IQXFDa3cYc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-02-05 00:00:00+00:00

GameStop has been the unavoidable story of the last week - but what does the Establishment's response to it tell us about the economy and how power operates? 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join/ and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My Audible Original, ‘Revelation', is released on 25 March
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

GameStop Explained (video by CNET): 
https://www.youtube.com/watch?v=ZoPEaBAe0CY&ab_channel=CNET

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

