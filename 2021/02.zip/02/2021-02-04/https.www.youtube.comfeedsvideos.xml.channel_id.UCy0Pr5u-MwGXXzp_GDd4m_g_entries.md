# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## I Got a Guy (ft. Peter Mckinnon)
 - [https://www.youtube.com/watch?v=5Fp2wdzfsUU](https://www.youtube.com/watch?v=5Fp2wdzfsUU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-02-04 00:00:00+00:00

If you need a guy, we got 'em. The first 1000 people to use this link will get a free trial of Skillshare Premium Membership: https://skl.sh/julienolke02211

Huge thank you to Pete! Be sure to check out @PeterMcKinnon and the video we made here: https://youtu.be/C1-iojgjXIA

Written by: Julie Nolke
Actors: Peter McKinnon & Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay

Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke

