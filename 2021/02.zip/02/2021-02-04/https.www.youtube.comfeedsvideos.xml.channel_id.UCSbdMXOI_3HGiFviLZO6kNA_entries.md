# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Oculus Quest 3 CONFIRMED and the BIGGEST Quest update yet
 - [https://www.youtube.com/watch?v=sVPrQW62d9A](https://www.youtube.com/watch?v=sVPrQW62d9A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-02-05 00:00:00+00:00

Hello and welcome to TUESDAY (even if it's not on a TUESDAY) NEWSDAY! Your number one resource for the entire weeks worth of VR news. This week is late, i'm sorry fam. I'll be getting back on schedule next week I PROMISE. Sorry for it, BUT!! We have some HUGE news this week from a GIGANTIC Quest and Quest 2 update, Quest 3 is confirmed by facebook, and Apple has it's next big VR project leaked... Oh boy this is spicy. 

Post your VR memes to- 
https://www.reddit.com/r/ThrillSeeker/

Join in my AMAZING discord server-
Discord.gg/Thrill

My 2nd channel-
https://youtu.be/srCEOYjRS58

Twitch-
Twitch.TV/Thrilluwu

Patreon link:Join
https://www.patreon.com/Thrillseeker

GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Outro Music-
Protostar Overdrive

Sources-
https://www.roadtovr.com/zuckerberg-quest-2-mainstream-vr-headset-facebook-q4-2020-earnings/
https://www.roadtovr.com/gorn-release-oculus-quest-2-date/
https://www.roadtovr.com/magic-leap-rony-abovitz-sun-thunder-virtual-humans/
https://venturebeat.com/2021/01/27/magic-leap-founder-rony-abovitz-creates-startup-sun-and-thunder/
https://vrscout.com/news/facebook-oculus-quest-2-successor-development/
https://uploadvr.com/oculus-quest-2-south-korea-retail/
https://www.socialmediatoday.com/news/facebooks-oculus-vr-arm-outlines-significant-growth-announces-messenger-i/594387/
https://www.roadtovr.com/oculus-app-lab-quest-independent-distribution/
https://uploadvr.com/apple-headset-specs-price/
https://uploadvr.com/oculus-app-lab-future-of-vr-quest/
https://www.roadtovr.com/steam-survey-quest-2-most-used-headsets-steamvr-record-high/
https://uploadvr.com/gorn-oculus-quest-release-date-revealed/

