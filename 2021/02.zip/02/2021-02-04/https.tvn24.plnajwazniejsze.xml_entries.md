# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "To była dla mnie forma ukarania siebie"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-913,S00E913,452273?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-913,S00E913,452273?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2021-02-04 11:29:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nespp3-go-sklej-4-5008871/alternates/LANDSCAPE_1280" />
    Anoreksja w izolacji.

