# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Reddit vs Wallstreet - GameStop, The Movie
 - [https://www.youtube.com/watch?v=YFQ-v1jCpF0](https://www.youtube.com/watch?v=YFQ-v1jCpF0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-02-04 00:00:00+00:00

#wallstreetbets #reddit #rebellion #gamestop
Discord: https://discord.gg/r5VedvVq

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/collections/all
AUSTRALIA: https://shop.coldfusioncollective.com/

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 


If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.reuters.com/article/us-retail-trading-shortbets-idUSKBN29X1SW

https://dailycaller.com/2021/02/02/robinhood-hedge-funds-citadel-order-flows-gamestop-stock-market/

https://finance.yahoo.com/m/65802ac4-1d3f-3fec-bf5d-cb1c45e5cd5d/nine-investors-instantly-make.html

https://www.reuters.com/article/us-retail-investing-robinhood-congress/robinhood-ceo-expected-to-testify-before-u-s-house-committee-on-february-18-politico-idUSKBN2A13O2

https://www.cnbc.com/video/2021/01/27/bidens-economic-team-is-monitoring-gamestop-activity-psaki.html

https://hbr.org/2020/01/why-stock-buybacks-are-dangerous-for-the-economy

https://www.washingtonpost.com/business/2021/01/29/robinhood-citadel-gamestop-reddit/

https://www.cnbc.com/2021/02/02/treasury-secretary-janet-yellen-to-call-regulator-meeting-on-gamestop-volatility-seeks-ethics-waiver.html?utm_content=Main&utm_medium=Social&utm_source=Twitter#Echobox=1612317691

https://www.businessinsider.com.au/steve-cohen-ken-griffin-invest-3-billion-gamestop-short-seller-2021-1?r=US&IR=T

https://finance.yahoo.com/news/blackrock-may-raked-2-4-160353188.html

https://www.investors.com/etfs-and-funds/sectors/gme-stock-gamestop-investors-instantly-make-16-billion-gamestop-stock-squeeze/?src=A00220

https://www.reddit.com/r/wallstreetbets/comments/lax9pp/gme_yolo_update_down_another_7000000_still/

https://www.reddit.com/r/wallstreetbets/comments/lb2vle/down_400k_i_will_hold/

https://www.sun-sentinel.com/news/ny-keith-gill-drove-gamestop-reddit-mania-to-gains-worth-millions-20210130-couaill75vbylene6anbk7t3y4-story.html

https://www.sba.gov/advocacy/small-businesses-drive-job-growth-us#:~:text=shows%20that%20small%20businesses%20added,of%20the%20state's%20private%20workforce.

https://www.theguardian.com/technology/2021/jan/29/facebook-shuts-popular-robinhood-stock-traders-group-amid-gamestop-frenzy

https://www.forbes.com/sites/siladityaray/2021/02/02/robinhood-is-down-to-1-star-on-googles-mobile-app-store-again-this-time-google-wont-intervene/?sh=79d0ae8b7c84

https://tech.hindustantimes.com/tech/news/google-deletes-1-star-reviews-saves-robinhood-app-rating-from-massive-nosedive-71611945295584.html

https://www.theverge.com/2021/1/28/22255245/google-deleting-bad-robinhood-reviews-play-store

https://www.instagram.com/tv/CKpnz2bDM09/?igshid=jncf3h5bob6g

https://www.instagram.com/tv/CKrMDopJQ61/?igshid=1mfem6oqmg1hl


//Soundtrack//

**coming soon**

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

