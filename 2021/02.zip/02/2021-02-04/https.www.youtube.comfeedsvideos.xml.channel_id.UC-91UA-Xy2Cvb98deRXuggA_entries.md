# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## "YOU'RE TOXIC, and promote CORPORATE SLAVE CULTURE if you only work to get paid and go home'
 - [https://www.youtube.com/watch?v=C9h8JG6cE_I](https://www.youtube.com/watch?v=C9h8JG6cE_I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2021-02-05 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

## CEO Responds to being called a SCAM - Am I wrong or Is he In damage control? #grindreel #india
 - [https://www.youtube.com/watch?v=AxAzE-yyj-g](https://www.youtube.com/watch?v=AxAzE-yyj-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2021-02-04 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

