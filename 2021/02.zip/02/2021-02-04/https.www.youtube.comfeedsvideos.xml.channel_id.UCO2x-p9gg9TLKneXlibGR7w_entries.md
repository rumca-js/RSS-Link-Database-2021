# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The History of the Smartphone! (Sponsored by Huawei)
 - [https://www.youtube.com/watch?v=UsUBakHnzos](https://www.youtube.com/watch?v=UsUBakHnzos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2021-02-05 00:00:00+00:00

In this video (sponsored by Huawei), we take a look at the history of the smartphone, what the present holds, and what that may mean for the future.

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Asking someone what the first "smartphone" was will result in different answers. It's well-recognized that the 2007 iPhone inspired the modern-era of smartphones we enjoy today; however, smartphones go back much further than that. Most generally recognize IBM's Simon from the early 1990s as the first crack at what we'd consider a modern smartphone. The Simon could send email, pages, and faxes while also being able to make calls over a cellular (as well as landline lol) network! There have been lots of "firsts" in the smartphone industry and we take a look at just how far we've come and what may be in store for the future.

