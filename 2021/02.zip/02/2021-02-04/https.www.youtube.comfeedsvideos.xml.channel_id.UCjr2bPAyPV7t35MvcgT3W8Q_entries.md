# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## DON'T Use WhatsApp!
 - [https://www.youtube.com/watch?v=shpiVm1qpnw](https://www.youtube.com/watch?v=shpiVm1qpnw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-02-04 00:00:00+00:00

WhatsApp has always been a privacy nightmare. Use Signal and Matrix if you care about your privacy and security!
Join my channel and become a member to enjoy perks https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Delete WhatsApp: https://faq.whatsapp.com/android/account-and-profile/how-to-delete-your-account/?lang=en&_fb_noscript=1
Use Matrix (Element): https://element.io/
Use Signal: https://signal.org/

Sources
WhatsApp Privacy Policy: https://www.whatsapp.com/legal/updates/privacy-policy/?lang=en&_fb_noscript=1 
The WhatsApp-Facebook deal: https://money.cnn.com/2014/02/19/technology/social/facebook-whatsapp/index.html
Signal delivers end-to-end encryption to WhatsApp: https://signal.org/blog/whatsapp/
Jan Koum on Facebook's acquisition: https://blog.whatsapp.com/index.php/2014/02/facebook/?page=5&_fb_noscript=1
Acton and Koum leaving Facebook: https://www.washingtonpost.com/business/economy/whatsapp-founder-plans-to-leave-after-broad-clashes-with-parent-facebook/2018/04/30/49448dd2-4ca9-11e8-84a0-458a1aa9ac0a_story.html?
New WhatsApp privacy policy: https://www.bloomberg.com/news/articles/2021-01-15/whatsapp-delays-updated-privacy-policy-after-confusing-users
https://www.bloomberg.com/news/articles/2021-01-11/why-whatsapp-s-privacy-rules-sparked-moves-to-rivals-quicktake



Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

