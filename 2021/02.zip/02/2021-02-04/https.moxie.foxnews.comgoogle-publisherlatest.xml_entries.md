# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Best of political cartoons: Never Forget
 - [https://www.foxnews.com/politics/cartoons-slideshow](https://www.foxnews.com/politics/cartoons-slideshow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2021-02-04 17:33:23+00:00



