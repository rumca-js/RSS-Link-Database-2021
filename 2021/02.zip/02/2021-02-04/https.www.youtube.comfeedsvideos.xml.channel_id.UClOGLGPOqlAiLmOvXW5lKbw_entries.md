# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Thief: The Dark Project Review
 - [https://www.youtube.com/watch?v=UBN5k6WoG-s](https://www.youtube.com/watch?v=UBN5k6WoG-s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2021-02-05 00:00:00+00:00

Thief The Dark Project is one of the ultimate stealth games but there are Thief 2 fans to argue with on that. The review also covers Thief Gold stuff!
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
00:55 - Fixes & EAX Sound Restoration
02:21 - Game Premise
3:40 - Visuals
5:14 - Music & Sound Design
8:40 - Gameplay Mechanics
13:09 - Levels & Pacing
18:59 - Storytelling
21:38 - Story (SPOILERS)
27:25 - Conclusions
28:20 - Credits
29:25 - Impregnable Defense

#Thief #Thief1 #ThiefReview #ThieftheDarkProject #ThiefPC #ThiefGame #ThiefGameReview #ThiefGold

