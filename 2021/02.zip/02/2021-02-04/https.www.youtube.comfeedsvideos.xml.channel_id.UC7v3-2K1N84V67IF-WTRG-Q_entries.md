# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## WandaVision - Episode 5 (My Thoughts)
 - [https://www.youtube.com/watch?v=a1fTO9vdfOg](https://www.youtube.com/watch?v=a1fTO9vdfOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-02-05 00:00:00+00:00

The intrigue ramps up with the tension. Here are my thoughts on Episode 5 of #WandaVision

