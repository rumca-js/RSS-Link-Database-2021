# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Why The Hobbit Trilogy Failed To Equal Lord Of The Rings
 - [https://www.youtube.com/watch?v=Il-0pW6BNSs](https://www.youtube.com/watch?v=Il-0pW6BNSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-02-05 00:00:00+00:00

The Hobbit trilogy is one of the most disappointing things since... well, most of modern entertainment. And I think it's about time I explained why these movies are so terrible.

