# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Huawei Mate Xs Impressions: The Hottest Foldable!
 - [https://www.youtube.com/watch?v=9zkFfBVgVtI](https://www.youtube.com/watch?v=9zkFfBVgVtI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-02-05 00:00:00+00:00

This folding phone is hot. But it's still not practical.

On the outward fold: https://youtu.be/4oco9pLw13E

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

