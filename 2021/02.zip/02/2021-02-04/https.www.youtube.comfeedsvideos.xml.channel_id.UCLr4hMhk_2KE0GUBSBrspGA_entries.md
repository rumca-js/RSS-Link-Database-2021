# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Devialet Gemini - słuchawki dla bogaczy
 - [https://www.youtube.com/watch?v=Fg3KobMDwN8](https://www.youtube.com/watch?v=Fg3KobMDwN8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-02-04 00:00:00+00:00

Czy są lepsze od słuchawek Bose? W tym filmie znajdziecie na to pytanie odpowiedź. I być może na kilka innych też :)

Ceny (ceneo):
Devialet Gemini: http://bit.ly/3q1tQVu
Bose QuietComfort Earbuds: http://bit.ly/3tliL3M

W odcinku:
00:00 Firma Devialet – produkty
00:27 Słuchawki dla bogaczy: Devialet Gemini i Bose QuietComfort
01:06 Wygląd – gumki
01:49 Dopasowanie do ucha – wygoda noszenia
02:41 Aktywna redukcja szumu
03:06 Brzmienie
03:28 Sterowanie
03:53 Mikrofony: Devialet Gemini vs Bose QuietComfort
04:32 Baterie
04:59 Łączenie z aplikacją
06:24 Czy warto je kupić?
07:17 Zakończenie

Moje sociale: 
Twitter: https://twitter.com/KubaKlawiter
Tiktok: https://vm.tiktok.com/ZSwcvjTo​
Insta: https://www.instagram.com/kubaklawiter/
FB: https://www.facebook.com/Kuba.Klawiterr

