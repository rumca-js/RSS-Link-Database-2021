# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## What I Like About You // The Romantics // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=MzEqcRRIamA](https://www.youtube.com/watch?v=MzEqcRRIamA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-02-04 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Please sit back, relax, and enjoy this spacey slow jam reinterpretation of The Romantics' "What I Like About You."

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar: Ryan Lerman
Bass: Nick Campbell
Drums: Tamir Barzilay
Additional keys/percussion: Ben Rose
Background Vocals: Nahneen Kula

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Tyler Karmen
Mixing/Mastering: Yianni AP
Producer: Ben Rose

VIDEO CREDITS
Director: George Sloan
DP: Ricky Chavez
Camera Operators: Ricky Chavez, Merlin Showalter, Sammy Rothman, Dijon Herron
Video Editor: Athena Wheaton

Recorded at 64 Sound in Los Angeles.

#Pomplamoose #IndieRock #WhatILikeAboutYou #TheRomantics

LYRICS
Hey
Uh huh huh
Hey
Uh huh huh

What I like about you
You hold me tight
Tell me I'm the only one
Wanna come over tonight, yeah

Keep on whispering in my ear
Tell me all the things that I wanna hear
'Cause it's true
That's what I like about you

What I like about you
You really know how to dance
When you go up, down, jump around
Think about true romance, yeah

Keep on whispering in my ear
Tell me all the things that I wanna hear
'Cause it's true
That's what I like about you
That's what I like about you
That's what I like about you

Hey

What I like about you
You keep me warm at night
Never wanna let you go
Know you make me feel all right, yeah

Keep on whispering in my ear
Tell me all the things that I wanna hear
'Cause it's true
That's what I like about you
That's what I like about you
That's what I like about you
That's what I like about you
That's what I like about you
That's what I like about you
That's what I like about you

Hey
Uh huh huh
Hey, hey, hey, hey
Uh huh huh, brr
Hey
Uh huh huh
Hey

