# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Annual Coffeezilla Shareholder Meeting $ZILA
 - [https://www.youtube.com/watch?v=EtJRDDeYCTg](https://www.youtube.com/watch?v=EtJRDDeYCTg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-04 00:00:00+00:00

$ZILA 🚀🚀🚀🚀🚀
CYBERPUNK 2077 WAR
SHAREHOLDER MEETING

twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.
#coffeezilla #shareholdersmeeting

## SEC is Investigating r/WallStreetBets for "Fraud", RobinHood CEO says:
 - [https://www.youtube.com/watch?v=xtHAv4ifPcE](https://www.youtube.com/watch?v=xtHAv4ifPcE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-02-04 00:00:00+00:00

Pack up your subreddit boys, the cops are coming. 🚨🚨🚨🚨
According to Bloomberg: 
U.S. Securities and Exchange Commission investigators are combing social media and message board posts for signs that fraud played a role in dizzying stock swings for GameStop Corp., AMC Entertainment Holdings Inc. and other companies, according to people familiar with the matter.
https://www.bloomberg.com/news/articles/2021-02-03/sec-hunts-for-fraud-in-social-media-posts-that-drove-up-gamestop
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

