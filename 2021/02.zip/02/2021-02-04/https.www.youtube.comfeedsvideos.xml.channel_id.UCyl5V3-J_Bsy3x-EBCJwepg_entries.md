# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Detective Andrew Cuomo Investigates NY Senior Deaths
 - [https://www.youtube.com/watch?v=khW1LDQcEfE](https://www.youtube.com/watch?v=khW1LDQcEfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-05 00:00:00+00:00

New York governor Andrew Cuomo investigates the sudden uptick in senior citizen deaths in the state of New York during 2020. Will he find the culprit?

See more Babylon Bee animation at: https://bit.ly/BeeAnimation

## Using The Internet To Make a Christian Movie And Bears Like Techno
 - [https://www.youtube.com/watch?v=Z_oD3bpBiLQ](https://www.youtube.com/watch?v=Z_oD3bpBiLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-02-05 00:00:00+00:00

Kyle and Ethan from The Babylon Bee talk about bears crashing a techno jam, spinach is now sending e-mails,  and how to generate a Christian movie using the internet. There’s weird news, stuff that’s good, and glorious hate mail.

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

