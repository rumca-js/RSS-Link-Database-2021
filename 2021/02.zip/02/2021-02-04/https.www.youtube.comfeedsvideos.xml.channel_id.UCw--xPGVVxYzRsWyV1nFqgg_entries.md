# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Lan Mandragoran Avengers Interview
 - [https://www.youtube.com/watch?v=j_-REwjPwFY](https://www.youtube.com/watch?v=j_-REwjPwFY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-02-05 00:00:00+00:00

Lan Mandragoran tries out for Marvel's Avengers.... because I am bored. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## LET'S DEBATE: Morality Thru Tech? Bad Characters in Scifi?
 - [https://www.youtube.com/watch?v=YQ0lG17FBYk](https://www.youtube.com/watch?v=YQ0lG17FBYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-02-04 00:00:00+00:00

Let us debate some scifi genre things my dudes!! 

Art Provided by: https://www.instagram.com/yoichi.art/

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

