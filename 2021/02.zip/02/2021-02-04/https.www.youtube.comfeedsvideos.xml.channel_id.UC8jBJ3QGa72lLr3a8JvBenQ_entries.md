## Apashe - Uebok VIP [Music Video]
 - [https://www.youtube.com/watch?v=gM4xZy39kNE](https://www.youtube.com/watch?v=gM4xZy39kNE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8jBJ3QGa72lLr3a8JvBenQ
 - date published: 2021-02-05 00:00:00+00:00

Uebok Gotta Run faster now cuz there are more bears everywhere. Enjoy this VIP (variation in production) of Uebok. 🏴

Stream Renaissance Remixes: https://bit.ly/Rennaissance_Remixes

Special thanks to IRO Pictures for remixing the video with those crazy VFX ! 🏴

--

Follow Apashe:
https://www.facebook.com/Apashe.Official
https://www.instagram.com/apashe
https://twitter.com/Apashe_Music
https://soundcloud.com/apashe

Follow Instasamka: 
https://www.instagram.com/instasamka
https://twitter.com/samkaofficial
https://soundcloud.com/instasamka

Video credits

Directors: Adrian Villagomez & John de Buck
Director of photography: Adrian Villagomez

Production coordinator Moscow: Marinka Guseva
Production coordinator Nizhny Novgorod: Katya Tebekina

Drifter: Artem Egiazarov
Dancer: Vitaliy Ulivanov
Hunter: Mikhail Mukhin
Drivers: Elia Fedorova, Ksenia Kruglova
Editor: Adrien Taret
Color grading: Charles Etienne Pascal
3D Supervisor: Alan Jonathan Iriarte
VFX Producer: Vijesh Rajwani 
VFX Supervisor: Ignacio Caicoya

With the participation of (спасибо): Vogue Diary, Diana Melison, Mark Sanevich, Melvin Laur, Anton Tereshchenko, Vladyslav Kampov, Michail Golovko, Ilya Velikanov, Alexey Gorin, Oleg Skopin, Mark Zaytsev, Milyakov Stanislav, Anton Bardin, Maxim Nagarkin, Eugene Shlikov.

