# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## DIABLO 4 RELEASE DATE CHANGED, EA DETAILS BIG BATTLEFIELD 6 CHANGES, & MORE
 - [https://www.youtube.com/watch?v=6DdEhA9CjmQ](https://www.youtube.com/watch?v=6DdEhA9CjmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-05 00:00:00+00:00

Brought to you by Raycon. Go to https://buyraycon.com/gameranx for 15% off your order! 

Subscribe for more: https://www.youtube.com/gameranxTV?su​...


Follow:
 Instagram: https://goo.gl/HH6mTW​

Twitter: https://bit.ly/3deMHW7​


 ~~~~STORIES~~~~


Battlefield 6 news
https://www.techradar.com/news/battlefield-6-will-feature-massive-immersive-battles-on-ps5-and-xbox-series-x
https://wccftech.com/battlefield-6-unscripted-skyscrapers-destruction/
Tech demo: https://www.youtube.com/watch?v=jMQ4n2922qI&ab_channel=GameSpot

Mass Effect Legendary Edition
https://youtu.be/n8i53TtQ6IQ


Weird year for Activision blizzard
https://www.pcgamer.com/overwatch-2-and-diablo-4-wont-be-out-this-year-blizzard-says/#:~:text=%22Our%20outlook%20does%20not%20include,to%20arrive%20later%20in%202021


Leaked Goldeneye
https://www.theverge.com/2021/2/5/22267913/goldeneye-007-xbox-360-live-arcade-nintendo-64-remake-remaster-rare


I am Jesus Christ gameplay
https://youtu.be/LZzT2pubnDw?t=804

Destruction All Stars launch trailer
https://youtu.be/-I4D7bsszsc

Before You Buy Werewolf
https://youtu.be/g8nZvhHcBYE

MGS3 in MGSV
https://www.reddit.com/r/metalgearsolid/comments/las904/mgsv_or_mgs3/?utm_content=title&utm_medium=post_embed&utm_name=eb1db4bd265d480fb5664c4f7bdbdb93&utm_source=embedly&utm_term=las904

Making of Hitman good read
https://www.gamesradar.com/the-making-of-hitman-codename-47/?utm_campaign=socialflow&utm_medium=social&utm_content=gamesradar&utm_source=facebook.com&fbclid=IwAR3cX3XUQsTShvYuBLq38CVE4DM2a0AxtqrmGsVo3I0BIXN8EcY3XBVbN0g


Stadia
https://www.ft.com/content/9cd27dce-cee0-46aa-a2fa-48971c1dfe4f

## Werewolf: The Apocalypse - Earthblood - Before You Buy
 - [https://www.youtube.com/watch?v=g8nZvhHcBYE](https://www.youtube.com/watch?v=g8nZvhHcBYE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-05 00:00:00+00:00

Werewolf: The Apocalypse - Earthblood (PC, PS5, PS4, Xbox) is a werewolf game with a unique spin and a beloved mythology backing it up. How is it? Let's talk.

Subscribe for more: https://www.youtube.com/gameranxTV?su...​

​


Watch more 'Before You Buy': https://bit.ly/2kfdxI6​

## PS5 Official Accessories: ARE THEY WORTH IT?
 - [https://www.youtube.com/watch?v=-m7FFXMx6Gc](https://www.youtube.com/watch?v=-m7FFXMx6Gc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-02-04 00:00:00+00:00

A review of the Sony branded PS5 accessories. PS5 official accessories are often more available than the console hardware itself. Many people buy them, but... do you really need them? We take a look.
Subscribe for more: http://youtube.com/gameranxtv

