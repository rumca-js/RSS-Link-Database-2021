# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Curious Expedition 2 | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=7BLBBIl9BDc](https://www.youtube.com/watch?v=7BLBBIl9BDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-02-05 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Jesse Galena reviews Curious Expedition 2, developed by 
Maschinen-Mensch.

Curious Expedition 2 on Steam: https://store.steampowered.com/app/1040230/Curious_Expedition_2/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Werewolf: the Apocalypse - Earthblood | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=HIEXN0N0AGA](https://www.youtube.com/watch?v=HIEXN0N0AGA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-02-04 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

KC Nwosu reviews Werewolf: The Apocalypse - Earthblood, developed by Cyanide Studio. 

Werewolf: The Apocalypse - Earthblood on EGS: https://www.epicgames.com/store/en-US/product/werewolf-the-apocalypse-earthblood/home

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

