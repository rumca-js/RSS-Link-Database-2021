# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## I Asked Bill Gates What's The Next Crisis?
 - [https://www.youtube.com/watch?v=Grv1RJkdyqI](https://www.youtube.com/watch?v=Grv1RJkdyqI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-02-04 00:00:00+00:00

I got the chance to interview Bill Gates so I asked him: Will Covid-19 be the last pandemic? How does he deal with misinformation and conspiracy theories? And what is the next disaster? The Foundation Letter is here: https://ve42.co/BG21

Special thanks to Patreon supporters:
Ludovic Robillard, jim buckmaster, Robert, fanime96, Marc Forand, Juan Benet, Robert Blum, Grace O'Maille KRON x Arc iOS, Richard Sundvall, Lee Redden, Vincent, Lyvann Ferrusca, Alfred Wallace, Arjun Chakroborty, Joar Wandborg, Clayton Greenwell, Pindex , Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal

Thanks to Petr Lebedev for the thumbnail, early edits and Jonny Hyman for feedback

