# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Why Emotional Tears Are Different
 - [https://www.youtube.com/watch?v=Rrle0mD92WU](https://www.youtube.com/watch?v=Rrle0mD92WU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-02-04 00:00:00+00:00

Emotional vs. physical tears, why are they different?
Try Dashlane Premium free on your first device: https://www.dashlane.com/asapscience
Check out our podcast channel: https://youtube.com/sidenotepodcast​
Join our mailing list: https://bit.ly/34fWU27​

Written by Gregory Brown
Editing by Luka Šarlija

FOLLOW US!
AsapSCIENCE
TikTok: @AsapSCIENCE 
Instagram: https://instagram.com/asapscience​
Facebook: https://facebook.com/asapscience​
Twitter: https://twitter.com/asapscience

REFERENCES: 
Adult Crying: A Biopsychosocial Approach - AJJM Vingerhoets, RR Cornelius - 2012
https://www.routledge.com/Adult-Crying-A-Biopsychosocial-Approach/Vingerhoets-Cornelius/p/book/9780415645720
https://www.frontiersin.org/articles/10.3389/fpsyg.2020.02134/full
https://www.psypost.org/2020/12/eye-tracking-study-suggests-that-other-peoples-tears-act-as-a-magnet-for-our-visual-attention-58821
https://pediatrics.aappublications.org/content/29/4/579.short
https://psycnet.apa.org/record/2020-66680-001
https://pediatrics.aappublications.org/content/145/6/e20192719
https://onlinelibrary.wiley.com/doi/full/10.1002/ejp.1623
https://onlinelibrary.wiley.com/doi/full/10.1002/dev.22058
https://psycnet.apa.org/record/2020-87337-001

