# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Using a Bunch of Mousetraps to Explain How Pandemics Work (feat. @theslowmoguys)
 - [https://www.youtube.com/watch?v=Et_J8_x4qBs](https://www.youtube.com/watch?v=Et_J8_x4qBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-02-04 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

More vaccine info here: https://www.cdc.gov/vaccines/vac-gen/default.htm 
Special thanks to @theslowmoguys ! https://www.youtube.com/user/theslowmoguys 

Thanks to Gates Notes for Supporting PBS.

Since the start of the coronavirus COVID-19 pandemic, the term “herd immunity” has been all over the news. But what does it really mean? One thing most people don’t realize about vaccines is that they aren’t just to protect the person who gets the shot. They also protect the population as a whole… even people who didn’t get the shot. In this video, we use lots and lots of mousetraps and ping-pong balls to show you how that works. #coronavirus #vaccines

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

References:  https://sites.google.com/view/mousetrap-herd-immunity/home

-----------

Special thanks to our Brain Trust Patrons:

dani bowman
David Johnston
Ahmed Elkhanany
Zenimal
Salih Arslan
Baerbel Winkler
Denzel Holmes
Robert Young
Amy Sowada
Benjamin Teinby
Eric Meer
Jay Stephens
Peter Ehrnstrom
Dustin
Marcus Tuepker
Karen Haskell
AlecZero 
Diego Lombeida

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

