# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## HarmonyOS is here, but it's disappointing
 - [https://www.youtube.com/watch?v=hXL50Zcr-sI](https://www.youtube.com/watch?v=hXL50Zcr-sI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-02-05 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc 

You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us. 


▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► This video ◄◄◄

Huawei has just released Harmony OS 2.0 as a developer beta. Turns out, it's just Android 10 in a disguise! Let's see how they compare: Harmony OS vs Android!

The Friday Checkout - Episode 34

Ron's Harmony OS analysis: https://arstechnica.com/gadgets/2021/02/harmonyos-hands-on-huaweis-android-killer-is-just-android/?comments=1


My original video on Harmony OS 2.0: https://www.youtube.com/watch?v=E9yFiZHXWi4

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄

Our Weekly Tech Knowledge Quiz is available:

In the Crrowd app: https://play.google.com/store/apps/details?id=com.crrowd
On the web: https://crrowd.com/quiz

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 


▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions ◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Time stamps ◄◄◄

0:00 Intro
0:38 Harmony OS disappoints
4:25 Goodbye, Stadia games
5:40 Internet-breaking laws


#Huawei #HarmonyOS #Android

