# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## TechScape: Why ‘hacker summer camp’ and pandemics don’t mix
 - [https://www.theguardian.com/technology/2021/aug/04/why-hacker-summer-camp-and-pandemic-precautions-dont-mix](https://www.theguardian.com/technology/2021/aug/04/why-hacker-summer-camp-and-pandemic-precautions-dont-mix)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-08-04 10:56:50+00:00

<p>Up for discussion in the Guardian tech newsletter: DEF CON hit by Covid concerns … Zuckerberg enters the Metaverse … and the impact of Final Fantasy VII</p><p>In a normal year, I would be getting on a plane today and travelling to Las Vegas for the loose conglomeration of events informally known as “Hacker Summer Camp”. Centred around <a href="https://defcon.org/">DEF CON</a> and its stuffy younger sibling Black Hat, the event sees Las Vegas taken over by hackers, information security specialists, spooks and criminals, all there to discuss the best ways to defend computers against hostile adversaries – and to break into those same computers as quickly as possible.</p> <a href="https://www.theguardian.com/technology/2021/aug/04/why-hacker-summer-camp-and-pandemic-precautions-dont-mix">Continue reading...</a>

