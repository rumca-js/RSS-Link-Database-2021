## Why Don’t Tech Companies Pay Their Engineers to Stay? | by Matthew Dean | Jul, 2021 | Marker
 - [https://marker.medium.com/why-dont-tech-companies-pay-their-engineers-to-stay-b9c7e4b751e9](https://marker.medium.com/why-dont-tech-companies-pay-their-engineers-to-stay-b9c7e4b751e9)
 - RSS feed: https://marker.medium.com
 - date published: 2021-08-04 22:33:49.064295+00:00

Staying in a role builds valuable, company-specific domain knowledge. Leaving often results in a pay day.

