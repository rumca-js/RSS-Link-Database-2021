# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Video Game Things You Won't Believe EXIST In Real Life
 - [https://www.youtube.com/watch?v=XqwZr08LKas](https://www.youtube.com/watch?v=XqwZr08LKas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-05 00:00:00+00:00

Some larger-than-life video game concepts actually exist in our real world. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Free Games With TERRIBLE PAY TO WIN Mechanics
 - [https://www.youtube.com/watch?v=xfufsELKMpQ](https://www.youtube.com/watch?v=xfufsELKMpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-04 00:00:00+00:00

Many free games have microtransactions and in-game purchases, but certain ones take it WAY too far. Here are some examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

