# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Meghan launches female mentorship program to mark her 40th birthday
 - [https://www.cnn.com/2021/08/04/us/meghan-female-mentorship-scli-intl/index.html](https://www.cnn.com/2021/08/04/us/meghan-female-mentorship-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 23:53:39+00:00

To mark her 40th birthday, Meghan, the Duchess of Sussex, has launched a mentorship program to support women getting back into the workforce after the pandemic.

## Journalist was at a cafe when Taliban attacked. Hear his story
 - [https://www.cnn.com/videos/world/2021/08/04/ali-latifi-afghanistan-chants-taliban-attack-oneworld-vpx.cnn](https://www.cnn.com/videos/world/2021/08/04/ali-latifi-afghanistan-chants-taliban-attack-oneworld-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 20:28:11+00:00

Journalist Ali Latifi discusses the scene in the capital and largest city of Afghanistan, Kabul, after the blast from the Taliban.

## See the dried up reservoir that's shutting down a power plant
 - [https://www.cnn.com/videos/weather/2021/08/04/lake-oroville-california-drought-power-plant-orig-jk.cnn](https://www.cnn.com/videos/weather/2021/08/04/lake-oroville-california-drought-power-plant-orig-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 20:11:48+00:00

Lake Oroville, a reservoir that provides water for a hydroelectric power plant in California, is so low that it must be shut down for the first time since it opened in the 60's.

## Andrew Cuomo long claimed to be a champion against sexual harassment and attacked GOP politicians for staying silent
 - [https://www.cnn.com/collections/cuomo-intl-080321/](https://www.cnn.com/collections/cuomo-intl-080321/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 19:14:25+00:00



## Cuomo long claimed to be champion against sexual harassment and attacked Republicans for silence
 - [https://www.cnn.com/2021/08/04/politics/kfile-andrew-cuomo-past-comments/index.html](https://www.cnn.com/2021/08/04/politics/kfile-andrew-cuomo-past-comments/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 19:01:34+00:00

• Analysis: Cuomo's utterly disastrous response to AG report findings
• Report spotlights Cuomo brothers' relationship

## Real estate tycoon Robert Durst, accused of killing his close friend, to take the stand today
 - [https://www.cnn.com/2021/08/04/us/robert-durst-testimony/index.html](https://www.cnn.com/2021/08/04/us/robert-durst-testimony/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 17:52:46+00:00

Robert Durst, the multimillionaire subject of the HBO crime documentary "The Jinx," is expected to take the witness stand in his defense Wednesday, his legal team told CNN, heaping more drama onto an already sensational murder trial.

## The speed of the US economic recovery has been record-breaking. But don't get used to it
 - [https://www.cnn.com/2021/08/04/perspectives/us-economic-recovery-speed-slowing/index.html](https://www.cnn.com/2021/08/04/perspectives/us-economic-recovery-speed-slowing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 17:49:47+00:00

Despite the continued optimism about the country reopening, US economic growth is already starting to slow.

## WHO calls for moratorium on booster shots until at least September to enable more widespread vaccination
 - [https://www.cnn.com/collections/covid-intl-080421/](https://www.cnn.com/collections/covid-intl-080421/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 17:33:43+00:00



## ABC News: Trump loyalist at DOJ circulated draft Georgia letter with false election fraud claims
 - [https://www.cnn.com/2021/08/04/politics/draft-doj-georgia-letter-election-reversal/index.html](https://www.cnn.com/2021/08/04/politics/draft-doj-georgia-letter-election-reversal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 17:07:26+00:00

A draft letter reportedly circulated late last year by a Donald Trump-loyalist at the Justice Department shows the lengths his allies were willing to go to overturn the presidential election.

## Rihanna is now officially a billionaire and the wealthiest female musician
 - [https://www.cnn.com/2021/08/04/business/rihanna-billionaire-forbes/index.html](https://www.cnn.com/2021/08/04/business/rihanna-billionaire-forbes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 16:40:31+00:00

Robyn "Rihanna" Fenty is officially a billionaire, according to Forbes.

## Lizzo started a rumor she's pregnant with Chris Evans' baby and he loves it
 - [https://www.cnn.com/2021/08/04/entertainment/lizzo-chris-evans-trnd/index.html](https://www.cnn.com/2021/08/04/entertainment/lizzo-chris-evans-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 16:35:19+00:00

Lizzo and Chris Evans are having lots of fun with their very public flirtation.

## WHO calls for a moratorium on booster shots until at least the end of September
 - [https://www.cnn.com/2021/08/04/health/who-coronavirus-booster-shots/index.html](https://www.cnn.com/2021/08/04/health/who-coronavirus-booster-shots/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 16:22:25+00:00

The World Health Organization is calling for a moratorium on booster shots until at least the end of September, WHO director-general Tedros Adhanom Ghebreyesus said during a news briefing in Geneva on Wednesday.

## Obama scales back big birthday bash amid Covid worries
 - [https://www.cnn.com/2021/08/04/politics/obama-60th-birthday-party-scale-back/index.html](https://www.cnn.com/2021/08/04/politics/obama-60th-birthday-party-scale-back/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 15:57:25+00:00

Former President Barack Obama has dramatically scaled back his planned 60th birthday party on Martha's Vineyard this weekend due to concerns about the highly transmissible Delta variant of Covid-19, according to a spokeswoman.

## Hubble captures stunning image of squabbling galaxies
 - [https://www.cnn.com/2021/08/04/world/hubble-squabbling-siblings-galaxies-scn/index.html](https://www.cnn.com/2021/08/04/world/hubble-squabbling-siblings-galaxies-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 15:49:35+00:00

A galactic sibling rivalry is taking place millions of light-years away, and the Hubble Space Telescope has captured it in a stunning image.

## 33 years ago, I was in the same room with Iran's new president when he voted to execute political prisoners
 - [https://www.cnn.com/2021/08/04/opinions/ebrahim-raisi-1988-iran-political-prisoner-executions-royaei/index.html](https://www.cnn.com/2021/08/04/opinions/ebrahim-raisi-1988-iran-political-prisoner-executions-royaei/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 15:40:12+00:00

August 3, 2021, marked the start of Ebrahim Raisi's four-year term as president of Iran. The validation ceremony took place in the "Beyt" (Arabic for "house") of the Supreme Leader, Ayatollah Ali Khamenei, as a prelude to Raisi's inauguration.

## Sean Combs on life without Kim Porter and posting that throwback Jennifer Lopez photo
 - [https://www.cnn.com/2021/08/04/entertainment/sean-combs-kim-porter-jennifer-lopez/index.html](https://www.cnn.com/2021/08/04/entertainment/sean-combs-kim-porter-jennifer-lopez/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 15:37:38+00:00

Sean "Diddy" Combs believes he's been given a second chance.

## Floods are getting worse, and the number of people exposed is 10 times higher than previously thought, study finds
 - [https://www.cnn.com/2021/08/04/weather/global-flood-risk-climate-change/index.html](https://www.cnn.com/2021/08/04/weather/global-flood-risk-climate-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 15:03:12+00:00

Amid a deadly summer of flooding in different parts of the world, scientists have found the number of people at risk to extreme flooding has grown significantly in the past two decades.

## Trump asks court to end House pursuit of his tax returns from IRS
 - [https://www.cnn.com/2021/08/04/politics/trump-tax-returns-response/index.html](https://www.cnn.com/2021/08/04/politics/trump-tax-returns-response/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 15:01:49+00:00

Former President Donald Trump's legal team formally stepped into a long-running fight over a US House request for his tax returns, claiming Trump's financial history is being unfairly pursued for political reasons by Democrats and seeking to end House Ways and Means Committee investigations into the ex-President and his companies.

## Christian Eriksen reunited with Inter teammates as he begins road to recovery
 - [https://www.cnn.com/2021/08/04/football/christian-eriksen-inter-milan-spt-intl/index.html](https://www.cnn.com/2021/08/04/football/christian-eriksen-inter-milan-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 14:54:34+00:00

Christian Eriksen has returned to the Inter Milan training ground for the first time since suffering a cardiac arrest while playing for Denmark at Euro 2020, the Italian club said on Wednesday.

## Democrats are losing the messaging war, according to Democrats
 - [https://www.cnn.com/2021/08/04/politics/democrats-house-2022/index.html](https://www.cnn.com/2021/08/04/politics/democrats-house-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 14:46:37+00:00

These two paragraphs from Politico are eye-opening:

## Doctor: 'Nauseating' these governors forbid mask mandates
 - [https://www.cnn.com/videos/health/2021/08/04/dr-jorge-rodriguez-anti-mask-mandates-gop-governors-sot-vpx.cnn](https://www.cnn.com/videos/health/2021/08/04/dr-jorge-rodriguez-anti-mask-mandates-gop-governors-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 14:17:56+00:00

Dr. Jorge Rodriguez, an internal medicine specialist and viral researcher, criticizes GOP governors Greg Abbott and Ron DeSantis for banning mask mandates in schools, calling it the "wrong thing to do" as coronavirus case counts rise in the US.

## Frontier Airlines now supports flight crew who restrained man who allegedly assaulted them
 - [https://www.cnn.com/travel/article/frontier-airlines-flight-crew-assault/index.html](https://www.cnn.com/travel/article/frontier-airlines-flight-crew-assault/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 13:59:40+00:00

Frontier Airlines now says it "supports" and will pay the crew of flight attendants it had earlier said were suspended after restraining a passenger charged with groping and punching them.

## Offspring drummer says band axed him from tour for not getting vaccinated
 - [https://www.cnn.com/2021/08/04/entertainment/offspring-pete-parada-vaccine-trnd/index.html](https://www.cnn.com/2021/08/04/entertainment/offspring-pete-parada-vaccine-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 13:47:55+00:00

Pete Parada says he's been dropped from his band The Offspring and their tour over his refusal to get vaccinated.

## Giraffes have been misunderstood and are just as socially complex as elephants, study says
 - [https://www.cnn.com/2021/08/04/africa/giraffes-complex-behavior-scn/index.html](https://www.cnn.com/2021/08/04/africa/giraffes-complex-behavior-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 13:18:51+00:00

With their crane-like necks, spindle legs and knobbly knees, giraffes are among the best loved and most recognizable of animals.

## Nearly 2 million lives were lost. Now divers search for remains
 - [https://www.cnn.com/travel/article/searching-for-slave-ship-wrecks-scn/index.html](https://www.cnn.com/travel/article/searching-for-slave-ship-wrecks-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 13:12:38+00:00

As he slipped through the kelp forest to the bottom of the Atlantic Ocean, Kamau Sadiki's eyes hooked onto something resembling the item he and fellow divers had been searching for.

## Avlon: Carlson is flirting with authoritarian leader
 - [https://www.cnn.com/videos/media/2021/08/04/tucker-carlson-viktor-orban-hungary-avlon-reality-check-vpx.cnn](https://www.cnn.com/videos/media/2021/08/04/tucker-carlson-viktor-orban-hungary-avlon-reality-check-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 13:07:49+00:00

CNN's John Avlon analyzes Hungarian Prime Minister Viktor Orban's regime as Fox News host Tucker Carlson makes a trip to the country to broadcast his show.

## Wuhan taking drastic action to stop spread of Delta variant
 - [https://www.cnn.com/videos/world/2021/08/04/wuhan-china-covid-delta-variant-outbreak-testing-culver-dnt-newday-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/08/04/wuhan-china-covid-delta-variant-outbreak-testing-culver-dnt-newday-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 13:02:15+00:00

China's spiraling outbreak of the Delta variant of Covid-19 has hit Wuhan, the original epicenter of the pandemic, prompting citywide coronavirus testing as authorities scramble to contain the city's first reported local infections in more than a year. CNN's David Culver reports from Wuhan, China.

## Brutal heatwave scorches southern Europe as continent's summer of extreme weather rages on
 - [https://www.cnn.com/2021/08/04/europe/southern-europe-extreme-weather-intl/index.html](https://www.cnn.com/2021/08/04/europe/southern-europe-extreme-weather-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 12:38:06+00:00

Extreme heat and wildfires continued to plague parts of southern Europe on Wednesday, a day after the top temperature in Greece reached 47.1 degrees Celsius (117 degrees Fahrenheit) -- just shy of the highest ever recorded in Europe.

## Remember when the internet lost its mind over Barack Obama's Stan Smith sneakers?
 - [https://www.cnn.com/style/article/barack-obama-stan-smith-remember-when/index.html](https://www.cnn.com/style/article/barack-obama-stan-smith-remember-when/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 12:35:39+00:00

After years of unadventurous presidential-wear and routine dad dressing, all it took was a pair of tennis shoes to spark joy. Or maybe it was the sight of Barack Obama's sockless ankles peeking out from beneath his slim olive-green chinos.

## The Delta variant is a threat to these stocks
 - [https://www.cnn.com/2021/08/04/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/08/04/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 12:17:11+00:00

If you're a company that manages ticket sales for concerts and other live events, it makes sense that after a long 18 months, you'd be getting excited about the future.

## Three people killed and eight seriously injured in Czech train crash
 - [https://www.cnn.com/2021/08/04/europe/train-crash-domazlice-czech-republic-intl/index.html](https://www.cnn.com/2021/08/04/europe/train-crash-domazlice-czech-republic-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 11:33:25+00:00

Three people died and eight were seriously injured on Wednesday when a Munich-to-Prague express train ran through a stop signal and collided with a local commuter train in the Czech Republic, Czech authorities said.

## Biden shows he's ready to make drastic moves in Covid fight -- even if he's not sure they're legal
 - [https://www.cnn.com/2021/08/04/politics/covid-emergency-moves-evictions/index.html](https://www.cnn.com/2021/08/04/politics/covid-emergency-moves-evictions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 11:29:34+00:00

Even President Joe Biden doesn't know whether his new federal eviction moratorium for renters is legal and sustainable. But crushing humanitarian and political pressure left him no choice but to take a chance on an emergency move.

## Japan's incredible convenience stores thrust into the Olympic spotlight
 - [https://www.cnn.com/travel/article/convenience-stores-konbini-tokyo-olympics/index.html](https://www.cnn.com/travel/article/convenience-stores-konbini-tokyo-olympics/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 11:18:00+00:00

Tokyo is considered one of the world's top food cities, drawing travelers from around the world who spend their days sampling renowned Japanese dishes, from sushi to ramen.

## Eerie video shows scene of murder investigation in Ukraine
 - [https://www.cnn.com/videos/world/2021/08/04/kiev-forest-vitaly-shishov-walk-and-talk-matthew-chance-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/08/04/kiev-forest-vitaly-shishov-walk-and-talk-matthew-chance-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 11:15:30+00:00

CNN's Matthew Chance walks through the forested area outside of Kiev where Ukrainian police said the body of Belarusian activist Vitaly Shishov was found with "abrasions" and "peeled skin."

## John Corbett says he and Bo Derek are finally married after 20 years together
 - [https://www.cnn.com/2021/08/04/entertainment/bo-derek-john-corbett-secret-wedding-scli-intl/index.html](https://www.cnn.com/2021/08/04/entertainment/bo-derek-john-corbett-secret-wedding-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 09:28:19+00:00

Actor John Corbett has revealed that he and partner Bo Derek married at a secret ceremony in December.

## World's oldest zoo panda celebrates with cake
 - [https://www.cnn.com/travel/article/panda-birthday-ocean-park-hong-kong-intl-hnk/index.html](https://www.cnn.com/travel/article/panda-birthday-ocean-park-hong-kong-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 09:13:08+00:00

Hong Kong Ocean Park's resident panda An An has just turned 35, making him the longest living male giant panda under human care in history. In panda years, that makes An An an impressive 105 years old.

## A year since the world's largest non-nuclear blast and questions still remain
 - [https://www.cnn.com/collections/intl-beirut-blast-anniversary-0804/](https://www.cnn.com/collections/intl-beirut-blast-anniversary-0804/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 09:13:03+00:00



## A year since the world's largest non-nuclear blast and questions still remain
 - [https://www.cnn.com/2021/08/04/middleeast/beirut-explosion-anniversary-questions-intl/index.html](https://www.cnn.com/2021/08/04/middleeast/beirut-explosion-anniversary-questions-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 09:05:50+00:00

• Bride speaks out one year after her wedding video went viral

## Fourth day of protests after 9-year-old girl allegedly raped and murdered in Indian capital
 - [https://www.cnn.com/2021/08/04/india/delhi-dalit-girl-rape-protests-intl-hnk/index.html](https://www.cnn.com/2021/08/04/india/delhi-dalit-girl-rape-protests-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 08:57:23+00:00

Hundreds of people protested in the Indian capital Delhi on Wednesday for the fourth day straight, as outrage continues to build over the alleged rape and murder of a 9-year-old girl from one of India's most oppressed castes.

## Beirut bride speaks out one year after her wedding video went viral
 - [https://www.cnn.com/videos/world/2021/08/03/beirut-explosion-bride-year-later-sfc-lon-orig.cnn](https://www.cnn.com/videos/world/2021/08/03/beirut-explosion-bride-year-later-sfc-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 07:31:15+00:00

It should have been one of the happiest days of their lives. But for Dr. Israa Seblani and Ahmad Sbeih, August 4, 2020 will always be remembered as the day a deadly explosion hit Beirut.

## IOC suspends its action on Raven Saunders' podium protest after her mother's death
 - [https://www.cnn.com/2021/08/04/sport/olympian-raven-saunders-protest-action-suspended/index.html](https://www.cnn.com/2021/08/04/sport/olympian-raven-saunders-protest-action-suspended/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 07:30:36+00:00

The probe into US athlete Raven Saunders' X gesture at the Olympics has been suspended after she shared on social media that her mother has died, according to the International Olympic Committee (IOC).

## California regulators vote to restrict water access for thousands of farmers amid severe drought
 - [https://www.cnn.com/2021/08/04/us/california-central-valley-farmers-water-access/index.html](https://www.cnn.com/2021/08/04/us/california-central-valley-farmers-water-access/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 07:26:58+00:00

California water regulators voted Tuesday to restrict water access for thousands of Central Valley farmers as the state endures a severe drought.

## China's biggest private companies are in chaos. It's all part of Beijing's plan
 - [https://www.cnn.com/2021/08/04/tech/china-crackdown-tech-education-mic-intl-hnk/index.html](https://www.cnn.com/2021/08/04/tech/china-crackdown-tech-education-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 05:17:33+00:00

China's crackdown on private enterprise has wiped out more than $1.2 trillion in market value for many powerful Chinese companies and stoked fears about the future of innovation in the world's second largest economy.

## Inside Maine church where most of the congregation is unmasked and unvaccinated
 - [https://www.cnn.com/videos/politics/2021/08/04/maine-church-covid-tuchman-dnt-ac360-vpx.cnn](https://www.cnn.com/videos/politics/2021/08/04/maine-church-covid-tuchman-dnt-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 04:02:06+00:00

CNN's Gary Tuchman visits a church in Bangor, Maine, where the pastor and most of the congregation are unmasked, unvaccinated and defiant against Covid-19 restrictions.

## Rare foods are on the brink of disappearing
 - [https://www.cnn.com/2021/08/03/europe/seed-detective-heritage-seed-library-spc-intl/index.html](https://www.cnn.com/2021/08/03/europe/seed-detective-heritage-seed-library-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 02:58:42+00:00

Hidden amongst lush Welsh woods and fields of wildflowers, grows an assortment of rare vegetable varieties. They might look ordinary enough, but many have been saved from extinction.

## Expert: Atmosphere of 'fear and intimidation' before election in Zambia
 - [https://www.cnn.com/videos/world/2021/08/04/zambia-pre-election-violence-judd-devermont-intv-oneworld-vpx.cnn](https://www.cnn.com/videos/world/2021/08/04/zambia-pre-election-violence-judd-devermont-intv-oneworld-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 02:09:26+00:00

Judd Devermont of the Center for Strategic and International Studies talks to CNN's Lynda Kinkade about Zambian president Edgar Lungu, who has deployed the military amid pre-election violence.

## Mom sold her blood to pay rent. See her reaction to incredible surprise
 - [https://www.cnn.com/videos/business/2021/08/03/dasha-kelly-eviction-donations-gofundme-support-ebof-intv-vpx.cnn](https://www.cnn.com/videos/business/2021/08/03/dasha-kelly-eviction-donations-gofundme-support-ebof-intv-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 00:41:14+00:00

Dasha Kelly, a mother of three who was facing eviction, talks to CNN's Erin Burnett about donations and support she received on GoFundMe, including thousands in donations that came in during their interview, that will allow her family to stay in their home.

## 'A master class in gaslighting': SE Cupp reacts to Cuomo statement
 - [https://www.cnn.com/videos/opinions/2021/08/03/se-cupp-cuomo-new-york-ag-report-unfiltered-vpx.cnn](https://www.cnn.com/videos/opinions/2021/08/03/se-cupp-cuomo-new-york-ag-report-unfiltered-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-04 00:35:45+00:00

CNN political commentator SE Cupp weighs in on a report released by New York Attorney General Letitia James that accused Gov. Andrew Cuomo (D-NY) of sexually harassing 11 women and creating a hostile work environment.

