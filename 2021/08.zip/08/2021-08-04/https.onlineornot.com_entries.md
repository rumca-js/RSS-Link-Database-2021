## Two months in: How the SaaS that was built in 7 days is going | OnlineOrNot
 - [https://onlineornot.com/two-months-on-how-onlineornot-is-going](https://onlineornot.com/two-months-on-how-onlineornot-is-going)
 - RSS feed: https://onlineornot.com
 - date published: 2021-08-04 09:30:03.766896+00:00

Just over two months I started OnlineOrNot by building an MVP in a single week sprint. Here's an update on how it's going.

