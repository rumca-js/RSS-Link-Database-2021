# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Jason Wilson's Viral Pep Talk Video, Guiding Kids Through Martial Arts
 - [https://www.youtube.com/watch?v=_BAgiKT4e1M](https://www.youtube.com/watch?v=_BAgiKT4e1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-05 00:00:00+00:00

Taken from JRE #1692 w/Jason Wilson:
https://open.spotify.com/episode/5JHFOXKMkahS4WjZBD3hgW?si=bHzQWEKwSfK9A1PRoKPudw&dl_branch=1

## Chad Mendes Announces Un-Retirement, Transition to Bare Knuckle Fighting
 - [https://www.youtube.com/watch?v=plZCZYR5Kts](https://www.youtube.com/watch?v=plZCZYR5Kts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-04 00:00:00+00:00

Taken from JRE MMA Show #113 w/Chad Mendes:
https://open.spotify.com/episode/3nqvEn8aufXL5oiTGYMSKe?si=7wkmgib5TKOmV-CglJ8Uqg&dl_branch=1

## Joe Talks About TJ Dillashaw's Comeback Fight with Chad Mendes
 - [https://www.youtube.com/watch?v=WXPgzyC8DD8](https://www.youtube.com/watch?v=WXPgzyC8DD8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-04 00:00:00+00:00

Taken from JRE MMA Show #113 w/Chad Mendes:
https://open.spotify.com/episode/3nqvEn8aufXL5oiTGYMSKe?si=7wkmgib5TKOmV-CglJ8Uqg&dl_branch=1

