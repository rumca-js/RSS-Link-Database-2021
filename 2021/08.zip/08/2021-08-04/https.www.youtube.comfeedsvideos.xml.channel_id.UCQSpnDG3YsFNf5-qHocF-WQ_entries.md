# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## New "Windows 365" Cloud PCs - Testing & Benchmarks
 - [https://www.youtube.com/watch?v=RmTAcskU3pM](https://www.youtube.com/watch?v=RmTAcskU3pM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-08-04 00:00:00+00:00

The latest cloud service from Microsoft is Windows PCs themselves 🤔
⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
0:51 - Plans & Pricing
3:10 - Setup Process
4:14 - Testing Basic PC
7:26 - Testing Premium PC
8:48 - Gaming Test
10:04 - Streaming from iPhone
10:34 - What's the Point?
13:02 - For Regular Uses

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

