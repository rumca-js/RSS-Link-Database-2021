# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Słowenia zwala z nóg! 😲 Najbardziej niedoceniany kraj Europy? Alpy Kamnickie i zawał serca 🇸🇮 1/2
 - [https://www.youtube.com/watch?v=KVVB1zlyWsQ](https://www.youtube.com/watch?v=KVVB1zlyWsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-08-04 00:00:00+00:00

Kurs filmowania i montażu 🎬 https://www.kursfilmowaniaimontazu.pl/
Dodatek Podróżniczy 🎬 http://filmypodroznicze.pl/

Tym razem mała przerwa od roweru, chociaż... także i w Słowenii pojeździmy. W Alpach Kamnickich tylko symbolicznie, w drugim odcinku więcej. Dzisiaj zabieramy Was w kilka naprawdę widokowych i zapierających dech w piersiach miejsc, z naciskiem na jedną taką górę, która miała być w miarę lajtowa, a trochę nam adrenalinę podniosła.

Jednak dobre jest to, że świetnie było z niej widać okolicę! I wszystkie te piękne atrakcje i ciekawe miejsca w Słowenii. Jest to naprawdę niesamowicie piękny kraj, który z impetem wbił na nasze podium najbardziej widokowych krajów w Europie. Absolutnie coś pięknego i jeśli tylko jeszcze w Słowenii nie byliście (albo traktujecie ją tylko przejazdem) to koniecznie musicie to zmienić.

Nasza trasa na Ojstrice:
https://en.mapy.cz/s/kutuvemupa

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Muzyka:
artlist oraz Nevaeh https://soundcloud.com/nevaxh

spis treści:
0:00 Słowenia
1:22 Ojstrica - idziemy na trekking
11:41 ciekawostki o Słowenii
13:46 Velika Planina
16:01 Dolina Logarska rowerem

