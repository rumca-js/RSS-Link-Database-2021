# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Why You Can't Get a PS5 (Or Anything Else)
 - [https://www.youtube.com/watch?v=LjUORIW1x4I](https://www.youtube.com/watch?v=LjUORIW1x4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-08-04 00:00:00+00:00

Where’s all the new fancy gadgets going? Are they gone forevermore? You probably already know all the answers, but I wrote this video anyway, so here it is. 

A video. 
About stuff. 
You probably already know.

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpe...

Music Throughout By https://soundcloud.com/sarahtheillstrumentalist



End music is probably somewhere on my soundcloud. If not it will be there someday. Eventually.



Additional Footage Credits:

PolarSaurusRex
WION
VICE Asia
nintendomaster2024
BombOmbAl
Cinemassacre Play

