## Amazon Unlawfully Confiscated Union Literature, NLRB Finds
 - [https://www.vice.com/en/article/bvz3kv/amazon-unlawfully-confiscated-union-literature-nlrb-finds](https://www.vice.com/en/article/bvz3kv/amazon-unlawfully-confiscated-union-literature-nlrb-finds)
 - RSS feed: https://www.vice.com
 - date published: 2021-08-04 22:38:59.501142+00:00

The National Labor Relations Board found that Amazon illegally interfered with worker organizing at its Staten Island, New York warehouse in May. 

