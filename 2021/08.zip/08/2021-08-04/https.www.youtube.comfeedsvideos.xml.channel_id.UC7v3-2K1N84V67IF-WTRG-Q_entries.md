# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Suicide Squad - Movie Review
 - [https://www.youtube.com/watch?v=aMSlvpQ-P5s](https://www.youtube.com/watch?v=aMSlvpQ-P5s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-08-04 00:00:00+00:00

The Suicide Squad is BACK! Bloodier, funnier, and more focused. Here's my review of #TheSuicideSquad

