## Professor suggests it should be a federal hate crime to criticize Fauci and other government-funded scientists
 - [https://www.thecollegefix.com/professor-suggests-it-should-be-a-federal-hate-crime-to-criticize-fauci-and-other-government-funded-scientists/](https://www.thecollegefix.com/professor-suggests-it-should-be-a-federal-hate-crime-to-criticize-fauci-and-other-government-funded-scientists/)
 - RSS feed: https://www.thecollegefix.com
 - date published: 2021-08-04 19:50:29+00:00

Professor suggests it should be a federal hate crime to criticize Fauci and other government-funded scientists

