# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## How a 28 Year Old Man Destroyed England’s Oldest Bank
 - [https://www.youtube.com/watch?v=avMbu6cc4Eo](https://www.youtube.com/watch?v=avMbu6cc4Eo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-08-04 00:00:00+00:00

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Discord:  https://discord.gg/coldfusion

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://ethicsunwrapped.utexas.edu/case-study/collapse-barings-bank

https://www.nationalgeographic.org/thisday/jan17/kobe-earthquake/#:~:text=On%20January%2017%2C%201995%2C%20a%20major%20earthquake%20struck%20near%20the,more%20than%2045%2C000%20people%20homeless.&text=The%20Kobe%20quake%20was%20a,Eurasian%20and%20Philippine%20plates%20interact.

https://www.cnbc.com/2020/02/26/barings-collapse-25-years-on-what-the-industry-learned-after-one-man-broke-a-bank.html

https://www.youtube.com/watch?v=uhrIAnbl5XE&ab_channel=JohnMusicman

My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Sublab - So In Love

Cody G - With You

Sangam & Cholombian - Shelter Me

Working Men's Club - Valleys (Confidence Man Remix)

Aleksandir - Between Summers

Catching Flies - The Long Journey Home

Nanobyte - Lost Time

SWOOSE - MEMBRANE THEORY

Mogwai - Take Me Somewhere Nice

Ex-Re - Romance

In Frames - Calm Wisdom

Julianna Barwick - Look Into Your Own Mind

Burn Water - Youth

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

