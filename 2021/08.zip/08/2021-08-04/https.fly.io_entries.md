## The 5-hour CDN · Fly
 - [https://fly.io/blog/the-5-hour-content-delivery-network/](https://fly.io/blog/the-5-hour-content-delivery-network/)
 - RSS feed: https://fly.io
 - date published: 2021-08-04 22:54:36+00:00

You can build a functional CDN on an 8-year-old laptop while you're sitting at a coffee shop. Here's what a CDN you put together in five hours might look like.

