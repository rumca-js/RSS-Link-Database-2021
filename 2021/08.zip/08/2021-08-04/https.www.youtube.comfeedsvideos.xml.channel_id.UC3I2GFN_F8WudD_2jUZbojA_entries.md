# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Half Waif - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=T2OvUxPubFA](https://www.youtube.com/watch?v=T2OvUxPubFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-05 00:00:00+00:00

http://KEXP.ORG presents Half Waif performing live, recorded exclusively for KEXP.

Songs:
Take Away the Ache 
Swimmer
Orange Blossoms 
Horse Racing
Sodium & Cigarettes

Filmed by the band at a cabin in the Catskills, Summer 2021
Mixed by Zubin Hensler
Edited by Nandi Rose and Kenna Hynes
With special thanks to Chromoscope and the Levine family

Nandi Rose - Vocals, Keys
Zubin Hensler - Horn, Synths, Vocals
Joanna Schubert - Vocals, Synths
Zack Levine - Drums

https://half-waif.com
http://kexp.org

## Half Waif - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=wuPQhHEgtY0](https://www.youtube.com/watch?v=wuPQhHEgtY0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-04 00:00:00+00:00

http://KEXP.ORG presents Half Waif sharing a live performance recorded exclusively for KEXP and talking to Gabriel Teodros, host of Early. Recorded July 21, 2021.

Songs:
Take Away the Ache 
Swimmer
Orange Blossoms 
Horse Racing
Sodium & Cigarettes

Filmed by the band at a cabin in the Catskills, Summer 2021
Mixed by Zubin Hensler
Edited by Nandi Rose and Kenna Hynes
With special thanks to Chromoscope and the Levine family

Nandi Rose - Vocals, Keys
Zubin Hensler - Horn, Synths, Vocals
Joanna Schubert - Vocals, Synths
Zack Levine - Drums

https://half-waif.com
http://kexp.org

