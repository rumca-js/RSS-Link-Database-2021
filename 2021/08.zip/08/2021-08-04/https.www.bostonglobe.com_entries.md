## ‘It has to be known what was done to us’: Natick couple harassed by eBay tell their story for the first time - The Boston Globe
 - [https://www.bostonglobe.com/2021/07/31/business/it-has-be-known-what-was-done-us-natick-couple-harassed-by-ebay-tell-their-story-first-time/?p1=Article_Feed_ContentQuery](https://www.bostonglobe.com/2021/07/31/business/it-has-be-known-what-was-done-us-natick-couple-harassed-by-ebay-tell-their-story-first-time/?p1=Article_Feed_ContentQuery)
 - RSS feed: https://www.bostonglobe.com
 - date published: 2021-08-04 22:25:44.241746+00:00

David and Ina Steiner were terrorized for weeks in the summer of 2019 by a team of employees from Internet giant eBay. Here is their account of the events, which have led to criminal charges and a civil lawsuit.

