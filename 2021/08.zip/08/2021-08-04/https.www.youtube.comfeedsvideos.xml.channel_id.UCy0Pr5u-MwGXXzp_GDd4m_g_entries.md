# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## It's locked
 - [https://www.youtube.com/watch?v=RakMOGUKlPA](https://www.youtube.com/watch?v=RakMOGUKlPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-08-05 00:00:00+00:00

Thank you to BetterHelp for sponsoring today's video. Get 10% off you first month here: https://BetterHelp.com/nolke

Actors: Julie Nolke & Gina Louise Phillips (https://www.imdb.com/name/nm1329052/)
Camera: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Also, join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

