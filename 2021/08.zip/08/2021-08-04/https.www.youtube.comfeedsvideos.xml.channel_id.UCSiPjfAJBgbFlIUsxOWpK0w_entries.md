# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## This is a French BOP // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=cxNzWrvx64c](https://www.youtube.com/watch?v=cxNzWrvx64c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-08-05 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Ok so I think that my French brain is permanently locked in middle / high school because that’s when I was there. It’s like I can’t help myself: anytime I write in French it’s about some awkward, unrequited romance. Exibit A: “Jean-Marie” written by Pomplamoose & Ben Rose.

Also, for all you Jazz nerds (woot!), that guitar riff is played by BRETT FARKAS and it’s a cover of AHMAD JAMAL’S “Patterns.” Many thanks to both of them for letting us incorporate their music into this weird French song.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

Jean-Marie is an original song by Pomplamoose.

MUSICIAN CREDITS
Vocals, Upright Bass: Nataly Dawn
Keys, Percussion: Jack Conte
Guitar: Brett Farkas
Drums, Additional Percussion: Ben Rose

AUDIO CREDITS
Mixing/Mastering: Yianni AP
Producer: Ben Rose
Written & Arranged by Ben Rose & Pomplamoose

VIDEO CREDITS
Camera Operator: Nataly Dawn
Assistant to the Regional Camera Operator: Ben Rose
Video Editor: Cleveen Dominguez
Colorist: Charlene Gibbs
Wardrobe: Elle Olsen

Recorded in our home studio in San Francisco, CA.

LYRICS (French / English)

Jean-Marie / Jean-Marie
On t’as dit / They told you
Que t’étais moitié fille / That you were half girl
Que ton pantalon marron / That your brown trousers
Était bien trop petit / Were far too small
Que ta mère / That your mom
Préférait ton frère / Preferred your brother
Qui fut accepté au / Who got into
Polytechnique / An Ivy League

Jean-Marie / Jean-Marie
Tu as bien compris / You already know
Que les gosses / That kids
Ne sont pas sympathiques / Aren’t nice
Sauf peut-être / Except for maybe
Celle qui s’appelle / The one named
Angélique / Angélique

Allez vas-y / Go for it
Tente ta chance / Try your luck
Allez vas-y / Go for it
Jean-Marie dance / Jean-Marie dance

Ben ça s’ai pas exactement passé / Okay so that didn’t exactly go
Comme tu l’imaginais / Like you thought it would
C’est pas grave / It’s not a big deal
La prochaine fois / Next time
Tu seras prêt / You’ll be ready
Ouais faut juste / You just gotta
Répéter un peu / Practice a little bit

Angélique / Angélique
On t’as dit / They told you
Que t’étais moitié jolie / That you were half pretty
Mais de toutes façons / But so what
Ils sont cons / They’re assholes
Et tous / And all of them
Moitié vide / Half empty

Et Jean-Marie / And Jean-Marie
Il te trouve pas mal lui / He thinks you aren’t bad
Pas mal du tout en faite / Not bad at all in fact
C’est pour ça qu’il t’a demandé / That’s why he asked you
D’être sa petite Angélique aimée / To be his little beloved Angélique
Et t’as dit non / But you said no

Allez vas-y / Go for it
Re-tente ta chance / Try your luck again
Allez vas-y / Go for it
Jean-Marie dance / Jean-Marie dance

