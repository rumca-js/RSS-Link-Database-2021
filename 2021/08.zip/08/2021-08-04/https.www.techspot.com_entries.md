## Facebook is reportedly trying to analyze encrypted data without decrypting it | TechSpot
 - [https://www.techspot.com/news/90660-facebook-reportedly-trying-analyze-encrypted-data-without-decrypting.html](https://www.techspot.com/news/90660-facebook-reportedly-trying-analyze-encrypted-data-without-decrypting.html)
 - RSS feed: https://www.techspot.com
 - date published: 2021-08-04 09:32:24.338969+00:00

The social networking giant confirmed as much to The Information (paywalled), and is apparently one of several tech companies interested in a field known as homomorphic encryption....

