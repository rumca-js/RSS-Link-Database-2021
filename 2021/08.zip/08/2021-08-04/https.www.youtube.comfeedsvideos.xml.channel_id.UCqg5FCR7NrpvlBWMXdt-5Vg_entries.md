# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Sky is the Massively Successful Follow-up to Journey No One Is Talking About
 - [https://www.youtube.com/watch?v=uEhCrXX9lKE](https://www.youtube.com/watch?v=uEhCrXX9lKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-08-05 00:00:00+00:00

Sky: Children of the Light is an excellent and successful game from developer thatgamecompany, the creator of Journey, yet it so rarely gets the sort of media attention that Journey received. Let’s fix that.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## What's Old Is New Again | Breakout
 - [https://www.youtube.com/watch?v=6tMlOFJHxzQ](https://www.youtube.com/watch?v=6tMlOFJHxzQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-08-05 00:00:00+00:00

This week on Breakout, we discuss franchises (or series) we'd like to see make a return, the use of deepfakes in media and reminisce a little bit about The Escapist as the site enters its third year of its revival effort on Thursday.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Cruelty Squad (Zero Punctuation)
 - [https://www.youtube.com/watch?v=gkFNpFbqQsw](https://www.youtube.com/watch?v=gkFNpFbqQsw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-08-04 00:00:00+00:00

This week on Zero Punctuation, Yahtzee reviews Cruelty Squad.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Dodgeball Academia | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=qQ5P_G7RGfA](https://www.youtube.com/watch?v=qQ5P_G7RGfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-08-04 00:00:00+00:00

Will Cruz reviews Dodgeball Academia, developed by Pocket Trap.

Dodgeball Academia on Steam: https://store.steampowered.com/app/1422420/Dodgeball_Academia/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee Plays Death's Door and The Forgotten City | Post-ZP Stream
 - [https://www.youtube.com/watch?v=vAa-wcNzGWE](https://www.youtube.com/watch?v=vAa-wcNzGWE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-08-04 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5...​

Yahtzee plays two hours of Death's Door and The Forgotten City for today's Post-ZP Stream.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

