# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## I Modded My Tesla Model 3!
 - [https://www.youtube.com/watch?v=-M6IcE-tQJM](https://www.youtube.com/watch?v=-M6IcE-tQJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2021-08-05 00:00:00+00:00

For your chance to win a Zelectic Porsche 912 and support a great cause, go to https://www.omaze.com/snazzylabs
In this video, Quinn disassembles his Tesla. Kinda to fix a problem, but mostly just because.


Alibaba bumper special - https://www.alibaba.com/product-detail/Modified-Body-kits-for-Tesla-model_1600190215084.html
Alibaba tail lights - https://www.aliexpress.com/item/1005002359118544.html?spm=a2g0o.productlist.0.0.38165c3136y3EJ&algo_pvid=314abd36-aefd-46b4-bbad-cc39dcfafc66&algo_exp_id=314abd36-aefd-46b4-bbad-cc39dcfafc66-1
HUD screen - https://amzn.to/3fzCOpX


Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq


In this video, Quinn rights the wrong of his $9,000 fender bender bill and adds additional features to his 2018 Tesla Model 3.

