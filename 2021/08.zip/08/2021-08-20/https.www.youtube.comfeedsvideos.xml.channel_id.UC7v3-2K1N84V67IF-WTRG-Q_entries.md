# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Reminiscence - Movie Review
 - [https://www.youtube.com/watch?v=pQbx86pMg8E](https://www.youtube.com/watch?v=pQbx86pMg8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-08-21 00:00:00+00:00

We have ourselves a futuristic, noir style investigation involving a missing woman, and a machine that allows one to relive their memories. Here's my review of REMINISCENCE!

#Reminiscence

## The Protégé - Movie Review
 - [https://www.youtube.com/watch?v=J8oqOwUVVFc](https://www.youtube.com/watch?v=J8oqOwUVVFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-08-20 00:00:00+00:00

Become smarter in 5 minutes by signing up for free today: https://cen.yt/mbjeremyjahns - Thanks to Morning Brew for sponsoring today’s video.

Maggie Q & Michael Keaton being on the flirty tension, but is that enough to make for some good spy thriller tension? Here's my review for The Protégé!

#TheProtege

