# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Ilu posłów jest zaszczepionych? Wpłynęło zapytanie do Kancelarii Sejmu!
 - [https://www.youtube.com/watch?v=GZ-X2R0HwHA](https://www.youtube.com/watch?v=GZ-X2R0HwHA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-08-21 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3zcHk5y
2. https://bit.ly/2UCGOPb
3. https://bit.ly/3kaRo8Z
4. https://bit.ly/3mASFcn
---------------------------------------------------------------
💡 Tagi: #sejm #polityka #covid19
--------------------------------------------------------------

## Pracodawca sprawdzi, czy pracownik jest zaszczepiony! Głosowanie 15 września!
 - [https://www.youtube.com/watch?v=Vtqn0-9Mazk](https://www.youtube.com/watch?v=Vtqn0-9Mazk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-08-20 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/2WdJUd2
2. https://bit.ly/3mi2hIL
3. https://bit.ly/3mpZQUF
---------------------------------------------------------------
💡 Tagi: #covid19 #QR
--------------------------------------------------------------

