# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Want To F*ck The System That's Been F*cking You? - WATCH THIS!
 - [https://www.youtube.com/watch?v=7ILYgJHo9iY](https://www.youtube.com/watch?v=7ILYgJHo9iY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-21 00:00:00+00:00

Check out this clip with activist and speaker Satish Kumar from my Luminary podcast, Under The Skin! We talk about the need for a better society and how protesting isn't enough when our social system is using us for profit!

You can listen to the full episode on Luminary, available on Apple Podcasts at http://apple.co/russell

#protest #society #SatishKumar #change #russellbrand

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## Snowden UNMASKS Apple’s New Ploy To SPY On You!!
 - [https://www.youtube.com/watch?v=VdjR2r5ty5o](https://www.youtube.com/watch?v=VdjR2r5ty5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-20 00:00:00+00:00

Apple announced a new set of “protection for children” features for US iPhones, but will it open the floodgates to a significant expansion of the surveillance state? 
#apple #iPhone #EdwardSnowden #surveillance #spying

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

