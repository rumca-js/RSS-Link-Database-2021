## Australia Is Betting on Remote Quarantine. Here’s What I Learned on the Inside. - The New York Times
 - [https://www.nytimes.com/2021/08/20/world/australia/howard-springs-quarantine.html](https://www.nytimes.com/2021/08/20/world/australia/howard-springs-quarantine.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2021-08-20 20:02:00+00:00

Australia Is Betting on Remote Quarantine. Here’s What I Learned on the Inside. - The New York Times

