# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Dad delivers passionate speech defending masks in schools
 - [https://www.cnn.com/videos/us/2021/08/20/tennessee-dad-mask-speech-williamson-county-school-board-orig-llr.cnn](https://www.cnn.com/videos/us/2021/08/20/tennessee-dad-mask-speech-williamson-county-school-board-orig-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 23:33:00+00:00

Justin Kanew, a father in Williamson County, Tennessee, shared how his 5-year-old daughter was one of a few students in her class wearing a mask on the first day of school.

## 'That was a newborn baby': CNN reporter reveals dire situation at Kabul airport
 - [https://www.cnn.com/videos/world/2021/08/20/kabul-airport-evacuation-afghanistan-lead-ward-pkg-vpx.cnn](https://www.cnn.com/videos/world/2021/08/20/kabul-airport-evacuation-afghanistan-lead-ward-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 22:13:08+00:00



## Biden picks Emanuel as ambassador to Japan and Burns as top envoy to China
 - [https://www.cnn.com/2021/08/20/politics/rahm-emanuel-japan-nick-burns-china/index.html](https://www.cnn.com/2021/08/20/politics/rahm-emanuel-japan-nick-burns-china/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 22:00:21+00:00

President Joe Biden on Friday announced his intention to nominate Rahm Emanuel as ambassador to Japan and Nicholas Burns as ambassador to China.

## US Capitol bomb suspect charged with threatening to use a weapon of mass destruction
 - [https://www.cnn.com/2021/08/20/politics/floyd-ray-roseberry-hearing-scheduled-bomb-threats-library-of-congress/index.html](https://www.cnn.com/2021/08/20/politics/floyd-ray-roseberry-hearing-scheduled-bomb-threats-library-of-congress/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 21:36:48+00:00

The Justice Department has charged Capitol bomb threat suspect Floyd Ray Roseberry with threatening to use a weapon of mass destruction and attempting to use an explosive device, a judge said Friday.

## Opinion: It's time for fans to demand the 'Jeopardy!' host we deserve
 - [https://www.cnn.com/2021/08/20/opinions/jeopardy-host-mike-richards-alex-trebek-perry/index.html](https://www.cnn.com/2021/08/20/opinions/jeopardy-host-mike-richards-alex-trebek-perry/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 21:08:56+00:00

When I was a junior in college, a reference librarian I knew at Wesleyan University, where I was in school, went on the game show "Jeopardy!"

## Why did OnlyFans ban sexually explicit content?
 - [https://www.cnn.com/2021/08/20/tech/onlyfans-explicit-content-ban-payment/index.html](https://www.cnn.com/2021/08/20/tech/onlyfans-explicit-content-ban-payment/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 20:47:12+00:00

Thursday's decision by the creator platform OnlyFans to soon stop hosting a wide swath of sexually explicit content is sending shockwaves through the internet.

## Initial autopsy fails to reveal what killed a family and their dog on trail near Yosemite
 - [https://www.cnn.com/2021/08/19/us/yosemite-family-death-trnd/index.html](https://www.cnn.com/2021/08/19/us/yosemite-family-death-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 20:29:15+00:00

Authorities in Mariposa County, California, are trying to determine why a family of three and their dog died on a remote hiking trail in the Sierra National Forest near Yosemite National Park.

## Angelina Jolie joins Instagram to call attention to suffering in Afghanistan
 - [https://www.cnn.com/2021/08/20/entertainment/angelina-jolie-afghanistan-instagram-trnd/index.html](https://www.cnn.com/2021/08/20/entertainment/angelina-jolie-afghanistan-instagram-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 19:26:44+00:00

Angelina Jolie, a notoriously private celebrity with no public social media presence, has joined Instagram, using the platform to draw attention to the situation in Afghanistan.

## Biden: We are considering every means to get people out
 - [https://www.cnn.com/videos/politics/2021/08/20/biden-afghanistan-evacuation-sot-nr-vpx.cnn](https://www.cnn.com/videos/politics/2021/08/20/biden-afghanistan-evacuation-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 18:57:09+00:00

President Joe Biden speaks about US military evacuations of American citizens, Special Immigrant Visa applicants and vulnerable Afghans as chaos continues around the Kabul airport.

## Prosecutors allege R Kelly knowingly infected people with herpes
 - [https://www.cnn.com/2021/08/20/us/r-kelly-trial-testimony-thursday/index.html](https://www.cnn.com/2021/08/20/us/r-kelly-trial-testimony-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 18:01:29+00:00

R. Kelly's personal physician of 25 years took the stand Thursday to testify about his treatment of the singer's genital herpes since at least 2007, after prosecutors allege the singer knowingly infected multiple people with the incurable sexually transmitted disease.

## Elon Musk says Tesla is building a humanoid robot
 - [https://www.cnn.com/videos/business/2021/08/20/tesla-bot-humanoid-robot-lon-orig-na.cnn-business](https://www.cnn.com/videos/business/2021/08/20/tesla-bot-humanoid-robot-lon-orig-na.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 17:36:50+00:00

CEO Elon Musk announced Tesla is working on a "friendly" humanoid robot. For now, he has a human in a robot suit.

## Ed Sheeran is dropping a new album in October
 - [https://www.cnn.com/2021/08/20/entertainment/ed-sheeran-new-album-equals-intl-scli-gbr/index.html](https://www.cnn.com/2021/08/20/entertainment/ed-sheeran-new-album-equals-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 15:49:47+00:00

Ed Sheeran has announced his fourth studio album, saying it is the "best bit of work that I've done."

## Princess Beatrice is refreshingly honest about her learning difficulty. Here's why it matters
 - [https://www.cnn.com/2021/08/20/uk/royal-news-newsletter-08-20-21-scli-gbr-cmd-intl/index.html](https://www.cnn.com/2021/08/20/uk/royal-news-newsletter-08-20-21-scli-gbr-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 14:46:16+00:00

"I remember feeling really confused -- an overwhelming sense of, 'Why does this all feel a little bit muddled?'" Princess Beatrice recalls from her early school years in an interview this week.

## Marjorie Taylor Greene heads to the Iowa State Fair. Hear what Iowans think about it
 - [https://www.cnn.com/videos/media/2021/08/20/iowa-state-fair-marjorie-taylor-greene-donie-osullivan-pkg-vpx.cnn](https://www.cnn.com/videos/media/2021/08/20/iowa-state-fair-marjorie-taylor-greene-donie-osullivan-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 14:18:43+00:00

As Rep. Marjorie Taylor Greene (R-GA) Georgia and Rep. Matt Gaetz (R-FL) are expected to attend this year's Iowa State Fair in Des Moines, CNN's Donie O'Sullivan hears what Iowans have to say about it.

## Girl meets girl at band camp. They fall in love
 - [https://www.cnn.com/travel/article/couple-met-at-band-camp-cmd/index.html](https://www.cnn.com/travel/article/couple-met-at-band-camp-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 13:18:23+00:00

It was August 2011 and Natasha Fisher was 17 and traveling from her home in England to the United States for the first time, desperate to spend a summer in New York living out a fantasy she'd only ever seen in TV and film.

## First cross-river railway bridge between China and Russia completed
 - [https://www.cnn.com/travel/article/tongjiang-china-russia-bridge-complete-intl-hnk/index.html](https://www.cnn.com/travel/article/tongjiang-china-russia-bridge-complete-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 12:10:14+00:00

A new bridge that will link Russia and China's railway systems was completed on August 17, 2021, seven years after its much-heralded groundbreaking.

## Rafael Nadal pulls out of US Open with foot injury, will miss remainder of 2021
 - [https://www.cnn.com/2021/08/20/tennis/rafael-nadal-withdraw-us-open-foot-injury-spt-intl/index.html](https://www.cnn.com/2021/08/20/tennis/rafael-nadal-withdraw-us-open-foot-injury-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 12:08:42+00:00

Rafael Nadal announced on Friday that he will miss the remainder of the 2021 season with a foot injury and will therefore take no part in this month's US Open -- the final tennis grand slam of the year.

## A billion children are at 'extremely high risk' of climate shocks, UNICEF says
 - [https://www.cnn.com/2021/08/20/world/children-climate-risk-unicef-intl/index.html](https://www.cnn.com/2021/08/20/world/children-climate-risk-unicef-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 11:23:09+00:00

Almost half of the world's 2.2 billion children are living in countries that face an extremely high risk of the impacts of the climate crisis, including environmental shocks such as cyclones and heatwaves, according to an index published Friday by UNICEF, the UN children's agency.

## Infant bats babble, just like human babies, study finds
 - [https://www.cnn.com/2021/08/20/world/baby-bats-babble-scli-intl-scn/index.html](https://www.cnn.com/2021/08/20/world/baby-bats-babble-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:46:32+00:00

Baby bats babble just like human infants when learning to communicate, a new study has found.

## As Covid-19 hospitalizations increase, a greater number of Americans are deciding to get vaccinated
 - [https://www.cnn.com/2021/08/20/health/us-coronavirus-friday/index.html](https://www.cnn.com/2021/08/20/health/us-coronavirus-friday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:41:54+00:00

The alarming rise in Covid-19 cases and hospitalizations has impacted one important indicator in a positive way -- new US Centers for Disease Control and Prevention data showed Thursday that more than one million doses of the vaccine were administered in a day.

## 'Don't forget the women of Afghanistan': Former Afghan football captain Khalida Popal speaks out on her country's fall to the Taliban
 - [https://www.cnn.com/2021/08/20/football/khalida-popal-afghanistan-women-football-spt-intl/index.html](https://www.cnn.com/2021/08/20/football/khalida-popal-afghanistan-women-football-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:39:03+00:00

On August 15, Khalida Popal watched from Denmark as her country fell into the grip of the Taliban.

## Opinion: This is the story of Haiti that matters most
 - [https://www.cnn.com/2021/08/20/opinions/haiti-earthquake-flooding-assassination-revolution-joseph/index.html](https://www.cnn.com/2021/08/20/opinions/haiti-earthquake-flooding-assassination-revolution-joseph/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:38:27+00:00

Haiti's pivotal historical role in Black political self-determination is essential to accurate portrayals of the country, and yet it is almost always absent from most stories about Ayiti, rocked by another earthquake that has killed more than 2100 people and hit thereafter by punishing floods from Tropical Storm Grace. These disasters come shortly after the assassination of Jovenel Moise, Haiti's president.

## Chuck Close, painter of striking large-scale portraits, dies aged 81
 - [https://www.cnn.com/style/article/chuck-close-artist-obituary/index.html](https://www.cnn.com/style/article/chuck-close-artist-obituary/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:36:20+00:00

American artist Chuck Close, whose large-scale portraits immortalized friends, artists and some of pop culture's most recognizable faces, died Thursday aged 81.

## Europe left exposed as Biden walks America away from the world stage
 - [https://www.cnn.com/2021/08/20/europe/europe-left-exposed-intl-cmd/index.html](https://www.cnn.com/2021/08/20/europe/europe-left-exposed-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:26:34+00:00

When US President Joe Biden finally broke his silence on the chaos unfolding in Afghanistan, European allies who'd had high hopes for a reset in the transatlantic alliance were left dismayed.

## Hundreds of cases are being reviewed after police officers involved were relieved of duty over racist and anti-Semitic messages
 - [https://www.cnn.com/2021/08/20/us/torrance-police-swastika-vandalism/index.html](https://www.cnn.com/2021/08/20/us/torrance-police-swastika-vandalism/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:21:02+00:00

Two former officers with the Torrance Police Department were charged Thursday with vandalism for allegedly spray-painting an impounded vehicle with a swastika, authorities said.

## House Republicans vow to probe Biden's Afghanistan exit
 - [https://www.cnn.com/2021/08/20/politics/house-republicans-afghanistan-biden-benghazi/index.html](https://www.cnn.com/2021/08/20/politics/house-republicans-afghanistan-biden-benghazi/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 10:01:10+00:00

Some Republicans see the fallout over the US exit from Afghanistan as their new Benghazi -- a foreign policy blunder ripe for investigation that could provide just the political ammunition they need to dent a popular Democratic President.

## All Blacks cancel fixtures against Australia and South Africa due to Covid-19 travel restrictions
 - [https://www.cnn.com/2021/08/20/sport/all-blacks-cancel-australia-south-africa-rubgy-spt-intl/index.html](https://www.cnn.com/2021/08/20/sport/all-blacks-cancel-australia-south-africa-rubgy-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 09:26:11+00:00

The All Blacks, the New Zealand men's rugby team, have canceled two tests against South Africa and a match against Australia because of Covid-19 travel restrictions.

## Harris heads to Southeast Asia in search of a foreign policy win amid Afghanistan crisis
 - [https://www.cnn.com/2021/08/20/politics/kamala-harris-southeast-asia-trip-afghanistan/index.html](https://www.cnn.com/2021/08/20/politics/kamala-harris-southeast-asia-trip-afghanistan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 09:20:10+00:00

Vice President Kamala Harris faces a steep challenge next week when she travels to Singapore and Vietnam, as a once-low-risk trip to friendly nations comes at the same time as a bungled US withdrawal from Afghanistan.

## Naomi Osaka exits Western & Southern Open but says she can 'sleep at night'
 - [https://www.cnn.com/2021/08/20/tennis/naomi-osaka-defeat-cincinnati-spt-intl/index.html](https://www.cnn.com/2021/08/20/tennis/naomi-osaka-defeat-cincinnati-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 09:01:22+00:00

Naomi Osaka suffered a shock defeat at the hands of Jil Teichmann in the Western & Southern Open on Thursday but says she can "sleep at night" knowing she tried her best throughout.

## Tesla is building a humanoid robot for 'boring, repetitive and dangerous' work
 - [https://www.cnn.com/2021/08/20/tech/tesla-ai-day-robot/index.html](https://www.cnn.com/2021/08/20/tech/tesla-ai-day-robot/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 08:59:14+00:00

Elon Musk said Thursday night at Tesla's AI Day that the company is building a humanoid robot, and will probably have a prototype next year.

## 'No one trusts anything that comes from the Taliban's mouth.' 
Three women on what Afghanistan is like under the militant group's rule
 - [https://www.cnn.com/2021/08/20/asia/afghanistan-women-taliban-intl/index.html](https://www.cnn.com/2021/08/20/asia/afghanistan-women-taliban-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 08:58:37+00:00

Since the Taliban swept to power in Afghanistan, seizing provincial capitals at lightning speed, it's been difficult to get a picture of what life is like for Afghans outside the capital, Kabul. Especially for women.

## China passes sweeping data privacy law, stinging tech stocks again
 - [https://www.cnn.com/2021/08/20/tech/china-data-privacy-law-intl-hnk/index.html](https://www.cnn.com/2021/08/20/tech/china-data-privacy-law-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 08:57:01+00:00

China has passed sweeping new rules about the collection and use of personal data as Beijing toughens its regulation of the country's tech companies.

## Taliban crush opposition across Afghanistan, as chaos builds at airport
 - [https://www.cnn.com/collections/afghan-taliban-intl-081921/](https://www.cnn.com/collections/afghan-taliban-intl-081921/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 08:38:11+00:00



## Why painting this design on your face is a protest against surveillance
 - [https://www.cnn.com/videos/beauty/2020/10/15/cv-dazzle-makeup-facial-recognition-surveillance-mxb-lon-orig.cnn](https://www.cnn.com/videos/beauty/2020/10/15/cv-dazzle-makeup-facial-recognition-surveillance-mxb-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 08:21:16+00:00

CV Dazzle is a striking makeup technique that uses abstract geometric patterns, asymmetry and contrasting colors to try and fool facial recognition technology and keep its wearer's identity anonymous. But as technology has gotten smarter, the looks have become a form of protest instead.

## Chinese astronauts conduct second spacewalk outside planned space station
 - [https://www.cnn.com/2021/08/20/china/china-tiangong-second-spacewalk-intl-hnk-scli-scn/index.html](https://www.cnn.com/2021/08/20/china/china-tiangong-second-spacewalk-intl-hnk-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 07:46:17+00:00

Chinese astronauts working on the country's planned space station carried out their second spacewalk on Friday, according to the China Manned Space Agency.

## Greek government pushes back on Stefanos Tsitsipas' vaccine comments
 - [https://www.cnn.com/2021/08/20/tennis/stefanos-tsitsipas-vaccines-criticism-spt-intl/index.html](https://www.cnn.com/2021/08/20/tennis/stefanos-tsitsipas-vaccines-criticism-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 07:29:22+00:00

A spokesman for the Greek government has pushed back on Stefanos Tsitsipas' comments in which he said he would only get vaccinated for Covid-19 if it became mandatory to compete in tennis.

## California's fast-moving wildfire scorched an area roughly half the size of Chicago in less than a week as thousands more evacuate
 - [https://www.cnn.com/2021/08/20/weather/us-western-wildfires-friday/index.html](https://www.cnn.com/2021/08/20/weather/us-western-wildfires-friday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 07:03:47+00:00

California's fast-moving Caldor Fire has spread so quickly that it burned an area roughly half the size of Chicago in less than a week, forcing thousands to abandon their homes.

## New Zealand to extend national lockdown after more Covid-19 cases identified
 - [https://www.cnn.com/2021/08/20/asia/new-zealand-lockdown-extension-intl-hnk/index.html](https://www.cnn.com/2021/08/20/asia/new-zealand-lockdown-extension-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 06:59:02+00:00

New Zealand will extend a nationwide lockdown for four days after uncovering several locally transmitted Covid-19 cases.

## China insists its zero Covid strategy is correct. Challenging it can be dangerous
 - [https://www.cnn.com/2021/08/20/china/china-zhang-wenhong-mic-intl-hnk/index.html](https://www.cnn.com/2021/08/20/china/china-zhang-wenhong-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 06:44:04+00:00

As the highly infectious Delta variant took hold in China last month, Zhang Wenhong, a well-respected infectious disease expert in Shanghai, told a concerned Chinese public to prepare to live with the coronavirus for the long haul — but his candor came at a price.

## Chaos continues to unfold at Kabul airport's north gate
 - [https://www.cnn.com/videos/world/2021/08/20/kabul-airport-chaos-afghanistan-taliban-npw-dlt-intl-vpx.cnn](https://www.cnn.com/videos/world/2021/08/20/kabul-airport-chaos-afghanistan-taliban-npw-dlt-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 06:34:07+00:00

With the Taliban in control of several access points to Kabul's Hamid Karzai International Airport, residents desperate to flee Afghanistan have overwhelmed the airport's north gate. Stun grenades light up the night and US troops have had to forcefully repel the gathering crowds. CNN's Nick Paton Walsh reports.

## The 'blackest' black: How a color controversy sparked a years-long art feud
 - [https://www.cnn.com/style/article/blackest-black-ink-culture-hustle/index.html](https://www.cnn.com/style/article/blackest-black-ink-culture-hustle/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 04:31:39+00:00

For decades, the idea that somebody can "own" a color has been a contentious one.

## Afghan man hands child over barbed wire to soldier
 - [https://www.cnn.com/videos/world/2021/08/20/afghanistan-child-handed-to-soldier-kabul-airport-llr-orig.cnn](https://www.cnn.com/videos/world/2021/08/20/afghanistan-child-handed-to-soldier-kabul-airport-llr-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 04:28:05+00:00

In a video showing a crowd gathered near the airport in Kabul, Afghanistan, a man can be seen seemingly handing over his child to a soldier. Witnesses say troops are not evacuating kids without their families. CNN has reached out to the Pentagon for comment.

## OnlyFans says it will ban sexually explicit content
 - [https://www.cnn.com/2021/08/19/tech/onlyfans-sexually-explicit-content-ban-intl-hnk/index.html](https://www.cnn.com/2021/08/19/tech/onlyfans-sexually-explicit-content-ban-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 03:58:15+00:00

OnlyFans is banning sexually explicit content starting in October, the company announced Thursday.

## Kimchi's new Chinese name has become the epicenter of a cultural war ... again
 - [https://www.cnn.com/travel/article/xinqi-kimchi-new-chinese-name-cmd/index.html](https://www.cnn.com/travel/article/xinqi-kimchi-new-chinese-name-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 03:42:15+00:00

More than just a spicy staple served in Korean households and restaurants around the world, kimchi -- the iconic fermented vegetable dish -- has once again become the subject of a cultural feud between China and South Korea.

## Don Lemon on Hannity: If only we had a vaccine against B.S.
 - [https://www.cnn.com/videos/media/2021/08/20/vaccines-accountability-hannity-take-this-dlt-vpx.cnn](https://www.cnn.com/videos/media/2021/08/20/vaccines-accountability-hannity-take-this-dlt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 03:30:53+00:00

CNN's Don Lemon discusses Fox News host Sean Hannity's mixed messages around vaccines and Covid-19.

## Last living Khmer Rouge leader says not behind Cambodia genocide
 - [https://www.cnn.com/2021/08/19/asia/khieu-samphan-khmer-rouge-appeal-intl-hnk/index.html](https://www.cnn.com/2021/08/19/asia/khieu-samphan-khmer-rouge-appeal-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 03:22:59+00:00

The last surviving leader of Cambodia's Khmer Rouge regime on Thursday denied involvement in genocide and being responsible for crimes against humanity, in one of his final appearances before an international tribunal.

## Police identify suspect who surrendered after claiming to have a bomb near US Capitol
 - [https://www.cnn.com/2021/08/19/politics/us-capitol-suspected-explosives/index.html](https://www.cnn.com/2021/08/19/politics/us-capitol-suspected-explosives/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 02:41:48+00:00



## Study finds 'very concerning' 74% increase in deaths associated with extreme heat
 - [https://www.cnn.com/2021/08/19/health/heat-deaths-concerning-study/index.html](https://www.cnn.com/2021/08/19/health/heat-deaths-concerning-study/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 02:05:44+00:00

A pair of new studies out Thursday find a "very concerning" rise in the number of climate-related deaths and paint a picture of world where people struggle with regular temperature extremes.

## Video shows baby being handed over Kabul airport wall to US troops
 - [https://www.cnn.com/videos/world/2021/08/20/kth-kabul-airport-wall-baby-afghanistan-ac360-vpx.cnn](https://www.cnn.com/videos/world/2021/08/20/kth-kabul-airport-wall-baby-afghanistan-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 01:00:54+00:00

CNN's Anderson Cooper discusses the chaos and desperation in Afghanistan after the Taliban's takeover following the withdrawal of US troops.

## Painter jumps from burning boom lift
 - [https://www.cnn.com/videos/us/2021/08/20/man-jumps-from-burning-boom-lift-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2021/08/20/man-jumps-from-burning-boom-lift-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 00:42:37+00:00

Firefighters caught a man after he was trapped on a burning boom lift. CNN's Jeanne Moos reports they had a hard time convincing him to jump.

## Biden faces some of most dire days of his presidency
 - [https://www.cnn.com/2021/08/19/politics/joe-biden-afghanistan-dire-days-of-presidency/index.html](https://www.cnn.com/2021/08/19/politics/joe-biden-afghanistan-dire-days-of-presidency/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-20 00:21:59+00:00

Two photographs of President Joe Biden this week neatly illustrated the White House's fight to contain the fallout of the biggest crisis of his presidency.

