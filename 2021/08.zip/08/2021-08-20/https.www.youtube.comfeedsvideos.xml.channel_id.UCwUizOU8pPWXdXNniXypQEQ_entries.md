# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Afghanistan: Helping Biden Be Even Worse!
 - [https://www.youtube.com/watch?v=gASF7u5QWFE](https://www.youtube.com/watch?v=gASF7u5QWFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-08-21 00:00:00+00:00

Grab your Blood Sugar Breakthrough at https://bloodsugarbreakthrough.health/jp20
Use Discount Code "AWJP" for a Deal

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

With the Afghanistan situation, I sat down with Biden to help him be even worse!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## Reclaiming Your Freedom and Sovereignty With Zion!
 - [https://www.youtube.com/watch?v=MAanV-46qd8](https://www.youtube.com/watch?v=MAanV-46qd8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-08-20 00:00:00+00:00

I’m incredibly excited to share with you this movement that will be a powerful catalyst for us to reclaim our freedom in sovereignty. Zion is the worlds first decentralized social media platform built on bitcoin technology. For more on Zion including to get on the waitlist to get in, go to https://getzion.com

In this video Zion founder Justin Rezvani and I have an informal LIVE discussion about Zion and what it means to freedom and sovereignty.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

