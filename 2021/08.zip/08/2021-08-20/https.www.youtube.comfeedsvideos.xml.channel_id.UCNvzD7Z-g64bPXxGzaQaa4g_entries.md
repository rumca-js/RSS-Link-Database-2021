# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 INSANE Evil Endings You Can Unlock in Games
 - [https://www.youtube.com/watch?v=AU-ET-8qJfs](https://www.youtube.com/watch?v=AU-ET-8qJfs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-21 00:00:00+00:00

Some video game endings just feel EXTREMELY bad. Here are some of our favorite evil crazy examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Chapters:
0:00 INTRO
0:31 Detroit: Become Human
2:15 Far Cry 3
3:38 Fallout 3
5:20 Star Wars: The Force Unleashed 2
6:35 Mass Effect 2
7:51 Spiderman: Web of Shadows
9:26 True Crime: Streets of LA
10:31 Zone of The Enders
11:43 Persona 4
12:36 Shadow of Destiny

## Ghost of Tsushima Director's Cut - Before You Buy
 - [https://www.youtube.com/watch?v=kbSozPzaNlA](https://www.youtube.com/watch?v=kbSozPzaNlA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-21 00:00:00+00:00

Ghost of Tsushima Director's Cut (PS4, PS5) brings new updates and improvements as well as a content expansion into a whole new island. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Skyward Sword: https://amzn.to/3z7rl8p


Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## NEW UNREAL ENGINE 5 GAME LOOKS INSANE, SKYRIM RELEASED ONE MORE TIME, & MORE
 - [https://www.youtube.com/watch?v=yIPNjjN_cCQ](https://www.youtube.com/watch?v=yIPNjjN_cCQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-20 00:00:00+00:00

Thanks to ExpressVPN for sponsoring this video! Go to https://expressvpn.com/gameranx and find out how you can get 3 months of ExpressVPN free!

Black Myth looks graphically amazing, Quake gets a surprise re-release,  Call of Duty Vanguard is revealed, and more in a week full of gaming news.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake's other channel: https://youtu.be/qH2O49EQop4



 ~~~~STORIES~~~~




Skyrim, AGAIN
https://www.windowscentral.com/bethesda-releasing-skyrim-yet-again-time-xbox-series-xs-and-ps5
https://www.ign.com/articles/skyrim-10th-anniversary-remaster-ps5-xbox-series-x


Black Myth Wukong:
https://youtu.be/nOMIwsupy9k


Saints Row returns
https://twitter.com/SaintsRow/status/1428724454314631171?s=20



Call of Duty Vanguard 
https://youtu.be/LE9ZqVo1NYc

https://www.pcgamer.com/cod-vanguard-ww2-campaign-preview/


QUAKE
https://youtu.be/fQRlgYT0xfA

FRIDAY READ
https://www.gamesradar.com/how-assassins-creed-valhalla-cyberpunk-2077-and-yakuza-set-new-standards-for-in-game-tattoos/


New Metroid trailer:
https://youtu.be/fDF5xpjGzBs

Pokemon Arceus 
https://youtu.be/IqLibUGxrE0

Siege Resident Evil stuff
https://www.youtube.com/watch?v=HgK_sURjI0Y
AC
https://www.youtube.com/watch?v=7YpxeHcyFTc

Fortnite Impostors
https://youtu.be/W1RNbUaCKHA


Bloodborne FPS
https://youtu.be/5ajjDb1n1-s

Milestone fundraising 
https://www.ign.com/articles/steven-spohn-able-gamers-charity-fundraising-drive-disabled-gamers?taid=611ef92aec41d30001d0b411&utm_campaign=trueAnthem:+Manual&utm_medium=trueAnthem&utm_source=facebook

