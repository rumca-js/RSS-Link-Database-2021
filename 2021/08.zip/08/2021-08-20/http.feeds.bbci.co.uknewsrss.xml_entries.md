# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Woke: Compliment or criticism, it is now fuelling the culture wars
 - [https://www.bbc.co.uk/news/uk-politics-58281576](https://www.bbc.co.uk/news/uk-politics-58281576)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:59:04+00:00

The surprising history of a term increasingly thrown around in UK political debate.

## Afghan crisis: Russia plans for new era with Taliban rule
 - [https://www.bbc.co.uk/news/world-europe-58265934?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58265934?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:58:02+00:00

While Western governments raced to get their people out, Russia appears unfazed by the takeover.

## Afghan crisis: Russia plans for new era with Taliban rule
 - [https://www.bbc.co.uk/news/world-europe-58265934](https://www.bbc.co.uk/news/world-europe-58265934)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:58:02+00:00

While Western governments raced to get their people out, Russia appears unfazed by the takeover.

## Computer Space and beyond: 50 years of gaming
 - [https://www.bbc.co.uk/news/technology-58281812](https://www.bbc.co.uk/news/technology-58281812)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:52:33+00:00

From an arcade game to a multi-billion pound industry, the BBC charts the ups and downs of video games.

## OnlyFans porn ban a 'kick in the teeth' for creators
 - [https://www.bbc.co.uk/news/newsbeat-58282653](https://www.bbc.co.uk/news/newsbeat-58282653)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:48:35+00:00

Content creators aren't pleased about the site's decision to ban explicit content from October.

## Week in pictures: 14 - 20 August 2021
 - [https://www.bbc.co.uk/news/in-pictures-58274001](https://www.bbc.co.uk/news/in-pictures-58274001)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:44:18+00:00

A selection of powerful images from all over the globe, taken this week.

## 'I play carrom with my feet'
 - [https://www.bbc.co.uk/news/world-asia-india-58265853](https://www.bbc.co.uk/news/world-asia-india-58265853)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:41:43+00:00

Twenty-three-year-old Harshad Gothankar was born without arms, but he is now a state carrom champion.

## Covid: CO2 monitors pledged to aid school ventilation
 - [https://www.bbc.co.uk/news/education-58285359](https://www.bbc.co.uk/news/education-58285359)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:32:24+00:00

Schools in England are to be given CO2 monitors to as part of plans to limit the spread of Covid.

## How Afghanistan's media is changing under Taliban rule
 - [https://www.bbc.co.uk/news/world-asia-58273011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-58273011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:07:48+00:00

The Taliban are currently on a media offensive but does their rhetoric match what’s happening on the ground?

## How Afghanistan's media is changing under Taliban rule
 - [https://www.bbc.co.uk/news/world-asia-58273011](https://www.bbc.co.uk/news/world-asia-58273011)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:07:48+00:00

The Taliban are currently on a media offensive but does their rhetoric match what’s happening on the ground?

## The West End star who worked as carer during lockdown
 - [https://www.bbc.co.uk/news/entertainment-arts-58080453](https://www.bbc.co.uk/news/entertainment-arts-58080453)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 23:05:03+00:00

As theatres reopen, actors like Stephen Beckett have been swapping their lockdown jobs for their place on the stage once more.

## Ever Given: Cargo ship returns through Suez Canal it blocked
 - [https://www.bbc.co.uk/news/world-middle-east-58288512](https://www.bbc.co.uk/news/world-middle-east-58288512)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 21:38:50+00:00

Global trade was disrupted in March when the massive container ship became stuck in the waterway.

## Afghanistan: The desperate scramble to escape
 - [https://www.bbc.co.uk/news/world-asia-58286000?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-58286000?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 20:54:30+00:00

The BBC witnesses scenes of chaos and panic as thousands still crowd Kabul's airport.

## Afghanistan: The desperate scramble to escape
 - [https://www.bbc.co.uk/news/world-asia-58286000](https://www.bbc.co.uk/news/world-asia-58286000)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 20:54:30+00:00

The BBC witnesses scenes of chaos and panic as thousands still crowd Kabul's airport.

## 'They will kill me': Desperate Afghans seek way out after Taliban takeover
 - [https://www.bbc.co.uk/news/world-asia-58286372?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-58286372?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 19:32:19+00:00

Many Afghans are desperate to escape after the Taliban takeover. Some fear there is no way out.

## 'They will kill me': Desperate Afghans seek way out after Taliban takeover
 - [https://www.bbc.co.uk/news/world-asia-58286372](https://www.bbc.co.uk/news/world-asia-58286372)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 19:32:19+00:00

Many Afghans are desperate to escape after the Taliban takeover. Some fear there is no way out.

## Covid cases: This summer compared with last
 - [https://www.bbc.co.uk/news/health-58281664](https://www.bbc.co.uk/news/health-58281664)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 18:31:38+00:00

Case numbers are 30 times higher than at the same point last year - where might we be heading next?

## Family of American taken by Taliban beg for return
 - [https://www.bbc.co.uk/news/world-us-canada-58276062?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-58276062?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 14:32:00+00:00

Mark Frerichs, 59, one of the last Americans kidnapped by the Taliban, is stuck in Afghanistan.

## Family of American taken by Taliban beg for return
 - [https://www.bbc.co.uk/news/world-us-canada-58276062](https://www.bbc.co.uk/news/world-us-canada-58276062)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 14:32:00+00:00

Mark Frerichs, 59, one of the last Americans kidnapped by the Taliban, is stuck in Afghanistan.

## Streatham terror attack: Prison recall may have stopped Sudesh Amman
 - [https://www.bbc.co.uk/news/uk-england-london-58281243](https://www.bbc.co.uk/news/uk-england-london-58281243)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 11:53:57+00:00

There were opportunities to stop Sudesh Amman stabbing two people in south London, an inquest finds.

## Dominic Raab defends lack of Afghan interpreter call
 - [https://www.bbc.co.uk/news/uk-politics-58282163](https://www.bbc.co.uk/news/uk-politics-58282163)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 11:41:17+00:00

The UK foreign secretary is facing calls to quit over his handling of evacuations.

## Arsenal sign Odegaard from Real Madrid as Ramsdale completes medical
 - [https://www.bbc.co.uk/sport/football/58279217](https://www.bbc.co.uk/sport/football/58279217)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 11:38:03+00:00

Arsenal sign midfielder Martin Odegaard from Real Madrid for about £30m and are close to completing a deal for Sheffield United goalkeeper Aaron Ramsdale.

## NZ cancellation lacked respect - Wallabies coach Rennie
 - [https://www.bbc.co.uk/sport/rugby-union/58278473](https://www.bbc.co.uk/sport/rugby-union/58278473)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 11:36:16+00:00

Australia coach Dave Rennie says he is "bloody angry" about New Zealand's decision to cancel the teams' Bledisloe Cup match without telling the Wallabies.

## Rafael Nadal: Spaniard ends 2021 season because of foot injury
 - [https://www.bbc.co.uk/sport/tennis/58281962](https://www.bbc.co.uk/sport/tennis/58281962)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 11:00:45+00:00

Spain's 20-time Grand Slam champion Rafael Nadal has ended his 2021 season because of a foot injury.

## Afghanistan: Tears and applause as UK appeal helps refugees
 - [https://www.bbc.co.uk/news/uk-58281203?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58281203?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 10:59:46+00:00

People in Chapel-en-le-Frith in the Peak District collected more than 1,000 bags of donations in 48 hours.

## Afghanistan: Tears and applause as UK appeal helps refugees
 - [https://www.bbc.co.uk/news/uk-58281203](https://www.bbc.co.uk/news/uk-58281203)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 10:59:46+00:00

People in Chapel-en-le-Frith in the Peak District collected more than 1,000 bags of donations in 48 hours.

## Morrisons backs US firm's improved £7bn takeover offer
 - [https://www.bbc.co.uk/news/business-58273916](https://www.bbc.co.uk/news/business-58273916)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 10:48:55+00:00

But shares in the supermarket open higher, suggesting some investors think the £7bn-plus battle is not over.

## Covid-antibody therapy approved in UK
 - [https://www.bbc.co.uk/news/health-58281332](https://www.bbc.co.uk/news/health-58281332)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 10:48:21+00:00

Antibody therapy - given to former US President Donald Trump - can now be used in the UK.

## Tokyo Paralympics: Eight global athletes to watch at Games
 - [https://www.bbc.co.uk/sport/disability-sport/58203418?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/disability-sport/58203418?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 09:58:43+00:00

From the Blade Jumper to the dancing star and the Tik Tok influencer, meet some of the global athletes hoping to make an impact at the Tokyo Paralympics.

## Sonny Chiba: Japan's martial arts star and Kill Bill actor dies of Covid at 82
 - [https://www.bbc.co.uk/news/entertainment-arts-58279397](https://www.bbc.co.uk/news/entertainment-arts-58279397)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 09:54:30+00:00

The actor and martial arts legend played a swordsmith in Quentin Tarantino's Kill Bill films.

## Red phone box stolen from Cheshire garden in broad daylight
 - [https://www.bbc.co.uk/news/uk-england-manchester-58280733](https://www.bbc.co.uk/news/uk-england-manchester-58280733)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 09:38:59+00:00

Three men used a digger to steal the phone box, belonging to Chelford Parish Council, police say.

## SNP and Greens agree new power-sharing deal
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-58272209](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-58272209)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 07:04:44+00:00

The agreement will see Greens enter national government for the first time anywhere in the UK.

## Osaka beaten by Swiss wildcard Teichmann at Cincinnati Masters
 - [https://www.bbc.co.uk/sport/tennis/58276218](https://www.bbc.co.uk/sport/tennis/58276218)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 06:57:09+00:00

World number two Naomi Osaka suffers a surprise third-round defeat to Swiss wildcard Jil Teichmann at the Cincinnati Masters.

## Lockdown screen time sees rise in short-sightedness among children
 - [https://www.bbc.co.uk/news/health-58274916](https://www.bbc.co.uk/news/health-58274916)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 05:35:08+00:00

Optometrists are diagnosing higher numbers of children with short-sightedness since the start of the pandemic.

## Record number of bids for UK City of Culture 2025
 - [https://www.bbc.co.uk/news/uk-england-58272630](https://www.bbc.co.uk/news/uk-england-58272630)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 05:16:06+00:00

For the first time groups of towns or areas have been able to bid for the cultural capital title.

## The Hundred: Hales, Parkinson, Brunt - watch 10 memorable moments
 - [https://www.bbc.co.uk/sport/av/cricket/58238657](https://www.bbc.co.uk/sport/av/cricket/58238657)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 05:08:26+00:00

Watch 10 memorable moments from the inaugural season of The Hundred, featuring Imran Tahir's hat-trick, Katherine Brunt v Shafali Verma, and Ravi Bopara's underpants.

## Facebook moves to protect Afghan users' accounts amid Taliban takeover
 - [https://www.bbc.co.uk/news/technology-58277175?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-58277175?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 04:45:02+00:00

The tech giant says it wants to reassure people worried about being tracked down by the Taliban.

## Facebook moves to protect Afghan users' accounts amid Taliban takeover
 - [https://www.bbc.co.uk/news/technology-58277175](https://www.bbc.co.uk/news/technology-58277175)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 04:45:02+00:00

The tech giant says it wants to reassure people worried about being tracked down by the Taliban.

## Afghanistan: Taliban 'tortured and massacred' men from Hazara minority
 - [https://www.bbc.co.uk/news/world-asia-58277463](https://www.bbc.co.uk/news/world-asia-58277463)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 03:53:03+00:00

Rights group Amnesty says the recent killings of men from the Hazara minority were a "horrifying indicator" of Taliban rule.

## The Papers: 'Bad call, minister' as pressure increases on Raab
 - [https://www.bbc.co.uk/news/blogs-the-papers-58276354](https://www.bbc.co.uk/news/blogs-the-papers-58276354)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 03:48:31+00:00

Some of the papers focus on the future of the foreign secretary over his handling of the Afghanistan crisis.

## What's behind the rising gun violence in the US?
 - [https://www.bbc.co.uk/news/world-us-canada-58207384](https://www.bbc.co.uk/news/world-us-canada-58207384)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 01:30:15+00:00

After a decline, gun violence in cities like Washington DC has been increasing since 2018.

## 'We felt free': Cubans remain defiant in face of protest crackdown
 - [https://www.bbc.co.uk/news/world-latin-america-58255555](https://www.bbc.co.uk/news/world-latin-america-58255555)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-20 00:56:55+00:00

A month after rare anti-government protests in Cuba, many of those who took part remain defiant.

