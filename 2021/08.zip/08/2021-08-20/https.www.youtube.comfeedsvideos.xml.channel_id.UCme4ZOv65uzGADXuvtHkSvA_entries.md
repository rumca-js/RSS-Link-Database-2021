# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#248] A co gdybym porzucił wiarę?
 - [https://www.youtube.com/watch?v=LzN1dgNgQZc](https://www.youtube.com/watch?v=LzN1dgNgQZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-21 00:00:00+00:00

​@Langustanapalmie #kazankodookienka #dobrewiadomości

1. czytanie (Joz 24, 1-2a. 15-17. 18b)

Jozue zgromadził w Sychem wszystkie pokolenia Izraela. Wezwał też starszych Izraela, jego książąt, sędziów i zwierzchników, którzy się stawili przed Bogiem. Jozue przemówił wtedy do całego narodu: «Gdyby wam się nie podobało służyć Panu, rozstrzygnijcie dziś, komu służyć chcecie, czy bóstwom, którym służyli wasi przodkowie po drugiej stronie Rzeki, czy też bóstwom Amorytów, w których kraju zamieszkaliście. Ja sam i mój dom służyć chcemy Panu». Naród wówczas odrzekł tymi słowami: «Dalecy jesteśmy od tego, abyśmy mieli opuścić Pana, a służyć cudzym bogom. Czyż to nie Pan, Bóg nasz, wyprowadził nas i przodków naszych z ziemi egipskiej, z domu niewoli? Czyż nie On przed oczyma naszymi uczynił wielkie znaki i ochraniał nas przez całą drogę, którą szliśmy, i wśród wszystkich ludów, pomiędzy którymi przechodziliśmy? My również chcemy służyć Panu, bo On jest naszym Bogiem».

2. czytanie (Ef 5, 21-32)

Bracia:
Bądźcie sobie wzajemnie poddani w bojaźni Chrystusowej. Żony niechaj będą poddane swym mężom, jak Panu, bo mąż jest głową żony, jak i Chrystus – Głową Kościoła: On – Zbawca Ciała. Lecz jak Kościół poddany jest Chrystusowi, tak i żony mężom – we wszystkim.
Mężowie, miłujcie żony, bo i Chrystus umiłował Kościół i wydał za niego samego siebie, aby go uświęcić, oczyściwszy obmyciem wodą, któremu towarzyszy słowo, aby samemu sobie przedstawić Kościół jako chwalebny, niemający skazy czy zmarszczki, czy czegoś podobnego, lecz aby był święty i nieskalany. Mężowie powinni miłować swoje żony, tak jak własne ciało. Kto miłuje swoją żonę, siebie samego miłuje. Przecież nigdy nikt nie odnosił się z nienawiścią do własnego ciała, lecz każdy je żywi i pielęgnuje, jak i Chrystus – Kościół, bo jesteśmy członkami Jego Ciała.
Dlatego opuści człowiek ojca i matkę, a połączy się z żoną swoją, i będą dwoje jednym ciałem. Tajemnica to wielka, a ja mówię: w odniesieniu do Chrystusa i do Kościoła.

Ewangelia (J 6, 55. 60-69)

W synagodze w Kafarnaum Jezus powiedział:
«Ciało moje jest prawdziwym pokarmem, a Krew moja jest prawdziwym napojem». A wielu spośród Jego uczniów, którzy to usłyszeli, mówiło: «Trudna jest ta mowa. Któż jej może słuchać?» Jezus jednak, świadom tego, że uczniowie Jego na to szemrali, rzekł do nich: «To was gorszy? A gdy ujrzycie Syna Człowieczego wstępującego tam, gdzie był przedtem? To Duch daje życie; ciało na nic się nie zda. Słowa, które Ja wam powiedziałem, są duchem i są życiem. Lecz pośród was są tacy, którzy nie wierzą». Jezus bowiem od początku wiedział, którzy nie wierzą, i kto ma Go wydać. Rzekł więc: «Oto dlaczego wam powiedziałem: Nikt nie może przyjść do Mnie, jeżeli nie zostało mu to dane przez Ojca». Od tego czasu wielu uczniów Jego odeszło i już z Nim nie chodziło. Rzekł więc Jezus do Dwunastu: «Czyż i wy chcecie odejść?» Odpowiedział Mu Szymon Piotr: «Panie, do kogo pójdziemy? Ty masz słowa życia wiecznego. A my uwierzyliśmy i poznaliśmy, że Ty jesteś Świętym Bożym».
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Kapłańska || Rozdział 26
 - [https://www.youtube.com/watch?v=UqvlXVImsfA](https://www.youtube.com/watch?v=UqvlXVImsfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-21 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#869] Brudne
 - [https://www.youtube.com/watch?v=_ZMiFNKbUaU](https://www.youtube.com/watch?v=_ZMiFNKbUaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-21 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Kapłańska || Rozdział 25
 - [https://www.youtube.com/watch?v=Mxf9bCW_Tdc](https://www.youtube.com/watch?v=Mxf9bCW_Tdc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#868] Wierzę
 - [https://www.youtube.com/watch?v=WEL1q_oMKhQ](https://www.youtube.com/watch?v=WEL1q_oMKhQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-20 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

