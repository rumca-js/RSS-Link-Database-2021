# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Capturing 920K Video! - HOLY $H!T
 - [https://www.youtube.com/watch?v=umyglbDr4IE](https://www.youtube.com/watch?v=umyglbDr4IE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-21 00:00:00+00:00

Receive a $25 credit for Ting Mobile today when you sign up at https://linus.ting.com/

Check out ORIGIN PC gaming laptops and desktops today at https://bit.ly/2Np7cZn

Watch Demonic: https://www.demonicmovie.com/

We were invited to the set of Neill Blomkamp's new movie Demonic to check out their crazy Volumetric Capture setup.

Check out Volumetric Camera Systems:
Website: https://www.volumetriccamerasystems.com/
Facebook: https://www.facebook.com/VolumetricCameraSystems/
Twitter: https://twitter.com/VolumetricCams
Linkedin: https://www.linkedin.com/company/68929650/admin/
Instagram: https://www.instagram.com/volumetriccamerasystems/

Discuss on the forum: https://linustechtips.com/topic/1366999-capturing-920k-video/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Green Man Gaming https://lmg.gg/GMGLTT
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 - Peacemaker Filmworks
0:55 - Origin PC
1:10 - Intro
1:18 - Yi Camera x239
2:15 - AI Feature Detection
3:30 - Large vs. High Resolution Array
4:17 - AI Upscaling
5:10 - Many a Computer
6:05 - Post Processing
7:26 - Lighting
8:13 - lttstore.com
8:16 - Volumetric capture on the go
8:56 - Additional use cases
10:12 - Ting
10:51 - Outro

## Should we Make Our Own OnlyFans Competitor? - WAN Show August 20, 2021
 - [https://www.youtube.com/watch?v=ussc5w4Tr2M](https://www.youtube.com/watch?v=ussc5w4Tr2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-20 00:00:00+00:00

Buy the Elgato Facecam today at https://geni.us/cvxrCH

Buy a Seasonic Ultra Titanium PSU
On Amazon: https://geni.us/q4lnefC
On NewEgg: https://lmg.gg/8KV3S

Start your build today at https://www.buildredux.com/linus

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Should-we-Make-Our-Own-OnlyFans-Competitor----WAN-Show-August-20--2021-e16ba51

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps  (Courtesy of NoKi1119)

[0:00] Chapters.
[2:18] Intro.
[3:03] Topic #1: OnlyFans banning NSFW content.
   3:26 LTT's OnlyFans.
    5:07 OnlyFans is NOT explicitly adult content.
    9:55 Comparing to Tumblr's decision.
    11:23 Discussing policies.
    16:12 Floatplane could have been an adult site.
    18:58 Is this the end of OnlyFans?
    21:34 How the adult industry shapes techs.
    23:55 LTT would not be involved in the industry.
[26:56] Topic #2: ARC: Intel's new brand.
    27:20 Discussing ARC and specs.
    31:44 Intel's Alder Lake and specs.
    33:59 In-CPU EMC technology.
[35:54] Sponsors.
    36:01 Build Redux PC Builder.
    36:31 Elgato Facecam.
    37:34 Seasonic's Ultra Titanium PSUs.
[38:03] Topic #3: Epic copies Among Us in Fortnite.
    40:39 Comparisons between the games.
[44:51] Topic #4: Gigabyte responds to "exploding" PSUs.
[47:55] Topic #5: Halo Infinite has NO co-op.
[51:23] LTTstore new merch.
[54:03] Superchats.
[1:03:51] Most purchased LTT lanyards
[1:05:47] Wrapping up.
[1:06:08] Outro.

