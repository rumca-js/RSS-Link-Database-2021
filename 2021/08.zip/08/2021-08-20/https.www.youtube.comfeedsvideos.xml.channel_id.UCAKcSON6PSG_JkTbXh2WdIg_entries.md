# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Michigander - Better (live #MicroShow performance)
 - [https://www.youtube.com/watch?v=UA9UU2kYeJs](https://www.youtube.com/watch?v=UA9UU2kYeJs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-08-21 00:00:00+00:00

Recorded live on August 3, 3031 at the Icehouse in Minneapolis, Detroit's  @Michigander made a grand return to Minnesota for The Current's first #MicroShow in over a year, including "Better" from his 2021 EP, Everything Will Be Okay Eventually.

Watch the full #MicroShow performance: https://youtu.be/KqceOXzSe7c

The Current's #MicroShows are produced in partnership with New Belgium Brewing.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Interview: Ani DiFranco on 'Revolutionary Love'
 - [https://www.youtube.com/watch?v=7UmGqLJ0MZU](https://www.youtube.com/watch?v=7UmGqLJ0MZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-08-20 00:00:00+00:00

Ani DiFranco joins Jill Riley from The Current to talk about the making of her new record, 'Revolutionary Love,' as well as her recent memoir 'No Walls and the Recurring Dream'. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Michigander - Misery (live #MicroShow performance)
 - [https://www.youtube.com/watch?v=KGJ_swwGDQw](https://www.youtube.com/watch?v=KGJ_swwGDQw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-08-20 00:00:00+00:00

Recorded live on August 3, 3031 at the Icehouse in Minneapolis, Detroit's @Michigander made a grand return to Minnesota for The Current's first #MicroShow in over a year, including his 2019 single, "Misery".

Watch the full #microshow performance: https://youtu.be/KqceOXzSe7c

The Current's #MicroShows are produced in partnership with New Belgium Brewing.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

