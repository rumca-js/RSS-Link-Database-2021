# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Personal Update 2
 - [https://www.youtube.com/watch?v=nD73ntUH9EQ](https://www.youtube.com/watch?v=nD73ntUH9EQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-08-20 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Helloooo! Just wanted to give you a little update on how things are going post-op, and what we’ve been up to.

