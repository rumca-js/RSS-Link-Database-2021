# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Glaurung, Ancalagon, & the Dragons of The Silmarillion | Tolkien Explained
 - [https://www.youtube.com/watch?v=0dkHn3bI0-Q](https://www.youtube.com/watch?v=0dkHn3bI0-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-08-21 00:00:00+00:00

Covering the origins and lives of the great dragons of the First Age.  Created by Morgoth to help defeat the Noldor, the dragons would be some of the most powerful and cunning of all evil beings.  Today, we feature the lives of Glaurung and Ancalagon the Black - the two most famous early dragons, as well as lesser known dragons like Gostir.

Glaurung, the father of dragons, shows his ability not only to destroy with his fire, but to manipulate with his words and bewitch with his gaze.  He even speaks with his master's voice at one point!  Ancalagon, the greatest and most powerful of Morgoth's dragons, would nearly win the War of Wrath for the Dark Lord, before being defeated in one of the most epic battles in Middle-earth History.

*Hit subscribe - and the bell!* 
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark

Glaurung - Nicolas Peña-Amisgaudi
Ancalagon the Black - Anato Finnstark
Glaurung - Justin Gerard
Dragons of the War of Wrath - Anato Finnstark
Dragon of the First Age - Ruben Devela
Morgoth and the Dragons - Anato Finnstark
The Siege of Angband - John Howe
Beleriand Map - Lamaarcana
Melkor - Anatasiya Cemetery
Dagor Argaleb - Luis F Bejarano
Glaurung - GabrielDNC
Glaurung - Denis Gordeev
The Coming of Glaurung - Alan Lee
Then Fingon rose against him - Jenny Dolfen
Glaurung the Deceiver - Simona Brunilde Jero
Glaurung - Miguel Pineda
Glaurung - Alvyne Sebalj
Azaghal the Great King of Belegost - DracarysDrekkar7
Nirnaeth Arnoediad - Jenny Dolfen
The Hill of the Slain - Ted Nasmith
Glaurung at Nargothrond - George Sukhoff
Turin Bemused by the Eyes of Glaurung - Alan Lee
Turin and Glaurung - Abe Papakhian
Sack of Nargothrond - Donato Giancola
Finduilas is Led Past Turin at Nargothrond - Ted Nasmith
The Fall of Nargothrond - Wouter Florusse
Turin Confronts Glaurung - Turner Mohan
Finduilas Led By Turin - Denis Gordeev
Glaurung - Turner Mohan
Turin in Nargothrond - Klaus Wittmann
Fall of Nargothrond - Alan Lee
The Journey of Morwen and Nienor - Alan Lee
Nienor confronts Glaurung - Jonathan Guzi
Nienor and Glaurung - Donato Giancola
Nienor and Glaurung - John Howe
Glaurung's Gaze - Ebe Kastein
Nienor Awakens - Peter Xavier Price
Turin and Glaurung - Helge C Balzer
Beneath the Dragon - Matt Stewart
Wilt thou take Turin Turambar - Peter Xavier Price
Glaurung - Nicolas Peña-Amisgaudi
The Death of Glaurung - John Howe
Nienor and Glaurung - Anke Eissmann
The Slaying of Glaurung - Darrell Sweet
Nienor finds Turin - Kenneth Sofia
Nienor finds Turin - Denis Gordeev
Nienor discovers Turin - Alarie
Nienor's fall at Cabed-en-Aras - Nim Lock
The Death of Glaurung - Alan Lee
Turin - Klaus Wittmann
Glaurung and Turin - Hoch Spannung
Dragon - Luo Haitao
Gondolin Falls - Federico Cimini
Flight of the Doomed - Ted Nasmith
The King's Tower Falls - Alan Lee
The Great Worms Attack - Turner Mohan
Beast of Gondolin - George Sukhoff
Ancalagon - Anato Finnstark
Ancalagon the Black - CK Goksoy
Ancalagon the Black - Anato Finnstark
The Dragon and the Star - Manuel Castanon
Ancalagon and Earenedil - Lorenzo De Sanctis Drago
Ancalagon and Earendil - Ivana Lekseich
Ancalagon attacks Vingilot - Lourdes Velez
Ancalagon atop Thangorodrim - Jovan Delic
Ancalagon the Black - CK Goksoy
Morgoth Defeated - Renato C Domingos
Ancalagon the Black - Federico Cimini
Dan I The Last King of the Grey Mountains - Jack Dullahan
Smaug - TheRisingSoul

#tolkien #dragons #silmarillion

