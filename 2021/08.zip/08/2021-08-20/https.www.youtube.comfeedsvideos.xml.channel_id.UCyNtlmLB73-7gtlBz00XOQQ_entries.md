# Source:FoldingIdeas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ, language:en-US

## An Exhaustive History of Ralph Bakshi's Lord of the Rings
 - [https://www.youtube.com/watch?v=Cr_rb_pitHk](https://www.youtube.com/watch?v=Cr_rb_pitHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ
 - date published: 2021-08-20 18:27:15+00:00

While the video talks mostly about The Lord of the Rings (1978) there is a discussion of Bakshi's earlier R-rated and NC-17 films, which deal with heavy subject matter like racism, police violence, transphobia, drug abuse, and various adult scenarios.

This was intended to be a quick little video that I could churn out in a couple weeks at the end of June, but it's now taken almost the whole summer. I haven't done animation like this in years, and never with this kind of a coherent goal, so approximately 48 seconds of this video consumed 80% of the entire post production time.

Written and performed by Dan Olson

Background artist: Agata Pankowska
https://twitter.com/AgataPortfolio

Crowdfunding: https://www.patreon.com/foldablehuman
Twitter: https://twitter.com/FoldableHuman

