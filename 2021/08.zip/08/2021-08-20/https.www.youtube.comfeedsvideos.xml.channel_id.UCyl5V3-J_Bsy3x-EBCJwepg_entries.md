# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Carolina Reaper Blazing Love Barrage and also Hunter Biden
 - [https://www.youtube.com/watch?v=lkPP1zoB6RI](https://www.youtube.com/watch?v=lkPP1zoB6RI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-20 00:00:00+00:00

In this episode of The Bee Weekly, Kyle and Ethan suffer severe gastrointestinal distress when they are subjected to the One Chip Challenge. They attempt to sing to a subscriber in the language of her choosing before then attempting to read weird news while digesting the Carolina Reaper and Scorpion Pepper seasoned tortilla chips. Then they talk to documentary filmmaker Phelim McAleer about My Son Hunter (https://mysonhunter.com/). Kyle and Ethan power through the pain to laugh at some hate mail and enter the subscriber-exclusive lounge.

This episode of The Bee Weekly is brought to you by Conservative Conversations by Intercollegiate Studies Institute (https://isi.org/podcasts/bee/). Enjoy in-depth conversations with leading thinkers on the most important issues facing conservatism.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Watch This Video Before It Gets Demonetized
 - [https://www.youtube.com/watch?v=8J2hycw5EFs](https://www.youtube.com/watch?v=8J2hycw5EFs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-20 00:00:00+00:00

Is this video full of misinformation and should be demonetized? Watch and find out before it’s too late.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

