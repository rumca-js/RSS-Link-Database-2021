# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Microsoft's Home of The Future 3: The Last Stand
 - [https://www.youtube.com/watch?v=YnF0n1zyNwM](https://www.youtube.com/watch?v=YnF0n1zyNwM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-08-20 00:00:00+00:00

Yet again we find ourselves with the greatest home in the world

IT’s Microsoft’s house

He lives here




NEW CHANNEL HERE IS NEW CHANNEL WATCH NEW CHANNEL HERE WATCH?:
https://www.youtube.com/c/Whimsu




Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
secret: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

Some music from vid is on my soundcloud, or Epidemic Sound, or somewhere in between?

Some music provided by:
https://soundcloud.com/sarahtheillstrumentalist




Original Tour of Home by RSVLTS
https://www.youtube.com/watch?v=_vsoBsgqoEg
https://www.youtube.com/watch?v=9fw4VkVRmLQ
https://www.youtube.com/watch?v=UgrwnCJRh8Y



Additional Footage Credits:
GarlandTheGreat
Bumbles McFumbles
DetroitBORG

