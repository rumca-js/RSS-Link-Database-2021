# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "I Got Family" / Remixing Dominic Toretto / Fast & Furious Song
 - [https://www.youtube.com/watch?v=NVFy25zaX6I](https://www.youtube.com/watch?v=NVFy25zaX6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-08-20 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong "I don't have friends. I got family"
"What's real, is family"
- Dom Toretto

Created with:
@teenageengineering OP-1
@KorgOfficial Minilogue
@KorgOfficial Microkorg
@MoogMusicInc Sub37
@1010music Blackbox & Bluebox
@strymon Mobius & Bigsky
and completed in Logic Pro X using stock plugins and instruments.

0:00 Making-of
3:04 Full Song

