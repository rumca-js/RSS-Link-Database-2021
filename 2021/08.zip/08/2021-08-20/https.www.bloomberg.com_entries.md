## OnlyFans to Bar Sexually Explicit Videos Starting in October - Bloomberg
 - [https://www.bloomberg.com/news/articles/2021-08-19/onlyfans-to-block-sexually-explicit-videos-starting-in-october](https://www.bloomberg.com/news/articles/2021-08-19/onlyfans-to-block-sexually-explicit-videos-starting-in-october)
 - RSS feed: https://www.bloomberg.com
 - date published: 2021-08-20 11:55:58.064635+00:00

OnlyFans is getting out of the pornography business.

