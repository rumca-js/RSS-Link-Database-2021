# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## A Blunt Moment - JRE Toons
 - [https://www.youtube.com/watch?v=pH8cH3V8JBs](https://www.youtube.com/watch?v=pH8cH3V8JBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-21 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1269 with Bryan Callen - Now Available exclusively on Spotify - https://open.spotify.com/episode/61Avm8lfXysH37LMbRFtEW?si=nZvcEC6fR46mnedJP6QXpA&dl_branch=1

## Why Megan Murphy Was Banned from Twitter for Life
 - [https://www.youtube.com/watch?v=7xhBnWGpI7c](https://www.youtube.com/watch?v=7xhBnWGpI7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-20 00:00:00+00:00

Taken from JRE #1699 w/Meghan Murphy:
https://open.spotify.com/episode/6yc6AIMf3JqLWygLQJ4Wrg?si=q6ChWS6rTLSPBuaYi1XWnA&dl_branch=1

