# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Samsung is finally ditching ads in OneUI
 - [https://www.youtube.com/watch?v=wqDadWihero](https://www.youtube.com/watch?v=wqDadWihero)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-08-20 00:00:00+00:00

Sponsored by Brilliant. The first 200 people to sign up get 20% off their annual premium subscription: https://brilliant.org/tfc

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week, Samsung finally decided to abandon ads in OneUI, OPPO teased fancy new camera tech, including a telephoto lens with continuous zoom, Windows 11 got a face lift and Intel spilled the beans on its ARC GPUs.

Episode 59

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-samsung-is-finally-ditching-ads

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:31 Release Monitor
1:54 Samsung abandons ads
3:26 OPPO's new camera tech
4:59 Windows 11 updates
5:42 Intel ARC GPUs detailed

