# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Mad Foxes - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=iFJHBqnmLmM](https://www.youtube.com/watch?v=iFJHBqnmLmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-21 00:00:00+00:00

http://KEXP.ORG presents Mad Foxes performing live, recorded exclusively for KEXP. 

Songs:
Ashamed
Gender Eraser
The Cheapest Friend
Home
Fear Of Love

Session recorded at Le Centre Brassens in Avrillé, France
Audio Recording, Mix & Master: Christophe Hogommat 
Video: Yohan Gerard, Aaron Benjamin & Naeva Nualas 
Thank you to Romain Mulochau & Le Centre Brassens in Avrillé, Catherine Rué, Alexis Prevost, Jim Beckmann & John Richards

Lucas Bonfils (guitar, vocals)
Elie Paquereau (vocals, drums)
Arnaud Turquier (bass)

https://madfoxes1.bandcamp.com
https://brassens.ville-avrille.fr
http://kexp.org

## Mad Foxes - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=hj0dKCyddfM](https://www.youtube.com/watch?v=hj0dKCyddfM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-20 00:00:00+00:00

http://KEXP.ORG presents Mad Foxes sharing a live performance recorded exclusively for KEXP. Singer/guitarist Lucas Bonfils talks with John Richards, host of The Morning Show. Recorded August 16, 2021.

Songs:
Ashamed
Gender Eraser
The Cheapest Friend
Home
Fear Of Love

Session recorded at Le Centre Brassens in Avrillé, France
Audio Recording, Mix & Master: Christophe Hogommat 
Video: Yohan Gerard, Aaron Benjamin & Naeva Nualas 
Thank you to Romain Mulochau & Le Centre Brassens in Avrillé, Catherine Rué, Alexis Prevost, Jim Beckmann & John Richards

Lucas Bonfils (guitar, vocals)
Elie Paquereau (vocals, drums)
Arnaud Turquier (bass)

https://madfoxes1.bandcamp.com
https://brassens.ville-avrille.fr
http://kexp.org

