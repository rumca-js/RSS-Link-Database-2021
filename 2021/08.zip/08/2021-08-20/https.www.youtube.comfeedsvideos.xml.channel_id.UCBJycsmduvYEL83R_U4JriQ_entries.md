# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Samsung Z Fold 3 Review: Let's Talk Ambition!
 - [https://www.youtube.com/watch?v=iLLi02P1FN4](https://www.youtube.com/watch?v=iLLi02P1FN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-08-20 00:00:00+00:00

Samsung Z Fold 3 is the second best folding phone on earth for a reason.
That shirt! http://shop.MKBHD.com
dbrand: https://dbrand.com/fold3

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Samsung for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

