# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Looking at Israel's number of hospitalizations, vaccinations, etc.
 - [https://www.youtube.com/watch?v=mYtfT7HsJq0](https://www.youtube.com/watch?v=mYtfT7HsJq0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.sciencemag.org/news/2021/08/grim-warning-israel-vaccination-blunts-does-not-defeat-delta

## Are plastic shields security theater?
 - [https://www.youtube.com/watch?v=Jf7ncRzQeos](https://www.youtube.com/watch?v=Jf7ncRzQeos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-20 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.nytimes.com/2021/08/19/well/live/coronavirus-restaurants-classrooms-salons.html

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Madison Ave is 39% empty; Manhattan landlords, can you lower the prices now?
 - [https://www.youtube.com/watch?v=xfHQZj3_TX4](https://www.youtube.com/watch?v=xfHQZj3_TX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-20 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.bloomberg.com/news/articles/2021-08-20/nyc-shoppers-shunning-madison-avenue-as-swanky-boutiques-depart
🔵 https://www.reddit.com/r/nyc/comments/innhah/nearly_twothirds_of_new_york_restaurants_may_have/g4ai27m/?context=3
🔵 https://www.youtube.com/watch?v=kuALRyGI3Ho&list=PLkVbIsAWN2lt_n88l7WC2u22TRHKmw8ya&index=4
🔵 https://www.youtube.com/watch?v=suQx7lachDE
🔵 https://www.youtube.com/watch?v=MpPvy4qyHg4


00:00 Intro
00:07 Apology
01:17 Real estate
01:20 Why I cover this
03:12 Building for lease
03:35 39% retail availability on Madison
05:22 Madison ave prices
07:12 Excuses, excuses
09:40 The problem - commercial mortgage backed securities
10:50 This needs to crash


👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Props to Luther Abel at National Review!
 - [https://www.youtube.com/watch?v=0W0erk_mPhQ](https://www.youtube.com/watch?v=0W0erk_mPhQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-20 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 Links:

🔵 https://www.nationalreview.com/2020/07/a-computer-repair-expert-takes-on-big-tech/
🔵 https://www.theamericanconservative.com/articles/david-vs-goliath-and-the-right-to-repair/
🔵 https://youtu.be/ZCRpoj8cuvw
🔵 https://youtu.be/oAbOpQJqKmw

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

