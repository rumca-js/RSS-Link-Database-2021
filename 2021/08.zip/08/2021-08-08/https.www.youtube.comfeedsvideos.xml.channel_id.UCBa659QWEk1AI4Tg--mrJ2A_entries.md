# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## How one little boat (and me) held up miles of London traffic at Tower Bridge
 - [https://www.youtube.com/watch?v=iitXhgif_lo](https://www.youtube.com/watch?v=iitXhgif_lo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-08-09 00:00:00+00:00

Tower Bridge is a tourist attraction these days: but first and foremost, it's a working, lifting bridge. And river traffic comes first. • Thanks to the Tower Bridge team: they have details of their tours here: https://www.towerbridge.org.uk/

Produced by: Cambria Bailey-Jones
Edited by: Guy Larsen
Camera: Jamie MacLeod
2nd Unit Camera: Jimmy Blake
Drone Director: Matthew Bateman
Drone Operators: Ian Hunter, Phil Conrad 

A Penny4 Production: https://www.penny4.co.uk
Filmed safely: https://www.tomscott.com/safe/

REFERENCES:
Corporation of London (Tower Bridge) Act 1885, https://vlex.co.uk/vid/corporation-of-london-tower-808108441
Hansard debate on Tower Bridge 1970, https://hansard.parliament.uk/Commons/1960-01-27/debates/9f990ccf-e0e0-439c-bdbb-ef42162e4c57/TowerBridge

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

