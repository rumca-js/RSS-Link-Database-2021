# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Jealous Guy | John Lennon | funk cover ft. Rett Madison
 - [https://www.youtube.com/watch?v=Rr4eM3zarJE](https://www.youtube.com/watch?v=Rr4eM3zarJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-08-09 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of John Lennon's "Jealous Guy" by Scary Pockets & Rett Madison.

MUSICIAN CREDITS
Lead vocal: Rett Madison
Drums: Joey Waronker
Bass: David Piltch
Organ: Swatkins
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
Director: Ben Kadie
DP: Kenzo Le 
Editor: Adam Kritzberg

Recorded Live at Big Bad Sound in Los Angeles, CA.

#ScaryPockets #Funk #JohnLennon #JealousGuy #RettMadison

