# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 10 Games That Deserve a Remake or Remaster
 - [https://www.youtube.com/watch?v=kprkGgGJ0Hg](https://www.youtube.com/watch?v=kprkGgGJ0Hg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-08-08 00:00:00+00:00

EA recently announced that its beloved horror game, Dead Space, would be getting its very own remake, which seems like a good idea after Capcom’s success with its Resident Evil 2 Remake. We've also seen other fantastic games like Crash Bandicoot and Spyro see their own graphical overhauls with well crafted remasters.

Whether it be a top-to-bottom re-imagining, like the Final Fantasy VII Remake, or something that simply updates the graphics and controls - many classics deserve this treatment so they can find a new passionate audience. These are Dave's top picks for games that deserve a remake or remaster.

Timestamps
00:00 Introduction
01:47 King's Field
03:15 Mario 64
04:36 Chrono Cross
06:10 Final Fantasy VI
06:50 Metal Gear Solid
08:09 Mega Man Legends
08:37 Silent Hill
10:13 Jet Set Radio
11:05 Power Stone
11:57 Jet Moto

#ea #kingsfield #mario64

