# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Hateful White Men Question How Hateful They Really Are
 - [https://www.youtube.com/watch?v=zfP_y4XVPqE](https://www.youtube.com/watch?v=zfP_y4XVPqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-09 00:00:00+00:00

It’s clear that these two white men are hateful, racist, misogynist bigots. But these men are also wonderin’… maybe they ain’t?

Become a premium subscriber:  https://babylonbee.com/plans?utm_source=YT&utm_medium=social&utm_campaign=description

Subscribe to our podcast channel: https://www.youtube.com/thebabylonbeepodcast

The Official The Babylon Bee Store: https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

