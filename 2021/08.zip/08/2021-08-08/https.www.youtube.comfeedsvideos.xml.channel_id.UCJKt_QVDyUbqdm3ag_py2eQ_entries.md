# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: mA2E & AceMan - Evolution (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=lZ6GCi2ycB0](https://www.youtube.com/watch?v=lZ6GCi2ycB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-08-09 00:00:00+00:00

"Evolution" by mA2E & AceMan (Stian Gudbrandsen & Jakub Szelag), 2nd at Shadow Party 2021. Art "Northstar" (2019) by Prowler.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 18 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

