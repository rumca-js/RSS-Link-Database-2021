## Why CAPTCHA Pictures Are So Unbearably Depressing | by Clive Thompson | Aug, 2021 | Medium
 - [https://clivethompson.medium.com/why-captcha-pictures-are-so-unbearably-depressing-20679b8cf84a](https://clivethompson.medium.com/why-captcha-pictures-are-so-unbearably-depressing-20679b8cf84a)
 - RSS feed: https://clivethompson.medium.com
 - date published: 2021-08-08 10:00:41.617697+00:00

They force you to look at the world the way an AI does

