# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Billionaire WEALTH TRANSFER – How The Super Rich Legally Rob You
 - [https://www.youtube.com/watch?v=bqysILJ83yc](https://www.youtube.com/watch?v=bqysILJ83yc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-09 00:00:00+00:00

America’s super rich are borrowing their way to ever more fortunes. How? Tax breaks. Who pays the price? You, of course! 
#billionaire #ElonMusk #tax #America #rich

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## Whistleblower Exposes Obama’s Drone LIES - Snowden Speaks Out!
 - [https://www.youtube.com/watch?v=mJNL2jg_Diw](https://www.youtube.com/watch?v=mJNL2jg_Diw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-08 00:00:00+00:00

Whistleblower Daniel Hale has been sentenced to jail for revealing, amongst other things, that 90% of people killed by US drones are innocent bystanders, not intended targets. This includes US citizens. 
#whistleblower #DanielHale #EdwardSnowden #America

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

