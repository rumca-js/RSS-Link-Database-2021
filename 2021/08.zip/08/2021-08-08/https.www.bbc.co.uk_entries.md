## Covid in Sydney: Communities feel under siege as troops deployed - BBC News
 - [https://www.bbc.co.uk/news/world-australia-58066389](https://www.bbc.co.uk/news/world-australia-58066389)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-08-08 14:10:22.751110+00:00

Residents say they're being treated like second-class citizens to stem a Covid outbreak.

