# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## MAN ON MAN - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=hC_22oopxM0](https://www.youtube.com/watch?v=hC_22oopxM0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-09 00:00:00+00:00

http://KEXP.ORG presents MAN ON MAN sharing a live performance recorded exclusively for KEXP and talking with Larry Rose. Recorded July 27, 2021.

Songs:
Stohner
Daddy
It's So Fun (To Be Gay)
1983
Please Be Friends

Session filmed and recorded at Strange Weather Studios in Brooklyn, NY
Directed by Brendan McGowan
B Cam by Shannon Madden
Engineered and Mixed by Ben Greenberg

Backing vocals on "It's So Fun (To Be Gay)" provided by Paul Soileau, Christopher Schulz, Stephen Wood, Shane Shane, Dust Tea Shoulders.

MAN ON MAN is:
Joey Holman on vocals and guitar
Roddy Bottum on vocals, guitar, and keys
Michael O’Neill on guitar
Chase Noelle on drums
Joey Howard on bass

https://polyvinyl.ffm.to/man-on-man
http://kexp.org

