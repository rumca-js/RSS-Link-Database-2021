# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Training for Tokyo: how athletes prepared and how they did – in pictures
 - [https://www.theguardian.com/sport/gallery/2021/aug/08/training-for-tokyo-2020-how-athletes-prepared-and-how-they-did-in-pictures](https://www.theguardian.com/sport/gallery/2021/aug/08/training-for-tokyo-2020-how-athletes-prepared-and-how-they-did-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-08-08 15:27:06+00:00

<p>How Olympians trained for the Olympic Games under the strain of lockdown and how that planning paid off</p> <a href="https://www.theguardian.com/sport/gallery/2021/aug/08/training-for-tokyo-2020-how-athletes-prepared-and-how-they-did-in-pictures">Continue reading...</a>

## Tokyo Olympics 2020: final day – in pictures
 - [https://www.theguardian.com/sport/gallery/2021/aug/08/tokyo-olympics-2020-final-day-in-pictures](https://www.theguardian.com/sport/gallery/2021/aug/08/tokyo-olympics-2020-final-day-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-08-08 09:46:00+00:00

<p>The best images from the final day of action in Tokyo, including cycling, volleyball and waterpolo</p> <a href="https://www.theguardian.com/sport/gallery/2021/aug/08/tokyo-olympics-2020-final-day-in-pictures">Continue reading...</a>

