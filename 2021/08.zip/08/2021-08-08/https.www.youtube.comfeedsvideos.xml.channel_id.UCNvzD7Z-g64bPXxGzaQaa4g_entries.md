# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW CO-OP Games of 2021
 - [https://www.youtube.com/watch?v=lhaUWOaG_E8](https://www.youtube.com/watch?v=lhaUWOaG_E8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-09 00:00:00+00:00

Looking for something to play with a friendly cooperatively on PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch? We've got you covered with these promising co-op games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


World War Z: Aftermath

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : TBA 2021 



Aliens: Fireteam Elite 

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : August 24, 2021



The Ascent

Platform : PC XSX|S XBOX ONE 

Release Date : 29 July 2021 



Samurai Warriors 5 

Platform : PC PS4 XBOX ONE Switch 

Release Date : July 27, 2021 



Valheim

Platform : PC Linux 

Release Date : 2 February 2021 



Monster Hunter Rise 

Platform : Switch March 26, 2021 

Release Date : PC Q1/Q2 2022 



Far Cry 6 

Platform : Stadia PC PS4 PS5 Xbox One XSX|S Amazon Luna 

Release Date : October 7, 2021 



Back 4 Blood 

Platform : PC PS4 PS5 XBOX ONE XSX|S 

Release Date : October 12, 2021 



It takes Two 

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : March 26, 2021 



Dying Light 2 Stay Human 

Platform : PC PS4 PS5 XSX|S Xbox One  

Release Date : December 7, 2021 



BONUS



Deathloop

Platform : PS5 PC 

Release Date : September 14, 2021

## 7 Dying Light Locations FREAKIER Than You Thought
 - [https://www.youtube.com/watch?v=nJfbwmPi-sI](https://www.youtube.com/watch?v=nJfbwmPi-sI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-08 00:00:00+00:00

Dying Light is creepier than you'd expect. Here are a few game locations from the open world zombie game that are totally strange.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

