# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Prof. Andrzej Horban zbada skuteczność szczepionek. Koszt 2000000. Te dane są za darmo!
 - [https://www.youtube.com/watch?v=YP7VkFQ45os](https://www.youtube.com/watch?v=YP7VkFQ45os)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-08-09 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3iybJ8I
2. https://bit.ly/2WZAVfK
3. https://cnb.cx/3iwhUKl
4. https://bit.ly/37uaKzW
5. https://bit.ly/2W1gw9J
6. https://bit.ly/2U5mh5G
7. https://bit.ly/3kxUl30
8. https://bit.ly/3sPcZWH
9. https://bit.ly/2PR4lJx
10. https://bit.ly/3lY3iWn
11. https://bit.ly/37qWV5l
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę ze strony: 
facebook.com / kancelaria premiera
https://bit.ly/3yBp3OU
---------------------------------------------------------------
💡 Tagi: #covid19
--------------------------------------------------------------

## Budowa Państwa Europa. Kto za to zapłaci, a kto zyska?
 - [https://www.youtube.com/watch?v=3zTw16H7S94](https://www.youtube.com/watch?v=3zTw16H7S94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-08-08 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3CmZVhn
2. https://bit.ly/3Ao2TQN
3. https://bit.ly/3yz11nV
4. https://bit.ly/3fF3KV9
5. https://bit.ly/3iugiR3
6. https://bit.ly/2VGrVeL
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
wikipedia.org / Armin Linnartz
https://bit.ly/3jDoRs6
---------------------------------------------------------------
💡 Tagi: #UE #ekologia
--------------------------------------------------------------

