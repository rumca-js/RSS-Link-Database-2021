## The Infrastructure Bill Requires New Cars To Come With Unproven Drunk Driving Detection Technology – Reason.com
 - [https://reason.com/2021/08/06/the-infrastructure-bill-requires-new-cars-to-come-with-unproven-drunk-driving-detection-technology/](https://reason.com/2021/08/06/the-infrastructure-bill-requires-new-cars-to-come-with-unproven-drunk-driving-detection-technology/)
 - RSS feed: https://reason.com
 - date published: 2021-08-08 14:44:47.965233+00:00

As early as 2026, new cars will have to come equipped with "advanced drunk and impaired driving prevention technology."

