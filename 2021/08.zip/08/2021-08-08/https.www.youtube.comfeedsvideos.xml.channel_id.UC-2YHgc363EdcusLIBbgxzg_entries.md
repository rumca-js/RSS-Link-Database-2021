# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Liquid Metal Batteries - As Good As The Hype? | Answers With Joe
 - [https://www.youtube.com/watch?v=FZHqIKIHSWo](https://www.youtube.com/watch?v=FZHqIKIHSWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-08-09 00:00:00+00:00

The first 1,000 people to use this link will get a 1 month free trial of Skillshare: https://skl.sh/joescott08211
There's no shortage of battery storage solutions these days, but one of the most interesting (and one with massive potential) is the liquid metal battery - a battery that you literally melt.

So let's talk about how it works, the pros and cons, and how they stack up against Tesla's lithium-ion battery packs.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.bloomberg.com/news/articles/2021-01-06/the-10-ways-renewable-energy-s-boom-year-will-shape-2021

https://www.waste360.com/safety/april-2020-fire-report-how-why-do-lithium-ion-batteries-fail-insight-jedi-master-lithium

https://en.wikipedia.org/wiki/Hoopes_process

https://ambri.com/company/

https://ambri.com/technology/

https://www.intelligentliving.co/redox-flow-battery-25-per-kwh-or-less/

https://www.cbsnews.com/news/crazy-tech-idea-that-bill-gates-loves-a-liquid-battery/

