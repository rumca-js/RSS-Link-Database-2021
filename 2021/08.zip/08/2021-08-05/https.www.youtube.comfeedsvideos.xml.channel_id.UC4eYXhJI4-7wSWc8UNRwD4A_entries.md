# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Tiny Desk Contest Top Shelf: Episode 3 with Tobe Nwigwe
 - [https://www.youtube.com/watch?v=zZs9EmpW04Y](https://www.youtube.com/watch?v=zZs9EmpW04Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-08-05 00:00:00+00:00

NPR Music received thousands of submissions to this year's Tiny Desk Contest, our annual search for the next great undiscovered artist to play a Tiny Desk concert. Before we announce this year's winner, this year's Contest judges are sharing their favorite entries in our weekly Tiny Desk Contest Top Shelf livestream series.

Episode 3 was hosted by Tiny Desk producer Bobby Carter and musician Tobe Nwigwe. Featured entries:
- "Running" by Freakquencee https://www.youtube.com/watch?v=16CsnLXWai8 
- "Far From Shore" by Rotem Sivan https://www.youtube.com/watch?v=ZurVzTEc7aQ
- "ON" by Xella https://www.youtube.com/watch?v=LIpV6kXc0n0 
- "Tweedlee Dee" by Quiana Lynell https://www.youtube.com/watch?v=H2SS3z81ZvA
- "Monarch" by Bird & Butterfly https://www.youtube.com/watch?v=ystNfhu5iOQ

Learn more about the Tiny Desk Contest: https://npr.org/tinydeskcontest.

#tinydesk #tinydeskcontest #tinydeskcontesttopshelf

