# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## NEW OPEN WORLD RPG FROM EX-ELDER SCROLLS TEAM, EA WANTS CREDIT FOR NO CLOSURES, & MORE
 - [https://www.youtube.com/watch?v=EM0PCQtNDV4](https://www.youtube.com/watch?v=EM0PCQtNDV4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-06 00:00:00+00:00

Thank you Raycon for sponsoring this video! Go to https://buyraycon.com/gameranx for 15% off your order! Brought to you by Raycon.

A new RPG from some of the people behind classic Elder Scrolls, updates from Sony on PS5 indies, Master Chief narrates your driving, Valve talks HALF LIFE, and more gaming news from this week.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake's other channel: https://youtu.be/6ytg4WMHPLI



 ~~~~STORIES~~~~

New RPG from old Elder Scrolls devs:
https://www.eurogamer.net/articles/2021-08-03-the-wayward-realms-is-a-grand-rpg-by-former-elder-scrolls-devs
If you’re waiting for Elder Scrolls 6…
https://gamerant.com/phil-spencer-confirms-elder-scrolls-6-releasing-after-fable/


EA’s statement
https://www.gamesradar.com/ea-says-it-doesnt-get-enough-credit-for-its-studio-acquisitions/


Waze has Master Chief now (texting while driving lol)
https://twitter.com/IGN/status/1422694023794466821?s=19

PlayStation Indies
https://www.eurogamer.net/articles/2021-08-05-heres-everything-revealed-as-part-of-sonys-playstation-indie-spotlight-event


Jesus game new ‘gameplay’
https://youtu.be/2zRCuMPQ1DU

Gabe on Half Life: https://youtu.be/9kO6Dj2XNfY
https://uploadvr.com/gabe-newell-alyx-ending?fbclid=IwAR3KTsia2ICBV8g5Bm03GJ-f4P8pseC0nHtvY1LJ-QZsJ7jkaVKMMOqw2ec


Blizzard prez steps down:
https://arstechnica.com/gaming/2021/08/blizzard-president-j-allen-brack-steps-down-amid-lawsuit-fallout/

New Guardians trailer
https://youtu.be/URUU5x-aOqs


New South Park game
https://www.pcgamesn.com/south-park-fractured-but-whole/new-game

## 10 Video Game Things You Won't Believe EXIST In Real Life
 - [https://www.youtube.com/watch?v=XqwZr08LKas](https://www.youtube.com/watch?v=XqwZr08LKas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-05 00:00:00+00:00

Some larger-than-life video game concepts actually exist in our real world. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

