# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Breakthrough Cases and Vaccine Passports
 - [https://www.youtube.com/watch?v=tiwsv51Il4k](https://www.youtube.com/watch?v=tiwsv51Il4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-06 00:00:00+00:00

Taken from JRE #1693 w/Evan Hafer:
https://open.spotify.com/episode/5ifCsGwt84dkHMxIrUHqwr?si=Wd50Uk4LT_u-NyVvSTVQSQ&dl_branch=1

## Jason Wilson's Viral Pep Talk Video, Guiding Kids Through Martial Arts
 - [https://www.youtube.com/watch?v=_BAgiKT4e1M](https://www.youtube.com/watch?v=_BAgiKT4e1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-05 00:00:00+00:00

Taken from JRE #1692 w/Jason Wilson:
https://open.spotify.com/episode/5JHFOXKMkahS4WjZBD3hgW?si=bHzQWEKwSfK9A1PRoKPudw&dl_branch=1

