# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## LA Law: Arresting The Poor and Protecting The Rich
 - [https://www.youtube.com/watch?v=kkJw7oXTxXE](https://www.youtube.com/watch?v=kkJw7oXTxXE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-06 00:00:00+00:00

The mayor of Los Angeles has signed an ordinance essentially criminalising being homeless in almost every area of the city. 
#homeless #LosAngeles #america #illegal

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## Wim Hof: The Ice Man On MAINSTREAM LIES
 - [https://www.youtube.com/watch?v=RZt4xl7d1X8](https://www.youtube.com/watch?v=RZt4xl7d1X8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-05 00:00:00+00:00

In this video I talk with WIM HOF (The Ice Man). Make sure to watch the full video at the link below, and let me know what you think of this Wim Hof Interview in the comments!

https://youtu.be/JPPlicAEFec

This is a short excerpt from my podcast "Under the Skin". Click below to listen to my luminary original podcast and hear from guests including Wim Hof, Brian Cox, Jordan Peterson, Edward Snowden, Jonathan Haidt, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.

🎙️ Subscribe to Luminary at http://apple.co/russell 🎙️

Watch the #UnderTheSkin Youtube Playlist:

https://youtube.com/playlist?list=PL5BY9veyhGt7eapYiWXyxGuSxTcysPpJ7

______________________________________________
Elites are taking over! Our only hope is to form our own. To learn more, join my cartel below and get weekly bulletins too incendiary for anything but your private inbox.

*not a euphemism

https://www.russellbrand.com/join

Are you interested in more video like this? I release videos EVERYDAY on Youtube (admit it, you enjoyed watching this one...). 

Click the link below to subscribe below to my Youtube Channel - don't forget to turn on that notification bell 🔔

http://www.youtube.com/c/RussellBrand?sub_confirmation=1

______________________________________________
SEE ME LIVE! Check out my live events and buy tickets here:

📅 https://www.russellbrand.com/live-dates/ 

🎧 My Audible Original, ‘Revelation', is out NOW!

US: http://adbl.co/revelation 🇺🇸
UK: http://adbl.co/revelationuk 🇬🇧
AU: http://adbl.co/revelationau 🇦🇺
CA: http://adbl.co/revelationca 🇨🇦

For meditation and breath work, subscribe to my side-channel:

http://www.youtube.com/c/AwakeningWithRussell?sub_confirmation=1

______________________________________________
Follow me here:

Instagram:
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Youtube:
http://www.youtube.com/c/RussellBrand?sub_confirmation=1

Facebook:
https://www.facebook.com/RussellBrand/

My Website:
https://www.russellbrand.com/

Join the Community:
https://www.russellbrand.com/join

#WimHof #RussellBrand #UnderTheSkin

