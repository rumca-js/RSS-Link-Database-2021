# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## 3 Jams With A Mini Sinfonion (DROID Modules)
 - [https://www.youtube.com/watch?v=MdQVssRnaOY](https://www.youtube.com/watch?v=MdQVssRnaOY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-08-06 00:00:00+00:00

Droid is a programmable, expandable CV generation and processing system designed by Mattias Ketter, the brain behind the ACL Sinfonion. In this video we use it to play some improvised jams in three different styles. Learn more about the Droid modular ecosystem here: https://shop.dermannmitdermaschine.de/pages/droid-universal-cv-processor

Modules in this video: 

Voices
Mutable Instruments Braids: https://bit.ly/3sLwL5o
Noise Engineering Manis Iteritas: https://bit.ly/3rMioz0
Qu-Bit Surface: http://bit.ly/pc_surface

Effects
Happy Nerding FX Aid XL: http://www.happynerding.com/category/fx-aid/
Make Noise Mimeophon: https://bit.ly/3yYFyW5
Mutable Instrument Blades: https://bit.ly/3xw9nMT
Qu-Bit Data Bender: http://bit.ly/pc_data_bender
Tip-Top Z5000: http://bit.ly/pc_z5000

Modulation
Abstract Devices ADE-32: https://bit.ly/3zhnGFl

Other
ALM Pamela's New Workout: https://bit.ly/2QRxnZO
Circuit Abbey Unify: http://circuitabbey.com/Unify.html
Intellijel Quad VCA: http://bit.ly/pc_quadvca
Squarp Hermod: http://bit.ly/pc_hermod
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

