# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Best Christian Album Covers And How To Hang Your Hammock
 - [https://www.youtube.com/watch?v=9iOlG7QLMUY](https://www.youtube.com/watch?v=9iOlG7QLMUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-06 00:00:00+00:00

In this episode, Kyle and Ethan are joined by Kevin McCreary from Say Goodnight Kevin (https://www.youtube.com/user/saygoodnightkevin). They talk about the best Christian album covers of all time, horrible places to hang your hammock, and The Babylon Bee triggering the socialists on Twitter. In the subscriber portion they talk about crazy Christian movies they can’t believe are real. 


Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## How To Tell If Your President Is A Totalitarian Fascist
 - [https://www.youtube.com/watch?v=49QlI-oEjxM](https://www.youtube.com/watch?v=49QlI-oEjxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-05 00:00:00+00:00

Does your President seem a little… off? Look for these signs to see if you actually have a dictator on your hands.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

