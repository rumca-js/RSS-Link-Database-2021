# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Guy sketches a woman at the airport. And the botched portrait goes viral
 - [https://www.cnn.com/videos/business/2021/08/05/botched-airport-portrait-teen-goes-viral-moos-pkg-vpx.cnn](https://www.cnn.com/videos/business/2021/08/05/botched-airport-portrait-teen-goes-viral-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 23:26:49+00:00

Guy sketches a woman at the airport, and the botched portrait goes viral. CNN's Jeanne Moos reports people like it because it's such a bad likeness.

## People in Alabama are changing their minds about the vaccine
 - [https://www.cnn.com/videos/health/2021/08/05/alabama-covid-19-vaccination-rate-rise-marquez-dnt-lead-vpx.cnn](https://www.cnn.com/videos/health/2021/08/05/alabama-covid-19-vaccination-rate-rise-marquez-dnt-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 21:41:37+00:00

CNN's Miguel Marquez looks at the rise in Covid-19 vaccinations in Alabama, despite the state being tied with Arkansas for the lowest vaccination rate.

## Jack Grealish signs record deal with Manchester City
 - [https://www.cnn.com/2021/08/05/football/jack-grealish-manchester-city-aston-villa-spt-intl/index.html](https://www.cnn.com/2021/08/05/football/jack-grealish-manchester-city-aston-villa-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 20:02:12+00:00

English Premier League champion Manchester City completed the signing of England international Jack Grealish​ on a six-year contract on Thursday.

## New York state impeachment investigation into Cuomo is 'nearing completion'
 - [https://www.cnn.com/2021/08/05/politics/new-york-cuomo-impeachment-investigation/index.html](https://www.cnn.com/2021/08/05/politics/new-york-cuomo-impeachment-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 19:38:06+00:00

A wide-ranging New York state impeachment investigation into various allegations of misconduct against embattled Democratic Gov. Andrew Cuomo is close to concluding, according to a letter obtained by CNN.

## Japanese whiskey worth $5,800 gifted to Pompeo is missing, State filings say
 - [https://www.cnn.com/2021/08/05/politics/pompeo-japanese-whiskey-bottle/index.html](https://www.cnn.com/2021/08/05/politics/pompeo-japanese-whiskey-bottle/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 19:34:26+00:00

The State Department is looking into the whereabouts of a $5,800 bottle of Japanese whiskey that was gifted to former Secretary of State Mike Pompeo, according to State Department filings in the federal register.

## Richard Trumka, head of powerful AFL-CIO union, has died
 - [https://www.cnn.com/2021/08/05/politics/richard-trumka-dies/index.html](https://www.cnn.com/2021/08/05/politics/richard-trumka-dies/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 19:13:11+00:00

AFL-CIO President Richard Trumka, the head of the most powerful labor organization in the country and a close ally of the Biden White House, has died. He was 72.

## US sprint great Carl Lewis calls Team USA's 4x100m relay fail a 'total embarrassment'
 - [https://www.cnn.com/collections/intl-olympics-news-0804/](https://www.cnn.com/collections/intl-olympics-news-0804/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 18:52:20+00:00



## Tesla just got snubbed by Biden's electric vehicle summit
 - [https://www.cnn.com/2021/08/05/business/tesla-snub-white-house-event/index.html](https://www.cnn.com/2021/08/05/business/tesla-snub-white-house-event/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 18:50:52+00:00

President Joe Biden will be celebrating ambitious electric vehicles goals by automakers at the White House on Thursday. But he'll be doing so without the world's largest maker of EVs: Tesla.

## Lionel Messi is leaving FC Barcelona despite agreeing new contract, club says
 - [https://www.cnn.com/2021/08/05/football/lionel-messi-contract-barcelona-spt-intl/index.html](https://www.cnn.com/2021/08/05/football/lionel-messi-contract-barcelona-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 18:48:58+00:00

Lionel Messi is leaving Barcelona, the Spanish club said on Thursday.

## These reality shows are sending regular people to space
 - [https://www.cnn.com/2021/08/05/tech/who-wants-to-be-an-astronaut-space-hero-reality-television-scn/index.html](https://www.cnn.com/2021/08/05/tech/who-wants-to-be-an-astronaut-space-hero-reality-television-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 17:51:50+00:00

The hottest new reality show isn't set in a house, on an obstacle course, or on the Jersey Shore. Television producers are betting on a new location: the International Space Station.

## New hardline Iranian President is on the same page as the Supreme Leader
 - [https://www.cnn.com/2021/08/05/middleeast/iran-president-raisi-inauguration-intl/index.html](https://www.cnn.com/2021/08/05/middleeast/iran-president-raisi-inauguration-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 17:32:57+00:00

Ebrahim Raisi was set to be inaugurated as Iran's next president on Thursday, signaling the start of a new harder-line era that could herald major shifts in the Islamic Republic's policies at home and abroad.

## Perfectly preserved cave lion cub found frozen in Siberia is 28,000 years old. Even its whiskers are intact.
 - [https://www.cnn.com/2021/08/05/world/frozen-cave-lion-cubs-siberia-scn/index.html](https://www.cnn.com/2021/08/05/world/frozen-cave-lion-cubs-siberia-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 16:57:54+00:00

Found frozen deep in the Siberian Arctic, the cave lion cub looks like she's asleep and one touch might awaken her.

## The soccer player who'll be the first openly trans Olympic medalist
 - [https://www.cnn.com/2021/08/05/sport/quinn-canada-sweden-spt-intl/index.html](https://www.cnn.com/2021/08/05/sport/quinn-canada-sweden-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 15:14:40+00:00

A gold medal is the ambition, but Quinn has already made history at the Tokyo 2020 Olympic Games by becoming the first trans and the first non-binary athlete to win a medal.

## You shouldn't miss this bombshell in Trump's ongoing election fraud lie
 - [https://www.cnn.com/2021/08/05/politics/donald-trump-jeffrey-rosen-election-fraud-cnn/index.html](https://www.cnn.com/2021/08/05/politics/donald-trump-jeffrey-rosen-election-fraud-cnn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:57:00+00:00

Unless you have been living on another planet for the past six months, you know by now that Donald Trump leaned on state and national officials in the final days of his presidency to force investigations into made-up claims of widespread election fraud in the 2020 race.

## Delta variant is ravaging the world but it's pushing Southeast Asia to breaking point
 - [https://www.cnn.com/collections/intl-covid-0805/](https://www.cnn.com/collections/intl-covid-0805/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:55:36+00:00



## 'South Park' creators score reported $900 million deal with ViacomCBS
 - [https://www.cnn.com/2021/08/05/media/south-park-deal-paramount/index.html](https://www.cnn.com/2021/08/05/media/south-park-deal-paramount/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:55:11+00:00

Trey Parker and Matt Stone, the co-creators behind the long-running animated series "South Park," have signed a new deal with ViacomCBS that will keep the cursing children of Colorado on Comedy Central through 2027.

## US intel agencies scour reams of genetic data from Wuhan lab in Covid origins hunt
 - [https://www.cnn.com/collections/intl-us-covid-0805/](https://www.cnn.com/collections/intl-us-covid-0805/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:51:32+00:00



## Carnival cruise ship reports Covid cases, brings in mask requirement for all passengers
 - [https://www.cnn.com/travel/article/carnival-cruise-line-covid-cases-mask-requirement/index.html](https://www.cnn.com/travel/article/carnival-cruise-line-covid-cases-mask-requirement/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:46:29+00:00

After a "small number of positive cases" of Covid-19 were detected aboard a Carnival Cruise Line ship, a new fleetwide mask policy requiring all guests to wear masks in some indoor areas was implemented ahead of schedule, the cruise line said.

## Biden extends temporary safe haven to Hong Kong residents in US amid China crackdown
 - [https://www.cnn.com/2021/08/05/politics/deferred-enforced-departure-hong-kong-china/index.html](https://www.cnn.com/2021/08/05/politics/deferred-enforced-departure-hong-kong-china/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:44:34+00:00

President Joe Biden on Thursday signed a memorandum extending temporary safe haven to certain Hong Kong residents in the US amid ongoing repression and undermining of democracy by China.

## 'There is no life for me here': One of the last Guantanamo detainees is a litmus test for Biden
 - [https://www.cnn.com/2021/08/05/politics/guantanamo-detainee-qahtani-biden-invs/index.html](https://www.cnn.com/2021/08/05/politics/guantanamo-detainee-qahtani-biden-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:38:46+00:00



## Unvaccinated man shares heartbreaking video diary from ICU
 - [https://www.cnn.com/videos/health/2021/08/05/virginia-dad-documents-covid-19-treatment-facebook-videos-newday-vpx.cnn](https://www.cnn.com/videos/health/2021/08/05/virginia-dad-documents-covid-19-treatment-facebook-videos-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:27:45+00:00

A  Virginia dad is chronicling his story of battling Covid-19 in a series of Facebook videos and says he made a mistake by not getting vaccinated. CNN's Brianna Keilar reports.

## 11 people arrested in hate crime investigation following Euro 2020 final
 - [https://www.cnn.com/2021/08/05/football/hate-crime-arrests-euro-2020-final-spt-intl/index.html](https://www.cnn.com/2021/08/05/football/hate-crime-arrests-euro-2020-final-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:13:31+00:00

British police have arrested 11 people across the UK in connection with episodes of racist abuse targeting England football players on social media following the team's Euro 2020 final loss to Italy.

## Go inside Simone Biles' 'secret gym' in Tokyo
 - [https://www.cnn.com/videos/sports/2021/08/05/simone-biles-secret-gym-juntendo-tokyo-olympics-exclusive-spt-intl.cnn](https://www.cnn.com/videos/sports/2021/08/05/simone-biles-secret-gym-juntendo-tokyo-olympics-exclusive-spt-intl.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 14:07:52+00:00

Simone Biles has publicly thanked the gym an hour outside of Tokyo where she was able to step away from the public eye and train privately to get ready for competing in the Olympics beam event. CNN's Will Ripley gets an exclusive tour inside the facility which helped her to overcome the "twisties" condition which forced her to pull out of the other gymnastic events.

## Two robots are changing the way we explore Mars
 - [https://www.cnn.com/2021/08/05/world/mars-helicopter-rover-raised-ridges-scn/index.html](https://www.cnn.com/2021/08/05/world/mars-helicopter-rover-raised-ridges-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 13:57:56+00:00

In the quest to understand Mars, two robots are better than one -- especially when they work together.

## Israelis told to 'stop embracing' as Covid-19 cases spike
 - [https://www.cnn.com/2021/08/05/middleeast/israel-boosters-restrictions-covid-spike-intl/index.html](https://www.cnn.com/2021/08/05/middleeast/israel-boosters-restrictions-covid-spike-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 13:51:36+00:00

Israeli Prime Minister Naftali Bennett is warning that Israelis over 60 are at risk unless they go get their third booster shot immediately.

## Robinhood brings the meme stock phenomenon full circle
 - [https://www.cnn.com/2021/08/05/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/08/05/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 13:05:22+00:00

Earlier this year, when GameStop shares exploded out of the blue, all eyes were on Robinhood, the commission-free trading app that was helping millions of amateur investors gain access to financial markets. Coordinating on social media, the app's users showed an uncanny ability to supercharge a wide array of stocks.

## It's unclear how they obtained it, but reams of genetic data from Chinese lab may help uncover virus's origins
 - [https://www.cnn.com/2021/08/05/politics/covid-origins-genetic-data-wuhan-lab/index.html](https://www.cnn.com/2021/08/05/politics/covid-origins-genetic-data-wuhan-lab/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 13:02:12+00:00

US intelligence agencies are digging through a treasure trove of genetic data that could be key to uncovering the origins of the coronavirus -- as soon as they can decipher it.

## Planets similar to those in our solar system found around nearby star
 - [https://www.cnn.com/2021/08/05/world/nearby-star-exoplanet-discovery-scn/index.html](https://www.cnn.com/2021/08/05/world/nearby-star-exoplanet-discovery-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 12:00:10+00:00

An array of planets with similarities to some in our solar system have been found around a nearby star by astronomers using the European Southern Observatory's Very Large Telescope in Chile.

## US men's 4x100m relay fail is a 'total embarrassment,' says sprint great Carl Lewis
 - [https://www.cnn.com/2021/08/05/sport/us-mens-4x100m-heat-spt-intl/index.html](https://www.cnn.com/2021/08/05/sport/us-mens-4x100m-heat-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 11:56:45+00:00

• India's 41-year wait for a men's hockey medal is finally over

## How South African artist Penny Siopis is exploring 'Shame'
 - [https://www.cnn.com/style/article/penny-siopis-south-africa-artist-shame-revisited-spc-intl-hnk/index.html](https://www.cnn.com/style/article/penny-siopis-south-africa-artist-shame-revisited-spc-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 11:53:38+00:00

Growing up in South Africa in the 1950s and '60s, it was inevitable that Penny Siopis' work would be political.

## Last of Tokyo's geishas cling to a disappearing trade
 - [https://www.cnn.com/style/article/geishas-tokyo-disappearing-trade/index.html](https://www.cnn.com/style/article/geishas-tokyo-disappearing-trade/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 11:53:04+00:00

Wearing tall platform sandals and a long kimono, Ikuko glides across the room as if she were balancing a glass of water on her head. She gazes at a wall of old photos in Tokyo's Akasaka geisha house.

## Brazil's Jair Bolsonaro will be investigated over unproven voter fraud claims
 - [https://www.cnn.com/2021/08/05/americas/brazil-bolsonaro-fraud-supreme-court-investigation-intl/index.html](https://www.cnn.com/2021/08/05/americas/brazil-bolsonaro-fraud-supreme-court-investigation-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 10:59:52+00:00

A Brazilian Supreme Court justice has ruled that President Jair Bolsonaro should be investigated for his unproven claims that the country's electronic voting system is vulnerable to fraud.

## Meet the British couple doing 96 events in 17 days: We have blisters on all of our toes!
 - [https://www.cnn.com/videos/sports/2021/08/04/spennylympics-mnd-tokyo-2020-lon-orig-tp.cnn](https://www.cnn.com/videos/sports/2021/08/04/spennylympics-mnd-tokyo-2020-lon-orig-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 10:13:26+00:00

Stuart Bates and Charlotte Nichols are competing in the "Spennylympics," a challenge they have set for themselves to raise money for the Motor Neurone Disease Association, in memory of Bates' brother, Spencer, who they lost to ALS in 2011.

## Nigeria seizes record $54 million in pangolin parts and elephant tusks
 - [https://www.cnn.com/2021/08/05/africa/pangolin-parts-seized-nigeria-intl/index.html](https://www.cnn.com/2021/08/05/africa/pangolin-parts-seized-nigeria-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 09:23:37+00:00

Officials in Nigeria - a hub for illegal wildlife trafficking - have seized a record amount of pangolin scales and claws and elephant tusks as the government attempts to combat the trade, the head of customs said on Wednesday.

## 'We didn't want a McMansion': Inside Adam Levine and Behati Prinsloo's understated home
 - [https://www.cnn.com/style/article/adam-levine-behati-prinsloo-home-architectural-digest/index.html](https://www.cnn.com/style/article/adam-levine-behati-prinsloo-home-architectural-digest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 08:49:53+00:00

Tucked between the Santa Monica Mountains and the Pacific Ocean sits Adam Levine and Behati Prinsloo's own private slice of serenity.

## 5 ways to support tweens' and teens' developing brains
 - [https://www.cnn.com/2021/08/05/health/teen-tween-developing-brains-wellness/index.html](https://www.cnn.com/2021/08/05/health/teen-tween-developing-brains-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 08:33:09+00:00

Do you feel frustrated by adolescent self-centeredness, boundary pushing and questionable decision-making that seem to come out of nowhere, a dramatic departure from the sweet elementary school years?

## Dubai's luxury megaproject Heart of Europe is creating a huge coral reef
 - [https://www.cnn.com/travel/article/dubai-heart-of-europe-coral-reef-spc-intl/index.html](https://www.cnn.com/travel/article/dubai-heart-of-europe-coral-reef-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 07:58:42+00:00

Off the coast of Dubai, a property developer is planning to create up to 500,000 square meters of coral reef.

## Southeast Asia grapples with worst outbreaks of pandemic
 - [https://www.cnn.com/2021/08/04/asia/southeast-asia-delta-covid-explainer-intl-hnk/index.html](https://www.cnn.com/2021/08/04/asia/southeast-asia-delta-covid-explainer-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 07:34:22+00:00

Countries across Asia are grappling with their worst coronavirus outbreaks of the pandemic, spurred by low vaccine rates and the highly-contagious Delta variant.

## Delhi leaders order judicial inquiry into alleged rape and murder of 9-year-old girl
 - [https://www.cnn.com/2021/08/05/india/india-dalit-rape-murder-judicial-inquiry-intl-hnk/index.html](https://www.cnn.com/2021/08/05/india/india-dalit-rape-murder-judicial-inquiry-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 07:06:56+00:00

Delhi's chief minister has ordered a judicial inquiry into the alleged rape and murder of a 9-year-old girl in the Indian capital, as protests continue for a fifth day.

## Extreme fires tear through Greece near historic sites
 - [https://www.cnn.com/videos/world/2021/08/05/europe-heat-wave-greece-turkey-fires-brunhuber-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/08/05/europe-heat-wave-greece-turkey-fires-brunhuber-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 06:00:02+00:00

While Greece is battling blazes across the country, Turkey is fighting devastating fires caused by extreme heat. CNN's Kim Brunhuber reports on the wildfires plaguing parts of southern Europe.

## Bill Gates says time he spent with Jeffrey Epstein 'a huge mistake'
 - [https://www.cnn.com/2021/08/05/business/bill-gates-regrets-jeffrey-epstein-relations/index.html](https://www.cnn.com/2021/08/05/business/bill-gates-regrets-jeffrey-epstein-relations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 05:47:21+00:00

Microsoft founder Bill Gates regrets his gatherings with Jeffrey Epstein, the wealthy financial manager who was accused of child sex trafficking, he told CNN Wednesday.

## 'Justice for India's daughter': Protests erupt over alleged rape and murder
 - [https://www.cnn.com/videos/world/2021/08/05/india-delhi-dalit-girl-alleged-rape-murder-sud-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/08/05/india-delhi-dalit-girl-alleged-rape-murder-sud-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 04:30:20+00:00

Protests are continuing over the alleged gang rape, murder and forced cremation of a 9-year-old girl in New Delhi, India. CNN's Vedika Sud reports.

## Australia to establish $280 million reparations fund for 'Stolen Generation'
 - [https://www.cnn.com/2021/08/05/australia/australia-reparations-stolen-generation-intl-hnk/index.html](https://www.cnn.com/2021/08/05/australia/australia-reparations-stolen-generation-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 04:02:52+00:00

Australia will create a reparations fund of 380 million Australian dollars ($280 million) for members of its Indigenous population who were forcibly removed from their families, Australian media reported on Thursday, months after 800 survivors filed a class action lawsuit.

## This doctor in Florida is spreading misinformation. CNN confronts him
 - [https://www.cnn.com/videos/health/2021/08/05/dr-joseph-mercola-covid-misinformation-kaye-pkg-ac360-vpx.cnn](https://www.cnn.com/videos/health/2021/08/05/dr-joseph-mercola-covid-misinformation-kaye-pkg-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 03:06:30+00:00

CNN's Randi Kaye attempts to track down Dr. Joseph Mercola to find out why he continues to spread misinformation about Covid-19 and the vaccine.

## Internet celebrity's 'Star Wars'-themed theater goes viral
 - [https://www.cnn.com/videos/business/2021/08/04/star-wars-theater-house-listing-viral-pkg-vpx.wtvd](https://www.cnn.com/videos/business/2021/08/04/star-wars-theater-house-listing-viral-pkg-vpx.wtvd)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-05 00:29:23+00:00

A $1.5M home listing went viral for its movie theater full of Star Wars and Star Trek memorabilia.

