# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## THE 💣 RETURNS💥
 - [https://www.youtube.com/watch?v=c15gvovdrEI](https://www.youtube.com/watch?v=c15gvovdrEI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-08-06 00:00:00+00:00

PDGDBAB has returned! 
BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

New P.O. Box: PO Box 7874 Henrico, VA 23231

## Best Game of Thrones Edition?
 - [https://www.youtube.com/watch?v=AqxsQsxwIMg](https://www.youtube.com/watch?v=AqxsQsxwIMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-08-05 00:00:00+00:00

Let's talk about the Folio Society's edition of Game Of Thrones! 
Get the book here: https://www.foliosociety.com/a-game-of-thrones.html?utm_source=daniel-green&utm_medium=pr&utm_campaign=a-game-of-thrones&utm_content=youtube-review

#GameOfThrones

New P.O. Box: PO Box 7874 Henrico, VA 23231

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1

