# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Everywhere That Will FLOOD In Our Lifetime
 - [https://www.youtube.com/watch?v=0yywWKtKheQ](https://www.youtube.com/watch?v=0yywWKtKheQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-08-06 00:00:00+00:00

A portion of this video is sponsored by Google.
There are NOT plenty of fish in the sea anymore. Can this damage be reversed?

Written by: Julia Wilde and Mitchell Moffit
Edited by: Luka Šarlija

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Sources and Further Reading:

Amos, By Jonathan. “One-Fifth of Earth’s Ocean Floor Is Now Mapped.” BBC News, 21 June 2020, www.bbc.com/news/science-environment-53119686.
“How Old Is the Ocean? | Saltwater Science | Learn Science at Scitable.” Nature, 2013, www.nature.com/scitable/blog/saltwater-science/how_old_is_the_ocean/
“Ocean Fish Numbers Cut in Half Since 1970.” Scientific American, 16 Sept. 2015, www.scientificamerican.com/article/ocean-fish-numbers-cut-in-half-since-1970.
Crockett, Zachary. “There Are 5 Trillion Pieces of Plastic Floating in Our Oceans. This Map Shows You Where.” Vox, 22 Nov. 2016, www.vox.com/2016/5/23/11735856/plastic-ocean.
Noaacoastsurvey. “The Future of Seabed 2030: From Vision to Action.” News & Updates, 31 Dec. 2019, nauticalcharts.noaa.gov/updates/the-future-of-seabed-2030-from-vision-to-action.
“Feeling the Heat: How Fish Are Migrating from Warming Waters.” Yale E360, 15 June 2017, e360.yale.edu/features/feeling-the-heat-warming-oceans-drive-fish-into-cooler-waters.
“Will There Be More Plastic than Fish in the Ocean by 2050?” CBC, 27 July 2019, www.cbc.ca/news/politics/ocean-plastic-liberals-fact-check-1.5212632#:%7E:text=%22In%20a%20business%2Das%2D,)%2C%22%20the%20report%20read.
Galey, Patrick Afp. “Tropical Oceans Headed For Collapse Within The Next 10 Years, Major Study Reveals.” ScienceAlert, 10 Apr. 2020, www.sciencealert.com/study-predicts-tropical-oceans-have-less-than-ten-years-before-ecological-collapse.
Lu, Denise, and Christopher Flavelle. “Rising Seas Will Erase More Cities by 2050, New Research Shows.” The New York Times, 28 Nov. 2019, www.nytimes.com/interactive/2019/10/29/climate/coastal-cities-underwater.html.
Smithsonian Ocean. “Sea Level Rise.” Smithsonian Ocean, 5 Aug. 2019, ocean.si.edu/through-time/ancient-seas/sea-level-rise.
Meyer, Robinson. “Terrifying Sea-Level Prediction for 2100 Now Seems Unlikely.” The Atlantic, 5 Jan. 2019, www.theatlantic.com/science/archive/2019/01/sea-level-rise-may-not-become-catastrophic-until-after-2100/579478.
Weisbrod, Katelyn. “Climate Change Is Weakening the Ocean Currents That Shape Weather on Both Sides of the Atlantic.” Inside Climate News, 25 Feb. 2021, insideclimatenews.org/news/25022021/climate-change-ocean-currents-atlantic.
“Ocean Acidification | National Oceanic and Atmospheric Administration.” NOAA, Apr. 2020, www.noaa.gov/education/resource-collections/ocean-coasts/ocean-acidification.
Bednaršek, N., Tarling, G., Bakker, D. et al. Extensive dissolution of live pteropods in the Southern Ocean. Nature Geosci 5, 881–885 (2012). https://doi.org/10.1038/ngeo1635
Wodinsky, Shoshana. “Climate Change May Be Dissolving the Ocean Floor. Here’s Why We Should Be Worried.” NBC News, 14 Nov. 2018, www.nbcnews.com/mach/science/climate-change-may-be-dissolving-ocean-floor-here-s-why-ncna935261.
Carrington, Damian. “Oceans Suffocating as Huge Dead Zones Quadruple since 1950, Scientists Warn.” The Guardian, 5 July 2018, www.theguardian.com/environment/2018/jan/04/oceans-suffocating-dead-zones-oxygen-starved.
https://www.iucn.org/sites/dev/files/content/documents/what_is_deox_infographic.pdf
Berwyn, Bob. “New Study Shows a Vicious Circle of Climate Change Building on Thickening Layers of Warm Ocean Water.” Inside Climate News, 30 Nov. 2020, insideclimatenews.org/news/28092020/ocean-stratification-climate-change.
Snider, Laura. “Climate Change Is Creating a Significantly More Stratified Ocean, New Study Finds | NCAR & UCAR News.” NCAR News, 28 Sept. 2020, news.ucar.edu/132759/climate-change-creating-significantly-more-stratified-ocean-new-study-finds.
Li, G., Cheng, L., Zhu, J. et al. Increasing ocean stratification over the past half-century. Nat. Clim. Chang. 10, 1116–1123 (2020). https://doi.org/10.1038/s41558-020-00918-2
Mooney, Chris. “What the Earth Will Be like in 10,000 Years, According to Scientists.” Washington Post, 8 Feb. 2016, www.washingtonpost.com/news/energy-environment/wp/2016/02/08/what-the-earth-will-be-like-in-10000-years-according-to-scientists.
National Geographic Society. “Seafloor Spreading.” National Geographic Society, 9 Oct. 2012, www.nationalgeographic.org/encyclopedia/seafloor-spreading.
“Hydrothermal Vent Creatures.” Smithsonian Ocean, 23 May 2018, ocean.si.edu/ocean-life/invertebrates/hydrothermal-vent-creatures.
McGrath, By Matt. “Oceans Can Be Successfully Restored by 2050, Say Scientists.” BBC News, 1 Apr. 2020, www.bbc.com/news/science-environment-52122447.

