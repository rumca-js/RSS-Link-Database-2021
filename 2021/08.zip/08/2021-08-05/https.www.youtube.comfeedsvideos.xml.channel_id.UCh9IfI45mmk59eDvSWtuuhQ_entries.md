# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## The First Guy To Ever Hire An Assassin
 - [https://www.youtube.com/watch?v=YtBeSeNIEu0](https://www.youtube.com/watch?v=YtBeSeNIEu0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-08-06 00:00:00+00:00

Click here http://bit.ly/BrightCellarsRyanGeorge2 to get 60% OFF your first 4-bottle box plus a BONUS bottle! That's 5 bottles for just 38 plus taxes. Get started by taking the taste palate quiz to see your personalized matches.

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

