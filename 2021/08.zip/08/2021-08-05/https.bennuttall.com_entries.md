## Ben Nuttall - The surreal experience of my first developer job
 - [https://bennuttall.com/the-surreal-experience-of-my-first-developer-job/](https://bennuttall.com/the-surreal-experience-of-my-first-developer-job/)
 - RSS feed: https://bennuttall.com
 - date published: 2021-08-05 09:43:45.413713+00:00

Nearly ten years ago I graduated with a degree in Mathematics & Computing, with a keen interest in pursuing a career involving maths and programming, but with little idea how. First and foremost I had decided to stay in Manchester after uni, rather than risk getting stuck at my parents’ if I moved back home. […]

