# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## The First Guy To Ever Shoplift
 - [https://www.youtube.com/watch?v=BoJap_LjExk](https://www.youtube.com/watch?v=BoJap_LjExk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-08-27 00:00:00+00:00

Sign up to Morning Brew for free today: https://bit.ly/ryangeorge

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

