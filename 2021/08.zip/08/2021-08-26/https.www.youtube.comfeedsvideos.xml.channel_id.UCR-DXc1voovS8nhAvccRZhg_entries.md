# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Myst runs at 4K on M1 Mac mini (2021 gameplay)
 - [https://www.youtube.com/watch?v=Uythif7gfJY](https://www.youtube.com/watch?v=Uythif7gfJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2021-08-27 00:00:00+00:00

Nobody else made a video on it, so I figured I'd put some gameplay at 4K and upscaled 720p so you can see what the new game looks and sounds like!

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com

#Myst #M1 #Apple

Contents:

00:00 - Myst on an M1 Mac mini
00:39 - Game Menus
01:12 - 4K Gameplay
03:30 - 720p Gameplay

