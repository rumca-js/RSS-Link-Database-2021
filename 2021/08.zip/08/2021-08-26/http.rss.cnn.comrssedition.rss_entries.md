# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Biden warns attackers: 'We will hunt you down and make you pay'
 - [https://www.cnn.com/videos/politics/2021/08/26/kabul-terror-attack-biden-sot-lead-vpx.cnn](https://www.cnn.com/videos/politics/2021/08/26/kabul-terror-attack-biden-sot-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 21:57:20+00:00

President Joe Biden addresses the terror attack near the Kabul airport that killed more than 60 people and wounded 140.

## Why is Herschel Walker candidacy a total nightmare for Republicans in the Senate
 - [https://www.cnn.com/videos/politics/2021/08/26/herschel-walker-senate-candidacy-cillizza-the-point.cnn](https://www.cnn.com/videos/politics/2021/08/26/herschel-walker-senate-candidacy-cillizza-the-point.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 16:55:20+00:00

Former NFL star Herschel Walker is the leading Republican candidate in the Georgia Senate race, but his candidacy is worst-case scenario for Minority Leader Mitch McConnell to try to oust freshman Democratic Sen. Raphael Warnock. In the latest episode of The Point, CNN's Chris Cillizza outlines why Donald Trump's support explains the Walker run.

## Navy helicopter crash-landing caught on video
 - [https://www.cnn.com/videos/world/2021/08/26/mexico-military-helicopter-crash-lon-orig-na.cnn](https://www.cnn.com/videos/world/2021/08/26/mexico-military-helicopter-crash-lon-orig-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 16:44:11+00:00

Several people were injured as a navy helicopter, en-route to areas hit by Hurricane Grace, crashed in Agua Blanca, Mexico, on August 25.

## Two teachers. Two different views on vaccine mandates. Hear them debate.
 - [https://www.cnn.com/videos/health/2021/08/26/nyc-teachers-vaccine-mandate-orig-mss.cnn](https://www.cnn.com/videos/health/2021/08/26/nyc-teachers-vaccine-mandate-orig-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 16:30:35+00:00

Mayor Bill De Blasio announced that 148,000 staff from New York City public schools are now required to get the Covid-19 vaccine. This is how two public school teachers feel about it.

## US personnel among those wounded in blast, officials say
 - [https://www.cnn.com/collections/afghanistan-082521/](https://www.cnn.com/collections/afghanistan-082521/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 16:01:04+00:00



## With more than 100,000 people in the hospital with Covid-19 in the US, this August is worse than last, expert says
 - [https://www.cnn.com/2021/08/26/health/us-coronavirus-thursday/index.html](https://www.cnn.com/2021/08/26/health/us-coronavirus-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 15:53:12+00:00

More than 100,000 people are currently hospitalized with Covid-19 in the United States, according to data from the US Department of Health and Human Services (HHS). That number puts the US in a worse place than August of last year.

## First images emerge from scene of explosion near Kabul airport
 - [https://www.cnn.com/videos/world/2021/08/26/explosion-hamid-karzai-airport-kabul-afghanistan-vpx.cnn](https://www.cnn.com/videos/world/2021/08/26/explosion-hamid-karzai-airport-kabul-afghanistan-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 15:50:13+00:00

Images show the aftermath of an explosion outside Hamid Karzai International Airport in Kabul, Afghanistan, as the US evacuate citizens and Afghans following the Taliban takeover.

## Skateboards containing American pro skater Tony Hawk's blood sell out overnight
 - [https://www.cnn.com/style/article/tony-hawk-blood-skateboard-scli-intl/index.html](https://www.cnn.com/style/article/tony-hawk-blood-skateboard-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 15:30:45+00:00

Athletes may be used to putting their blood, sweat and tears into sports, but legendary skater Tony Hawk has just taken it one step further.

## In the turbulent South China Sea, the US Navy bets on a troubled warship
 - [https://www.cnn.com/2021/08/25/asia/us-navy-littoral-combat-ships-pacific-south-china-sea-intl-hnk-ml-dst/index.html](https://www.cnn.com/2021/08/25/asia/us-navy-littoral-combat-ships-pacific-south-china-sea-intl-hnk-ml-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 15:20:40+00:00

When US Vice President Kamala Harris stepped aboard the littoral combat ship USS Tulsa in Singapore on Monday, it put a fresh spotlight on arguably one of the most divisive vessels in the US Navy's fleet.

## Some female hummingbirds look like males which helps them avoid many fights, a study finds
 - [https://www.cnn.com/2021/08/26/world/hummingbird-coloring-harassment-study-scn/index.html](https://www.cnn.com/2021/08/26/world/hummingbird-coloring-harassment-study-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 15:10:50+00:00

Researchers discovered a species of hummingbird in which some of the females have male-colored plumage and are socially harassed less than their drab-colored counterparts.

## Mandy Patinkin shares emotional 'Princess Bride' backstory
 - [https://www.cnn.com/2021/08/26/entertainment/mandy-patinkin-princess-bride-trnd/index.html](https://www.cnn.com/2021/08/26/entertainment/mandy-patinkin-princess-bride-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 15:07:53+00:00

Way to make us cry Mandy Patinkin.

## Dad in Texas strips to support masks at school board meeting
 - [https://www.cnn.com/videos/politics/2021/08/26/school-board-meeting-mask-mandate-texas-orig-me.cnn](https://www.cnn.com/videos/politics/2021/08/26/school-board-meeting-mask-mandate-texas-orig-me.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 15:06:44+00:00

"We follow certain rules for a very good reason," says James Akers, a Texas parent who nearly stripped naked during a Dripping Springs school board meeting.

## 'I want to do it again' says five-year-old after hiking Appalachian Trail
 - [https://www.cnn.com/videos/us/2021/08/26/appalachian-trail-5-year-old-boy-galanos-mxp-vpx.hln](https://www.cnn.com/videos/us/2021/08/26/appalachian-trail-5-year-old-boy-galanos-mxp-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 14:55:32+00:00

Five-year-old Harvey Sutton becomes one of the youngest people to hike the Appalachian Trail with his parents over the course of seven months. HLN's Mike Galanos reports.

## 4-year-old's adorable passion for veggies and nutrition goes viral
 - [https://www.cnn.com/videos/health/2021/08/26/tiktok-viral-veggie-kid-orig-bdk.cnn](https://www.cnn.com/videos/health/2021/08/26/tiktok-viral-veggie-kid-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 14:23:24+00:00

A young boy from Alaska has become an internet sensation for TikTok videos showing his love for eating from his family's vegetable garden.

## Kanye West is holding a new listening event and this one has vaccines
 - [https://www.cnn.com/2021/08/26/entertainment/kanye-west-trnd/index.html](https://www.cnn.com/2021/08/26/entertainment/kanye-west-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 14:02:40+00:00

Kanye West is holding more listening events in anticipation of his "Donda" album, and the next one will have Covid-19 vaccines available.

## UK worker shortages could cancel Christmas. Brexit isn't helping
 - [https://www.cnn.com/2021/08/26/business/brexit-uk-food-shortages-christmas/index.html](https://www.cnn.com/2021/08/26/business/brexit-uk-food-shortages-christmas/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 13:56:01+00:00

UK food producers and supermarkets are warning that empty shelves could persist through the year-end holiday season unless the government acts to ease a shortage of workers and truck drivers caused by Brexit and the coronavirus pandemic.

## The US economy grew slightly more than we thought last quarter
 - [https://www.cnn.com/2021/08/26/economy/us-economy-second-quarter-gdp/index.html](https://www.cnn.com/2021/08/26/economy/us-economy-second-quarter-gdp/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 13:56:00+00:00

America's economy expanded at a slightly faster pace than initially thought in the second quarter, the Bureau of Economic Analysis reported Thursday.

## John McEnroe says his famous on-court outburst earned him a Netflix voice-over career
 - [https://www.cnn.com/2021/08/26/entertainment/john-mcenroe-netflix-voice-over-career-scli-intl/index.html](https://www.cnn.com/2021/08/26/entertainment/john-mcenroe-netflix-voice-over-career-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 13:54:00+00:00

Tennis legend John McEnroe, who earned plaudits for an unlikely turn as narrator of the popular Netflix teen drama "Never Have I Ever," has credited his voice-over career to his famous 1981 outburst in which he screamed, "You cannot be serious" at an umpire.

## Gunmen kill 36 villagers in Nigeria's divided Plateau state
 - [https://www.cnn.com/2021/08/26/africa/villagers-killed-plateau-nigeria-intl/index.html](https://www.cnn.com/2021/08/26/africa/villagers-killed-plateau-nigeria-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 13:33:28+00:00

Attackers shot dead at least 36 people and destroyed buildings in a night raid on a village near the central Nigerian city of Jos, officials said, in an area hit by repeated ethnic clashes.

## Politico will be sold to Axel Springer for over $1 billion
 - [https://www.cnn.com/2021/08/26/media/politico-sale-axel-springer/index.html](https://www.cnn.com/2021/08/26/media/politico-sale-axel-springer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 13:26:34+00:00

Axel Springer, the German media conglomerate, has agreed to buy the Washington-based Politico franchise for more than $1 billion.

## What pizza from a vending machine really tastes like
 - [https://www.cnn.com/travel/article/rome-pizza-vending-machine-review/index.html](https://www.cnn.com/travel/article/rome-pizza-vending-machine-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 13:24:12+00:00

Rome's new pizza vending machine, Mr. Go, cooks pizza from scratch in just three minutes. Can it beat the famous pizzerias of Trastevere?

## Online shopping used to be immune to inflation. Not anymore
 - [https://www.cnn.com/2021/08/26/economy/inflation-economy-online-shopping/index.html](https://www.cnn.com/2021/08/26/economy/inflation-economy-online-shopping/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 13:03:55+00:00

Sticker shock has even invaded the land of falling prices: online shopping.

## Michael Nader, 'Dynasty' and 'All My Children' actor, dies age 76
 - [https://www.cnn.com/2021/08/26/entertainment/michael-nader-dynasty-dies-intl-scli/index.html](https://www.cnn.com/2021/08/26/entertainment/michael-nader-dynasty-dies-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 12:52:47+00:00

Michael Nader, the actor best known for playing Farnsworth "Dex" Dexter on the hit soap "Dynasty," has died age 76.

## Afro Latinx children's books are still too rare. These four authors are trying to change that
 - [https://www.cnn.com/style/article/afro-latinx-childrens-books-hyphenated/index.html](https://www.cnn.com/style/article/afro-latinx-childrens-books-hyphenated/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 12:51:46+00:00

A vivid homage to the graffitied streets of the Boogie Down Bronx and an interstellar quest for the perfect natural hair style are part of a new wave of picture books celebrating Afro Latinx culture and characters, in an industry where these stories are still few and far between.

## Will Trump's 'executive privilege' claim work or just delay insurrection probe?
 - [https://www.cnn.com/videos/politics/2021/08/26/january-6-commission-subpoenas-donald-trump-executive-privilege-honig-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/08/26/january-6-commission-subpoenas-donald-trump-executive-privilege-honig-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 12:29:08+00:00

CNN senior legal analyst Elie Honig shows how former President Donald Trump's claims of executive privilege could play out in relation to the House special commission on the January 6 insurrection.

## The most ridiculous historical arguments denying women the right to vote
 - [https://www.cnn.com/2021/08/26/us/womens-equality-day-right-to-vote-trnd/index.html](https://www.cnn.com/2021/08/26/us/womens-equality-day-right-to-vote-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 12:03:51+00:00

Today, women being able to vote is a given. A no-brainer. A natural, non-negotiable insurance of a Constitution designed to provide equality for all people. But before the 19th Amendment was ratified in 1920, ensuring all women the right to vote*, people invented all sorts of reasons why they didn't belong at the polls. (*Assuming you weren't Black or disabled.)

## Kristen Stewart channels Princess Diana's turmoil in 'Spencer' poster
 - [https://www.cnn.com/style/article/kristen-stewart-diana-spencer-poster/index.html](https://www.cnn.com/style/article/kristen-stewart-diana-spencer-poster/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 11:59:21+00:00

A newly unveiled poster for the upcoming Princess Diana biopic, "Spencer," hints at the behind-the-scenes royal anguish depicted by director Pablo Larraín and lead actress Kristen Stewart.

## Interest rate hikes have arrived in this major economy
 - [https://www.cnn.com/2021/08/26/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2021/08/26/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 11:46:25+00:00

The hottest debate among economists and investors is when central banks will back away from pandemic-era policies. After months of ambiguity, they finally have an answer — at least from South Korea.

## Are you working for the Taliban?: CNN asks Kabul mayor
 - [https://www.cnn.com/videos/world/2021/08/25/afghanistan-taliban-kabul-mayor-mohammad-daoud-sot-giokos-ctw-vpx.cnn](https://www.cnn.com/videos/world/2021/08/25/afghanistan-taliban-kabul-mayor-mohammad-daoud-sot-giokos-ctw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 10:57:28+00:00

Kabul Mayor Mohammad Daoud tells CNN's Eleni Giokos why he stayed in Afghanistan's capital as the Taliban took over, and that he remains the mayor of the city.

## Hong Kong's global banks brace for 'cold war' to escalate
 - [https://www.cnn.com/2021/08/26/business/hong-kong-anti-sanctions-law-banks-intl-hnk/index.html](https://www.cnn.com/2021/08/26/business/hong-kong-anti-sanctions-law-banks-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 10:43:05+00:00

Three quarters of the world's top banks do business in Hong Kong. But they've been getting squeezed by changes forcing them to fall in line with Beijing's agenda — and there may be signs of even tougher times to come.

## See massive jellyfish swarm wash up on Crimea beach
 - [https://www.cnn.com/videos/world/2021/08/26/jellyfish-swarm-crimea-lon-orig-tp.cnn](https://www.cnn.com/videos/world/2021/08/26/jellyfish-swarm-crimea-lon-orig-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 10:35:20+00:00

Jellyfish gather along the coast every year to feed and breed, but higher water temperatures have created ideal conditions for their numbers to boom.

## Gunman kills four in attack near French embassy in Tanzania
 - [https://www.cnn.com/2021/08/26/africa/gunman-kills-four-tanzania-intl/index.html](https://www.cnn.com/2021/08/26/africa/gunman-kills-four-tanzania-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 10:29:22+00:00

A gunman killed three police officers and a private security guard on a rampage through a diplomatic quarter of Tanzania's main city Dar es Salaam on Wednesday, before being shot dead while holed up in a guardhouse at the French embassy's gate.

## It's summertime and the food freezing is easy. Here's how
 - [https://www.cnn.com/2021/08/26/health/food-freezing-summer-wellness/index.html](https://www.cnn.com/2021/08/26/health/food-freezing-summer-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 10:29:02+00:00

Whether you're a home gardener, a CSA-er or a farmers' market regular, it's easy to wind up with more irresistibly pristine, fresh-picked produce than your household can possibly consume in its peak state of ripeness.

## Man arrested after food injected with needles at stores
 - [https://www.cnn.com/2021/08/26/europe/london-supermarket-contamination-arrest-scli-intl-gbr/index.html](https://www.cnn.com/2021/08/26/europe/london-supermarket-contamination-arrest-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 10:23:16+00:00

A man has been arrested on suspicion of contaminating food after processed meat and microwaveable products were injected with needles at three London stores.

## This new class of hot ocean worlds could support life
 - [https://www.cnn.com/2021/08/26/world/hycean-planets-habitable-scn/index.html](https://www.cnn.com/2021/08/26/world/hycean-planets-habitable-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 10:16:55+00:00

In the quest to find potentially habitable planets outside of our solar system, astronomers have searched for exoplanets similar to Earth.

## What do we know about ISIS branch threatening Kabul evacuation?
 - [https://www.cnn.com/videos/tv/2021/08/25/exp-tsr-todd-isis-k.cnn](https://www.cnn.com/videos/tv/2021/08/25/exp-tsr-todd-isis-k.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 09:59:15+00:00

CNN's Brian Todd explains the terrorist group ISIS-K, the ISIS branch that rivalries the Taliban in Afghanistan and could pose a threat to the American evacuation from the Kabul airport.

## Artist uses costume to defy stereotypes of Afro Latinx and Caribbean religions
 - [https://www.cnn.com/style/article/yelaine-rodriguez-costumes-afro-latinx-caribbean-religions-hyphenated/index.html](https://www.cnn.com/style/article/yelaine-rodriguez-costumes-afro-latinx-caribbean-religions-hyphenated/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 09:32:01+00:00

Yelaine Rodriguez is used to people making assumptions about her identity and what she does.

## Pep Guardiola says he plans to leave Manchester City in 2023 as Harry Kane says he's staying at Spurs
 - [https://www.cnn.com/2021/08/26/football/manchester-city-guardiola-kane-spt-intl/index.html](https://www.cnn.com/2021/08/26/football/manchester-city-guardiola-kane-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 08:54:42+00:00

Manchester City suffered a double blow on Wednesday as manager Pep Guardiola said he plans to leave the club in 2023 as Spurs striker Harry Kane announced he is staying at the London team.

## Roman Catholic Diocese of Las Vegas will not issue religious exemptions for Covid-19 vaccine
 - [https://www.cnn.com/2021/08/26/us/catholic-diocese-covid-19-vaccine-religious-exemption/index.html](https://www.cnn.com/2021/08/26/us/catholic-diocese-covid-19-vaccine-religious-exemption/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 08:51:51+00:00

The Roman Catholic Diocese of Las Vegas will not issue letters of exemption for the Covid-19 vaccine on religious grounds, the diocese told pastors Monday.

## This center in Dubai is growing 'future-proof' food in the desert
 - [https://www.cnn.com/2021/08/26/middleeast/dubai-icba-future-food-spc-intl/index.html](https://www.cnn.com/2021/08/26/middleeast/dubai-icba-future-food-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 08:49:35+00:00

Rising temperatures and extreme weather events exacerbated by climate change are making farming conditions increasingly challenging and disrupting food distribution. But scientists in some of the world's driest places are coming up with solutions to boost local food production by introducing plants that thrive with less-fertile soil and seawater.

## Hong Kong national security police investigate Tiananmen Square vigil organizers
 - [https://www.cnn.com/2021/08/26/asia/hong-kong-national-security-tiananmen-vigil-intl-hnk/index.html](https://www.cnn.com/2021/08/26/asia/hong-kong-national-security-tiananmen-vigil-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 07:47:53+00:00

Hong Kong's national security police are investigating the group behind the city's annual June 4 vigil, which commemorates pro-democracy protesters who died in the 1989 Tiananmen Square crackdown in Beijing, according to a letter to organizers seen by CNN.

## Eliud Kipchoge: Can't move forward without embracing technology, says Olympic champion
 - [https://www.cnn.com/2021/08/26/sport/eliud-kipchoge-technology-athletes-spt-intl/index.html](https://www.cnn.com/2021/08/26/sport/eliud-kipchoge-technology-athletes-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 07:41:09+00:00

Marathon world record holder and Olympic champion Eliud Kipchoge hopes that technology will take "centre stage" as athletes strive for improvement and chase faster times in the future.

## Australia reports record Covid-19 cases as Sydney hospitals set up emergency tents
 - [https://www.cnn.com/2021/08/26/australia/australia-sydney-covid-19-pandemic-intl-hnk/index.html](https://www.cnn.com/2021/08/26/australia/australia-sydney-covid-19-pandemic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 06:00:22+00:00

Australia's new daily cases of Covid-19 topped 1,000 on Thursday for the first time since the global pandemic began, as two major hospitals in Sydney set up emergency outdoor tents to help deal with a rise in patients.

## This former ICU nurse makes $200k a month on OnlyFans
 - [https://www.cnn.com/videos/business/2021/08/25/onlyfans-ban.cnn](https://www.cnn.com/videos/business/2021/08/25/onlyfans-ban.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 05:01:47+00:00

OnlyFans reversed its decision to ban sexually explicit content on the platform, after backlash from creators like Allie Rae who earn a living on the site.

## Iceland has had 0 deaths from coronavirus since May. Here's why
 - [https://www.cnn.com/videos/world/2021/08/26/iceland-coronavirus-vaccines-tuchman-dnt-ac360-vpx.cnn](https://www.cnn.com/videos/world/2021/08/26/iceland-coronavirus-vaccines-tuchman-dnt-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 04:58:48+00:00

CNN's Gary Tuchman looks at how Iceland has been able to lower deaths from Covid-19 to zero, and maintain it since May.

## Anger and confusion inside ABC News after former 'Good Morning America' boss is sued for alleged sexual assault
 - [https://www.cnn.com/2021/08/25/media/abc-news-michael-corn-kim-godwin/index.html](https://www.cnn.com/2021/08/25/media/abc-news-michael-corn-kim-godwin/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 04:32:03+00:00

A version of this article first appeared in the "Reliable Sources" newsletter. You can sign up for free right here.

## She lost her legs in a terror attack. Now, she's competing in the Paralympics
 - [https://www.cnn.com/2021/08/26/sport/beatrice-de-lavalette-tokyo-2020-spt-intl/index.html](https://www.cnn.com/2021/08/26/sport/beatrice-de-lavalette-tokyo-2020-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 04:11:48+00:00

Beatrice de Lavalette was 17 years old when she was at Brussels' Zaventem Airport, heading back to the US for spring break.

## Why I love 'boring' hotels
 - [https://www.cnn.com/travel/article/praise-generic-boring-hotels-cmd/index.html](https://www.cnn.com/travel/article/praise-generic-boring-hotels-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 02:24:11+00:00

Standing in a pretentious New York City art gallery, I heard the woman next to me sniff loudly and say: "That piece should be hanging in a hotel."

## Virgin Hyperloop releases new video of 670 mph passenger pods
 - [https://www.cnn.com/travel/article/virgin-hyperloop-video-scli-intl/index.html](https://www.cnn.com/travel/article/virgin-hyperloop-video-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 02:03:43+00:00

Virgin Hyperloop has released a new concept video showing its plans for a transportation system it says will allow passengers to travel in a pod in a near-vacuum tube, reaching speeds of up to 670 mph.

## Video of Rudy Giuliani in airport grosses out internet users
 - [https://www.cnn.com/videos/us/2021/08/26/rudy-giuliani-seen-shaving-in-public-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2021/08/26/rudy-giuliani-seen-shaving-in-public-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 00:51:27+00:00

Rudy Giuliani shaves in public at an airport dining area. Grossed out viewers lose their appetites. CNN's Jeanne Moos reports.

## CNN speaks to voters in California
 - [https://www.cnn.com/videos/politics/2021/08/25/california-recall-newsom-democrats-lah-lead-pkg-vpx.cnn](https://www.cnn.com/videos/politics/2021/08/25/california-recall-newsom-democrats-lah-lead-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-26 00:24:18+00:00

CNN's Kyung Lah reports on the frustration and rising tensions among California Democrats about Gov. Gavin Newsom.

