## Australia Revives Nazi-style “Quarantine Camps” to “Keep People Safe” - The New American
 - [https://thenewamerican.com/australia-revives-nazi-style-quarantine-camps-to-keep-people-safe/](https://thenewamerican.com/australia-revives-nazi-style-quarantine-camps-to-keep-people-safe/)
 - RSS feed: https://thenewamerican.com
 - date published: 2021-08-26 20:30:33+00:00

Australia Revives Nazi-style “Quarantine Camps” to “Keep People Safe” - The New American

