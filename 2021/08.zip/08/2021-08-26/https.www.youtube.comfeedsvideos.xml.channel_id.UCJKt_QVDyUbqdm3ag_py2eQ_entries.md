# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Firefox - Galaxy (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=WYCwDoyfLN4](https://www.youtube.com/watch?v=WYCwDoyfLN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-08-27 00:00:00+00:00

"Galaxy" (1990) by Firefox/Phenomena (Jimmy Fredriksson), 1st at Phenomena & Censor Party. Art "Lockdown - Luctor et Emergo" by Facet/Lemon^Genesis Project, 2nd at Revision Online 2021.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

