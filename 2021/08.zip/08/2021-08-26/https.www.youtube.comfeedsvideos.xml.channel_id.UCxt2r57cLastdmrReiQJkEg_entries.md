# Source:Tom Nicholas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxt2r57cLastdmrReiQJkEg, language:en-US

## The Problem with YouTuber Boxing 🥊
 - [https://www.youtube.com/watch?v=_X_R-OewhxY](https://www.youtube.com/watch?v=_X_R-OewhxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxt2r57cLastdmrReiQJkEg
 - date published: 2021-08-26 00:00:00+00:00

Go to https://Surfshark.deals/tomnicholas and use code TOMNICHOLAS to get 83% off a 2 year plan plus 3 extra months for free!

Watch this video ad-free on Nebula: https://nebula.tv/videos/tom-nicholas-the-problem-with-youtuber-boxing

A video about Logan Paul, Jake Paul, YouTube boxing and the pursuit of redemption.

*Chapters*

0:00 Logan Paul & Jake Paul Boxing Call-Out
01:36 1. YouTuber Boxing
07:38 2. More Than Just a Game
13:00 3. The Boxing Story
21:02 Surfshark VPN Spot
22:46 4. Lads Who Landscape
32:06 5. Respectability on the Ropes
42:35 6. Whose Story is it Anyway?

*Some Copy about the Video for the YouTube Algorithm*

The past few years have seen the rise of a strange phenomenon in the form of YouTuber Boxing. Where Joe Weller vs KSI and even KSI vs Logan Paul felt strange and new, the recent Social Gloves (or YouTubers vs TikTokers) event suggested that the embrace of the sweet science of bruising by influencers and other online creators might be here to stay.

Few have embraced the trend more than the Paul brothers, Logan & Jake, however. Since losing to KSI, Logan has gone on to fight Floyd Mayweather whilst Jake has taken on Deji, AnEsonGib, Nate Robinson and Ben Askren. Jake Paul vs Tyron Woodley is sure to similarly draw huge crowds to watch online.

In this video, I try to unpick the Jake Paul and Logan Paul's pivot to boxing as an act of story telling—in particular an attempt to draw upon a well-established set of tropes from the boxing film genre (including titles such as Rocky, Creed, Million Dollar Baby, Raging Bull, The Fighter and Cinderella Man) to help pave their road to redemption.

Support the channel on Patreon at http://patreon.com/tomnicholas

If you've enjoyed this video and would like to see more including my What The Theory? series in which I provide some snappy introductions to key theories in the humanities as well as video essays and more then do consider subscribing.

Thanks for watching!

Twitter: http://twitter.com/tom_nicholas
Instagram: http://instagram.com/tomnicholaswtf
Patreon: http://patreon.com/tomnicholas
Website: http://www.tomnicholas.com

#jakepaul #loganpaul #boxing

