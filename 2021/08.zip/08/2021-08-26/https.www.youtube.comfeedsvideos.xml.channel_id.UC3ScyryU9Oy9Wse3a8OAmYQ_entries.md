# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Beyond Baghdad (full documentary) | FRONTLINE
 - [https://www.youtube.com/watch?v=u2ne_MNa3vk](https://www.youtube.com/watch?v=u2ne_MNa3vk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2021-08-26 00:00:00+00:00

In the summer of 2003, violence against the U.S.-led coalition in Iraq spiked alarmingly. Traveling across Iraq, FRONTLINE reporters went to see how the U.S. plan to turn the country into a showcase for democracy in the Middle East was faring. (Aired 2004)
 
This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate​.

In the 2004 documentary, “Beyond Baghdad'', veteran investigative team Martin Smith, Marcela Gaviria and Scott Anger continued their reporting on Iraq, setting out on a five-week journey across the country, from the Kurdish north, through the Sunni Triangle, to the Shiite south, taking a hard look at the social and political reality beyond the political corridors of Baghdad.

Love FRONTLINE? Find us on the PBS Video App where there are more than 300 FRONTLINE documentaries available for you to watch any time: https://to.pbs.org/FLVideoApp​ 

#Documentary​ #BeyondBaghdad

Subscribe on YouTube: http://bit.ly/1BycsJW​
Instagram: https://www.instagram.com/frontlinepbs​
Twitter: https://twitter.com/frontlinepbs​
Facebook: https://www.facebook.com/frontline

Major funding for FRONTLINE is provided by the Ford Foundation. Additional funding is provided by the Abrams Foundation; the John D. and Catherine T. MacArthur Foundation; Park Foundation; and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation, and additional support from Koo and Patricia Yuen.

