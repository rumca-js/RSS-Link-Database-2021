# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Candyman (2021) - Movie Review
 - [https://www.youtube.com/watch?v=4Lfx-eotCOM](https://www.youtube.com/watch?v=4Lfx-eotCOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-08-27 00:00:00+00:00

Video Sponsored by Ridge Wallet. Check them out here: https://ridge.com/JAHNS Use Code JAHNS for 10% off your order!

Candyman, is the sequel to Candyman. Does Candyman live up to Candyman? Here's my review of CANDYMAN!

#Candyman

