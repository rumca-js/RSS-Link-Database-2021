# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## This Tortoise Has a Taste for Blood | SciShow News
 - [https://www.youtube.com/watch?v=2b7t6kUdWhQ](https://www.youtube.com/watch?v=2b7t6kUdWhQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-08-27 00:00:00+00:00

You're entering a world, where one of the most blood thirsty predators, is a giant tortoise

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, charles george, Christoph Schwanke, Ash, Silas Emrys, KatieMarie Magnone, Eric Jensen, Adam Brainard, Piya Shedden, Alex Hackman, James Knight, GrowingViolet, Sam Lutfi, Alisa Sherbow, Jason A Saslow, Dr. Melvin Sanicas

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.cell.com/current-biology/fulltext/S0960-9822(21)00917-9 
https://www.eurekalert.org/news-releases/925589
https://doi.org/10.1656/1528-7092-7.3.562
https://doi.org/10.1111/j.1469-7998.1988.tb02451.x 
https://doi.org/10.1676/04-056

https://dx.doi.org/10.1016/j.cub.2021.08.010
https://www.eurekalert.org/news-releases/926020 
https://doi.org/10.3390/ijerph17217827
https://www.aaas.org/news/have-we-entered-second-antibiotic-era
https://doi.org/10.3389/fmicb.2014.00023
https://doi.org/10.1038/sj.bdj.2012.573 

https://commons.wikimedia.org/wiki/File:Fregate_Island_3.jpg
https://www.eurekalert.org/multimedia/796889
https://commons.wikimedia.org/wiki/File:Anse_Victorin,_Fregate_Island,_Seychelles_-_panoramio.jpg
https://www.istockphoto.com/photo/deer-fawn-gm472096009-32309546
https://www.istockphoto.com/photo/brown-bear-roaring-in-forest-gm914770576-251764468
https://www.istockphoto.com/photo/veterinarian-holds-syringe-with-antibiotics-gm1126701092-296728113
https://en.wikipedia.org/wiki/File:Eurasian_Brown_Bear.jpg
https://en.wikipedia.org/wiki/Clostridioides_difficile_(bacteria)#/media/File:Clostridium_difficile_01.jpg

