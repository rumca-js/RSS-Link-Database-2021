# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Free Will and the Problem of Drunk Driving Elephants
 - [https://www.youtube.com/watch?v=cor2rXkFfek](https://www.youtube.com/watch?v=cor2rXkFfek)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-27 00:00:00+00:00

Kyle and Ethan are joined by our friendly neighborhood professor of theology, Dr. Thaddeus Williams. He is the author of Confronting Injustice Without Compromising Truth (https://www.amazon.com/Confronting-Injustice-without-Compromising-Truth/dp/0310119480) and God Reforms Hearts: Rethinking Free Will and the Problem of Evil (https://www.amazon.com/God-Reforms-Hearts-Rethinking-Problem/dp/1683594975/ref=sr_1_4?crid=ETLXLM9GB31M&dchild=1&keywords=thaddeus+williams&qid=1629828040&sprefix=micro+h%2Caps%2C220&sr=8-4). 

As usual, they dig into the weird news of the week, but they also get an update from Ethan’s wife about her experience getting a mandatory jab, and talk to Dr. Williams about how free will doesn’t get God off the hook for all the evil in the world.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Gavin Newsom Tells Californians To Stay Home Stay Safe On Recall Election Day
 - [https://www.youtube.com/watch?v=8vSZ1teZldc](https://www.youtube.com/watch?v=8vSZ1teZldc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-26 00:00:00+00:00

Covid is bad! We gotta do something about it. Well, Governor Newsom has a plan. All Californians lockdown on September 14th, which happens to also be recall election day! Easy! Don’t do anything on September 14th. For Covid. No other reason.


Become a premium subscriber:  https://babylonbee.com/plans


The Official The Babylon Bee Store:  https://shop.babylonbee.com/


Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

