# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## All Eyes on Me // Bo Burnham // POMP + Nick Campbell Destroys
 - [https://www.youtube.com/watch?v=HpGtRhGmRyE](https://www.youtube.com/watch?v=HpGtRhGmRyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-08-26 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Not sure if you’ve gotten around to the Bo Burnham special yet, but I live under a rock and I still saw it soooo...I’m assuming the rest of the internet has too. This beeeeauty here is a cover of “All Eyes on Me” featuring Nick Campbell and Swatkins! It is fun to watch and also to listen to.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Bo Burnham's "All Eyes on Me" by Pomplamoose, Nick Campbell, & Swatkins

MUSICIAN CREDITS
Lead Vocals / Keys: Swatkins
Keys: Jack Conte, Jacob Luttrell
Bass: Nick Campbell
Drums: Chaun Horton
Percussion: Ben Rose

AUDIO CREDITS
Engineer: Tim Sonnefeld 
Assistant Engineer: Tyler Karmen
Mixing/Mastering: Yianni AP

VIDEO CREDITS
Director: Dom Fera
DP: Merlin Showalter
Gaffer: Arjay Ancheta
Production Design: Katie Theel
PA: Chris Modl
Assistant: Alex Allen
Editor: Dominic Mercurio

Recorded at 64 Sound in Los Angeles.

