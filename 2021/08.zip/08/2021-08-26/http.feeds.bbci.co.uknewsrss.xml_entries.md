# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Tokyo Paralympics: Lee Pearson wins 12th gold as GB enjoy cycling and swimming success
 - [https://www.bbc.co.uk/sport/disability-sport/58338980?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/disability-sport/58338980?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 11:55:30+00:00

Lee Pearson wins his 12th gold medal as Great Britain enjoy a successful day two at the Tokyo Paralympics

## Majority of eligible people evacuated from Kabul - PM
 - [https://www.bbc.co.uk/news/uk-58339762?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58339762?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 11:47:08+00:00

Boris Johnson says British troops have evacuated about 15,000 people from the Afghan capital.

## Champions League draw: When does it take place? Who has qualified? All you need to know
 - [https://www.bbc.co.uk/sport/football/58256936?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58256936?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 11:46:39+00:00

The draw for this the Champions League takes place on Thursday at 17:00 BST in Istanbul, as defending champions Chelsea await their fate.

## Former England and Sussex captain Dexter dies aged 86
 - [https://www.bbc.co.uk/sport/cricket/58337771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/58337771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 11:39:30+00:00

Former England captain and attacking batter Ted Dexter dies aged 86.

## Stalin-era mass grave found in Ukraine
 - [https://www.bbc.co.uk/news/world-europe-58340805?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58340805?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 11:22:50+00:00

Thousands of people are thought to be buried at the site - one of the largest ever found in Ukraine.

## England v India: Mohammed Shami bowls Rory Burns for 61
 - [https://www.bbc.co.uk/sport/av/cricket/58343176?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/58343176?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 11:00:10+00:00

India's Mohammed Shami bowls England opener Rory Burns for 61 to end his 135-run first-wicket partnership with Haseeb Hameed on day two of the third Test at Headingley.

## Food firm in 'drastic' action amid driver shortage
 - [https://www.bbc.co.uk/news/business-58339182?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-58339182?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 10:57:44+00:00

Wholesaler Country Range says it is buying smaller vans to get round the lack of HGV drivers.

## Afghanistan: Plane leaving Luton to evacuate rescue animals and staff
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-58340272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-58340272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 10:51:24+00:00

The privately funded plane is due to collect Paul "Pen" Farthing along with staff and animals.

## Lisa Shaw: Presenter's death due to complications of Covid vaccine
 - [https://www.bbc.co.uk/news/uk-england-tyne-58330796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-58330796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 10:48:31+00:00

Lisa Shaw developed headaches shortly after being vaccinated against Covid-19.

## Custard to be reinstated in Aberdeenshire after school petition
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-58341247?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-58341247?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 10:36:25+00:00

Aberdeenshire pupils took action to reinstate their favourite puddings, described as the "best in the world".

## Mass brawl erupts in Armenian parliament: Third violent bout in just two days
 - [https://www.bbc.co.uk/news/world-europe-58340042?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-58340042?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 10:31:52+00:00

Security personnel were called in to remove several members after violence erupted on the parliament floor.

## Taylor Wessing Prize 2021: Shortlisted photographers revealed
 - [https://www.bbc.co.uk/news/entertainment-arts-58341080?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58341080?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 10:25:45+00:00

The three shortlisted photographers for the prestigious Taylor Wessing Prize have been revealed.

## Abba: Band teases major announcement ahead of new music
 - [https://www.bbc.co.uk/news/entertainment-arts-58339627?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-58339627?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 10:06:18+00:00

The band, who have not released new music for 39 years, reveal a new project called Abba Voyage.

## Northern Ireland hospital waiting lists grow
 - [https://www.bbc.co.uk/news/uk-northern-ireland-58342209?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-58342209?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 09:52:55+00:00

The latest figures show that 348,867 people are now waiting for a first consultant appointment.

## Sports Direct owner's new boss offered potential £100m bonus
 - [https://www.bbc.co.uk/news/business-58340082?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-58340082?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 09:30:02+00:00

Michael Murray, Mike Ashley's future son-in-law, must more than double the firm's share price.

## GB's Kearney wins 100m freestyle gold in record time
 - [https://www.bbc.co.uk/sport/av/disability-sport/58340452?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/disability-sport/58340452?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 08:36:30+00:00

Watch ParalympicsGB's Tully Kearney win gold in the women's S5 100m freestyle final in Tokyo, breaking her own world record.

## Data protection 'shake-up' takes aim at cookie pop-ups
 - [https://www.bbc.co.uk/news/technology-58340333?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-58340333?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 08:19:03+00:00

A new head has been appointed to the UK data regulator amid a plan to drive the economy using data.

## Guardiola plans to leave Man City when contract expires in 2023
 - [https://www.bbc.co.uk/sport/football/58339343?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/58339343?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 06:54:04+00:00

Pep Guardiola says he will leave Manchester City when his contract runs out in 2023 before managing a national team.

## Covid: Jab preparation for 12 to 15-year-olds and vial shortages
 - [https://www.bbc.co.uk/news/uk-58335460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-58335460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 06:51:10+00:00

Five things you need to know about the coronavirus pandemic this Thursday morning.

## Frozen: Can the stage musical recreate the film's magic?
 - [https://www.bbc.co.uk/news/entertainment-arts-57968594?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-57968594?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 05:45:26+00:00

Some critics are sceptical, but London's Anna and Elsa say the stage adaptation will please fans.

## Tokyo Paralympics: Britain's Ali Jawad says he has 'been in self-isolation for three years'
 - [https://www.bbc.co.uk/sport/disability-sport/58288094?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/disability-sport/58288094?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 05:26:46+00:00

British powerlifter Ali Jawad says he has effectively self-isolated for three years to make it to the Paralympics.

## John McAleese: The SAS soldier who was the man behind the mask
 - [https://www.bbc.co.uk/news/uk-scotland-tayside-central-58328164?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-tayside-central-58328164?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 05:17:12+00:00

John McAleese was the Scots soldier watched by millions on live television in the Iranian Embassy raid.

## The Papers: 'Head for border' and jab plan for 12-year-olds
 - [https://www.bbc.co.uk/news/blogs-the-papers-58337522?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-58337522?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 05:06:50+00:00

The focus is on the latest efforts to evacuate Afghans, and the possibility of extending the Covid vaccine rollout to younger age groups.

## Australian farmer draws heart with sheep in tribute to aunt
 - [https://www.bbc.co.uk/news/world-australia-58338661?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-58338661?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 03:59:50+00:00

The Australian man was unable to attend his aunt's funeral because of Covid travel restrictions.

## The English Riviera during the 2021 UK staycation
 - [https://www.bbc.co.uk/news/in-pictures-58319665?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-58319665?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-26 00:54:37+00:00

Photographer David Hares captures people enjoying the seaside during the staycation of 2021.

