# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Jeff Tweedy - three solo, live performances (2018)
 - [https://www.youtube.com/watch?v=3TVqbvp_QNI](https://www.youtube.com/watch?v=3TVqbvp_QNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-08-26 00:00:00+00:00

Happy birthday to Jeff Tweedy! Born August 25 in Belleville, Ill., near St. Louis, Mo.; Tweedy moved upstate to Chicago after Uncle Tupelo broke up in 1994, at which time Tweedy co-founded the band Wilco.

Here are three solo acoustic performances by Jeff Tweedy, recorded for a Live From Here episode at the Lied Center for Performing Arts, Lincoln, Neb., on Oct. 27, 2018.

SONGS PERFORMED
0:00 "Some Birds"
3:25 "Having Been Is No Way To Be"
7:53 "You And I"

PERSONNEL
Jeff Tweedy – guitar and vocals
Alex Hargreaves – fiddle (on "Having Been Is No Way To Be")

CREDITS
Video & Photo: Ben Miller, American Public Media
Audio: Sam Hudson, American Public Media
Production: Jeffy Hnilicka, Tom Campbell, American Public Media

FIND MORE:
2015 Tweedy studio session: https://www.thecurrent.org/feature/2015/03/09/tweedy-perform-live-in-the-current-studio
2016 Wilco live performance of "If I Ever Was a Child":
https://www.thecurrent.org/feature/2016/09/09/listen-to-wilco-from-halls-island
2017 Wilco concert at the Palace Theatre:
https://www.thecurrent.org/feature/2017/11/16/wilco-live-in-concert-from-the-palace-theatre
2017 Live From Here show:
https://www.livefromhere.org/shows/2017/12/16/live-broadcast-december-16-2017-with-jeff-tweedy-the-staves-ymusic-punch-brothers-and-tom
2018 Live From Here show:
https://www.livefromhere.org/shows/2018/10/27/jeff-tweedy-diana-gordon-todd-barry

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#jefftweedy #solo #acoustic

