# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## I'm on wikifeet..
 - [https://www.youtube.com/watch?v=hMLazPRc664](https://www.youtube.com/watch?v=hMLazPRc664)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-08-26 00:00:00+00:00

I found my wikifeet profile.. Thank you to Canva for sponsoring this video, get your 45 day extended free trial here: http://canva.me/julienolke

Actors: Julie Nolke & Jill Agopsowicz (https://www.imdb.com/name/nm10409865/?ref_=fn_al_nm_1)
Written by: Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Support the channel by liking and subscribing! 
Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke

