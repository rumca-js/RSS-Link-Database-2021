# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The Tragic Tale of Reddit
 - [https://www.youtube.com/watch?v=0SQ-TJKPPIg](https://www.youtube.com/watch?v=0SQ-TJKPPIg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2021-08-27 00:00:00+00:00

Reddit mods are destroying the internet. And they're being paid for it. 

This video explains how Reddit makes money and how Reddit became trash and why Reddit is now cringe. Reddit mods have made Reddit suck and they did it for money. This video will go through the story of why Reddit is trash and why Reddit is so bad for censorship because of Reddit mods. 
This video explains how Reddit became trash and why Reddit is now cringe. Reddit mods have made Reddit millions and are a key reason behind how Reddit makes money. This video will go through the story of why Reddit is trash and why Reddit is so bad for censorship because of Reddit mods.

►  Become a Patron:  https://www.patreon.com/MoonReal

📹𝗠𝘆 𝗘𝗾𝘂𝗶𝗽𝗺𝗲𝗻𝘁:
► Microphone: https://www.amazon.co.uk/gp/product/B07DV2WK77/ref=as_li_tl?ie=UTF8&camp=1634&creative=6738&creativeASIN=B07DV2WK77&linkCode=as2&tag=moonreal-21&linkId=1e984828cb3122716d17530c662a0776

💊* Ultimate Blackpill on China*:
►https://www.amazon.co.uk/gp/product/0099507374/ref=as_li_tl?ie=UTF8&camp=1634&creative=6738&creativeASIN=0099507374&linkCode=as2&tag=moonreal-21&linkId=296f051e6483a68d0d1fff2e5e074a86

🎶 Music:
►Epidemic Sounds - https://www.epidemicsound.com/referral/w1vpsh/

*These are affiliate links

