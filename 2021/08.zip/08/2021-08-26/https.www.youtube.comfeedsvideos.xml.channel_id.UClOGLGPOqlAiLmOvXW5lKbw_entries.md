# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## RUINER Review
 - [https://www.youtube.com/watch?v=fXSVZDovisE](https://www.youtube.com/watch?v=fXSVZDovisE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2021-08-26 00:00:00+00:00

RUINER is a stylish fast-paced cyberpunk action game probably inspired by Ghost in the Shell and Drive. It's very red. Also it's not Hotline Miami, stop it.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/mandaloregaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
01:04 - Visuals
02:58 - Music & Sound Design
04:38 - Gameplay Mechanics
11:24 - Story (SPOILERS)
14:47 - Conclusions
15:38 - Credits
16:54 - The Loading Hint Was Real
#RUINER #RUINERPC #RUINERGameplay #RUINERReview #DevolverDigital #RUINERGame

