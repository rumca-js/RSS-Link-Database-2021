# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## An honest conversation with Larry Sharpe; Andrew Cuomo's challenger from 2018 race
 - [https://www.youtube.com/watch?v=HhqTxlxOQBM](https://www.youtube.com/watch?v=HhqTxlxOQBM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.youtube.com/channel/UCp2EegvSGEsgc-diPwc0ZHQ
https://larrysharpe.com/
https://twitter.com/LarrySharpe

Here we'll have a conversation with Larry Sharpe, the 2018 candidate for Governor of NY State that ran against Andrew Cuomo.

