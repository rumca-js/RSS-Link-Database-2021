# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Foldables outsell other Samsung flagships
 - [https://www.youtube.com/watch?v=cc0uOAMTFEs](https://www.youtube.com/watch?v=cc0uOAMTFEs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-08-27 00:00:00+00:00

Sponsored by Backblaze. Start backing up your computers and try them free for 15 days, no credit cards required: https://backblaze.com/tfc

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week, Samsung's foldables seem to be doing way better than expected, even outselling the Note and S series, Xiaomi announced their stellar Q2 earnings and Tesla announced a new machine learning chip, the Dojo D1.

Episode 60

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:38 Release Monitor
1:50 Samsung Foldable sales
3:43 Xiaomi earnings
4:43 Tesla Dojo D1 chip

