# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## NEW OPEN WORLD GAME ASTOUNDS, ELDEN RING'S MASSIVE INFO DROP & MORE
 - [https://www.youtube.com/watch?v=TQpr4Gkh68Y](https://www.youtube.com/watch?v=TQpr4Gkh68Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-27 00:00:00+00:00

Thanks to Vessi for sponsoring. Click https://vessi.com/gameranx and use my code GAMERANX to get $25 off of your Vessi shoes if you miss the sale! Free shipping to CA, US, AUS, NZ, JP, TW, KR, SGP

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

MORE Gamescom INFO 
https://youtu.be/U2QC6pJKB-o




 ~~~~STORIES~~~~


Elden Ring info blowout:

https://www.eurogamer.net/articles/2021-08-26-elden-ring
https://www.gameinformer.com/preview/2021/08/27/elden-ring-features-a-map-and-fast-travel-from-almost-anywhere
https://www.ign.com/articles/elden-ring-in-game-text-miyazaki-george-martin

New screenshots:
https://twitter.com/geoffkeighley/status/1431240090475327490?s=21

DokeV
https://youtu.be/FaRbQHlegaM

MORE Gamescom INFO 
https://youtu.be/U2QC6pJKB-o

Horizon Forbidden West Feb 18 2022(PS5 update)
https://gamerant.com/horizon-forbidden-west-release-date-delay-zero-dawn-ps5-update/


Halo Infinite December 8 2021
https://www.gamespot.com/articles/halo-infinite-release-date-is-december-8-for-campaign-and-multiplayer/1100-6495546/

SAINTS ROW
https://youtu.be/iDr4l1DdRCU

Sifu 
https://youtu.be/bC9w47FIkes

Midnight Fight Express
https://youtu.be/6OCsN9Z3JSg

Blasphemous 2
https://wccftech.com/blasphemous-sequel-announced-to-be-released-in-2023/

Midnight Suns
https://www.theverge.com/2021/8/25/22641590/midnight-suns-marvel-tactics-rpg-xcom-firaxis-trailer-release-date-gamescom



Fake Mando game looks cool
https://youtu.be/tlVs43yeAsY

Metroid Dread trailer
https://youtu.be/V4p2C7YAEbA

Catdog
https://www.destructoid.com/april-oneil-catdog-nickelodeon-all-star-brawl-trailer-gamescom/?utm_source=rss&utm_medium=rss&utm_campaign=april-oneil-catdog-nickelodeon-all-star-brawl-trailer-gamescom&fbclid=IwAR154228UF7UA0c_N78xMdfnkBfqXnSk9Y_BJmb6w4BRg-F7U2u__4e4kUE


No more No More Heroes
https://twitter.com/nmh3_ghm/status/1431216210381705216?s=20

## Top 10 NEW Games of Gamescom 2021
 - [https://www.youtube.com/watch?v=U2QC6pJKB-o](https://www.youtube.com/watch?v=U2QC6pJKB-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-26 00:00:00+00:00

Gamescom 2021 dropped a ton of surprising new game announcements and release dates. Here are the revealed games we're looking forward to the most.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1



10- Marvel Midnight Suns

Platform : Switch PS4 PS5 PC Xbox One XSX|S

Release Date : March 2022



9- Into the Pit

Platform : PC Xbox One XSX|S

Release Date : October 19, 2021



8- Park Beyond

Platform : PC PS5 XSX|S

Release Date : 2022



7- Death Cathedral

Platform : PC CONSOLES[TBA]

Release Date : TBA



6- Wasteland 3: Cult of the Holy Detonation

Platform : PC PS4 Xbox One

Release Date : October 5, 2021 



5- Cult of the Lamb

Platform : PC Consoles[TBA]

Release Date : 2022



4- Dream Cycle

Platform : PC

Release Date : September 7, 2021 (Early access) 



3-  Stray Blade
Platform : PC PS5 XBOX SERIES X/S
Release Date : 2022



2- UFL

Platform : TBA

Release Date : TBA



1- Saints Row Reboot

Platform : PS4 PS5 Xbox One XSX|S PC

Release Date : Feb 2022



BONUS



Valheim: Hearth & Home

Platform : PC

Release Date : September 16, 2021 


Monster Rancher 1 & 2 DX

Platform : PC iOS SWITCH

Release Date : 2022


Blasphemous 2

Platform : PC, Switch, Consoles

Release Date : 2023


0:00 INTRO
0:21 Marvel Midnight Suns
1:30 Into the Pit
2:11 Park Beyond
2:59 Death Cathedral
3:46 Wasteland 3: Cult of the Holy Detonation
4:25 Cult of the Lamb
5:06 Dream Cycle
5:43 Stray Blade
7:00 UFL
7:54 Saints Row REBOOT
9:07 BONUS

