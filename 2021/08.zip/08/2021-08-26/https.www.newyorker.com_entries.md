## The Thing About Homophobia | The New Yorker
 - [https://www.newyorker.com/culture/personal-history/the-thing-about-homophobia](https://www.newyorker.com/culture/personal-history/the-thing-about-homophobia)
 - RSS feed: https://www.newyorker.com
 - date published: 2021-08-26 18:15:10.372953+00:00

We’re baffled by the ghoulishness of it, and by its startling predictability. We also have to live with its consequences.

