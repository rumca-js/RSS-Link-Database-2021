# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## YOU CAN INSTALL WINDOWS 11!! - WAN Show August 27, 2021
 - [https://www.youtube.com/watch?v=1w3biMwl9m4](https://www.youtube.com/watch?v=1w3biMwl9m4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-27 00:00:00+00:00

Learn PDFelement to edit pdf: https://bit.ly/3j570LL
Get 50% off: https://bit.ly/2XFveny
OCR PDF: https://bit.ly/3sCOxJE

Thanks to Secret Lab for sponsoring today's WAN Show! Check them out at https://lmg.gg/SecretLabWAN

Check out what’s on sale on Green Man Gaming at https://lmg.gg/GMGWAN

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/YOU-CAN-INSTALL-WINDOWS-11-----WAN-Show-August-27--2021-e16lo8m

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (courtesy of NoKi1119)
[0:00] Chapters.
[1:14] Intro.
[1:51] Topic #1: Windows 11 system requirements.
   3:14 Compatible CPUs.
    5:54 Reasoning behind the restrictions.
    7:48 Restrictions do NOT apply to clean install.
    10:24 No performance gain in gaming.
    12:10 Talking about the OEM licenses.
[15:42] Topic #2: Samsung & WD swapping SSD components.
    17:00 WD's NAND swap on SN550.
    18:03 Explaining SLC cache and performance.
    21:06 Discussing WD's NAS controversy.
    24:17 Samsung's NAND swap on 970 Evo Plus.
[31:22] Sponsors.
    31:37 Green Man Gaming games.
    32:29 PDFelement editor.
    33:05 Secret Lab chairs.
[35:22] LTTstore new merch.
[36:52] Topic #3: OnlyFans reverts content ban & policies.
[46:05] Topic #4: TSMC raising prices due to shortage.
[51:38] Topic #5: Apple settling developer lawsuit.
    52:59 Summarizing the lawsuit.
[1:00:44] Topic #6: Samsung disables Z Fold 3 cameras.
[1:02:54] Superchats.
[1:09:03] Wrapping up.
[1:09:20] Outro.

## Should gamers stick to Windows 10?
 - [https://www.youtube.com/watch?v=21jH39rlvDA](https://www.youtube.com/watch?v=21jH39rlvDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-26 00:00:00+00:00

Use code LINUS to get 70% off a 2-year Nordpass Premium plan with four months FREE at https://www.nordpass.com/linus

http://amdgameeveryday.com/

Windows 11 is fast approaching, but while Microsoft promises big improvements, is it really going to be a boon to gamers, or is it just going to be a side-grade with a new skin?


Buy a GeForce GTX 1060: https://geni.us/4Zsv

Buy a GeForce RTX 3080: https://geni.us/je2M4u

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1368309-should-gamers-stick-to-windows-10/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:04 Setting up
1:29 RTX 3080 gaming results (CPU bottleneck)
2:10 WHAT IS GOING ON???
4:10 GTX 1060 gaming results (GPU bottleneck)
4:56 The one advantage of Windows 11 (maybe)
6:47 DirectStorage could be faster maybe
8:08 Conclusion(?)

