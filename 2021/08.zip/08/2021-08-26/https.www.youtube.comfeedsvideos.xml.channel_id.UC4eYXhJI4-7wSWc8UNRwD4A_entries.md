# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Tiny Desk Contest Top Shelf: Episode 6 with Linda Diaz
 - [https://www.youtube.com/watch?v=DBQNfxcZzeo](https://www.youtube.com/watch?v=DBQNfxcZzeo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-08-26 00:00:00+00:00

NPR Music received thousands of submissions to this year's Tiny Desk Contest, our annual search for the next great undiscovered artist to play a Tiny Desk concert. Before we announce this year's winner, this year's Contest judges are sharing their favorite entries in our weekly Tiny Desk Contest Top Shelf livestream series.

Episode 6 was hosted by Tiny Desk creator Bob Boilen and 2020 Contest winner Linda Diaz.

Featured entries:
"Riightway" by Mamii
"Still Life" by Alisa Amador
"La Caliente" by Yosmel Montejo
"Superego" by Allison Mahal
"Bloodlines" y Lilith Ai

Learn more about the Tiny Desk Contest: https://npr.org/tinydeskcontest.

#tinydesk #tinydeskcontest #tinydeskcontesttopshelf

