# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Słuchawki, które NAPRAWDĘ wyciszają otoczenie i całkiem śmieszny gimbal. Elevoc, PowerVision S1
 - [https://www.youtube.com/watch?v=QLJjogFXIKY](https://www.youtube.com/watch?v=QLJjogFXIKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-08-26 00:00:00+00:00

Słuchawki wyciszające otoczenie ELEVOC: https://bit.ly/3yhDyGJ
Gimbal PowerVision S1: https://bit.ly/3Bb9VsD

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Gimbal PowerVision S1- zapowiedź
00:26 Słuchawki do gadania – Elevoc
01:07 Dźwięk
01:35 Test wyciszania otoczenia – Elevoc
02:21 Test wyciszania otoczenia – AirPods Pro
02:45 Cena
02:50 Bateria
02:58 Wymienne gumki
03:16 Gimbal i etui na smartfona – funkcje i możliwości
04:53 Sterowanie – funkcja Power Follow
06:03 Cena i zawartość zestawu
06:33 Dobra rada w sprawie zakupu gimbala
07:06 YouTube Shorts i zapowiedzi kolejnych recenzji
08:14 „Gorsze” pożegnanie?

