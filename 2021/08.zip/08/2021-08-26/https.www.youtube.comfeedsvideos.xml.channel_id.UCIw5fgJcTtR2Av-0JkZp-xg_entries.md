# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "I Got Family" (Full Song)
 - [https://www.youtube.com/watch?v=1edcVg2AYbw](https://www.youtube.com/watch?v=1edcVg2AYbw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-08-27 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Watch the making-of: https://youtu.be/NVFy25zaX6I

If you would like to use this song in your videos, read the license below:
Licensed under Creative Commons Attribution-NonCommercial-ShareAlike
https://creativecommons.org/licenses/by-nc-sa/4.0/

