# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How Anthony Bourdain Dealt with Fame
 - [https://www.youtube.com/watch?v=wQUkBh9NpYY](https://www.youtube.com/watch?v=wQUkBh9NpYY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-26 00:00:00+00:00

Taken from JRE #1702 w/Laurie Woolever:
https://open.spotify.com/episode/6NLVspKgSTLlMCDcFW5NX1?si=Z8N1Ti3eQpST2BxKS2v0qA&dl_branch=1

## Laurie Woolever Remembers Anthony Bourdain
 - [https://www.youtube.com/watch?v=GZPNw_QsYLs](https://www.youtube.com/watch?v=GZPNw_QsYLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-26 00:00:00+00:00

Taken from JRE #1702 w/Laurie Woolever:
https://open.spotify.com/episode/6NLVspKgSTLlMCDcFW5NX1?si=Z8N1Ti3eQpST2BxKS2v0qA&dl_branch=1

