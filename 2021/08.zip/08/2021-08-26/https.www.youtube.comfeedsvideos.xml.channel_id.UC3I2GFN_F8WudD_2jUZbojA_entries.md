# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Cosmic Collective - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=RXBBRUBh8iE](https://www.youtube.com/watch?v=RXBBRUBh8iE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-27 00:00:00+00:00

http://KEXP.ORG presents Cosmic Collective sharing a live performance recorded exclusively for KEXP and talking to Lace Cadence, host of Overnight Afrobeats. Recorded August 12, 2021.

Songs:
Transcendent Love
Friends With Benefits Don't Work Out
Time Socks
Them Changes (Thundercat cover)
Gotta Get Out Of Here

Session mixed and mastered by Jon Estes

Nikki Elias - keys/vox/lyrics/composer
Tyler Enslow - bass/composer/recording engineer/video production
Brad Covington - drums

https://cosmiccollectivemusic.com
http://kexp.org

