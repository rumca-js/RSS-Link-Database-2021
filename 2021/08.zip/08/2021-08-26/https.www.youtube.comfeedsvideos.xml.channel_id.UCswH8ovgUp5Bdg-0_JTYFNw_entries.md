# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Tesla Bot: Elon Musk’s AI APOCALYPSE?!!
 - [https://www.youtube.com/watch?v=Vkt3-PVoXco](https://www.youtube.com/watch?v=Vkt3-PVoXco)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-27 00:00:00+00:00

Elon Musk has unveiled a humanoid robot called the Tesla Bot that runs on the same AI used by Tesla's fleet of autonomous vehicles. But are AI robots like Boston Dynamics' and Tesla's here to help us or replace us? 
#tesla #ElonMusk #TeslaBot #robot #AI 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## Mind Control Expert: You Have Been TRICKED Into Your Tribal Beliefs!!!
 - [https://www.youtube.com/watch?v=XDYLInUgbBg](https://www.youtube.com/watch?v=XDYLInUgbBg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-08-26 00:00:00+00:00

In this interview, I speak with Derren Brown (@OfficialDerrenBrown) about how you are just a product of your environment (he talks about a Jonathan Haidt idea of left wing + right wing people changing their views based on their environment). What do you think about this? Have you watched the full interview with Derren I had on my Podcast "Under the Skin"? I highly suggest you watch the full interview here:

https://youtu.be/5E26ztUXkaE

This is a short excerpt from my podcast "Under the Skin". Click below to listen to my luminary original podcast and hear from guests including Derren Brown, Jordan Peterson, Edward Snowden, Jonathan Haidt, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.

🎙️ Subscribe to Luminary at http://apple.co/russell 🎙️

Watch the #UnderTheSkin Youtube Playlist:

https://youtube.com/playlist?list=PL5BY9veyhGt7eapYiWXyxGuSxTcysPpJ7

______________________________________________________________
Elites are taking over! Our only hope is to form our own. To learn more, join my cartel below and get weekly bulletins too incendiary for anything but your private inbox.

*not a euphemism

https://www.russellbrand.com/join

Are you interested in more video like this? I release videos EVERYDAY on Youtube (admit it, you enjoyed watching this one...). 

Click the link below to subscribe below to my Youtube Channel - don't forget to turn on that notification bell 🔔

http://www.youtube.com/c/RussellBrand?sub_confirmation=1

______________________________________________________________
SEE ME LIVE! Check out my live events and buy tickets here:

📅 https://www.russellbrand.com/live-dates/ 

🎧 My Audible Original, ‘Revelation', is out NOW!

US: http://adbl.co/revelation 🇺🇸
UK: http://adbl.co/revelationuk 🇬🇧
AU: http://adbl.co/revelationau 🇦🇺
CA: http://adbl.co/revelationca 🇨🇦

For meditation and breath work, subscribe to my side-channel:

http://www.youtube.com/c/AwakeningWithRussell?sub_confirmation=1

______________________________________________________________
Follow me here:

Instagram:
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Youtube:
http://www.youtube.com/c/RussellBrand?sub_confirmation=1

Facebook:
https://www.facebook.com/RussellBrand/

My Website:
https://www.russellbrand.com/

Join the Community:
https://www.russellbrand.com/join

#DerrenBrown #RussellBrand #UnderTheSkin

