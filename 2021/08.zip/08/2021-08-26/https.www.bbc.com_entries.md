## Lisa Shaw: Presenter's death due to complications of Covid vaccine - BBC News
 - [https://www.bbc.com/news/uk-england-tyne-58330796](https://www.bbc.com/news/uk-england-tyne-58330796)
 - RSS feed: https://www.bbc.com
 - date published: 2021-08-26 12:41:47+00:00

Lisa Shaw: Presenter's death due to complications of Covid vaccine - BBC News

