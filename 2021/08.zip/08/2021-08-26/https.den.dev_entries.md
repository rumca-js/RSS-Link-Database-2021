## The Rise Of User-Hostile Software | Den Delimarsky
 - [https://den.dev/blog/user-hostile-software/](https://den.dev/blog/user-hostile-software/)
 - RSS feed: https://den.dev
 - date published: 2021-08-26 18:37:58.227611+00:00

Or why software we get today is not the software we should strive to be getting tomorrow.

