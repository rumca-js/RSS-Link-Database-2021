# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best Tactical Shooters That TRULY TEST Your Patience
 - [https://www.youtube.com/watch?v=5lgtr8Cm0YU](https://www.youtube.com/watch?v=5lgtr8Cm0YU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-17 00:00:00+00:00

Looking for a game with intensity, room for teamwork, and a reliance on precision? We've got you covered with these fun recent tactical games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Insurgency: Sandstorm
Platforms: PS4, Xbox One, PlayStation 5, Xbox Series X and Series S, PC

#9 Tom Clancy's Ghost Recon Wildlands
Platforms: PS4, Xbox One, PlayStation 5, Xbox Series X and Series S, PC

#8 ENLISTED
Platforms: PlayStation 5, Xbox Series X and Series S, PC

#7 Star Wars: Republic Commando
Platforms: PC

#6 Rising Storm 2: Vietnam
Platforms: PC

#5 CS:GO
Platforms: PC, macOS

#4 ARMA 3
Platforms: PC, macOS

#3 Squad
Platforms: PC

#2 Escape from Tarkov
Platforms: PC, macOS

#1 Tom Clancy's Rainbow Six Siege
Platforms: PS4, Xbox One, PlayStation 5, Google Stadia, Xbox Series X and Series S, PC

## 10 Expansions BETTER Than The Main Game
 - [https://www.youtube.com/watch?v=-1KV_vU0ZHk](https://www.youtube.com/watch?v=-1KV_vU0ZHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-16 00:00:00+00:00

Some games are only made even better by their expantions, additions, and DLCs. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

