# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Bad Bad Hats - three songs for The Current (2015; 2018; 2019)
 - [https://www.youtube.com/watch?v=IbMt3eTX8vA](https://www.youtube.com/watch?v=IbMt3eTX8vA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-08-17 00:00:00+00:00

Six years ago this week, Bad Bad Hats performed in The Current studio in support of their first full-length album, "Psychic Reader." Since that time, Bad Bad Hats have performed in The Current studio, at two of The Current's anniversary parties, at Rock the Garden and at The Current's Day Party during SXSW 2019. What's next for Bad Bad Hats? They'll release their next album, "Walkman," on September 17, 2021, on the New Jersey-based label Don Giovanni Records.

Watch three performances by Bad Bad Hats — the first two recorded in The Current studio in 2015 and 2018, and the third recorded at The Current's Day Party during SXSW in Austin, Texas, in 2019.

SONGS PERFORMED
0:00 "Midway" (2015)
3:08 "Write It On Your Heart" (2018)
5:51 "Wide Right" (2019)

PERSONNEL
Kerry Alexander – vocals, guitar
Chris Hoge – guitar
Noah Boswell – bass (2015; 2018)
Cooper Doten – bass (2019)
Arlen Peiffer – drums (2015)
Connor Davison – drums (2018; 2019)

CREDITS
Video & Photo: Nate Ryan; Leah Garaas; Devon Quick; Patrick Galbreath; Helen Teague
Audio: Michael DeMark; Corey Schreppel
Production: David Campbell; Jesse Wiza; Brett Baldwin

FIND MORE:
2015 studio session: https://www.thecurrent.org/feature/2015/08/16/bad-bad-hats-perform-in-the-current-studio
2018 studio session: https://www.thecurrent.org/feature/2018/08/20/bad-bad-hats-perform-in-the-current-studio
2019 Day Party during SXSW:
https://www.thecurrent.org/feature/2019/03/16/watch-bad-bad-hats-perform-at-the-current-day-party-in-austin-texas-sxsw

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#badbadhats #thecurrent

