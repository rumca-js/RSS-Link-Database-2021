## All the Ways Spotify Tracks You—and How to Stop It | WIRED
 - [https://www.wired.com/story/spotify-tracking-how-to-stop-it/](https://www.wired.com/story/spotify-tracking-how-to-stop-it/)
 - RSS feed: https://www.wired.com
 - date published: 2021-08-16 09:56:59.235089+00:00

Whether you're listening to workout music or a "cooking dinner" playlist, the app can show you ads based on your mood and what you're doing right now.

