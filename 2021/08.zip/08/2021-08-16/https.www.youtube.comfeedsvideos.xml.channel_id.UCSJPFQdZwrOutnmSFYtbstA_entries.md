# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Production Hell - Star Trek V: The Final Frontier
 - [https://www.youtube.com/watch?v=opi09hwaYDU](https://www.youtube.com/watch?v=opi09hwaYDU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-08-16 00:00:00+00:00

The movie that almost killed a franchise. Set phasers to drunk and join me as I explore the notoriously troubled production behind the most infamous of Trek movies - The Final Frontier.

