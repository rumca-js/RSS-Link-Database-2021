# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## My Girl | The Temptations | funk cover ft. Casey Abrams
 - [https://www.youtube.com/watch?v=L1xj8Dm7BH4](https://www.youtube.com/watch?v=L1xj8Dm7BH4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-08-16 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of The Temptations' "My Girl" by Scary Pockets & Casey Abrams.

MUSICIAN CREDITS
Lead vocal: Casey Abrams
Drums: Darren King
Bass: Joe Ayoub
Wurlitzer + Prophet: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Alejandro Echevarria
Editor: Adam Kritzberg

Recorded Live at Sunset Sound in Los Angeles, CA.

#ScaryPockets #Funk #MyGirl #TheTemptations #CaseyAbrams

