# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Była lobbystka koncernów farmaceutycznych została szefową Europejskiej Agencji Leków!
 - [https://www.youtube.com/watch?v=L91cQVRi3ng](https://www.youtube.com/watch?v=L91cQVRi3ng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-08-17 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. http://bit.ly/2LC8IEc
2. https://bit.ly/3g7csvK
3. https://bit.ly/3stC3UO
4. https://bit.ly/3AKhCWm
5. https://bit.ly/2VUbCvD
6. https://bit.ly/3ASjyMO
7. https://bit.ly/3gb0Rfn
---------------------------------------------------------------
🎴 Dd kolażu wykorzystano grafikę ze strony / autorstwa:
ema.europa.eu - https://bit.ly/3iRYTSL
---------------------------------------------------------------
💡 Tagi: #EMA #UE
--------------------------------------------------------------

## Izrael wycofuje chargé d'affaires z Polski. Analiza sytuacji
 - [https://www.youtube.com/watch?v=Vm8Ow1bMdNY](https://www.youtube.com/watch?v=Vm8Ow1bMdNY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-08-16 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3g7HweU
2. https://bit.ly/3g7Hxzu
3. https://bit.ly/37PFrj3
4. https://youtu.be/5Wda2sigEEg
5. https://bit.ly/2UnbRhP
6. https://bit.ly/3k3qXlD
7. https://bit.ly/3iQx5xZ
8. https://bit.ly/3yUWhJj
9. https://bit.ly/37QO9Od
10. https://bit.ly/3yW1CjB
11. https://bit.ly/3jY44zU
12. https://bit.ly/3yTZjgP
13. https://bit.ly/3sjh5YA
14. https://bit.ly/2Uo1Hh5
15. https://bit.ly/3ARk3ql
---------------------------------------------------------------
🎴 Dd kolażu wykorzystano grafikę ze strony / autorstwa:
 wikipedia / TheCuriousGnome
https://bit.ly/2VRWXB9
---
ulice-warszawy.pl
https://bit.ly/3iMtZep
---------------------------------------------------------------
💡 Tagi: #polityka #Izrael
--------------------------------------------------------------

