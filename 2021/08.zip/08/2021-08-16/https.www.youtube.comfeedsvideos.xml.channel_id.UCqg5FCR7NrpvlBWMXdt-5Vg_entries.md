# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The First Hour of Your Game Sucks | Slightly Something Else
 - [https://www.youtube.com/watch?v=4pFa4K7NfpI](https://www.youtube.com/watch?v=4pFa4K7NfpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-08-17 00:00:00+00:00

This week on Slightly Something Else, Yahtzee and Jack discuss game openings.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Idris Elba Is The Suicide Squad's Secret Weapon | In The Frame
 - [https://www.youtube.com/watch?v=axQQTclNeaE](https://www.youtube.com/watch?v=axQQTclNeaE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-08-16 00:00:00+00:00

It seems like a safe assertion that Idris Elba is one of the most beloved actors on the planet.

Elba was named the sexiest man alive by People magazine in 2018. Elba remains the favorite to one day play James Bond and is still addressing such speculation at the point where he would be the oldest actor to take up the mantle. Elba is so beloved in his native United Kingdom that television provider Sky has built an almost-decade-long advertising campaign around how cool it would be if Idris Elba were in all television or if he showed up at random strangers’ houses to watch television with them.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

