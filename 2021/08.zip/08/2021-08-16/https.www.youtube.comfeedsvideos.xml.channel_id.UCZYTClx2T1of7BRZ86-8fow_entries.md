# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Real Reason Dogs Kick When You Scratch Them
 - [https://www.youtube.com/watch?v=znPDZfr_pHk](https://www.youtube.com/watch?v=znPDZfr_pHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-08-17 00:00:00+00:00

If you’ve ever been scratching a dog and seen them do the kicky leg thing, it’s truly adorable. But it might not necessarily be a feel-good thing.

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, charles george, Christoph Schwanke, Ash, Silas Emrys, KatieMarie Magnone, Eric Jensen, Adam Brainard, Piya Shedden, Alex Hackman, James Knight, GrowingViolet, Sam Lutfi, Alisa Sherbow, Jason A Saslow, Dr. Melvin Sanicas

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:

https://physoc.onlinelibrary.wiley.com/doi/pdf/10.1113/jphysiol.1906.sp001139
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5867383/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1540657/pdf/jphysiol02560-0045.pdf
https://physoc.onlinelibrary.wiley.com/doi/pdf/10.1113/jphysiol.1906.sp001139 
https://www.popsci.com/article/science/why-does-my-dog-kick-when-i-scratch-his-belly/
https://journals.physiology.org/doi/abs/10.1152/ajplegacy.1931.98.3.368
https://link.springer.com/article/10.1007/BF00606269 
https://science.sciencemag.org/content/209/4462/1261.abstract
https://www.allergyearskincare.com/scabies-mange.pml
https://bvajournals.onlinelibrary.wiley.com/doi/abs/10.1136/vr.148.20.621
https://www.magonlinelibrary.com/doi/abs/10.1111/j.2044-3862.2007.tb00173.x?journalCode=ukvc
http://www.itchnot.com/images/_9_Scabies.pdf
https://bmcvetres.biomedcentral.com/articles/10.1186/s12917-017-1258-2
https://www.psychologytoday.com/us/blog/animal-emotions/201903/being-touched-is-fine-some-dogs-not-others
https://animalwellnessmagazine.com/human-touch-dog/
http://www.animalplanet.com/pets/why-do-dogs-shake-their-legs/ 

Images:
https://www.storyblocks.com/video/stock/a-dog-scratching-his-ear-edmiabkfgijtzqj3e
https://www.istockphoto.com/photo/brown-dog-tick-rhipicephalus-sanguineus-on-white-fur-close-up-of-a-parasite-with-gm1216554688-354785277
https://www.storyblocks.com/video/stock/woman-petting-dog-in-slow-motion-4gxedx6
storyblocks.com/video/stock/girl-scratches-a-small-dog-on-the-grass-a-girl-is-sitting-on-the-grass-and-playing-with-a-small-dog-bbek90kwuzj6e4r37
https://www.storyblocks.com/video/stock/doctor-the-neurologist-examines-the-patient-taps-with-a-hammer-on-the-knee-close-up-s7xjpl-vizjdbimia4
https://www.istockphoto.com/photo/this-sure-feels-good-gm1271641116-374162601
https://commons.wikimedia.org/wiki/File:Scratch_reflex_demonstrated_by_Irish_Wolfhound_mix.webm

## Is Coffee Disappearing... or Will It Just Taste Different?
 - [https://www.youtube.com/watch?v=Ai_uHrQNLtQ](https://www.youtube.com/watch?v=Ai_uHrQNLtQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-08-16 00:00:00+00:00

Many of us rely on a morning cup of coffee, or several morning cups of coffee, to get us going. But climate change has the potential to shift not only where and how we grow coffee, but whether it can be grown at all.

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Chris Peters, Matt Curls, Kevin Bealer, Jeffrey Mckishen, Jacob, Christopher R Boucher, Nazara, charles george, Christoph Schwanke, Ash, Silas Emrys, KatieMarie Magnone, Eric Jensen, Adam Brainard, Piya Shedden, Alex Hackman, James Knight, GrowingViolet, Sam Lutfi, Alisa Sherbow, Jason A Saslow, Dr. Melvin Sanicas

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://advances.sciencemag.org/content/5/1/eaav3473
https://www.nature.com/articles/s41598-021-87647-4#Sec7
https://academicjournals.org/journal/AJAR/article-full-text-pdf/584CE7F60601.pdf
https://onlinelibrary.wiley.com/doi/10.1111/gcb.14341
https://www.sciencedirect.com/science/article/pii/S1573521417300155
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0047981
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7590209/
https://www.researchgate.net/publication/265026454_Coffee_Quality_and_Its_Interactions_with_Environmental_Factors_in_Minas_Gerais_Brazil
https://www.sciencedirect.com/science/article/pii/S030147971831171X
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0024528
https://www.researchgate.net/publication/350980117_Arabica-like_flavour_in_a_heat-tolerant_wild_coffee_species
 https://link.springer.com/article/10.1007/s12571-015-0446-9 
https://www.theatlantic.com/science/archive/2020/09/coffee-rust/616358/
https://www.apsnet.org/edcenter/disandpath/fungalbasidio/pdlessons/Pages/CoffeeRust.aspx
 
Images:
https://www.storyblocks.com/video/stock/afro-american-woman-in-kitchen-enjoying-coffee-in-the-morning-r15qhuxtwkh6w6fa9
https://commons.wikimedia.org/wiki/File:Unroasted_coffee.jpg
https://commons.wikimedia.org/wiki/File:Canephora.jpg
https://www.istockphoto.com/photo/closeup-of-coffee-fruit-in-coffee-farm-and-plantations-in-brazil-gm1250294651-364622890
https://www.istockphoto.com/photo/cef%C3%A9-plantation-in-minas-gerais-gm837859062-136289603
https://www.istockphoto.com/photo/young-african-man-collecting-coffee-cherries-east-africa-gm1269660092-372906810
https://www.istockphoto.com/photo/coffee-plants-in-ethiopia-gm1209684943-350141386
https://www.istockphoto.com/photo/coffee-bushes-gm1196249860-341200521
https://commons.wikimedia.org/wiki/File:Hypothenemus.jpg
https://commons.wikimedia.org/wiki/File:Berry-borer.png
https://commons.wikimedia.org/wiki/File:Hemileia_vastatrix.jpg
https://www.istockphoto.com/photo/dramatic-image-of-coffee-plants-growing-on-the-hillside-in-the-caribbean-mountains-gm1327170607-411610404
https://www.istockphoto.com/photo/group-of-farmers-collecting-coffee-beans-gm538908564-95969441
https://commons.wikimedia.org/wiki/File:Coffea_stenophylla-Jardin_botanique_de_Berlin_(1).jpg
https://www.istockphoto.com/photo/a-hand-pouring-steaming-coffee-in-to-a-cup-on-a-work-desk-when-work-from-home-gm1215931274-354351568

