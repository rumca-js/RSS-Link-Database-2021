# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## If Authoritarians Taught Self Help!
 - [https://www.youtube.com/watch?v=dBVm5XuT78g](https://www.youtube.com/watch?v=dBVm5XuT78g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-08-16 00:00:00+00:00

Grab your Remedy Sleep Mask at https://blublox.com/jp
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

If Authoritarians taught self-help! Imagine if the authoritarians installed their version of Tony Robbins. We’d be empowered to be even more obedient! Self-help that destroys yourself!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

