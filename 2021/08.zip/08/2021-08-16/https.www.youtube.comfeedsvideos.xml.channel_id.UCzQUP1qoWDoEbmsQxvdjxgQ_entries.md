# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Praises Ciryl Gane's Performance Against Derrick Lewis
 - [https://www.youtube.com/watch?v=_HPVZOkxdkk](https://www.youtube.com/watch?v=_HPVZOkxdkk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-17 00:00:00+00:00

Taken from JRE #1696 w/Lex Fridman:
https://open.spotify.com/episode/0DsunsN5MGI0CWwvuaxZdt?si=E_KR9bYZTC2-mIC4H-sFTw&dl_branch=1

## The Taliban Taking Over Afghanistan
 - [https://www.youtube.com/watch?v=3wc23FQZeTE](https://www.youtube.com/watch?v=3wc23FQZeTE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-08-17 00:00:00+00:00

Taken from JRE #1696 w/Lex Fridman:
https://open.spotify.com/episode/0DsunsN5MGI0CWwvuaxZdt?si=E_KR9bYZTC2-mIC4H-sFTw&dl_branch=1

