# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Johnny Depp says Hollywood is boycotting him
 - [https://www.cnn.com/2021/08/16/entertainment/johnny-depp-hollywood-boycott-trnd/index.html](https://www.cnn.com/2021/08/16/entertainment/johnny-depp-hollywood-boycott-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 23:51:13+00:00

According to Johnny Depp, the past five years have been "surreal" for him.

## Fareed Zakaria: This withdrawal is a stain on Biden's foreign policy
 - [https://www.cnn.com/videos/world/2021/08/16/fareed-zakaria-afghanistan-biden-acfc-sot-vpx.cnn](https://www.cnn.com/videos/world/2021/08/16/fareed-zakaria-afghanistan-biden-acfc-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 23:41:43+00:00

CNN's Anderson Cooper talks with Fareed Zakaria about the crisis unfolding in Afghanistan and what this means for President Joe Biden's foreign policy. Watch "Full Circle" Monday, Wednesday and Friday 6p E.T.

## Investigation underway after paratrooper found dead in his Fort Bragg barracks room
 - [https://www.cnn.com/2021/08/16/politics/fort-bragg-investigation/index.html](https://www.cnn.com/2021/08/16/politics/fort-bragg-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 23:36:40+00:00

An investigation is underway after an 82nd Airborne Division paratrooper was found unresponsive in his barracks room on Fort Bragg and pronounced dead on Friday, a release from the 82nd Airborne Division public affairs office said.

## Afghan reporter's emotional question during Pentagon briefing
 - [https://www.cnn.com/videos/world/2021/08/16/nazira-karimi-afghan-journalist-questions-john-kirby-pentagon-briefing-tl-vpx.cnn](https://www.cnn.com/videos/world/2021/08/16/nazira-karimi-afghan-journalist-questions-john-kirby-pentagon-briefing-tl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 21:55:29+00:00

Afghan reporter Nazira Karimi makes an emotional plea to Pentagon spokesman John Kirby at the Pentagon briefing after the Taliban's taking of Kabul.

## First-ever water cuts declared for Colorado River in historic drought
 - [https://www.cnn.com/2021/08/16/us/lake-mead-colorado-river-water-shortage/index.html](https://www.cnn.com/2021/08/16/us/lake-mead-colorado-river-water-shortage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 21:47:52+00:00

The federal government on Monday declared a water shortage on the Colorado River for the first time, triggering mandatory water consumption cuts for states in the Southwest, as climate change-fueled drought pushes the level in Lake Mead to unprecedented lows.

## 'Why do they have to cover their face?': Clarissa Ward presses Taliban commander on Afghan women's rights
 - [https://www.cnn.com/videos/world/2021/08/16/taliban-afghanistan-take-over-ward-pkg-newday-vpx.cnn](https://www.cnn.com/videos/world/2021/08/16/taliban-afghanistan-take-over-ward-pkg-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 20:53:22+00:00

CNN's Clarissa Ward describes life inside Afghanistan's capital Kabul as Taliban fighters swarm the streets after entering the city's presidential palace after former President Ashraf Ghani fled the country.

## Canadian luxury scenic train line debuts its first US route
 - [https://www.cnn.com/travel/article/rocky-mountaineer-train-route-united-states/index.html](https://www.cnn.com/travel/article/rocky-mountaineer-train-route-united-states/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 20:15:33+00:00

The United States' railroad system is getting a boost from its northern neighbor.

## Excerpts from new book detail Trump's final days in office
 - [https://www.cnn.com/videos/media/2021/08/16/new-book-peril-trump-biden-gangel-nr-vpx.cnn](https://www.cnn.com/videos/media/2021/08/16/new-book-peril-trump-biden-gangel-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 19:40:26+00:00

CNN's Jamie Gangel previews a new book from journalists Bob Woodward and Robert Costa detailing the final days of Trump's presidency and the transition to the Biden administration.

## Tesla is under investigation because its cars keep hitting emergency vehicles
 - [https://www.cnn.com/2021/08/16/business/tesla-autopilot-federal-safety-probe/index.html](https://www.cnn.com/2021/08/16/business/tesla-autopilot-federal-safety-probe/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 17:01:56+00:00

Federal safety regulators are investigating at least 11 accidents involving Tesla cars using Autopilot or other self-driving features that crashed into emergency vehicles when coming upon the scene of an earlier crash.

## Travis Barker, Blink-182 drummer, takes first flight since deadly 2008 plane crash
 - [https://www.cnn.com/2021/08/16/entertainment/travis-barker-flies-first-time-intl-scli/index.html](https://www.cnn.com/2021/08/16/entertainment/travis-barker-flies-first-time-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 16:50:37+00:00

Travis Barker has flown on a plane for the first time since he survived a deadly plane crash 13 years ago, TMZ reports.

## Meet the Nigerian artist illustrating the human experience with a ballpoint pen
 - [https://www.cnn.com/style/article/jacqueline-suowari-ballpoint-artist-nigeria-spc-intl/index.html](https://www.cnn.com/style/article/jacqueline-suowari-ballpoint-artist-nigeria-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 16:16:32+00:00

From a distance, Jacqueline Suowari's larger-than-life portraits look like monochromatic photographs overlaid with colorful graphics. Upon closer inspection, you see these dramatic images are the culmination of thousands of tiny lines made using a simple ballpoint pen.

## US legend Carli Lloyd to retire from soccer
 - [https://www.cnn.com/2021/08/16/football/carli-lloyd-retirement-uswnt-spt-intl/index.html](https://www.cnn.com/2021/08/16/football/carli-lloyd-retirement-uswnt-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 16:16:21+00:00

Carli Lloyd, who is one of the most successful players in the history of the United States Women's National Team (USWNT), is to retire from professional football.

## Being a better listener for your loved ones might protect their brain health, study finds
 - [https://www.cnn.com/2021/08/16/health/good-listener-benefits-brain-health-wellness/index.html](https://www.cnn.com/2021/08/16/health/good-listener-benefits-brain-health-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 15:51:15+00:00

Having good listeners in your life might help your brain be more resilient in the face of any future age- or disease-related changes, a new study has found.

## Tropical storm threatens further devastation in Haiti after quake kills over 1,400
 - [https://www.cnn.com/collections/intl-haiti-081521/](https://www.cnn.com/collections/intl-haiti-081521/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 15:01:45+00:00



## Ripples in Saturn's rings reveal planet's 'fuzzy' core
 - [https://www.cnn.com/2021/08/16/world/saturn-rings-fuzzy-core-scn/index.html](https://www.cnn.com/2021/08/16/world/saturn-rings-fuzzy-core-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 15:01:22+00:00

A rippling detected within the rings around Saturn has helped scientists determine that the giant planet may be "fuzzy" at its core.

## Second 'Chibok girl' freed in a week seven years after abduction
 - [https://www.cnn.com/2021/08/16/africa/chibok-girl-freed-intl/index.html](https://www.cnn.com/2021/08/16/africa/chibok-girl-freed-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 13:45:01+00:00

A second young woman abducted seven years ago from the town of Chibok by Boko Haram militants was freed this week, Borno state's governor has said.

## Roger Federer will miss US Open after announcing further knee surgery
 - [https://www.cnn.com/2021/08/16/tennis/roger-federer-us-open-knee-injury-spt-intl/index.html](https://www.cnn.com/2021/08/16/tennis/roger-federer-us-open-knee-injury-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 13:36:14+00:00

Tennis great Roger Federer will miss the US Open later this month and possibly the rest of the season, after announcing that he needs another knee surgery which will sideline him for "many months."

## The Cure's Simon Gallup 'fed up of betrayal' and leaving band after 40 years
 - [https://www.cnn.com/2021/08/16/entertainment/simon-gallup-cure-trnd/index.html](https://www.cnn.com/2021/08/16/entertainment/simon-gallup-cure-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 12:58:52+00:00

"Boys Don't Cry," but in the case of Simon Gallup, they do post their feelings on Facebook and offer their resignation publicly.

## Zambia's opposition leader wins landslide election as young people turnout in huge numbers
 - [https://www.cnn.com/2021/08/16/africa/zambia-election-president-hichilema/index.html](https://www.cnn.com/2021/08/16/africa/zambia-election-president-hichilema/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 11:37:53+00:00

Opposition leader Hakainde Hichilema has won a landslide victory over incumbent Edgar Lungu in Zambia's presidential election, results showed on Monday.

## New clue to human evolution's biggest mystery emerges in Philippines
 - [https://www.cnn.com/2021/08/16/world/denisovan-dna-philippines-scn/index.html](https://www.cnn.com/2021/08/16/world/denisovan-dna-philippines-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 11:17:34+00:00

The only definitive fossil evidence that points to the existence of Denisovans -- an enigmatic group of early humans first identified in 2010 -- comes from five bones from the Denisova cave in the foothills of Siberia's Altai mountains.

## India's Modi promises to spend over $1 trillion on infrastructure -- once again
 - [https://www.cnn.com/2021/08/16/business-india/modi-india-infrastructure-hnk-intl/index.html](https://www.cnn.com/2021/08/16/business-india/modi-india-infrastructure-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 10:57:56+00:00

Indian Prime Minister Narendra Modi has renewed a pledge to spend more than $1 trillion on infrastructure to create jobs for hundreds of thousands of young Indians and boost the economy.

## BMX biker suffered brain shearing and bleeding after crash
 - [https://www.cnn.com/2021/08/16/sport/connor-fields-update-instagram-spt-intl/index.html](https://www.cnn.com/2021/08/16/sport/connor-fields-update-instagram-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 10:33:17+00:00

American BMX rider Connor Fields says he is "progressing nicely" after he suffered brain shearing and bleeding, intubation, a broken rib and a collapsed lung following his crash at the Tokyo 2020 Olympics.

## Sex ed conversations you need to have with your tween or teen
 - [https://www.cnn.com/2021/08/16/health/sex-ed-teen-conversation-wellness/index.html](https://www.cnn.com/2021/08/16/health/sex-ed-teen-conversation-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 10:30:10+00:00

My mom and I first talked about menstrual cycles last year, at ages 83 and 46, respectively. While sometimes the phrase "better late than never" applies, in this case, it does not.

## Former Rugby World Cup star and family attacked in home
 - [https://www.cnn.com/2021/08/16/sport/toutai-kefu-home-attack-spt-intl/index.html](https://www.cnn.com/2021/08/16/sport/toutai-kefu-home-attack-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 10:27:51+00:00

Former Australian rugby player and Rugby World Cup winner Toutai Kefu and his family have been injured after being attacked in their home in Brisbane, Australia.

## The Delta variant is just one of the clouds hanging over China's economy
 - [https://www.cnn.com/2021/08/16/economy/delta-variant-china-economy-intl-hnk/index.html](https://www.cnn.com/2021/08/16/economy/delta-variant-china-economy-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 09:05:14+00:00

China's economic recovery is slowing down — and it's not just the spread of the Delta variant of Covid-19 that has economists and government officials on alert.

## Analysis: Chinese and Russian militaries link up, but both sides have differing objectives
 - [https://www.cnn.com/2021/08/16/asia/chinese-russian-military-ties-intl-hnk-ml/index.html](https://www.cnn.com/2021/08/16/asia/chinese-russian-military-ties-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 08:36:04+00:00

• New intel reports indicate fresh efforts by Russia to interfere in 2022 election
• China appears to be expanding its nuclear capabilities, US researchers say

## For China, the return of the Taliban poses more risk than it does opportunity
 - [https://www.cnn.com/2021/08/16/china/china-afghanistan-taliban-mic-intl-hnk/index.html](https://www.cnn.com/2021/08/16/china/china-afghanistan-taliban-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 08:33:30+00:00

As China watches the chaotic scenes unfold in the Afghan capital Kabul, it is likely seeing more imminent risk than opportunity.

## Malaysia Prime Minister resigns after losing majority
 - [https://www.cnn.com/2021/08/16/world/malaysia-prime-minister-resigns-intl-hnk/index.html](https://www.cnn.com/2021/08/16/world/malaysia-prime-minister-resigns-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 06:13:45+00:00

Malaysia's cabinet led by Prime Minister Muhyiddin Yassin has tendered its resignation to the king, science minister Khairy Jamaluddin said on Monday, after months of political turmoil that resulted in a loss of the premier's majority.

## Biden's botched Afghan exit a disaster at home and abroad long in the making
 - [https://www.cnn.com/2021/08/16/politics/afghanistan-joe-biden-donald-trump-kabul-politics/index.html](https://www.cnn.com/2021/08/16/politics/afghanistan-joe-biden-donald-trump-kabul-politics/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 05:02:27+00:00

The debacle of the US defeat and chaotic retreat in Afghanistan is a political disaster for Joe Biden, whose failure to orchestrate an urgent and orderly exit will further rock a presidency plagued by crises and stain his legacy.

## Taliban take control of Kabul's presidential palace
 - [https://www.cnn.com/world/live-news/afghanistan-taliban-us-news-08-16-21/index.html](https://www.cnn.com/world/live-news/afghanistan-taliban-us-news-08-16-21/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 04:53:58+00:00



## Why your old video games may be worth millions
 - [https://www.cnn.com/style/article/most-expensive-video-games/index.html](https://www.cnn.com/style/article/most-expensive-video-games/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 03:44:42+00:00

When Roberto Dillon began collecting retro video games more than 12 years ago, he scoured auction sites and connected with niche groups of hobbyists to amass a personal archive that is now hundreds of titles strong. But at the time, there was a consensus among collectors that buying old games was "a sort of fad," said the academic and game developer.

## Chaos is unfolding in Afghanistan. Here's what you need to know
 - [https://www.cnn.com/2021/08/15/politics/taliban-kabul-afghanistan-explainer/index.html](https://www.cnn.com/2021/08/15/politics/taliban-kabul-afghanistan-explainer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 03:25:28+00:00

The Taliban edged closer to solidifying control of Afghanistan on Sunday, including entering the presidential palace in Kabul hours after former President Ashraf Ghani fled the country.

## Tourism Australia's new campaign isn't about travel -- it's about vaccination
 - [https://www.cnn.com/travel/article/tourism-australia-vaccine-campaign-intl-hnk/index.html](https://www.cnn.com/travel/article/tourism-australia-vaccine-campaign-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 03:12:46+00:00

The midst of lockdowns and border closures may not seem like the most logical time to launch a tourism campaign.

## The FPV drone pilots taking cameras where humans can't go
 - [https://www.cnn.com/travel/article/fpv-drone-videography-spc-intl-hk/index.html](https://www.cnn.com/travel/article/fpv-drone-videography-spc-intl-hk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 02:58:35+00:00

Standing deep in the jungle of Venezuela, Ellis van Jason was surrounded by insects. "These ants went into my ear, into my nose, like even inside the goggles," he tells CNN.

## Drone pilot captures stunning images of world's tallest waterfall
 - [https://www.cnn.com/videos/tv/2021/08/13/fpv-drone-volcano-waterfall-hnk-spc-intl.cnn](https://www.cnn.com/videos/tv/2021/08/13/fpv-drone-volcano-waterfall-hnk-spc-intl.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 02:54:46+00:00

Ellis van Jason and Julio Carvajal share a passion: flying cinematic first-person view (FPV) drones. Capturing nature from a different perspective, the craft combines creativity, technical know-how and adrenaline to form the ultimate visual experience.

## Chaos is unfolding in Afghanistan. Here's what you need to know
 - [https://www.cnn.com/collections/intl-afghanistan-08162021/](https://www.cnn.com/collections/intl-afghanistan-08162021/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 02:16:49+00:00



## More than 1,200 killed and thousands injured in Haiti earthquake
 - [https://www.cnn.com/2021/08/15/world/haiti-earthquake-news-sunday/index.html](https://www.cnn.com/2021/08/15/world/haiti-earthquake-news-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 02:07:19+00:00



## Girl, 7, killed in Chicago weekend of gun violence
 - [https://www.cnn.com/2021/08/15/us/il-chicago-weekend-gun-violence/index.html](https://www.cnn.com/2021/08/15/us/il-chicago-weekend-gun-violence/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 01:57:41+00:00

An unknown suspect shot two young girls, killing one and leaving the other "fighting for her life," as they sat in a parked vehicle on a Chicago street Sunday, according to police.

## At least 20 people killed when fuel tank explodes in Lebanon
 - [https://www.cnn.com/2021/08/15/middleeast/lebanon-explosion-intl-hnk/index.html](https://www.cnn.com/2021/08/15/middleeast/lebanon-explosion-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-08-16 00:01:13+00:00

At least 20 people were killed and 79 injured in a fuel tank explosion in the Akkar region in northern Lebanon, the Lebanese Red Cross said on its Twitter account early on Sunday.

