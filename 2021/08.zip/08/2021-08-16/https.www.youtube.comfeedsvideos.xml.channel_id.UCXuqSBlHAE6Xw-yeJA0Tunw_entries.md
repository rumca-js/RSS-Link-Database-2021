# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Mom's Basement Upgrade - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=6oIlGhTgaKo](https://www.youtube.com/watch?v=6oIlGhTgaKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-17 00:00:00+00:00

Thanks to Intel for sponsoring this series! Buy an Intel Core i9-11900k CPU
On Amazon (PAID LINK): https://geni.us/Ruxpt
On Best Buy (PAID LINK): https://geni.us/5UPU
On Newegg (PAID LINK): https://geni.us/MH6yAl

Buy EVGA FTW3 RTX 3080
On Amazon (PAID LINK): https://geni.us/2m1BBk
On Best Buy (PAID LINK): https://geni.us/dZEo7S

Buy Seasonic FOCUS GX-850 PSU
On Amazon (PAID LINK): https://geni.us/EiUc8
On Best Buy (PAID LINK): https://geni.us/5g1Z0
On Newegg (PAID LINK): https://geni.us/xjsIa

Buy ASUS TUF Gaming Z590-Plus
On Amazon (PAID LINK): https://geni.us/JAybsI
On Best Buy (PAID LINK): https://geni.us/AwXmL
On Newegg (PAID LINK): https://geni.us/9JvSbBA

Buy AVerMedia Live Gamer Duo Capture Card
On Amazon (PAID LINK): https://geni.us/JzFx
On Best Buy (PAID LINK): https://geni.us/xrBerkA
On Newegg (PAID LINK): https://geni.us/wMZs4

Buy Fractal Design Meshify 2 C (White):
On Amazon (PAID LINK): https://geni.us/CqpKl
On Newegg (PAID LINK): https://geni.us/ulCu
On B&H (PAID LINK): https://geni.us/Ko3dk

Buy Western Digital 1TB WD Blue SSD
On Amazon (PAID LINK): https://geni.us/jNCJ5
On Best Buy (PAID LINK): https://geni.us/Hp85
On Newegg (PAID LINK): https://geni.us/8qRl

Buy Noctua NH-D15 chromax.Black CPU Cooler
On Amazon (PAID LINK): https://geni.us/4MpN4S
On Newegg (PAID LINK): https://geni.us/FpU3
On B&H (PAID LINK): https://geni.us/NR2CF

Buy Corsair Vengeance LPX 16GB (2x8GB) DDR4 RAM
On Amazon (PAID LINK): https://geni.us/8dZ0NW
On Best Buy (PAID LINK): https://geni.us/pEAeCAM
On Newegg (PAID LINK): https://geni.us/0lAgt

Buy Samsung Odyssey G7 Gaming Monitor
On Samsung (PAID LINK): https://geni.us/3Pmmk
On Amazon (PAID LINK): https://geni.us/jPqN2d
On Best Buy (PAID LINK): https://geni.us/DPNf6

Buy Elgato Stream Deck
On Amazon (PAID LINK): https://geni.us/BvLqh
On Best Buy (PAID LINK): https://geni.us/VFtQSc
On Newegg (PAID LINK): https://geni.us/xSAVx

Check out the Nanoleaf Essentials bulbs at https://lmg.gg/6cgzl

Buy Audio-Technica AT2020 XLR Microphone
On Amazon (PAID LINK): https://geni.us/ISys
On Best Buy (PAID LINK): https://geni.us/yyD1kt
On Newegg (PAID LINK): https://geni.us/kNOkDZ7

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1365910-ultimate-gaming-basement-setup-intel-5000-extreme-tech-upgrade/


► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro

## How to Buy a Laptop
 - [https://www.youtube.com/watch?v=3sYNn9RlyOw](https://www.youtube.com/watch?v=3sYNn9RlyOw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-16 00:00:00+00:00

Check out the Drop + Infinity War Custom Keycap Set at https://dro.ps/ltt-infinity-war

Learn more about MSI's CLUTCH GM41 Lightweight Wireless Gaming Mouse at https://lmg.gg/gm41
Buy on Amazon at (PAID LINK): https://geni.us/8RPQ

We wanted to do a Back To School Buyers Guide.. but the second we recommend something in 2021 it will be sold out. So instead we're giving you the tools to figure out what laptop is best for you.


Buy HP Envy 14: https://lmg.gg/vCI95

Buy Dell XPS 15: https://geni.us/BKcV

Buy HP Envy 13: https://geni.us/dkRj

Buy MacBook Air M1: https://geni.us/ofdNxIK

Buy Acer Nitro 5: https://geni.us/LFOO

Buy Alienware m15: https://geni.us/TiBFNAM

Buy HP Omen 15: https://lmg.gg/oxzSl

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1365637-how-to-buy-a-laptop/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 - Intro
0:27 - MSI Clutch!
0:40 - The XPS 15 is sick
1:05 - How much performance do you need?
1:48 - GPU Selection
3:36 - CPU Selection
5:30 - How much RAM?
6:00 - How much Storage?
6:50 - Apple M1
7:43 - Chromebooks
8:15 - Display Selection
12:05 - Keyboard & Trackpad
15:00 - Weight and Battery Life
15:56 - Drop.com
16:35 - Outro

