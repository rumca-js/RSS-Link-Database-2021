# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: CS-Jay & Slide - TDTTDHAD (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=nvB9j50ZK-0](https://www.youtube.com/watch?v=nvB9j50ZK-0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-08-17 00:00:00+00:00

"TDTTDHAD aka The Demo Tune That Didn't Have A Demo" by CS-Jay/PM^Desire & Slide/Polka Brothers (Christian Steen Jensen & Henrik Juhl), 1st at Shadow Party 2021. Art "Renaissance" by Fiver2, 8th at The Party 1996.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Infinite oversampling with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- This was a 4 channel Protracker module

Visit my channel for more Amiga music.

## Amiga Paula does XM: Idle - Almost There (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=SajYTR-8--c](https://www.youtube.com/watch?v=SajYTR-8--c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2021-08-16 00:00:00+00:00

"Almost There (Compo)" (1996) by Idle/Independent (Thomas Björkmann), 1st at Birdie 5. Art "Alternative Tequila" by Dean, 2nd at Assembly 1992.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 16 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

