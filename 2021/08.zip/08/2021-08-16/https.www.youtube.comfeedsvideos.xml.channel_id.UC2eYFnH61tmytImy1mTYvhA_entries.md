# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## The Most Monumental Software Oversight in History? (CONSPIRACY, lol!)
 - [https://www.youtube.com/watch?v=Hwab428Iqxs](https://www.youtube.com/watch?v=Hwab428Iqxs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-08-17 00:00:00+00:00

A brief disaster story of how one minor line of code, added as a bugfix has had monumental ramifications on software. This is arguable an ad hoc bug fix that will be nagging us financially for decades, depending on the future of Bitcoin.

My website: https://lukesmith.xyz
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

## OBS is Major Soyware...
 - [https://www.youtube.com/watch?v=FSJNuYQ-oeU](https://www.youtube.com/watch?v=FSJNuYQ-oeU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-08-16 00:00:00+00:00

I'll read donations: https://donate.lukesmith.xyz

