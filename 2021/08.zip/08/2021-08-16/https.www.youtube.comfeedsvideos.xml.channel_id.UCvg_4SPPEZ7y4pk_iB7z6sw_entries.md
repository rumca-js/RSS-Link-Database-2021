# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Epic Vs Apple: Re-Reckoning
 - [https://www.youtube.com/watch?v=_wJc9ueBoFc](https://www.youtube.com/watch?v=_wJc9ueBoFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-08-16 00:00:00+00:00

Epic and Apple had a big fun battle. It was fun. You should’ve been there.

Today I discuss things pertaining to the events that transpired. Yup.

There's a lot of information that keeps leaking out over time, and I may make future vids regarding new developments on stuffs like the "Chamber of Progress", but, well, that leaked several minutes before I started uploading this.

Alas.

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpe...

Additional Footage Credits:
ReAct Theatre

