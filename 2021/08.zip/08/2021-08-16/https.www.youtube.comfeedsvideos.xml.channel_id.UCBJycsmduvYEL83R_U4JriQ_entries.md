# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Google Pixel 5A: Spot the Difference!
 - [https://www.youtube.com/watch?v=SG3Zz_pfbOE](https://www.youtube.com/watch?v=SG3Zz_pfbOE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-08-17 00:00:00+00:00

Pixel 5A vs Pixel 4A 5G. A budget smartphone refresh for the history books.
ExpressVPN: https://expressvpn.com/MKBHD
That shirt: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Google for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

