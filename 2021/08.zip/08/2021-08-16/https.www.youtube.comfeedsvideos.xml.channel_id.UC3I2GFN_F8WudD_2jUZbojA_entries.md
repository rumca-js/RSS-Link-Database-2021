# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Squid - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=wsCk1SXbciU](https://www.youtube.com/watch?v=wsCk1SXbciU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-17 00:00:00+00:00

http://KEXP.ORG presents Squid performing live, recorded exclusively for KEXP.

Songs:
Peel St.
G.S.K.
Global Groove
2010
Paddling

Session recorded at The Cube Microplex, Bristol
Director: Benjamin Brook
Producer: Duncan Harrison
DoP: Jamie Harding
Camera Operator: Jerry Dobson
Sound Engineer: Max Goulding
Editor & Colourist: Benjamin Brook
Thanks to: Sinead Mills, Ina Tatarko, Natasha Cutts, Dan Hilltout, Robbie Warin, Chiz Williams

https://squidband.uk
http://kexp.org

## Squid - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=6GS7o5v5vao](https://www.youtube.com/watch?v=6GS7o5v5vao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-16 00:00:00+00:00

http://KEXP.ORG presents Squid sharing a live performance recorded exclusively for KEXP and talking to DJ Morgan. Recorded August 3, 2021.

Songs:
Peel St.
G.S.K.
Global Groove
2010
Paddling

Session recorded at The Cube Microplex, Bristol
Director: Benjamin Brook
Producer: Duncan Harrison
DoP: Jamie Harding
Camera Operator: Jerry Dobson
Sound Engineer: Max Goulding
Editor & Colourist: Benjamin Brook
Thanks to: Sinead Mills, Ina Tatarko, Natasha Cutts, Dan Hilltout, Robbie Warin, Chiz Williams

https://squidband.uk
http://kexp.org

