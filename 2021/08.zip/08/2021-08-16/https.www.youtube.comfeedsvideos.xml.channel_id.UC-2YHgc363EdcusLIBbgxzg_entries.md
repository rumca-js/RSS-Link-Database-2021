# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## This Video Will Doom You. | Answers With Joe
 - [https://www.youtube.com/watch?v=Rg37rg8Vfxo](https://www.youtube.com/watch?v=Rg37rg8Vfxo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-08-16 00:00:00+00:00

Get 20% of a premium subscription to Brilliant when you're one of the first 200 people to sign up at http://www.brilliant.org/answerswithjoe
Nothing like a good paradox to melt your brain. So today we're going to look at some of the most interesting and mind-blowing paradoxes and thought experiments. 


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

