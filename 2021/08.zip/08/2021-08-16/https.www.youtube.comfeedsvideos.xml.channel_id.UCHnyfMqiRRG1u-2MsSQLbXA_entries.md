# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## Clickbait is Unreasonably Effective
 - [https://www.youtube.com/watch?v=S2xHZPH5Sng](https://www.youtube.com/watch?v=S2xHZPH5Sng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-08-17 00:00:00+00:00

The title and thumbnail play a huge role in a video's success or failure.
Check out http://kiwico.com/Veritasium50 for 50% off your first month of any subscription!

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Special thanks to Patreon supporters: Alvaro Naranjo, Burt Humburg, Blake Byers, Dumky, Mike Tung, Evgeny Skvortsov, Meekay, Ismail Öncü Usta, Paul Peijzel, Crated Comments, Anna, Mac Malkawi, Michael Schneider, Oleksii Leonov, Jim Osmun, Tyson McDowell, Ludovic Robillard, Jim buckmaster, fanime96, Juan Benet, Ruslan Khroma, Robert Blum, Richard Sundvall, Lee Redden, Vincent, Marinus Kuivenhoven, Alfred Wallace, Arjun Chakroborty, Joar Wandborg, Clayton Greenwell, Pindex, Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal 

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Written by Derek Muller
Animation by Ivy Tello
Filmed by Derek Muller and Emily Zhang
Additional video supplied by Getty Images 
Produced by Derek Muller, Emily Zhang and Petr Lebedev

