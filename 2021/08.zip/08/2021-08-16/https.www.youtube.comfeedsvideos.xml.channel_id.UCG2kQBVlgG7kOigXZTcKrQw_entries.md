# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Perła Słowenii - TRIGLAV. Wejście na 2409m i odwrót 😬 + rowerem wśród jezior i rzek Słowenii. Socza!
 - [https://www.youtube.com/watch?v=IL_UnOBIXTc](https://www.youtube.com/watch?v=IL_UnOBIXTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2021-08-17 00:00:00+00:00

Zainteresowana/y książką? Zapisz się do powiadomień 
📙👉 https://kolemsietoczy.pl/ksiazka/

Kurs filmowania i montażu 🎬 https://www.kursfilmowaniaimontazu.pl/
Dodatek Podróżniczy 🎬 http://filmypodroznicze.pl/

Dzień dobry! Dziękujemy bardzo za odbiór pierwszego filmu ze Słowenii. Ogląda się aż miło... bije na głowę wszystkie poprzednie. Mam nadzieję, że dzisiejsza Słowenia jeszcze bardziej przypadnie Wam do gustu, zwłaszcza, że widokowo odwiedzone miejsca wydają mi się być jeszcze ładniejsze.   Pokręcimy się w okolicach Triglavskiego Parku narodowego, wejdziemy na szczyt Križ, a także pokręcimy się po najładniejszych miejscach w okolicy. Również wyskoczymy na kilka tras rowerowych wzdłuż słoweńskich rzek - Idrijicy, Baczy no i oczywiście najpiękniejszej rzeki Słowenii - Soczy.

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

muzyka: Nevaeh oraz artlist.io

link do chatek  https://en.pzs.si/koce.php


spis treści:
0:00  Słowenia - wstęp
00:31  Triglavski Park Narodowy
02:38  Jezioro Bled
04:26 Jezioro Bohinjsko
05:48  wspinaczka na Križ
09:40  Triglav
11:03  niebezpieczne zejście ze szlaku
12:49  słoweńskie szlaki rowerowe
13:20 region Primorska
14:07 Most na Soči
17:32  Inne trasy rowerowe w Słowenii

