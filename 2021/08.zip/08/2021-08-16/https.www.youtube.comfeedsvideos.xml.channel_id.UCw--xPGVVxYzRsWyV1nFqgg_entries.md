# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## LotR Moving Controversy🤔One Piece Live Action🏴‍☠️Good Reads Extortion😈-FANTASY NEWS
 - [https://www.youtube.com/watch?v=5grPKlraT-w](https://www.youtube.com/watch?v=5grPKlraT-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-08-17 00:00:00+00:00

LETS TALK ABOUT THE FANTASY NEWS!!! 
Checkout Campfire today: https://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q3_21

BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

New P.O. Box: PO Box 7874 Henrico, VA 23231

NEWS: 

00:00 Intro

Book Store Indiegogo: https://www.indiegogo.com/projects/garden-party-books#/ 

01:03 Toll The Hounds: https://twitter.com/kemar74/status/1425796355684028421 

01:44 Good Reads Extortion: https://time.com/6078993/goodreads-review-bombing/ 

03:22 #LOTR Relocating: https://screenrant.com/lord-rings-amazon-production-move-uk-crew-details/amp/ 

05:46 #Halo Master Chief Change: https://comicbook.com/gaming/news/halo-tv-series-side-of-master-chief-not-seen-in-games/ 

08:54 KEEPER OF THE NIGHT: https://twitter.com/KylieYamashiro/status/1425488445909225472?s=20 

09:22 #Dune 2 Main Character: https://theronin.org/2021/08/13/dune-denis-villeneuve-says-dune-part-two-will-see-zendayas-chani-as-the-protagonist/ 

10:37 One Piece Live Action: https://www.theilluminerdi.com/2021/08/12/one-piece-character-descriptions/ 

12:13 My Hero Academia Live Action Movie: https://twitter.com/DiscussingFilm/status/1426281580692185092 

13:05 WoT Casting: https://redanianintelligence.com/2021/08/13/amazons-the-wheel-of-time-casts-danish-actress-for-season-2/ 

13:58 George R R Martin New Novel: https://www.bluemountaineagle.com/life/entertainment/george-rr-martin-stars-work-on-a-new-graphic-novel/article_f39eeaa2-a5ab-5c59-88f1-6d4d8cdda07e.html

