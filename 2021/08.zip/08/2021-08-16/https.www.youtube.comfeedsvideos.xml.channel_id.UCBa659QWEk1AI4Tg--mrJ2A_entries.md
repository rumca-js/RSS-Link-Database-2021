# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## I helped cover a 5,000-year-old monument with worn-out tires
 - [https://www.youtube.com/watch?v=hUyvk_hdMNs](https://www.youtube.com/watch?v=hUyvk_hdMNs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-08-16 00:00:00+00:00

Ness of Brodgar, in Orkney, is one of the most important archaeological sites in western Europe. This week, it was covered by old, worn-out tires. Here's why. ■ Thanks to the Ness team! More about them, volunteering, and donating: https://www.nessofbrodgar.co.uk/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

