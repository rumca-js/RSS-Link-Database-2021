# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## CNN Praises Taliban For Wearing Masks During Attack
 - [https://www.youtube.com/watch?v=g-FLw-YY5sY](https://www.youtube.com/watch?v=g-FLw-YY5sY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-17 00:00:00+00:00

A special CNN report on the Taliban’s brave stance on Covid safety. With special guest, Reliable Sources host, Brian Stelter (russet).

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Christian Movies, Nicolas Cage, and Say Goodnight Kevin | The Kevin McCreary Interview
 - [https://www.youtube.com/watch?v=moQFUQyGs2o](https://www.youtube.com/watch?v=moQFUQyGs2o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-08-17 00:00:00+00:00

On The Babylon Bee Interview Show, Kyle and Ethan talk to Kevin McCreary from Say Goodnight Kevin. They talk about the art of making fun of Christian movies, Nicolas Cage in Left Behind, and the state of Christian art. Kevin created his YouTube channel back in 2014 for a way to help people think for themselves on movies. He has grown his audience by taking apart Christian movies and still remaining a Christian. One of his featured videos gives a breakdown on How to Make a Christian movie.

Check out BetterHelp.com/BabylonBee for 10% off

Be sure to check out Say Goodnight Kevin: https://www.youtube.com/user/saygoodnightkevin

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com​​​​
Follow The Babylon Bee:
Website: https://babylonbee.com​​​​
Twitter: http://twitter.com/thebabylonbee
​​​​Facebook: http://facebook.com/thebabylonbee
​​​​Instagram: http://instagram.com/thebabylonbee​

