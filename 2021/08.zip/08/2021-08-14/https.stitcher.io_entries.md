## Why do I write? - stitcher.io
 - [https://stitcher.io/blog/why-do-i-write](https://stitcher.io/blog/why-do-i-write)
 - RSS feed: https://stitcher.io
 - date published: 2021-08-14 15:55:57.263623+00:00

Thoughts on a fast-food content-creation culture

