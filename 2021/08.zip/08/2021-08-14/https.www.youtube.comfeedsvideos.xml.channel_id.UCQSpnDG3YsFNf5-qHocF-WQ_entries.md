# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The Cancelled Version of Windows
 - [https://www.youtube.com/watch?v=2WotS8EBzU0](https://www.youtube.com/watch?v=2WotS8EBzU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-08-14 00:00:00+00:00

Did you know about this abandoned version of Windows? 🤔
• Check out Bitdefender Total Security here (Sponsored) ⇨ https://www.bitdefender.com/media/html/consumer/new/TJ-SQ3-Bitdefender/?cid=inf%7Cc%7Cyt%7CTJQ3

▼ Time Stamps: ▼
0:00 - Intro
2:18 - Evolution 1: Dual Screen
3:19 - Evolution 2: Lightweight Single Screen
7:14 - 10X No More

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

