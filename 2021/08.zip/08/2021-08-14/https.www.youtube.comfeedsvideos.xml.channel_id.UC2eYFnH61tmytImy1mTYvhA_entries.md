# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## I installed OpenBSD. (Nothing serious)
 - [https://www.youtube.com/watch?v=ieXax2u6_NY](https://www.youtube.com/watch?v=ieXax2u6_NY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-08-15 00:00:00+00:00

Lincucks on sewerslide watch.

I'm talking out loud here about my basic first impressions with installing and running basic commands on OpenBSD. I don't like the idea of the installer, but it worked well. Some familiar commands on GNU/Linux are lacking on BSD. Installing programs is pretty easy, but it'll probably be an issue to rebuild a familiar setup on OpenBSD. No ttys in the way I'm familiar with them and a bunch of little differences.

My website: https://lukesmith.xyz
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

## Why Most "Serious" Cryptos are Still Scammy
 - [https://www.youtube.com/watch?v=dHsxmoZWEw4](https://www.youtube.com/watch?v=dHsxmoZWEw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2021-08-14 00:00:00+00:00

Most people in crypto are making vaporware for sick gains via buzzword smothering. Few projects actually are well-designed self-propelling incentive systems that can feasibly end up as underlying internet protocol.

"AUUUGH I'M GONNA BITCOOOOOOOIN"

My website: https://lukesmith.xyz
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

