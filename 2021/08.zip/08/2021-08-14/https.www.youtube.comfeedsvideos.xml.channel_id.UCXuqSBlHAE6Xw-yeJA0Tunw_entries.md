# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Once Caught a Monitor THIS BIG - Samsung Odyssey Neo G9 Showcase
 - [https://www.youtube.com/watch?v=tURZaUyUoOM](https://www.youtube.com/watch?v=tURZaUyUoOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-15 00:00:00+00:00

Thanks to Samsung for sponsoring this video! Check out the Samsung Odyssey Neo G9 gaming monitor at https://lmg.gg/qHI76

The Odyssey Neo G9 might LOOK like the previous model, but under the hood, there's A LOT more going on with this ultra-wide curved gaming monitor thanks to their new panel.

Buy AMD Ryzen 9 5950x
On Amazon (PAID LINK): https://geni.us/OIidjZg
On Best Buy (PAID LINK): https://geni.us/a3pw
On Newegg (PAID LINK): https://geni.us/EBMsy2

Buy NVIDIA RTX 3090
On Amazon (PAID LINK): https://geni.us/B9HljZ
On Best Buy (PAID LINK): https://geni.us/Kp2K
On Newegg (PAID LINK): https://geni.us/RmFCXUT

Buy 1TB Samsung 970 EVO Plus
On Amazon (PAID LINK): https://geni.us/aGp2Uw 
On Best Buy (PAID LINK): https://geni.us/8BAWt
On Newegg (PAID LINK): https://geni.us/5w9w4

Buy ASUS Prime x570 Pro
On Amazon (PAID LINK): https://geni.us/q4fmvQ
On Newegg (PAID LINK): https://geni.us/FbBpI
On B&H (PAID LINK): https://geni.us/nWhC

Buy G.Skill RGB 3200MHz 4x16GB
On Amazon (PAID LINK): https://geni.us/f4hpo
On Newegg (PAID LINK): https://geni.us/6HMvbx

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1365335-i-once-caught-a-monitor-this-big-samsung-odyssey-neo-g9-showcase-sponsored/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:04 Unboxing
3:05 The Back
3:50 Plugging It In
4:30 Turning It On
6:00 Mini LED
7:55 Destiny
9:33 Forza
10:25 Doom
11:05 Conclusion
11:45 Outro

## How BAD is it if you forget to peel??
 - [https://www.youtube.com/watch?v=fDogiKaNaac](https://www.youtube.com/watch?v=fDogiKaNaac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-08-14 00:00:00+00:00

Start your build today at https://www.buildredux.com/linus

Save 10% and Free Worldwide Shipping at Ridge Wallet by using offer code LINUS at https://www.ridge.com/LINUS

Waterblocks and air coolers both share the common trait of a metal cold plate that makes contact with the CPU for heat transfer. This needs to be protected, and not all protection is created equal. What happens to your Core i9 if you forget to peel that little piece of plastic? Let's find out.


Buy Cooler Master Hyper 212 Evo CPU Cooler: https://geni.us/YaKyGxD

Buy NZXT Kraken x62: https://geni.us/7RADLA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1365065-how-bad-is-it-if-you-forget-to-peel/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:22 Why is plastic protection needed?
2:40 i3-8100 - Setup
3:36 Brandon gives away the mystery :(
3:46 i3-8100 - Testing
6:19 i9-9900k - Setup
7:07 i9-9900k - Testing
8:00 Heat transfer explanation
9:49 Thermal throttling explanation
10:42 How bad is it ACTUALLY?

