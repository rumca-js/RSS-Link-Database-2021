# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Ethiopia: What do we know about aid going into Tigray?
 - [https://www.bbc.co.uk/news/58189049](https://www.bbc.co.uk/news/58189049)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 23:52:00+00:00

Who's preventing desperately needed aid supplies reaching Ethiopia's Tigray region?

## 'This was a race and we lost': How US doctors really feel about Covid surge
 - [https://www.bbc.co.uk/news/world-us-canada-58208721](https://www.bbc.co.uk/news/world-us-canada-58208721)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 23:42:41+00:00

Healthcare workers react to the growing rise of Covid patients in US hospitals despite vaccines.

## 'My night in Quisling's cabin'
 - [https://www.bbc.co.uk/news/stories-58208551](https://www.bbc.co.uk/news/stories-58208551)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 23:20:17+00:00

When Ben McPherson realised he could rent Vidkun Quisling's cabin, it struck him as weird. His Norwegian wife disagreed.

## Who is TikTok’s masked vigilante?
 - [https://www.bbc.co.uk/news/blogs-trending-58195065](https://www.bbc.co.uk/news/blogs-trending-58195065)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 23:08:16+00:00

Think you’re safe being an anonymous TikTok troll or cyber bully? Meet your worst nightmare.

## 'How I found out my dad was a best-selling sex writer'
 - [https://www.bbc.co.uk/news/stories-58171940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-58171940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 22:53:51+00:00

Sara Faith Alterman was always close to her father. Then she learned he was concealing a secret.

## 'How I found out my dad was a best-selling sex writer'
 - [https://www.bbc.co.uk/news/stories-58171940](https://www.bbc.co.uk/news/stories-58171940)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 22:53:51+00:00

Sara Faith Alterman was always close to her father. Then she learned he was concealing a secret.

## How do we slow down fast fashion?
 - [https://www.bbc.co.uk/news/uk-scotland-58216479](https://www.bbc.co.uk/news/uk-scotland-58216479)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 18:06:40+00:00

The clothes we wear can have a huge impact on the climate, even more so than the aviation industry.

## Nicola Sturgeon's sister Gillian arrested over Ayrshire incident
 - [https://www.bbc.co.uk/news/uk-scotland-58213744](https://www.bbc.co.uk/news/uk-scotland-58213744)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 11:50:34+00:00

Nicola Sturgeon's sister Gillian was arrested along with a man over an alleged domestic incident in North Ayrshire.

## Man Utd complete signing of Varane from Real Madrid
 - [https://www.bbc.co.uk/sport/football/58176187](https://www.bbc.co.uk/sport/football/58176187)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 11:38:13+00:00

Manchester United complete the signing of France centre-back Raphael Varane from Real Madrid on a four-year-deal.

## Channel migrant crossings reach record high as man dies
 - [https://www.bbc.co.uk/news/uk-england-kent-58213583](https://www.bbc.co.uk/news/uk-england-kent-58213583)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 11:34:28+00:00

The UK deals with 592 people crossing the Channel on the day a migrant makes a fatal leap into the sea.

## Sarah Rainsford on Russia: 'I've been told I can't come back - ever'
 - [https://www.bbc.co.uk/news/world-europe-58213845](https://www.bbc.co.uk/news/world-europe-58213845)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 11:17:34+00:00

The BBC's Sarah Rainsford, devastated after being told she could not return to Russia, ever.

## Lions greats say World Rugby should end tactical substitutions or risk on-field death
 - [https://www.bbc.co.uk/sport/rugby-union/58213246](https://www.bbc.co.uk/sport/rugby-union/58213246)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 11:01:49+00:00

Five British and Irish Lions greats ask World Rugby to change laws on substitutions, fearing a player could die on the field otherwise.

## Marines to check sea depths after recruit drowned
 - [https://www.bbc.co.uk/news/uk-england-cornwall-58205696](https://www.bbc.co.uk/news/uk-england-cornwall-58205696)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 10:59:38+00:00

A 20-year-old recruit died after disembarking into deep water at Tregantle in Cornwall.

## Plymouth shooting: Killer had shotgun permit returned last month
 - [https://www.bbc.co.uk/news/uk-england-devon-58209726](https://www.bbc.co.uk/news/uk-england-devon-58209726)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 10:47:07+00:00

The police watchdog is investigating the decision to give back Jake Davison's shotgun and certificate.

## Sark: Two people test positive for Covid-19
 - [https://www.bbc.co.uk/news/world-europe-guernsey-58212983](https://www.bbc.co.uk/news/world-europe-guernsey-58212983)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 10:08:34+00:00

The small Channel Island only recorded its first case of Covid-19 in July.

## Newcastle tyre-flipping world records attempted
 - [https://www.bbc.co.uk/news/uk-england-tyne-58207214](https://www.bbc.co.uk/news/uk-england-tyne-58207214)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 08:53:37+00:00

The organisers plan teams and individual attempts using large car and tractor tyres.

## Shetland’s biggest gig – the day Pulp flew in to Lerwick
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-57599869](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-57599869)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 08:38:50+00:00

At the height of their fame, the Britpop icons travelled to Lerwick to play a show for just 1,400 fans.

## Wade set to 'shock the world' in NFL - Obada
 - [https://www.bbc.co.uk/sport/american-football/58156239](https://www.bbc.co.uk/sport/american-football/58156239)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 08:02:18+00:00

Christian Wade's American football dream is about to come true, says his fellow Briton and new Buffalo Bills team-mate Efe Obada.

## Nanci Griffith: Folk and country singer-songwriter dies aged 68
 - [https://www.bbc.co.uk/news/entertainment-arts-58212802](https://www.bbc.co.uk/news/entertainment-arts-58212802)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 07:59:13+00:00

The Grammy-winning artist was best known for her influential career in folk and country music.

## Plymouth shooting: 'It could have been any of us'
 - [https://www.bbc.co.uk/news/uk-58213293](https://www.bbc.co.uk/news/uk-58213293)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 07:44:56+00:00

Hundreds of people attended a vigil on Friday evening close to where five people were shot dead in Plymouth.

## Brett Staniland: Love Island contestant's twin calls out trolls
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-58201708](https://www.bbc.co.uk/news/uk-england-derbyshire-58201708)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 06:38:56+00:00

Scott Staniland says comments about his brother Brett's looks are particularly upsetting.

## Who were the victims?
 - [https://www.bbc.co.uk/news/uk-58202760](https://www.bbc.co.uk/news/uk-58202760)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 06:04:40+00:00

The gunman's mother, Maxine Davison, and three-year-old Sophie Martyn have been named among the dead.

## The papers: Gun licence questions after 'senseless massacre'
 - [https://www.bbc.co.uk/news/blogs-the-papers-58209181](https://www.bbc.co.uk/news/blogs-the-papers-58209181)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 04:44:53+00:00

Revelations about Plymouth shooter Jake Davison's gun licence feature on the front pages.

## Nicki Minaj and husband Kenneth Petty sued by sex assault victim
 - [https://www.bbc.co.uk/news/world-us-canada-58209403](https://www.bbc.co.uk/news/world-us-canada-58209403)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 03:46:41+00:00

The woman claims the couple harassed her to try to make her recant accusations against Kenneth Petty.

## David Skelton: Is a new form of snobbery reshaping British politics?
 - [https://www.bbc.co.uk/news/uk-politics-58186519](https://www.bbc.co.uk/news/uk-politics-58186519)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 00:48:05+00:00

The working classes are looked down upon for very different reasons than in the past, argues a new book.

## Myanmar: The woman who jumped to her death while fleeing police
 - [https://www.bbc.co.uk/news/world-asia-58196465](https://www.bbc.co.uk/news/world-asia-58196465)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 00:25:35+00:00

Wai Wai Myint was among five people who jumped out of a building while fleeing a police raid in Myanmar.

## Afghans living under Taliban lament loss of freedoms
 - [https://www.bbc.co.uk/news/world-asia-58191440](https://www.bbc.co.uk/news/world-asia-58191440)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-08-14 00:15:15+00:00

Afghans in Taliban-controlled provinces describe life under its fundamentalist Islamist rule.

