## This Leeds dad makes teddies with health conditions to help children living with medical disorders
 - [https://inews.co.uk/news/real-life/this-leeds-dad-makes-teddies-with-health-conditions-to-help-children-living-with-medical-disorders-1148392](https://inews.co.uk/news/real-life/this-leeds-dad-makes-teddies-with-health-conditions-to-help-children-living-with-medical-disorders-1148392)
 - RSS feed: https://inews.co.uk
 - date published: 2021-08-14 08:59:42.012619+00:00

From pacemakers to hearing aids, Emily Cope meets the man who makes teddy bears who wear medical devices

