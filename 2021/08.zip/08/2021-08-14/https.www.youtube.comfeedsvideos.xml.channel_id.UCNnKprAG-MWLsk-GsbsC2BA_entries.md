# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Netflix ruins He-Man (parody)
 - [https://www.youtube.com/watch?v=sWdSNicgUKk](https://www.youtube.com/watch?v=sWdSNicgUKk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-08-15 00:00:00+00:00

Support us on Patreon! (STICKERS)
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

Composited by ► 
Oddest of the Odd

Lip Sync ► 
James Cunningham
 
Sound ► 
Justin Greger

Music ►
Tom Ryan

VO ►
Skeletor - Tom 
He-Man - Don 
Beastman - Don
Roboto - Don
Modulok - Tom
Stratos - Don

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

