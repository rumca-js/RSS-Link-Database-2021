## FOSS app removed from the Play Store for linking to the project's website | Hacker News
 - [https://news.ycombinator.com/item?id=28172490](https://news.ycombinator.com/item?id=28172490)
 - RSS feed: https://news.ycombinator.com
 - date published: 2021-08-14 08:52:33.219672+00:00



