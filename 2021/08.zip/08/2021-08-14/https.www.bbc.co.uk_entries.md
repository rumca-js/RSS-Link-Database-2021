## Apple regrets confusion over 'iPhone scanning' - BBC News
 - [https://www.bbc.co.uk/news/technology-58206543](https://www.bbc.co.uk/news/technology-58206543)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-08-14 08:54:43.412669+00:00

The iPhone-maker will introduce tools that can detect child sex abuse images uploaded to iCloud.

