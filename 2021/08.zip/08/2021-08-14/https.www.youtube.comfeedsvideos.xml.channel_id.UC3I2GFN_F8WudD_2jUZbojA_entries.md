# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## The Murlocs - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=oVz9ZVyt7zo](https://www.youtube.com/watch?v=oVz9ZVyt7zo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-08-14 00:00:00+00:00

http://KEXP.ORG presents The Murlocs performing live, recorded exclusively for KEXP.

Songs:
Francesca 
Skyrocket
Dangerous Nature
Eating At You (feat. Folk Bitch Trio)
Bittersweet Demons (feat. Folk Bitch Trio)
Blue Eyed Runner (feat. Folk Bitch Trio)

Session Recorded and Filmed by Tim Dunn at Button Pushers Studios
Additional Filming and Edit by Alex Mclaren
Audio Mix by Stu Mackenzie

The Murlocs:
Tim Karmouche - Keys and Synth
Matt Blach - Drums and Backing Vocals
Cook Craig - Bass Guitar
Ambrose Kenny-Smith - Vocals, Guitar, Harmonica and Mellotron.
Callum Shortal - Lead Guitar

Folk Bitch Trio:
Jeanie Pilkington - Backing Vocals
Gracie Sinclair - Backing Vocals
Heide Peverelle - Backing Vocals

https://unclemurl.com
http://kexp.org

