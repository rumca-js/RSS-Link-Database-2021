# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Money, Power and Wall Street, Part Three (full documentary) | FRONTLINE
 - [https://www.youtube.com/watch?v=71lrn2BxIvQ](https://www.youtube.com/watch?v=71lrn2BxIvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2021-08-15 00:00:00+00:00

In part three of this 2012 award-winning series, FRONTLINE goes inside the Obama White House, telling the story of how a newly elected president with a mandate for change inherited a financial crisis that would challenge his administration and define his first term.
 
This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate​.
 
FRONTLINE’s veteran financial and political producers Michael Kirk (The Choice 2020: Trump Vs. Biden, United States of Conspiracy), Martin Smith (The Crown Prince of Saudi Arabia, The Pension Gamble), Marcela Gaviria (A Subprime Education, Separated: Children at the Border) and Tom Jennings (Right to Fail, Opioids Inc.) team up to present this Emmy Award-winning documentary series.
 
#Documentary​ #MoneyPowerWallStreet 

Subscribe on YouTube: http://bit.ly/1BycsJW​
Instagram: https://www.instagram.com/frontlinepbs​
Twitter: https://twitter.com/frontlinepbs​
Facebook: https://www.facebook.com/frontline

Major funding for FRONTLINE is provided by the Ford Foundation. Additional funding is provided by the Abrams Foundation; the John D. and Catherine T. MacArthur Foundation; Park Foundation; and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation, and additional support from Koo and Patricia Yuen.

## Money, Power and Wall Street, Part Two (full documentary) | FRONTLINE
 - [https://www.youtube.com/watch?v=Mb786mTZVHk](https://www.youtube.com/watch?v=Mb786mTZVHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2021-08-14 00:00:00+00:00

In part two of this 2012 award-winning series, FRONTLINE investigates the largest government bailout in U.S. history and a series of decisions that rewrote the rules of government and fueled a debate that would alter the country’s political landscape.
 
This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate​.

In the second hour of Money, Power and Wall Street, FRONTLINE producer Michael Kirk tells the story of how the country’s leaders—Treasury Secretary Henry Paulson, Federal Reserve Chairman Ben Bernanke and New York Federal Reserve President Timothy Geithner—struggled to respond to a financial crisis that caught them by surprise. 
 
FRONTLINE’s veteran financial and political producers Michael Kirk (The Choice 2020: Trump Vs. Biden, United States of Conspiracy), Martin Smith (The Crown Prince of Saudi Arabia, The Pension Gamble), Marcela Gaviria (A Subprime Education, Separated: Children at the Border) and Tom Jennings (Right to Fail, Opioids Inc.) team up to present this Emmy Award-winning documentary series.
 
#Documentary​ #MoneyPowerWallStreet

Subscribe on YouTube: http://bit.ly/1BycsJW​
Instagram: https://www.instagram.com/frontlinepbs​
Twitter: https://twitter.com/frontlinepbs​
Facebook: https://www.facebook.com/frontline

Major funding for FRONTLINE is provided by the Ford Foundation. Additional funding is provided by the Abrams Foundation; the John D. and Catherine T. MacArthur Foundation; Park Foundation; and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation, and additional support from Koo and Patricia Yuen.

