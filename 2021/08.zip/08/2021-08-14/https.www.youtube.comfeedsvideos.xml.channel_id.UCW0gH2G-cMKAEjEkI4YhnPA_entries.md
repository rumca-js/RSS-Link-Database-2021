# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Gil-galad, the Last High King | Tolkien Explained
 - [https://www.youtube.com/watch?v=FciPUcV99GM](https://www.youtube.com/watch?v=FciPUcV99GM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-08-14 00:00:00+00:00

Today, we cover the entire life of one of the greatest High Kings of the Noldor - Gil-galad!  Sure to feature in the new Amazon series, Gil-galad leads his people during the final days of the First Age and throughout the entire Second Age.  He shows great wisdom and bravery, and is personally involved in defeating Sauron TWICE in war.

Founding the Kingdom of Lindon, he provides a safe haven for the elves of Beleriand to begin the Second Age.  While elves like Galadriel and Celebrimbor would strike out to other realms, Gil-galad, Círdan, and Elrond would remain in Lindon, where they would face threats from dark forces...

*Hit subscribe - and the bell!* 
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc

Ereinion - MissingMyMind
Gil-galad - Luis F Bejarano
Sauron vs Gil-galad - Rui Goncalves
Gil-galad - Madlore
The Battle of Sudden Flame - Dagor Bragollach - Jovandarkart
Beleriand Map - Lamaarcana
Gil-galad - Mellorianj
Farewell Fingon and Ereinion - Marya Filatova
Turin in Nargothrond - Alan Lee
Glaurung - Justin Gerard
Gil-galad was an Elven king - Jenny Dolfen
Celebrimbor - Angus McBride
Galadriel and Celeborn at Lake Evendim - Ted Nasmith
Gil-galad - Ivan Cavini
Aldarion Returns From His First Voyage - Ted Nasmith
Sauron - Jerry Vanderstelt
The Necromancer - Spartank42
Numenor - Eric Faure Brac
Numenorean Guard - Luis F Bejarano
Union of Maedhros - Alan Lee
The Oath of Felagund - Antti Autio
The Forging of the Ring - Alan Lee
Celebrimbor's Death - Peet
The King and His Herald - Lelia
Gil-galad - Irsanna
Ar-Pharazon - Steamey
Sauron bows, submits to Ar-Pharazon - Kip Rasmussen
Ar-Pharazon and Sauron - Janka Lateckova
The Ships of the Faithful - Ted Nasmith
The Last Alliance - Abe Papakhian
Gil-galad - Sebastian Pagh
Elf Last Alliance - Angel Falto
Dark Lord Sauron - Spartank42
Sauron vs Elendil and Gil-galad on Orodruin - Kip Rasmussen
Gil-galad, Sauron, Elendil - Tom Romain
Gil-galad Burns - Vik Wizard
Gil-galad - Tolrone
Gil-galad - Lucius Arobel
Gil-galad - Per Sjogren
Scion of Kings - Karolina Wegrzyn
The Last Alliance - Jenny Dolfen
I Behold - Abe Papakhian

For more on Gil-galad and the Second Age, check out these great resources:
Unfinished Tales
The Silmarillion
Tolkien Gateway
The Encyclopedia of Arda

#gilgalad #tolkien #lotronprime

