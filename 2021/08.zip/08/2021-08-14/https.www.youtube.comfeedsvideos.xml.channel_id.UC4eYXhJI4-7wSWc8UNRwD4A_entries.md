# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Amplify with Lara Downes: Camille A. Brown
 - [https://www.youtube.com/watch?v=vGACLfYWq_4](https://www.youtube.com/watch?v=vGACLfYWq_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-08-14 00:00:00+00:00

Lara Downes | August 14, 2021
As a child, Camille A. Brown was self-conscious — and teased — about her small speaking voice. She had to find a way to speak her mind and express her ideas. She found her voice in dance, a joyful place where her body could move freely, fill space boldly and tell stories to the world.

I know how it feels, as a small girl, to find the safe haven of your creativity, to rejoice in the power of a world you invent all by yourself. I also know how it feels when you realize that there's another world out there, big and loud and sometimes unkind. That world can ignore you; it can make you doubt that you're visible or valuable. It can make you give up, or it can make you fight on.

Camille says that her success came by way of rejection. She heard so many "no's" early on, found so many doors and minds closed to her body and her artistry. It's hard to imagine such a rocky start when you look at the scope of her achievements as a true superstar in the worlds of dance, theater and even opera, where she will soon make history as the first Black director at New York's Metropolitan Opera.

What is it that makes you move past the closed doors, push back against the "no's" and stay the course to achieve your greatness? I think it's simply this: You know that what you have to say is bigger than you. You find your voice because you need to tell stories that have gone unheard, to speak up for others who have been ignored and rejected. Camille's work is speaking for Black identity, telling stories of the past and present. And, most importantly, her work is shaping the future, in the hopes that going forward the world will listen to the voice of a little Black girl who has a lot to say.

