# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Księga Kapłańska || Rozdział 20
 - [https://www.youtube.com/watch?v=udrETY-3EIE](https://www.youtube.com/watch?v=udrETY-3EIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-15 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Niezniszczalni [#09] Q&A - Pytania do mężczyzn
 - [https://www.youtube.com/watch?v=5RmhQCyWhvc](https://www.youtube.com/watch?v=5RmhQCyWhvc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-15 00:00:00+00:00

@Langustanapalmie @RTCK_robtocokochasz 

Tego jeszcze nie było! Dwóch żonatych i ksiądz. Po męsku. Przy kawie. W półmroku. Zapraszamy na nową serię o mężczyznach - nie tylko dla mężczyzn...

☕️☕️☕️➡️  TUTAJ znajdziesz KAWĘ RTCK 
💥 https://www.rtck.pl/sklep/akcesoria/kawa-rtck/?ref=17/

PROWADZĄCY: 
➜ o. Adam Szustak OP - https://www.instagram.com/langustanapalmie/ 
➜ Michał Szczepanek - https://www.instagram.com/michalszczepanek.pl/ 
➜ Piotr Piwowar - https://www.instagram.com/_piotrpiwowar 

PREZENT dla "Langustowiczów" od RTCK: 
Odbierz ZA DARMO jedną z trzech NAJLEPSZYCH audiokonferencji RTCK: ks. Piotra Pawlukiewicza, o. Adama Szustaka, lub ks. Jana Kaczkowskiego i ROZWIŃ swoje powołanie, aby mieć WIĘCEJ satysfakcji z PRACY, RODZINY i ŻYCIA. 
Tutaj LINK ➡️ https://www.rtck.pl/?ref=17/ 

wideo: Jakub Kosakowski i Krzysztof Ogórek 
dźwięk: Maksymilian Zięba i Bartłomiej (Wacek) Wawrzyniak 
czołówka: Krzysztof Ogórek 
fotografie: Dorota Czoch 
montaż i koncepcja czołówki: Michał Szczepanek i Piotr Piwowar

serię nagrano i wyprodukowano w studio RTCK - Rób to co kochasz
INSTAGRAM https://www.instagram.com/rtck.pl/
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#247] Zło zwycięża w świecie? A gdzie tam!
 - [https://www.youtube.com/watch?v=Hwkp_eWxJ1w](https://www.youtube.com/watch?v=Hwkp_eWxJ1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-14 00:00:00+00:00

@Langustanapalmie #cnn #kazankodookienka #dobrewiadomości 

Uroczystość Wniebowzięcia Najświętszej Maryi Panny

1. czytanie (Ap 11, 19a; 12, 1. 3-6a. 10ab)

Świątynia Boga w niebie się otwarła, i Arka Jego Przymierza ukazała się w Jego świątyni. Potem wielki znak się ukazał na niebie: Niewiasta obleczona w słońce i księżyc pod jej stopami, a na jej głowie wieniec z gwiazd dwunastu.

Ukazał się też inny znak na niebie: Oto wielki Smok ognisty; ma siedem głów i dziesięć rogów, a na głowach siedem diademów. Ogon jego zmiata trzecią część gwiazd z nieba i rzucił je na ziemię. Smok stanął przed mającą urodzić Niewiastą, ażeby skoro porodzi, pożreć jej Dziecko. I porodziła syna – mężczyznę, który będzie pasł wszystkie narody rózgą żelazną. Dziecko jej zostało porwane do Boga i do Jego tronu. Niewiasta zaś zbiegła na pustynię, gdzie miejsce ma przygotowane przez Boga.

I usłyszałem donośny głos mówiący w niebie: «Teraz nastało zbawienie, potęga i królowanie Boga naszego i władza Jego Pomazańca»


2. czytanie (1 Kor 15, 20-26)

Bracia:
Chrystus zmartwychwstał jako pierwszy spośród tych, co pomarli. Ponieważ bowiem przez człowieka przyszła śmierć, przez człowieka też dokona się zmartwychwstanie. I jak w Adamie wszyscy umierają, tak też w Chrystusie wszyscy będą ożywieni, lecz każdy według własnej kolejności. Chrystus jako pierwszy, potem ci, co należą do Chrystusa, w czasie Jego przyjścia. Wreszcie nastąpi koniec, gdy przekaże królowanie Bogu i Ojcu i gdy pokona wszelką Zwierzchność, Władzę i Moc.

Trzeba bowiem, ażeby królował, aż położy wszystkich nieprzyjaciół pod swoje stopy. Jako ostatni wróg, zostanie pokonana śmierć.


Ewangelia (Łk 1, 39-56)

Maryja wybrała się i poszła z pośpiechem w góry do pewnego miasta w pokoleniu Judy. Weszła do domu Zachariasza i pozdrowiła Elżbietę.
Gdy Elżbieta usłyszała pozdrowienie Maryi, poruszyło się dzieciątko w jej łonie, a Duch Święty napełnił Elżbietę. Wydała ona okrzyk i powiedziała:
«Błogosławiona jesteś między niewiastami i błogosławiony jest owoc Twojego łona. A skądże mi to, że Matka mojego Pana przychodzi do mnie? Oto skoro głos Twego pozdrowienia zabrzmiał w moich uszach, poruszyło się z radości dzieciątko w moim łonie. Błogosławiona jesteś, któraś uwierzyła, że spełnią się słowa powiedziane Ci od Pana».
Wtedy Maryja rzekła:
«Wielbi dusza moja Pana,
i raduje się duch mój w Bogu, moim Zbawcy.
Bo wejrzał na uniżenie swojej służebnicy.
Oto bowiem odtąd błogosławić mnie będą
wszystkie pokolenia.
Gdyż wielkie rzeczy uczynił mi Wszechmocny.
święte jest Jego imię,
A Jego miłosierdzie z pokolenia na pokolenie
nad tymi, co się Go boją.
Okazał moc swego ramienia,
rozproszył pyszniących się zamysłami serc swoich.
Strącił władców z tronu, a wywyższył pokornych.
Głodnych nasycił dobrami, a bogatych z niczym odprawił.
Ujął się za swoim sługą, Izraelem,
pomny na swe miłosierdzie.
Jak przyobiecał naszym ojcom,
Abrahamowi i jego potomstwu na wieki».

Maryja pozostała u niej około trzech miesięcy; potem wróciła do domu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Kapłańska || Rozdział 19
 - [https://www.youtube.com/watch?v=-OV6t9ZNa_o](https://www.youtube.com/watch?v=-OV6t9ZNa_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-14 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Targ intencji || sierpień 2021
 - [https://www.youtube.com/watch?v=fE-E7QHiKXc](https://www.youtube.com/watch?v=fE-E7QHiKXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-14 00:00:00+00:00

@Langustanapalmie 

Targ intencji sierpień 2021
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#863] Perspektywa
 - [https://www.youtube.com/watch?v=ExHeMO9ywo4](https://www.youtube.com/watch?v=ExHeMO9ywo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-08-14 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

