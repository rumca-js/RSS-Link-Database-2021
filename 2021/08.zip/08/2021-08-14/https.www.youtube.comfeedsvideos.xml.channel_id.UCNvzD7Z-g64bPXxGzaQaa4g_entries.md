# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Copycat Games That Are Actually Good
 - [https://www.youtube.com/watch?v=d9sXZv_yy1E](https://www.youtube.com/watch?v=d9sXZv_yy1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-15 00:00:00+00:00

Some games borrow ideas from others and it works out well. Here are our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 OVERPOWERED Guns That Had To Be REMOVED (Part 2)
 - [https://www.youtube.com/watch?v=o0qoftK068E](https://www.youtube.com/watch?v=o0qoftK068E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-08-14 00:00:00+00:00

Some video game weapons are just too much. Here are some more insanely OP guns that needed to be fixed, banned, or cut from games entirely. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

