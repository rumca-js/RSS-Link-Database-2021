# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## China’s CRAZY Oculus Quest 2 Alternative
 - [https://www.youtube.com/watch?v=M2NrBNsL3xc](https://www.youtube.com/watch?v=M2NrBNsL3xc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-08-14 00:00:00+00:00

Hello and welcome to another VIRTUALLY ODD!

Today I will be going over the Pico Neo 3, essentially the Oculus Quest 2 equivalent VR headset rocking the same resolution, IPD setting, and more but there's something interesting here.. You can't buy a Quest 2 in China, but you can't buy this outside of China. Well there's a lot more to the story here and I have come to actually really enjoy this VR headset and there's more behind the scenes as to what this headset is doing directly for the Western VR market. This may not seem like competition, but it sort of is! Plus it's allowing tons of western developers to bring their games and apps to other regions. More VR for the world!

My links:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

