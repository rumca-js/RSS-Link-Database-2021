# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## $600 Million Dollar Crypto Hack - POLYNETWORK Exploit!
 - [https://www.youtube.com/watch?v=iB7hJA1Eo2I](https://www.youtube.com/watch?v=iB7hJA1Eo2I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-08-14 00:00:00+00:00

DEFI is great until someone hacks you... then it kinda sucks...

The cybercriminals exploited a vulnerability in Poly Network, a platform that looks to connect different blockchains so that they can work together. Poly Network disclosed the attack Tuesday and asked to establish communication with the hackers, urging them to “return the hacked assets.” [CNBC: https://www.cnbc.com/2021/08/11/cryptocurrency-theft-hackers-steal-600-million-in-poly-network-hack.html] 

Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryBagg96

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

## Kay's HORRIBLE Save The Kids Response In One Minute
 - [https://www.youtube.com/watch?v=G7wwlZDTq4k](https://www.youtube.com/watch?v=G7wwlZDTq4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-08-14 00:00:00+00:00

Full response coming soon.
Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryBagg96

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.
#ScamTheKids #SaveTheKay

