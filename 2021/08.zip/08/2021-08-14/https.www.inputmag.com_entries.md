## Amazon will monitor workers' keystrokes to 'combat data theft'
 - [https://www.inputmag.com/tech/amazon-will-monitor-workers-keystrokes-to-combat-data-theft-privacy-spying-surveillance](https://www.inputmag.com/tech/amazon-will-monitor-workers-keystrokes-to-combat-data-theft-privacy-spying-surveillance)
 - RSS feed: https://www.inputmag.com
 - date published: 2021-08-14 14:08:30.346902+00:00

The company defends the decision citing instances when hackers or imposters might have accessed a worker's account to steal customer information.

