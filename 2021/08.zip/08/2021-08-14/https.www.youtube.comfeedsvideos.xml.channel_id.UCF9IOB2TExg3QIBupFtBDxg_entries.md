# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Expensive treatment in US
 - [https://www.youtube.com/watch?v=VuY5Ia5XmRA](https://www.youtube.com/watch?v=VuY5Ia5XmRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-08-15 00:00:00+00:00

UK update, ONSand vaccine acceptance for children
https://www.bbc.co.uk/news/uk-51768274

https://coronavirus.data.gov.uk

Rise in covid deaths

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19/latestinsights

See more from Wefwafwa, https://www.youtube.com/channel/UCzsLklGgOttU3Se-WGLp7ow

Australia 

Cases, + 415 locally acquired

273 cases under investigation

7,745 locally acquired cases reported since 16 June 2021

Deaths, + 4 = 48 = 104

Currently in hospital, 361, (62, 24)

New restrictions now in place for all regional NSW until 22 August

Sewage surveillance program positives without identified cases

United States

Baton Rouge, LA

https://www.youtube.com/watch?v=pA6rBx7V1pg

Patients refused ICU care

https://covid.cdc.gov/covid-data-tracker/#trends_dailytrendscases

https://covid.cdc.gov/covid-data-tracker/#vaccination-trends

https://covid.cdc.gov/covid-data-tracker/#hospitalizations

Monoclonal antibodies MABS

Phased illness

https://www.evms.edu/covid-19/covid_care_protocol/

https://covid19criticalcare.com/wp-content/uploads/2020/12/FLCCC-Protocols-–-A-Guide-to-the-Management-of-COVID-19.pdf

Regeneron

Florida

Mississippi

https://www.wsj.com/articles/regeneron-covid-19-antibody-drug-reduced-risk-of-hospitalization-death-by-70-in-late-stage-trial-11616479200

https://www.washingtonpost.com/politics/2021/08/13/desantis-regeneron-florida-covid-antibodies/

Mobile clinics already operating in some areas

Governor DeSantis championed Regeneron’s monoclonal antibody cocktail

the most effective treatment that we’ve yet encountered for people who are actually infected with covid-19

best shot we’ve got right now to keep people out of the hospital and keep them safe

(has rejected mask mandates and restrictions)

70% reduction in hospitalizations, (DeSantis)

Supply?

Trump administration initially bought 300,000 doses

$1,500 per dose at the time

Federal government has now bought 1.5 million doses

Free to patients

DeSantis urged people at high risk to get the treatment at the first sign of symptoms

become part of the standard of care

Regeneron, $2.59 billion in sales

Kami Kim, division of infectious-disease, University of South Florida

The number one strategy is probably going back to social distancing again and wearing masks

And obviously, Governor DeSantis has his view on that, which most public health people would not entirely agree with

