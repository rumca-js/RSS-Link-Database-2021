# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## A peaceful night in New York City.
 - [https://www.youtube.com/watch?v=t0T15-oKEMo](https://www.youtube.com/watch?v=t0T15-oKEMo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-15 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://nypost.com/2021/08/14/nyc-shootings-leave-3-dead-overnight/
🔵 https://youtu.be/lh2j8x86jts

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Ford HACKED after donating 4 million to fearmongering cybersecurity committee 🤣
 - [https://www.youtube.com/watch?v=PpjqbsG70os](https://www.youtube.com/watch?v=PpjqbsG70os)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-15 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.bleepingcomputer.com/news/security/ford-bug-exposed-customer-and-employee-records-from-internal-systems/
🔵 https://web.archive.org/web/20200808035535/https://safeandsecuredata.org/get-the-facts/
🔵 https://ballotpedia.org/Massachusetts_Question_1,_%22Right_to_Repair_Law%22_Vehicle_Data_Access_Requirement_Initiative_(2020)#Opposition
https://youtu.be/EozPi1qmH44

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## it's getting harder to BS the public
 - [https://www.youtube.com/watch?v=clAE0C3ZX4A](https://www.youtube.com/watch?v=clAE0C3ZX4A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-08-15 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://dailygazette.com/2021/08/07/letters-to-the-editor-saturday-aug-7/
🔵 https://dailygazette.com/2021/08/14/letters-to-the-editor-saturday-aug-14/

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0 OR https://amzn.to/2W1etTj
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

