# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Augmented Reality: A Failed Promise
 - [https://www.youtube.com/watch?v=7BpwB7R7kR0](https://www.youtube.com/watch?v=7BpwB7R7kR0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-07-23 00:00:00+00:00

Augmented Reality. It’s like reality, but better.
At least that’s what they tell me.

Watch my other channel, Whimsu:
https://www.youtube.com/c/Whimsu

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
secret: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

Additional Footage Credits:

Ádám Horváth
AR MR XR
최성광
Adam C
ILMVFX
Raymond N
IGN
JSFILMZ
CNN
CNET
Engadget
lukejmu
Super Tech Camp
Rich Radke

Some External Reading Stuff:

https://www.cs.unc.edu/~azuma/ARpresence.pdf

https://www.researchgate.net/publication/349446880_Augmented_reality_using_artificial_neural_networks_-a_review

