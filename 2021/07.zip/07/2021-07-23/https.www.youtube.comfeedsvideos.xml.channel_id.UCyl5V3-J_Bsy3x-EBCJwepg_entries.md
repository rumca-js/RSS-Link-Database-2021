# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Bigoted Crossword Puzzles, Pregnant Man Emojis, and Ask A Christian Woman
 - [https://www.youtube.com/watch?v=1JxPsfCNGYI](https://www.youtube.com/watch?v=1JxPsfCNGYI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-07-23 00:00:00+00:00

In this episode, Kyle and Ethan are joined by Kristin Weber (http://www.kristinweberonline.com/), a comedian, speaker, and author of several books including Adulting For Jesus (https://www.amazon.com/Adulting-Jesus-Trusting-Obviously-Burritos/dp/0830781854). She also plays a mean accordion. Kristin gifts us with our new theme song before getting into all the weird news of the week like how human civilization has finally reached pregnant man emojis and how crossword puzzles are bigoted now. There’s also Real Things Blue Checks Say, Ask A Christian Woman, and glorious hate mail.

This episode is brought to you by The Chesterton Conference (chesterton.org/conference) happening July 29, 30, and 31 and you can even attend online! (Bee fans make sure to get your substantial discount by using promo code TheBee25!)

