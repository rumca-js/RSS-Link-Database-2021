# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## Why You Should Want Driverless Cars On Roads Now
 - [https://www.youtube.com/watch?v=yjztvddhZmI](https://www.youtube.com/watch?v=yjztvddhZmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2021-07-23 00:00:00+00:00

How close are we to having fully autonomous vehicles on the roads? Are they safe? In Chandler, Arizona a fleet of Waymo vehicles are already in operation. Waymo sponsored this video and provided access to their technology and personnel. Check out their safety report here: https://waymo.com/safety/

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
References:

Waymo Safety Reports — https://waymo.com/safety/

Driving Statistics — https://ve42.co/DrivingStats

The Real Moral Dilemma of Self-Driving Cars https://ve42.co/SelfDriving

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Special thanks to Patreon supporters: 
Alvaro naranjo, Burt Humburg, Blake Byers, Dumky, Mike Tung, Evgeny Skvortsov, Meekay, Ismail Öncü Usta, Paul Peijzel, Crated Comments, Anna, Mac Malkawi, Michael Schneider, Oleksii Leonov, Jim Osmun, Tyson McDowell, Ludovic Robillard, Jim buckmaster, fanime96, Juan Benet, Ruslan Khroma, Robert Blum, Richard Sundvall, Lee Redden, Vincent, Marinus Kuivenhoven, Alfred Wallace, Arjun Chakroborty, Joar Wandborg, Clayton Greenwell, Pindex, Michael Krugman, Cy 'kkm' K'Nelson, Sam Lutfi, Ron Neal 

▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ 
Animation by Fabio Albertelli and Jakub Misiek
Edited by Trenton Oliver
Audio Mix and SFX by Shaun Clifford
Music by Epidemic Sound https://epidemicsound.com 
Additional video supplied by Getty Images and Pond 5
Produced by Derek Muller, Emily Zhang and Petr Lebedev

