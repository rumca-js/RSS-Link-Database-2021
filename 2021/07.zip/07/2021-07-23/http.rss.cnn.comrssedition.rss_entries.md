# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Unvaccinated nursing instructor in Missouri is hospitalized with Covid and urging everyone to get the vaccine
 - [https://www.cnn.com/collections/us-covid-0723/](https://www.cnn.com/collections/us-covid-0723/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 23:17:33+00:00



## Fear stalks Haitians as their murdered president is buried and gangs terrorize the capital
 - [https://www.cnn.com/2021/07/23/americas/haiti-moise-kidnappings-refugees-insecurity-intl-cmd/index.html](https://www.cnn.com/2021/07/23/americas/haiti-moise-kidnappings-refugees-insecurity-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 23:10:57+00:00

Kidnapped from church, shot at during an evening commute, chased out of their homes as flames licked up the street.

## Thieves in California are stealing scarce water amid extreme drought
 - [https://www.cnn.com/2021/07/22/us/california-water-thieves-drought/index.html](https://www.cnn.com/2021/07/22/us/california-water-thieves-drought/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 22:31:37+00:00

As an extreme drought grips California, making water increasingly scarce, thieves are making off with billions of gallons of the precious resource, tapping into fire hydrants, rivers, and even small family homes and farms.

## Opinion: Opening Ceremony for the ages? That's an understatement
 - [https://www.cnn.com/2021/07/23/opinions/olympics-opening-ceremony-naomi-osaka-bass/index.html](https://www.cnn.com/2021/07/23/opinions/olympics-opening-ceremony-naomi-osaka-bass/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 20:47:37+00:00

As thousands gathered outside Olympic Stadium, some in protest, wielding signs that read, "Cancel the Olympics -- Save Lives," and some in support, with signs that read, "I believe in the power of sport," the Tokyo Olympic Games Opening Ceremony asked us to Imagine. With clouds of drones coalescing in the sky to form an image of the Earth, alongside the lyrics of John Lennon's signature song -- sung by an international array of performers that included Americans John Legend and Keith Urban -- the spectacle's theme, "moving forward," became clear.

## Cleveland Indians changing name to Cleveland Guardians
 - [https://www.cnn.com/2021/07/23/us/cleveland-major-league-baseball-name/index.html](https://www.cnn.com/2021/07/23/us/cleveland-major-league-baseball-name/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 19:29:11+00:00

The Cleveland Indians are changing their name next season to the Cleveland Guardians, the Major League Baseball club announced Friday morning, after the old moniker drew criticism for decades from Native Americans.

## Olympic events to watch this weekend
 - [https://www.cnn.com/2021/07/23/entertainment/olympic-schedule-events-today-spt/index.html](https://www.cnn.com/2021/07/23/entertainment/olympic-schedule-events-today-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 19:18:44+00:00

The torch has been lit at the Tokyo Olympics and the opening weekend will feature competition in men's gymnastics, women's soccer, swimming, tennis and more.

## Trump ally strikes a $250 million bail deal to get out of jail
 - [https://www.cnn.com/collections/tom-barrack-072321/](https://www.cnn.com/collections/tom-barrack-072321/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 18:53:48+00:00



## A 'Big Eyes' painting stolen in 1972 has been returned to the family that owned it
 - [https://www.cnn.com/style/article/stolen-keane-painting-returned-trnd/index.html](https://www.cnn.com/style/article/stolen-keane-painting-returned-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 18:07:52+00:00

A stolen painting by famed American artist Margaret Keane is back home with its original owners -- including one of the women depicted in the portrait -- almost 50 years after someone swiped it from a Honolulu dentist's office.

## British lawmaker thrown out for calling Boris Johnson a liar
 - [https://www.cnn.com/videos/world/2021/07/23/mp-thrown-out-for-saying-boris-johnson-lied-orig-cb-jk.cnn](https://www.cnn.com/videos/world/2021/07/23/mp-thrown-out-for-saying-boris-johnson-lied-orig-cb-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 17:38:00+00:00

Dawn Butler, an MP for Britain's Labour Party, was thrown out for breaking the rules in the House of Commons.

## The Kavanaugh news proves it's impossible to have an apolitical Supreme Court
 - [https://www.cnn.com/collections/kavanaugh-072321/](https://www.cnn.com/collections/kavanaugh-072321/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 17:11:17+00:00



## Gun that killed Wild West outlaw Billy the Kid goes to auction
 - [https://www.cnn.com/2021/07/23/world/billy-the-kid-gun-scli-intl/index.html](https://www.cnn.com/2021/07/23/world/billy-the-kid-gun-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 17:04:45+00:00

The gun used to kill the notorious Wild West outlaw Billy the Kid 140 years ago is going to public auction for the first time -- with an estimated selling price of $2-3 million.

## Trump isn't putting his money where his mouth is on election 'fraud'
 - [https://www.cnn.com/2021/07/23/politics/donald-trump-election-fraud-2020/index.html](https://www.cnn.com/2021/07/23/politics/donald-trump-election-fraud-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 17:01:12+00:00

These two paragraphs from The Washington Post are both unsurprising and deeply troubling:

## The Kavanaugh news proves it's impossible to have an apolitical Supreme Court
 - [https://www.cnn.com/2021/07/23/politics/brett-kavanaugh-supreme-court-fbi/index.html](https://www.cnn.com/2021/07/23/politics/brett-kavanaugh-supreme-court-fbi/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 16:56:32+00:00



## Sean Penn won't return to 'Gaslit' set unless all cast and crew receive Covid vaccinations
 - [https://www.cnn.com/2021/07/23/entertainment/sean-penn-gaslit-vaccination-intl-scli/index.html](https://www.cnn.com/2021/07/23/entertainment/sean-penn-gaslit-vaccination-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 16:41:57+00:00

Sean Penn will not return to the set of his new show "Gaslit" until the entire cast and crew have received Covid vaccinations, the star's representative confirmed to CNN on Friday.

## Ancient viruses dating back 15,000 years found in Tibetan glacier
 - [https://www.cnn.com/2021/07/23/asia/climate-ancient-viruses-glacier-scli-intl-scn/index.html](https://www.cnn.com/2021/07/23/asia/climate-ancient-viruses-glacier-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 16:08:40+00:00

Scientists have discovered previously unknown viruses dating from 15,000 years ago in ice samples taken from a glacier in the Tibetan plateau.

## Video shows Yorkie chase coyote away from 10-year-old girl
 - [https://www.cnn.com/videos/world/2021/07/23/yorkie-dog-rescue-child-from-coyote-mxp-hln-vpx.hln](https://www.cnn.com/videos/world/2021/07/23/yorkie-dog-rescue-child-from-coyote-mxp-hln-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 15:27:49+00:00

Macy the Yorkshire terrier becomes a hero after rescuing 10-year-old Lily Kwan from a coyote. HLN's Robin Meade reports.

## Eight months of long Covid brought me to the brink
 - [https://www.cnn.com/2021/07/23/opinions/long-covid-symptoms-brought-me-to-the-brink-stephens/index.html](https://www.cnn.com/2021/07/23/opinions/long-covid-symptoms-brought-me-to-the-brink-stephens/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 14:56:43+00:00

As Americans continue to become infected with the new highly contagious Delta variant of the coronavirus -- and every US state and Washington DC sees a rise in Covid-19 cases, about 10%, doctors say, will go on to develop what I've been struggling with for months: long Covid-19 — or lingering symptoms post-infection that are difficult to diagnose.

## Why you're getting less cereal for the same money
 - [https://www.cnn.com/2021/07/23/business/shrinkflation-prices-grocery-stores/index.html](https://www.cnn.com/2021/07/23/business/shrinkflation-prices-grocery-stores/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 14:27:53+00:00

Less cereal in the box. Smaller snack sizes. Ice cream gone missing in a container.

## Governor of Alabama: It's time to start blaming unvaccinated folks
 - [https://www.cnn.com/videos/us/2021/07/23/alabama-governor-ivey-covid-19-vaccinations-newsroom-vpx.cnn](https://www.cnn.com/videos/us/2021/07/23/alabama-governor-ivey-covid-19-vaccinations-newsroom-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 13:40:02+00:00

Alabama Governor Kay Ivey spoke out against the unvaccinated population in Alabama and says it's time to start blaming them for not doing their part in the pandemic.

## FBI says it got more than 4,500 tips on Kavanaugh, providing 'relevant' ones to Trump White House
 - [https://www.cnn.com/2021/07/22/politics/fbi-kavanaugh-ford-investigation/index.html](https://www.cnn.com/2021/07/22/politics/fbi-kavanaugh-ford-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 13:38:06+00:00

The FBI disclosed that it received more than 4,500 tips on a phone line in 2018 as part of a background investigation into then-Supreme Court nominee Brett Kavanaugh and provided "relevant" ones to former President Donald Trump's White House counsel.

## See what life was like in the Olympic Village in 1984
 - [https://www.cnn.com/videos/business/2021/07/19/1984-olympic-village-los-angeles-vault-zw-orig.cnn-business](https://www.cnn.com/videos/business/2021/07/19/1984-olympic-village-los-angeles-vault-zw-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 12:58:17+00:00

During the 1984 Olympic Games, CNN went inside the Olympic Village in Los Angeles to see what life was like for the greatest athletes of their day. See how the technology -- and security -- has changed in this video from the CNN archives.

## State Department suspends passport online booking system because of bots
 - [https://www.cnn.com/2021/07/23/politics/state-department-booking-system/index.html](https://www.cnn.com/2021/07/23/politics/state-department-booking-system/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 12:56:14+00:00

The US State Department on Wednesday evening temporarily suspended an online booking system used for urgent appointments because of bots, according to an update posted to its consular affairs website.

## Extreme weather events put spotlight on climate change's toll on US infrastructure
 - [https://www.cnn.com/2021/07/23/politics/infrastructure-extreme-weather-climate-change/index.html](https://www.cnn.com/2021/07/23/politics/infrastructure-extreme-weather-climate-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 12:41:38+00:00

America's infrastructure has taken a beating from extreme weather events in recent weeks spurred by climate change, raising concerns among officials that the nation's roads, bridges and even commercial flights can't stand the severe conditions.

## Adorable animal takes 'extraordinary' 600-mile trip
 - [https://www.cnn.com/videos/us/2021/07/23/marmot-takes-600-mile-road-trip-orig-bdk.cnn](https://www.cnn.com/videos/us/2021/07/23/marmot-takes-600-mile-road-trip-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 12:21:38+00:00

Wildlife officials in Arizona got a big surprise when they found out the marmot they trapped had traveled to the Phoenix area all the way from Crested Butte, Colorado.

## Lebanon's water system on brink of total collapse, says UN
 - [https://www.cnn.com/2021/07/23/middleeast/lebanon-water-collapse-intl/index.html](https://www.cnn.com/2021/07/23/middleeast/lebanon-water-collapse-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 12:03:01+00:00

Lebanon's water supply system is on the verge of total collapse, according to the United Nations Children's Fund (UNICEF), in what would mark the latest development in the eastern Mediterranean country's slide into chaos.

## African countries to receive six million Johnson and Johnson vaccines, the African Union says
 - [https://www.cnn.com/2021/07/23/africa/africa-receives-jj-vaccines-intl/index.html](https://www.cnn.com/2021/07/23/africa/africa-receives-jj-vaccines-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 11:39:04+00:00

Around six million doses of the single-shot Johnson & Johnson coronavirus vaccine will be delivered by the African Union to 27 African nations that have paid for the shipments through the end of August, an AU special envoy said on Thursday.

## See Tokyo 2020 Olympics from above
 - [https://www.cnn.com/videos/world/2021/07/23/cnn-flies-over-tokyo-olympics-2020-ripley-dnt-vpx.cnn](https://www.cnn.com/videos/world/2021/07/23/cnn-flies-over-tokyo-olympics-2020-ripley-dnt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 10:55:38+00:00

CNN's Will Ripley takes a look at the city of Tokyo ahead of the 2020 Olympics, where a growing number of athletes have tested positive for Covid-19 and venues sit nearly empty.

## UK sanctions Equatorial Guinea leader's son over 'lavish lifestyle' spending
 - [https://www.cnn.com/2021/07/23/africa/uk-sanctions-teodoro-obiang-intl/index.html](https://www.cnn.com/2021/07/23/africa/uk-sanctions-teodoro-obiang-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 10:48:37+00:00

Britain on Thursday sanctioned the son of Equatorial Guinea's president for misappropriating millions of dollars which London said was spent on luxury mansions, private jets and a $275,000 glove worn by Michael Jackson.

## 'The biggest mistake of my life': Why this woman is turning on Bolsonaro
 - [https://www.cnn.com/videos/world/2021/07/23/jair-bolsonaro-brazil-covid-crisis-corruption-allegations-soares-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/07/23/jair-bolsonaro-brazil-covid-crisis-corruption-allegations-soares-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 10:23:33+00:00

Brazilian President Jair Bolsonaro is the subject of public wrath over his mismanagement of the Covid crisis and a growing vaccine scandal that could engulf his presidency. CNN's Isa Soares reports.

## Seagull smacks into teen on amusement park ride
 - [https://www.cnn.com/videos/travel/2021/07/22/seagull-amusement-park-ride-midair-collision-moos-pkg-vpx.cnn](https://www.cnn.com/videos/travel/2021/07/22/seagull-amusement-park-ride-midair-collision-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 10:19:34+00:00

A teenager got smacked by a seagull while on an amusement park ride. CNN's Jeanne Moos reports on the midair collision.

## Tennessee to remove bust of Ku Klux Klan leader from state Capitol
 - [https://www.cnn.com/2021/07/23/us/kkk-leader-bust-removed-tn-capitol/index.html](https://www.cnn.com/2021/07/23/us/kkk-leader-bust-removed-tn-capitol/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 09:16:56+00:00

Tennessee officials voted Thursday to remove the bust of a Ku Klux Klan and Confederate leader Nathan Bedford Forrest from the State Capitol and into the Tennessee State Museum.

## Tragic death of translator highlights plight of allies left behind in Afghanistan
 - [https://www.cnn.com/videos/world/2021/07/14/afghanistan-translator-coren-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/07/14/afghanistan-translator-coren-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 08:46:10+00:00

CNN's Anna Coren speaks with Afghan interpreters who risked their lives helping the US government, and now face reprisals from the Taliban as many of them struggle to secure US visas and protection.

## US strikes Taliban and captured equipment in support of Afghan forces
 - [https://www.cnn.com/2021/07/22/politics/us-taliban-airstrikes/index.html](https://www.cnn.com/2021/07/22/politics/us-taliban-airstrikes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 03:08:47+00:00

The US military carried out two strikes against the Taliban overnight in support of Afghan forces in the Kandahar province, multiple defense officials said, targeting captured equipment.

## 'Just get the stupid shot': Unvaccinated mom who got coronavirus
 - [https://www.cnn.com/videos/health/2021/07/23/unvaccinated-mom-coronavirus-vaccine-kaye-pkg-ac360-vpx.cnn](https://www.cnn.com/videos/health/2021/07/23/unvaccinated-mom-coronavirus-vaccine-kaye-pkg-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 03:08:16+00:00

After choosing not to get the Covid-19 vaccine, Ganeene Starling ended up in the ICU with coronavirus and was given a 20% chance of survival by doctors. Starling speaks with CNN's Randi Kaye about her experience.

## Afghan interpreter for US Army was beheaded by Taliban. Others fear they will be hunted down too
 - [https://www.cnn.com/2021/07/22/asia/afghanistan-interpreters-taliban-reprisals-intl-hnk/index.html](https://www.cnn.com/2021/07/22/asia/afghanistan-interpreters-taliban-reprisals-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 02:05:57+00:00

Sohail Pardis was driving from his home in Afghanistan's capital Kabul to nearby Khost province to pick up his sister for the upcoming Eid holiday celebrations to mark the end of Ramadan.

## Covid-19 casts shadow over Tokyo Olympics
 - [https://www.cnn.com/2021/07/22/sport/tokyo-olympics-preview-spt-intl/index.html](https://www.cnn.com/2021/07/22/sport/tokyo-olympics-preview-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 01:49:09+00:00

• See the Tokyo Olympics from above

## Ex-nurse didn't get vaccinated, then she was hospitalized with Covid-19. Hear her message
 - [https://www.cnn.com/videos/health/2021/07/23/coronavirus-vaccine-missouri-nurse-marquez-pkg-vpx-lead.cnn](https://www.cnn.com/videos/health/2021/07/23/coronavirus-vaccine-missouri-nurse-marquez-pkg-vpx-lead.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 01:29:55+00:00

A handful of states have been driving the bulk of the nationwide surge of Covid-19 cases and many of those cases are unvaccinated people. CNN's Miguel Marquez reports.

## NFL assistant coach dies following bicycle crash
 - [https://www.cnn.com/2021/07/22/us/greg-knapp-new-york-jets-assistant-coach-dies-spt/index.html](https://www.cnn.com/2021/07/22/us/greg-knapp-new-york-jets-assistant-coach-dies-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 01:17:03+00:00

New York Jets assistant coach Greg Knapp has died, five days after being involved in a bicycling crash, the Knapp family announced on Thursday. He was 58.

## Emilia Clarke's rapid-fire accents blow away Fallon
 - [https://www.cnn.com/videos/media/2021/07/22/emilia-clarke-tonight-show-good-4-u-accents-orig-ah.cnn](https://www.cnn.com/videos/media/2021/07/22/emilia-clarke-tonight-show-good-4-u-accents-orig-ah.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-23 00:29:24+00:00

Actress Emilia Clarke impressed Jimmy Fallon on The Tonight Show by reciting lyrics from Olivia Rodrigo's "good 4 u" in eight different accents.

