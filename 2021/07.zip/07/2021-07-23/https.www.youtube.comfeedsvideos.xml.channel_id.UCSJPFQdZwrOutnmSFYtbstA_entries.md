# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Masters of the Universe: Revelation - Absolute Disaster
 - [https://www.youtube.com/watch?v=u6GUGatFBLo](https://www.youtube.com/watch?v=u6GUGatFBLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-07-24 00:00:00+00:00

Masters of the Universe: Revelation, courtesy of Kevin Smith and Netflix, is the latest classic franchise to be utterly butchered by today's entertainment hacks.

