## Ottawa outlines new legislation to define and crack down on online hate speech | CBC News
 - [https://www.cbc.ca/news/politics/hate-speech-bill-c36-1.6077606](https://www.cbc.ca/news/politics/hate-speech-bill-c36-1.6077606)
 - RSS feed: https://www.cbc.ca
 - date published: 2021-07-23 16:36:52+00:00

Ottawa outlines new legislation to define and crack down on online hate speech | CBC News

