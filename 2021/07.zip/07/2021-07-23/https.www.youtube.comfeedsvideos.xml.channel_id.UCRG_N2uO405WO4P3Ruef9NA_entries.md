# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## MediaTek gaming PCs are coming!
 - [https://www.youtube.com/watch?v=eG1gDFbOFaI](https://www.youtube.com/watch?v=eG1gDFbOFaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-07-23 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc

You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us. 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week, Nvidia demoed their graphics cards working with MediaTek chips and Linux, WearOS got multiple shots in the arm and new right to repair rules were passed by the US FTC.

Episode 55

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-mediatek-pcs-are-coming

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:32 Release Monitor
1:33 MediaTek x Nvidia computers
2:52 WearOS isn't dead yet
4:45 Right to repair

