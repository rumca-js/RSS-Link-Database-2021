## Exclusive: Discord is getting threads – this is what it looks like | TechRadar
 - [https://www.techradar.com/news/threads-are-finally-coming-to-discord](https://www.techradar.com/news/threads-are-finally-coming-to-discord)
 - RSS feed: https://www.techradar.com
 - date published: 2021-07-23 15:20:33.364012+00:00

One of the most useful Discord features yet

