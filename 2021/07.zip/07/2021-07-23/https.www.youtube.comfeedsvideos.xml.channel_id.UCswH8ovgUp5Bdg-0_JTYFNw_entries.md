# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is THIS Why We Were Lied To About Psychedelics?!
 - [https://www.youtube.com/watch?v=qwh1SqWxW3E](https://www.youtube.com/watch?v=qwh1SqWxW3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-24 00:00:00+00:00

New studies show MDMA could help cure PTSD. Why have the benefits of psychedelics as a psychiatric treatment been buried for over half a century? 
#psychedelics #MDMA #MagicMushrooms 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

Get passes to my show Our Little Lives: Shakespeare & Me. It's streaming on Live Now on July 14th. http://bit.ly/3godW5g

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

___________________________________
Click the link below to subscribe below to my Youtube Channel:

http://www.youtube.com/c/RussellBrand?sub_confirmation=1


For meditation and breath work, subscribe to my side-channel: 

http://www.youtube.com/c/AwakeningWithRussell?sub_confirmation=1
___________________________________

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## Russell Brand Reacts To His Viral Jeremy Paxman Interview
 - [https://www.youtube.com/watch?v=LXHqPnh1rp0](https://www.youtube.com/watch?v=LXHqPnh1rp0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-23 00:00:00+00:00

In this video, I take you through one of my favourite VIRAL moments with interlocutor Jeremy Paxman. I share some of the ways I parry and handle confrontation. 

#JeremyPaxman #viralvideos #confrontation #BBC #BBCNewsnight

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

Get passes to my show Our Little Lives: Shakespeare & Me. It's streaming on Live Now on July 14th. http://bit.ly/3godW5g

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

___________________________________
Click the link below to subscribe below to my Youtube Channel:

http://www.youtube.com/c/RussellBrand?sub_confirmation=1


For meditation and breath work, subscribe to my side-channel: 

http://www.youtube.com/c/AwakeningWithRussell?sub_confirmation=1
___________________________________

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

