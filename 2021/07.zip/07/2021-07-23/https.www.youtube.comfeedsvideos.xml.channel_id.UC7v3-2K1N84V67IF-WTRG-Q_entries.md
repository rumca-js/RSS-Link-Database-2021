# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Old - Movie Review
 - [https://www.youtube.com/watch?v=JbiaKC-rSTU](https://www.youtube.com/watch?v=JbiaKC-rSTU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-07-24 00:00:00+00:00

M. Night Shyamalan brings us another cinematic thriller, which revolves around a beach where people rapidly age. Curiosity piqued, so let's review OLD!

#Old #OldMovie

## Snake Eyes - Movie Review
 - [https://www.youtube.com/watch?v=MAWucYmwI8o](https://www.youtube.com/watch?v=MAWucYmwI8o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-07-23 00:00:00+00:00

Snake Eyes gets an origin movie in an attempt to reboot the G.I. Joe on the big screen. No WAY Hollywood will screw this up.....here's my review for SNAKE EYES!

#SnakeEyes #GIJoe

