# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 HIDDEN Mechanics Big Games Never Tell You About [Part 2]
 - [https://www.youtube.com/watch?v=VKrF_NQRqJY](https://www.youtube.com/watch?v=VKrF_NQRqJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-24 00:00:00+00:00

Some games use clever tricks behind the scenes to make gameplay even better. Here are more of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## GTA 6 MAP LEAK DEBUNKED, NEW PS5 MODEL? & MORE
 - [https://www.youtube.com/watch?v=gpn1Ualb4BI](https://www.youtube.com/watch?v=gpn1Ualb4BI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-23 00:00:00+00:00

Go to https://www.expressvpn.com/gameranx and find out how you can get 3 months of ExpressVPN free! Thanks to ExpressVPN for sponsoring this video.


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake's other channel: https://youtu.be/He7LV38FAXI



 ~~~~STORIES~~~~


GTA 6 debunked
https://charlieintel.com/gta-6-leak-shows-off-alleged-vice-city-theme-park/115829/

New PS5
https://www.psu.com/news/new-ps5-digital-edition-model-revision-coming-weighs-300-grams-lighter/

Dead Space remake
https://www.gameinformer.com/2021/07/23/new-dead-space-remake-details-revealed-including-zero-loading-screens-and-learning-from


BF 2042 portal mode
https://youtu.be/q4qWMcQfOCc

Apex Legends Emergence
https://youtu.be/N5hVbkojZa0


Neil Blomkaamp game
https://twitter.com/VG247/status/1417578810111889408

Death’s Door trailer
https://youtu.be/D_tmwz-AhgQ

Free stuff on PS5
https://twitter.com/PlayStation/status/1418586781407006722

Steam Deck info: 
https://youtu.be/e3HnDR7A8yE


New Ubisoft shooter
https://youtu.be/nmlhRFabV6w


GTA Online expansion 
https://youtu.be/mP6KvFnltWc


Ghost of Tsushima expansion
https://youtu.be/UCwWTaZoLPo

Activision Blizzard sued
https://www.gameinformer.com/2021/07/22/lawsuit-document-against-activision-blizzard-details-a-long-history-of-harassment-and


Follow up from last week - Netflix gaming
https://twitter.com/getFANDOM/status/1417595516540493824

