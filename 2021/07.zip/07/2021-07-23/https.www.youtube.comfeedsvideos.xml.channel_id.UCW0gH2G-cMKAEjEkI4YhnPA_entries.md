# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete Travels of Bilbo Baggins | Tolkien Explained
 - [https://www.youtube.com/watch?v=uwmtKlLxDA8](https://www.youtube.com/watch?v=uwmtKlLxDA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-07-24 00:00:00+00:00

Bilbo Baggins is Middle-earth's most adventurous hobbit. Today, we cover his complete life of travels, from his early efforts to see elves and dwarves, to his famous Quest of Erebor, to his return to Dale and Rivendell later in life.

*Hit subscribe - and the bell!* 
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Jenny Dolfen - goldseven.wordpress.com/

Bilbo Baggins - Mike Szabados
Female hobbit - Kiikii sempai
The Young Bilbo - Sara M Morello
Bilbo's Eleventy-First Birthday - Joe Gilronan
Gandalf Tells a Story - Joanna Pasek
Bag End - Wictorian Art
Shire Map - Maxime Plasse
Good Morning, Gandalf and Bilbo - Donato Giancola
An Unexpected Party - Alan Lee
An Unexpected Party - John Howe
Bilbo and the Dwarves - Alan Lee
Trolls - John Paul Cavara
The Trolls See the Dawn - Alan Lee
Over Hill - Bilbo and Gandalf - Joel Lee
In the House of Elrond - Abe Papakhian
Glamdring - Paul Raymond Gregory
Hiding the Ring - Frank Rivolli
The Hobbit, Gollum and Bilbo - Ranghos
The Wargs - Alan Lee
Elvish Feast in Mirkwood - Ullakko
Elves - faqy
Bilbo and Spiders - Marc Daniel Goecke
Sting - Wes Talbott
Entering Mirkwood - Ted Nasmith
Thorin Oakenshield - John Howe
Barrels Out of Bond - Alan Lee
Esgaroth, Lake-town - Alanise
Bilbo and the Thrush - Alarie
Bilbo and Smaug - Diego Gisbertllorens
On the Doorstep - Chris Rahn
Smaug the Destroyer - Ted Nasmith
Balin - Turner Mohan
Thorin Suffering from Dragon Sickness - CF Griffith
Thorin Bestows Gifts Upon Bilbo - John Howe
Roac, son of Carc - John Howe
The Arkenstone - Ted Nasmith
The Battle of Five Armies - Matt Stewart
Battle of Five Armies - Justin Gerard
Farewell, King Under the Mountain - Donato Giancola
The Passing of Thorin Oakenshield - Abe Papakhian
Yule tide in Beorn's House - Mirachravaia
Bilbo Baggins Concept Art - Paul Tobin (WETA)
Summer at Bag End - Kelleybean86
Visit to Bilbo - Alan Lee
Bilbo and Frodo - Mensuramjr
Bilbo - Raoul Vitale
Bilbo at Rivendell - The Brothers Hildebrandt
Rivendell - Jerry Vanderstelt
The Council of Elrond - Mysilvergreen
Bilbo and Frodo - Anke Eissmann
Bilbo at Rivendell - Alan Lee
On the Road to the Grey Havens - Victoria Clare
Departure at the Grey Havens - Ted Nasmith

For more on Bilbo Baggins, check out these great resources:
The Hobbit
The Lord of the Rings
The Encyclopedia of Arda
Tolkien Gateway
TheOneRing Daily Middle-earth Calendar

#bilbo #hobbit #lordoftherings

