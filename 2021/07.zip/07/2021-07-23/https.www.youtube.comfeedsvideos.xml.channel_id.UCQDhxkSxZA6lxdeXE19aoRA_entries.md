# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Revolting 1970s Computer Deep Cleaning
 - [https://www.youtube.com/watch?v=xffIohMseVg](https://www.youtube.com/watch?v=xffIohMseVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-07-24 00:00:00+00:00

Its time this filthy 1970s computer got a much needed clean.
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Tools I Use: https://www.hughjeffreys.com/tools

Get parts, tools, and thousands of free repair guides from iFixit at: 
                               https://iFixit.com/hughjeffreys
Australian Store: https://ifix.gd/2FPxhKy
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

