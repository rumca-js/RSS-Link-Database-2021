## Migrating Facebook to MySQL 8.0 - Facebook Engineering
 - [https://engineering.fb.com/2021/07/22/data-infrastructure/mysql/](https://engineering.fb.com/2021/07/22/data-infrastructure/mysql/)
 - RSS feed: https://engineering.fb.com
 - date published: 2021-07-23 09:37:08.839937+00:00

We are sharing how we tackled the migration to MySQL 8.0 — and some of the surprises we had in the process.

