# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#244] Jak się nauczyć kochać słabości innych?
 - [https://www.youtube.com/watch?v=ZHH9L5FmX2g](https://www.youtube.com/watch?v=ZHH9L5FmX2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-24 00:00:00+00:00

@Langustanapalmie 

1. czytanie (2 Krl 4, 42-44)

Pewien człowiek przyszedł z Baal-Szalisza, przynosząc mężowi Bożemu, Elizeuszowi, chleb z pierwocin, dwadzieścia chlebów jęczmiennych i świeże zboże w worku. On zaś rozkazał: «Podaj ludziom i niech jedzą!» Lecz sługa jego odrzekł: «Jakże to rozdzielę między stu ludzi?»
A on odpowiedział: «Podaj ludziom i niech jedzą, bo tak mówi Pan: Nasycą się i pozostawią resztki». Położył więc to przed nimi, a ci jedli i pozostawili resztki – według słowa Pańskiego.

2. czytanie (Ef 4, 1-6)

Bracia: Zachęcam was ja, więzień w Panu, abyście postępowali w sposób godny powołania, do jakiego zostaliście wezwani, z całą pokorą i cichością, z cierpliwością, znosząc siebie nawzajem w miłości. Usiłujcie zachować jedność Ducha dzięki więzi, jaką jest pokój.
Jedno jest Ciało i jeden Duch, bo też zostaliście wezwani do jednej nadziei, jaką daje wasze powołanie. Jeden jest Pan, jedna wiara, jeden chrzest. Jeden jest Bóg i Ojciec wszystkich, który jest i działa ponad wszystkimi, przez wszystkich i we wszystkich.

Ewangelia (J 6, 1-15)

Jezus udał się na drugi brzeg Jeziora Galilejskiego, czyli Tyberiadzkiego. Szedł za Nim wielki tłum, bo oglądano znaki, jakie czynił dla tych, którzy chorowali. Jezus wszedł na wzgórze i usiadł tam ze swoimi uczniami. A zbliżało się święto żydowskie, Pascha. Kiedy więc Jezus podniósł oczy i ujrzał, że liczne tłumy schodzą się do Niego, rzekł do Filipa: «Gdzie kupimy chleba, aby oni się najedli?» A mówił to, wystawiając go na próbę. Wiedział bowiem, co ma czynić. Odpowiedział Mu Filip: «Za dwieście denarów nie wystarczy chleba, aby każdy z nich mógł choć trochę otrzymać».
Jeden z Jego uczniów, Andrzej, brat Szymona Piotra, rzekł do Niego: «Jest tu jeden chłopiec, który ma pięć chlebów jęczmiennych i dwie ryby, lecz cóż to jest dla tak wielu?» Jezus zaś rzekł: «Każcie ludziom usiąść». A w miejscu tym było wiele trawy. Usiedli więc mężczyźni, a liczba ich dochodziła do pięciu tysięcy. Jezus więc wziął chleby i odmówiwszy dziękczynienie, rozdał siedzącym; podobnie uczynił i z rybami, rozdając tyle, ile kto chciał. A gdy się nasycili, rzekł do uczniów: «Zbierzcie pozostałe ułomki, aby nic nie zginęło». Zebrali więc i ułomkami z pięciu chlebów jęczmiennych, pozostałymi po spożywających, napełnili dwanaście koszów. A kiedy ludzie spostrzegli, jaki znak uczynił Jezus, mówili: «Ten prawdziwie jest prorokiem, który ma przyjść na świat». Gdy więc Jezus poznał, że mieli przyjść i porwać Go, aby Go obwołać królem, sam usunął się znów na górę.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Wyjścia || Rozdział 38
 - [https://www.youtube.com/watch?v=eyVSO3xb33I](https://www.youtube.com/watch?v=eyVSO3xb33I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-24 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#845] Na twardo
 - [https://www.youtube.com/watch?v=ZzP8LvAwgjs](https://www.youtube.com/watch?v=ZzP8LvAwgjs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-24 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Wyjścia || Rozdział 37
 - [https://www.youtube.com/watch?v=PMhTIsb3hk4](https://www.youtube.com/watch?v=PMhTIsb3hk4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-23 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#844] Cóż może?
 - [https://www.youtube.com/watch?v=C9qYzJguVdg](https://www.youtube.com/watch?v=C9qYzJguVdg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-23 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

