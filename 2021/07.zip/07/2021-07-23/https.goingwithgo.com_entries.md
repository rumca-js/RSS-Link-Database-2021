## Building Business Applications in Go - Three Dots Labs
 - [https://goingwithgo.com/2021/07/building-business-applications-in-golang-three-dots-labs/](https://goingwithgo.com/2021/07/building-business-applications-in-golang-three-dots-labs/)
 - RSS feed: https://goingwithgo.com
 - date published: 2021-07-23 23:13:08.596382+00:00

Miłosz Smółka is one of the co-founders of Three Dots Labs - a consulting and development agency specializing in building business applications in Go.

