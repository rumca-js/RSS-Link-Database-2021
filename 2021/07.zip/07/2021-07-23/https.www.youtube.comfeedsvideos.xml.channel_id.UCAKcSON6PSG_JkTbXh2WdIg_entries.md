# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Yola - Stand For Myself (live performance for The Current)
 - [https://www.youtube.com/watch?v=QsXfnM0uUeA](https://www.youtube.com/watch?v=QsXfnM0uUeA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-24 00:00:00+00:00

Yola plays the title track from her upcoming record, 'Stand For Myself', coming out on @EasyEyeSound.

Don't miss Yola's full virtual session, including an interview about playing Sister Rosetta Tharpe in the upcoming Baz Luhrmann film 'Elvis,' and how her childhood musical influences came through on the new record: https://youtu.be/PQEdil-40SE

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Yola - Starlight (live performance for The Current)
 - [https://www.youtube.com/watch?v=-qaBK6Y49Bo](https://www.youtube.com/watch?v=-qaBK6Y49Bo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-24 00:00:00+00:00

Yola plays "Diamond Studded Shoes" from her upcoming record, 'Stand For Myself', coming out on @EasyEyeSound.

Don't miss Yola's full virtual session, including an interview about playing Sister Rosetta Tharpe in the upcoming Baz Luhrmann film 'Elvis,' and how her childhood musical influences came through on the new record: https://youtu.be/PQEdil-40SE

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Yola plays songs from Stand For Myself (live performance for The Current)
 - [https://www.youtube.com/watch?v=f0KIptymZc4](https://www.youtube.com/watch?v=f0KIptymZc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-24 00:00:00+00:00

Yola plays three tracks from her upcoming record, 'Stand For Myself', coming out July 2021 on @EasyEyeSound.

Songs Played:
00:01 Diamond Studded Shoes
03:37 Stand For Myself
07:56 Starlight

Don't miss Yola's full virtual session, including an interview about playing Sister Rosetta Tharpe in the upcoming Baz Luhrmann film 'Elvis,' and how her childhood musical influences came through on the new record: https://youtu.be/PQEdil-40SE

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Shungudzo - It's a good day (to fight the system) (live performance for The Current)
 - [https://www.youtube.com/watch?v=M5sDOep8UPY](https://www.youtube.com/watch?v=M5sDOep8UPY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-23 00:00:00+00:00

Zimbabwean-American artist Shungudzo joins The Current to share a performance of "It's a good day (to fight the system)" which appears on her debut record, 'I am not a mother, but I have children'.

Don't miss @Shungudzo's full interview with The Current's Mary Lucia about   the ways poetry are intertwined with her songwriting, her experiences as a child moving from Zimbabwe to the US, and what she's got planned for the fall: https://youtu.be/qloTMIT_pWI

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Shungudzo performs songs from 'I'm not a mother, but I have children'
 - [https://www.youtube.com/watch?v=zuL9nToegLw](https://www.youtube.com/watch?v=zuL9nToegLw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-23 00:00:00+00:00

Zimbabwean-American artist Shungudzo joins The Current to share performances of songs from her debut record, 'I'm not a mother, but I have children'.

Songs Played:
00:01 It's a good day (to fight the system)
03:16 There's only so much a soul can take
06:20 To be me
10:14 I'm not a mother, but I have children

Don't miss @Shungudzo's full interview with The Current's Mary Lucia about   the ways poetry are intertwined with her songwriting, her experiences as a child moving from Zimbabwe to the US, and what she's got planned for the fall: https://youtu.be/qloTMIT_pWI

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Yola - Diamond Studded Shoes (live performance for The Current)
 - [https://www.youtube.com/watch?v=K5J-hvoElBM](https://www.youtube.com/watch?v=K5J-hvoElBM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-23 00:00:00+00:00

Yola plays "Diamond Studded Shoes" from her upcoming record, 'Stand For Myself', coming out on @EasyEyeSound. 

Don't miss Yola's full virtual session, including an interview about playing Sister Rosetta Tharpe in the upcoming Baz Luhrmann film 'Elvis,' and how her childhood musical influences came through on the new record: https://youtu.be/PQEdil-40SE

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

