# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Loshh - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=ugiwhrY-AXo](https://www.youtube.com/watch?v=ugiwhrY-AXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-24 00:00:00+00:00

http://KEXP.ORG presents Loshh performing live, recorded exclusively for KEXP.

Songs:
É Beré
Feelam
Í
Faji

Session filmed at Boiler Room in London
Director: Clio Marden 
Camera operator : Ramone Anderson
Audio recording: Harry Lightfoot
Mix Engineer: Finn Gee
Editor: Kima Hibbert 
Courtesy of Don’t Sleep 

Vocals: Loshh 
Guitar: Seun Folayan
Drums: Santiago Morales 
Keys: Charlie Tappin 
Bass: Jonah Scott 

https://lnk.site/0/ifarada
http://kexp.org

## Loshh - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=25fkytXWYHE](https://www.youtube.com/watch?v=25fkytXWYHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-23 00:00:00+00:00

http://KEXP.ORG presents Loshh sharing a live performance recorded exclusively for KEXP and talking to Lace Cadence, host of Overnight Afrobeats. Recorded July 12, 2021.

Songs:
É Beré
Feelam
Í
Faji

Session filmed at Boiler Room in London
Director: Clio Marden 
Camera operator : Ramone Anderson
Audio recording: Harry Lightfoot
Mix Engineer: Finn Gee
Editor: Kima Hibbert 
Courtesy of Don’t Sleep 

Vocals: Loshh 
Guitar: Seun Folayan
Drums: Santiago Morales 
Keys: Charlie Tappin 
Bass: Jonah Scott 

https://lnk.site/0/ifarada
http://kexp.org

