## Why a YouTube Chat About Chess Got Flagged for Hate Speech | WIRED
 - [https://www.wired.com/story/why-youtube-chat-chess-flagged-hate-speech/](https://www.wired.com/story/why-youtube-chat-chess-flagged-hate-speech/)
 - RSS feed: https://www.wired.com
 - date published: 2021-07-23 09:18:42.807720+00:00

AI programs that analyze language have difficulty gauging context. Words such as “black,” “white,” and “attack" can have different meanings.

