# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Cheap Full Body Tracking for EVERYONE : SlimeVR Review
 - [https://www.youtube.com/watch?v=O13L5MxOlHo](https://www.youtube.com/watch?v=O13L5MxOlHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-07-23 00:00:00+00:00

I am extremely excited and happy to present this review of the SlimeVR full body trackers! Doesn’t matter whether you’re on a quest, rift, HO Reverb G2, Index, Pimax… you now can have full body tracking without basestations and it’s actually pretty good.. and getting better every day it seems! I love full body tracking and I want more games with it but we need more people with it! Hopefully you enjoy this video!


https://www.crowdsupply.com/slimevr/slimevr-full-body-tracker

My links:
Join my discord for VR meetups!
Discord.gg/Thrill

I stream VR content on twitch weekly!
Twitch.tv/thrilluwu

