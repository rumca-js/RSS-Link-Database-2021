# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Techifying a freakin' BOAT!
 - [https://www.youtube.com/watch?v=SypkW1g4jMc](https://www.youtube.com/watch?v=SypkW1g4jMc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-07-24 00:00:00+00:00

Thanks to Jackery for sponsoring today's video! Get 10% off all Jackery products on their website with code LinusTechTips:  https://www.jackery.com?aff=27
 
We overhauled a boat with the latest in tech featuring Jackery's Explorer 2000 Solar generator!

Buy Apple TV 4K 2021
On Amazon (PAID LINK): https://geni.us/DF4JWpJ
On Best Buy (PAID LINK): https://geni.us/bGuXN
On B&H (PAID LINK): https://geni.us/sZx0A

Buy Apple iPad Pro
On Amazon (PAID LINK): https://geni.us/dYqp
On Best Buy (PAID LINK): https://geni.us/LUoq3d
On Newegg (PAID LINK): https://geni.us/GsJN

Buy RAM Mounts
On Amazon (PAID LINK): https://geni.us/e39lh
On B&H (PAID LINK): https://geni.us/S61HC4

Buy Samsung Monitors
On Amazon (PAID LINK): https://geni.us/OnBf
On Best Buy (PAID LINK): https://geni.us/0kbvZ
On Newegg (PAID LINK): https://geni.us/BAONZa

Buy Kanto RV250G TV Wall Mount
On Amazon (PAID LINK): https://geni.us/BfWvSax
On Newegg (PAID LINK): https://geni.us/JaLWCT
On B&H (PAID LINK): https://geni.us/YiWWwJ

Buy Polk Audio Atrium5 Outdoor Speakers
On Amazon (PAID LINK): https://geni.us/zjg0ZlA
On Newegg (PAID LINK): https://geni.us/qnKjJq
On B&H (PAID LINK): https://geni.us/IQA3y1k

Buy Alpine Electronics PWE-S8 Subwoofer
On Amazon (PAID LINK): https://geni.us/VvjG
On Best Buy (PAID LINK): https://geni.us/ObAlH8
On Newegg (PAID LINK): https://geni.us/wQAAD

Buy JL Audio C1-400 Car Audio Speakers
On Newegg (PAID LINK): https://geni.us/dc0bG

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1359246-techifying-a-freakin-boat/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Don't hit the boat, Linus!
0:39 Entertainment system setup
2:54 Cable-managing a boat is hard lol
3:38 VESA Mounting issues
5:01 Story behind Colin's Dad's boat
6:08 Wiring done but diagnosing power switch
6:25 Outdoor speaker install
7:51 Subwoofer mounting time
8:23 Jackery Saga Solar Generator install and Crabrave
10:09 The tech side of things
11:03 Conclusion and Jackery Explorer 2000

## Talk me Down from The Wall... - WAN Show July 23, 2021
 - [https://www.youtube.com/watch?v=2xlkKIGNsMw](https://www.youtube.com/watch?v=2xlkKIGNsMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-07-23 00:00:00+00:00

Pre-order Megapro's new 24-in-1 Precision Screwdriver at https://lmg.gg/MegaproWAN

Start your build today at https://www.buildredux.com/linus

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/wan

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Talk-me-Down-from-The-Wall------WAN-Show-July-23--2021-e151loa

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtacy of NoKi1119)
[0:00] Chapters
[1:39] Intro
[2:40] Topic #1: Blizzard civil lawsuit.
   4:24 Discrimination and sexual conduct.
   5:34 Activision's response to the allegations.
   6:16 Harassment towards female workers.
   9:17 Discussing the response.
[18:47] Topic #2: Samsung's second generation 'The Wall'.
   19:37 Specifications of the new display.
   20:29 Advantages of MicroLED.
   21:29 Wattage and required cooling.
   35:42 Possible content using the display.
   44:05 Golden controller being sold.
   46:34 Sony projectors and others as a substitute.
[54:52] Sponsors
   55:31 Megapro's Screwdriver.
   56:22 Freshbooks Accounting.
   57:34 Redux PC Builder.
[58:38] New LTTstore merch.
[1:02:48] Topic #3: 30% decrease in WoW players during the pandemic.
   1:03:06 Reasons behind the decrease.
[1:03:56] Topic #3.5: Amazon's MMO "New World" bricks RTX 3090's.
[1:08:20] Topic #4: Spectrum Eve monitor.
   1:10:01 Poll: To cover or not to cover?
   1:12:45 Reasons behind the interest.
[1:13:18] Topic #5: 'Freedom Phone'.
   1:13:46 Discussing Finman's claims.
   1:16:03 FP is a more expensive UMIDIGI phone.
[1:19:34] Topic #6: Bezos brothers went to space.
   1:21:27 Jeff thanking Amazon employees and customers for this.
[1:23:46] Topic #7: Nvidia's MediaTek ARM CPU demo.
   1:25:58 Scientist patched Linux on RISC-V CPU with RX 6700 XT.
   1:27:38 Intel's (leaked) 12th generation is in 10nm.
[1:28:07] Superchats (& Impersonating Jeff Bezos)
[1:46:44] Wrapping up
[1:47:13] Outro

