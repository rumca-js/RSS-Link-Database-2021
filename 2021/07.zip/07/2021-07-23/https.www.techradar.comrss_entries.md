# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Dead Space remake release date, gameplay, trailers and news
 - [https://www.techradar.com/news/dead-space-remake/](https://www.techradar.com/news/dead-space-remake/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2021-07-23 10:25:25+00:00

The Dead Space remake looks set to drag the cult horror game onto modern consoles. Here's what you need to know.

## Dead Space remake release date, gameplay, trailers and news
 - [https://www.techradar.com/news/dead-space-remake](https://www.techradar.com/news/dead-space-remake)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2021-07-23 10:25:25+00:00

The Dead Space remake offers up a modern version of the cult horror classic. Here's what you need to know.

