# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## How Jeff Bezos Became Public Enemy Number One
 - [https://www.youtube.com/watch?v=QTOFrg2EAQs](https://www.youtube.com/watch?v=QTOFrg2EAQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2021-07-24 00:00:00+00:00

Sign up here https://cen.yt/mbcoldfusion10 for your free daily newsletter - I’ve really enjoyed Morning Brew and I think you will too!

My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Discord:  https://discord.gg/coldfusion

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

Rob Braxman Tech : https://www.youtube.com/watch?v=ccrUAp4GQvY

https://www.theguardian.com/us-news/2019/jul/11/amazon-ice-protest-immigrant-tech

Pro publica https://www.youtube.com/watch?v=8pBPZMUcsh0

https://www.forbes.com/sites/jackkelly/2021/06/17/amazon-prime-day-offers-great-sales-heres-what-workers-suffer-through-to-make-this-happen/?sh=1be67f381519

https://www.theverge.com/22264856/jeff-bezos-worth-amazon-founder-ceo-193-billion-dollars

https://marketrealist.com/p/why-do-people-hate-jeff-bezos/

https://www.protocol.com/bulletins/jeff-bezos-tax-rate-billionaires

https://www.businessinsider.com.au/jeff-bezos-facts-2021-1?r=US&IR=T

https://www.theguardian.com/technology/2020/feb/05/amazon-workers-protest-unsafe-grueling-conditions-warehouse

https://qz.com/1145669/googles-true-origin-partly-lies-in-cia-and-nsa-research-grants-for-mass-surveillance/

https://www.newidea.com.au/nike-sweatshops-the-truth-about-the-nike-factory-scandal

https://www.theguardian.com/environment/2019/oct/29/the-fight-over-water-how-nestle-dries-up-us-creeks-to-sell-water-in-plastic-bottles

https://www.propublica.org/article/the-secret-irs-files-trove-of-never-before-seen-records-reveal-how-the-wealthiest-avoid-income-tax

https://www.businessinsider.com.au/jeff-bezos-biological-father-2013-10?r=US&IR=T

//Soundtrack//

Burn Water – The Final Push

Blindspot - Rynn

BUCK UK - Once

Kazukii – Changes

David Keno - Golden Ticket

Zachary David  - The Light 

Biosphere - Poa Alpina

Burn Water – Does it Get Easier?

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

