# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The Radical Rebrand of Russell Brand
 - [https://www.youtube.com/watch?v=YJZ56Eb-3i4](https://www.youtube.com/watch?v=YJZ56Eb-3i4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2021-07-24 00:00:00+00:00

At one point in time Russell Brand was known as a movie star and husband of Katy Perry. Now Russell Brands talks with Jordan Peterson and Ben Shapiro.

Today Russell brand is married and owner of the biggest political commentary channel on YouTube. Where Russel discusses Covid, Covid passports and Russell’s perspective of bill gates and the great reset. With Russell Brand's podcast Under the Skin, giving Russell Brand the chance to talk to Ben Shapiro, Jordan Peterson and Candace Owens for education.Russell brand now talks about covid vaccines, covid protests and covid-19 laws. With videos such as Vaccine Passports: THIS Is Where It Leads, Vaccination passports are creating public and political dispute across the world. Is this debate a matter of civil liberties, and can the state compel you to take a vaccine with the reward of everyday freedoms? And videos like “They’re Lying To You”: If Science CAUSED COVID - what’s next? With daily revelations about the COVID origin, Wuhan, and Anthony Fauci, as well as information we already know regarding Big Pharma and its influence on mainstream media, how much can we trust what we've been told so far?  And of course Vaccine Gold Rush: Do You Trust Gates?The pharmaceutical industry has been pouring resources into the growing political fight over generic coronavirus vaccines. They a useful and powerful ally in Bill Gates, so does this undermine his status as a philanthropist and make a mockery of his stated aim of getting the world “back to normal”?

How did this happen?
 ******
►  Become a Patron:  https://www.patreon.com/MoonReal


📹𝗠𝘆 𝗘𝗾𝘂𝗶𝗽𝗺𝗲𝗻𝘁:
► Microphone: https://www.amazon.co.uk/gp/product/B07DV2WK77/ref=as_li_tl?ie=UTF8&camp=1634&creative=6738&creativeASIN=B07DV2WK77&linkCode=as2&tag=moonreal-21&linkId=1e984828cb3122716d17530c662a0776

💊*Blackpill on China*
►https://www.amazon.co.uk/gp/product/0099507374/ref=as_li_tl?ie=UTF8&camp=1634&creative=6738&creativeASIN=0099507374&linkCode=as2&tag=moonreal-21&linkId=296f051e6483a68d0d1fff2e5e074a86

🎶 𝐌𝐮𝐬𝐢𝐜 𝐔𝐬𝐞𝐝:
►Epidemic Sounds - https://www.epidemicsound.com/referral/w1vpsh/


******
AFFILIATE DISCLOSURE: there may be a few links in this description that, at no cost to you, will earn me a commission if you choose to click them and make a purchase. I only ever promote things that have genuinely helped me.



Donate here: https://www.patreon.com/MoonReal

