# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Jak w prosty sposób uratować Ziemię? Jeff Bezos, Evolve, Porsche Taycan, Audi E-Tron GT
 - [https://www.youtube.com/watch?v=gz_ixtO4-Zs](https://www.youtube.com/watch?v=gz_ixtO4-Zs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-07-04 00:00:00+00:00

Po pierwsze:
Trzeba zrobić to, co Amazon, czyli wyrzucać dużo elektroniki: https://youtu.be/mxqz2g05MTI
Po drugie można założyć fundację jak Jeff Bezos: https://bit.ly/3we8NS1
Po trzecie zrezygnować z bycia szefem Amazona jak Jeff Bezos: https://cnn.it/2TAudeL
Można też rozwijać latające samochody jak Słowacy: https://bit.ly/3yp1msW
Albo recenzować nowe smartfony od Sony: https://bit.ly/3wgnjZI
Kupić nową deskę Evolve'a do jeżdżenia po lesie: https://bit.ly/3wgblPH
Wrzucać dłuższe filmy na tiktoka, bo już można: https://bit.ly/3wgnfZY
Czekać na nowe iPhone'y: https://bit.ly/3whLnev
Wspominać starego walkmana: https://bit.ly/3ArjP9L
Płacić cło i VAT za zakupy z Ali, bo już trzeba: https://bit.ly/3xhZ1jf
Cieszyć się, że tablety mają nowe funkcje: https://bit.ly/3hgdXc7
Instalować Windowsa 11 na Lumii 950: https://bit.ly/36a3RmE
Kibicować Richardowi Bransonowi: https://bit.ly/3AqisID
I 82-letniej kosmonautce: https://bit.ly/3hxq9Ei
Martwić się co z nową Teslą: https://bloom.bg/3qPcQDs
Współczuć właścicielom Porsche Taycana: https://bit.ly/2SKoKSe
I Audi E-Tron GT: https://bit.ly/3jIZVRF
Ale ostateczny efekt tych działań nadal pozostaje niewiadomą. 

To zupełnie jak moja aktywność na social mediach:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Wstęp
00:21 Dobry wieczór
00:26 Amazon niszczy #jeszczedobre produkty
01:58 Bezos przestaje być szefem amazona i zostaje kosmonautą 
02:27 Słowacki latający samochód
03:58 Zapowiedź recenzji telefonu od Sony i słuchawek od Apple
04:37 Temat desek za 10 tysięcy złotych (Evolve)
05:44 3 minutowe filmy na TikToku
06:14 Za niedługo nowe iPhony
06:52 Dalej słuchamy muzyki jak z Walkmana
07:18 VAT i cło za zakupy z aliexpress
07:52 Tablet od Lenovo z funkcją monitora
08:37 Windows na Lumii 950 
09:10 Beta iOS 15
09:26 Richard Branson leci w kosmos przed Bezosem
10:11 Problemy z elektrycznymi autami
10:47 Znośnego tygodnia!

