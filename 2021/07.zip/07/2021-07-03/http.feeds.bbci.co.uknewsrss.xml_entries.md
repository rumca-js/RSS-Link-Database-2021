# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Nnamdi Kanu's arrest leaves Nigeria's Ipob separatists in disarray
 - [https://www.bbc.co.uk/news/world-africa-57693863](https://www.bbc.co.uk/news/world-africa-57693863)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:45:07+00:00

Igbo separatist leader Nnamdi Kanu was largely ignored until his movement became an armed struggle.

## Your pictures on the theme of 'animal crossing'
 - [https://www.bbc.co.uk/news/in-pictures-57695724](https://www.bbc.co.uk/news/in-pictures-57695724)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:38:14+00:00

A selection of striking images from our readers around the world.

## Euro 2020: England fans celebrate as Three Lions advance to semi-finals
 - [https://www.bbc.co.uk/news/uk-57710515](https://www.bbc.co.uk/news/uk-57710515)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:35:21+00:00

Fans react as England beat Ukraine 4-0 to reach Euro 2020 semi-final.

## What we can all learn from Britney Spears’ case
 - [https://www.bbc.co.uk/news/world-us-canada-57698820](https://www.bbc.co.uk/news/world-us-canada-57698820)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:29:34+00:00

The pop star’s conservatorship has shed light on our treatment of female celebrities in the 2000s.

## Ukraine v England pictures: Fans jubilant as Three Lions soar in Rome
 - [https://www.bbc.co.uk/news/uk-57707677](https://www.bbc.co.uk/news/uk-57707677)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:14:08+00:00

Fans celebrate as England head for the Euro 2020 semi-finals after beating Ukraine.

## Euro 2020: Ukraine 0-4 England - 'England want to go two steps further' says Gareth Southgate
 - [https://www.bbc.co.uk/sport/football/57707754](https://www.bbc.co.uk/sport/football/57707754)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:04:37+00:00

England are not settling for a semi-final spot at Euro 2020 after they reach the last four by thrashing Ukraine, says Gareth Southgate.

## Portal: Lithuania and Poland build a window connecting two cities
 - [https://www.bbc.co.uk/news/world-europe-57694055](https://www.bbc.co.uk/news/world-europe-57694055)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:02:35+00:00

Residents of Vilnius, Lithuania and Lublin, Poland are now connected by a 'portal' between the cities.

## Israeli videographer goes viral with sheep drone shots
 - [https://www.bbc.co.uk/news/world-middle-east-57690125](https://www.bbc.co.uk/news/world-middle-east-57690125)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 23:02:30+00:00

Lior Patel's drone footage of sheep has been viewed more than 100,000 times on Facebook.

## England at Euro 2020: 'Something special is happening'
 - [https://www.bbc.co.uk/sport/football/57710205](https://www.bbc.co.uk/sport/football/57710205)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 22:31:54+00:00

Former England captain Alan Shearer believes "something special is happening" as Gareth Southgate's side reach the Euro 2020 semi-finals.

## How cattle are helping rare butterflies to thrive at Mabie Forest
 - [https://www.bbc.co.uk/news/uk-scotland-south-scotland-57636202](https://www.bbc.co.uk/news/uk-scotland-south-scotland-57636202)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 22:31:39+00:00

Pearl-bordered fritillary numbers are rising at one site - with some unusual assistance.

## Prince Charles reveals favourite songs in radio show to thank volunteers
 - [https://www.bbc.co.uk/news/uk-57709443](https://www.bbc.co.uk/news/uk-57709443)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 22:08:32+00:00

The future king highlights one 1970s pop hit which gave him "an irresistible urge to dance".

## England beat Ukraine: how social media reacted
 - [https://www.bbc.co.uk/sport/football/57709903](https://www.bbc.co.uk/sport/football/57709903)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 22:08:29+00:00

England strolled into the semi-finals of Euro 2020 with a 4-0 win over Ukraine. Here's how it unfolded on social media.

## Euro 2020: Ukraine v England - how you rated the players
 - [https://www.bbc.co.uk/sport/football/51199153](https://www.bbc.co.uk/sport/football/51199153)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 21:59:37+00:00

How you rated the players in the Euro 2020 quarter-final between Ukraine and England.

## Highlights: England thrash Ukraine to reach semi-finals
 - [https://www.bbc.co.uk/sport/av/football/57709899](https://www.bbc.co.uk/sport/av/football/57709899)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 21:10:33+00:00

Watch highlights as Harry Kane's brace helped England cruise to victory beating Ukraine 4-0 to advance to the semi-finals of Euro 2020 against Denmark at Wembley.

## ‘I’m going to have to do some laundry tonight’ – British teenager Raducanu into Wimbledon last 16
 - [https://www.bbc.co.uk/sport/tennis/57706687](https://www.bbc.co.uk/sport/tennis/57706687)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 14:51:03+00:00

Emma Raducanu's dream debut run at Wimbledon continues into the fourth round with victory over Romania's world number 45 Sorana Cirstea.

## Covid: Stars perform musical song in latest vaccine push
 - [https://www.bbc.co.uk/news/uk-57702498](https://www.bbc.co.uk/news/uk-57702498)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 12:17:09+00:00

Film, TV and stage actors appear in a campaign video urging people to get their Covid jab.

## Japan landslide: 20 missing in Atami city
 - [https://www.bbc.co.uk/news/world-asia-57704967](https://www.bbc.co.uk/news/world-asia-57704967)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 11:47:38+00:00

The government is dispatching an emergency task force to the area around Atami, which has seen heavy rain.

## Canada heatwave: Lightning triggers wildfires in British Columbia
 - [https://www.bbc.co.uk/news/world-us-canada-57703853](https://www.bbc.co.uk/news/world-us-canada-57703853)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 11:46:34+00:00

Military aircraft are mobilised as fires burn across British Columbia following a record-breaking heatwave.

## Morrisons: Supermarket agrees £6.3bn takeover
 - [https://www.bbc.co.uk/news/business-57705253](https://www.bbc.co.uk/news/business-57705253)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 11:33:00+00:00

The UK's fourth largest supermarket accepts an offer from the US owner of Majestic Wine.

## Covid: Doctors want to keep some measures after 19 July
 - [https://www.bbc.co.uk/news/uk-57703959](https://www.bbc.co.uk/news/uk-57703959)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 11:19:13+00:00

Ministers are considering allowing fully vaccinated people to avoid isolation if exposed to Covid.

## Ukraine plans for women to march in high heels spark outrage
 - [https://www.bbc.co.uk/news/world-europe-57706617](https://www.bbc.co.uk/news/world-europe-57706617)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 11:09:37+00:00

The military wants women soldiers to march in heels rather than army boots on independence day.

## Oxford Circus stabbing: Man charged with murder
 - [https://www.bbc.co.uk/news/uk-england-london-57705785](https://www.bbc.co.uk/news/uk-england-london-57705785)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 10:36:54+00:00

The 60-year-old victim was stabbed outside the Microsoft store in central London on Thursday.

## Covid in Scotland: Contact tracers to prioritise 'high risk' cases
 - [https://www.bbc.co.uk/news/uk-scotland-57705375](https://www.bbc.co.uk/news/uk-scotland-57705375)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 10:07:04+00:00

Staff will only call the most urgent cases, while text messages will be used for those deemed low risk.

## England bowler Ollie Robinson suspended for eight matches for past racist and sexist tweets
 - [https://www.bbc.co.uk/sport/cricket/57697159](https://www.bbc.co.uk/sport/cricket/57697159)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 09:54:25+00:00

England fast bowler Ollie Robinson is banned for eight matches - five of them suspended for two years - for historical racist and sexist tweets but is free to play again.

## Tough Mudder Scotland in Dalkeith cancelled night before event
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-57703084](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-57703084)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 08:55:47+00:00

Midlothian Council withdrew the event's licence less than 15 hours before it was due to start.

## Lewis Hamilton: Mercedes driver signs new two-year deal
 - [https://www.bbc.co.uk/sport/formula1/57680700](https://www.bbc.co.uk/sport/formula1/57680700)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 08:55:24+00:00

World champion Lewis Hamilton signs a new two-year deal with Mercedes until the end of 2023.

## Lyme disease: 'People say I don't look ill'
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-57693815](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-57693815)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 08:11:31+00:00

Yen Lau describes her Lyme disease as an "invisible disease" that can cause days of sickness and fatigue.

## Norfolk seal inscription mystery solved by US man on Twitter
 - [https://www.bbc.co.uk/news/uk-england-norfolk-57678500](https://www.bbc.co.uk/news/uk-england-norfolk-57678500)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 08:02:58+00:00

Alex Cortez from California says he used a free morning to research a silver seal found in Norfolk.

## US companies hit by 'colossal' cyber-attack
 - [https://www.bbc.co.uk/news/world-us-canada-57703836](https://www.bbc.co.uk/news/world-us-canada-57703836)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 07:37:55+00:00

A cyber-security firm says it believes the Russia-linked REvil ransomware gang is responsible.

## Euro 2020: England fan picks lucky shirt from 367-strip collection
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-57698126](https://www.bbc.co.uk/news/uk-england-lincolnshire-57698126)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 07:24:59+00:00

Collector Pete Hammond dons his favourite three lions kit as the team prepares to face Ukraine.

## Belfast murals: Dan Kitchener street graffiti inspired by Japanese art
 - [https://www.bbc.co.uk/news/57663446](https://www.bbc.co.uk/news/57663446)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 06:19:33+00:00

A renowned street artist explains the Japanese-inspired mural he's created in Belfast.

## England v Ukraine at Euro 2020: How well do you remember previous Three Lions quarter-finals?
 - [https://www.bbc.co.uk/sport/football/57667397](https://www.bbc.co.uk/sport/football/57667397)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 05:21:10+00:00

How much do you know about England's previous 12 quarter-finals at major tournaments? Take our quiz.

## Euro 2020: Gareth Southgate's 25-year quest for redemption with England
 - [https://www.bbc.co.uk/sport/av/football/57695367](https://www.bbc.co.uk/sport/av/football/57695367)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 05:18:09+00:00

BBC Sport looks back at Gareth Southgate's 25-year quest for redemption with England, both as a player and a manager, in his own words.

## The Papers: Quarantine 'to end' for fully jabbed, and 'Yes we Kane'
 - [https://www.bbc.co.uk/news/blogs-the-papers-57703809](https://www.bbc.co.uk/news/blogs-the-papers-57703809)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 04:39:12+00:00

Saturday's papers feature reports about what life could look like for those given two Covid vaccines.

## Should we raucously celebrate a football win in a pandemic?
 - [https://www.bbc.co.uk/news/uk-57664286](https://www.bbc.co.uk/news/uk-57664286)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 00:18:58+00:00

Scenes of England fans celebrating beating Germany have delighted many - but raised some eyebrows.

## Can esports be more inclusive and accessible for people with disabilities?
 - [https://www.bbc.co.uk/news/newsbeat-57696675](https://www.bbc.co.uk/news/newsbeat-57696675)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-03 00:13:59+00:00

A pilot event has taken place to work out how competitive gaming can include more people.

