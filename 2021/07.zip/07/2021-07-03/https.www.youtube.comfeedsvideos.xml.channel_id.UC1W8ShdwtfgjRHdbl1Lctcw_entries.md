# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## A Day in San Francisco 1940's in color [60fps, Remastered] w/added sound
 - [https://www.youtube.com/watch?v=JfM6La2RlAg](https://www.youtube.com/watch?v=JfM6La2RlAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2021-07-04 00:00:00+00:00

I have colorized and digitally restored and worked a sound design for this video of  San Francisco 1940's
a time travel in 1940's , we can clearly see what is happening in broad daylight, the San Francisco Ferry Building way in the distance with its famous tower almost centered with Market Street  (thank you:
Engin Savaş, BlueSky, WAL_DC-6B)
 
Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

Thanks to A/V Geeks for share the amazing B&W Video Source

B&W Video Source from: A/V Geeks on archive.org
B&W Video Source: https://archive.org/details/pet1186r5sf

Rights to the black and white 35mm Video Source are held by Internet Archive. under the Creative Commons Attribution License
- - - - - - - - - - - - - - - - - - - -
About A/V Geeks: A/V Geeks started by collecting thousands of old 16mm educational films. Now, they have over 24,000 which they sell for stock footage. Also, they digitize a variety of film (8mm, super8, 16mm, 35mm) and video formats (Umatic, 1" open reel, MII, Beta SP, Digibeta, Betacam SX, Betacam IMX, Video8, Hi8, VHS, SVHS, DVCAM, DVCPRO25, HDV) to archival digital file formats.
You can support A/V Geeks via patreon : https://www.patreon.com/avgeeks
- - - - - - - - - - - - - - - - - - - -
📨 Contact me at :nassthegoodman@gmail.com
- - - - - - - - - - - - - - - - - - - -
For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page! Please consider "fair use" before filing a claim. Thank You!

