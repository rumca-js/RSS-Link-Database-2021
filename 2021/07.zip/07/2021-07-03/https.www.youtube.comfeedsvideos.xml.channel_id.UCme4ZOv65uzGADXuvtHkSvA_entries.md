# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Księga Wyjścia || Rozdział 18
 - [https://www.youtube.com/watch?v=KU_3JVoPdIc](https://www.youtube.com/watch?v=KU_3JVoPdIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-04 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Niezniszczalni [#03] Męskie wtorki
 - [https://www.youtube.com/watch?v=0FoE7FcFHTY](https://www.youtube.com/watch?v=0FoE7FcFHTY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-04 00:00:00+00:00

@Langustanapalmie @RTCK_robtocokochasz 

Tego jeszcze nie było! Dwóch żonatych i ksiądz. Po męsku. Przy kawie. W półmroku. Zapraszamy na nową serię o mężczyznach - nie tylko dla mężczyzn...

PROWADZĄCY: 
➜ o. Adam Szustak OP - https://www.instagram.com/langustanapalmie/ 
➜ Michał Szczepanek - https://www.instagram.com/michalszczepanek.pl/ 
➜ Piotr Piwowar - https://www.instagram.com/_piotrpiwowar 

PREZENT dla "Langustowiczów" od RTCK: 
Odbierz ZA DARMO jedną z trzech NAJLEPSZYCH audiokonferencji RTCK: ks. Piotra Pawlukiewicza, o. Adama Szustaka, lub ks. Jana Kaczkowskiego i ROZWIŃ swoje powołanie, aby mieć WIĘCEJ satysfakcji z PRACY, RODZINY i ŻYCIA. 
Tutaj LINK ➡️ https://www.rtck.pl/?ref=17/ 

wideo: Jakub Kosakowski i Krzysztof Ogórek 
dźwięk: Maksymilian Zięba i Bartłomiej (Wacek) Wawrzyniak 
czołówka: Krzysztof Ogórek 
fotografie: Dorota Czoch 
montaż i koncepcja czołówki: Michał Szczepanek i Piotr Piwowar

serię nagrano i wyprodukowano w studio RTCK - Rób to co kochasz
INSTAGRAM https://www.instagram.com/rtck.pl/

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#241] Szatan odbiera ci wartość na trzy sposoby
 - [https://www.youtube.com/watch?v=Fc2-Y3JPHOg](https://www.youtube.com/watch?v=Fc2-Y3JPHOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-03 00:00:00+00:00

Kazanko do okienka, czyli komentarz do niedzielnych czytań.
XIV Niedziela zwykła, Rok B

1. czytanie (Ez 2, 2-5)

Wstąpił we mnie duch, gdy do mnie mówił, i postawił mnie na nogi; potem słuchałem Tego, który do mnie mówił. Powiedział mi: «Synu człowieczy, posyłam cię do synów Izraela, do ludu buntowników, którzy Mi się sprzeciwili. Oni i przodkowie ich występowali przeciwko Mnie aż do dnia dzisiejszego. To ludzie o bezczelnych twarzach i zatwardziałych sercach; posyłam cię do nich, abyś im powiedział: Tak mówi Pan Bóg. A oni, czy będą słuchać, czy też zaprzestaną – są bowiem ludem opornym – przecież będą wiedzieli, że prorok jest wśród nich».

2. czytanie (2 Kor 12, 7-10)

Bracia: Aby nie wynosił mnie zbytnio ogrom objawień, dany mi został oścień dla ciała, wysłannik Szatana, aby mnie policzkował – żebym się nie unosił pychą. Dlatego trzykrotnie prosiłem Pana, aby odszedł ode mnie, lecz mi powiedział: «Wystarczy ci mojej łaski. Moc bowiem w słabości się doskonali». Najchętniej więc będę się chlubił z moich słabości, aby zamieszkała we mnie moc Chrystusa. Dlatego mam upodobanie w moich słabościach, w obelgach, w niedostatkach, w prześladowaniach, w uciskach z powodu Chrystusa. Albowiem ilekroć niedomagam, tylekroć jestem mocny.

Ewangelia (Mk 6, 1-6)

Jezus przyszedł do swego rodzinnego miasta. A towarzyszyli Mu Jego uczniowie. Gdy zaś nadszedł szabat, zaczął nauczać w synagodze; a wielu, przysłuchując się, pytało ze zdziwieniem: «Skąd to u Niego? I co to za mądrość, która Mu jest dana? I takie cuda dzieją się przez Jego ręce! Czy nie jest to cieśla, syn Maryi, a brat Jakuba, Józefa, Judy i Szymona? Czyż nie żyją tu u nas także Jego siostry?» I powątpiewali o Nim. A Jezus mówił im: «Tylko w swojej ojczyźnie, wśród swoich krewnych i w swoim domu może być prorok tak lekceważony».
I nie mógł tam zdziałać żadnego cudu, jedynie na kilku chorych położył ręce i uzdrowił ich. Dziwił się też ich niedowiarstwu. Potem obchodził okoliczne wsie i nauczał.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Ghost of Tsushima [35] Towarzyszyć w odejściu
 - [https://www.youtube.com/watch?v=qa-f8AAmBpU](https://www.youtube.com/watch?v=qa-f8AAmBpU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-03 00:00:00+00:00

@langustanapalmie #ksiadzgrawgre #GhostOfTsushima
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Wyjścia || Rozdział 17
 - [https://www.youtube.com/watch?v=EjxUxbAnRsQ](https://www.youtube.com/watch?v=EjxUxbAnRsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-03 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#827] Kręgi
 - [https://www.youtube.com/watch?v=lyF0IDq7Xb8](https://www.youtube.com/watch?v=lyF0IDq7Xb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-07-03 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

