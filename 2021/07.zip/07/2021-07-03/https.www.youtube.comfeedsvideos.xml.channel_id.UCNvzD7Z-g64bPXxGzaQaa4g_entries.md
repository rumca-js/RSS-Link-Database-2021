# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 20 NEW Upcoming Games of 2021 [Second Half]
 - [https://www.youtube.com/watch?v=SNUur2qV1pE](https://www.youtube.com/watch?v=SNUur2qV1pE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-04 00:00:00+00:00

2021 is filled with games releasing on PC, PS5, PS4, Xbox Series X/S/One, Nintendo Switch, and more. Here's some stuff to look forward to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

20 Tales of Arise

Platform : PS5 PS4 PC XBOX ONE XSX|S 

Release Date : September 10, 2021 



19 Aliens: Fireteam Elite 

Platform : PC PS4 PS5 XBOX ONE XSX|S 

Release Date : August 24 2021 



18 Monster Hunter Stories 2: Wings of Ruin 

Platform : PC SWITCH 

Release Date : July 9, 2021 



17 Metroid Dread 

Platform : Switch 

Release Date : October 8, 2021



16 Samurai Warriors 5 

Platform : SWITCH PC PS4 XBOX ONE 

Release Date : July 27, 2021 



15 Little Devil Inside 

Platform : PC PS4 PS5 XBOX ONE XSX|S 

Release Date : July 2021 



14 No More Heroes III

Platform : Switch 

Release Date : August 27, 2021 



13 Psychonauts 2 

Platform : PC PS4 XBOX ONE XSX|S Linux 

Release Date : August 25, 2021 



12 Kena: Bridge of Spirits 

Platform : PC PS4 PS5 

Release Date : August 24, 2021 



11 Rainbow Six Extraction

Platform : PC PS4 PS5 XSX|S XBOX ONE LUNA GOOGLE STADIA 

Release Date : September 16, 2021 



10 Ghostwire: Tokyo 

Platform : PC PS5 October 2021 

Release Date : XSX|S Q4 2022


9 Forza Horizon 5 

Platform : PC XSX|S XBOX ONE 

Release Date : November 9 2021 



8 Age of Empires IV 

Platform : PC Xbox Cloud Gaming 

Release Date : October 28, 2021 



7 Deathloop

Platform : PC PS5 

Release Date : September 14, 2021 



6 Battlefield 2042 

Platform : XBOX ONE XSX|S PC PS4 PS5 

Release Date : October 22, 2021 



5 Halo Infinite 

Platform : PC XSX|S XBOX ONE

Release Date : Q4 2021 



4 Back 4 Blood 

Platform : PC PS4 PS5 XSX|S XBOX ONE 

Release Date : October 12, 2021 



3 Far Cry 6  

Platform : PC PS4 PS5 XBOX ONE XSX|S Amazon Luna Stadia 

Release Date : October 7, 2021 



2 Guardians of the Galaxy 

Platform : PC PS4 PS5 XBOX ONE XSX|S Switch 

Release Date : October 26, 2021 



1 Dying Light 2 Stay Human 

Platform : PC PS5 PS4 XBOX ONE XSX|S 

Release Date : December 7, 2021 



BONUS

Chernobylite 

Platform : PC PS5 PS4 XBOX ONE XSX|S 

Release Date : July 2021



The Ascent 

Platform : XSX|S PC XBOX ONE 

Release Date : July 29, 2021



The Legend of Zelda: Skyward Sword HD 

Platform : Switch 

Release Date : July 16, 2021 



Grand Theft Auto V - ps5 series x 

Platform : XSX|S PS5 

Release Date : November 11, 2021

Pokémon Brilliant Diamond and Shining Pearl 

Platform : Switch 

Release Date : November 19, 2021

## 10 Most EVIL CHOICES You Can Make in Video Games
 - [https://www.youtube.com/watch?v=Ce2vjqNpsaQ](https://www.youtube.com/watch?v=Ce2vjqNpsaQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-03 00:00:00+00:00

Some video games give you the option to do some truly terrible things. Here are our favorite evil examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Credit:
https://www.reddit.com/r/Fallout/comments/nspons/one_of_the_most_evil_things_you_can_do_in_new/

