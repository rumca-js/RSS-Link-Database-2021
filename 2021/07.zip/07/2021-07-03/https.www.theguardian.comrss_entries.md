# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## The Brazilian protest leader determined to bring Bolsonaro’s ‘genocidal’ government down - video
 - [https://www.theguardian.com/world/video/2021/jul/03/the-brazilian-protest-leader-determined-to-bring-bolsonaros-genocidal-government-down-video](https://www.theguardian.com/world/video/2021/jul/03/the-brazilian-protest-leader-determined-to-bring-bolsonaros-genocidal-government-down-video)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-07-03 09:33:10+00:00

<p>The Guardian follows Guilherme Boulos, who ran against Bolsonaro in the last elections, as he leads thousands through the streets of São Paulo, calling for the country’s president to be impeached.&nbsp;</p><p>The pressure is mounting on Bolsonaro as he faces a scandal over allegedly corrupt Covid vaccine deals and public rage over his handling of a pandemic that has killed more than half a million people.&nbsp;<br /></p><p>Boulos has helped lead and organise two mass demonstrations already in the past month and will be at the forefront of a third protest this Saturday. Tens of thousands of people are expected to turn out.&nbsp;<br /></p><ul><li><a href="https://www.theguardian.com/world/2021/jul/01/bolsonaro-brazil-vaccine-covid-scandal">Pressure mounts on Bolsonaro amid rising anger over vaccine corruption scandal</a></li></ul><p><br /></p> <a href="https://www.theguardian.com/world/video/2021/jul/03/the-brazilian-protest-leader-determined-to-bring-bolsonaros-genocidal-government-down-video">Continue reading...</a>

