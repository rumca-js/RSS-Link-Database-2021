# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## 5 Problems With Plastic and How We Can Fix Them | Compilation
 - [https://www.youtube.com/watch?v=O3ze21R8bec](https://www.youtube.com/watch?v=O3ze21R8bec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-07-04 00:00:00+00:00

Though not everyone is excited about it, plastics are pretty much everywhere. But what problems are they causing and is there anything we can do to solve those problems?

Hosted by: Michael Aranda

Why We're So Bad at Recycling Plastic - https://www.youtube.com/watch?v=unLu7rFRGc0&t=3s
Paper, Plastic, or Reusable? The Truth About Green Grocery Bags - https://www.youtube.com/watch?v=JvzvM9tf5s0
Why You Should Care About the Plastic in Your Poop - https://www.youtube.com/watch?v=Qi7Ak_wsqaQ
Should I Be Afraid of BPA? - https://www.youtube.com/watch?v=8mXosTkwtYs
How Can We Clean Up the Oceans? - https://www.youtube.com/watch?v=7i8pjnjZcF8

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org

----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Alisa Sherbow, Silas Emrys, Drew Hart. Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Jason A Saslow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------

