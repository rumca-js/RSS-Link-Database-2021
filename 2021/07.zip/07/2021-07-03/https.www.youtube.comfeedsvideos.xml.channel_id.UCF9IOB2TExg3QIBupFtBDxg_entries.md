# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Canadian heat stroke
 - [https://www.youtube.com/watch?v=nBwi_gme-gA](https://www.youtube.com/watch?v=nBwi_gme-gA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-04 00:00:00+00:00

Friendly Pharmacy 5: https://www.youtube.com/c/FriendlyPharmacy5

Vitamin D & Immunity in Older Adults: A Study published by Oxford University Press: https://www.youtube.com/watch?v=0dIAyLLhUFg&t=75s

Photosensitivity and your skin: https://www.skincancer.org/risk-factors/photosensitivity/
The Sun and Your Medicine: https://www.fda.gov/drugs/special-features/sun-and-your-medicine

Government of Canada Extreme Heat Waves: https://www.canada.ca/en/health-canada/services/sun-safety/extreme-heat-heat-waves.html

Over 700 deaths reported in BC during extreme heat wave: https://www.cheknews.ca/over-700-sudden-deaths-reported-in-b-c-amid-heat-wave-chief-coroner-832913/

## Canada update
 - [https://www.youtube.com/watch?v=beFQ_fpbaPo](https://www.youtube.com/watch?v=beFQ_fpbaPo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-03 00:00:00+00:00

References: COVID-19 Update, Saugeen First Nation, Residential schools in Canada

Friendly Pharmacy 5: https://www.youtube.com/c/FriendlyPharmacy5

Vitamin D & Immunity in Older Adults: A Study published by Oxford University Press: https://www.youtube.com/watch?v=0dIAyLLhUFg&t=75s
 

10 SCIENTIFIC Reasons to Support AIRBORNE Transmission of SARS-CoV-2: https://www.youtube.com/watch?v=gD1kEezz7fQ&t=23s
COVID-19 2nd Dose & Variants of Concern; How EFFECTIVE is the MIX & MATCH Approach: https://www.youtube.com/watch?v=cXrhX3m7c94&t=65s
 
COVID-19 Vaccine Effectiveness against Variants of Concern: Dr. Kim Gauthier PhD: https://www.youtube.com/watch?v=bppcSNGFQAM&t=656s
 
 Royal Society of Canada: Excess All-cause mortality during the COVID-19 pandemic: https://rsc-src.ca/en/covid-19-policy-briefing/excess-all-cause-mortality-during-covid-19-epidemic-in-canada
Health Canada Epidemiologic Summary: https://health-infobase.canada.ca/covid-19/epidemiological-summary-covid-19-cases.html

Chief declares emergency and crisis amid outbreak at Saugeen: https://www.owensoundsuntimes.com/news/local-news/chief-declares-emergency-and-crisis-amid-outbreak-at-saugeen

Residential Schools in Canada: https://www.thecanadianencyclopedia.ca/en/article/residential-schools

Toronto clinic administers record-breaking 26,000+
 doses in one day: https://toronto.ctvnews.ca/toronto-clinic-administers-record-breaking-26-000-doses-in-one-day-1.548745

COVID-19 deaths in Canada may be 2 times higher than reported, study finds: https://www.cbc.ca/news/health/canada-covid-19-excess-deaths-1.6084595

Where is the Delta variant most prevalent in Canada?: https://www.ctvnews.ca/health/coronavirus/where-is-the-delta-variant-most-prevalent-in-canada-1.5490578

## Ireland special report
 - [https://www.youtube.com/watch?v=YnLuJ-qTZvk](https://www.youtube.com/watch?v=YnLuJ-qTZvk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-03 00:00:00+00:00

Great insights PJ, thank you. https://www.96fm.ie/player/

