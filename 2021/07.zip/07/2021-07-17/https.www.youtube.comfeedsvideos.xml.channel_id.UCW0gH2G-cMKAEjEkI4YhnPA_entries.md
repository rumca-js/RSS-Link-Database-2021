# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Greatest Axes in Middle-earth | Tolkien Explained
 - [https://www.youtube.com/watch?v=7CqC-fEsboU](https://www.youtube.com/watch?v=7CqC-fEsboU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-07-17 00:00:00+00:00

It's the most famous axes, maces, hammers, and spears of Middle-earth to conclude our weapons series!  From the legendary deeds of First Age heroes like Húrin and Tuor, to more recent axe wielders like Gimli and Dain Ironfoot, who uses his great red axe. 

*Hit subscribe - and the bell!* 
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Jenny Dolfen - goldseven.wordpress.com/


Melkor Teaches the Noldor to Manufacture Arms - Ivana Lekseich
House of the Hammer of Wrath - Thomas Rouillard
Gimli - Sergio Pena
Beleriand Map - Lamaarcana
Aure Entuluva - Jenny Dolfen
Hurin - Michal Ivan
Hurin - Steamey
Hurin's Last Stand - Brokenmachine86
Ulmo and Tuor - Daniel Pilla
Gondolin - Alan Lee
Tuor - Natalie Chen
Flight of the Doomed - Ted Nasmith
Ships of the Faithful - Ted Nasmith
Numenorean Armor - Turner Mohan
Imperial Numenorean Armor - Turner Mohan
Across Middle-earth: The Argonath - Ralph Damiani
The Argonath - Armand Cabrera
The Argonath - JC Barquet
Gimli - Julio ROcha
Rog - Natalie Chen
Lord of Gondolin - Kazuki Mendou
Feanor against the Lord of Balrogs - Evolvana
Morgoth and Fingolfin - Joel Kilpatrick
Fingolfin's Challenge - John Howe
Grond - Lonesome Crow
Grond - Paul Raymond Gregory
Sauron - Jean Pascal Lecler
Sauron vs Elendil and Gil-Galad on Orodruin - Kip Rasmussen
Gil-galad - Sebastian Pagh
Gil-galad - Mellorianj
Gil-galad - Ivan Cavini
Azaghal - Turner Mohan
Glaurung - Justin Gerard
Death of Azaghal - David Cuzik
Azaghal the Great King of Belegost - DracarysDrekkar7
Azaghal - Steamey
Upper Armories of the Deep - Tulikoura
Battle for Moria - Tulikoura
The Battle of the Five Armies - Ozakuya
The Battle of Five Armies - Justin Gerard
Vengeance - Steamey
Dain Ironfoot - WETA
King Brand and King Dain Ironfoot - Steamey
Easterling Skirmisher - Martin de Diego
Forty-Two - Matthew Stewart
The Fellowship of the Ring - JB Casacop
Gimli 300 Rise of the Empire Inspired - Sabrisalim
The Battle of Amon Hen - Chris Rahn
Eol - Yi Jong

#axes #tolkien #lordoftherings

