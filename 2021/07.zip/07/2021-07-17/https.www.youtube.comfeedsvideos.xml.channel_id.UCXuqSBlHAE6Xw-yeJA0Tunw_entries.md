# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Where did these AWESOME Retro Consoles come from??? - Anbernic, Retroid, ODROID
 - [https://www.youtube.com/watch?v=LXj5A9ZhPSE](https://www.youtube.com/watch?v=LXj5A9ZhPSE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-07-18 00:00:00+00:00

Check out the Manta toolkit at: https://www.iFixit.com/LTT

Every gaming handheld I’ve ever owned has come from some big Japanese company – But these didn’t. What are they, and can they possibly be any good?

Buy ANBERNIC RG351M
On Amazon (PAID LINK): https://geni.us/wyoXuo
On Newegg (PAID LINK): https://geni.us/4vCfF0

Buy Retroid Pocket 2
On Amazon (PAID LINK): https://geni.us/pNp8iqt
On Newegg (PAID LINK): https://geni.us/P0MBl0

Check out the ODROID-GO Super at https://lmg.gg/QZpTN 

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1357425-where-did-these-come-from/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:38 What ARE these?
1:55 Anbernic RG351M
6:22 Retroid Pocket 2
10:53 ODROID-Go Super
14:47 Some history
16:18 Piracy
17:13 Conclusion

## The PRACTICAL Tech Transformation - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=ShtiJ8Y2alE](https://www.youtube.com/watch?v=ShtiJ8Y2alE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-07-17 00:00:00+00:00

Thanks to Intel for sponsoring this series! Check out the Intel Core i9-10850K (PAID LINK): https://geni.us/4w11

Buy Intel Core i9-10850K CPU
On Amazon (PAID LINK): https://geni.us/2Vp22w
On Best Buy (PAID LINK): https://geni.us/53Fd0b 
On Newegg (PAID LINK): https://geni.us/HAOo

Buy ASUS ROG Strix Z490-E
On Amazon (PAID LINK): https://geni.us/BA46A
On Best Buy (PAID LINK): https://geni.us/SGyOBjK
On Newegg (PAID LINK): https://geni.us/8u1A

Buy Crucial Ballistix 16GB (8GBx2) DDR4 RAM
On Amazon (PAID LINK): https://geni.us/zmnR

Buy Toshiba X300 4TB HDD
On Amazon (PAID LINK): https://geni.us/nmuFVm
On Newegg (PAID LINK): https://geni.us/FedBkw4

Buy Seasonic Syncro Q7 Case
On Newegg (PAID LINK): https://geni.us/Z56ORJ

Buy EVGA RTX 3080 Ti XC3 Ultra Gaming GPU
On Amazon (PAID LINK): https://geni.us/Kgo2eGa
On Best Buy (PAID LINK): https://geni.us/AB2X8as
On Newegg (PAID LINK): https://geni.us/SuPpM

Buy HP ENVY 14 (2021)
On HP (PAID LINK): https://geni.us/vAsvKv9
On Amazon (PAID LINK): https://geni.us/ki3OM9
On B&H (PAID LINK): https://geni.us/eBZJp

Buy Microsoft Surface Headphones 2
On Amazon (PAID LINK): https://geni.us/CCfc
On Best Buy (PAID LINK): https://geni.us/n0KzT
On Newegg (PAID LINK): https://geni.us/K2BCFn

Buy Dell S2721D Monitor
On Amazon (PAID LINK): https://geni.us/hotR

Buy Logitech G305 LIGHTSPEED Wireless Gaming Mouse
On Amazon (PAID LINK): https://geni.us/p5UJT
On Best Buy (PAID LINK): https://geni.us/ON7Ln
On Newegg (PAID LINK): https://geni.us/dkCQx8f

Buy Logitech K400 Plus Wireless TV Keyboard
On Amazon (PAID LINK): https://geni.us/6QUBcNY
On Newegg (PAID LINK): https://geni.us/futfB8P
On B&H (PAID LINK): https://geni.us/l7Ogrxw

Buy Philips Hue Smart Lightstrip Plus 2m/6ft Base Kit
On Amazon (PAID LINK): https://geni.us/hpyyWT
On Best Buy (PAID LINK): https://geni.us/uDpeF
On B&H (PAID LINK): https://geni.us/B0MOaC

Buy Logitech K845 Mechanical Keyboard
On Amazon (PAID LINK): https://geni.us/DfiiA
On Newegg (PAID LINK): https://geni.us/3AOePr
On B&H (PAID LINK): https://geni.us/GJoo

Buy RODE PSA 1 Microphone Boom Arm
On Amazon (PAID LINK): https://geni.us/QoOiI
On Best Buy (PAID LINK): https://geni.us/tFNzQm
On Newegg (PAID LINK): https://geni.us/eSi1G
Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1357288-a-big-tech-transformation-intel-5000-extreme-tech-upgrade/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro

