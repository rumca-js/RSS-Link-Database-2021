## France: Thousands protest against vaccination, COVID passes | AP News
 - [https://apnews.com/article/europe-business-health-government-and-politics-france-d25494f4cf4ca6c6d1464188a89ece6f](https://apnews.com/article/europe-business-health-government-and-politics-france-d25494f4cf4ca6c6d1464188a89ece6f)
 - RSS feed: https://apnews.com
 - date published: 2021-07-17 19:59:30+00:00

France: Thousands protest against vaccination, COVID passes | AP News

