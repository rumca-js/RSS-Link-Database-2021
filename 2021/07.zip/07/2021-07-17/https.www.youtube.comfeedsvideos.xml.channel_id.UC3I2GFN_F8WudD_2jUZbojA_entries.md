# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Kiwi Jr. - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Jyp_CjQgXiw](https://www.youtube.com/watch?v=Jyp_CjQgXiw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-17 00:00:00+00:00

http://KEXP.ORG presents Kiwi Jr. performing live, recorded exclusively for KEXP.

Songs:
Cooler Returns
Salary Man
Domino
Highlights Of 100
Undecided Voters

"Shot live on location at Heat (1995) Crime/Drama"
Camera & Editing: Danny Alexander
Camera: Keith McManamen
Audio Engineer: Jason Cabanaw
Producer: Mike Philip Walker

This project is funded in part by FACTOR, the Government of Canada and Canada’s private radio broadcasters. 
Ce projet est financé en partie par FACTOR, le gouvernement du Canada et les radiodiffuseurs privés du Canada.

https://www.kiwijr.com
http://kexp.org

