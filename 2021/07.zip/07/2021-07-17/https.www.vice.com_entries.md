## We Got the Phone the FBI Secretly Sold to Criminals
 - [https://www.vice.com/en/article/n7b4gg/anom-phone-arcaneos-fbi-backdoor](https://www.vice.com/en/article/n7b4gg/anom-phone-arcaneos-fbi-backdoor)
 - RSS feed: https://www.vice.com
 - date published: 2021-07-17 10:09:37.453176+00:00

'Anom’ phones used in an FBI honeypot are mysteriously showing up on the secondary market. We bought one.

