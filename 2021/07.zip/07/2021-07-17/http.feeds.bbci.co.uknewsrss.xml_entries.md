# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Broadway dancer whose lockdown business bloomed
 - [https://www.bbc.co.uk/news/stories-57840115](https://www.bbc.co.uk/news/stories-57840115)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-07-17 23:22:52+00:00

When Covid closed New York theatres, dancer Robbie Fairchild started a business that put down roots.

