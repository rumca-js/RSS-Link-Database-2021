## Clippy returns - as an emoji - BBC News
 - [https://www.bbc.co.uk/news/technology-57849880](https://www.bbc.co.uk/news/technology-57849880)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-07-17 13:56:38.481647+00:00

Microsoft changes its paperclip emoji to look like its early virtual assistant, the object of much affection and frustration.

## Health Secretary Sajid Javid tests positive for Covid - BBC News
 - [https://www.bbc.co.uk/news/uk-57874744](https://www.bbc.co.uk/news/uk-57874744)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2021-07-17 13:51:58.615293+00:00

He says he has had two jabs and so far his symptoms are "very mild" after feeling "groggy" on Friday.

