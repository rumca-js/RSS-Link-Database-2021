## ‘Hubble is back!’ Famed space telescope has new lease on life after computer swap appears to fix glitch | Science | AAAS
 - [https://www.sciencemag.org/news/2021/07/hubble-back-famed-space-telescope-has-new-lease-life-after-computer-swap-appears-fix](https://www.sciencemag.org/news/2021/07/hubble-back-famed-space-telescope-has-new-lease-life-after-computer-swap-appears-fix)
 - RSS feed: https://www.sciencemag.org
 - date published: 2021-07-17 08:16:58.191035+00:00

Email suggests famed space telescope could quickly resume scientific observations

