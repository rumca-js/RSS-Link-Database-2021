# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Amplify with Lara Downes: Will Liverman
 - [https://www.youtube.com/watch?v=y0i3Oflyvwc](https://www.youtube.com/watch?v=y0i3Oflyvwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2021-07-17 00:00:00+00:00

Lara Downes | July 17, 2021
In Februrary, Will Liverman released his album Dreams of a New Day. It's a beautiful collection of art songs by Black composers, many in world premiere recordings, that chart the peaks and valleys of the Black American experience, celebrating hope and joy, but too often chronicling pain, violence and loss.

The opening track is a setting by composer Damien Sneed of Langston Hughes' "I Dream a World," in which the poet writes: "A world I dream where black or white, / Whatever race you be, / Will share the bounties of the earth / And every man is free."

That dream — a dream deferred — took on urgency and energy in recent years, bringing millions together in the streets of our cities. And those of us who express this dream through music have also come together, lifting our voices in a crescendo that asks for one simple thing: just to be heard. When we choose, as Will and I both have, to uncover the forgotten music of Black composers like Margaret Bonds, Florence Price, and H. Leslie Adams, when we collaborate with Black composers of our own generation to create new work, we do it because we want our own stories to be heard, and we want to tell them in our own way.

Next season, Will stars in the first opera by a Black composer ever performed at New York's Metropolitan Opera — a dream come true, for him and for the many singers before him who never had that chance. And he's writing his own opera, The Factotum, a joyous reimagining of Rossini's The Barber of Seville that's set in a modern-day Black barbershop on Chicago's South Side, with a score that draws on hip-hop, R&B and gospel as well as classic opera. He's realizing the dream of telling his own story, to be heard in a new way, for a new day.

