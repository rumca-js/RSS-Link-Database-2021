# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Dlaczego moszna?
 - [https://www.youtube.com/watch?v=NhWtSaLT1-g](https://www.youtube.com/watch?v=NhWtSaLT1-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-07-17 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Czas pochylić się nad ważnym pytaniem...

===
Rozkład jazdy:

0:00 W czasie kręcenia filmu nie ucierpiał żaden Adam
1:10 Ciężar posiadania moszny
2:48 Przegląd moszny ssaków
5:30 Zimny chów
8:36 Hartowanie plemników
11:46 Hipoteza galopu
13:15 Nieodpowiadalne pytanie

===
Źródła (wybrane):

L. Welderin i in. - The evolution of the scrotum and testicular descent in mammals: a phylogenetic view
K. Kleisner i in. - The evolutionary history of testicular externalization and the origin of the scrotum
W. B. Miller i in. - Reappraising the exteriorization of the mammalian testes through evolutionary physiology

L. Drew - Ja, ssak. Co łączy nas z gorylem, wielorybem i nietoperzem

https://www.smithsonianmag.com/science-nature/earliest-mammals-kept-their-cool-descended-testicles-180969476/

