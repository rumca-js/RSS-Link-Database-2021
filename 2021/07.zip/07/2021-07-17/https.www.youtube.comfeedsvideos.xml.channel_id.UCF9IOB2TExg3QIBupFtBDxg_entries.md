# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## US, Vaccine immune escape
 - [https://www.youtube.com/watch?v=YYmW-FqSQBE](https://www.youtube.com/watch?v=YYmW-FqSQBE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-17 00:00:00+00:00

US, Delta, New infections, up 70%. It's July, obviously.
https://www.washingtonpost.com/health/2021/07/16/covid-cases-rising/
Hospitalization, up 36%

(Unvaccinated, 97% of admissions)

Deaths, up 26%

(Almost all unvaccinated)

https://covid.cdc.gov/covid-data-tracker/#vaccination-trends

US, 68% of population with one dose

CDC, Rochelle Walensky

This is becoming a pandemic of the unvaccinated

We are seeing outbreaks in parts of the country that have low vaccination coverage

Because unvaccinated people are at risk

All over the country

Anthony Fauci

Delta variant, more than 70% of cases

Young people, been particularly hesitant about getting vaccinated

Hospitalized to a greater extent than they were earlier in the pandemic, in large part 
because most older Americans are vaccinated.

Four worst states, 41% of new infections

California

Texas 

Missouri

Florida 

(20% of new infections, 45,000 cases last week, 47% fully vaccinated)

LA county, masks required in public spaces

Tennessee

Last 2 weeks, 310% increase in cases

Breakthrough infections

27 states report 66,000 breakthroughs

NBC, not CDC

Hospitalizations rare

President Biden

Vaccine misinformation is killing people

66% of unvaccinated adults believe myths about vaccines

Dr. Murthy

https://www.hhs.gov/sites/default/files/surgeon-general-misinformation-advisory.pdf

During this pandemic, health misinformation has led people to resist wearing masks

and to choose not to get vaccinated

All of this has led to avoidable illnesses and deaths. Simply put, health misinformation has cost us lives

Hesitancy, (Census bereau)

https://www.census.gov/library/visualizations/interactive/household-pulse-survey-covid-19-vaccination-tracker.html

Household Pulse Survey COVID-19 Vaccination Tracker

UK

Testing positive, + 54,674

300,302 (up 40.5%)


Admitted,+ 740

4,313 (up 39,4%)

Deaths, + 41

284 (up 47.9%)

## Uganda, Special report
 - [https://www.youtube.com/watch?v=9zOFmA8wO1I](https://www.youtube.com/watch?v=9zOFmA8wO1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-17 00:00:00+00:00

To donate to Wefwafwa, Use Sendwave
Mobile money: +256785698803
Registered name: Wefwafwa Andrew
Country: Uganda
Email: wefandew@gmail.com
If you do send a donation, please text Wefwafwa as well so he can acknowledge and thank you
Please subscribe to Wefafa's channel, it will help his work, https://www.youtube.com/channel/UCzsLklGgOttU3Se-WGLp7ow

