## What I learned from Software Engineering at Google | Swizec Teller
 - [https://swizec.com/blog/what-i-learned-from-software-engineering-at-google/](https://swizec.com/blog/what-i-learned-from-software-engineering-at-google/)
 - RSS feed: https://swizec.com
 - date published: 2021-07-17 22:27:11.938024+00:00

When I first picked up Software Engineering at Google I thought it was another one of those FAANG books full of lessons that make no sense at human scale. I was surprised, lessons apply to teams as small as 5.

