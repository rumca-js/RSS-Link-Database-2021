# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Lanue - July (live MN Session for The Current)
 - [https://www.youtube.com/watch?v=cgh6WfUGvCg](https://www.youtube.com/watch?v=cgh6WfUGvCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-17 00:00:00+00:00

For The Current's Minnesota Sessions, Sarah Krueger brings the lustrous sounds of her project, Lanue, to Black Beach in Silver Bay, Minnesota. Under the Lanue moniker, the Duluth-based singer-songwriter embarks on a new artistic evolution with multilayered soundscapes that weave in acoustic and electronic elements. Watch a performance of "July" from Lanue's 2021 self-titled album.

Minnesota Sessions are presented by Lovin' Lake County. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

The Current encourages all music fans to support their local artists and the continued longevity of their craft. As part of this effort, The Current will be compensating artists for their performances in Minnesota Sessions through the Legacy Amendment Arts and Cultural Fund.

## Lanue - Something Sacred (live MN Session for The Current)
 - [https://www.youtube.com/watch?v=VboDWyLmqWI](https://www.youtube.com/watch?v=VboDWyLmqWI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-17 00:00:00+00:00

For The Current's Minnesota Sessions, Sarah Krueger brings the lustrous sounds of her project, Lanue, to Black Beach in Silver Bay, Minnesota. Under the Lanue moniker, the Duluth-based singer-songwriter embarks on a new artistic evolution with multilayered soundscapes that weave in acoustic and electronic elements. Watch a performance of "Something Sacred" from Lanue's 2021 self-titled album.

Minnesota Sessions are presented by Lovin' Lake County. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

The Current encourages all music fans to support their local artists and the continued longevity of their craft. As part of this effort, The Current will be compensating artists for their performances in Minnesota Sessions through the Legacy Amendment Arts and Cultural Fund.

## Lanue - What I Love The Most (live MN Session for The Current)
 - [https://www.youtube.com/watch?v=OjS7j6A4pxI](https://www.youtube.com/watch?v=OjS7j6A4pxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-17 00:00:00+00:00

For The Current's Minnesota Sessions, Sarah Krueger brings the lustrous sounds of her project, Lanue, to Black Beach in Silver Bay, Minnesota. Under the Lanue moniker, the Duluth-based singer-songwriter embarks on a new artistic evolution with multilayered soundscapes that weave in acoustic and electronic elements. Watch a performance of "What I Love The Most" from Lanue's 2021 self-titled album.

Minnesota Sessions are presented by Lovin' Lake County. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

The Current encourages all music fans to support their local artists and the continued longevity of their craft. As part of this effort, The Current will be compensating artists for their performances in Minnesota Sessions through the Legacy Amendment Arts and Cultural Fund.

