# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Do This For Maximum Security On The Web
 - [https://www.youtube.com/watch?v=pid5kmWXSj8](https://www.youtube.com/watch?v=pid5kmWXSj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-07-17 00:00:00+00:00

JavaScript will probably ruin your life. Disable it, block it, and stay safe from the most common vector of malware infection.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Sources
Text tutorial on how to disable JavaScript on Chromium browsers: https://www.howtogeek.com/663569/how-to-disable-and-enable-javascript-on-google-chrome/
Tor Browser security settings: https://tb-manual.torproject.org/ga/security-settings/


The following browser add-ons can be found in your browser's extension store (i.e. Chrome or Mozilla):
NoScript: https://noscript.net/
uBlock Origin: https://github.com/gorhill/uBlock

Official documentation on JavaScript by Mozilla
https://developer.mozilla.org/en-US/docs/Web/JavaScript 
https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps/What_is_JavaScript

General information about JavaScript 
https://w3techs.com/technologies/details/cp-javascript/
History of JS http://speakingjs.com/es5/ch04.html
Web 2.0 https://www.britannica.com/topic/Web-20
https://www.oreilly.com/pub/a//web2/archive/what-is-web-20.html

JavaScript security report 2020
https://go.talasecurity.io/global-data-risk-state-web-report-2020?

Examples of exploits delivered by JavaScript 
https://citizenlab.ca/2016/08/million-dollar-dissident-iphone-zero-day-nso-group-uae/
https://www.zdnet.com/article/an-insecure-mess-how-flawed-javascript-is-turning-web-into-a-hackers-playground/
https://www.techrepublic.com/article/major-websites-plagued-by-lack-of-effective-security-against-javascript-vulnerabilities/
Cross-site scripting: https://www.cloudflare.com/learning/security/threats/cross-site-scripting/
https://arstechnica.com/gadgets/2018/01/meltdown-and-spectre-heres-what-intel-apple-microsoft-others-are-doing-about-it/
https://googleprojectzero.blogspot.com/2019/08/a-very-deep-dive-into-ios-exploit.html
https://techcrunch.com/2019/08/29/google-iphone-secretly-hacked/
https://www.forbes.com/sites/thomasbrewster/2019/09/01/iphone-hackers-caught-by-google-also-targeted-android-and-microsoft-windows-say-sources/
https://www.bleepingcomputer.com/news/security/google-fixes-sixth-chrome-zero-day-exploited-in-the-wild-this-year/



Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

