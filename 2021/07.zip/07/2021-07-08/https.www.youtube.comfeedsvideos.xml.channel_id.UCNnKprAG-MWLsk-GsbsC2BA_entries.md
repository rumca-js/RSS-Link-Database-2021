# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## The Furry Pit
 - [https://www.youtube.com/watch?v=xHazuLosflE](https://www.youtube.com/watch?v=xHazuLosflE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2021-07-08 00:00:00+00:00

Support us on Patreon!
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers!

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

Animatic  ►
Perry Hull

Animation ►
Don Greger
James Cunningham
Szymon Kwinto
CalebJordann

Backgrounds ►  
Lines - Soured Apple https://www.twitter.com/SouredApple
Color - Naav Draws https://www.instagram.com/naav_draws/

Lip Sync ► 
Lewis Bown
 
Sound ► 
Justin Greger

VO ►
Black Templar - Tim Plewman
Furry Emperor - Don Greger

Music ►
Tom Ryan

Ad Compositing ► 
Oddest of the Odd

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

