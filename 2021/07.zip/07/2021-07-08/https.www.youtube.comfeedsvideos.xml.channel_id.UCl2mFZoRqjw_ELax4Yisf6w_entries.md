# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## 1st ave walkthrough: East Village, NYC is becoming a dead mall.
 - [https://www.youtube.com/watch?v=OqSUhVjS77o](https://www.youtube.com/watch?v=OqSUhVjS77o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-09 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://evgrieve.com/
👉 https://www.reddit.com/r/nyc/comments/innhah/nearly_twothirds_of_new_york_restaurants_may_have/g4ai27m/?context=3
🔵 Camera: https://bit.ly/sonyax53camera
🔵 Microphone: https://bit.ly/dpa4065

Title is NOT FINANCIAL ADVICE, not investment advice, and is just my opinion. Do not short CMBS and say I told you to. People thought shorting gamestop was a good idea in December...

## BIDEN SIGNS EXECUTIVE ORDER ON RIGHT TO REPAIR!
 - [https://www.youtube.com/watch?v=GE-qEDjUJYY](https://www.youtube.com/watch?v=GE-qEDjUJYY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-09 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.whitehouse.gov/briefing-room/statements-releases/2021/07/09/fact-sheet-executive-order-on-promoting-competition-in-the-american-economy/
🔵 IRP program: https://www.youtube.com/watch?v=rwgpTDluufY
🔵 IRP program: https://www.reddit.com/r/RealTesla/comments/ith4va/tesla_detects_unauthorized_modifications_after/g5g3vip?utm_source=share&utm_medium=web2x&context=3
🔵 FTC report: https://www.ftc.gov/system/files/documents/reports/nixing-fix-ftc-report-congress-repair-restrictions/nixing_the_fix_report_final_5521_630pm-508_002.pdf
🔵 FTC video: https://www.youtube.com/watch?v=ZKALUEoRd7E
🔵 CBC news piece on the Genius Bar: https://www.youtube.com/watch?v=o2_SZ4tfLns
🔵 Steve Wozniak supporting Right to Repair: https://www.youtube.com/watch?v=CN1djPMooVY
🔵 My old Right to Repair video from 2013: https://www.youtube.com/watch?v=UdlZ1HgFvxI

## A2141 Macbook Pro has same design flaw as 2016 Macbook Pro!
 - [https://www.youtube.com/watch?v=KQXXqny2wEA](https://www.youtube.com/watch?v=KQXXqny2wEA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.youtube.com/watch?v=jahtu1_idVU
https://www.youtube.com/watch?v=jtUwBZ4R9fI

🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 TOOLS USED:
✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station with bent nozzles: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl



✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Discord: https://tinyurl.com/rossmatrix

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## An honest conversation with Autocare
 - [https://www.youtube.com/watch?v=39K70VZ8SPA](https://www.youtube.com/watch?v=39K70VZ8SPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
I'M SORRY ABOUT THE AUDIO, I was using streamyard. It does this regularly and it drives me nuts. It's a horribly buggy platform. Usually I record my own audio separately in Vegas and sync it later, I forgot to this time so I had to use streamyard audio which is garbage. 


https://www.ratchetandwrench.com/articles/11439-right-to-repair-suit-in-court

## Commercial Mortgage Backed Securities are destroying NYC.
 - [https://www.youtube.com/watch?v=kuALRyGI3Ho](https://www.youtube.com/watch?v=kuALRyGI3Ho)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
This is SoHo & Greenwich Village. 
👉 https://www.reddit.com/r/nyc/comments/innhah/nearly_twothirds_of_new_york_restaurants_may_have/g4ai27m/?context=3
🔵 Camera: https://bit.ly/sonyax53camera
🔵 Microphone: https://bit.ly/dpa4065

Title is NOT FINANCIAL ADVICE, not investment advice, and is just my opinion. Do not short CMBS and say I told you to. People thought shorting gamestop was a good idea in December...

## Ford outdoes Tesla in being a shitty unrepairable brand
 - [https://www.youtube.com/watch?v=dzoe7mEHr30](https://www.youtube.com/watch?v=dzoe7mEHr30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.autoevolution.com/news/mustang-mach-e-owner-gets-rear-ended-is-mad-about-parts-not-being-available-164814.html

👉 https://www.youtube.com/watch?v=EozPi1qmH44

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my

🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W
g-available-164814.html

## Freedom vs planning; it's not MY place to plan YOUR life!
 - [https://www.youtube.com/watch?v=PWBE7iApIuA](https://www.youtube.com/watch?v=PWBE7iApIuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.reddit.com/r/apple/comments/ofq1sz/steve_wozniak_speaks_on_right_to_repair/h4eiowy/?context=3

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

