# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## A New Ember: Flame 4VOX Polyphonic Wavetable Oscillator
 - [https://www.youtube.com/watch?v=JRSw2hV6Lck](https://www.youtube.com/watch?v=JRSw2hV6Lck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2021-07-09 00:00:00+00:00

The 4Vox is a quad wavetable oscillator with up to four voices per VCO channel, resulting
in a maximum of 16 voices at four individual outputs. 

https://www.modulargrid.net/e/flame-4vox

This is a weird one. I sold it after having it for about a week after buying it new. It's a really interesting oscillator but I found it pretty unwieldy to use. YMMV!

I have a big video of just performances with this thing over yonder: https://youtu.be/1vykoQD0Zs8

Modules used in this video:
After Later Monsoon:  http://bit.ly/pc_after_later
Bubblesound HEXvca: http://bit.ly/pc_hexvca
Intellijel Quad VCA: http://bit.ly/pc_quadvca
Intellijel Quadrax: http://bit.ly/pc_quadrax
Klavis Quadigy: http://bit.ly/pc_quadigy
Klavis Twin Waves MkII: http://bit.ly/pc_twin_waves
Ornament and Crime:  http://bit.ly/pc_oc
ALM Pamela's New Workout: https://bit.ly/2QRxnZO
Tip-Top Z5000: http://bit.ly/pc_z5000
Varigate 8+: http://bit.ly/pc_varigate
VPME QD: http://bit.ly/pc_VPME_QD
XAOC Devices Zadar: http://bit.ly/pc_zadar
------------------------------------
If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

