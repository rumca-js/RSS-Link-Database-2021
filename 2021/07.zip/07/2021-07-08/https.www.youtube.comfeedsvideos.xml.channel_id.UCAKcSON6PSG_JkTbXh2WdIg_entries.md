# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Dave Simonett - The High Road (live MN Session for The Current)
 - [https://www.youtube.com/watch?v=EvN9gIFIAPo](https://www.youtube.com/watch?v=EvN9gIFIAPo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-09 00:00:00+00:00

For The Current's Minnesota Sessions, Dave Simonett brings acoustic tunes to the Wolf Ridge Environmental Learning Center. You know Dave as the frontman of Duluth-based bluegrass act Trampled by Turtles as well as his work under the moniker Dead Man Winter, and he's developed a legacy as an endearing and thoughtful songwriter. Watch Dave play "The High Road" from his 2021 solo EP, Orion.

Minnesota Sessions are presented by Lovin' Lake County. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

The Current encourages all music fans to support their local artists and the continued longevity of their craft. As part of this effort, The Current will be compensating artists for their performances in Minnesota Sessions through the Legacy Amendment Arts and Cultural Fund.

## Dave Simonett - Pisces, Queen of Hearts (live MN Session for The Current)
 - [https://www.youtube.com/watch?v=vFSNnZ1J31g](https://www.youtube.com/watch?v=vFSNnZ1J31g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-08 00:00:00+00:00

For The Current's Minnesota Sessions, Dave Simonett brings acoustic tunes to the Wolf Ridge Environmental Learning Center. You know Dave as the frontman of Duluth-based bluegrass act Trampled by Turtles as well as his work under the moniker Dead Man Winter, and he's developed a legacy as an endearing and thoughtful songwriter. Watch Dave play "Pisces, Queen of Hearts" from his 2020 solo LP, Red Tail.

Minnesota Sessions are presented by Lovin' Lake County. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

The Current encourages all music fans to support their local artists and the continued longevity of their craft. As part of this effort, The Current will be compensating artists for their performances in Minnesota Sessions through the Legacy Amendment Arts and Cultural Fund.

## Listen to Looch: "Summer of Soul" is a must-see documentary
 - [https://www.youtube.com/watch?v=DS1-vOW53HA](https://www.youtube.com/watch?v=DS1-vOW53HA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-08 00:00:00+00:00

Mary Lucia talks about "Summer of Soul," a new documentary directed by Questlove that features footage of performances — stashed away for 50 years — of the Harlem Cultural Festival that took place in New York in 1969.

The lineup was incredible, featuring such artists as Stevie Wonder, Gladys Knight and the Pips, the Staple Singers, Sly and the Family Stone, Mahalia Jackson, Hugh Masekela, the Fifth Dimension, B.B. King and many others. Notably, the festival took place in 1969, the same year as Woodstock, but only now is this historic music and cultural moment coming back to light.

"Go watch it," Mary says. "Summer of Soul" is available in theaters and it is also streaming on Hulu.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#summerofsoul #marylucia #questlove

