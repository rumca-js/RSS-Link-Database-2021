# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The Surprising Species That Everything Else Depends On | IN OUR NATURE
 - [https://www.youtube.com/watch?v=i8wrAkixfHc](https://www.youtube.com/watch?v=i8wrAkixfHc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-07-08 00:00:00+00:00

“In Our Nature” is a NEW special limited series on It’s Okay To Be Smart!
SUBSCRIBE so you don’t miss the next episode! ►► http://bit.ly/iotbs_sub
↓↓↓ More info and sources below ↓↓↓

Seemingly distant ecosystems, even half a world apart, are connected in surprising ways. In this special limited series, Emily Graslie and Trace Dominguez join me as we explore the universal rules of life that tie together Earth’s living systems. In episode 1, we travel from Africa’s Serengeti plains to the nearly extinct prairies of the western United States to discover the unexpected species that determine the very existence of these places. Can an ecosystem survive without its keystone species? And can we restore endangered human cultures by bringing back a nearly-extinct ecosystem?

Co-hosted by:
Trace Dominguez  @TraceDominguez 
Emily Graslie   @EmilyGraslie 

References: https://sites.google.com/view/inournature-ep1-references/home 

In Our Nature is a special miniseries produced by It’s Okay To Be Smart for PBS. Stay tuned for more episodes coming this summer, here on our YouTube channel!

Original Production Funding provided by: Anne Ray Foundation, a Margaret A. Cargill Philanthropy

-----------

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart

Special thanks to our Brain Trust Patrons:

DeliciousKashmiri
Mario Orso
Brian Chang
Roy Lasris
Javier Soto
dani bowman
David Johnston
Zenimal
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Benjamin Teinby
Eric Meer
Peter Ehrnstrom
Dustin
Marcus Tuepker
Karen Haskell
AlecZero

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

