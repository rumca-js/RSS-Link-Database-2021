# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Cheap GPUs are FINALLY Coming Back!! - WAN Show July 9, 2021
 - [https://www.youtube.com/watch?v=OvjrZprxGio](https://www.youtube.com/watch?v=OvjrZprxGio)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-07-09 00:00:00+00:00

Get 25% off Display Fusion with code WANSHOW at: https://lmg.gg/DisplayFusion

Use code LTT for $50 off MAXNOMIC gaming chairs at https://geni.us/needforseat until July 18, 2021

Buy a Seasonic Ultra Titanium PSU
On Amazon: https://geni.us/q4lnefC
On NewEgg: https://lmg.gg/8KV3S

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Cheap-GPUs-are-FINALLY-Coming-Back-----WAN-Show-July-9--2021-e14b3f3

Check out our other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of NoKi1119)
[0:00] Chapters
[01:41] Intro
[02:15] Topic #1: Cryptocurrency crackdown in China leading to Graphics Card prices to drop. 
   02:37 Reasons behind the drop in prices.
   08:24 Discussing local prices.
   10:19 eBay prices on GPUs are dropping.
   11:30 The energy factor affecting Cryptomining in China.
   13:25 Cryptocurrencies dipping and Linus wanting to invest.
   15:34 The effect of chips shortage on the GPU pricing and future releases.
[19:40] Topic #2: Biden directing F.T.C. to make new regulations for Right-to-Repair.
   19:40 Biden issuing an Executive order towards F.T.C. and its regulations.
   21:00 Right to Repair already exists in automotive repairs.
   23:00 How the executive order helps farmers.
   26:12 Directive includes DoD and mobile phone contractors.
[29:14] Sponsors.
   29:22 DisplayFusion multi-monitor manager.
   30:23 NeedForSeat gaming chairs.
   31:50  Seasonic Power Supply (and more).
[32:54] Topic #2.5: Nintendo Switch "Pro" Controversy.
   32:54 Expectations V.S. Reality.
   36:48 Linus's experience with the Switch.
   39:14 Linus appreciates Nintendo's consistency.
   40:12 Linus's games of choice on Switch.
[43:20] Topic #3: Google Playstore is under fire.
   44:05 Google's Response to the whole lawsuit.
   46:35 Google anti-consumer policies on subscription-based streaming services.
   51:23 Lawsuit requires Google to "allow" for the removal of pre-installed apps.
   53:22 Thoughts on Google's response.
   56:02  LTTstore has a discount.
[57:24] Topic #3.5: China uses Facial Recognition to control gamers.
   58:25 Spending money on lootboxes  IS gambling.
   59:46 Parents should enforce the limits, NOT the government.
   1:00:50 China's 996 working hours system.
[1:03:06] Topic #4: Linus's new house challenges.
   1:04:46 The house heating problem.
   1:06:40 Whole house water-cooling.?
   1:08:47 Discussing computers.
   1:13:57 Home theater.
   1:17:46 Linus's home plan ft MsPaint.
[1:22:44] Not-So-Superchats.
[1:32:15] Wrapping up.
[1:32:24] Outro.

## CELEBRITY Tech Trivia!
 - [https://www.youtube.com/watch?v=6rIVWFCatH8](https://www.youtube.com/watch?v=6rIVWFCatH8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-07-08 00:00:00+00:00

Thanks to Intel for sponsoring Tech Trivia, Answered in the Form of a Question! Check out their 11th gen Rocket Lake CPU's
On Amazon (PAID LINK): https://geni.us/f51j
On Newegg (PAID LINK): https://geni.us/BzVVmAF

Follow Intel on Twitter: https://twitter.com/IntelTech

Thank you to EVERYONE who participated in this event! Go check them out if you haven't already.

Contestants
Snazzy Labs: https://www.youtube.com/user/ThatSnazzyiPhoneGuy
UFD Tech: https://www.youtube.com/channel/UC4Z8mPYjn6Dhr6n531YDh0Q
Bitwit: https://www.youtube.com/user/AwesomeSauceNews
Paul's Hardware: https://www.youtube.com/user/paulshardware
iJustine: https://www.youtube.com/user/ijustine
Marques Brownlee: https://www.youtube.com/user/marquesbrownlee

Special Guests
Austin Evans: https://www.youtube.com/user/duncan33303
Jayztwocents: https://www.youtube.com/user/Jayztwocents
Sara Dietschy: https://www.youtube.com/user/saradietschy
Gamers Nexus: https://www.youtube.com/user/GamersNexus
JerryRigEverything: https://www.youtube.com/user/JerryRigEverything

LTTSTORE.COM
Buy a 21oz Classic Orange LTT water bottle and get any color of our keyboard t-shirt for free! And Grab a FREE 2021 Sticker Pack with all http://www.lttstore.com purchases, while supplies last.

Discuss on the forum: https://linustechtips.com/topic/1354709-celebrity-tech-trivia/

►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

CHAPTERS
---------------------------------------------------  
0:00 Game 1
25:10 Game 2
47:39 Final Game

