# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Infections in many poorer countries
 - [https://www.youtube.com/watch?v=3Z4P9ZGZHk8](https://www.youtube.com/watch?v=3Z4P9ZGZHk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-09 00:00:00+00:00

Tunisia, 11.7 million

https://www.theguardian.com/world/live/2021/jul/06/coronavirus-live-news-germany-to-lift-uk-and-india-travel-ban-israel-to-trade-700000-pfizer-doses-with-south-korea

Cases, + 7,930 (highest so far) = 455,000

Health authorities, intensive care wards full

Situation was “catastrophic”

Zimbabwe

14.2 million

Last 2 weeks, cases quadrupled

Back to a strict lockdown, stay at home order

Delta variant

Shortages

Namibia

Conny
Well, we in face same or even worse situation then Indonesia, already for the past 6 weeks. Our death rate per capita is one of the highest in the world. No hospital beds, no oxygen... And now we are running out of vaccine. But the world doesn't take notice

Vietnam 

96.5 million

https://www.theguardian.com/world/live/2021/jul/06/coronavirus-live-news-germany-to-lift-uk-and-india-travel-ban-israel-to-trade-700000-pfizer-doses-with-south-korea?page=with:block-60e462458f083c0d860df9f8#block-60e462458f083c0d860df9f8

Cases, + 1,029 = 22,064

Ho Chi Minh City, epicentre, flights stopped 

Land controls in and out

US

https://covid.cdc.gov/covid-data-tracker/#trends_dailytrendscases

Cases up 11 % over past week

Hospitalizations up 7%

Pfizer developing tweaked delta vaccine booster

6 months after 2nd dose
Highly effective

Missouri, delta 90% of cases

Younger patients

More rapid onset of serious illness

UK

https://coronavirus.data.gov.uk
ONS

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19roundup/2020-03-26

Week ending 26 June 2021

Delta variant (B.1.617.2) continued to increase in England, Wales and Scotland

Prevalence

0.39% in England (1 in 260 people)

0.22% in Wales (1 in 450 people) 

0.15% in Northern Ireland (1 in 670 people) 

0.68% in Scotland (1 in 150 people)

Delta

Week ending 21st June

COVID-19 antibodies continue to rise in line with vaccinations across the UK countries

Percentage of adult population tested positive for COVID-19 antibodies

England, 89.8% of the adult population

Wales, 91.8%

Northern Ireland, 87.2%

Scotland, 84.7%

## US delta and more long covid
 - [https://www.youtube.com/watch?v=16PNx403DtM](https://www.youtube.com/watch?v=16PNx403DtM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-08 00:00:00+00:00

US, Delta, 51.6%,      80.7% Kansas, Missouri, Nebraska, Iowa
https://www.youtube.com/watch?v=8_aNYpQhCBw

Zoe data 

https://covid.joinzoe.com/data#levels-over-time

https://www.youtube.com/watch?v=7CQH4Kme9mQ&t=56s

Positivity rate

Unvaccinated, 5.25%

One dose, 3.2%

Fully vaccinated, 0.99%

Tim Spector

Low levels of covid for a long time

Long covid

20s 1.2%

Middle aged, 4.7%

Proportions lower than 2nd wave

1 in 80 unvaccinated going into long covid

Currently, 500 people per day

Plus 200 than have been vaccinated

50,000 cases per day would result I 1,000 long covid per day

Last year 180,000 people with at least 3 months of symptoms

Advice

Socialise outside or in a well-ventilated area

Indoor and public transport, wear masks

Hand washing

Common curtesy

Respect

Links for Vlad

Original video

https://www.youtube.com/watch?v=-LilQE3AwfY&t=292s

Vlad’s YT channel

https://www.youtube.com/channel/UC6-33VO9eerq9MXFaivi0gg

Twitter name @vladvexler and hashtag #VladsMEdiary,

https://twitter.com/VladVexler

