# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Enumclaw - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=8MCHZTD4YVw](https://www.youtube.com/watch?v=8MCHZTD4YVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-09 00:00:00+00:00

http://KEXP.ORG presents Enumclaw sharing a live performance recorded exclusively for KEXP and talking to Larry Mizell, Jr., host of The Afternoon Show. Recorded June 24, 2021.

Songs:
2002
Free Drop Billy
Cents
Cinderella
Fast N All

Recording Credits (as presented by the band):
Video By Ian Ostrowski & Tristan Johnson
Recorded @ “An Air Bnb on Anderson island that we got a negative review” by Matt Baloogz Clark
Mixed by Matt Baloogz Clark 
Audience, Chris Harmen & Xayvien Ceccarelli
Party Saver, Benji Navas
Island Guide, Cryokeen
S/O Black guy from the ferry that thought Aramis worked at wells fargo 

https://fanlink.to/Jimbodemo
http://kexp.org

## Japanese Breakfast - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=0Ghb9Quev1Y](https://www.youtube.com/watch?v=0Ghb9Quev1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-08 00:00:00+00:00

http://KEXP.ORG presents Japanese Breakfast performing live, recorded exclusively for KEXP.

Songs:
Kokomo, IN
Tactics
Be Sweet
Savage Good Boy
Ballad O (BUMPER)

Performed by Japanese Breakfast
Michelle Zauner
Peter Bradley
Craig Hendrix
Deven Craige
Molly Germer
Gabby Smith

Recorded at Baby's Alright in Brooklyn, NY
Audio Engineer Harrison Fore
Asst Audio Engineer Starr McLaughlin
Mix Engineer Craig Hendrix
Director of Photography Adam Kolodny
B-Camera Operator Robert Kolodny
Production Assistant Greg Rutkin

http://japanesebreakfast.rocks
http://kexp.org

