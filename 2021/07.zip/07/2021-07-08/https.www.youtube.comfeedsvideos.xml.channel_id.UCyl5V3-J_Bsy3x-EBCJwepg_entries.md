# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Check Out This HATEFUL Right-Wing Satire Of The Gay Community 😡
 - [https://www.youtube.com/watch?v=GATjQe_Ae3M](https://www.youtube.com/watch?v=GATjQe_Ae3M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-07-09 00:00:00+00:00

Right-wingers have been trafficking in misinformation under the guise of satire and this new comedy sketch by The San Francisco Gay Men's Chorus is hateful and bigoted toward the LGBT community.



Become a premium subscriber:  https://babylonbee.com/plans


The Official The Babylon Bee Store:  https://shop.babylonbee.com/


Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## THE BEE WEEKLY: Evangelicals, Catholics and Facebook Extremists Together
 - [https://www.youtube.com/watch?v=hTNw1m_ZxHI](https://www.youtube.com/watch?v=hTNw1m_ZxHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-07-09 00:00:00+00:00

In this episode of The Bee Weekly, Kyle and Ethan are joined by fan favorite Seamus Coughlin (twitter.com/seamus_coughlin) of FreedomToons (www.youtube.com/user/Cartanimation) to talk about skunks in pickle jars, Facebook warning you about all the extremists they platform, and how The Babylon Bee doesn’t make fun of Trump. There’s also weird news, hate mail, and the ultimate showdown between Calvinists and Catholics that will once and for all settle all theological debates. 

Be sure to visit FreedomToons: https://www.youtube.com/user/Cartanimation

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Five Tips For Reading Your Bible
 - [https://www.youtube.com/watch?v=TkPk76UoaXM](https://www.youtube.com/watch?v=TkPk76UoaXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-07-08 00:00:00+00:00

Reading your Bible can be hard with your busy schedule, hectic days, and inability to just pick it up and read it. Here are some tips to help!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

