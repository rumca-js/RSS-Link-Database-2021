# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## How dinosaurs REALLY went extinct
 - [https://www.youtube.com/watch?v=FnxMhFoRLAs](https://www.youtube.com/watch?v=FnxMhFoRLAs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-07-08 00:00:00+00:00

You want answers? Look no further... Thank you to BetterHelp for sponsoring today's video. Get 10% off you first month here: https://BetterHelp.com/nolke

Written by: Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

