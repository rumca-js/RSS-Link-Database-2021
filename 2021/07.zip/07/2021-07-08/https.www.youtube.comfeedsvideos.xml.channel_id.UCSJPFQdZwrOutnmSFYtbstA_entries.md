# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Black Widow - Clumsy, Dumb and Disappointing
 - [https://www.youtube.com/watch?v=0c5ynKJxnWI](https://www.youtube.com/watch?v=0c5ynKJxnWI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-07-09 00:00:00+00:00

Well, after about ten years of waiting, Black Widow is finally here. And it totally wasn't worth the wait.

