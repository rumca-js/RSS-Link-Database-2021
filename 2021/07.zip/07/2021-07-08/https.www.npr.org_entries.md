## Why Media Mogul Barry Diller Thinks The Movie Business Is Dead : NPR
 - [https://www.npr.org/2021/07/08/1014095135/barry-diller-headed-2-hollywood-studios-he-now-says-the-movie-business-is-dead](https://www.npr.org/2021/07/08/1014095135/barry-diller-headed-2-hollywood-studios-he-now-says-the-movie-business-is-dead)
 - RSS feed: https://www.npr.org
 - date published: 2021-07-08 14:15:32+00:00

Why Media Mogul Barry Diller Thinks The Movie Business Is Dead : NPR

