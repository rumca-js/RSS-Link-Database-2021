# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## OnePlus has finally throttled
 - [https://www.youtube.com/watch?v=C7ENj_WuY0A](https://www.youtube.com/watch?v=C7ENj_WuY0A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-07-09 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc

You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us. 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week, OnePlus got caught throttling their phones, Xiaomi's premium phones finally gained some ground and OPPO is gearing up to launch their first chip.

Episode 54

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-oneplus-has-finally-throttled

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar


▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:31 Release Monitor
1:32 OnePlus throttling
5:32 Premium Xiaomi
6:20 OPPO's first chip

