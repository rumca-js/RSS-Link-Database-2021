# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Why Sniffing Drugs Changes Your Butthole
 - [https://www.youtube.com/watch?v=w8Ef4mR2MSg](https://www.youtube.com/watch?v=w8Ef4mR2MSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-07-08 00:00:00+00:00

The science of poppers (sold as VHS cleaner) loosens your butthole, is that why so many people are sniffing it?
PODCAST ON POPPERS ft. PRIYANKA: https://youtu.be/eKTnSaJNTlc

Join our mailing list: https://bit.ly/34fWU27
FOLLOW US!
Instagram: https://instagram.com/asapscience​
Facebook: https://facebook.com/asapscience​
Twitter: https://twitter.com/asapscience​
TikTok: @AsapSCIENCE 

Written by: Greg Brown + Emma Jones
Edited by: Luka Šarlija

SOURCES
https://basicmedicalkey.com/vasodilators-the-treatment-of-angina-pectoris/
https://pubmed.ncbi.nlm.nih.gov/25311028/
https://pubmed.ncbi.nlm.nih.gov/9743790/
https://pubmed.ncbi.nlm.nih.gov/26971703/
https://www.drugabuse.gov/publications/research-reports/inhalants/what-are-other-medical-consequences-inhalant-abuse
http://www.nwprimarycare.com/Journal%20Articles/arterial_anatomy_and_hemodynaics.pdf
https://journals.sagepub.com/doi/pdf/10.1177/070674377802300711
“How gay culture bottled a formula that has broken down boundaries”. The  Independent. 2016-01-22. Retrieved 2017-01-21 

The effects of nitroglycerin and amyl nitrite on  arteriolar and venous tone in the human forearm. Circulation 1965;32:755–65.  doi:10.1161/01.CIR.32.5.755 

Poppers: Epidemiology and Clinical Management of Inhaled Nitrite Abuse by  Romanelli, Frank and Smith, Kelly M and Thornton, Alice C and Pomeroy, Claire  Pharmacotherapy, ISSN 0277-0008, 01/2004, Volume 24, Issue 1, pp. 69 - 78 Duesberg, P (2003). 

“The chemical bases of the various AIDS epidemics: recreational  drugs, anti-viral chemotherapy and malnutrition”. J Biosci. 28 (4): 383–412. 5. Poppers and Sexual Behavior: An Intimate Relationship by Banducci Rahe,  Bernardo and Marques Fidalgo, Thiago and Xavier Silveira, Dartiu The Journal of  Sexual Medicine, ISSN 1743-6095, 05/2017, Volume 14, Issue 5, pp. e296 - e296 6. Alkyl Nitrites (Poppers) Drug Science - An Independent Scientific Community on  Drugs 

http://www.drugscience.org.uk/drugs/dissociatives/alkyl-nitrates 7. Romanelli, F.; Smith, KM. (Jun 2004). “Recreational use of sildenafil by HIV-positive  and -negative homosexual/bisexual males”. Ann Pharmacother. 38 (6): 1024–30.  doi:10.1345/aph.1D571. PMID 15113986. 

O’Malley, Gerald F.; O’Malley, Rika (January 2016). “Volatile Nitrites”. In Porter,  Robert S.; et al. The Merck Manual Online. Merck & Co. Retrieved 2017-09-16. 9. Use of nitrite inhalants (“poppers”) among American youth by Ringwalt, Chris L  and Wu, Li-Tzy and Schlenger, William E . Journal of Adolescent Health, 2005 ,  Volume 37 , Issue 1 , pp. 52 - 60

