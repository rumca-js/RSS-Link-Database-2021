## Inside Nancy Pelosi’s Husband’s $5 Million Alphabet Options Windfall
 - [https://www.forbes.com/sites/antoinegara/2021/07/08/inside-nancy-pelosis-husbands-5-million-alphabet-options-windfall/](https://www.forbes.com/sites/antoinegara/2021/07/08/inside-nancy-pelosis-husbands-5-million-alphabet-options-windfall/)
 - RSS feed: https://www.forbes.com
 - date published: 2021-07-08 20:12:47+00:00

Inside Nancy Pelosi’s Husband’s $5 Million Alphabet Options Windfall

