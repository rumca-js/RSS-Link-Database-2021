# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Śmierć na dnie Bałtyku - trailer
 - [https://www.youtube.com/watch?v=OYTH1h6hj6U](https://www.youtube.com/watch?v=OYTH1h6hj6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-07-09 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Największy projekt roku - soon...

