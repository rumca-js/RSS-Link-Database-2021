# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Big Yellow Taxi // Joni Mitchell // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=M_r906QqjtY](https://www.youtube.com/watch?v=M_r906QqjtY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-07-08 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 I felt inspired to do a little baritone uke cover of "Big Yellow Taxi" and it turned out sadder than I expected, but I'm ok with that. This is one of my favorite Joni Mitchell compositions...maybe the first song of hers that I ever heard. She really is an insanely good songwriter.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Joni Mitchell's "Big Yellow Taxi" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals / Baritone Ukulele: Nataly Dawn
Keys: Jack Conte
Bass: Nick Campbell
Drums / Percussion: Kyle Crane

AUDIO CREDITS
Engineer: Bill Mims
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Director: Dom Fera
DP / A Cam: Ricky Chavez
B Cam: Merlin Showalter
Gaffer / Key Grip: Arjay Ancheta
Production Designer: Genevieve Parkes
Wardrobe: Elle Olsen
Assistant / Wardrobe: Alex Allen
PA: Chris Modl
Video Editor / Colorist: Athena Wheaton

Recorded in Los Angeles.

#Pomplamoose #JoniMitchell #BigYellowTaxi

LYRICS

Pave paradise, put up a parking lot
With a pink hotel, a boutique, and a swingin' hot spot

Don't it always seem to go
That you don't know what you've got 'til it's gone?
Pave paradise, put up a parking lot
They pave paradise, put up a parking lot

They took all the trees, put 'em in a tree museum
And they charged all the people a dollar and a half just to see 'em

Don't it always seem to go
That you don't know what you've got 'til it's gone?
They paved paradise, ​put up a parking lot
They paved paradise, ​put up a parking lot

Late last night, I heard the screen door slam
And a big yellow taxi took away my old man

Don't it always seem to go
That you don't know what you've got
Don't it always seem to go
That you don't know what you've got
Don't it always seem to go
That you don't know what you've got 'til it's gone?

