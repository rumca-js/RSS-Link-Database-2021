# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## See the moment a tornado tore through this city
 - [https://www.cnn.com/videos/weather/2021/07/08/jacksonville-florida-tornado-tropical-storm-elsa-mh-orig.cnn](https://www.cnn.com/videos/weather/2021/07/08/jacksonville-florida-tornado-tropical-storm-elsa-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 21:00:21+00:00

Surveillance video captured a tornado causing some major damage to a street in Jacksonville, Florida.

## Man makes daring jump to elude police
 - [https://www.cnn.com/videos/us/2021/07/08/boyle-heights-la-church-fire-arrest-orig-ff.cnn](https://www.cnn.com/videos/us/2021/07/08/boyle-heights-la-church-fire-arrest-orig-ff.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 20:23:51+00:00

A suspected arsonist is now in custody after evading police by jumping from roof to roof in Los Angeles.

## CNN anchor on why Marjorie Taylor Greene makes anti-Semitic comments
 - [https://www.cnn.com/videos/politics/2021/07/08/marjorie-taylor-greene-brown-shirt-abby-phillip-sot-vpx-ebof.cnn](https://www.cnn.com/videos/politics/2021/07/08/marjorie-taylor-greene-brown-shirt-abby-phillip-sot-vpx-ebof.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 17:37:08+00:00

CNN's Abby Phillip says that Rep. Marjorie Taylor Greene (R-GA) keeps making comments like the ones that compared the Biden administration's vaccination push to Nazi-era Brown Shirts because Greene believes that they help her with the Republican base loyal to former President Donald Trump.

## Huge 1,174-carat diamond unearthed in Botswana
 - [https://www.cnn.com/style/article/botswana-diamond-unearthed-scli-intl/index.html](https://www.cnn.com/style/article/botswana-diamond-unearthed-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 16:14:47+00:00

An enormous 1,174-carat diamond has been unearthed in Botswana, a mining company has said, the second massive diamond to be found in the country in the space of a few weeks.

## This artwork only lasts a couple of hours
 - [https://www.cnn.com/videos/style/2021/07/08/sand-art-nikola-faller-lon-orig-tp.cnn](https://www.cnn.com/videos/style/2021/07/08/sand-art-nikola-faller-lon-orig-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 15:22:58+00:00

Nicola Faller has been drawing geometrical patterns in the sand for around seven years. His latest work was featured at the Zen Opuzen Festival in Croatia.

## A wildfire has destroyed 90% of this town. Indigenous communities have been hit the hardest
 - [https://www.cnn.com/2021/07/08/americas/canada-lytton-wildfire-climate-change-indigenous-intl-cmd/index.html](https://www.cnn.com/2021/07/08/americas/canada-lytton-wildfire-climate-change-indigenous-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 13:53:34+00:00

Schoolteacher Katrina Sam has lived in Lytton in the Canadian province of British Columbia all her life, but a week after a disastrous wildfire, the town she grew up in is almost entirely gone.

## Belgium recalls ambassador to Seoul after wife's second physical altercation
 - [https://www.cnn.com/2021/07/08/asia/belgium-seoul-ambassador-immediate-return-intl/index.html](https://www.cnn.com/2021/07/08/asia/belgium-seoul-ambassador-immediate-return-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 13:49:04+00:00

Belgium is recalling its ambassador to Seoul "without further delay," after the envoy's wife was accused of getting into a second physical altercation in four months.

## The story behind Lady Gaga's iconic outfit from the designer
 - [https://www.cnn.com/videos/fashion/2021/07/08/schiaparelli-couture-daniel-roseberry-paris-mxb-lon-orig.cnn](https://www.cnn.com/videos/fashion/2021/07/08/schiaparelli-couture-daniel-roseberry-paris-mxb-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 13:25:17+00:00

Often cited as Coco Chanel's "greatest rival" Elsa Schiaparelli established her historic label in 1927. Today, Daniel Roseberry's fantastical silhouettes are a link to her irreverent legacy, seen on the likes of Lady Gaga and Beyonce.

## What 'Blackfishing' means and why people do it
 - [https://www.cnn.com/2021/07/08/entertainment/blackfishing-explainer-trnd/index.html](https://www.cnn.com/2021/07/08/entertainment/blackfishing-explainer-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 12:37:41+00:00

First there was blackface. Now there's "Blackfishing."

## US death rates are falling for many types of cancer, but not all, report says
 - [https://www.cnn.com/2021/07/08/health/us-cancer-deaths-decline/index.html](https://www.cnn.com/2021/07/08/health/us-cancer-deaths-decline/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 12:29:33+00:00

US death rates from cancer continued to decline from 2014 to 2018, driven mostly by drops in deaths from lung cancer and melanoma, according to a new report published Thursday.

## Five undervaccinated clusters put the entire United States at risk
 - [https://www.cnn.com/2021/07/08/health/undervaccinated-clusters-covid-risk/index.html](https://www.cnn.com/2021/07/08/health/undervaccinated-clusters-covid-risk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 12:04:37+00:00

A new data analysis identifies clusters of unvaccinated people, most of them in the southern United States, that are vulnerable to surges in Covid-19 cases and could become breeding grounds for even more deadly Covid-19 variants.

## Four suspects connected to the killing of President Jovenel Moise were killed by police overnight, and another two were detained, officials said
 - [https://www.cnn.com/2021/07/08/americas/haiti-moise-assassination-suspects-killed-intl-hnk/index.html](https://www.cnn.com/2021/07/08/americas/haiti-moise-assassination-suspects-killed-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 11:53:34+00:00

Haiti was in turmoil Thursday as police hunted for the suspects behind the assassination of its president and questions swirled over who would take charge of the impoverished Caribbean nation.

## The young American couturier creating Surrealist fashion for the modern era
 - [https://www.cnn.com/style/article/daniel-roseberry-schiaparelli-couture/index.html](https://www.cnn.com/style/article/daniel-roseberry-schiaparelli-couture/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 11:47:58+00:00

For those who need convincing that fashion is a form of art, Daniel Roseberry's designs for Maison Schiaparelli offer a persuasive argument.

## Biden to speak on Afghanistan amid US troop withdrawal and Taliban gains
 - [https://www.cnn.com/2021/07/08/politics/biden-afghanistan-speech/index.html](https://www.cnn.com/2021/07/08/politics/biden-afghanistan-speech/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 11:34:13+00:00

President Joe Biden will receive an update Thursday on the swiftly concluding war in Afghanistan, where a near-complete withdrawal of American troops is coinciding with major Taliban gains.

## Biden administration to spotlight voting rights Thursday as advocates push the President to do more
 - [https://www.cnn.com/2021/07/08/politics/voting-rights-biden-harris/index.html](https://www.cnn.com/2021/07/08/politics/voting-rights-biden-harris/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 11:33:42+00:00

President Joe Biden plans to hold another meeting on voting rights Thursday as Democrats clamor for him to do and say more on the issue after defeats in Congress and the Supreme Court.

## Video appears to show moments after Haiti President's assassination
 - [https://www.cnn.com/videos/world/2021/07/08/haiti-president-dead-jovenel-moise-suspects-newday-vpx.cnn](https://www.cnn.com/videos/world/2021/07/08/haiti-president-dead-jovenel-moise-suspects-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 11:32:52+00:00

A video on social media appears to show the moments after the assassination of Haitian President Jovenel Moise. CNN cannot verify the authenticity of the audio or the video. Four suspects connected to the assassination were killed by police, and another two have been detained, Haiti's ambassador to the United States said.

## She flew from Australia to England for a first date. Here's what happened next.
 - [https://www.cnn.com/travel/article/laura-sara-australia-uk-twitter-romance/index.html](https://www.cnn.com/travel/article/laura-sara-australia-uk-twitter-romance/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 11:25:02+00:00

British college student Laura was scrolling through social media one day in 2014, when a Tweet caught her eye, and changed her life.

## Microsoft issues urgent security warning: Update your PC immediately
 - [https://www.cnn.com/2021/07/07/tech/microsoft-security-update/index.html](https://www.cnn.com/2021/07/07/tech/microsoft-security-update/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 10:45:18+00:00

Microsoft is urging Windows users to immediately install an update after security researchers found a serious vulnerability in the operating system.

## Chinese tech stocks roiled by worsening crackdown
 - [https://www.cnn.com/2021/07/08/tech/china-antitrust-didi-alibaba-tencent-intl-hnk/index.html](https://www.cnn.com/2021/07/08/tech/china-antitrust-didi-alibaba-tencent-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 10:40:30+00:00

China is not slowing down with its historic tech crackdown.

## Haitian Americans say they are soul-searching after the assassination
 - [https://www.cnn.com/2021/07/08/us/haitian-americans-react-assassination-president/index.html](https://www.cnn.com/2021/07/08/us/haitian-americans-react-assassination-president/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 10:29:08+00:00

The assassination of Haiti's President Jovenel Moise has many Haitian-American community leaders fearing what may come next.

## Republicans preview months ahead filled with obstruction and extremism
 - [https://www.cnn.com/2021/07/08/politics/republican-extremism-latest/index.html](https://www.cnn.com/2021/07/08/politics/republican-extremism-latest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 10:14:57+00:00

House Republicans are done pretending and aren't even trying to disguise their identity as the party of extremism, conservative media stunts and obstruction.

## Democrats look to avoid 'circus' as they push forward with new select committee
 - [https://www.cnn.com/2021/07/08/politics/january-6-select-committee-democratic-strategy/index.html](https://www.cnn.com/2021/07/08/politics/january-6-select-committee-democratic-strategy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 10:05:44+00:00

As they start the process of standing up a select committee to investigate security failings and circumstances surrounding the deadly January 6 attack on the US Capitol, House Democrats aim to use a strategy that avoids turning the investigation into a spectacle.

## Tokyo Olympics will be held under a state of emergency as Japan mulls opening ceremony fan ban
 - [https://www.cnn.com/2021/07/08/asia/japan-state-of-emergency-olympics-intl-hnk/index.html](https://www.cnn.com/2021/07/08/asia/japan-state-of-emergency-olympics-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 10:03:28+00:00

The pandemic-delayed Tokyo 2020 Olympics will take place under a coronavirus state of emergency, Japanese Prime Minister Yoshide Suga confirmed Thursday.

## Former South African President Jacob Zuma hands himself over to police
 - [https://www.cnn.com/2021/07/07/africa/jacob-zuma-police-custody-intl-hnk/index.html](https://www.cnn.com/2021/07/07/africa/jacob-zuma-police-custody-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 10:01:22+00:00

Former South African President Jacob Zuma handed himself over to police late Wednesday, authorities said, to begin a 15-month prison sentence for contempt of court.

## Climate change altered the size of human bodies
 - [https://www.cnn.com/2021/07/08/world/climate-change-body-size-intl-scli-scn/index.html](https://www.cnn.com/2021/07/08/world/climate-change-body-size-intl-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 09:51:32+00:00

The average body size of humans has fluctuated significantly over the last million years and is linked to a changing climate, according to research published Thursday.

## These futuristic pods could help cities solve their traffic problems
 - [https://www.cnn.com/2021/07/08/tech/usky-pod-sharjah-uae-spc-intl/index.html](https://www.cnn.com/2021/07/08/tech/usky-pod-sharjah-uae-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 09:39:45+00:00

Traffic congestion is a problem for cities around the world, with some looking to electric scooters to ease gridlock, and others to AI-enabled traffic lights. But one company believes the solution is to build a network of driverless high-speed pods that ride around cities suspended from a steel track.

## The abandoned airport terminal where everything still works
 - [https://www.cnn.com/travel/article/new-orleans-old-msy-abandoned-terminal/index.html](https://www.cnn.com/travel/article/new-orleans-old-msy-abandoned-terminal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 09:15:12+00:00

"The first thing you notice about New Orleans are the burying grounds -- the cemeteries -- one of the best things there are here" wrote Bob Dylan in his 2004 book "Chronicles: Volume One."

## Indian Prime Minister fires health minister and 11 others as Covid crisis lingers
 - [https://www.cnn.com/2021/07/08/india/india-cabinet-reshuffle-modi-intl-hnk/index.html](https://www.cnn.com/2021/07/08/india/india-cabinet-reshuffle-modi-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 08:50:57+00:00

Indian Prime Minister Narendra Modi dropped 12 members of his cabinet on Wednesday in a dramatic reshuffle, including the federal ministers for health and law, as he faces fierce criticism over the government's alleged mishandling of the coronavirus pandemic.

## England reaches first major final since 1966 thanks to controversial winner
 - [https://www.cnn.com/2021/07/07/football/england-denmark-semifinals-euro-2020-spt-intl/index.html](https://www.cnn.com/2021/07/07/football/england-denmark-semifinals-euro-2020-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 08:42:39+00:00

England reached its first men's major tournament final since winning the World Cup in 1966 after beating Denmark 2-1 at Euro 2020 in a gripping encounter on Wednesday at Wembley Stadium.

## Delta variant is 'Covid-19 on steroids,' expert says, with cases increasing in nearly half of US states
 - [https://www.cnn.com/2021/07/08/health/us-coronavirus-thursday/index.html](https://www.cnn.com/2021/07/08/health/us-coronavirus-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 08:35:30+00:00

Twenty-four states have seen an uptick of at least 10% in Covid-19 cases over the past week as health experts and the federal government keep pressing for more people to get vaccinated.

## Lead Sinovac vaccine scientist in Indonesia dies of suspected Covid-19, media say
 - [https://www.cnn.com/2021/07/08/asia/sinovac-scientist-indonesia-dies-intl-hnk/index.html](https://www.cnn.com/2021/07/08/asia/sinovac-scientist-indonesia-dies-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 08:00:23+00:00

The lead scientist on China's Sinovac vaccine trials in Indonesia died of suspected Covid-19 on Wednesday, Indonesian media said.

## Why NASA's Space Shuttle was so revolutionary
 - [https://www.cnn.com/videos/design/2021/04/08/nasa-space-shuttle-history-mxb-lon-orig.cnn](https://www.cnn.com/videos/design/2021/04/08/nasa-space-shuttle-history-mxb-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 07:24:29+00:00

The Space Shuttle wasn't just the next step after Apollo, it was a giant leap in the way we understood and used space. CNN remembers the shuttle 10 years after its final mission.

## Egypt's big plans for 'vertical forests'
 - [https://www.cnn.com/videos/world/2021/07/02/egypt-vertical-forest-spc-intl.cnn](https://www.cnn.com/videos/world/2021/07/02/egypt-vertical-forest-spc-intl.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 07:07:16+00:00

Egypt is planning to put sustainability at the heart of its New Administrative Capital, including "vertical forests" -- buildings adorned with plants and trees.

## What Indonesia looks like as it grapples with its worst Covid outbreak
 - [https://www.cnn.com/videos/world/2021/07/08/indonesia-coronavirus-oxygen-crisis-covid-19-hancocks-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/07/08/indonesia-coronavirus-oxygen-crisis-covid-19-hancocks-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 06:57:42+00:00

Indonesia is now experiencing its worst Covid-19 outbreak after reporting record cases and deaths. As hospitals become overwhelmed with patients, many are being turned away. CNN's Paula Hancocks reports.

## Turmoil in Haiti as police shoot men suspected of assassinating president
 - [https://www.cnn.com/collections/haiti-president-intl-070721/](https://www.cnn.com/collections/haiti-president-intl-070721/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 06:49:31+00:00



## Colombia used 'excessive force' against protesters, says human rights report
 - [https://www.cnn.com/2021/07/08/americas/colombia-excessive-force-protests-intl/index.html](https://www.cnn.com/2021/07/08/americas/colombia-excessive-force-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 06:29:27+00:00

An international human rights body has accused Colombia's security forces of applying "disproportionate and excessive force," in dealing with street protesters, more than two months since demonstrations began in Bogota, which left dozens dead.

## Travelers are going to this US island just to get vaccinated
 - [https://www.cnn.com/travel/article/taiwan-guam-vaccination-travel-intl-hnk/index.html](https://www.cnn.com/travel/article/taiwan-guam-vaccination-travel-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 06:02:06+00:00

On July 6, a planeload of Taiwanese travelers arrived in the US territory of Guam. But they didn't just travel for the island's gorgeous scenery -- they were also there to get vaccinated against Covid-19.

## Why Haiti President Jovenel Moise was a controversial figure
 - [https://www.cnn.com/2021/07/07/americas/haiti-president-jovenel-moise-attack-intl/index.html](https://www.cnn.com/2021/07/07/americas/haiti-president-jovenel-moise-attack-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 05:56:32+00:00

Haiti's President Jovenel Moise was killed during an attack on his private residence early on Wednesday, according to the country's acting Prime Minister Claude Joseph, who has declared a state of seige in the country.

## The Surfside community gathers for a memorial as search efforts turn from rescue to recovery
 - [https://www.cnn.com/2021/07/08/us/miami-dade-building-collapse-thursday/index.html](https://www.cnn.com/2021/07/08/us/miami-dade-building-collapse-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 05:55:38+00:00

At the edge of the rubble from a condo building collapse in the Miami-Dade area, first responders, officials, faith leaders and journalists hung their heads for a moment of silence Wednesday evening, honoring those who lost their lives under the debris.

## Marvel's long-awaited release of 'Black Widow' is a triumphant moment for the movie industry
 - [https://www.cnn.com/2021/07/07/media/black-widow-movie-industry-reliable-sources/index.html](https://www.cnn.com/2021/07/07/media/black-widow-movie-industry-reliable-sources/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 05:01:26+00:00

A version of this article first appeared in the "Reliable Sources" newsletter. You can sign up for free right here.

## China is cracking down on data privacy. That's bad news for some tech companies
 - [https://www.cnn.com/collections/intl-china-070721/](https://www.cnn.com/collections/intl-china-070721/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 03:55:54+00:00



## Global Covid-19 death toll surpasses 4 million
 - [https://www.cnn.com/collections/0807-covid-intl/](https://www.cnn.com/collections/0807-covid-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 03:52:09+00:00



## Dozens of US states are suing Google over app store practices
 - [https://www.cnn.com/2021/07/07/tech/google-app-store-lawsuit/index.html](https://www.cnn.com/2021/07/07/tech/google-app-store-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 03:40:21+00:00

Dozens of states have filed an antitrust lawsuit against Google that zeroes in on its app store practices.

## Philippine President Rodrigo Duterte 'seriously thinking' about running for vice president
 - [https://www.cnn.com/2021/07/07/asia/philippines-rodrigo-duterte-vice-president-intl-hnk/index.html](https://www.cnn.com/2021/07/07/asia/philippines-rodrigo-duterte-vice-president-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 03:01:25+00:00

Philippine President Rodrigo Duterte on Wednesday gave the strongest hint yet that he might seek the vice presidency in next year's election, saying he was now "seriously thinking" about running.

## Trump and Greene invite a horrific history to repeat itself
 - [https://www.cnn.com/2021/07/07/opinions/trump-greene-horrific-history-dantonio/index.html](https://www.cnn.com/2021/07/07/opinions/trump-greene-horrific-history-dantonio/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 02:52:12+00:00

In excerpts  from the upcoming book, "Frankly, We Did Win This Election: The Inside Story of How Trump Lost," Michael C. Bender alleges that Donald Trump's former chief of staff, John Kelly, recounted a grotesque episode he said took place during a 2018 presidential visit to Europe.  According to Kelly, Trump interrupted a discussion of Nazi atrocities to say, "Well, Hitler did a lot of good things." Kelly, a retired Marine Corps general--whose son, also a US Marine, died in combat, argued with his boss.

## Fire rips through Dubai port after explosion inside ship container
 - [https://www.cnn.com/collections/0807-dubai-intl/](https://www.cnn.com/collections/0807-dubai-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 02:08:55+00:00



## 'Crazy Rich Asians' star's top travel tips
 - [https://www.cnn.com/travel/article/henry-golding-travel-interview/index.html](https://www.cnn.com/travel/article/henry-golding-travel-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 01:57:10+00:00

Henry Golding could rival James Bond for being a smooth talking, crisply dressed world traveler.

## Zoo staff hunt escaped 12-foot Burmese python in US mall
 - [https://www.cnn.com/2021/07/07/us/python-missing-louisiana-trnd/index.html](https://www.cnn.com/2021/07/07/us/python-missing-louisiana-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 01:25:37+00:00

Search teams in Baton Rouge are rolling snake eyes when it comes to finding Cara, a large, banana-yellow Burmese python that slithered out of her exhibit in the Blue Zoo aquarium in the Mall of Louisiana on Monday night.

## Inside Myanmar mountain camp where rebels train to fight junta
 - [https://www.cnn.com/2021/07/07/asia/myanmar-camp-victoria-rebels-cmd-intl/index.html](https://www.cnn.com/2021/07/07/asia/myanmar-camp-victoria-rebels-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 00:57:16+00:00

Full-throated they belt out songs of victory, their boots adding the drumbeat as ranks of new recruits jog in formation through their jungle training camp.

## Unrecognizable stray dog that went viral gets storybook ending
 - [https://www.cnn.com/videos/us/2021/07/07/hairiest-dog-adopted-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2021/07/07/hairiest-dog-adopted-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 00:53:19+00:00

A neglected dog that was so hairy he was unrecognizable gets adopted. Jeanne Moos reports on the hairiest dog finding a forever home.

## Anderson Cooper: Marjorie Taylor Greene is at it again
 - [https://www.cnn.com/videos/politics/2021/07/08/marjorie-taylor-greene-vaccination-kth-cooper-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/07/08/marjorie-taylor-greene-vaccination-kth-cooper-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-08 00:43:21+00:00

Rep. Marjorie Taylor Greene (R-GA) compared officials carrying out President Joe Biden's latest Covid-19 vaccination push to Nazi-era "brown shirts," just weeks after apologizing for her comments comparing Capitol Hill mask-wearing rules to the Holocaust.

