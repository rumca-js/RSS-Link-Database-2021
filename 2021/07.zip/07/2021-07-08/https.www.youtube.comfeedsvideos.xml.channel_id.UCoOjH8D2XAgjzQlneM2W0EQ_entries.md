# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## A Criminal’s Guide to Laundering Money with Crypto
 - [https://www.youtube.com/watch?v=CL5bv5MOUu4](https://www.youtube.com/watch?v=CL5bv5MOUu4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-07-08 00:00:00+00:00

Get the VPN trusted by millions of customers: https://www.privateinternetaccess.com/JakeTran
As recommended in Forbes, PCMAG, lifehacker, and more!

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

This video is for entertainment purposes only. Money laundering is illegal. Don't do it.

Money Laundering: The Art of Cleaning Dirty Money https://youtu.be/iGCcZu3zKjo

Check out Chainalysis’s blog for the most up-to-date cryptocurrency research and news: http://blog.chainalysis.com/ 

💸 Win $1,000! https://jake.yt/1000 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✨ Follow us on TikTok: https://jake.yt/tiktok
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
💬 Join the community Discord: http://discord.gg/BmK8EnQ

💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎵 Get unlimited royalty-free music for your videos with Epidemic Sound! ➡️ https://share.epidemicsound.com/jaketran 

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/36ABXk9

-----------------------
Let’s say you’re a cyber criminal - theoretically, of course. Whatever cyber criminal you are, if you’re not making money right now, you suck. The problem with any type of ill-gotten gains is that if you just straight up use that money to buy a lambo, to buy that mansion eventually people like the IRS, the FBI, the DEA, are gonna come knocking on your door, wondering where you got all this money from? So we need a way to clean this dirty money so that it looks like it came from a legitimate source. 

Back in the early days of crypto, it was the Golden age of money laundering. Today however, it’s a lot harder. Regulators are putting more and more pressure on exchanges. That’s where Over The Counter brokers come in. The OTC works their magic and shuffles the funds around with other client’s money and other OTC’s. And then the OTC goes to an exchange like Binance or Huobi to get your cash.

What is Bitcoin Fog? It’s known as a Bitcoin Mixer, or Crypto Tumbler - and it’s exactly what it sounds like. Think of it like a literal laundry machine for crypto. Bitcoin Fog took in around $336m in Bitcoin over its lifespan, which comes out to around a $5m profit for the owner.

Instead of mixing Bitcoins, you can also get out of public cryptos entirely and exchange it for privacy coins. Like Monero, Zcash, and Grin. Privacy coins are just like any other cryptocurrency, except they provide way more, well, privacy. You should be warned, though, these privacy coins may not be around forever.

The invention of Bitcoin ATMs has also changed the money laundering game. This is great if you’re running any traditional rackets where your profits are still in fiat. You take the dirty money, and simply use any one of the 11,000 unregulated Bitcoin ATMs around the world to turn that cash into clean Bitcoin.

Privacy wallets are responsible for around 12% of all Bitcoin laundering last year - making them the preferred choice among cyber criminals. 

-----------------------

#piavpn

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

