# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## EA RESPONDS TO IN-GAME ADS DEAL, NEW ASSASSIN'S CREED DESIGNED LIKE FORTNITE? & MORE
 - [https://www.youtube.com/watch?v=dTPFXHrfkMg](https://www.youtube.com/watch?v=dTPFXHrfkMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-09 00:00:00+00:00

Sign up for free: https://cen.yt/mbgameranx and become smarter in 5 minutes - Thanks to Morning Brew for sponsoring today’s video.


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake's other channel: https://youtu.be/AV__0w6HE78




 ~~~~STORIES~~~~


Switch OLED https://nintendoeverything.com/switch-oled-list-of-specs/

Asssassin’s Creed Infinite
https://www.ign.com/articles/assassins-creed-infinity-online-platform-multiple-games-settings-fortnite-gta-online

EA putting more ads in games?
https://www.pcgamer.com/uk/this-company-is-putting-video-ads-in-games-and-ea-has-already-signed-up/


PS state of play:
Deathloop: https://youtu.be/kTnzLC6Utk0
Lost Judgement: https://youtu.be/yXufyWdCa_U
Sifu (delayed) https://youtu.be/Y7y1yJn2B9U
Moss sequel https://youtu.be/x8HvWj2sMeYFIST: https://youtu.be/E1EHQKECRdE
Full 30 min State of Play with Indies: https://youtu.be/Sm8a4OC6W3A


Lol Sony: https://kotaku.com/sony-pulls-ad-featuring-upside-down-ps5-1847253801


Monster Hunter Stories 2
https://youtu.be/BfCeZk0jIxU

Badrobo made Ratchet in Dreams
https://youtu.be/TYY2R2wFYl4

Robert Cop https://youtu.be/j2TL1TgJUfk

New EA studio
https://www.ign.com/articles/dice-la-ripple-effect-studios-christian-grass-news

Xbox stuff
https://www.tomsguide.com/news/xbox-series-x-games-could-get-a-big-boost-thanks-to-ai-upscaling
Accessibility update https://www.ign.com/articles/xbox-party-chat-text-to-speech-speech-to-text

Happy ending story
https://www.bbc.com/news/uk-england-merseyside-57720242

## 10 Most UNSETTLING Plot Twists in Video Games
 - [https://www.youtube.com/watch?v=mUwTKv5FrBo](https://www.youtube.com/watch?v=mUwTKv5FrBo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-08 00:00:00+00:00

Some video game twists aren't just surprising, they're downright unsettling. Here are some of our favorite examples. SPOILER WARNING
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:22 10 Dead Space
1:42 9 SUPERHOT
2:51 8 Nier 
4:27 7 Bloodborne 
5:55 6 Spec Ops: The line 
7:03 5 Silent Hill: Shattered Memories
8:10 4 Killer 7
9:37 3 Little Nightmares 2
10:52 2 Soma
12:19 1 Silent Hill 2

## What Made Need For Speed: Most Wanted A BIG DEAL?
 - [https://www.youtube.com/watch?v=v9YIOymxHoQ](https://www.youtube.com/watch?v=v9YIOymxHoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-08 00:00:00+00:00

Need for Speed Most Wanted is one of the most beloved street racing games of all time. Here's why.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

