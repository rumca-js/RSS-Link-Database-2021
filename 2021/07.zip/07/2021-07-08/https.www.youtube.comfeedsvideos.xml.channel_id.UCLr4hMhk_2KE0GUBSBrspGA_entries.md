# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Pies robot Unitree
 - [https://www.youtube.com/watch?v=QcL8KmRkAA0](https://www.youtube.com/watch?v=QcL8KmRkAA0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-07-08 00:00:00+00:00

Oraz super szybka karta SD oraz moje przemyślenia na temat hypeme.
Psa robota do testów pożyczyła nam firma: https://www.edu4industry.com
Karta Platinet: https://bit.ly/2Uu0t3q
Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Dzisiaj w odcinku
00:44 Karty SD od Platinet – mail od firmy
02:17 Test kart – zwykła karta SD vs karta Platinet
03:20 Wyniki i podsumowanie testu
03:48 Ceny kart od Platinet
04:09 Unboxing psa od firmy Unitree
05:00 Co potrafi pies robot?
06:14 Co pies robot robi na uczelniach?
07:06 Jak postawić psa robota?
07:32 Jak długo wytrzymuje bateria?
08:00 Wyjście na spacer i konfrontacja z prawdziwymi psami
08:55 Kuba vs pies robot
09:29 Przemyślenia Kuby o aplikacji Hype Me
12:29 Kuba vs wybory
12:43 Znośnego weekendu

