# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## How To Handle Confrontation: Me Vs Westboro Baptist Church
 - [https://www.youtube.com/watch?v=9c6sZXmm9QY](https://www.youtube.com/watch?v=9c6sZXmm9QY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-09 00:00:00+00:00

In this video, I'm reacting to some of my viral videos where I discuss how to deal with confrontation! In this one, I playback some clips from my FX show with the Westboro Baptist Church lot...

#viral #reaction #westborobaptistchurch #russellbrand #confrontation #laugh #westboro #viralvideos #conflict #christianity #WBC

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

Get passes to my show Our Little Lives: Shakespeare & Me. It's streaming on Live Now on July 14th. http://bit.ly/3godW5g

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/channel/UChFKcTjkOFIBvwFWPvokXoA

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

## "It's Coming Home": My Reaction To England Reaching Final
 - [https://www.youtube.com/watch?v=AyIvzCCL8Ys](https://www.youtube.com/watch?v=AyIvzCCL8Ys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-08 00:00:00+00:00

Yesterday England won against Denmark in the Euro Semi-Final. Let's look at the reaction of the football fans and explore the idea of nationalism. Do you think it's coming home and will you be watching England Vs Italy match on Sunday?

Football War - MiniWars #2 video from OverSimplified:
https://www.youtube.com/watch?v=W12vb_Crf00

#England #Euros #UEFA #ItsComingHome #ItalyVEngland #Final  #RussellBrand

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

Get passes to my show Our Little Lives: Shakespeare & Me. It's streaming on Live Now on July 14th. http://bit.ly/3godW5g

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWi...

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

