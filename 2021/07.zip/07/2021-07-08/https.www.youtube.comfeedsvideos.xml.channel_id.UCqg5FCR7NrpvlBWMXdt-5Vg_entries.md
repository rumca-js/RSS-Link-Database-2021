# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Chivalry 2 | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=1xRIQ_cgbZc](https://www.youtube.com/watch?v=1xRIQ_cgbZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-07-08 00:00:00+00:00

Jesse Galena reviews Chivalry 2, developed by Torn Banner Studios.

Chivalry 2 on EGS: https://www.epicgames.com/store/en-US/p/chivalry-2

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## How Death's Door and Tunic Aim to Transcend Soulslikes
 - [https://www.youtube.com/watch?v=1XLECqkMk7Q](https://www.youtube.com/watch?v=1XLECqkMk7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-07-08 00:00:00+00:00

While we’ve seen plenty of Zelda-likes and Souls-likes over the years, few games have managed to understand the exact elements that makes them great quite like Tunic and Death’s Door. The thing that makes the Souls games so memorable isn’t the steep difficulty, nebulous mechanics, or grotesque bosses, but rather a pure sense of adventure, exploration, and discovery, and these two games have that in spades. And so, while we wait for Elden Ring and the sequel to Breath of the Wild to come along next year, it’s indies like these that seem to be adeptly carrying their torch.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Loki - Episode 5 'Journey Into Mystery' Review | A Marvelous Escape
 - [https://www.youtube.com/watch?v=FCwIlUqjppU](https://www.youtube.com/watch?v=FCwIlUqjppU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-07-08 00:00:00+00:00

This week on A Marvelous Escape, Darren, Amy and KC discuss the latest episode of Loki, 'Journey Into Mystery'.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#Loki

