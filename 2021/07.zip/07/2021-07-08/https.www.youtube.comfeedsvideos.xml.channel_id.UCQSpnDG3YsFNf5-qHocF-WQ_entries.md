# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## How to Get a Verified Email Badge (Extremely Rare)
 - [https://www.youtube.com/watch?v=3ne0d37cZyc](https://www.youtube.com/watch?v=3ne0d37cZyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-07-08 00:00:00+00:00

How did I not know this has been a thing for years?
Email Certificate Registration ⇨ https://extrassl.actalis.it/portal/uapub/freemail?lang=en

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
1:03 - What does it mean?
2:31 - Requirements?
3:21 - S/MIME Explained
5:43 - Info about email certificates
7:34 - The Walkthrough
7:45 - Acquiring a free email certificate
10:06 - Installing the Certificate
11:43 - Exporting Intermediate Certificates
14:28 - Setting Up Outlook
19:40 - Installing Certificates on iPhone
22:47 - Enabling Signing on iPhone
23:50 - Why you must always test
24:18 - Installing Certificates on MacOS
24:52 - Installing Certificates on Android
25:17 - Note about managed work accounts

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

