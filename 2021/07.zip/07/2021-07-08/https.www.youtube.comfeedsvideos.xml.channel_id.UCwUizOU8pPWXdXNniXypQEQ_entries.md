# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## When the Biden Administration Knocks On Your Door…
 - [https://www.youtube.com/watch?v=k29PCOFXSKc](https://www.youtube.com/watch?v=k29PCOFXSKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-07-08 00:00:00+00:00

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Check Out My Merch Here - https://awakenwithjp.com

When the Biden administration knocks on your door... Operation strike force at its best!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

