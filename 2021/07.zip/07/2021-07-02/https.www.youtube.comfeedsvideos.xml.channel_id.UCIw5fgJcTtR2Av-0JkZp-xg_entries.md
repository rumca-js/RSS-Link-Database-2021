# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "I Will Find You" (Song Version)
 - [https://www.youtube.com/watch?v=rFSaxNaxLgU](https://www.youtube.com/watch?v=rFSaxNaxLgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2021-07-03 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Watch the making of: 
https://youtu.be/PR6yxAYr3-s

The full line:
 "I don't know who you are. I don't know what you want. If you are looking for ransom, I can tell you I don't have money. But what I do have are a very particular set of skills, skills I have acquired over a very long career, skills that make me a nightmare for people like you. If you let my daughter go now, that'll be the end of it. I will not look for you. I will not pursue you. But if you don't, I will look for you, I will find you, and I will kill you." - Liam Neeson as Bryan Mills

Created with Teenage Engineering OP-1 and completed in Logic Pro X using stock plugins and instruments.

VHS glitch footage by Christopher Huppertz:
https://www.youtube.com/channel/UCLEANTxyZzGnBIPyHnjq6kw

