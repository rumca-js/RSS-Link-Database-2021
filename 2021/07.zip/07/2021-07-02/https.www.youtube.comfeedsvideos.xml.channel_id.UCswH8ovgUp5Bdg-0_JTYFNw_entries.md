# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Russell Brand & Ben Shapiro "Respectfully Disagreeing"
 - [https://www.youtube.com/watch?v=xMiug2sZ4Io](https://www.youtube.com/watch?v=xMiug2sZ4Io)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-03 00:00:00+00:00

I spoke with #BenShapiro on my weekly podcast Under the Skin from Luminary. Ben is a very popular US conservative political commentator - he presents a daily current affairs show called The Ben Shapiro show on YouTube. His new book "The Authoritarian Moment” will be released on July 27. In this video you can watch the first half of our conversation - if you'd like to listen to the rest (another hour) of this audio podcast you can over on Apple Podcasts here: http://apple.co/russell

If you are on Android you can listen here: http://luminary.link/russell

Ben's YouTube channel: https://www.youtube.com/benshapiro

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva. Subscribe to Luminary on Apple Podcasts here: http://apple.co/russell

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary too!
http://apple.co/meditate 

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

#RussellBrand

## Why Is The Mainstream Media IGNORING the BIGGEST PROTEST for a generation???
 - [https://www.youtube.com/watch?v=2GBcOCutzhc](https://www.youtube.com/watch?v=2GBcOCutzhc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-02 00:00:00+00:00

Thousands of protesters were seen marching through the streets of central London last Saturday. What does the media's coverage tell us about their agenda? 

#Media #Protest #UK #Russellbrand

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: 
http://adbl.co/revelation
UK: 
http://adbl.co/revelationuk
AU: 
http://adbl.co/revelationau
CA: 
http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

