# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Repairing MrMobile's Busted Motorola Razr 5G - Feat. Michael Fisher
 - [https://www.youtube.com/watch?v=5D0VuKeuCko](https://www.youtube.com/watch?v=5D0VuKeuCko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-07-03 00:00:00+00:00

@TheMrMobile goes "into the fold", but I go inside the fold in an effort to repair his folding Razr smartphone that not even Motorola offered a repair on.
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Tools I Use: https://www.hughjeffreys.com/tools

Get parts, tools, and thousands of free repair guides from iFixit at: 
                               https://iFixit.com/hughjeffreys
Australian Store: https://ifix.gd/2FPxhKy

Michael Fisher: https://www.youtube.com/channel/UCSOpcUkE-is7u7c4AkLgqTw

MrMobile - I Broke My First Foldable [Into The Fold Episode 6]: https://www.youtube.com/watch?v=JrkcNAgJkes
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

