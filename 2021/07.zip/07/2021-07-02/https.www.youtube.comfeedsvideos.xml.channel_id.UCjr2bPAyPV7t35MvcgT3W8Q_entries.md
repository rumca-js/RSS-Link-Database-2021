# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## How Tim Cook Surrendered Apple to the Chinese Government
 - [https://www.youtube.com/watch?v=Ev9_oDHNf-4](https://www.youtube.com/watch?v=Ev9_oDHNf-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-07-02 00:00:00+00:00

This is how Tim Cook turned Apple into China's biggest ally in their imperial and authoritarian expansion.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Apple is making billions of dollars integrating into countries with authoritarian regimes. Even if it means helping to cement the power of the ruling elite or enabling egregious abuse of human rights. And there doesn’t seem to be anything Apple wouldn’t do for the sake of growth and expansion. Apple cites compliance with local laws as the reason for giving human rights abuse a go.  But the actions of the most valuable company in the world go far beyond compliance with the law.

Sources
Apple's financial report: https://www.apple.com/newsroom/2021/04/apple-reports-second-quarter-results/
https://www.apple.com/newsroom/pdfs/FY21_Q2_Consolidated_Financial_Statements.pdf
LGBT apps censored by Apple or removed from the App Store: https://www.dailymail.co.uk/sciencetech/article-9693665/Report-says-27-LGBT-apps-censored-Apple-China-tech-giant-denies-that.html
https://www.protocol.com/china/china-app-store-lgbtq-censorship
Apple's Private Relay feature not available in China: https://www.reuters.com/world/china/apples-new-private-relay-feature-will-not-be-available-china-2021-06-07/
Apple censoring Belarus activists: https://www.msn.com/en-us/news/world/apple-is-censoring-belarus-protesters-activists-say/ar-BB1a4oXd
Telegram censorship: https://www.nytimes.com/2018/05/31/technology/telegram-apple-russia.html
Apple helps Saudi men track their wives: https://www.insider.com/absher-14-members-of-congress-demand-apple-google-remove-saudi-app-2019-2
https://www.aljazeera.com/economy/2019/2/13/apple-google-urged-to-remove-app-that-lets-saudi-men-track-wives
Apple's integration into China: https://www.nytimes.com/2021/05/17/technology/apple-china-censorship-data.html
https://www.nytimes.com/2018/06/18/technology/apple-tim-cook-china.html
https://www.nytimes.com/2020/08/19/technology/apple-2-trillion.html
https://www.nytimes.com/2016/12/29/technology/apple-iphone-china-foxconn.html
https://www.nytimes.com/2021/06/17/technology/apple-china-doug-guthrie.html
Surrendering iCloud data to the Chinese government: https://www.theverge.com/2018/2/28/17055088/apple-chinese-icloud-accounts-government-privacy-speed
https://www.nytimes.com/2018/01/23/opinion/apple-china-data.html
https://www.bloomberg.com/news/articles/2017-07-12/apple-to-build-first-china-data-center-to-comply-with-local-law
https://www.reuters.com/article/us-apple-datacenter-idUSKBN1FQ2E6
https://thediplomat.com/2017/06/chinas-cybersecurity-law-what-you-need-to-know/
https://www.nytimes.com/2017/07/12/business/apple-china-data-center-cybersecurity.html
Apple censored New York Times app in China: https://www.nytimes.com/2017/01/04/business/media/new-york-times-apps-apple-china.html
Censoring Hong Kong apps: https://www.nytimes.com/2019/10/09/technology/apple-hong-kong-app.html
https://www.macrumors.com/2019/10/03/apple-bans-app-used-by-hong-kong-protestors/
https://techcrunch.com/2019/10/09/apple-pulls-hkmap-from-app-store-the-day-after-chinese-state-media-criticized-its-unwise-and-reckless-decision-to-approve-it/?
Censoring Quartz: https://www.theverge.com/2019/10/9/20907228/apple-quartz-app-store-china-removal-hong-kong-protests-censorship
Censoring VPNs: https://www.nytimes.com/2017/07/29/technology/china-apple-censorhip.html?
Tim Cook says "I'm gay": https://www.msnbc.com/msnbc/apple-ceo-tim-cook-comes-out-gay-im-proud-msna447236
Apple kowtowed to the FBI: https://www.reuters.com/article/us-apple-fbi-icloud-exclusive/exclusive-apple-dropped-plan-for-encrypting-backups-after-fbi-complained-sources-idUSKBN1ZK1CT
...but Google didn't: https://security.googleblog.com/2018/10/google-and-android-have-your-back-by.html
Hosting malware apps on the App Store that target Uyghurs: https://www.theinformation.com/articles/apple-hosts-apps-run-by-china-paramilitary-group-accused-of-uyghur-genocide
https://appleinsider.com/articles/21/03/26/apple-accused-of-hosting-apps-by-chinese-group-tied-to-uyghur-genocide
https://about.fb.com/news/2021/03/taking-action-against-hackers-in-china/
Apple censored 55,000 apps in China: https://www.reuters.com/article/us-apple-china-games-idUSKBN2950P1

Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

