# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Black Widow - Movie Review
 - [https://www.youtube.com/watch?v=4OrTD81vdAU](https://www.youtube.com/watch?v=4OrTD81vdAU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-07-02 00:00:00+00:00

The movie wanted by fans back in 2014 finally got made. Was it worth the wait? Here's my review for #BlackWidow

