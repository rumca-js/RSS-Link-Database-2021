# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## iOS 15 Hands-On: Top 5 New Features!
 - [https://www.youtube.com/watch?v=O1sZcX-BBSA](https://www.youtube.com/watch?v=O1sZcX-BBSA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-07-02 00:00:00+00:00

The best iOS 15 Features, coming to an iPhone near you!
The first 1,000 people to use this link will get a 1 month free trial of Skillshare: https://skl.sh/marquesbrownlee06211

iOS 15 wallpapers: https://9to5mac.com/2021/06/07/download-the-new-ios-15-wallpapers-for-your-devices-right-here/

0:00 Intro
1:02 Redesigned apps
2:56 Facetime features
5:31 Live Text
7:07 Notifications
8:13 Focus Modes
10:15 Other Stuff + Conclusions

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

