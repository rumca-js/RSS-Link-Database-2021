# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe & Tim Dillon Discuss UFO Revelations
 - [https://www.youtube.com/watch?v=V1-QIhvPjFw](https://www.youtube.com/watch?v=V1-QIhvPjFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-07-03 00:00:00+00:00

Taken from JRE #1677 w/Tim Dillon:
https://open.spotify.com/episode/1yTuhZLmS9akyUadLm4zgT?si=Vi7kw2pcQEygn-z4daAXow&dl_branch=1

## Tim Dillon Has Suggestions for The View
 - [https://www.youtube.com/watch?v=URQg5_HjxKs](https://www.youtube.com/watch?v=URQg5_HjxKs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-07-03 00:00:00+00:00

Taken from JRE #1677 w/Tim Dillon:
https://open.spotify.com/episode/1yTuhZLmS9akyUadLm4zgT?si=Vi7kw2pcQEygn-z4daAXow&dl_branch=1

