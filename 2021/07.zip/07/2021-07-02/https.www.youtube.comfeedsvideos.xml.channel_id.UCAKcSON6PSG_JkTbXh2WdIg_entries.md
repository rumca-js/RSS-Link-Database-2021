# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Alice Merton - Lash Out (live performance for The Current)
 - [https://www.youtube.com/watch?v=1gCk1NSiDLg](https://www.youtube.com/watch?v=1gCk1NSiDLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-03 00:00:00+00:00

@AliceMerton joins The Current to play her 2019 single, "Lash Out".

Don't miss Alice's full virtual session, including an interview with The Current about overcoming her anxieties around performing, what makes a place "home," and her thoughts on writing about heartbreak: https://youtu.be/bP0kA6cX4uM

Subscribe to our channel:
http://www.youtube.com/user/893TheCur...

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Sunflower Bean - three songs at The Current (2016, 2018, 2019)
 - [https://www.youtube.com/watch?v=Rt10cX75bpI](https://www.youtube.com/watch?v=Rt10cX75bpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-03 00:00:00+00:00

Three years ago this week, Sunflower Bean performed in our studio. They've visited The Current before and since, so here are three performances by Sunflower Bean, recorded live in our studio over the past several years.

SONGS PERFORMED
0:00 "Easier Said" (2016)
3:18 "I Was A Fool" (2018)
8:07 "Come For Me" (2019)

PERSONNEL
Julia Cumming – vocals, bass 
Nick Kivlen – guitar, backing vocals 
Danny Ayala – guitar, keys, backing vocals
Jacob Faber – drums 

CREDITS
Video & Photo: Nate Ryan; Mary Mathis
Audio: Michael DeMark; John Miller; Cameron Wiley
Production: Derrick Stevens

FIND MORE:
2016 studio session: https://www.thecurrent.org/feature/2016/04/06/sunflower-bean-perform-in-the-current-studio
2018 session during SXSW:
https://www.thecurrent.org/feature/2018/03/13/sunflower-bean-take-the-stage-at-our-sxsw-day-party
2018 studio session: https://www.thecurrent.org/feature/2018/06/29/sunflower-bean-perform-in-the-current-studio
2019 studio session:
https://www.thecurrent.org/feature/2019/02/15/sunflower-bean-perform-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#thecurrent #sunflowerbean

## Alice Merton - No Roots (live performance for The Current)
 - [https://www.youtube.com/watch?v=bUMa51Qu0js](https://www.youtube.com/watch?v=bUMa51Qu0js)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-02 00:00:00+00:00

@AliceMerton joins The Current to play her 2016 hit song, "No Roots".

Don't miss Alice's full virtual session, including an interview with The Current about overcoming her anxieties around performing, what makes a place "home," and her thoughts on writing about heartbreak: https://youtu.be/bP0kA6cX4uM

Subscribe to our channel:
http://www.youtube.com/user/893TheCur...

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

## Alice Merton - Vertigo (live performance for The Current)
 - [https://www.youtube.com/watch?v=XMIKckPRI6g](https://www.youtube.com/watch?v=XMIKckPRI6g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-02 00:00:00+00:00

@AliceMerton joins The Current to play her latest single, "Vertigo".

Don't miss Alice's full virtual session, including an interview with The Current about overcoming her anxieties around performing, what makes a place "home," and her thoughts on writing about heartbreak: https://youtu.be/bP0kA6cX4uM

Subscribe to our channel:
http://www.youtube.com/user/893TheCur...

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

