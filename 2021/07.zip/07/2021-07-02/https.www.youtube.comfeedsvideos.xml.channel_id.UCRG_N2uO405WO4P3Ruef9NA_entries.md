# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Why Microsoft won't let you run Windows 11
 - [https://www.youtube.com/watch?v=_xqbp0w5fJ4](https://www.youtube.com/watch?v=_xqbp0w5fJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-07-02 00:00:00+00:00

Sponsored by Morning Brew. Sign up for free today: https://bit.ly/mbfridaycheckout 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week the Microsoft Store got a lot of classic apps, Microsoft tried to keep customers from updating to Windows 11 with strange hardware requirements and Realme wants to launch over 100 new products.

Episode 53

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-why-microsoft-wont-let-you-run-windows-11

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:32 Release Monitor
1:31 Microsoft Store updates
2:57 Windows 11 update mystery
6:59 Realme TechLife



▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Sources ◄◄◄

Overview:
https://www.techrepublic.com/article/windows-11-understanding-the-system-requirements-and-the-security-benefits/?ftag=COS-05-10aaa0g&taid=60dc71dfbcdfda0001431590&utm_campaign=trueAnthem:+Twitter+Card&utm_medium=trueAnthemCard&utm_source=twitterCard


Official Windows 11 docs: https://blogs.windows.com/windows-insider/2021/06/28/update-on-windows-11-minimum-system-requirements/
Secured Core:
https://www.microsoft.com/security/blog/2019/10/21/microsoft-and-partners-design-new-device-security-requirements-to-protect-against-targeted-firmware-attacks/
VBS explained: https://docs.microsoft.com/en-us/windows-hardware/design/device-experiences/oem-vbs
HVCI explained:
https://docs.microsoft.com/en-us/windows-hardware/design/device-experiences/oem-hvci-enablement
Turning on VBS by default: https://techcommunity.microsoft.com/t5/virtualization/virtualization-based-security-enabled-by-default/ba-p/890167

The same security stuff in Windows 10 since 2017:
https://www.bleepingcomputer.com/news/security/microsoft-releases-standards-for-highly-secure-windows-10-devices/

Performance complaints on Windows 10:
http://borec.ch/the-potential-performance-impact-of-device-guard-hvci/
https://www.ctrl.blog/entry/slow-windows-hvci.html
https://steamcommunity.com/discussions/forum/11/1631916887508385541/
https://www.reddit.com/r/sysadmin/comments/9ll02b/windows_defender_credential_guard_performance/

Chip vendors chiming in:
https://community.amd.com/t5/amd-business-blog/amd-and-microsoft-secured-core-pc/ba-p/418204
https://itpeernetwork.intel.com/foundational-pc-protection-for-the-changing-security-landscape/#gs.5av831

