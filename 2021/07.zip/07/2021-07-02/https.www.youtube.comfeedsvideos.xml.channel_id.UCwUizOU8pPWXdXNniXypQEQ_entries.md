# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Wokecabulary - Leftist Speech Translated!
 - [https://www.youtube.com/watch?v=HWms5J7yzW8](https://www.youtube.com/watch?v=HWms5J7yzW8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-07-03 00:00:00+00:00

Grab Your Freedom Bundle Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Learn the new meaning of old words with Wokecabulary, leftist speech translated. How can you be the most politically correct, most woke, most Marxist, most socially destructive person possible? Expanding your Wokecabulary is the key!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

