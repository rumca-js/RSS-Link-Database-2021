# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Most EVIL CHOICES You Can Make in Video Games
 - [https://www.youtube.com/watch?v=Ce2vjqNpsaQ](https://www.youtube.com/watch?v=Ce2vjqNpsaQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-03 00:00:00+00:00

Some video games give you the option to do some truly terrible things. Here are our favorite evil examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Credit:
https://www.reddit.com/r/Fallout/comments/nspons/one_of_the_most_evil_things_you_can_do_in_new/

## TODD HOWARD GIVES ELDER SCROLLS 6 UPDATE, ROCKSTAR FOUNDER'S NEW STUDIO & MORE
 - [https://www.youtube.com/watch?v=V9oVtmuJVPA](https://www.youtube.com/watch?v=V9oVtmuJVPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-02 00:00:00+00:00

Brought to you by Raycon. Go to http://buyraycon.com/gameranx for 15% off your order!

A Dead Space remake update, Rockstar Games' cofounder starts a new studio, Xbox talks the future, Ghost of Tsushima is expanded with a Director's Cut, and more in a week full of gaming news.

Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake's other channel: https://youtu.be/AqozTuGx6Ss




 ~~~~STORIES~~~~


Gamestop’s PS5 thing
https://kotaku.com/gamestop-takes-advantage-of-ps5-scarcity-with-scummy-pr-1847211489

Rockstar founder’s new studio:
https://www.pcgamer.com/rockstars-dan-houser-has-set-up-his-new-studio/



Todd Howard and ES6
https://www.videogameschronicle.com/news/its-good-to-think-of-elder-scrolls-6-as-still-in-a-design-phase-says-todd-howard/amp/?__twitter_impression=true


Kojima 
https://venturebeat.com/2021/07/01/hideo-kojimas-deal-with-xbox-reaches-key-milestone/

Bloober and Konami:
https://www.videogameschronicle.com/news/konami-and-bloober-team-announce-partnership-amid-silent-hill-links/

Ghost of Tsushima expansion
https://blog.playstation.com/2021/07/01/ghost-of-tsushima-directors-cut-arrives-on-ps5-and-ps4-consoles-on-august-20/

Sony acquires Housemarque 
https://www.gq-magazine.co.uk/culture/article/housemarque-sony-playstation-acquisition
https://www.businesswire.com/news/home/20210701005274/en/Sony-Interactive-Entertainment-Acquires-Nixxes-to-Further-Elevate-PlayStation-Studios-Exclusive-Titles

No new Xbox hardware revisions soon: 
https://www.ign.com/articles/xbox-series-x-s-new-hardware-roadmap-tease-phil-spencer


New Diablo 4 stuff
https://www.polygon.com/22557359/diablo-4-art-characters-classes-enemies-monster-design


Zelda trailer 
https://youtu.be/y-u1tM-zADg

Fan made dark souls sequel: https://youtu.be/XXTyC7ImsvQ

DeLorean wow
https://twitter.com/torque99uk/status/1410854261378932737?s=20


Dead Space
https://venturebeat.com/2021/07/01/dead-space-remake-is-in-the-works-at-motive/
EA Play stuff: https://twitter.com/bioware/status/1410659591277486081?s=20

