# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Grające kolczyki Nova H1, smartfon do kontrolowania dzieci i Beats Studio Buds przyszły! #MWC2021
 - [https://www.youtube.com/watch?v=IYIRbwou97k](https://www.youtube.com/watch?v=IYIRbwou97k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-07-02 00:00:00+00:00

To już ostatni film z targów MWC i jednocześnie pierwsze wrażenia dotyczące słuchawek Beats Studio Buds, które właśnie do mnie przyszły.
Film zawiera lokowanie ZEN: https://bit.ly/3rklh8W (kod przedłużający okres próbny: klawyzen)
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Barcelona – wideo
00:28 Nowe drzwi w studio
00:42 Dzisiaj w odcinku
01:28 Grające kolczyki Nova H1 
03:00 Brzmienie kolczyków – opinia Patrycji
03:37 Wappsto:bit – proste urządzenie dla młodych programistów
04:18 Smartfon do kontrolowania dzieci
05:50 Smart opaska dla kotów – Catmos
06:48 Beats Studio Buds – unboxing i pierwsze wrażenia 
08:37 Lokowanie ZEN – fragment sponsorowany
09:34 W kolejnych odcinkach…
09:59 Pożegnanie

