# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## SPELLLING - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=IHM2kvRo_1M](https://www.youtube.com/watch?v=IHM2kvRo_1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-03 00:00:00+00:00

http://KEXP.ORG presents SPELLLING performing live, recorded exclusively for KEXP.

Songs:
Little Deer
Always
Awaken
Boys at School
Sweet Talk

Session Recorded at Tiny Telephone in Oakland, California
Filmed and edited by Chantel Beam
Piano by Javier Santiago
Bass by Gulio Xavier Cetto
Mixed by Maryam Qudus

https://www.spelllingmusic.com
http://kexp.org

## SPELLLING - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Y8ZdHuhQqsQ](https://www.youtube.com/watch?v=Y8ZdHuhQqsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-02 00:00:00+00:00

http://KEXP.ORG presents SPELLLING sharing a live performance recorded exclusively for KEXP and talking to Gabriel Teodros, host of Early on KEXP. Recorded June 17, 2021.

Songs:
Little Deer
Always
Awaken
Boys at School
Sweet Talk

Session Recorded at Tiny Telephone in Oakland, California
Filmed and edited by Chantel Beam
Piano by Javier Santiago
Bass by Gulio Xavier Cetto
Mixed by Maryam Qudus

https://www.spelllingmusic.com
http://kexp.org

