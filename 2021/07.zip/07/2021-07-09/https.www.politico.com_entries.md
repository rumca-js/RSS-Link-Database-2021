## POLITICO-Harvard poll: Most Americans believe Covid leaked from lab  - POLITICO
 - [https://www.politico.com/news/2021/07/09/poll-covid-wuhan-lab-leak-498847](https://www.politico.com/news/2021/07/09/poll-covid-wuhan-lab-leak-498847)
 - RSS feed: https://www.politico.com
 - date published: 2021-07-09 19:35:21+00:00

POLITICO-Harvard poll: Most Americans believe Covid leaked from lab  - POLITICO

