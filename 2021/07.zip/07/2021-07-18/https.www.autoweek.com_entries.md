## GM Will Suck Lithium From the Salton Sea to Make Batteries
 - [https://www.autoweek.com/news/green-cars/a37029490/gm-will-suck-lithium-from-the-salton-sea-to-make-batteries/](https://www.autoweek.com/news/green-cars/a37029490/gm-will-suck-lithium-from-the-salton-sea-to-make-batteries/)
 - RSS feed: https://www.autoweek.com
 - date published: 2021-07-18 07:00:55.792589+00:00

The process will have a lower environmental impact than traditional lithium mining. 

