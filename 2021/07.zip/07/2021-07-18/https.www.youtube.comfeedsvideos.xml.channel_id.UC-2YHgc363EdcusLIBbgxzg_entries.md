# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Weird Phenomenon That Proves Pain Is All In The Mind | Answers With Joe
 - [https://www.youtube.com/watch?v=uvzKQ2xTjUA](https://www.youtube.com/watch?v=uvzKQ2xTjUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-07-19 00:00:00+00:00

Use code JOESCOTT14 for up to 14 FREE MEALS across your first 5 HelloFresh boxes plus free shipping at https://bit.ly/3qmkZPn !
Up to 70% of amputees claim to feel pain in their missing limbs, and we're still not completely sure why. Some of the theories range from nerve damage to crossed wires in the brain to a redrawing of the mind's map. And some new therapies involving simple mirror illusions and cutting edge technology are helping amputees live less painful lives. And it's also making us question the very nature of reality.

Big thanks to Giovannie Cruz, Kyle Montgomery, and Cooper Carr for help with the intro!
Check out Giovannie's IMDB page: https://www.imdb.com/name/nm4530613/?ref_=nv_sr_srsg_0


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS

https://www.historic-uk.com/HistoryUK/HistoryofEngland/Admiral-Lord-Nelson/
https://ageofrevolution.org/surgeons-blade-nelsons-trauma-tenerife/

https://www.beaconpo.com/blog/what-is-phantom-pain-and-how-can-it-be-treated 

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4182588/

https://www.news-medical.net/health/What-is-a-Phantom-Limb.aspx

https://www.mayoclinic.org/diseases-conditions/phantom-pain/symptoms-causes/syc-20376272

https://www.mcmasteroptimalaging.org/blog/detail/blog/2019/02/18/mirror-therapy-for-stroke-rehabilitation-tricking-the-brain-into-believing-what-it-sees

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3935120/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5825921/

https://www.mobihealthnews.com/content/researchers-pair-vr-tactile-prosthetics-fight-amputees-phantom-limb-sensations
https://jnnp.bmj.com/content/90/7/833

