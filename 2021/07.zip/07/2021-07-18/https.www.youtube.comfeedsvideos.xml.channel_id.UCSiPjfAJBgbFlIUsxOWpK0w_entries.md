# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Pomplamoose + Scary Pockets love triangle 😍😍😍
 - [https://www.youtube.com/watch?v=g0R5tfPIMO8](https://www.youtube.com/watch?v=g0R5tfPIMO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2021-07-19 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Funny story…Jack and I actually got married twice…and Ryan Lerman played us down the aisle both times, with the song “God Only Knows.” So when Ryan invited me to sing with Scary Pockets, I knew what we had to do :)

Watch the cover on the Scary Pockets channel: https://youtu.be/lRYQAoXQfn8

VIDEO CREDITS
Director: Dom Fera
DP/Camera Op: Ricky Chavez
Editor: Jeremiah Williams
Illustrations: Veronica K.

Recorded at Boulevard in Los Angeles.

