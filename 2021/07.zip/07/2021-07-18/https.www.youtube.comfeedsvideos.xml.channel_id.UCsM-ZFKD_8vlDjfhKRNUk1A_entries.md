# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Muchy - Psy miłości - live MUZO.FM feat. Monika Borzym
 - [https://www.youtube.com/watch?v=0eNyeGJrQ_s](https://www.youtube.com/watch?v=0eNyeGJrQ_s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2021-07-19 00:00:00+00:00

Muchy na żywo w MUZO.FM. Utwór Psy miłości pochodzi z płyty grupy Muchy - Szaroróżowe. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Muchy : http://www.facebook.com/Muchyband
Instagram Muchy : http://www.instagram.com/muchyband
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

