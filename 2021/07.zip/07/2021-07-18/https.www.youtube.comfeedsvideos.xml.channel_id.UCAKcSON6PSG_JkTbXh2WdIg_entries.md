# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Shungudzo - Virtual Session
 - [https://www.youtube.com/watch?v=qloTMIT_pWI](https://www.youtube.com/watch?v=qloTMIT_pWI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-07-19 00:00:00+00:00

@Shungudzo joins Mary Lucia in conversation about the ways poetry are intertwined with her songwriting, her experiences as a child moving from Zimbabwe to the U.S., and what she's got planned for the fall. Plus, watch performances of tracks from her new record, 'I'm not a mother, but I have children'.

Songs Played: 
00:01 It's a good day (to fight the system)
14:47 There's only so much a soul can take
30:45 To be me
42:11 I'm not a mother, but I have children

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/

Credits
Host - Mary Lucia
Producer - Derrick Stevens
Technical Director - Eric Romani
Digital Producer - Jesse Wiza

