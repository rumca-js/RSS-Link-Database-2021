## McCloskeys plead guilty to charges after gun-toting display
 - [https://news.yahoo.com/mccloskeys-plead-guilty-charges-gun-195300768.html](https://news.yahoo.com/mccloskeys-plead-guilty-charges-gun-195300768.html)
 - RSS feed: https://news.yahoo.com
 - date published: 2021-07-18 14:15:49+00:00

McCloskeys plead guilty to charges after gun-toting display

