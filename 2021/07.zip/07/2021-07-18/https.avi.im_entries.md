## Inserting One Billion Rows in SQLite Under A Minute - blag
 - [https://avi.im/blag/2021/fast-sqlite-inserts/](https://avi.im/blag/2021/fast-sqlite-inserts/)
 - RSS feed: https://avi.im
 - date published: 2021-07-18 21:38:57+00:00

This is a chronicle of my experiment where I set out to insert 1B rows in SQLite

