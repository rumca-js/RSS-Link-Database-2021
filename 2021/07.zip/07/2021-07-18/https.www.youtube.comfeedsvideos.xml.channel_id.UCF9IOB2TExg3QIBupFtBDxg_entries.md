# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Taiwan and South Africa
 - [https://www.youtube.com/watch?v=mhjIpLaW5gA](https://www.youtube.com/watch?v=mhjIpLaW5gA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-19 00:00:00+00:00

Thank you so much Jessica and Barbara for these authoritative reports from your local situations.
I know Jessica and Barbara will be reading the comments section so please feel free to leave them both your supportive comments.

## UK hospital admissions will rise
 - [https://www.youtube.com/watch?v=TP8gsgTFPVc](https://www.youtube.com/watch?v=TP8gsgTFPVc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-19 00:00:00+00:00

The unknown is by how much, as the UK reopens, it is going to be a difficult summer

Neil Ferguson, (SAGE member)

England and Scotland have eases restrictions

Almost all legal restrictions on social contact end in England

Almost certain to reach

100,000 cases per day

1,000 hospital admissions per day

Maintaining this level could be described as success

Possible to reach

200,000 cases per day

2,000 hospital admissions per day

This would cause major disruption to the NHS

Much less certain to predict

May be a need to slow the spread to some extent

If hospital admissions were to reach 2,000 or 3,000 per day

Best projections

Peak, between August and mid-September

It will take 3 weeks to know effects of easing

Covid passports

In the UK from end of September

Long Covid

Another 500,000mpeople could get long Covid

I think case numbers are likely to be declining at least by late September, even in the the worst-case scenario

Going into the winter, I think we will have quite a high degree of immunity against Covid, 

the real concerns are a resurgence of influenza, because we haven't had any influenza for 18 months

Flu could be, frankly, almost as damaging both for health and the health system, by December or January, as Covid has been this year


Pingdemic

Health Secretary Sajid Javid positive

Doubled jabbed, pinged Boris Johnson and Rishi Sunak

https://www.bbc.co.uk/news/business-57878345

Rising exponentially

W/E 7th July

500,000 alerts sent to NHS Test and Trace app users

 Up 46% on previous week

Pinging level is about 3:1 of Covid cases

From 16 August

Fully vaccinated will not have to self-isolate if they are pinged 

Instead advised to take PCR test ASAP

Supermarket boss

The clock is ticking and the government needs to act fast to get people back to work if they have a negative test

If not, we could be heading towards crisis point next month

Morrisons

Throughout the whole of the pandemic, we have not been required to close a store

British Retail Consortium

Government must bring forward the changes on self-isolation from 16 August

so that people who are fully vaccinated or have a negative test are not forced to needlessly quarantine

The Joint Committee on Vaccination and Immunisation (JCVI)

https://www.bbc.co.uk/news/uk-57876608

12 to 17s soon

Vulnerable 12 to 15-year-olds and those nearly 18

Jeremy Hunt

the government was likely to have to reintroduce some controls in the autumn

Hospital admissions, NHS was facing a very serious situation

Prof Jonathan Van-Tam

Bumpy winter ahead

Approach the easing, in a cautious, steady, gradual way

## World watching UK experiment
 - [https://www.youtube.com/watch?v=IUc_W1KbHNo](https://www.youtube.com/watch?v=IUc_W1KbHNo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-19 00:00:00+00:00

TV interview

