# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Spiritfarer Documentary - A Game About Dying
 - [https://www.youtube.com/watch?v=qxx8sEGjntI](https://www.youtube.com/watch?v=qxx8sEGjntI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-07-19 00:00:00+00:00

The Escapist is very proud to present our latest documentary telling the story of the development behind Thunder Lotus' indie-hit, Spiritfarer.

If you enjoy the documentary and want to see even more of them, please consider becoming a Member on YouTube or sending in a donation to support its creation! https://www.escapistmagazine.com/v2/the-escapist/

Interviews: Nick Calandra
Editing: Omar Ahmed
Original Soundtrack: James Elsey - https://jameselseymusic.bandcamp.com/album/spiritfarer-documentary-original-soundtrack


Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

