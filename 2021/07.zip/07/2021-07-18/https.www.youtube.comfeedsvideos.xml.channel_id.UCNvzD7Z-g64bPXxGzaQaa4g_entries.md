# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Open World Games That RUINED EXPECTATIONS
 - [https://www.youtube.com/watch?v=ZsImM6Savas](https://www.youtube.com/watch?v=ZsImM6Savas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-19 00:00:00+00:00

Some open world games just don't live up to the hype. Here are some of our least favorites.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Games That Force You to FIGHT YOUR PARTNER
 - [https://www.youtube.com/watch?v=wVo2uMAA4D4](https://www.youtube.com/watch?v=wVo2uMAA4D4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-18 00:00:00+00:00

Some games eventually make you turn on your team/partner/comrade/friend and it hurts every time. Here are some examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

