# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Valve Entered The Console Market (For Real This Time)
 - [https://www.youtube.com/watch?v=OwxS6oH04pQ](https://www.youtube.com/watch?v=OwxS6oH04pQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2021-07-19 00:00:00+00:00

Valve made a Nintendo Switch

Kinda wish they didn’t announce this the moment I uploaded the last video, but alas

Here's a video about things including the topic in question

Yup

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpe...

Additional Footage Credits:

iGN
ETA PRIME
Tech Help Sourav
Origin PC
Alienware
Digital Foundry
MKWCTs

