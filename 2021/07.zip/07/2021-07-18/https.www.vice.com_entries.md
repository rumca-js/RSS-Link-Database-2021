## I'm a Frito-Lay Factory Worker. I Work 12-Hour Days, 7 Days a Week
 - [https://www.vice.com/en/article/pkbmwy/im-a-frito-lay-factory-worker-i-work-12-hour-days-7-days-a-week](https://www.vice.com/en/article/pkbmwy/im-a-frito-lay-factory-worker-i-work-12-hour-days-7-days-a-week)
 - RSS feed: https://www.vice.com
 - date published: 2021-07-18 07:22:42.003691+00:00

Hundreds of workers at the Frito-Lay plant in Topeka, Kansas are striking for the first time. 

