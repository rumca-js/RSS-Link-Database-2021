# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Sun Valley - The New Davos?
 - [https://www.youtube.com/watch?v=TXnHT1aRD7k](https://www.youtube.com/watch?v=TXnHT1aRD7k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-19 00:00:00+00:00

What happens at the Sun Valley conference, the secret gathering of unelected billionaire kings?
#SunValley #davos #BillGates #JeffBezos #MarkZuckerberg

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

Get passes to my show Our Little Lives: Shakespeare & Me. It's streaming on Live Now on July 14th. http://bit.ly/3godW5g

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

___________________________________
Click the link below to subscribe below to my Youtube Channel:

http://www.youtube.com/c/RussellBrand?sub_confirmation=1


For meditation and breath work, subscribe to my side-channel: 

http://www.youtube.com/c/AwakeningWithRussell?sub_confirmation=1
___________________________________

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

## Thought Amazon Couldn’t Sink Any Lower?? THINK AGAIN!!!
 - [https://www.youtube.com/watch?v=-7SZ9vsaKew](https://www.youtube.com/watch?v=-7SZ9vsaKew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-07-18 00:00:00+00:00

Welcome to dystopia: getting fired from your job as an Amazon worker by an APP! 
#amazon #JeffBezos #RusellBrand 

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

Get passes to my show Our Little Lives: Shakespeare & Me. It's streaming on Live Now on July 14th. http://bit.ly/3godW5g

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

___________________________________
Click the link below to subscribe below to my Youtube Channel:

http://www.youtube.com/c/RussellBrand?sub_confirmation=1


For meditation and breath work, subscribe to my side-channel: 

http://www.youtube.com/c/AwakeningWithRussell?sub_confirmation=1
___________________________________

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

