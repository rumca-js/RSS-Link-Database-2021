# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## An Unedited, Rain-Soaked Ride on Claughton's Aerial Ropeway
 - [https://www.youtube.com/watch?v=7JTWc6jWZ9Q](https://www.youtube.com/watch?v=7JTWc6jWZ9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-07-19 00:00:00+00:00

Here's the full video from a camera attached to a bucket on the Claughton Aerial Ropeway! And here's my whole video about the ropeway and its history: https://www.youtube.com/watch?v=6RiYXI1Tfu4

Thanks to all the team at Forterra: https://www.forterra.co.uk/

Filmed on a GoPro Hero 9 with Hypersmooth Boost enabled

I've got a newsletter now! It goes out every week and includes interesting links I've found while researching that week: https://www.tomscott.com/newsletter/

And there's an experimental second channel in progress: https://www.youtube.com/watch?v=ZNyOrINHtdM

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

