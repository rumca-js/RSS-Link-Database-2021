# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## God Only Knows | The Beach Boys | funk cover ft. Pomplamoose
 - [https://www.youtube.com/watch?v=lRYQAoXQfn8](https://www.youtube.com/watch?v=lRYQAoXQfn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-07-19 00:00:00+00:00

Watch the behind the scenes video: https://youtu.be/g0R5tfPIMO8

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of The Beach Boys "God Only Knows" by Scary Pockets & Nataly Dawn.

MUSICIAN CREDITS
Lead vocal: Nataly Dawn of Pomplamoose
B3 Organ: Larry Goldings
Drums: Lemar Carter
Bass: Nicole Row
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP/Camera Op: Ricky Chavez
Editor: Adam Kritzberg

Recorded Live at Boulevard in Los Angeles, CA.

#ScaryPockets #Funk #TheBeachBoys #GodOnlyKnows #NatalyDawn #Pomplamoose

