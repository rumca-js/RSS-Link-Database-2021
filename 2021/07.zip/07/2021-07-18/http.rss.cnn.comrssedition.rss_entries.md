# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Coco Gauff will miss the Tokyo Olympics after testing positive for Covid-19
 - [https://www.cnn.com/2021/07/18/us/cori-coco-gauff-covid-19-olympics-spt-trnd/index.html](https://www.cnn.com/2021/07/18/us/cori-coco-gauff-covid-19-olympics-spt-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 22:02:52+00:00

American tennis hopeful Cori "Coco" Gauff will miss the Tokyo Olympics after announcing on Twitter Sunday she tested positive for Covid-19.

## #FreeBritney activists celebrate win for Britney Spears this week
 - [https://www.cnn.com/2021/07/18/entertainment/britney-spears-thanks-fans-free-britney-conservatorship-hearing/index.html](https://www.cnn.com/2021/07/18/entertainment/britney-spears-thanks-fans-free-britney-conservatorship-hearing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 21:09:00+00:00

Outside the Los Angeles County Superior Courthouse on the day of Britney Spears' July 14 court hearing for her conservatorship, a dozens of some of the singer's most devoted fans gathered.

## Lewis Hamilton wins British Grand Prix after high-speed collision with Max Verstappen
 - [https://www.cnn.com/2021/07/18/motorsport/british-grand-prix-max-verstappen-lewis-hamilton-collision-spt-intl/index.html](https://www.cnn.com/2021/07/18/motorsport/british-grand-prix-max-verstappen-lewis-hamilton-collision-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 21:05:43+00:00

Formula One world champion Lewis Hamilton and Max Verstappen, who is leading the drivers' championship this season, were involved in a high-speed collision on the opening lap of the British Grand Prix on Sunday.

## Collin Morikawa makes history with Open win after dramatic final round
 - [https://www.cnn.com/2021/07/18/golf/collin-morikawa-the-open-winner-spt-intl/index.html](https://www.cnn.com/2021/07/18/golf/collin-morikawa-the-open-winner-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 21:00:12+00:00

Collin Morikawa won the Open golf tournament on Sunday, finishing two shots ahead of Jordan Spieth.

## 'An interesting twist': Carlson went on the record with Time magazine reporter. Here's what she learned
 - [https://www.cnn.com/videos/media/2021/07/18/charlotte-alter-tucker-carlson-interview-tuckerism-sot-rs-vpx.cnn](https://www.cnn.com/videos/media/2021/07/18/charlotte-alter-tucker-carlson-interview-tuckerism-sot-rs-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 19:42:42+00:00

Time Magazine's Charlotte Alter got a rare on-the-record interview with Fox News host Tucker Carlson and shares what she learned about why he is so appealing to the conservative base.

## Tadej Pogacar: Slovenian cycling sensation clinches second Tour de France victory
 - [https://www.cnn.com/2021/07/18/sport/tadej-pogacar-tour-de-france-spt-intl/index.html](https://www.cnn.com/2021/07/18/sport/tadej-pogacar-tour-de-france-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 19:41:57+00:00

Sunday's processional final Tour de France stage that concluded in Paris confirmed Tadej Pogacar as winner of the race for a second year running.

## Timeline: Six key moments that shaped Jerusalem
 - [https://www.cnn.com/2021/07/18/middleeast/jerusalem-original-series-faith-and-fury-timeline/index.html](https://www.cnn.com/2021/07/18/middleeast/jerusalem-original-series-faith-and-fury-timeline/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 17:59:48+00:00

When there's news out of Jerusalem, reports often point to recent history to explain how such a complex web of communities came to reside in the Holy City.

## OPEC+ is boosting oil production, ending dispute that shook energy markets
 - [https://www.cnn.com/2021/07/18/business/opec-oil-increase/index.html](https://www.cnn.com/2021/07/18/business/opec-oil-increase/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 17:42:54+00:00

OPEC+ agreed to increase oil production Sunday, as demand roars back and prices surge, ending a dispute between the United Arab Emirates and Saudi Arabia.

## Researchers identify 14 living descendants of Leonardo da Vinci's family tree
 - [https://www.cnn.com/2021/07/18/us/leonardo-da-vinci-living-descendants-trnd/index.html](https://www.cnn.com/2021/07/18/us/leonardo-da-vinci-living-descendants-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 17:40:24+00:00

Decades-long research into Leonardo da Vinci's purported remains has revealed how many people currently alive can claim to be descendants of the Renaissance genius and Mona LIsa painter:

## Haiti's journey from riches to chaos
 - [https://www.cnn.com/videos/tv/2021/07/18/exp-gps-0718-haitis-turbulent-history.cnn](https://www.cnn.com/videos/tv/2021/07/18/exp-gps-0718-haitis-turbulent-history.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 16:18:02+00:00

Fareed takes a look at the history that led Haiti to become the Western hemisphere's poorest country in spite of its huge natural wealth.

## Enormous scale of destruction is revealed as water subsides after historic western Europe flooding
 - [https://www.cnn.com/2021/07/18/europe/western-europe-floods-sunday-intl/index.html](https://www.cnn.com/2021/07/18/europe/western-europe-floods-sunday-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 15:55:46+00:00

More than 160 people are dead and hundreds more remain missing after catastrophic flooding hit large swaths of western Europe, with tens of thousands unable to return to their homes and many still left without access to power and drinking water.

## Austria probes reports of Havana Syndrome among US diplomats in Vienna
 - [https://www.cnn.com/2021/07/18/europe/austria-us-havana-syndrome-intl/index.html](https://www.cnn.com/2021/07/18/europe/austria-us-havana-syndrome-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 14:28:27+00:00

Austrian authorities said they are investigating reports that US diplomats in Vienna have experienced symptoms of a mystery illness known as Havana Syndrome.

## 3 dead, 2 taken to hospital in suspected carbon monoxide exposure during Michigan music festival, police say
 - [https://www.cnn.com/2021/07/18/us/carbon-monoxide-exposure-michigan/index.html](https://www.cnn.com/2021/07/18/us/carbon-monoxide-exposure-michigan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 14:16:31+00:00

Three men were found dead inside a travel trailer Saturday at a country music festival in southern Michigan in what police believe is a case of carbon monoxide exposure, officials said.

## Donald Trump's big book party
 - [https://www.cnn.com/2021/07/18/opinions/trumps-big-book-party-opinion-weekly-column-carr/index.html](https://www.cnn.com/2021/07/18/opinions/trumps-big-book-party-opinion-weekly-column-carr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 13:58:00+00:00

"The past is never dead. It's not even past," wrote William Faulkner in "Requiem for a Nun."

## Covid outbreak at Olympic Village in Tokyo
 - [https://www.cnn.com/2021/07/18/asia/olympic-village-athletes-covid-intl-hnk/index.html](https://www.cnn.com/2021/07/18/asia/olympic-village-athletes-covid-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 13:32:36+00:00

Two athletes in Tokyo's Olympic Village have tested positive for Covid-19, organizers confirmed Sunday, just days before the Games were set to begin.

## Germany's Olympic soccer team walks off the pitch during friendly match over alleged racial abuse
 - [https://www.cnn.com/2021/07/17/football/germany-olympics-football-honduras-racism-spt-intl/index.html](https://www.cnn.com/2021/07/17/football/germany-olympics-football-honduras-racism-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 13:19:34+00:00

Germany's Olympic soccer team walked off the pitch during a friendly match against Honduras after one of the German players was racially abused, according to the German Football Association (DFB).

## IOC backs transgender weightlifter's selection for Tokyo
 - [https://www.cnn.com/2021/07/17/sport/laurel-hubbard-tokyo-2020-transgender-ioc-spt-intl/index.html](https://www.cnn.com/2021/07/17/sport/laurel-hubbard-tokyo-2020-transgender-ioc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 13:17:02+00:00

The International Olympic Committee on Saturday backed New Zealand's selection of transgender weightlifter Laurel Hubbard for the Tokyo Olympics despite criticism, saying that under the current rules -- which will be reviewed in future -- she can compete.

## We need Nelson Mandela's example more than ever today
 - [https://www.cnn.com/2021/07/18/us/nelson-mandela-birthday-lessons-for-us-politics-today/index.html](https://www.cnn.com/2021/07/18/us/nelson-mandela-birthday-lessons-for-us-politics-today/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 13:16:10+00:00

One autumn evening, Nelson Mandela answered a knock at his front door and found himself facing his most dangerous enemy.

## Thai golfer Jazz Janewattananond hits bunker shot from knees during the Open -- and posts video on social media showing he'd practiced it beforehand
 - [https://www.cnn.com/2021/07/17/golf/jazz-janewattananond-bunker-shot-knees-the-open-spt-intl/index.html](https://www.cnn.com/2021/07/17/golf/jazz-janewattananond-bunker-shot-knees-the-open-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 12:45:11+00:00

A golfer's flexibility and ability to adapt to difficult terrains are some of his most important attributes.

## Boris Johnson will place English citizens at the center of a risky Covid experiment
 - [https://www.cnn.com/collections/intl-uk-covid-0718/](https://www.cnn.com/collections/intl-uk-covid-0718/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 11:47:18+00:00



## NBA Finals: Bucks rally past Suns, take 3-2 lead
 - [https://www.cnn.com/2021/07/18/sport/milwaukee-bucks-phoenix-suns-nba-finals-game-5-spt-intl/index.html](https://www.cnn.com/2021/07/18/sport/milwaukee-bucks-phoenix-suns-nba-finals-game-5-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 11:41:54+00:00

The Milwaukee Bucks scorched the host Phoenix Suns with a sizzling second quarter before holding on to inch closer to their first NBA title in a half-century.

## Dozens of Black cultural sites will be preserved for years to come, thanks to a $3 million grant
 - [https://www.cnn.com/2021/07/18/us/black-cultural-heritage-sites-preservation-grant-trnd/index.html](https://www.cnn.com/2021/07/18/us/black-cultural-heritage-sites-preservation-grant-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 11:21:54+00:00

The stories and legacies of Black Americans can be found throughout the US, each site and landmark helping illustrate a more complete picture of the nation we live in.

## Half of the US believes a deadly conspiracy theory
 - [https://www.cnn.com/2021/07/17/politics/conspiracy-theories-election-vaccines-analysis/index.html](https://www.cnn.com/2021/07/17/politics/conspiracy-theories-election-vaccines-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 11:05:50+00:00

The two most monumental events of the last year in the US were the election of Joe Biden to the presidency and the introduction of Covid-19 vaccines. Yet there are those who falsely believe Biden won only because of fraud or that they shouldn't get a vaccine.

## The UK Prime Minister will place English citizens at the center of a risky Covid experiment, while his government made yet another U-turn today
 - [https://www.cnn.com/2021/07/18/uk/boris-johnson-covid-gamble-freedom-day-intl-gbr-cmd/index.html](https://www.cnn.com/2021/07/18/uk/boris-johnson-covid-gamble-freedom-day-intl-gbr-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 10:19:06+00:00

On Monday, Boris Johnson will place English citizens at the center of an experiment that will give some indication of how well a highly populated country with surging cases of coronavirus copes when lockdown restrictions are lifted.

## Grief-induced anxiety: Calming the fears that follow loss
 - [https://www.cnn.com/2021/07/18/health/grief-anxiety-healing-loss-wellness/index.html](https://www.cnn.com/2021/07/18/health/grief-anxiety-healing-loss-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 10:06:30+00:00

Millions of Americans are grieving loved ones taken by Covid-19. Yet even outside of a pandemic — with its staggering losses of lives, homes, economic security and normalcy — grief is hard work.

## Suspected candle thief in Florida injures dozens of people with bear spray during his escape, police say
 - [https://www.cnn.com/2021/07/18/us/florida-candle-thief-bear-spray/index.html](https://www.cnn.com/2021/07/18/us/florida-candle-thief-bear-spray/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 09:12:56+00:00

A man in Doral, Florida, escaped from a mall store with stolen goods on Saturday by spraying everyone in his way with bear repellent, according to police.

## Indonesia battles devastating Covid crisis. The peak is yet to come
 - [https://www.cnn.com/2021/07/17/asia/indonesia-covid-second-wave-outbreak-intl-hnk-dst/index.html](https://www.cnn.com/2021/07/17/asia/indonesia-covid-second-wave-outbreak-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 08:34:10+00:00

• Two athletes in Tokyo's Olympic Village test positive for Covid-19
• Half of US believes a deadly conspiracy theory

## Qatar's Ras Abu Aboud stadium is the first built in World Cup history that was meant to be torn down
 - [https://www.cnn.com/2021/07/18/football/ras-abu-aboud-stadium-2022-qatar-world-cup-cmd-spt-intl/index.html](https://www.cnn.com/2021/07/18/football/ras-abu-aboud-stadium-2022-qatar-world-cup-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 07:37:36+00:00

It was once a quiet waterfront, only enjoying the occasional sounds from the nearby Gulf shores. Now, it's a dizzying burst of color and life -- soon to be filled with up to 40,000 screaming fans.

## Climate is the only thing Russia and the US can agree on right now
 - [https://www.cnn.com/2021/07/18/world/russia-us-climate-crisis-intl-cmd/index.html](https://www.cnn.com/2021/07/18/world/russia-us-climate-crisis-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 04:06:40+00:00



## Is Antarctica a country? The future of the world's least understood continent
 - [https://www.cnn.com/travel/article/is-antarctica-a-country-intl-hnk/index.html](https://www.cnn.com/travel/article/is-antarctica-a-country-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 01:45:23+00:00



## More than 60 sickened by 'chemical incident' at Texas water park
 - [https://www.cnn.com/videos/us/2021/07/18/texas-water-park-chemical-incident-sot-nr-vpx.cnn](https://www.cnn.com/videos/us/2021/07/18/texas-water-park-chemical-incident-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 01:05:20+00:00

Around 65 people were sickened at a Houston-area water park in what officials called a "chemical incident." CNN affiliate KPRC's Bill Barajas has details.

## Spike Lee shocks Cannes audience
 - [https://www.cnn.com/style/article/cannes-film-festival-2021-palme-dor-titane-julia-ducournau-highlights-spc-intl/index.html](https://www.cnn.com/style/article/cannes-film-festival-2021-palme-dor-titane-julia-ducournau-highlights-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 01:01:59+00:00



## Spike Lee stuns audience by announcing Cannes winner early
 - [https://www.cnn.com/videos/entertainment/2021/07/18/spike-lee-cannes-film-festival-titane-winner-sot-nr-vpx.cnn](https://www.cnn.com/videos/entertainment/2021/07/18/spike-lee-cannes-film-festival-titane-winner-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-07-18 00:59:29+00:00

In a shock moment, Spike Lee announced the winner of the Palme d'Or in error early in the Cannes Film Festival awards ceremony after a miscommunication.

