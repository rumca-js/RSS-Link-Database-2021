## Revealed: leak uncovers global abuse of cyber-surveillance weapon | Surveillance | The Guardian
 - [https://www.theguardian.com/world/2021/jul/18/revealed-leak-uncovers-global-abuse-of-cyber-surveillance-weapon-nso-group-pegasus](https://www.theguardian.com/world/2021/jul/18/revealed-leak-uncovers-global-abuse-of-cyber-surveillance-weapon-nso-group-pegasus)
 - RSS feed: https://www.theguardian.com
 - date published: 2021-07-18 21:55:29.750497+00:00

Spyware sold to authoritarian regimes used to target activists, politicians and journalists, data suggests

