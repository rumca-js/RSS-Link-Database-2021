# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Kylie V - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=iDnaSGW1bVk](https://www.youtube.com/watch?v=iDnaSGW1bVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-19 00:00:00+00:00

http://KEXP.ORG presents Kylie V (they/them) sharing a live performance recorded exclusively for KEXP and talking to DJ Abbie. Recorded July 6, 2021.

Songs:
On My Mind
Solace
Big Blue
A Story If You Want It
All Too Well (Taylor Swift cover)

Vocals, guitar: Kylie V
Bass: Cristian Hobson-Dimas
Violin: Tegan Wahlgren
Drums: Beni Hobson-Dimas

Camera operators: Joseph Hirabayashi, Dan Loan
Audio Engineer: Noah Kamis
Video Editing: Jim Beckmann (KEXP)
Audio Mixer: Kevin Suggs (KEXP)

https://kylievmusic.com
http://kexp.org

