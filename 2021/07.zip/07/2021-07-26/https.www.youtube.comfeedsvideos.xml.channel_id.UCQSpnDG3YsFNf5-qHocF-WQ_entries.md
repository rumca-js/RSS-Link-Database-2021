# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## This Smart Bed Water-Cools You: Eight Sleep "Pod Pro Max" Review
 - [https://www.youtube.com/watch?v=yNRyX7DT1cA](https://www.youtube.com/watch?v=yNRyX7DT1cA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-07-27 00:00:00+00:00

What even is a "smart" mattress anyway?  🤔
• Eight Sleep Website ⇨ https://eight-sleep.ioym.net/9WA76E (Code "THIO" for $350 off Pod 3 / $200 off the Pod 3 Cover - LIMITED TIME Black Friday Deal!) [Affiliate Link & Code]

▼ Time Stamps: ▼
0:00 - Intro
0:48 - Review Disclosures
1:39 - What is it?
3:32 - Why would you want this?
4:21 - Setup Process & Hardware
6:58 - Thermal Camera View & Test
9:52 - App: Features & Controls
14:22 - App: Sleep Report
16:26 - App: Health Report
17:07 - App: More Features
17:50 - The Mattress & Models
19:26 - Overall Thoughts

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

