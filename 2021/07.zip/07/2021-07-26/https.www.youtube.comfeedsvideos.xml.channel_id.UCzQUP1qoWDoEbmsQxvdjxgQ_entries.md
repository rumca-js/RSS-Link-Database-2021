# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Jimmy Dore's Experience with Vaccine Side Effects
 - [https://www.youtube.com/watch?v=UiLGSVH_UPA](https://www.youtube.com/watch?v=UiLGSVH_UPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-07-27 00:00:00+00:00

Taken from JRE #1687 w/Jimmy Dore:
https://open.spotify.com/episode/6CD0S0b1D5JknWXBQCctqI?si=4EZsROqOQA6un0OjwmKfgQ&dl_branch=1

