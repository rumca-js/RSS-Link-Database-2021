# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## Test zabawek naukowych #5
 - [https://www.youtube.com/watch?v=Z1gAb02wiig](https://www.youtube.com/watch?v=Z1gAb02wiig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2021-07-26 09:00:09+00:00

Scifun znowu bawi się zabawkami i udaje, że to praca.
Kupuj wszystko z cashbackiem Letyshops - https://letyshops.onelink.me/HKO3/267d74a3
Zainstaluj wtyczkę Letyshops - https://bit.ly/3iEegwJ

