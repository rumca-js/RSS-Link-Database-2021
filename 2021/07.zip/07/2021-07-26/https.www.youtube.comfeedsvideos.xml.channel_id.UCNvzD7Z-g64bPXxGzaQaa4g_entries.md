# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Red Dead Redemption 2: 10 NEW Things Discovered By Fans
 - [https://www.youtube.com/watch?v=tfCJVgVQnx8](https://www.youtube.com/watch?v=tfCJVgVQnx8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-27 00:00:00+00:00

Red Dead Redemption 2 is filled with secrets. Believe it or not, NEW things are still being discovered all of the time. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

SOURCES:

10. You can mess up the UFO
https://youtu.be/wCOMNnPu8Jc

https://www.reddit.com/r/reddeadmysteries/comments/aji1y3/not_sure_if_posted_already_a_youtuber_took/



9. The legendary Catfish
https://youtu.be/cGZXQ_ZFk5k


https://www.pcgamesn.com/red-dead-redemption-2/rdr2-fish



8. A mysterious 'lost' character is actually in the game files!

https://www.gamespot.com/articles/red-dead-redemption-2-pc-players-discover-a-hidden/1100-6471313/

https://www.reddit.com/r/reddeadredemption/comments/dt6mkv/spoilers_ikz_is_in_the_game_files_using_mods_to/

https://reddead.fandom.com/wiki/Isabeau_Katharina_Zinsmeister




7. River monster found in the game's code

https://www.youtube.com/watch?v=E9DbK1csSrU




6. Micah's Hideout in Mount Hagen has a secret

https://www.reddit.com/r/reddeadmysteries/comments/ioy7mz/i_thought_this_was_interesting_credit_goes_to/





5. The giant stump near valentine

https://www.reddit.com/r/reddeadmysteries/comments/m9l5ii/was_told_i_should_post_this_here_from_the_main/






4. The Mysterious Lightning strikes

https://www.reddit.com/r/reddeadmysteries/comments/fot0th/help_me_locate_all_of_the_areas_lightning_strikes/?utm_source=share&utm_medium=web2x

https://www.eurogamer.net/articles/2020-04-16-meet-the-storm-chaser-of-red-dead-redemption-2




3. There are coordinates on the loading screens pictures

https://www.reddit.com/r/reddeadmysteries/comments/anb4c0/rockstar_hid_a_coordinates_system_in_the_loading/




2. you can stare down bears to get them to leave you alone

https://www.vg247.com/2020/02/28/red-dead-redemption-2-stare-down-bear/




1. You can prevent fall damage by puking!

https://www.vg247.com/2020/02/24/vomit-roping-red-dead-redemption-2/

https://www.reddit.com/r/RedDeadOnline/comments/ds5m5s/vomit_ropetechnique/

## 5 NEW Graphics Tricks That Could Change Video Games
 - [https://www.youtube.com/watch?v=NVvQ_oZixKc](https://www.youtube.com/watch?v=NVvQ_oZixKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-07-26 00:00:00+00:00

Graphical technology is always evolving, and we've got 5 recent impressive examples of video games looking cooler than ever.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

5 Realtime Deepfake
https://www.youtube.com/watch?v=olKHiiEaPc4&ab_channel=BabyZone

#4
https://www.ea.com/seed/news/cog2021-curiosity-driven-rl-agents

#3 Machine Learning
https://www.tweaktown.com/news/80371/microsoft-experiments-with-high-end-machine-learning-on-xbox-series/index.html
https://www.tweaktown.com/news/79579/sony-ai-working-with-first-party-ps5-devs-on-machine-learning/index.html
+
https://www.windowscentral.com/amd-fsr-vs-nvidia-dlss


#2 Nanites
https://www.unrealengine.com/en-US/blog/understanding-nanite---unreal-engine-5-s-new-virtualized-geometry-system

#1
https://developer.microsoft.com/en-us/games/blog/microsoft-flight-simulator-the-future-of-game-development/

