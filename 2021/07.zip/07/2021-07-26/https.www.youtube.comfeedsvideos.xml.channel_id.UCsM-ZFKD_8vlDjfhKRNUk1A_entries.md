# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Kaśka Sochacka - Ciche dni - live MUZO.FM
 - [https://www.youtube.com/watch?v=pggneoZSJLc](https://www.youtube.com/watch?v=pggneoZSJLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2021-07-26 00:00:00+00:00

Kaśka Sochacka na żywo w MUZO.FM. Utwór Ciche dni pochodzi z debiutanckiej płyty artystki - Ciche dni. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Kaśka Sochacka: http://www.facebook.com/sochacka.kaska
Instagram Kaśka Sochacka: http://www.instagram.com/sochacka_kaska 
Instagram: http://www.instagram.com/muzofm 
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

