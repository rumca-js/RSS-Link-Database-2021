# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## We Can Work it Out | The Beatles | funk cover ft. Judith Hill
 - [https://www.youtube.com/watch?v=szv6oXFFxDw](https://www.youtube.com/watch?v=szv6oXFFxDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-07-26 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of The Beatles' "We Can Work it Out" by Scary Pockets & Judith Hill.

MUSICIAN CREDITS
Lead vocal: Judith Hill
Drums: Joey Waronker
Bass: David Piltch
Organ: Swatkins
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Director: Ben Kadie
DP: Kenzo Le
Editor: Adam Kritzberg

Recorded Live at Big Bad Sound in Los Angeles, CA.

#ScaryPockets #Funk #TheBeatles #WeCanWorkItOut #JudithHIll

