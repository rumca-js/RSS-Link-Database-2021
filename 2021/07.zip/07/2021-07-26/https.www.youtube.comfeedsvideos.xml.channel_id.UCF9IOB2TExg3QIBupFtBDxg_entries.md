# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## UK, down and down
 - [https://www.youtube.com/watch?v=xAmoA_q8Rjk](https://www.youtube.com/watch?v=xAmoA_q8Rjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-27 00:00:00+00:00

UK, Scotland, Cases peaked 1st July, Hospitalisations peaked 14th July

https://www.bbc.co.uk/news/health-57971990
Scotland, schools break up end of June

England, Scotland, schools break up 16th July

Great weather

PM

https://www.bbc.co.uk/news/uk-57981899

remain cautious

premature conclusions

This is still a dangerous disease

Test to release

Starts 16th August

Prof Neil Ferguson

Scientific Advisory Group for Emergencies

The effect of vaccines is hugely reducing the risk of hospitalisations and death

And I'm positive that by late September or October time we will be looking back at most of the pandemic.

We will have Covid with us, we will still have people dying from Covid, but we'll have put the bulk of the pandemic behind us too early to tell

happy to be wrong

We're not completely out of the woods, but the equation has fundamentally changed

Clearly the higher we can get vaccination coverage, the better. That will protect people and reduce transmission - but there is going to be remaining uncertainty until the autumn

## United States and Australia
 - [https://www.youtube.com/watch?v=k7sR3p0uiCg](https://www.youtube.com/watch?v=k7sR3p0uiCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-27 00:00:00+00:00

US, 100 million Americans unvaccinated, Infections rising in every state

http://www.healthdata.org/covid

https://www.cdc.gov/coronavirus/2019-ncov/covid-data/covidview/index.html

Current 7 day average + 40,246 per day

Up 46.75 on last week, = 27,443

Hospitalizations

Current 7-day average + 3,521 per day

Up 32% on last week

Deaths

Total, 607,684

Current 7-day average + 233 per day

Up 9.3% on last week

NYC and California, vaccinations, or weekly testing for all employees

Mask mandates spreading for vaccinated and unvaccinated

Veteran’s affairs, mandating vaccination for medical workers

Potential for 200,000 cases and 4,000 deaths per day by October

https://edition.cnn.com/2021/07/27/health/us-coronavirus-tuesday/index.html

Fauci

Worried about vaccine immune escape

Birmingham Alabama

Fully vaccinated 34%

Hospitalizations up 326% since July 1st

Last 31 samples all delta

Lower numbers than January

Younger patients than in January


Australia

https://www.theaustralian.com.au/nation/politics/coronavirus-australia-live-news-victoria-sa-to-exit-lockdown-but-no-end-in-sight-for-nsw/news-story/89daaf47902c918b13c83fadc6c8ef63?utm_source=TheAustralian&utm_medium=Email&utm_campaign=Editorial&utm_content=TA_BREAKING_CUR_04&net_sub_id=@@@@@%@@@@&type=curated&position=1&overallPos=1&utm_source=TheAustralian&utm_medium=Email&utm_campaign=Editorial&utm_content=emailname_

NSW

Cases, + 172 (60 in the community)

NT makes all NSW a hotspot

Mandatory 14-day quarantine at the Alice Springs or Howard Springs facilities

## Barbados, Special report
 - [https://www.youtube.com/watch?v=wTeE9vztyo8](https://www.youtube.com/watch?v=wTeE9vztyo8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-26 00:00:00+00:00

Thanks to Amy from Barbados, an impressive response.

## UK, Decline and Fall
 - [https://www.youtube.com/watch?v=hed0TgaprMI](https://www.youtube.com/watch?v=hed0TgaprMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-07-26 00:00:00+00:00

UK, Cases down for last 7 days

In case you want to support Our community outreach through donations

USE SENDWAVE/ WorldRemit /Western Union
Mobile money number:+256785698803
Country: Uganda
Registered name : Wefwafwa Andrew

Email me when you send: wefandrew@gmail.com

Addresses: Republic street
City: Mbale city
Country: Uganda

Direct link to full version of Community day 2 video

https://www.youtube.com/watch?v=zfBvidbS_8Y&t=544s

follow this link to watch the song in the background 👇https://youtu.be/1050TdkwQr0



Download John's two comprehensive but free educational text books using this link: http://159.69.48.3



https://ourworldindata.org/coronavirus

https://coronavirus.data.gov.uk

Monday, 26th, + 24,950

Sunday, 25th + 29,173

Saturday, 24th, + 31,795

Friday, 23rd, + 36,389

Thursday, 22nd + 39,906

Wednesday, 21st, + 44,104

Tuesday, 20th, + 46,558

Saturday, 17th + 54,674 (peak)

https://www.bbc.co.uk/news/health-57962995

First sustained drop not coincided with a national lockdown

Prof Paul Hunter, University of East Anglia

The data at present is looking good for at least the summer

Today's figures do not of course include any impact of last Monday's end of restrictions. 

It will not be until about next Friday before the data includes the impact of this change

(Netherlands and Spain, reopening of nightclubs followed by a sharp rise in infections)

Causes of decline

Football related in Scotland

Good weather

Schools summer holidays

92% of adults in the UK have antibodies


UK, 8 million adults with no vaccination

Most children under 18

Risk of immune escape

https://www.bbc.co.uk/news/health-57941574

Dr Aris Katzourakis, Viral Evolution, University of Oxford

We are probably at the evolutionary high point, at the worst combination for an escape to happen in the UK

The UK is in a prone position, whether it will happen we don't know, but it's more likely to happen here, now, than ever before

Numbers game, large scale immunity reduces viral numbers

One in 80 infected

Escape mutations would be immensely beneficial to the virus

If we compromise the incredible vaccines we have now I don't even want to contemplate what that world would look like

Delta variant, is better at causing reinfection as well as evading vaccine immunity

Beta is worst so far, but vaccines are still protecting against most hospitalisations

Viruses don't tend to be perfect at everything

US

https://covid.cdc.gov/covid-data-tracker/#trends_dailytrendscases

Vaccine uptake

https://covid.cdc.gov/covid-data-tracker/#vaccination-trends


https://www.bbc.co.uk/news/world-us-canada-57962387

Dr Anthony Fauci

US heading in the wrong direction

a pandemic among the unvaccinated

Delta variant driving spike in low vaccination areas

Considering revising mask guidance for vaccinated

Considering offering booster jabs to vulnerable people

Gain-of-function research

https://www.bbc.co.uk/news/57932699

Developing viruses that are potentially more transmissible and dangerous

To gain understanding of viral evolution

Develop better treatments and vaccines

Dr Fauci

Director of the US National Institute of Allergy and Infectious Diseases (NIAID)

Part of the US government's National Institutes of Health (NIH)

Which did give money to US-based EcoHealth Alliance

That collaborated with the Wuhan Institute of Virology

Research on possible coronaviruses from bats

2014, pulled in 2020

Dr Fauci

National Institutes of Health (NIH) has not ever and does not now fund gain-of-function research in the Wuhan Institute of Virology

Senator Rand Paul

Asked Dr Fauci this week if he wanted to retract that statement

As you are aware it is a crime to lie to Congress

Richard Ebright, Rutgers University

Research showed that new viruses were created

risked creating new potential pathogens

The research in both papers was gain-of-function research

Dr Fauci 

Research in question has been evaluated multiple times by qualified people to not fall under the gain-of-function definition

molecularly impossible for these viruses to have resulted in the coronavirus

Dr Ralph Baric, University of North Carolina
 
Work they did was reviewed by NIH and university's own biosafety committee

for potential of gain-of-function research and were deemed not to be gain-of-function

We never introduced mutations into spike to enhance growth in human cells

Rebecca Moritz, Colorado State University

There is not always consensus [on gain-of-function research] even amongst experts, and institutions interpret and apply policy differently

