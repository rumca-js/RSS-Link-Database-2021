# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The iPhone 13 Models!
 - [https://www.youtube.com/watch?v=TranVlEwQqw](https://www.youtube.com/watch?v=TranVlEwQqw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-07-27 00:00:00+00:00

Let's take a look at iPhone 13 dummy models and some updated thoughts.

The STUDIO Channel! http://youtube.com/c/TheStudio

Moment MagSafe car mount: https://www.shopmoment.com/products/car-vent-mount-for-magsafe/

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Shoutout to Sonny Dixon for the models

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

