# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## I tried to film a volcano and it was a complete disaster
 - [https://www.youtube.com/watch?v=fzfpExS_wic](https://www.youtube.com/watch?v=fzfpExS_wic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-07-26 00:00:00+00:00

Iceland has a new volcano, Fagradalsfjall: I wanted to visit, to talk about the infrastructure around it, and work out how the country deals with a new and dangerous tourist attraction. It didn't go well.

Thanks to Bjorn Steinbekk, who I thoroughly recommend if you need a fixer or drone pilot in Iceland! https://www.steinbekk.com/ He's also the person who flew a drone into the lava: https://www.youtube.com/watch?v=HmGKL19W_UM

The quote is from Sam Hughes' Ra, which is free online. I thoroughly recommend it: https://qntm.org/ra

Filmed safely: https://www.tomscott.com/safe/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

