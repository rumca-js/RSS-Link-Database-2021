# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## When the White House Censors Your Texts…
 - [https://www.youtube.com/watch?v=Ncd7YUr3nsQ](https://www.youtube.com/watch?v=Ncd7YUr3nsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-07-27 00:00:00+00:00

Grab your Blood Sugar Breakthrough at https://bloodsugarbreakthrough.health/jp20
Use Discount Code "AWJP" for a Deal

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here’s what it will look like when the White House starts censoring your texts. After the Biden administration announced it wants to work with SMS carriers to censor miss information from text messages, this is what the world will look like with increased thought police protecting you from freedom of speech on your own phone.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

