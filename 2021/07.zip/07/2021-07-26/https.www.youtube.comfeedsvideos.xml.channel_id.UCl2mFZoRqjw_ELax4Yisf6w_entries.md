# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Announcing more free soldering and troubleshooting workshops in person
 - [https://www.youtube.com/watch?v=SHK7_lSECMw](https://www.youtube.com/watch?v=SHK7_lSECMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.meetup.com/Rossmann-Group-meetup/events/279741444/?_xtd=gatlbWFpbF9jbGlja9oAJDhkMTAwM2Y3LTkxMTUtNDczNS05MzJhLTk5ZWFlNTY0MDE0MQ&utm_campaign=rsvp-confirmation&_af=event&_af_eid=279741444&utm_medium=email&utm_source=join_rsvp_info

https://www.meetup.com/Rossmann-Group-meetup/events/279741501/?_xtd=gatlbWFpbF9jbGlja9oAJGRkYzM1NDUzLTI0ZDAtNGU1ZC05ZTFhLTMwNzE0NTIyOWFiNw&utm_campaign=rsvp-confirmation&_af=event&_af_eid=279741501&utm_medium=email&utm_source=join_rsvp_info

## Let's talk about greenwashing, the giraffe, and pretending to care about the giraffe.
 - [https://www.youtube.com/watch?v=IBqSOA9wRPk](https://www.youtube.com/watch?v=IBqSOA9wRPk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-27 00:00:00+00:00

👉 Citations:
🔵 https://www.youtube.com/watch?v=JLIWDKA-1Tw
🔵 https://www.apple.com/newsroom/2020/07/apple-commits-to-be-100-percent-carbon-neutral-for-its-supply-chain-and-products-by-2030/
🔵 https://youtu.be/lTpHa70DDX0

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## What is Apple authorized repair REALLY like?
 - [https://www.youtube.com/watch?v=ANSkQ4gmEkg](https://www.youtube.com/watch?v=ANSkQ4gmEkg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 Citations:
🔵 https://www.businessinsider.com/apple-repair-workers-sweatshop-csat-solutions-2021-7
🔵 https://www.youtube.com/watch?v=ATxsy9otVzs
🔵 https://www.youtube.com/watch?v=0tywN7-0dIA
🔵 https://www.reddit.com/r/apple/comments/acqwut/do_you_know_what_happens_to_your_macbook_when_you/
🔵 https://youtu.be/OR5ZUl0Q-NI
🔵 https://youtu.be/OLRDKsd0lJM

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## A boring bike ride through a busy & bustling NYC
 - [https://www.youtube.com/watch?v=KrkUiwfWToY](https://www.youtube.com/watch?v=KrkUiwfWToY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
Stuff I recorded this with:
🔵 DJI Action 4K: https://amzn.to/3aI5dqa
🔵 DPA 4066: https://bit.ly/dpa4065 (my favorite mic)
🔵 Zoom H1n: https://amzn.to/2Y44HwF (this works amazingly well)

## Apple can't handle the truth, so they delete & bury it.
 - [https://www.youtube.com/watch?v=PQLjEhEn4Ac](https://www.youtube.com/watch?v=PQLjEhEn4Ac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 Sources & citations:
🔵 https://www.youtube.com/watch?v=neigIMBUQf0
🔵 https://www.youtube.com/watch?v=NzjoELvrkYo
🔵 https://support.apple.com/13-inch-macbook-pro-display-backlight-service
🔵 https://www.youtube.com/watch?v=oaBW9qlYcwc
🔵 https://www.youtube.com/watch?v=_b3tnN7AtkI
🔵 https://www.youtube.com/watch?v=rPfL66YBaaw
🔵 https://discussions.apple.com/thread/250461433?answerId=255609918022&fbclid=IwAR1S925zerSolCXDviFCniMyQmJBDLaQXVk1PY1qVJUqAzK5XIscYVo3p4U#255609918022
🔵 https://scontent-lga3-2.xx.fbcdn.net/v/t39.30808-6/217724407_4184332771602046_2718601697196754630_n.jpg?_nc_cat=107&ccb=1-3&_nc_sid=825194&_nc_ohc=K538HFrRn1sAX8Tf3Bx&_nc_ht=scontent-lga3-2.xx&oh=920de3df6ea71260a149e878538e4ea0&oe=6102A458

👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Clinton the cat
 - [https://www.youtube.com/watch?v=tzDp4XdwS6A](https://www.youtube.com/watch?v=tzDp4XdwS6A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-26 00:00:00+00:00

https://tinyurl.com/rossmatrix

## First free workshop went really well; thanks for coming!
 - [https://www.youtube.com/watch?v=1p44lI18omE](https://www.youtube.com/watch?v=1p44lI18omE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-07-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.meetup.com/Rossmann-Group-meetup/events/279680435/
https://www.youtube.com/watch?v=KDSosPekjjU

