# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Save The Kids - The Final Chapter
 - [https://www.youtube.com/watch?v=3Xw9rWmTQfc](https://www.youtube.com/watch?v=3Xw9rWmTQfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-07-27 00:00:00+00:00

Save the Kids was a crypto that was promoted by the top influencers in the world. 
Faze Kay, Faze Jarvis, Faze Teeqo, Faze Nikan and Ricegum all promoted the coin, along with many other popular influencers being involved.  After this story broke, Kay was kicked out of Faze along with several other members being suspended. 

Today I wanted to figure out, who was TRULY behind Save The Kids Token. Who designed Save The Kids? Who Created Save The Kids? Who changed the Anti-Whale code? Today, we get answers. 

SPECIAL THANKS TO: 
Mutahar from SomeOrdinaryGamers
Barely Sociable
@iambookz on twitter for helping teach me birdlaw

THE INVESTIGATION CONTINUES AT
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/

Coffeezilla 🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1

NOTE: This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

