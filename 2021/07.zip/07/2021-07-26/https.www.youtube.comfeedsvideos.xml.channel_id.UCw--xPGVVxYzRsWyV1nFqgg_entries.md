# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## NEW WoT COVERS!📘 Dune Comics💣 Pokemon Netflix Show🐙 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=4n2OX6GJn_E](https://www.youtube.com/watch?v=4n2OX6GJn_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-07-27 00:00:00+00:00

Let's jump into the fantasy news!!! 
BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 

00:00 Discord Update 

01:23 WoT Poster: https://twitter.com/AmazonStudios/status/1418636956448169986/photo/1  

04:49 A Twist of Fate: https://twitter.com/SubPress/status/1419643515596939273 

05:21 New World Dev Issues: https://kotaku.com/amazons-new-mmo-is-killing-some-high-end-pc-graphics-ca-1847335269 

07:30 Limited Edition Faithful and the Fallen: https://www.youtube.com/watch?v=VB3I1-BVbKk&ab_channel=TheBrokenBinding

08:00 Dune Trailer: https://www.youtube.com/watch?v=8g18jFHCLXk&ab_channel=WarnerBros.Pictures 

08:32 Dune Soundtrack: https://www.youtube.com/watch?v=AgzE2TeXCl0&ab_channel=WaterTowerMusic 

08:50 Dune Expanding: https://www.syfy.com/syfywire/dune-publishing-panel-sdcc-2021 

10:30 Blade Runner Adult Swim: https://www.youtube.com/watch?v=ahNgjVcq4sA&ab_channel=AdultSwim 

11:42 Invincible Live Action: https://screenrant.com/invincible-live-action-movie-show-differences/?utm_content=bufferc035a&utm_medium=Social-Distribution&utm_source=SR-TW&utm_campaign=SR-TW

12:44 Dragon Ball Movie: https://www.theilluminerdi.com/2021/07/23/dragon-ball-super-movie/ 

13:36 Pokemon Live Action: https://variety.com/2021/tv/news/pokemon-netflix-series-live-action-joe-henderson-1235026390/amp/?__twitter_impression=true 

14:22 Blizzard Situation (hazel nutty games): https://www.youtube.com/watch?v=UCrP8CD2AO4&t=381s&ab_channel=Hazelnuttygames

