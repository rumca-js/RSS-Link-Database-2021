# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Altin Gun - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=o9g_iyBR7xo](https://www.youtube.com/watch?v=o9g_iyBR7xo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-07-27 00:00:00+00:00

http://KEXP.ORG presents Altin Gün performing live, recorded exclusively for KEXP.

Songs:
Macka Yollari
Anlatmam Derdimi
Ordunun Dereleri
Hey Nari
Yüce Dağ Başında
Seker Oglan
Halkalı Şeker

Session recorded at Patronaat, Haarlem, The Netherlands
Audio recording by Jasper Geluk
Filmed by SUEM (Sem Lingerak, Jelle Weber and Stan de Wit)
Video edited by Jim Beckmann (KEXP)

https://atorecords.com/artists/altin-gun
https://www.patronaat.nl
https://www.suem.nl
http://www.kexp.org

