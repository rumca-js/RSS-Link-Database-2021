# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Aliens, Sci-Fi, and Christianity | The Dr. Jeff Zweerink Interview
 - [https://www.youtube.com/watch?v=beya_FHe98Q](https://www.youtube.com/watch?v=beya_FHe98Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-07-27 00:00:00+00:00

On The Babylon Bee Interview Show, Kyle and Ethan talk to Dr. Jeff Zweerink about aliens, accurate Sci-Fi movies, and being a scientist and a Christian. Dr. Jeff is a senior research scholar at Reasons To Believe. He holds a Ph.D. in Astrophysics and has debated Ken Ham on the age of the earth on the Unbelievable radio program. He struggled earlier in life with how to reconcile his biblical training and love for science. But when he first heard Hugh Ross, President & Founder of Reasons To Believe and an astrophysicist, speak at Iowa State University, Dr. Zweerink began to think he could combine science and faith together with his life’s work.

If you're hopelessly fascinated by the world of celebrity relationships, you can find Young & Holmes podcast episodes every two weeks on the podcast platform of your choice. You can also visit youngandholmes.com for more info.

Submit Your Own Headlines and Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com​​​​
Follow The Babylon Bee:
Website: https://babylonbee.com​​​​
Twitter: http://twitter.com/thebabylonbee
​​​​Facebook: http://facebook.com/thebabylonbee
​​​​Instagram: http://instagram.com/thebabylonbee​

## US Women’s Soccer Team To Boycott Scoring Goals Until Racism Is Defeated
 - [https://www.youtube.com/watch?v=dTPlDTSGUg8](https://www.youtube.com/watch?v=dTPlDTSGUg8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-07-27 00:00:00+00:00

Megan Rapinoe and the US Women’s Soccer team have made history at the Olympics by not scoring a single goal to bring awareness to racism. Brave. Stunning. And other buzz words.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## INCLUSIVE Official Trailer | The Most Representative Love Story Ever Told
 - [https://www.youtube.com/watch?v=DdUNRsyWfzo](https://www.youtube.com/watch?v=DdUNRsyWfzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-07-26 00:00:00+00:00

Check out the trailer for the more representative love story ever told: INCLUSIVE. Never in the history of film has a male lead been more representative of every race, gender, and disability. While it may not be the most original plot or even marginally good writing, INCLUSIVE is the most important movie ever made. Go see it today unless you are highly intolerant!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

