# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Richard Branson is getting out of hand
 - [https://www.youtube.com/watch?v=higGbesl05A](https://www.youtube.com/watch?v=higGbesl05A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-07-26 00:00:00+00:00

🚀 Get 2 free stocks worth up to $2,300 with Webull: https://act.webull.com/invite/share.html?inviteCode=jo7qlxQxOak8 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Watch our video on Bernard Arnault: The Ruthless Rise & Reign of The Wolf in Cashmere https://youtu.be/AO86pQ5-d_A 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✨ Follow us on TikTok: https://jake.yt/tiktok
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/3eYlwm6

-----------------------
Richard Branson was given an ultimatum. He had been crippled with dyslexia his whole life to where he could barely read by the age of 8 and was completely lost when it came to numbers. So school was a torture. And by high school, he had started his first real business: a magazine for students. Seeing him struggle, his high school headmaster called him in one day and said, you can either leave the school and run the magazine, or stay in school and leave the magazine. Richard Branson became a high school dropout.

Richard Branson was born in London in 1950. He came from a loving, happy family. Even as a kid, Branson had an entrepreneurial spirit. And although he had a natural talent for business, Branson wasn’t great in school because of his dyslexia.

Fast forward to the 60s, and the youth wanted a voice. It’s not surprising that soon after the magazine took off, Branson’s headmaster gave him that ultimatum: leave the school and run the magazine, or stay in school and leave the magazine.

As a way to make money for the magazine, Branson got the idea to sell discounted music records by mail. The business took off, but just 5 months after opening, the tax man came knocking and threw him in jail. 

While running the record store, Branson came across a guitar demo made by a 15 year old musician. Instead of letting that discourage him, he thought “screw it, let’s do it,” and created a record label just like that to record it themselves. The album's success made Richard a millionaire before his 23rd birthday.

24 year old Richard Branson was living the rockstar millionaire life. But Branson wanted to do more. And out of the blue, an insurance lawyer called him and asked Branson to back him on starting a Transatlantic Airline.

When Branson launched Virgin Atlantic, one simply didn’t just “start an airline”. Virgin Atlantic was launched with a single, used airplane leased from Boeing. But Virgin Atlantic’s biggest competitor, British Airways, wasn’t happy with this newcomer on the block. So they launched what the media would call the Dirty Tricks Campaign.

Branding is what Virgin is all about. Richard set out to embody that brand and he did everything he could think of to promote it. Some worked, some went under, but he didn’t stop expanding.

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

