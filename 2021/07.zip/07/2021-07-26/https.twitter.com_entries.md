## Tomasz Lis - obowiązkowe szczepienia
 - [https://twitter.com/lis_tomasz/status/1419667101485252610](https://twitter.com/lis_tomasz/status/1419667101485252610)
 - RSS feed: https://twitter.com
 - date published: 2021-07-26 07:43:46+00:00

Tomasz Lis - obowiązkowe szczepienia

## Tomasz Trela - Antyszczepionkowcy
 - [https://twitter.com/poselTTrela/status/1419758808906223623?s=20](https://twitter.com/poselTTrela/status/1419758808906223623?s=20)
 - RSS feed: https://twitter.com
 - date published: 2021-07-26 07:39:57+00:00

Tomasz Trela - Antyszczepionkowcy

