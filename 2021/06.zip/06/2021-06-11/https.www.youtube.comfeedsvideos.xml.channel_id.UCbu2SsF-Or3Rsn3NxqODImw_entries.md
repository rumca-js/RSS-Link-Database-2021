# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 8 Minutes Of Rainbow Six Extraction Gameplay
 - [https://www.youtube.com/watch?v=1SUV-2X7TWc](https://www.youtube.com/watch?v=1SUV-2X7TWc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Your favorite siege operators are fighting off an alien infestation! Check out 8 minutes of preview gameplay from Rainbow Six Extraction's Incursion mode.

## Assassin's Creed Valhalla Full Presentation | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=RlGOrDYycbc](https://www.youtube.com/watch?v=RlGOrDYycbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Ubisoft elaborates on Valhalla's free updates including River Raids, Master Challenges, and one handed swords. In the next major expansion, Assassin's Creed Valhalla is going to Paris in the Siege of Paris, coming summer 2021. Additionally, it's getting Discovery Tour Viking Age, with promise of more DLC to come in 2022.

## Avatar Frontiers of Pandora Reveal Trailer | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=Kt40a4PQhfQ](https://www.youtube.com/watch?v=Kt40a4PQhfQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Ubisoft gave us the first look at its long awaited Avatar game, based off of James Cameron's cinematic spectacle epic. The trailer showcased a look at the Na'vi fighting against the human militant force RDA, with airborne battles on Leonopteryxs. The game is expected to launch in 2022 on PlayStation 5, Xbox Series X|S, PC, Stadio, and Luna.

## Devolver Digital Showcase 2021 Livestream
 - [https://www.youtube.com/watch?v=7ytOy0UX_Hw](https://www.youtube.com/watch?v=7ytOy0UX_Hw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Tune into Devolver's Digital Showcase to see new games from developers Flying Wild Hog, Galvanic Games, Doinksoft and more. You'll also learn the release dates for Phantom Abyss and Death's Door.

Devolver Digital is responsible for a variety of titles in the industry including Loop Hero which had breakout success in 2021 as well as Olija and Shadow Warrior 3. Devolver Digital isn't officially part of E3 but is hosting their own Devolver Digital Showcase on the first day of E3 2021! 

#Devolver #DevolverDigital #E3

## E3 2021 Ubisoft Forward, Gearbox Showcase and More | Play For All
 - [https://www.youtube.com/watch?v=XHI0HmVrQLc](https://www.youtube.com/watch?v=XHI0HmVrQLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Tune into the first official day of E3 2021 on June 12th for the Ubisoft Forward, Gearbox Showcase, and more. Join as we learn more get exciting new trailers, announcements, gameplay and more from both showcases.

E3 is a trade event for the video game industry. The Entertainment Software Association organizes and presents E3, which many developers, publishers, hardware and accessory manufacturers use to introduce and advertise upcoming games and game-related merchandise to retailers and to members of the press.

After a brief hiatus, E3 is back and GameSpot is an official media partner here to show off all the latest games and releases from developers all over the industry. E3 Day 1 is just the beginning with Ubisoft, but stay tuned over the next 3 days as E3 will feature presentations from Bethesda, Xbox, Razer, Square Enix, Capcom Take Two, PC Gaming Show, and More! 

Ubisoft Forward 12PM PT
Gearbox Panel 2PM PT

#E32021 #E3 #Ubisoft

## Far Cry 6 Full Presentation | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=ySR4X1fFuSc](https://www.youtube.com/watch?v=ySR4X1fFuSc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Far Cry 6 features Giancarlo Esposito as Antón Castillo, and in this meet the villain trailer, we get a look at his story. Antón Castillo's son, Diego is set to succeed Antón, and we get a look at their dynamic.

In this Far Cry 6 season pass trailer, which will feature some Far Cry's most memorable villains, we get to take a look at these now playable characters in Become the Villain. Far Cry 6 Season Pass will be included with the gold edition of Far Cry 6, available for pre-order now.

## Firearms Expert Reacts To Necromunda: Hired Gun’s Guns
 - [https://www.youtube.com/watch?v=_CTGVSBS97M](https://www.youtube.com/watch?v=_CTGVSBS97M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the future weaponry of Necromunda: Hired Gun, including the franchise’s iconic Boltgun, the Ironfist Stubgun, and a rifle called the Vapanther.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down the guns of Necromunda: Hired Gun, and compares them to their real-life counterparts.

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can purchase Jonathan’s book here - https://www.headstamppublishing.com/bullpup-rifle-book

## Gearbox E3 2021 Showcase Livestream
 - [https://www.youtube.com/watch?v=QJSTFrFRBLs](https://www.youtube.com/watch?v=QJSTFrFRBLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Tune into the Gearbox E3 showcase to learn more about what the team has been working on. The Gearbox showcase will be live at 2:00pm PT.

Gearbox E3 Showcase is a part of the E3 Day 1 2021 events featuring a day full of presentations including Ubisoft's E3 2021 presentation. 

Gearbox is an American video game developer best known for the Borderlands series which just unveiled its latest installment in the franchise universe, Tiny Tina's Wonderlands. Borderlands is also being turned into a movie production.

#gearbox #e32021

## Guerrilla Collective Day 2 & Wholesome Direct
 - [https://www.youtube.com/watch?v=s_4OxLdZBWY](https://www.youtube.com/watch?v=s_4OxLdZBWY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Tune into the 2nd day of the Guerrilla collective showcasing new announcements, trailers, gameplay and more. Stick around as well for the Wholesome direct which will feature over 75 indie games.

Guerrilla Collective is a digital games festival to reveal fresh announcements, trailers, gameplay, and more, bringing together some of the hottest developers and publishers around the world! This is the 2nd annual Guerrilla Collective featuring a variety of up and coming indie games and presentations. 

#GuerillaCollective #E32021 #Guerilla

## Mario + Rabbids: Sparks Of Hope Cinematic Trailer | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=diaZyka9GDA](https://www.youtube.com/watch?v=diaZyka9GDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

The tactical turn-based role-playing game that bridges together Mario and Rayman's Rabbids is back with Sparks of Hope. The trailer featured Mario dual wielding two guns alongside a Prince Peach Rabbid, Luigi, and more, facing against a new intergalactic foe. Coming to Nintendo Switch.

## Mario + Rabbids: Sparks Of Hope Full Presentation | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=BrzH5h_SSrE](https://www.youtube.com/watch?v=BrzH5h_SSrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Mario + Rabbids: Sparks Of Hope brings the two unlikely universes together through a new journey across galaxies. The sequel to the popular tactical turn-based RPG introduces new foes, and Sparks, which will aid Mario and his friends. Coming to the Nintendo Switch.

## Mario + Rabbids: Sparks Of Hope Gameplay Trailer | Ubisoft Forward E3 2021
 - [https://www.youtube.com/watch?v=jjrPUjiMKYw](https://www.youtube.com/watch?v=jjrPUjiMKYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Ubisoft revealed a first look at the gameplay of Mario + Rabbids: Sparks of Hope in this trailer. This crossover between Nintendo and Ubisoft's Rayman characters and take on XCom will have brand new maps and a new story. We saw the characters in a vibrant beach stage, with all new enemies. Mario + Rabbids: Sparks of Hope will be releasing sometime in 2022.

## Rainbow Six Extraction - Aliens In The Siege Ecosystem
 - [https://www.youtube.com/watch?v=M1RctJS0bR8](https://www.youtube.com/watch?v=M1RctJS0bR8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Rainbow Six Extraction is a standalone game that picks up where Siege’s Outbreak limited-time event left off with aliens invading the world.  We’re looking at how it’s grown from Outbreak and what might set it apart from Siege.

Rainbow Six Extraction is a standalone co-op game pitting 1-3 Siege Operators against an Alien infestation. The game picks up the storyline directly from the New Mexico event and greatly expands on the alien menace with evolved enemy types, randomly chosen objectives, operator rescues, specialized gear, and a persistent health system. 

In this video, we’re going to cover what it's like playing the Alaska map on Incursion mode, which involves three submaps with escalating difficulty and rewards. Players can extract at any time but, by progressing further, can earn more XP and unlock React tech used to fight the Aliens. Players who go down are captured and must be rescued in-game. You’ll see a select roster from the base game, including Doc, Pulse, Ella, Alibi, Hibana, Lion, Vigil, Sledge, Pulse, Ela, and Finka. Their gear works very similar to Siege but, in some cases, is more effective versus aliens than humans in PvP. 

Several of the objectives require coordinated teamwork like Triangulation where you need to turn on laptops in a specific order and rescue where you pull a VIP out of a goo pillar while your team shoots tentacles. 

Rainbow Six Extraction is in development with no current release date.

## Rainbow Six Extraction Cinematic Trailer | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=pONh29XLl44](https://www.youtube.com/watch?v=pONh29XLl44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

In this new cinematic trailer for Rainbow Six Extraction, operators Lion, Ela, and Nomad infiltrate a music venue in San Francisco, where they fight off hordes of alien sentient-like creatures. Rainbow Six Extraction is a PVE, 3 player co-op take on the popular tactical FPS Rainbow Six Siege. The game is expected to release September 16, 2021.

## Rainbow Six Extraction Full Presentation | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=AUYZeiXWbM8](https://www.youtube.com/watch?v=AUYZeiXWbM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

In this new cinematic trailer for Rainbow Six Extraction, operators Lion, Ela, and Nomad infiltrate a music venue in San Francisco, where they fight off hordes of alien-like creatures. Rainbow Six Extraction is a PVE, 3 player co-op take on the popular tactical FPS Rainbow Six Siege. In this presentation shown during the 2021 Ubisoft Forward, developers breakdown the games enemies, new gear, and co-op mechanics. The game is expected to release September 16, 2021.

## Rainbow Six Extraction Gameplay Trailer | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=KVjoiGFjwow](https://www.youtube.com/watch?v=KVjoiGFjwow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

In this new gameplay trailer for Rainbow Six Extraction, Ubisoft takes us to the Orpheus Research Center in Alaska. Operators Ela, Alibi, and Sledge utilize their operator abilities to face off a nest of Archæons. The Rainbow Six operators utilize stealth and cooperative tactics to defeat the alien infestation. The game is expected to release September 16, 2021.

## Rainbow Six Extraction Reveal Trailer--Everything You Missed
 - [https://www.youtube.com/watch?v=5P9THlqepF8](https://www.youtube.com/watch?v=5P9THlqepF8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

(Presented by Ubisoft) Persia and Kurt react to the Rainbow Six Extraction trailer from the Ubi Forward Event during E3. Check out their thoughts as well as every Rainbow Six easter egg, gameplay tease, and detail they caught!

## Rainbow Six Siege North Star Story Trailer | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=20osGfiaFVs](https://www.youtube.com/watch?v=20osGfiaFVs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Thunderbird is joining Team Rainbow for North Star which starts next week. Tom Clancy's Rainbow Six Siege first released in 2015. Rainbow Six Siege continues with new seasons and June 30 crossplay between PC, Stadia, and Luna. Early 2022, crossplay will be available between Xbox and Playstation.

## Riders Republic Trailer | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=tasjYid5Yec](https://www.youtube.com/watch?v=tasjYid5Yec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Riders Republic is a massive multiplayer extreme sports game featuring mountain biking, snowboarding, paragliding, and... jetpacks? Take to the outdoors to explore areas of the United States doing extreme stunts along the way.

## Rocksmith+ Full Presentation | Ubisoft Forward 2021 | E3 2021
 - [https://www.youtube.com/watch?v=7mgGOOhfR6s](https://www.youtube.com/watch?v=7mgGOOhfR6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Rocksmith+ revealed all new details, showcasing that both acoustic and electric guitar players can utilize this subscription service. Both chords and note for note arrangements are included in Rocksmith+, as well as a workshop where users can create their own arrangements. A diverse library of multiple genres of music will be included in Rocksmith+.

## Tiny Tina's Wonderlands Full Presentation | Gearbox E3 2021
 - [https://www.youtube.com/watch?v=gUmZEFjmPlk](https://www.youtube.com/watch?v=gUmZEFjmPlk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

In this video, the developers elaborate on its new looter shooter Borderlands spinoff, Wonderlands.

## Ubisoft Forward E3 2021 Best Trailers
 - [https://www.youtube.com/watch?v=7WQjv-ngaK8](https://www.youtube.com/watch?v=7WQjv-ngaK8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

We round up the most exciting trailers from Ubisoft Forward.

We round up the most exciting trailers from Ubisoft Forward, featuring  Mario + Rabbids Sparks of Hope, Far Cry 6, Avatar: Frontiers of Pandora, and Rainbox Six Extraction.

00:03 - Mario + Rabbids Sparks of Hope (Cinematic World Premiere Trailer)
02:58 - Avatar: Frontiers of Pandora – First Look Trailer
05:40 - Far Cry 6 (Meet the Villain: Antón Cinematic)
09:26 - Rainbow Six Extraction (Cinematic Reveal Trailer)
13:02 - Far Cry 6 (Season Pass Trailer -Become The Villain)

## Ubisoft Forward E3 2021 Livestream
 - [https://www.youtube.com/watch?v=Vff3GtPumj8](https://www.youtube.com/watch?v=Vff3GtPumj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-12 00:00:00+00:00

Tune into Ubisoft Forward to learn more about Far Cry 6, Riders Republic, and Rainbow Six Extraction. Get updates on Assassin's Creed Valhalla, Rainbow Six Sieges upcoming event, and more on Mythic Quest, the soon to released movie Werewolves Within, and more. Ubisoft Forward is a part of E3 2021! E3 is one of the largest, if not biggest events in the games industry showcasing games and announcements across a multitude of developers, genres, and platforms. 

Ubisoft Entertainment is a French video game company headquartered in Paris with several development studios across the world. Its video game franchises include Rayman, Rabbids, Prince of Persia, Assassin's Creed, Far Cry, Watch Dogs, Just Dance, and the Tom Clancy's series.

#Ubisoft #E3 #E32021

## 12 Minutes Presentation | Tribeca Games Spotlight 2021
 - [https://www.youtube.com/watch?v=5CoK_7AMq5c](https://www.youtube.com/watch?v=5CoK_7AMq5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

12 Minutes is an interactive thriller about a man trapped inside a time loop. At the end of every loop, the main character's wife will be murdered. It's the player's objective to break the loop, by repeating it over and over. 12 Minutes stars Star Wars' Daisy Ridley, Xmen's James McAvoy, and Willem Dafoe.

## Elden Ring Gameplay Trailer Breakdown
 - [https://www.youtube.com/watch?v=NuhylvBFIfU](https://www.youtube.com/watch?v=NuhylvBFIfU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

After 2 years of waiting, FromSoftware has finally released a gameplay trailer for their upcoming game, Elden Ring. Dave breaks down the trailer and relates what about Elden Ring seems to pull from Dark Souls, Bloodborne, and Sekiro respectively. FromSoftware's much anticipated Elden Ring has a release date of January 21, 2022.

## Final Form Reveal Trailer | Koch Media Primetime 2021
 - [https://www.youtube.com/watch?v=P1FEOsAURic](https://www.youtube.com/watch?v=P1FEOsAURic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

In Final Form, you take the role of a sentient female machine in this Sci Fi Adventure FPS game developed by Reikon for Prime Matter. As you have a robotic body, you will have various cybernetic enhancements.

## Kena: Bridge Of Spirits Presentation | Tribeca Games Spotlight 2021
 - [https://www.youtube.com/watch?v=jppkGthLvk8](https://www.youtube.com/watch?v=jppkGthLvk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

The developers at Ember Labs speak on their background in Hollywood animation, and the influence of playing action adventure games growing up, and how that's impacted the direction of Kena: Bridge Of Spirits. In this featurette during the Tribeca Game Spotlight, they elaborate on the game's score, and cinematic quality.

## Kena: Bridge Of Spirits Preview
 - [https://www.youtube.com/watch?v=rfZZ8tas9BA](https://www.youtube.com/watch?v=rfZZ8tas9BA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

We spent about an hour playing Ember Lab's first game, spending some time learning its fast-paced combat, exploring the world, and becoming best friends with the Rot.

Action-adventure game Kena: Bridge of Spirits mixes a bunch of inspirations, from the combat of The Legend of Zelda to the storytelling sensibilities of Akira Kurosawa's Rashomon. We recently got a chance to play about an hour of Ember Lab's new title, and came away struck by how well it balances its ideas, and just how cute its little black mascots, the Rot, really are.

Protagonist Kena is a spirit guide, and hergoal throughout the game is to discover what happened to a village where a calamity has taken place. Corruption infects the land around the village and the spirits of some of its inhabitants are trapped, unable to move on, and becoming corrupted, too. In our playthrough, we went in search of a spirit named Taro, searching for relics to uncover his memories, learn what happened to him, and finally, summon him to help him cross over.

The Rot, the little black creatures who follow you around, are a big part of the gameplay experience. You find them in the world, and the more you have, the more powerful they become. You can use them to solve puzzles, move objects to clear paths, and repair shrines and statues to help restore the village and its surroundings. But the Rot also help you fight, attacking and distracting enemies and powering up your attacks. The Rot are your constant companions, and represent how Ember Lab is looking to tell Kena's story through gameplay and the connections you make with characters, both friendly and not-so-friendly, along the way.

Kena: Bridge of Spirits is headed to PlayStation 4, PlayStation 5, and PC this August.

#Kena #KenaBridgeOfSpirits #PS5

## Koch Primetime E3 2021 Livestream
 - [https://www.youtube.com/watch?v=O7eNmlVJnow](https://www.youtube.com/watch?v=O7eNmlVJnow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

Tune in to Koch Media's showcase for game updates, trailers, announcements and more. Koch Media revealed a brand new publishing label today Prime Matter. They showcased over 10 upcoming titles including Payday 3, Gungrave: G.O.R.E., Encased, The Last Oricru, King's Bounty 2, Crossfire Legion, The Chant, Codename Final Form, Dolmen, Project: Echoes of the End, and Painkiller. Let's see if we find out more information about any of the above during tomorrows showcase.

#kochprimetime #e32021

## Netflix Geeked Week Livestream
 - [https://www.youtube.com/watch?v=oGQE1LQ_hMM](https://www.youtube.com/watch?v=oGQE1LQ_hMM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

Netflix is closing out Geeked Week with new titles from the games you love. Come hang out for GameSpot's pre-show and post-show and tune in for news, exclusive trailers, game announcements, and much more.

#netflix #geekedweek2021

## Tribeca Games Spotlight Digital Showcase Live
 - [https://www.youtube.com/watch?v=7g9qrmEGcaU](https://www.youtube.com/watch?v=7g9qrmEGcaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-11 00:00:00+00:00

Tune into the Tribeca Games Spotlight for creator interviews, appearances by special guests, and exclusive gameplay from the 8 official selections. The 8 selections include: Harold Halibut, Kena Bridge of Spirits, Lost In Random, Norco, Sable, Signalis, The Big Con, and Twelve Minutes.

#tribecagamesspotlight

