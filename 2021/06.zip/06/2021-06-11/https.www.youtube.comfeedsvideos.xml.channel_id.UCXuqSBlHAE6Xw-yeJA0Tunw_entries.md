# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Turn your Outdated Computer into a Monitor! - Luna Display
 - [https://www.youtube.com/watch?v=u4bGGtnc6Ds](https://www.youtube.com/watch?v=u4bGGtnc6Ds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-12 00:00:00+00:00

Learn more about CleanMyMac X: http://bit.ly/cleanmymac-LLT
Download a free trial: http://bit.ly/download-cleanmymac-LLT

Add Honey for FREE and start saving today at https://joinhoney.com/ltt
Thanks, Honey for sponsoring!

been a thing since 2014. Enter Luna Display, a dongle that hopes to fix that – But is it really better than AirPlay?

Check out the Astropad Luna Display at https://lmg.gg/JPmIr

Buy Apple iPad Pro
On Amazon (PAID LINK): https://geni.us/x0ud3
On Best Buy (PAID LINK): https://geni.us/GDIa
On Newegg (PAID LINK): https://geni.us/QKSXc

Buy Apple iMac 2021
On Amazon (PAID LINK): https://geni.us/iF2g
On Best Buy (PAID LINK): https://geni.us/tDFBtw
On Newegg (PAID LINK): https://geni.us/MJ7CiJ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1346878-dont-junk-your-outdated-computer/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 - Intro
0:47 - Honey! Sponsor
1:07 - What is Luna?
2:44 - Performance Testing and comparison to Sidecar
4:45 - Using Luna on an Intel-based Mac thoughts
5:29 - Luna's usefulness going forward
5:56 - Why Apple got rid of Target Display mode
7:16 - Why Luna Display is good after WWDC 2021
8:09 - Luna Display for PC
8:36 - Clean my Mac! Sponsor
9:17 - Outro

## Sharing our Own Troubling Experience - WAN Show Jun 11, 2021
 - [https://www.youtube.com/watch?v=D10gTfBLrwg](https://www.youtube.com/watch?v=D10gTfBLrwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-11 00:00:00+00:00

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Buy a Seasonic Ultra Titanium PSU
On Amazon: https://geni.us/q4lnefC
On NewEgg: https://lmg.gg/8KV3S

Learn more about MSI's CLUTCH GM41 Lightweight Wireless Gaming Mouse at https://lmg.gg/gm41
Buy on Amazon at (PAID LINK): https://geni.us/8RPQ

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Sharing-our-Own-Troubling-Experience---WAN-Show-Jun-11--2021-e12oijv

Check out Other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Timmy Fox)
00:00:33 – Topics overview
– 00:01:22 – Bad pun
------------------------------------------------
00:01:39 – Intro
– 00:02:00 – Sponsor overview
00:02:11 – HardwareUnboxed...except not
------------------------------------------------
00:03:40 – HardwareUnboxed's LG review drama
– 00:04:00 – LG CNS tangent
– – 00:06:10 – Possible benefits of the company split
– 00:07:13 – Last minute release embargo (Main topic introduction)
– – 00:07:35 – Intel embargo email
– – 00:08:11 – It is not usual to add embargos after reviewing the product
– – 00:09:48 – HardwareUnboxed never agreed to any embargo
– – 00:10:17 – HardwareUnboxed's review was very positive
– – 00:10:55 – LG reaching out
– 00:11:07 – Remembering Youtube annotations
– 00:12:00 – HardwareUnboxed's response
– 00:12:44 – LG's further imposed embargos
– 00:14:35 – Who is LG CNS...?
– 00:15:57 – Buzzword Bingo
– 00:16:41 – LG's response
– 00:18:17 – Linus' thoughts
– – 00:18:47 – Trying to find a document
– – 00:19:18 – Linus' actual point
– – 00:21:08 – Can you imagine that?!
– – 00:24:30 – In the context of the global silicon shortage
– – 00:25:08 – Shoutout to Jarrod's tech
– 00:25:42 – Back to LG's guidelines
– 00:28:32 – The problem (possible reasons and LG's intentions)
– 00:29:47 – Moving on even further (rest of the email)
– – 00:30:37 – A review cannot be a paid review
– 00:31:17 – LG kept digging
– 00:32:27 – LG made a 180
– – 00:32:54 – What Linus wants to know
– 00:34:13 – Summary and things to keep in mind
– – 00:35:26 – Where companies run into problems
– – 00:36:07 – Sponsored content when the product is included
– – 00:37:58 – Luke weighing in
– 00:38:54 – The most ridiculous thing about this
– 00:40:34 – HardwareUnboxed did the right thing
------------------------------------------------
00:41:19 – WWDC discussion
– 00:42:09 – Colin's comment
– 00:42:48 – Linus' Uncle's story
– 00:43:39 – Lack of T9 dialing
– 00:45:49 – What drives Linus crazy
– 00:46:44 – How Luke gets paid
– 00:47:28 – Facetime
– 00:49:27 – Value of getting kids using your tech
– 00:50:18 – Linus needs to buy a Chromebook
------------------------------------------------
00:53:17 – Sponsors
– 00:53:27 – MSI
– 00:54:00 – Seasonic
– 00:54:30 – Squarespace
------------------------------------------------
00:55:10 – LTT Sad Linus sequin pillow launch (New merch)
– Large CPU pillows back in stock (00:57:38)
------------------------------------------------
00:57:15 – Tesla Model S Plaid / Games in a Tesla (First public Navi 23 demo)
– 00:57:38 – Tangent: Large CPU pillows back in stock
– 00:58:38 – Back on topic
– 01:00:10 – Compared to Android Auto (why Tesla does it better)
– 01:02:20 – Tesla's claims
– 01:03:37 – Would you game on this?
– 01:04:58 – Luke's screen complaints
– 01:06:09 – Linus' alternate take
– 01:06:33 – Further thoughts (Linus not being the customer for this)
– 01:09:30 – Discussion about how expensive it is
------------------------------------------------
01:14:30 – Windows 10 being retired
------------------------------------------------
01:15:58 – El Salvador adopting Bitcoin
------------------------------------------------
01:17:38 – Superchats
– 01:17:52 – Hoodie
– 01:18:11 – LG comment
– 01:18:20 – T9 dialing
– 01:18:48 – Having to buy a Galaxy Tab
– 01:19:01 – Google Workspace
– 01:19:45 – GPU stock scanbot listings tweet
– 01:20:00 – LTT socks
------------------------------------------------
01:20:43 – Update on 3080 & 3080 TI prices equalizing (Checking eBay prices)
– 01:23:54 – Repeating what was said in the reviews
– 01:24:19 – Linus' question
– 01:24:59 – Linus never said it's a good value
– 01:25:20 – Linus' question (cont.)
– 01:27:57 – Would you rather market or manufacturer setting the price?
------------------------------------------------
01:28:23 – Closing comments and extra superchats
– 01:28:47 – LGBT comments
– 01:29:51 – "Bye" + Outro
– 01:30:14 – One more thing
– 01:31:01 – "Bye" x2

