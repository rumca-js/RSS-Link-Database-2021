## What Happens When Hedge Funds Buy Up Neighborhoods
 - [https://thefederalist.com/2021/06/11/what-happens-when-hedge-funds-buy-up-neighborhoods/](https://thefederalist.com/2021/06/11/what-happens-when-hedge-funds-buy-up-neighborhoods/)
 - RSS feed: https://thefederalist.com
 - date published: 2021-06-11 10:43:20+00:00

What Happens When Hedge Funds Buy Up Neighborhoods

