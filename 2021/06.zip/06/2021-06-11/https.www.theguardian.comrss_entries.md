# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Rukmini Iyer’s trio of summer salads: chicken, butter beans and feta
 - [https://www.theguardian.com/feasting-with-ocado/2021/jun/11/rukmini-iyers-trio-of-summer-salads-chicken-butter-beans-and-feta](https://www.theguardian.com/feasting-with-ocado/2021/jun/11/rukmini-iyers-trio-of-summer-salads-chicken-butter-beans-and-feta)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2021-06-11 10:51:39+00:00

<p>The Roasting Tin author on three ways to add colour and crunch to your summer feasting table</p><p>These recipes highlight that a few good ingredients need little more than a simple dressing to shine.</p><p>In all three, the star ingredient – from my favourite Navarrico jarred butter beans to free-range chicken and good feta cheese – has a short stint marinating in a herby lemon and olive oil dressing before stirring it through with a handful of complementary ingredients.</p><p>Roast chicken with grapefruit, watercress and hazelnuts</p> <a href="https://www.theguardian.com/feasting-with-ocado/2021/jun/11/rukmini-iyers-trio-of-summer-salads-chicken-butter-beans-and-feta">Continue reading...</a>

