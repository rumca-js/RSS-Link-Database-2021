# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## The Most Boring Dystopia: 1999 Microsoft 'Home of the Future'
 - [https://www.youtube.com/watch?v=31GQ6ybnzMo](https://www.youtube.com/watch?v=31GQ6ybnzMo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2021-06-12 00:00:00+00:00

Homes are cool. I don’t have one though. I live in an apartment. I imagine if I had one it would be nice. But alas.

Here’s what people in the past thought about homes in the future. They were pretty…..pretty…pretty close.

New Channel: https://www.youtube.com/c/Whimsu
Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
secret: https://www.youtube.com/channel/UC-KL...
Spotify: https://open.spotify.com/artist/3STpe...

Additional Credits
Windows Expert

