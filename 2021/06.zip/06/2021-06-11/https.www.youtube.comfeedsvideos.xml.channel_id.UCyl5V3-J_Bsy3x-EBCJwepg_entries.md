# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Saving Abuela and Deliverance from Evil
 - [https://www.youtube.com/watch?v=9D4QNdBn6OI](https://www.youtube.com/watch?v=9D4QNdBn6OI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-06-11 00:00:00+00:00

On this episode of The Bee Weekly, Kyle and Ethan are joined by Andrew Lowen to talk about his new board game set in the battle between angels and demons, Deliverance (https://www.kickstarter.com/projects/lowenhigh/deliverance-board-game?ref=bmakbh). They also talk about noble efforts to help AOC’s Abuela and The Babylon Bee going up against The New York Times. Afterwards Andrew shares his creative process for creating Deliverance and how this game is unlike most Christian games in that it is not terrible.


Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com​​​​

Follow The Babylon Bee:
Website: https://babylonbee.com​​​​
Twitter: http://twitter.com/thebabylonbee​​​​
Facebook: http://facebook.com/thebabylonbee​​​​
Instagram: http://instagram.com/thebabylonbee​

