# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Ratchet & Clank: Rift Apart - Before You Buy
 - [https://www.youtube.com/watch?v=R3cVCikK5Es](https://www.youtube.com/watch?v=R3cVCikK5Es)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-12 00:00:00+00:00

Ratchet & Clank: Rift Apart (PS5) marks the return of a beloved franchise. How does this PS5 shake up? Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?su...

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## Elden Ring - Things You MISSED In The Gameplay Trailer (4K)
 - [https://www.youtube.com/watch?v=jb_X5q0qv5w](https://www.youtube.com/watch?v=jb_X5q0qv5w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-11 00:00:00+00:00

Elden Ring. (PC, PS5, PS4, Xbox Series X/S/One) finally has a release date and a nice new trailer filled with details we want to discuss.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## NEW XBOX SERIES HARDWARE SOON? ELDEN RING, EA HACKED, & MORE
 - [https://www.youtube.com/watch?v=l80qsBhnZQ8](https://www.youtube.com/watch?v=l80qsBhnZQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-11 00:00:00+00:00

Go to https://www.expressvpn.com/gameranx and find out how you can get 3 months of ExpressVPN free!

More Xbox console and streaming news, Elden Ring is finally revealed at Summer Games Fest, EA falls victim to a massive hack, Battlefield 2042 ditches story campaign, and more in a week filled with gaming news from E3 2021 and beyond.

Subscribe for more: https://www.youtube.com/gameranxTV?su...


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake’s other channel:
https://youtu.be/DKtOpOsT1nI



 ~~~~STORIES~~~~



Xbox news
https://www.gamespot.com/articles/xbox-will-be-built-into-tvs-xbox-branded-streaming-devices-announced/1100-6492606/
+ https://in.ign.com/xbox-series-s/160132/news/xbox-says-its-working-on-new-hardware-and-insists-consoles-are-its-flagship-experience


Summer Game Fest (everything announced)https://www.digitaltrends.com/gaming/everything-announced-at-summer-game-fest/
Elden Ring, Tiny Tina’s Wonderlands, and more


Netflix reveals Witcher, Splinter Cell tease, Cuphead show, and more:https://www.pcgamer.com/all-the-videogame-shows-announced-during-netflixs-geeked-week/


EA hacked
https://www.bbc.com/news/technology-57431987


Battlefield 2042
(No campaign, high price yikes)
https://youtu.be/ASzOzrB-a9E

Small Far Cry 6 update
https://www.gameinformer.com/2021/06/04/far-cry-6-will-offer-a-third-person-mode-throughout-the-game



Launch trailer for Ratchet and Clank
https://youtu.be/55PRv_e00wc

Chivalry 2
https://youtu.be/VJMFuN_xaL0

Fallen Order updated
https://www.ea.com/games/starwars/jedi-fallen-order/news/next-gen-release-details

Control free on Epic
https://twitter.com/EpicGames/status/1403004157208842260



***E3 schedule here:

https://www.gamesindustry.biz/articles/2021-06-10-e3-2021-and-summer-games-fest-full-schedule-and-showtimes

