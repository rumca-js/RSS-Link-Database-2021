# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## The Ruthless Rise of The Wolf in Cashmere
 - [https://www.youtube.com/watch?v=AO86pQ5-d_A](https://www.youtube.com/watch?v=AO86pQ5-d_A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-06-11 00:00:00+00:00

📹 Get unlimited stock video, photos, music, & more at http://storyblocks.com/jaketran

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Alex Becker - I Spent Millions On Garbage https://youtu.be/8XGLiV_QVHM
How to Become a Big Tech Billionaire https://youtu.be/4jz1JIjFEVo
@TeddyBaldassarre (where I bought my watch): https://www.teddybaldassarre.com/ 

💸 Win $1,000! https://jake.yt/1000 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✨ Follow us on TikTok: https://jake.yt/tiktok
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG: @jaketran.io // http://bit.ly/jt-ig
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/3gqOATb

-----------------------
When you look at the Forbes Billionaires list, almost all the men you see made their money in tech: Jeff Bezos with Amazon, Elon with Tesla, Gates with Microsoft, Zuckerberg with Facebook, Ellison with Oracle, and Page and Brin with Google and then you have a man named Bernard Arnault, at #2 with around $170 billion dollars, trailing right behind Jeff Bezos and in front of Elon Musk, and often trading places with them. 

Bernard made his billions in the world of luxury: everything from fashion, leather goods, jewelry, and high-end spirits. He’s the man behind the parent company that owns some of the biggest names in luxury: Louis Vuitton, Dior, Celine, Hennessy, Tiffany & Co, Tag Heuer, Hublot, Sephora, and many more.

The world is ran by smart people. If you look at the totem pole of society, it’s just smart people on top of smart people trying to convince other people to do what they want them to do. When you’re poor, you are owned by smart people: like your boss. But then, some people are able to make it out of that poor phase into the freedom phase where you’re making around $100k a year or more on your own. At this point, smart people can no longer get at you - but they still really want to because we're naturally power hungry creatures. So in order for smart people to convince successful people to do what they want them to do, you have to lure them in with something else. And that something else is luxury goods.

Bernard grew up as the son of a father that owned a manufacturing/civil engineering company in France. According to Bernard, his mom made two major contributions to his life: one, she made him take piano lessons and two, she had a fascination with the perfume and fashion brand Christian Dior. His father was the one that really gave him a sense of business, and by age 25, he took over the reigns of his dad’s company, with the ambitions to start his own empire.

-----------------------

No Spirit - Reliving https://chll.to/d61278d4 

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

