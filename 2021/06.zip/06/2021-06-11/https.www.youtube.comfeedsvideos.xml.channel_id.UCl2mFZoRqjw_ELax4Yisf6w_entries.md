# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Florida is a beautiful, scary, but AWESOME place. Meet my new friend!
 - [https://www.youtube.com/watch?v=Ognsk4fjnmo](https://www.youtube.com/watch?v=Ognsk4fjnmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-06-11 00:00:00+00:00

https://tinyurl.com/rossmatrix

## Right to Repair bill PASSES in NY state senate! What now?
 - [https://www.youtube.com/watch?v=FX6BVQe6Tq4](https://www.youtube.com/watch?v=FX6BVQe6Tq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-06-11 00:00:00+00:00



