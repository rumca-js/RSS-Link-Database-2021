# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## New Trump scandal shows the depth of his assault on American democracy
 - [https://www.cnn.com/collections/trump-doj-intl-061121/](https://www.cnn.com/collections/trump-doj-intl-061121/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 23:30:51+00:00



## This skateboard club is helping plus-size riders push body positivity forward
 - [https://www.cnn.com/2021/06/11/health/human-factor-andy-duran-chub-rollz-overweight-skate-club-wellness/index.html](https://www.cnn.com/2021/06/11/health/human-factor-andy-duran-chub-rollz-overweight-skate-club-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 23:18:18+00:00

Windows down, music up.

## This is how internet sleuths are hunting down insurrectionists
 - [https://www.cnn.com/videos/politics/2021/06/11/internet-sleuths-insurrection-murray-dnt-lead-vpx.cnn](https://www.cnn.com/videos/politics/2021/06/11/internet-sleuths-insurrection-murray-dnt-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 23:13:30+00:00

Some Internet users are joining together to hunt down the identities of insurrectionists who stormed the Capitol on January 6, 2021.

## Djokovic: 'My greatest ever match in Paris'
 - [https://www.cnn.com/2021/06/11/tennis/novak-djokovic-rafael-nadal-french-open-spt-intl/index.html](https://www.cnn.com/2021/06/11/tennis/novak-djokovic-rafael-nadal-french-open-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 22:31:50+00:00

Novak Djokovic dethroned Rafael Nadal in an all-time classic encounter to reach the French Open final, winning 3-6 6-3 7-6 6-2 in a match that lasted more than four hours.

## Italy delivers dominant performance in Euro 2020 opener
 - [https://www.cnn.com/2021/06/11/football/turkey-italy-euro-2020-opening-game-spt-intl/index.html](https://www.cnn.com/2021/06/11/football/turkey-italy-euro-2020-opening-game-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 21:56:24+00:00

Italy laid down an early marker on the opening night of Euro 2020 with a dominant 3-0 victory over Turkey.

## Alicia Silverstone let's us know we've been saying her name wrong this whole time
 - [https://www.cnn.com/2021/06/11/entertainment/alicia-silverstone-name-wrong/index.html](https://www.cnn.com/2021/06/11/entertainment/alicia-silverstone-name-wrong/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 21:48:30+00:00

Shout-out to TikTok for giving Alicia Silverstone a safe space to check us on being "Clueless" about her name.

## Analysis: The depth of Trump's abuse of power
 - [https://www.cnn.com/2021/06/11/politics/trump-justice-department-democrats/index.html](https://www.cnn.com/2021/06/11/politics/trump-justice-department-democrats/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 20:04:13+00:00

New revelations suggesting that the Trump administration abused Justice Department powers to target his political enemies underscore just how far the ex-President went to destroy cherished principles of American republican government.

## Volkswagen hacked as 3 million customers have their information stolen
 - [https://www.cnn.com/2021/06/11/cars/vw-audi-hack-customer-information/index.html](https://www.cnn.com/2021/06/11/cars/vw-audi-hack-customer-information/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 19:16:48+00:00

Volkswagen and Audi, VW's luxury brand, have been hit by a data breach that exposed the contact information and, in some cases, personal details, like driver license numbers, of customers in the United States and Canada.

## Car prices have soared, and it's not over yet
 - [https://www.cnn.com/2021/06/11/business/car-prices-record-high-short-supply/index.html](https://www.cnn.com/2021/06/11/business/car-prices-record-high-short-supply/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 19:05:36+00:00

Car dealer lots have only a fraction of the vehicles — both new and used — that they typically have. That's helping send prices to record levels and lifting the nation's overall inflation rate.

## China may not be a member of the G7, but it's dominating the agenda
 - [https://www.cnn.com/collections/intl-g7-boris-biden-061021/](https://www.cnn.com/collections/intl-g7-boris-biden-061021/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 17:16:30+00:00



## American Airlines and Virgin Atlantic order electric air taxis from UK startup
 - [https://www.cnn.com/2021/06/11/business/vertical-aerospace-evtol/index.html](https://www.cnn.com/2021/06/11/business/vertical-aerospace-evtol/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 16:17:23+00:00

Vertical Aerospace, a UK electric aircraft manufacturer, has won the backing of American Airlines, Virgin Atlantic and Microsoft in its bid to make urban air travel a reality.

## Young Ugandans suffer most in second wave as country grapples with severe vaccine shortages
 - [https://www.cnn.com/2021/06/11/africa/uganda-vaccines-second-wave-cmd-intl/index.html](https://www.cnn.com/2021/06/11/africa/uganda-vaccines-second-wave-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 15:45:33+00:00

Three men wearing white hazmat suits carry a dark blue body bag into the back of an ambulance parked next to a soccer field in Uganda's main stadium -- the latest victim of the virulent second wave of Covid-19 that has hit the East African country.

## Norway to proceed with sound experiment on whales, despite protests
 - [https://www.cnn.com/2021/06/11/europe/norway-whale-test-intl-scli-scn/index.html](https://www.cnn.com/2021/06/11/europe/norway-whale-test-intl-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 15:19:32+00:00

A group of international scientists has called on Norway to halt plans for acoustic experiments on minke whales.

## How does inflation affect my standard of living?
 - [https://www.cnn.com/2021/06/11/success/inflation-calculator/index.html](https://www.cnn.com/2021/06/11/success/inflation-calculator/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 14:56:50+00:00

Use this calculator to determine the impact inflation may have on your standard of living, and what your living expenses might cost you in the future.

## Giant blinking star near center of Milky Way
 - [https://www.cnn.com/2021/06/11/world/blinking-star-milky-way-scn/index.html](https://www.cnn.com/2021/06/11/world/blinking-star-milky-way-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 14:56:39+00:00

A giant star is blinking near the center of our Milky Way galaxy like a stellar beacon, according to new observations by astronomers. The star is located more than 25,000 light-years away from Earth.

## 'Jessica, we are live': Excruciating on-air gaffe goes viral
 - [https://www.cnn.com/2021/06/11/africa/namibia-newsreader-gaffe-scli-intl/index.html](https://www.cnn.com/2021/06/11/africa/namibia-newsreader-gaffe-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 14:18:36+00:00

We've all faced disagreements at work, or been trapped in an uncomfortable stand-off after getting in someone's bad books.

## 'Jessica, we are live': On-air gaffe goes viral
 - [https://www.cnn.com/videos/media/2021/06/11/jessica-we-are-live-anchors-awkward-moment-lon-orig-na.cnn](https://www.cnn.com/videos/media/2021/06/11/jessica-we-are-live-anchors-awkward-moment-lon-orig-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 13:39:04+00:00

Two presenters on Namibia's flagship broadcaster have gone viral after their awkward exchange was seen live on air.

## 'Ring of fire' solar eclipse lights up the sky
 - [https://www.cnn.com/videos/business/2021/06/10/solar-eclipse-ring-of-fire-orig.cnn-business](https://www.cnn.com/videos/business/2021/06/10/solar-eclipse-ring-of-fire-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 13:34:35+00:00

A solar eclipse was visible in parts of the Northern Hemisphere as the moon partially blocked out the sun.

## Blake Lively pays tribute to her father, actor Ernie Lively, following his death
 - [https://www.cnn.com/2021/06/11/entertainment/blake-lively-dad-ernie-lively-dead-intl-scli/index.html](https://www.cnn.com/2021/06/11/entertainment/blake-lively-dad-ernie-lively-dead-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 12:45:15+00:00

Blake Lively has shared a touching tribute to her father, the actor Ernie Lively, following his death aged 74.

## Iran says its naval vessels have reached the Atlantic for the first time
 - [https://www.cnn.com/2021/06/11/middleeast/iran-navy-atlantic-intl/index.html](https://www.cnn.com/2021/06/11/middleeast/iran-navy-atlantic-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 12:42:42+00:00

An Iranian navy destroyer ship has reached the Atlantic Ocean, Iran's deputy army commander, Admiral Habibullah Sayyari said, according to official news agency IRNA.

## Hollywood's Latin ambitions hit new heights
 - [https://www.cnn.com/2021/06/11/entertainment/hollywood-latin-ambition/index.html](https://www.cnn.com/2021/06/11/entertainment/hollywood-latin-ambition/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 12:26:21+00:00

If this Clubhouse room was an actual club, it'd be the most FOMO-inducing spot in town. Drink special of the night: piping hot tea.

## China releases new images of Mars taken by its Zhurong rover
 - [https://www.cnn.com/2021/06/11/asia/china-mars-rover-photos-intl-hnk-scn/index.html](https://www.cnn.com/2021/06/11/asia/china-mars-rover-photos-intl-hnk-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 12:06:14+00:00

China unveiled new photos of its Mars rover exploring the surface of the red planet on Friday, with state media hailing it as a sign of the mission's "complete success."

## Brisbane set to host 2032 Olympics after IOC endorsement
 - [https://www.cnn.com/2021/06/11/sport/brisbane-2032-olympics-spt-intl/index.html](https://www.cnn.com/2021/06/11/sport/brisbane-2032-olympics-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 11:45:38+00:00

Brisbane, Australia is set to host the 2032 Olympics after the International Olympic Committee (IOC) endorsed its unopposed bid for the future Games.

## States are scaling back on reporting Covid-19 data, but some experts say it's too soon
 - [https://www.cnn.com/2021/06/11/health/states-scale-back-covid-data-reporting/index.html](https://www.cnn.com/2021/06/11/health/states-scale-back-covid-data-reporting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 11:11:14+00:00

Only about half of US states still provide daily updates on key Covid-19 metrics -- such as new cases, deaths, hospitalizations and vaccinations -- a trend that worries some public health experts.

## Analysis: US military 'laser focused' on keeping up with China
 - [https://www.cnn.com/2021/06/11/asia/us-military-focus-china-intl-hnk/index.html](https://www.cnn.com/2021/06/11/asia/us-military-focus-china-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 10:50:14+00:00



## NBA star helps food truck graffitied with anti-Asian slur and image
 - [https://www.cnn.com/2021/06/11/sport/jordan-clarkson-food-truck-utah-jazz-la-clippers-milwaukee-bucks-brooklyn-nets-spt-intl/index.html](https://www.cnn.com/2021/06/11/sport/jordan-clarkson-food-truck-utah-jazz-la-clippers-milwaukee-bucks-brooklyn-nets-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 10:35:28+00:00

Utah Jazz guard Jordan Clarkson says there is "just no room" for racist incidents days after helping a food truck which had been graffitied with an anti-Asian racial slur and offensive images.

## Here's what happens when you swap your home with strangers for a vacation
 - [https://www.cnn.com/travel/article/families-vacations-for-homeswapping/index.html](https://www.cnn.com/travel/article/families-vacations-for-homeswapping/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 09:39:31+00:00

The concept of staying in another family's home while they bed down in yours isn't exactly new.

## Jill Biden's 'love' blazer sets the tone for G7 summit
 - [https://www.cnn.com/style/article/jill-biden-love-jacket-g7/index.html](https://www.cnn.com/style/article/jill-biden-love-jacket-g7/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 08:57:27+00:00

Jill Biden has underscored her husband's unity agenda ahead of the G7 summit in Cornwall, UK, wearing a blazer embellished with the word "love."

## Why the Queen never wears beige
 - [https://www.cnn.com/style/article/the-queens-fashion-and-colorful-style/index.html](https://www.cnn.com/style/article/the-queens-fashion-and-colorful-style/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 08:37:02+00:00

As Britain's longest-reigning monarch, the Queen is both a cherished and consistent part of public life -- her image synonymous with stability and tradition to the British people.

## China may not be a member of the G7, but it's dominating the agenda
 - [https://www.cnn.com/2021/06/11/china/g7-summit-agenda-mic-intl-hnk/index.html](https://www.cnn.com/2021/06/11/china/g7-summit-agenda-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 08:29:48+00:00

Editor's note: CNN will be launching the Meanwhile in China newsletter on June 21, a three-times-a-week update exploring what you need to know about the country's rise and how it impacts the world. Sign up here.

## Vaccinations remain our best fight against Covid-19, which could surge again in the winter, expert warns
 - [https://www.cnn.com/2021/06/11/health/us-coronavirus-friday/index.html](https://www.cnn.com/2021/06/11/health/us-coronavirus-friday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 07:18:47+00:00

With declining rates of Covid-19 infections and deaths across the US, more cities and states have lifted safety restrictions in anticipation of a better summer.

## California jury awards $15 million to victims after a storage tank malfunction destroyed embryos
 - [https://www.cnn.com/2021/06/11/us/california-embryo-destruction-case-verdict/index.html](https://www.cnn.com/2021/06/11/us/california-embryo-destruction-case-verdict/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 07:09:02+00:00

In a historic verdict, five victims were awarded nearly $15 million by a jury after a storage tank malfunction at a fertility clinic in San Francisco destroyed their frozen embryos three years ago.

## Carrie Johnson steps onto global stage with G7 role
 - [https://www.cnn.com/2021/06/11/europe/carrie-johnson-g7-spouses-intl-cmd-gbr/index.html](https://www.cnn.com/2021/06/11/europe/carrie-johnson-g7-spouses-intl-cmd-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 07:03:00+00:00

• LIVE UPDATES: Leaders from world's largest economies gather
• 'Jill from Philly' to meet the Queen
• Biden joins the world leaders club at G7 with call for wartime effort against Covid-19

## The Americans locked up in Myanmar's notorious prison
 - [https://www.cnn.com/2021/06/10/media/myanmar-coup-prison-american-journalists-intl-hnk-dst/index.html](https://www.cnn.com/2021/06/10/media/myanmar-coup-prison-american-journalists-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 06:52:53+00:00

It was supposed to be an exciting trip home to surprise his parents in the United States, his family said.

## 'Friends' fan cruise to set sail in 2022
 - [https://www.cnn.com/travel/article/friends-cruise-celebrity-equinox-trnd/index.html](https://www.cnn.com/travel/article/friends-cruise-celebrity-equinox-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 06:38:34+00:00

First, the "Friends" reunion, now the "Friends" cruise.

## Indonesia's coronavirus spike has health experts worried the worst is yet to come
 - [https://www.cnn.com/2021/06/11/asia/coronavirus-variants-indonesia-clusters-intl-hnk/index.html](https://www.cnn.com/2021/06/11/asia/coronavirus-variants-indonesia-clusters-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 05:25:08+00:00

A jump in coronavirus cases on Indonesia's two most populous islands has health experts worried the worst could be yet to come, with few curbs on movement at a time when dangerous variants drive record fatalities elsewhere in Southeast Asia.

## Peru's presidential election is just too close to call
 - [https://www.cnn.com/2021/06/11/americas/peru-election-intl/index.html](https://www.cnn.com/2021/06/11/americas/peru-election-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 05:22:51+00:00

Peru's presidential election is going to the wire with authorities in the Latin American country yet to declare a winner in a tightly contested battle between a  political newcomer and his conservative opponent.

## Elephant migration may reveal serious problem for China
 - [https://www.cnn.com/videos/world/2021/06/11/china-elephants-migration-coren-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/06/11/china-elephants-migration-coren-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 05:02:49+00:00

A herd of 15 wild Asian elephants has been wandering across Yunnan province in southern China since March last year. They have trekked more than 300 miles in search of food and a new habitat. CNN's Anna Coren talks to  an expert on what this migration means for the species and its survival in China.

## At least 7 Nicaraguan opposition leaders detained ahead of election
 - [https://www.cnn.com/videos/world/2021/06/11/nicaragua-daniel-ortega-democracy-rivers-dnt-lead-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/06/11/nicaragua-daniel-ortega-democracy-rivers-dnt-lead-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 03:57:52+00:00

In less than a week, seven of President Daniel Ortega's most high-profile opponents have been detained months before a crucial election in Nicaragua as Ortega seeks a fourth term in office. CNN's Matt Rivers reports.

## Chinese researchers find batch of new coronaviruses in bats
 - [https://www.cnn.com/2021/06/10/health/bats-coronavirus-china-genome/index.html](https://www.cnn.com/2021/06/10/health/bats-coronavirus-china-genome/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 03:46:03+00:00

Chinese researchers said Thursday they had found a batch of new coronaviruses in bats including one that may be the second-closest yet, genetically, to the Covid-19 virus.

## Trump Justice Department subpoenaed Apple for data from House Intelligence Committee Democrats, sources say
 - [https://www.cnn.com/2021/06/10/politics/house-intelligence-committee-apple-data-trump-justice-department-doj/index.html](https://www.cnn.com/2021/06/10/politics/house-intelligence-committee-apple-data-trump-justice-department-doj/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 03:39:33+00:00

Prosecutors in the Trump administration Justice Department subpoenaed Apple for data from the accounts of House Intelligence Committee Democrats -- including Chairman Adam Schiff -- along with their staff and family members as part of a leak investigation, an Intelligence Committee official and a source familiar with the matter confirmed to CNN.

## An electrical substation fire in Puerto Rico has knocked out power throughout the island
 - [https://www.cnn.com/2021/06/10/us/puerto-rico-substation-fire-power-outage/index.html](https://www.cnn.com/2021/06/10/us/puerto-rico-substation-fire-power-outage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 03:08:15+00:00

A fire at an electrical substation in Puerto Rico has knocked out power throughout the island, utility company LUMA Energy said Thursday.

## High school principal sings 'I Will Always Love You' to graduating class
 - [https://www.cnn.com/videos/us/2021/06/10/principal-sings-to-graduating-class-orig-jk.cnn](https://www.cnn.com/videos/us/2021/06/10/principal-sings-to-graduating-class-orig-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 03:06:09+00:00

Listen to this principal's stunning voice and the reasons why he sang to his graduates.

## The architect on a mission to recycle everything
 - [https://www.cnn.com/style/article/arthur-huang-miniwiz-hospital-ward-c2e-spc-intl-hnk/index.html](https://www.cnn.com/style/article/arthur-huang-miniwiz-hospital-ward-c2e-spc-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 02:52:28+00:00

When the Covid-19 pandemic hit, Taiwanese architect and engineer Arthur Huang wanted to do something to help. As the construction industry across the world ground to a halt, putting many of his projects on hold, Huang turned his attention to solving the urgent need for medical supplies and hospital space.

## 'In the Heights' director Jon M. Chu: 'The American dream is not a given'
 - [https://www.cnn.com/style/article/jon-m-chu-in-the-heights-hyphenated/index.html](https://www.cnn.com/style/article/jon-m-chu-in-the-heights-hyphenated/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 02:24:58+00:00

In this summer's highly-anticipated "In the Heights," cast members sing and dance on the streets of Manhattan to tell the tale of a bodega owner who dreams of one day returning to the Dominican Republic to open a bar.

## New Zealand's Maori may have discovered Antarctica 1,300 years before Westerners, study says
 - [https://www.cnn.com/2021/06/10/australia/new-zealand-maori-antarctica-intl-hnk-scn/index.html](https://www.cnn.com/2021/06/10/australia/new-zealand-maori-antarctica-intl-hnk-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 02:07:28+00:00

For decades, historians and scientists believed Antarctica was first discovered by Europeans and Americans. But according to a new study, it may have been New Zealand's indigenous Maori people who first laid eyes on the icy landscape.

## Pregnant woman's car spins out and flips after being hit by an officer
 - [https://www.cnn.com/videos/us/2021/06/11/arkansas-car-flipped-by-officer-traffic-stop-mh-orig.cnn](https://www.cnn.com/videos/us/2021/06/11/arkansas-car-flipped-by-officer-traffic-stop-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 01:57:51+00:00

A woman is suing the Arkansas State Trooper who hit her car in order to get her to pull over. The police say it's not the first time this tactic has been used.

## The chipmaking factory of the world is battling Covid and the climate crisis
 - [https://www.cnn.com/2021/06/10/tech/taiwan-chip-shortage-covid-climate-crisis-intl-hnk/index.html](https://www.cnn.com/2021/06/10/tech/taiwan-chip-shortage-covid-climate-crisis-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 01:30:02+00:00

Taiwanese officials are fretting about whether a severe outbreak of Covid-19 could jeopardize the island's critical role in the global semiconductor supply chain. But there's another threat to the industry that experts worry may have even more drastic consequences: the climate crisis.

## FBI Director Chris Wray says he's 'not aware of any investigation' against Trump related to the insurrection
 - [https://www.cnn.com/2021/06/10/politics/fbi-chris-wray-trump-insurrection/index.html](https://www.cnn.com/2021/06/10/politics/fbi-chris-wray-trump-insurrection/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 00:35:21+00:00

FBI Director Chris Wray said Thursday that he is "not aware of any investigation" against former President Donald Trump in connection with the January 6 insurrection.

## Kim Jong Un's new appearance raises questions
 - [https://www.cnn.com/videos/world/2021/06/10/kim-jong-un-weight-loss-north-korea-ripley-pkg-vpx.cnn](https://www.cnn.com/videos/world/2021/06/10/kim-jong-un-weight-loss-north-korea-ripley-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-11 00:00:08+00:00

Kim Jong Un's apparent weight loss prompts speculation over the North Korean leader's health. CNN's Will Ripley reports.

