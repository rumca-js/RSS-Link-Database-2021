# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Further Discusses Logan Paul vs. Floyd Mayweather
 - [https://www.youtube.com/watch?v=Dth18cbQ8M4](https://www.youtube.com/watch?v=Dth18cbQ8M4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-11 00:00:00+00:00

Taken from JRE #1666 w/Duncan Trussell:
https://open.spotify.com/episode/6AQf83SnZ7TGyXs7cwZOU3?si=uMXlAJSTTTara1iYvY8lFw&dl_branch=1

## John Cena Apologizing to China Signifies Cultural Shift
 - [https://www.youtube.com/watch?v=CdDmUDxEqwo](https://www.youtube.com/watch?v=CdDmUDxEqwo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-11 00:00:00+00:00

Taken from JRE #1666 w/Duncan Trussell:
https://open.spotify.com/episode/6AQf83SnZ7TGyXs7cwZOU3?si=uMXlAJSTTTara1iYvY8lFw&dl_branch=1

