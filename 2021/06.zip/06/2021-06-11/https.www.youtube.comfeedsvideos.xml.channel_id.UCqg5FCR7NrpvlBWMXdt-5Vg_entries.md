# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## How The Ascent Moves the Genre of Top-Down Shooters Forward | Interview
 - [https://www.youtube.com/watch?v=c9Ei7q-YisI](https://www.youtube.com/watch?v=c9Ei7q-YisI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-12 00:00:00+00:00

Nick Calandra interviews Arcade Berg of Neon Giant to learn more about The Ascent, an upcoming top-down shooter set in a cyberpunk open world filled to the brim with detail. In the interview we discuss the philosophy behind Neon Giant as a studio, the design of the The Ascent's open world, combat, coop and more.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#TheAscent

## In The Heights | Review
 - [https://www.youtube.com/watch?v=-krHRZ5_A94](https://www.youtube.com/watch?v=-krHRZ5_A94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-12 00:00:00+00:00

Darren Mooney reviews In The Heights for The Escapist.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Mario + Rabbids: Sparks of Hope - A Surprise Sequel to Kingdom Battle | E3 2021
 - [https://www.youtube.com/watch?v=4jq-7DQFeFA](https://www.youtube.com/watch?v=4jq-7DQFeFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-12 00:00:00+00:00

Mario + Rabbids: Sparks of Hope was announced that the Ubisoft Forward E3 2021 press event this afternoon as a sequel to Kingdom Battle, this time bringing a more ambitious game with exploration, platforming a new combat system.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Ubisoft Forward + Devolver + Gearbox E3 2021 Showcase
 - [https://www.youtube.com/watch?v=QgQEgXxuQKs](https://www.youtube.com/watch?v=QgQEgXxuQKs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-12 00:00:00+00:00

Join The Escapist as we co-stream the Ubisoft Forward E3 2021 event. Pre-show begins at 1:30 PM CT with Nick and Marty, and a post-show will immediately follow the event discussing our thoughts and reactions to new announcements.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Death Stranding Director's Cut - What Are We Expecting? | Summer Game Fest
 - [https://www.youtube.com/watch?v=sc3AU52iUzg](https://www.youtube.com/watch?v=sc3AU52iUzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-11 00:00:00+00:00

Hideo Kojima revealed that a Director's Cut of Death Stranding is coming to the PS5 (and presumably PC), but what exactly does that mean? Nick, Marty and Jesse speculate about what a Director's Cut might look like for Death Stranding.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#DeathStranding #PS5 #SummerGameFest

## Evil Dead: The Game Looks Surprisingly Good | Summer Game Fest
 - [https://www.youtube.com/watch?v=aJ0p53WThvY](https://www.youtube.com/watch?v=aJ0p53WThvY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-11 00:00:00+00:00

The new Evil Dead game from Saber Interactive looks surprisingly fun. Nick, Marty and Jesse breakdown their thoughts on the game following the full reveal at Summer Game Fest. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#EvilDeadTheGame #SummerGameFest

## Planet of Lana - The Next Big Side-Scroller Adventure? | Summer Game Fest
 - [https://www.youtube.com/watch?v=vjf__K9EKF4](https://www.youtube.com/watch?v=vjf__K9EKF4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-11 00:00:00+00:00

Revealed at Summer Game Fest, Planet of Lana is a beautiful side-scrolling adventure game that takes heavy inspiration from Inside and Studio Ghibli films. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#PlanetofLana #SummerGameFest

## Sniper: Ghost Warrior Contracts 2 | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=osa_u1e4Mi4](https://www.youtube.com/watch?v=osa_u1e4Mi4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-11 00:00:00+00:00

Jesse Galena reviews Sniper: Ghost Warrior Contracts 2, developed by CI Games.

Sniper: Ghost Warrior Contracts 2 on Steam: https://store.steampowered.com/app/1338770/Sniper_Ghost_Warrior_Contracts_2/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Tiny Tina's Wonderlands - Fantasy Borderlands? | Summer Game Fest
 - [https://www.youtube.com/watch?v=fxYtrGMGpkY](https://www.youtube.com/watch?v=fxYtrGMGpkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2021-06-11 00:00:00+00:00

Tiny Tina's Wonderlands was revealed at Summer Game Fest so Nick, Marty and Jesse have some thoughts about it.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► http://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#TinyTinasWonderlands #SummerGameFest

