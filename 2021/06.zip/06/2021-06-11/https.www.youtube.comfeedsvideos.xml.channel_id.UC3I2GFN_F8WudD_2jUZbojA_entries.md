# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## True Loves - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=H49tu_VoViU](https://www.youtube.com/watch?v=H49tu_VoViU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-06-12 00:00:00+00:00

http://KEXP.ORG presents True Loves performing live, recorded exclusively for KEXP.

Songs:
S.O.S.
Objects In Mirror
Did It Again
First Impression 
Lavender 
Sunday Afternoon 

Directed by blazinspace 
Camerawork by Carl Westgren
Edited by Jim Beckmann (KEXP)
Live Sound by Bradley Laina
Audio Mix by Ian Macklin Davidson

True Loves:
Bryant Moore - bassist
David McGraw - drummer
Gordon Brown - saxophonist
Greg Kramer - trombonist
Iván Galvez - percussionist
Jimmy James - guitarist
Jason Cressey - trombonist
Skerik - saxophonist

https://www.truelovesband.com
http://kexp.org

## True Loves - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Ryi2w-zgd1U](https://www.youtube.com/watch?v=Ryi2w-zgd1U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-06-11 00:00:00+00:00

http://KEXP.ORG presents True Loves sharing a live performance recorded exclusively for KEXP and talking to Troy Nelson. Recorded May 27, 2021.

Songs:
S.O.S.
Objects In Mirror
Did It Again
First Impression 
Lavender 
Sunday Afternoon 

Directed by blazinspace 
Camerawork by Carl Westgren
Edited by Jim Beckmann (KEXP)
Live Sound by Bradley Laina
Audio Mix by Ian Macklin Davidson

True Loves:
Bryant Moore - bassist
David McGraw - drummer
Gordon Brown - saxophonist
Greg Kramer - trombonist
Iván Galvez - percussionist
Jimmy James - guitarist
Jason Cressey - trombonist
Skerik - saxophonist

https://www.truelovesband.com
http://kexp.org

