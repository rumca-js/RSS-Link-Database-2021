# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## This Is The Worst Company In The World
 - [https://www.youtube.com/watch?v=KkOqvQeOecM](https://www.youtube.com/watch?v=KkOqvQeOecM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-06-11 00:00:00+00:00

PayPal has one of the worst reputations in the world and its centralized business model poses a threat to all users.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Companies that handle your money have a responsibility to their shareholders. They need to pay out dividends and increase share prices, otherwise investors might bail. Serving customers neutrally is risky, because at least some of them might use their service in ways that produce really bad PR. 

PayPal’s terms of service redefines what money means. Its narrow acceptable use policy makes money function as a permissioned tender. You cannot use your funds however you want. PayPal has a broad definition for which payments require pre-approval and which ones are not allowed at all. It isn’t the only financial company susceptible to the failures of centralization, but it’s a perfect case study for why you shouldn’t trust any single authority when it comes to your money. 

Sources
PayPal sucks https://www.trustpilot.com/review/www.paypal.com
PayPal's acceptable use policy https://www.paypal.com/en/webapps/mpp/ua/acceptableuse-full

Ridiculous examples of PayPal financial censorship
Tardigrade
https://news.bitcoin.com/the-moss-piglet-dilemma-paypal-bans-payments-to-merchants-using-the-word-tardigrade/
https://twitter.com/c/ArchieMcPhee/status/1304434532293046272
https://www.geekwire.com/2020/weird-seattle-retailer-archie-mcphee-hit-even-weirder-paypal-security-glitch/
https://twitter.com/princessmlokhia/status/1394399401263632384
Cancelled without explanation 
https://mises.org/power-market/paypal-censorship-not-limited-online-provocateurs
https://puntofisso.medium.com/paypal-closed-my-account-with-no-explanation-it-could-happen-to-you-6ff0ba4ea95f
https://twitter.com/Kimberleypfp/status/1304443884005740544
Cancelled for speech
https://www.theguardian.com/technology/2018/nov/09/paypal-proud-boys-antifa-ban-gavin-mcinnes-criticism
https://www.huffpost.com/entry/tech-companies-white-supremacists-stripe-paypal-square-anedot_n_5b71fd68e4b0ae32af9ae20e
https://www.theverge.com/2017/8/16/16159310/apple-pay-drops-support-white-supremacist-neo-nazi-merchandise
https://www.buzzfeednews.com/article/blakemontgomery/the-alt-right-has-a-payment-processor-problem
https://www.cnet.com/news/paypal-and-shopify-remove-trump-related-accounts-citing-policies-against-supporting-violence/
https://mashable.com/article/epik-domain-names-paypal-proud-boys/?
https://www.nytimes.com/2021/01/10/technology/parler-app-trump-free-speech.html

Screening based on keywords
https://thegrayzone.com/2020/01/09/paypal-blocks-donations-iran/
https://www.coindesk.com/venmo-censorship-neutral-platforms-like-bitcoin 
https://www.businessinsider.com/venmo-blocking-palestine-relief-payments-us-treasury-sanctions-rules-2021-5
https://twitter.com/SJPUIC/status/1394417124458827780

Censoring publishers
https://news.bitcoin.com/pornhub-accepts-bitcoin-top-adult-site-cryptocurrency-payment/
https://www.wired.com/2010/12/paypal-wikileaks/
https://www.thepaypalblog.com/2010/12/paypal-statement-regarding-wikileaks/
https://www.forbes.com/sites/andygreenberg/2010/12/07/visa-mastercard-move-to-choke-wikileaks/
https://www.coindesk.com/blackballed-by-paypal-scientific-paper-pirate-takes-bitcoin-donations
https://www.washingtonpost.com/national-security/justice-department-investigates-sci-hub-founder-on-suspicion-of-working-for-russian-intelligence/2019/12/19/9dbcb6e6-2277-11ea-a153-dce4b94e4249_story.html

PayPal under investigation https://www.washingtonpost.com/business/economy/us-consumer-watchdog-agency-investigates-venmo-payments-app/2021/02/05/a869e7d6-67ad-11eb-886d-5264d4ceb46d_story.html

PayPal's crypto lure
https://newsroom.paypal-corp.com/2020-10-21-PayPal-Launches-New-Service-Enabling-Users-to-Buy-Hold-and-Sell-Cryptocurrency
https://blog.trezor.io/why-you-should-not-use-paypal-for-bitcoin-f6e2d436ca96?

PayPal's compliance with government mandates
https://www.bbc.com/news/technology-32067151
OFAC https://home.treasury.gov/policy-issues/office-of-foreign-assets-control-sanctions-programs-and-information
https://newsroom.paypal-corp.com/Keeping-the-Venmo-Community-Secure-The-Companys-Approach-to-OFAC-Compliance

PayPal's integration into China
https://www.reuters.com/article/us-china-paypal-stake-idUSKBN29J0IC
https://edition.cnn.com/2019/09/30/tech/paypal-gopay-china-payments/index.html
https://techcrunch.com/2021/04/28/paypal-china/?

Censorship by other centralized financial institutions
https://www.huffpost.com/entry/bank-of-america-will-stop_n_798605
https://stripe.com/restricted-businesses

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

