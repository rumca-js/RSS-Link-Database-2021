# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## Brains Are Jerks At 3AM
 - [https://www.youtube.com/watch?v=kSpdkIQ-ouE](https://www.youtube.com/watch?v=kSpdkIQ-ouE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-06-11 00:00:00+00:00

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

