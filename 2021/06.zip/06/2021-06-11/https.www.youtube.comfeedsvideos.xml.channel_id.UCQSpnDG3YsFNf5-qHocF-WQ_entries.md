# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## How to Spot Any Spoofed & Fake Email (Ultimate Guide)
 - [https://www.youtube.com/watch?v=hF1bIT1ym4g](https://www.youtube.com/watch?v=hF1bIT1ym4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-06-12 00:00:00+00:00

YOU'LL NEVER GET TRICKED AGAIN! (Scammers will hate this)
⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
1:49 - The "From" Domain
7:17 - The Reply-To Field
10:07 - Mailed By & Signed By
12:16 - Authentication Headers (Basics)
16:49 - SPF
17:47 - DKIM
21:32 - DMARC
23:46 - How SPF Works
24:59 - How DKIM Works
26:59 - How DMARC Works
27:53 - WHY BOTHER?

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

