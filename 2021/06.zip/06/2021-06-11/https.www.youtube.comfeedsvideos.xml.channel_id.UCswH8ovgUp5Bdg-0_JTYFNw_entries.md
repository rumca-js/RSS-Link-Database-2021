# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Taking The Knee & Taking The P*ss: Does Sport Care About Equality?
 - [https://www.youtube.com/watch?v=nCxd_aBcTOg](https://www.youtube.com/watch?v=nCxd_aBcTOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-06-11 00:00:00+00:00

It feels like we live in a climate where we're talking about mental health and racism all the time. But do gestures around these causes distract from a lack of action by the very corporations who benefit from the issues they claim to care about? 
#NaomiOsaka #BlackLivesMatter #BLM #TakingThe Knee #Tennis #FrenchOpen #MentalHealth

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: 
http://adbl.co/revelation
UK: 
http://adbl.co/revelationuk
AU: 
http://adbl.co/revelationau
CA: 
http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

