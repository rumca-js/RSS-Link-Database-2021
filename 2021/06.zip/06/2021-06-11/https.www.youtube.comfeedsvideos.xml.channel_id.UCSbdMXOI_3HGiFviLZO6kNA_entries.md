# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## What happened to my Oculus Quest 2 after 9 months of usage?
 - [https://www.youtube.com/watch?v=uct0UV9GHR0](https://www.youtube.com/watch?v=uct0UV9GHR0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-06-12 00:00:00+00:00

Hello! Welcome to my complete analysis of the Oculus Quest 2, its hardware, software, firmware, and its impact on the entire VR industry. This was a really fun video to make, I hope you all enjoy greatly! Spent some time really dissecting the Quest 2 as a complete VR headset. Lets see if The quest 2 has survived the greatest test ever: time.

Really, the last sentence is probably the most powerful words I have ever said about VR in a video. Like I said I hope you enjoy.


Giving away THREE Quest 2s TOMORROW on stream: Twitch.tv/Thrilluwu
My links;
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

