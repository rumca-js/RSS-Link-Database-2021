# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Helm Hammerhand and the War of the Rohirrim | Tolkien Explained
 - [https://www.youtube.com/watch?v=EbI2WyNmh70](https://www.youtube.com/watch?v=EbI2WyNmh70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-06-12 00:00:00+00:00

We cover the complete life and travels of Helm Hammerhand, the ninth King of Rohan.  To celebrate the announcement of the new animated film The Lord of the Rings: The War of the Rohirrim, we take a look at this time period in Middle-earth, as this mighty king faces grave enemies both outside Rohan, and from within.  We follow his life from his birth to taking refuge in the very gorge that would one day bear his name - Helm's Deep.

*Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!*  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, I highly recommend checking out these amazing artists online!

Turner Mohan - https://www.instagram.com/turner_mohan
Ted Nasmith - https://www.tednasmith.com/shop/
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Jenny Dolfen - https://goldseven.wordpress.com/

Men of Dunland - Turner Mohan
Helm Hammerhand - Turner Mohan
Helm Hammerhand - Sebastian Rodriguez
The Riders of Rohan - Turner Mohan
Dunlending - John Howe
Orthanc in the Second Age - Ted Nasmith
Isengard Map - LOTRO
Rohirrim vs Dunlendings - Cristi Balanescu
Edoras - Bakarov
Men are Freer Outside - Turner Mohan
Helm Kills Freca - LOTRO
Helm's Dike - Mariusz Gandzel
Wulf - Turner Mohan
Snow Covered Plains - Alayna Danner
Helm Hammerhand - Turner Mohan
Helm Hammerhand - Ben Wootten
Helm's Last Stand - Turner Mohan
Helm's Death - HeavyPred
Helm Hammerhand's Last Stand - Matej Cadil
Rider of Rohan - Javier Charro Martinez
Rohirrim - CG Warrior
Rohan Character Circles - LOTRO
Free Realistic Snow Overlay by Kosmos Motion Graphics
http://youtu.be/vEhD5WwCo44


For more information on Helm Hammerhand and this time period in Rohan, check out:
The Lord of the Rings: Appendix A: The House of Eorl
The Lord of the Rings: Appendix A: The Kings of the Mark
The Encyclopedia of Arda
Tolkien Gateway


#rohirrim #tolkien #waroftherohirrim

