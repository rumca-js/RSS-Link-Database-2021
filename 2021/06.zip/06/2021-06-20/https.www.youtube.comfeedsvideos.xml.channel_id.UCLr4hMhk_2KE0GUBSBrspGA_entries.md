# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Zepsułem MacBooka i po co Ci gimbal? MacBook 15 2018, MacBook 13 M1, Zhiyun Smooth Q3, DJI OM 3,OM 4
 - [https://www.youtube.com/watch?v=hmig-uom5LE](https://www.youtube.com/watch?v=hmig-uom5LE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-06-21 00:00:00+00:00

W dzisiejszym tech vlogu:
Zepsuty MacBook 15 2018
Nowy MacBook 13 M1
ZEN (fragment spons): https://bit.ly/3rklh8W 
(kod przedłużający okres próbny: klawyzen)
Pasta bezjajeczna
Zhiyun Smooth Q3
DJI Osmo Mobile 3
DJI OM 4

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Bezsenna noc Kuby
00:43 Wybór MacBooka 13 Pro M1
01:08 Fragment sponsorowany ZEN
01:37 Jak zrobić recenzję PowerBanku?
02:20 Test kanapki z pastą bezjajeczną
02:58 Unboxing nowego MacBooka i transfer danych
03:22 Dlaczego nie MacBook 13 Pro M1?
03:56 Dobre rady, z nami łatwiej żyć – gimbale
06:55 Test prędkości MacBooka – eksport pliku
07:55 Podsumowanie testu i zakończenie

## Tech Week: Kto zostanie właścicielem internetu? Oraz: realme GT 5G, Beats Studio Buds, Doom Ikea
 - [https://www.youtube.com/watch?v=RPkTfz04WCk](https://www.youtube.com/watch?v=RPkTfz04WCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-06-20 00:00:00+00:00

A także:
Kogo interesuje film o realme GT 5G: https://youtu.be/Nr_KQzsh-N8
Nowe słuchawki Sony w recenzji: https://youtu.be/yz3qkMigj9g
Nowe Beats Studio Buds: https://youtu.be/-XM7883VytU 
Nintendo nie pokazało nowego Switcha: https://bit.ly/3wDBuJb
Doom na żarówce z IKEI: https://bit.ly/2SOeFDN
Archiwalna dokumentacja: https://bit.ly/3zG49iD
Kup sobie internet: https://cnet.co/3wDBSHD
Canon uszczęśliwia pracowników: https://bit.ly/3zGY715
Tamagotchi wróciło: https://engt.co/3iU2jEU
Wristcam dostał 25M $ na rozwój: https://tcrn.ch/2TOSaPk
Petycja, żeby Bezos nie wracał z kosmosu: https://bit.ly/2SGUt74
Petycja, żeby Bezos zjadł Mona Lisę: https://bit.ly/3xxtucM

Moje sociale: 
Insta: https://www.instagram.com/kubaklawiter/
Twitter: https://twitter.com/KubaKlawiter

Spis treści:
00:00 Wstęp
00:15 Dobry wieczór!
00:20 W jutrzejszym vlogu - nowy MacBook 13 Pro M1
00:39 Realme GT 5G – zapowiedź filmu 100 pytań o…
02:20 Beats Studio Buds
02:33 O montowaniu materiałów
03:18 Czy muzyka jest istotna w filmach na YouTube?
03:46 Porównanie słuchawek Sony XM4 do Bose i AirPods Pro
04:25 Brak newsów technologicznych w Tech Weeku
04:59 Nowe słuchawki douszne Beats Studio Buds od Apple
06:36 Brak nowego Switcha od Nintendo 
06:48 Doom na żarówce z Ikei
07:32 Internet na sprzedaż w postaci NFT
08:00 Canon uszczęśliwia pracowników
08:36 Powrót Tamagotchi
09:03 Wristcam dostaje 2 mln $ na rozwój
09:35 Petycja, żeby Bezos nie wracał z kosmosu
09:46 Petycja, żeby Bezos kupił i zjadł Mona Lisę
09:53 Wspieranie ludzi słabszych i tych, którym nie wychodzi
10:19 Pożegnanie
10:27 Znośnego tygodnia

