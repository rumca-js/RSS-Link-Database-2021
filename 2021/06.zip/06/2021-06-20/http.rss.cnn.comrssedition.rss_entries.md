# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Suspect charged with murder in death of American woman in Russia
 - [https://www.cnn.com/2021/06/20/europe/russia-catherine-serou-found-dead-intl/index.html](https://www.cnn.com/2021/06/20/europe/russia-catherine-serou-found-dead-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 23:44:52+00:00

Russian authorities have found the body of Catherine Serou, a missing United States student who vanished earlier this week in the country's Nizhny Novgorod region.

## 'Sesame Street' introduces family with two gay dads
 - [https://www.cnn.com/videos/us/2021/06/20/sesame-street-gay-dads-family-pride-month-eg-orig.cnn](https://www.cnn.com/videos/us/2021/06/20/sesame-street-gay-dads-family-pride-month-eg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 21:42:56+00:00

Cast member Nina introduced her brother and his husband, as well as their daughter, to Elmo and his friends as they celebrated Family Day on the decades-old children's show.

## Astronauts install new solar panels in 6-hour spacewalk on International Space Station
 - [https://www.cnn.com/2021/06/20/world/nasa-spacewalk-sunday-solar-arrays-scn/index.html](https://www.cnn.com/2021/06/20/world/nasa-spacewalk-sunday-solar-arrays-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 19:41:31+00:00

NASA astronaut Shane Kimbrough and European Space Agency astronaut Thomas Pesquet conducted a spacewalk Sunday -- their second in the past week -- to install new solar arrays that will provide a power boost to the space station.

## Republican and lifelong FBI agent debunks conspiracy theory
 - [https://www.cnn.com/videos/politics/2021/06/20/brian-fitzpatrick-republican-capitol-riot-fbi-sotu-bash-vpx.cnn](https://www.cnn.com/videos/politics/2021/06/20/brian-fitzpatrick-republican-capitol-riot-fbi-sotu-bash-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 17:07:56+00:00

Rep. Brian Fitzpatrick (R-PA) says that his fellow Republicans need to stop giving air to a false flag conspiracy that the FBI was involved in the deadly assault on the US Capitol.

## How CNN obtained the dramatic videos of the US Capitol riot
 - [https://www.cnn.com/2021/06/20/politics/cnn-capitol-riot-videos/index.html](https://www.cnn.com/2021/06/20/politics/cnn-capitol-riot-videos/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 16:43:21+00:00

Words can only describe so much from the nearly 500 criminal cases against rioters who overtook the US Capitol on January 6.

## Woman dies after falling 200 feet off a cliff during a sunrise hike
 - [https://www.cnn.com/2021/06/19/us/wyoming-hiking-death-woman-falls/index.html](https://www.cnn.com/2021/06/19/us/wyoming-hiking-death-woman-falls/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 12:29:22+00:00



## How Trump dashed dreams of reform in Iran
 - [https://www.cnn.com/2021/06/20/middleeast/iran-analysis-trump-raisi-cmd-intl/index.html](https://www.cnn.com/2021/06/20/middleeast/iran-analysis-trump-raisi-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 12:28:03+00:00

It should have been a spring day most Iranians could look forward to. The trees that lined Tehran's boulevards glistened in the sun as a gentle breeze wafted through the city. But on May 8, 2018, the capital's residents braced themselves for a terrible reversal of fortunes.

## This cargo ship's captain died aboard. The crew was stuck at sea for weeks, with a dead body no country would take
 - [https://www.cnn.com/2021/06/19/europe/italy-captain-capurro-intl-hnk-dst/index.html](https://www.cnn.com/2021/06/19/europe/italy-captain-capurro-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 12:16:37+00:00



## Biden's partisan opponents hold potent weapons and a relentless determination to see him fail
 - [https://www.cnn.com/2021/06/20/politics/biden-domestic-agenda-challenge/index.html](https://www.cnn.com/2021/06/20/politics/biden-domestic-agenda-challenge/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 11:57:53+00:00

With confidence and elan, President Joe Biden rallied allies abroad last week around the viability of 21st century democracy. Proving it here at home will be harder.

## One dead after a truck hit pedestrians at a Florida Pride parade
 - [https://www.cnn.com/videos/us/2021/06/20/south-florida-pride-parade-death-chen-ndwknd-vpx.cnn](https://www.cnn.com/videos/us/2021/06/20/south-florida-pride-parade-death-chen-ndwknd-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 11:33:32+00:00

Two pedestrians at a Pride parade near Miami on Saturday were hit by a truck, leaving one dead and the other injured, according to police.

## Summer solstice 2021: Sensual traditions on the longest day of the year
 - [https://www.cnn.com/travel/article/summer-solstice-2021-traditions-scn-trnd/index.html](https://www.cnn.com/travel/article/summer-solstice-2021-traditions-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 10:02:03+00:00

Call it romance. Call it sensuality. Heck, call it old-fashioned lust if you wish.

## Some people who lost loved ones to Covid say they're receiving messages from beyond the grave
 - [https://www.cnn.com/2021/06/20/health/supernatural-encounters-pandemic-loved-ones-blake/index.html](https://www.cnn.com/2021/06/20/health/supernatural-encounters-pandemic-loved-ones-blake/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 08:07:00+00:00

• This cargo ship's captain died aboard. The crew was stuck at sea for weeks, with a potential Covid outbreak on its hands

## 'Homophobia is a huge problem in Poland': Thousands march for LGBT equality
 - [https://www.cnn.com/2021/06/20/europe/poland-lgbt-march-intl/index.html](https://www.cnn.com/2021/06/20/europe/poland-lgbt-march-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 07:57:10+00:00

Thousands marched through central Warsaw on Saturday in an "Equality Parade" demanding an end to discrimination against the LGBT community, amid what campaigners say has been a rising tide of homophobia in Poland in recent years.

## Man with giant kidneys to have major surgery to remove both
 - [https://www.cnn.com/2021/06/20/uk/warren-higgs-windsor-appeal-scli-intl-gbr/index.html](https://www.cnn.com/2021/06/20/uk/warren-higgs-windsor-appeal-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 07:35:10+00:00

A man from Windsor, southern England is set to have major surgery next month after his kidneys grew up to an estimated 40kg (88lb) due to polycystic kidney disease (PKD).

## Olympic coach tests positive for Covid after arriving in Japan
 - [https://www.cnn.com/2021/06/20/asia/uganda-olympics-covid-intl-hnk/index.html](https://www.cnn.com/2021/06/20/asia/uganda-olympics-covid-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 07:05:35+00:00



## Emory University School of Medicine formally apologizes after rejecting an applicant for his race
 - [https://www.cnn.com/2021/06/20/us/emory-university-marion-hood-trnd/index.html](https://www.cnn.com/2021/06/20/us/emory-university-marion-hood-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 05:03:06+00:00

More than 60 years ago, Marion Gerald Hood was rejected from a medical school because of his race. This week, the school apologized.

## 1 person is dead after a truck hit pedestrians at a Florida Pride parade
 - [https://www.cnn.com/2021/06/20/us/pride-parade-florida-truck-hits-pedestrians/index.html](https://www.cnn.com/2021/06/20/us/pride-parade-florida-truck-hits-pedestrians/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 04:23:39+00:00

Two pedestrians at a Pride parade near Miami on Saturday were hit by a truck, leaving one dead and the other injured, according to police.

## Hitler banned Jews from serving in the military. Nine decades later this rabbi is taking on a previously unimaginable job
 - [https://www.cnn.com/2021/06/20/europe/rabbi-zsolt-balla-german-military-jewish-intl-cmd/index.html](https://www.cnn.com/2021/06/20/europe/rabbi-zsolt-balla-german-military-jewish-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 04:06:54+00:00



## The US triples its vaccine donations to Taiwan as the island battles an outbreak
 - [https://www.cnn.com/2021/06/19/asia/taiwan-us-vaccine-donations-intl-hnk/index.html](https://www.cnn.com/2021/06/19/asia/taiwan-us-vaccine-donations-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-20 03:35:23+00:00



