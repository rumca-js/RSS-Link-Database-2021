# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 5 Mythical Creatures That (Kinda) Actually Existed | Answers With Joe
 - [https://www.youtube.com/watch?v=FNC6RfhKDi0](https://www.youtube.com/watch?v=FNC6RfhKDi0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2021-06-21 00:00:00+00:00

Get your daily dose of quick, important info by signing up for Morning Brew for free here: http://bit.ly/joescott
There are myths and legends of mythical creatures through out the folklore of civilizations around the world. Myths like dragons, cyclops and the kraken. But where did these myths come from? And could they have actually existed in some way?

Oh, here's the cephalopods video Jason made me reference...
https://youtu.be/73-QuQwFFAY

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

