# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Best Tech Deals: Amazon Prime Day 2021 -- YA BLEW IT THEY'RE OVER
 - [https://www.youtube.com/watch?v=KRnCvgYDfLE](https://www.youtube.com/watch?v=KRnCvgYDfLE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2021-06-21 00:00:00+00:00

🡇 Prime Trials 🡇
30 Day Free Trial: https://amzn.to/3h6gDrB
6 Month Student Free Trial: https://amzn.to/3vEORri

🡇 Amazon Devices 🡇
Echo 4th Gen: https://amzn.to/3wPQLXi
Echo Dot 4th Gen: https://amzn.to/3xzUDM0
Ring Doorbell Wired: https://amzn.to/3zJxSXT
Kindle Paperwhite: https://amzn.to/3zJxSXT
Kindle Oasis: https://amzn.to/35H8c0p

🡇 Tech Deals 🡇
Roomba i6+: https://amzn.to/3gQzYy5
Roomba 692: https://amzn.to/3zMwmUY
Samsung T5 2TB SSD: https://amzn.to/2Uqhnjx
Samsung 980 Pro 500GB: https://amzn.to/3wSdN00
Samsung 980 Pro 2TB: https://amzn.to/3j4tKfh
Crucial P5 1TB: https://amzn.to/3gIPhZu
Asus Chromebook C433: https://amzn.to/3zN1u6G
Steelseries Apex Pro: https://amzn.to/2SS1zpd
Razer BlackWidow: https://amzn.to/3j0rYvS
Apple TV 4K: https://www.walmart.com/ip/Apple-TV-4K-32GB/976529747
Samsung Galaxy S21: https://amzn.to/3gUTW9o
Yubico Security Key: https://amzn.to/3gLkcEt
LG 27GL83A Monitor: https://amzn.to/3wLFebF
Samsung Odyssey G5 Monitor: https://amzn.to/2TUNMhD
Philips Hue LightStrip Bundle: https://amzn.to/3zFG9MN

(NOTE: These are Amazon affiliate links so I may get a commission if you buy them which I'll put towards the channel)

