# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Back-to-back birdies put Jon Rahm into US Open lead
 - [https://www.bbc.co.uk/sport/av/golf/57549374](https://www.bbc.co.uk/sport/av/golf/57549374)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:58:06+00:00

Spain's Jon Rahm takes the lead in the US Open with back-to-back birdies on the 17th and 18th holes.

## Birtukan Mideksa: Ethiopia's electoral board chairperson
 - [https://www.bbc.co.uk/news/world-africa-57486959](https://www.bbc.co.uk/news/world-africa-57486959)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:57:44+00:00

Birtukan Mideksa, a former opposition leader who went into exile in the US, says "shortfalls are inevitable".

## French court dog helps soothe anxious victims of crime
 - [https://www.bbc.co.uk/news/world-europe-57481565](https://www.bbc.co.uk/news/world-europe-57481565)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:51:27+00:00

How one Labrador has helped the victims of violent crime in southern France.

## Joe Biden: My surprise claim to be the US president's English cousin
 - [https://www.bbc.co.uk/news/world-us-canada-57496834](https://www.bbc.co.uk/news/world-us-canada-57496834)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:46:45+00:00

Paul Harris has records that show a link to the president via recently discovered English ancestors.

## The Lazarus heist: How North Korea almost pulled off a billion-dollar hack
 - [https://www.bbc.co.uk/news/stories-57520169](https://www.bbc.co.uk/news/stories-57520169)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:45:52+00:00

In 2016 North Korean hackers planned a $1bn raid on Bangladesh's national bank and came within an inch of success. But how did they do it?

## Nottingham Castle: City hopes to shed 'workaday' image with £30m refurb
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-57490256](https://www.bbc.co.uk/news/uk-england-nottinghamshire-57490256)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:42:58+00:00

Can a £30m refurbishment make up for the fact Nottingham's movie star castle is long gone?

## Tankers and Transit vans sculpted into steel forests
 - [https://www.bbc.co.uk/news/entertainment-arts-57513965](https://www.bbc.co.uk/news/entertainment-arts-57513965)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:38:02+00:00

Dan Rawlings has transformed a petrol lorry into a woodland sculpture with an environmental message.

## Usain Bolt welcomes newborn twin sons Thunder and Saint Leo
 - [https://www.bbc.co.uk/news/world-latin-america-57549202](https://www.bbc.co.uk/news/world-latin-america-57549202)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:29:42+00:00

The Olympic champion and his girlfriend Kasi Bennett announced the births on Instagram.

## Post Office scandal: 'I just forgot how to laugh'
 - [https://www.bbc.co.uk/news/business-57523644](https://www.bbc.co.uk/news/business-57523644)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:18:12+00:00

Anjana and Baljit Sethi ran two successful Post Office branches - then they fell victim to the Horizon scandal.

## South Korea: Swapping Seoul megacity isolation for village life
 - [https://www.bbc.co.uk/news/world-asia-57513600](https://www.bbc.co.uk/news/world-asia-57513600)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:00:52+00:00

Some South Korean families are abandoning Seoul and swapping megacity isolation for rural village life.

## Covid vaccine: Margaret Keenan reflects receiving world's first jab
 - [https://www.bbc.co.uk/news/health-57532766](https://www.bbc.co.uk/news/health-57532766)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 23:00:31+00:00

Since receiving the world's first Covid-19 vaccine, Ms Keenan has stayed in contact with the nurse who administered it.

## Italy 1-0 Wales: The Euro 2020 loss in Rome which felt like a win for Wales
 - [https://www.bbc.co.uk/sport/football/57548582](https://www.bbc.co.uk/sport/football/57548582)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 21:04:45+00:00

Wales celebrate one of their greatest defeats, a loss in Rome which takes them to the knockout stage of Euro 2020, where "the real stuff starts".

## US Navy uses 40,000lb explosive to test warship in 'Full Ship Shock Trial'
 - [https://www.bbc.co.uk/news/world-us-canada-57547885](https://www.bbc.co.uk/news/world-us-canada-57547885)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 20:55:09+00:00

The US Navy conducted a 'Full Ship Shock Trial' against its aircraft carrier, the USS Gerald R. Ford.

## Dál Riata Channel: First all-female relay team swim 'perilous' waterway
 - [https://www.bbc.co.uk/news/uk-northern-ireland-57543609](https://www.bbc.co.uk/news/uk-northern-ireland-57543609)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 17:05:59+00:00

The group swam from Scotland to NI in just over eight hours, after abandoning a first attempt.

## ICYMI: Birds, planes and automobiles
 - [https://www.bbc.co.uk/news/world-57532638](https://www.bbc.co.uk/news/world-57532638)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 13:37:23+00:00

Brooklyn ducks, a Brittany bird-man, and a race with a difference - some of the stories you might have missed this week.

## Tokyo Olympics: Can this athletes' village keep out Covid?
 - [https://www.bbc.co.uk/news/world-asia-57546256](https://www.bbc.co.uk/news/world-asia-57546256)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 13:09:58+00:00

Thousands of athletes will be living together for several weeks - how will they be kept safe?

## Andy Burnham's anger at Manchester-Scotland travel ban
 - [https://www.bbc.co.uk/news/uk-england-manchester-57544665](https://www.bbc.co.uk/news/uk-england-manchester-57544665)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 12:06:37+00:00

Greater Manchester mayor Andy Burnham says Nicola Sturgeon's announcement came "out of the blue".

## Covid: Brazil hits 500,000 deaths amid 'critical' situation
 - [https://www.bbc.co.uk/news/world-latin-america-57541794](https://www.bbc.co.uk/news/world-latin-america-57541794)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 11:58:47+00:00

Experts warn the outbreak could worsen amid a slow vaccination programme and the start of winter.

## Conservative councillor's house set on fire in third attack
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-57545325](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-57545325)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 11:53:26+00:00

Police are treating the blaze at Graeme Stewart's property in Fortrose Gardens, Motherwell as suspicious.

## Former Speaker and Conservative MP John Bercow joins Labour
 - [https://www.bbc.co.uk/news/uk-politics-57541836](https://www.bbc.co.uk/news/uk-politics-57541836)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 11:11:07+00:00

He says he shares Labour values and the "reactionary" Conservative government needs to be replaced.

## Iran election: Israel PM warns world of Ebrahim Raisi
 - [https://www.bbc.co.uk/news/world-middle-east-57541346](https://www.bbc.co.uk/news/world-middle-east-57541346)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 11:10:48+00:00

Prime Minister Naftali Bennett attacks Iran as a "regime of brutal hangmen" at a cabinet meeting.

## Stoke-on-Trent crash: Girl, 6, killed and father hurt
 - [https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-57544083](https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-57544083)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 10:57:20+00:00

The girl was walking with her father when the pair were reportedly hit by a car, police said.

## DUP leadership: Donaldson favourite as nominations open
 - [https://www.bbc.co.uk/news/uk-northern-ireland-57542596](https://www.bbc.co.uk/news/uk-northern-ireland-57542596)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 10:12:17+00:00

Sir Jeffrey Donaldson has made it clear he intends to lead the party from Stormont as first minister.

## Euro 2020: What England need to change against Czech Republic - Alan Shearer
 - [https://www.bbc.co.uk/sport/football/57542472](https://www.bbc.co.uk/sport/football/57542472)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 10:00:04+00:00

Former England captain and BBC Sport columnist Alan Shearer says now the dust has settled on Friday's disappointing draw with Scotland, there is no need for the Three Lions to panic.

## Sort rape convictions or go, Labour tells Buckland
 - [https://www.bbc.co.uk/news/uk-politics-57542194](https://www.bbc.co.uk/news/uk-politics-57542194)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 09:48:22+00:00

Labour says the justice secretary must resign if he cannot reverse low rape convictions in a year.

## Cummings revelations beyond The Thick of It, says Capaldi
 - [https://www.bbc.co.uk/news/uk-57544203](https://www.bbc.co.uk/news/uk-57544203)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 09:34:23+00:00

Peter Capaldi says his famously abrasive character wouldn't fit into the current government landscape.

## Mayfair 'guardian angel' who saved man's life after stroke found
 - [https://www.bbc.co.uk/news/uk-england-london-57539824](https://www.bbc.co.uk/news/uk-england-london-57539824)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 09:00:40+00:00

Mathew O'Toole's plea to find the woman who saved him was seen by one of her friends on Saturday.

## Gold coins lost in Black Death confusion found in Reepham
 - [https://www.bbc.co.uk/news/uk-england-norfolk-57520248](https://www.bbc.co.uk/news/uk-england-norfolk-57520248)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 06:29:51+00:00

Hardly any of the leopard coins from 1344 have survived, an expert says.

## Are Spurs back to square one in search for new manager?
 - [https://www.bbc.co.uk/sport/football/57537595](https://www.bbc.co.uk/sport/football/57537595)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 05:32:18+00:00

All eyes might be on Euro 2020, but Tottenham's managerial search is also serving up plenty of drama.

## The papers: Fight against more lockdowns and Bercow joins Labour
 - [https://www.bbc.co.uk/news/blogs-the-papers-57542374](https://www.bbc.co.uk/news/blogs-the-papers-57542374)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 05:10:04+00:00

An attempt to limit any further Covid restrictions is among a range of stories on the front pages.

## Outdoor civil weddings and partnerships get the go ahead
 - [https://www.bbc.co.uk/news/uk-57542818](https://www.bbc.co.uk/news/uk-57542818)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 03:01:12+00:00

Non-religious weddings in England and Wales have had to take place indoors until now.

## McIlroy & DeChambeau in hunt as US Open set up beautifully for final day
 - [https://www.bbc.co.uk/sport/golf/57542274](https://www.bbc.co.uk/sport/golf/57542274)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2021-06-20 01:36:29+00:00

Rory McIlroy and Bryson DeChambeau make their move but Richard Bland's challenge fades as the scene is set for a thrilling US Open final day.

