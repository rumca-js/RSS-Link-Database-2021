# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Everybody Wants to Rule the World | Tears for Fears | funk cover ft. Cory Henry
 - [https://www.youtube.com/watch?v=kPDT4SM_WSg](https://www.youtube.com/watch?v=kPDT4SM_WSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2021-06-21 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Tears for Fears' "Everybody Wants to Rule the World" by Scary Pockets & Cory Henry.

MUSICIAN CREDITS
Lead vocal / Keys: Cory Henry
Drums: Louis Cato
Bass: Solomon Dorsey
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Chad Gordon
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Director: Merlin Camozzi
DP: Marc Patterson
Camera Operator: Silvia Lara
Editor: Adam Kritzberg
Lighting Design: Cole Peterson 
Production Design: Justin O’Brien
Tech: Joonas Cohen

Recorded Live at East West in Los Angeles, CA.

#ScaryPockets #Funk #TearsForFears #CoryHenry #EverybodyWantsToRuleTheWorld

