# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## History forgot these old fireworks. We recreated them.
 - [https://www.youtube.com/watch?v=J3F2odr2MsQ](https://www.youtube.com/watch?v=J3F2odr2MsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2021-06-21 00:00:00+00:00

Around the old mining areas of North Wales, you can find rock cannon: old Welsh firework sites. Most of the world has never heard of them: so we recreated them on a test range. • Thanks to Steve from Live Action FX: http://liveactionfx.com/ • Thanks to Owain for the idea!

Edited by Michelle Martin: https://twitter.com/mrsmmartin

Filmed safely: https://www.tomscott.com/safe/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

