# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## The World is Closer Than Ever to WWIII Right Now
 - [https://www.youtube.com/watch?v=m-1PtqJDu10](https://www.youtube.com/watch?v=m-1PtqJDu10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-06-21 00:00:00+00:00

Play Conflict of Nations for FREE on PC or Mobile: 💥  https://con.onelink.me/kZW6/84d44f21
Receive an Amazing New Player Pack, only available for the next 30 days! Thanks to Conflict of Nations for sponsoring this video!

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Video on the US's covert operations: https://youtu.be/vuxsRox7okg

💸 Win $1,000! https://jake.yt/1000 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✨ Follow us on TikTok: https://jake.yt/tiktok
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG for a chance to win $1,000: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/3q7tGNc

-----------------------
All these temptings with fate happened during cold wars. Which brings us to today, with the biggest cold war the world has ever seen, where the players are bigger and more powerful than ever: the US and China. And the geographical center of this new Cold War? The South China Sea

For us in the West, the South China Sea might sound like just some random body of water over in Asia - what’s the big deal? Well, the South China Sea is to China what the Mediterranean Sea was to the Roman Empire. It is one of the most important bodies of water today. Needless to say, whoever controls the South China Sea, will flourish and dominate Asia.

Dividing up land with borders is pretty easy since we live on land so it’s tangible. This meant that every country had the right to everything within 200 nautical miles of their shores. Any area that doesn’t fall within a country’s EEZ is considered international waters and follows UN maritime laws. This is great and all, but the problem comes when you’re dealing with an area like the South China Sea, where multiple countries are right next to each other so all their EEZ’s overlap. But the country with the biggest take on what’s theirs, is China.

China claims that around 90% of the South China Sea is theirs, even though it only borders less than a quarter of the entire area. Since China obviously owns all of these waters and the other surrounding countries have no right to them at all, this has led to some creative aggression from China that has only gotten worse over the years.

For years, the US Air Force had most of its warplanes in just two locations in the western Pacific: Guam and Japan. To counter these two megabases, China simply built a bunch of missiles aimed that the two bases. But with that combined with China’s growing presence in the South China Sea, the US is fanning out its Air Force across the Pacific in preparation for war with China. It’s safe to say that neither side wants war. But that doesn’t mean war will be avoided. 

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

