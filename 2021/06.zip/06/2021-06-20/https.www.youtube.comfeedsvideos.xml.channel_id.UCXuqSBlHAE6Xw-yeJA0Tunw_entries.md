# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This should be illegal… - Manufacturers are swapping SSD components
 - [https://www.youtube.com/watch?v=K07sEM6y4Uc](https://www.youtube.com/watch?v=K07sEM6y4Uc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-21 00:00:00+00:00

Get a Free Pair of Wireless Bluetooth Headphones at Micro Center: https://micro.center/e244f6

Check out the Micro Center Custom PC Builder: https://micro.center/0fb9b8
Join the Micro Center Community: https://micro.center/057537

Add Honey for FREE and start saving today at https://joinhoney.com/ltt
Thanks, Honey for sponsoring!

Bait & switch is a common deception technique that's as old as time itself, but usually it's only seen being done by bad actors. What if I told you that this is happening today, right now, on sites like Amazon and Newegg, with some of the best selling SSDs?

Discuss on the forum: https://linustechtips.com/topic/1349334-this-should-be-illegal%E2%80%A6-manufacturers-are-swapping-ssd-components/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:50 The SX8200 Pro's claims
2:32 Reddit 
3:16 What actually determines SSD performance?
4:52 Our drive variants
5:57 Benchmarks
7:06 Why is ADATA doing this?
8:42 The core issue
9:25 This has happened before
10:27 Should SSDs have a performance standard?
11:58 Outro

## The longest unboxing we've ever done. - Tormach CNC Mill Commissioning
 - [https://www.youtube.com/watch?v=cATjlaTS7uI](https://www.youtube.com/watch?v=cATjlaTS7uI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-20 00:00:00+00:00

Check out the Hammer Fidget Spinner Artizen Keycap from Drop at https://dro.ps/ltt-spinner-21

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Our new CNC milling machine runs... Linux? We're gonna give you the ins-and-outs of this huge 10,000RPM toolchanging beast of a machine that took us nearly a month to build.

Check out Tormach's 1100MX CNC Mill at https://hubs.ly/H0LmXww0

Check out Saunders Machine Works' Fixturing Plates at https://lmg.gg/nPUFc

Buy Kurt DX6 Vise
On Amazon (PAID LINK): https://geni.us/0FWb669
On Newegg (PAID LINK): https://geni.us/Ka8bSkw

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1348916-the-longest-unboxing-weve-ever-done-tormach-mill-commissioning/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:18 You dropped this in Black Mesa 
3:00 It moves!
3:58 Finishing Touches
4:52 The PC hardware
5:42 Motion Control cabinet
7:05 Servos
7:39 Spindle and Toolchanger 
8:54 Interface and Pathpilot
10:30 DJ TechTips
10:49 Workholding and 4th Axis
12:22 Why does it cost what it does?
13:15 Making chips

