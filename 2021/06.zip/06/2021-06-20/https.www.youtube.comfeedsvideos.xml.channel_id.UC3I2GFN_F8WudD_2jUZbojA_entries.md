# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Cassandra Jenkins - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Pg_ijQmHVPo](https://www.youtube.com/watch?v=Pg_ijQmHVPo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-06-21 00:00:00+00:00

http://KEXP.ORG presents Cassandra Jenkins sharing a live performance recorded exclusively for KEXP at talking to Cheryl Waters. Recorded June 8, 2021.

Songs:
Michelangelo
Crosshairs
New Bikini
Hard Drive
The Ramble

Cassandra Jenkins - vocals, guitar
Doug Wieselman - piano, sax, bass clarinet
Adam Brisbin - Guitar
Wyndham Boylan Garnett - Video

https://cassandrajenkins.com
http://kexp.org

