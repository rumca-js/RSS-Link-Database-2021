# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 UNSETTLING Strangers Spotted in Open World Games
 - [https://www.youtube.com/watch?v=0x5wfJt2doE](https://www.youtube.com/watch?v=0x5wfJt2doE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-21 00:00:00+00:00

Some open world games have some really random scary people and places waiting to be found. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Players We CAN'T LIVE WITHOUT in Multiplayer Games
 - [https://www.youtube.com/watch?v=eAQA1zjzUTA](https://www.youtube.com/watch?v=eAQA1zjzUTA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-20 00:00:00+00:00

Who you get paired with in multiplayer games can be a bit of a crapshoot...but sometimes somebody great comes along.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

