# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Gary Louris - Virtual Session with The Current
 - [https://www.youtube.com/watch?v=qkFFG30Z6rk](https://www.youtube.com/watch?v=qkFFG30Z6rk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-21 00:00:00+00:00

Founding member of @jayhawksofficial, Gary Louris joins us for a virtual session to play songs from his second solo record, 'Jump For Joy' which came out this month. Gary chats with Mary Lucia about navigating quarantine as an artist, how he approaches his writing and recording in his solo work, and what's in store for his projects next.

Songs Played: 
02:30 Follow
12:45 Too Late To Key
24:55 Almost Home
36:13 Bitter Pill (by The Jayhawks) 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/​

