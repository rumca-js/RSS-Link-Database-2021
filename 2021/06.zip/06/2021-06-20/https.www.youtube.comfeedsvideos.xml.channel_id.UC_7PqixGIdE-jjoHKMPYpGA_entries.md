# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Ilu z nas to geje i lesbijki?
 - [https://www.youtube.com/watch?v=JrC1TGNJ5Zw](https://www.youtube.com/watch?v=JrC1TGNJ5Zw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2021-06-21 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Obejrzałem ostatnio długi wywiad z pewnym trendującym politykiem. Zmotywował mnie on do poruszenia pewnego tematu, który dojrzewał u mnie w głowie latami...

🎞 Moje filmy o homoseksualizmie:
https://www.youtube.com/watch?v=tmvH9Ou54F4
https://www.youtube.com/watch?v=VXNKmidjDwU

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 A Sławomir Mentzen powiedział...
4:40 Problemy z poszukiwaniem odpowiedzi
8:15 Zero absolutne
11:28 Idealna ankieta nie ist...
15:39 Zderzenie z rzeczywistością

===
Źródła (wybrane):

J.M. Baley i in. - Sexual Orientation, Controversy, and Science
S. Stephenson-Davidowitz - Everybody Lies
C. Caceres i in. - Estimating the number of men who have sex with men in low and middle income countries

https://www.npr.org/2011/06/08/137057974/-institute-of-medicine-finds-lgbt-health-research-gaps-in-us?t=1622542959495
https://williamsinstitute.law.ucla.edu/publications/how-many-people-lgbt/
https://en.wikipedia.org/wiki/Demographics_of_sexual_orientation
https://en.wikipedia.org/wiki/LGBT_demographics_of_the_United_States#2021
https://static1.squarespace.com/static/51d894bee4b01caf88ccb4f3/t/539722e8e4b067f59011f01e/1402413800945/CDCPresentation.pdf

