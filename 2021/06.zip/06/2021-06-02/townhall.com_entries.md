## We Now Know Why Facebook May Have Censored the Lab Leak Theory
 - [https://townhall.com/tipsheet/katiepavlich/2021/06/02/we-now-know-why-facebook-may-have-censored-the-lab-leak-theory-n2590360](https://townhall.com/tipsheet/katiepavlich/2021/06/02/we-now-know-why-facebook-may-have-censored-the-lab-leak-theory-n2590360)
 - RSS feed: townhall.com
 - date published: 2021-06-02 06:52:01+00:00



