# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Conservative Comedy Writers VS. Liberal Comedy Writers FIGHT
 - [https://www.youtube.com/watch?v=C0xeqOqpekE](https://www.youtube.com/watch?v=C0xeqOqpekE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-06-03 00:00:00+00:00

Comedy is a fight! And it's conservative vs liberal. Can these conservative comedy writers think up a third joke? Of course not. If only they were liberal comedy writers with their wide variety of jokes!

Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com​​​​

Follow The Babylon Bee:
Website: https://babylonbee.com​​​​
Twitter: http://twitter.com/thebabylonbee​​​​
Facebook: http://facebook.com/thebabylonbee​​​​
Instagram: http://instagram.com/thebabylonbee​

## Wuhan Lab Changes Sign To '0 Days Since Accidentally Releasing A Virus'
 - [https://www.youtube.com/watch?v=pfUi0BjIzOM](https://www.youtube.com/watch?v=pfUi0BjIzOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2021-06-02 00:00:00+00:00

Was Covid-19 created in a laboratory? Did it originate in Wuhan? Will this man get to finish his bat sandwich? Watch, like and subscribe to find out!

Become a Premium Subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com​​​​

Follow The Babylon Bee:
Website: https://babylonbee.com​​​​
Twitter: http://twitter.com/thebabylonbee​​​​
Facebook: http://facebook.com/thebabylonbee​​​​
Instagram: http://instagram.com/thebabylonbee​

