## A Virginia Teacher Was Put On Leave After Opposing New Rights For Trans Students
 - [https://www.npr.org/2021/06/02/1002479412/a-virginia-teacher-was-put-on-leave-after-opposing-a-new-policy-for-trans-studen](https://www.npr.org/2021/06/02/1002479412/a-virginia-teacher-was-put-on-leave-after-opposing-a-new-policy-for-trans-studen)
 - RSS feed: https://www.npr.org
 - date published: 2021-06-02 21:17:09+00:00

A Virginia Teacher Was Put On Leave After Opposing New Rights For Trans Students

