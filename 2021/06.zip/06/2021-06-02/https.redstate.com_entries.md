## Fauci's Emails Expose His Lies About Masks in Stunning Fashion – RedState
 - [https://redstate.com/bonchie/2021/06/02/faucis-emails-expose-his-lies-about-masks-in-stunning-fashion-n390282](https://redstate.com/bonchie/2021/06/02/faucis-emails-expose-his-lies-about-masks-in-stunning-fashion-n390282)
 - RSS feed: https://redstate.com
 - date published: 2021-06-02 19:28:27+00:00

Fauci's Emails Expose His Lies About Masks in Stunning Fashion – RedState

