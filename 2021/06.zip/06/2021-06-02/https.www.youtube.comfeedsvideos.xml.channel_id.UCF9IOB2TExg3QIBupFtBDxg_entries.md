# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## International vaccine implications
 - [https://www.youtube.com/watch?v=YqK77o_ve4g](https://www.youtube.com/watch?v=YqK77o_ve4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-06-02 00:00:00+00:00

WHO

https://www.dw.com/en/coronavirus-who-approves-sinovac-covid-vaccine-for-emergency-use/a-57750495

Approved Sinovac Biotech (CoronaVac) for emergency use

Supplying Cambodia
 
Inactivated 
 
Grown in cell cultures, monkey kidney cells

Beta-propiolactone

Replication deficient

Proteins remain intact

Two dose

Now part of COVAX, but no deal yet

Capacity, 2 billion doses per year

Phase 3 data, efficacy, 51 – 91% in blocking infections

Turkey, efficacy, 91.25% 

Brazil, 51%

Brazil, 83.7% in preventing medical treatment

Brazil, all deaths

Indonesia, HCWs, n = 120,000, 94% effective at preventing symptomatic illness

Sinopharm (inactivated) already approved in April

Others WHO approved

BioNTech-Pfizer, Moderna, AstraZeneca, Johnson & Johnson.

Secretary of State Antony Blinken

https://www.washingtonpost.com/national-security/blinken-coronavirus-latin-america/2021/06/01/b5ed2e10-c32c-11eb-8c18-fd53a628b992_story.html

Global distribution soon

Latin America

China, 165 million doses to Latin America and Caribbean

Sometime in the next week to two weeks we will be announcing the process by which we will distribute those vaccines

President Biden, 80 million global doses by end of June

China

https://www.washingtonpost.com/nation/2021/06/02/coronavirus-covid-live-updates-us/

May 31, 22.3 million doses given

Doses so far, 660 million

Beijing’s vaccination program got off to a slow start but has rapidly picked up pace: 

China now six times faster than US peak in April

Strict border controls still in place

North Korea 

https://www.reuters.com/article/health-coronavirus-northkorea/update-1-skorea-says-vaccine-shipment-to-nkorea-from-covax-delayed-again-idUSL2N2NK01H

South Korea COVAX delivery not made yet

2 million doses of AstraZeneca

Global Alliance for Vaccines and Immunization (GAVI)

Future Proof report (Centre for Long-Term Resilience)

https://drive.google.com/file/d/1LHn3nzxF2p68SfhwiPLCb5FMaMLq1dk6/view

Extreme risks

Global catastrophic risks

Existential risks

Specific risks

Biosecurity

Artificial intelligence

Climate change

Nuclear security

Biosecurity

DNA synthesis machines

Gene editing

Gain of function

Thrombocytopenia in mice reported in 2006

Blood, (2006)

https://ashpublications.org/blood/article/109/7/2832/125650/Adenovirus-induced-thrombocytopenia-the-role-of

Thrombocytopenia has been consistently reported following the administration of adenoviral gene transfer vectors. 

All mice received virus through a single tail vein injection

