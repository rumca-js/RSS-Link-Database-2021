# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## The Twilight Hours - three songs at the Minnesota State Fair (2016)
 - [https://www.youtube.com/watch?v=4z1CKSQQIlI](https://www.youtube.com/watch?v=4z1CKSQQIlI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-03 00:00:00+00:00

Eleven years ago this week, the Twilight Hours performed live in The Current studio. Although we don't have video from that performance, here are three songs by Twilight Hours recorded live before an audience at the MPR Booth at the Minnesota State Fair in 2016. You can feel the energy of the live audience as The Twilight Hours play songs from their 2016 album "Black Beauty." 

SONGS PERFORMED
0:00 "Maybe"
4:05 "Rain"
7:44 "Sioux City Swinger"

PERSONNEL
Matt Wilson – vocals, guitar
John Munson – vocals, bass
Richard Medek – drums
Dave Salmela – keyboards, vocals
Jacques Wait – guitar

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark; Michael "Ozzie" Osborne
Production: Anna Weggel

FIND MORE:
2009 studio session: https://www.thecurrent.org/feature/2009/06/02/the_twilight_hours
2010 studio session: https://www.thecurrent.org/feature/2010/01/08/the-twilight-hours
2011 State Fair session:
https://www.thecurrent.org/feature/2011/08/26/twilight-hours-msf
2016 full State Fair session, including interview:
https://youtu.be/RQw_Xr07bdI 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#thetwilighthours #thecurrent #minnesotastatefair

## Listen to Looch: 'Halston' captures iconic fashion designer's life amid '70s excess
 - [https://www.youtube.com/watch?v=m_6JLR0gQec](https://www.youtube.com/watch?v=m_6JLR0gQec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-02 00:00:00+00:00

The Netflix miniseries "HALSTON" follows the legendary fashion designer (played by Ewan McGregor), as he turns his single, invented name into a worldwide fashion empire.

McGregor is "one of my favorite actors," Mary says. "He's completely fearless."

Mary says you don't even need to be into fashion to appreciate the story. "Just to see how McGregor portrays Halston through the sort of progression of his horrifying cocaine addiction and his claim to fame and people trying to take [his name] away from him," Mary explains. "Think about that: What is it like? Maybe that's sometimes all you feel like you have is your name.

"It's so worth watching."

"HALSTON" also features Krysta Rodriguez as Halston's muse, Liza Minelli. The series is directed by Daniel Minahan, and it is streaming now on Netflix.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#marylucia #halston #netflix

