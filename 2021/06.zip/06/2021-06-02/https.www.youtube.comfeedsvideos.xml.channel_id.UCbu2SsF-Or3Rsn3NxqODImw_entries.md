# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Mario Golf: Super Rush - The Final Preview
 - [https://www.youtube.com/watch?v=lmAt_t171ZM](https://www.youtube.com/watch?v=lmAt_t171ZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-03 00:00:00+00:00

Nintendo's new Mario Golf game for Switch injects even more action into the sport.

You can read the full written preview by Kevin Knezevic on GameSpot: https://www.gamespot.com/articles/mario-golf-super-rushs-speed-golf-mode-looks-chaotic-in-the-best-way/1100-6492312/

Mario Golf: Super Rush will release on June 25th exclusively for Nintendo Switch. This is the first full Mario Golf game since Mario Golf: World Tour on the Nintendo 3DS, and the first home console Mario Golf game since Mario Golf: Toadstool Tour on the Nintendo GameCube. For more on Mario Golf: Super Rush, including our review, stay right here on GameSpot.

