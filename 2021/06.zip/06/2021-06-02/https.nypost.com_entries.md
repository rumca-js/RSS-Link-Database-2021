## Fauci was warned that COVID-19 may have been ‘engineered,’ emails show
 - [https://nypost.com/2021/06/02/fauci-was-warned-that-covid-may-have-been-engineered-emails/](https://nypost.com/2021/06/02/fauci-was-warned-that-covid-may-have-been-engineered-emails/)
 - RSS feed: https://nypost.com
 - date published: 2021-06-02 07:23:57+00:00

Fauci was warned that COVID-19 may have been ‘engineered,’ emails show

