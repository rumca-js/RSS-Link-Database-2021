# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Addressing my Bad Take on RTX 3080 Ti - WAN Show Jun 4, 2021
 - [https://www.youtube.com/watch?v=PkJYWMStLRA](https://www.youtube.com/watch?v=PkJYWMStLRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-04 00:00:00+00:00

Help your IT team take care of support, maintenance, and security for Enterprise Linux systems with TuxCare at https://hubs.ly/H0NDWk10

Save 10% at Ridge Wallet with offer code WAN at https://www.ridge.com/WAN

Buy a Seasonic Ultra Titanium PSU
On Amazon: https://geni.us/q4lnefC
On Newegg: https://lmg.gg/8KV3S

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Addressing-my-Bad-Take-on-RTX-3080-Ti---WAN-Show-Jun-4--2021-e12b0fl

Check out Other Podcasts:
Carpool Critics Movie Podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Kaspar Zubarev)
2:16 - Sponsors
2:30 - About the review
11:40 - Nvidia's MSRP is bull***t
15:20 - Secondary market is more "fair"
17:30 - Does 3080 for $700 exist?
22:00 - Founder's are not an easy catch
27:45 - Budget gamers suffer
29:50 - Some thoughts about comments
35:20 - Linus explodes and roasts Nvidia
39:15 - AMD time and FSR
47:50 - New APUs
57:20 - Don't buy top-tier for future-proofing
59:56 - surprise phonecall
1:10:08 - NUC coverage

## Running a YouTube Business is EASY (just kidding)
 - [https://www.youtube.com/watch?v=gC6dQrScmHE](https://www.youtube.com/watch?v=gC6dQrScmHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2021-06-03 00:00:00+00:00

Thanks to monday.com for sponsoring this video! Get a 30 day Pro plan trial for free at https://lmg.gg/G4WPB

In this video, we follow a typical week at LMG as the team works to shoot all the Linus Tech Tips, ShortCircuit, and TechQuickie videos that our fans expect.


Discuss on the forum: https://linustechtips.com/topic/1344340-how-we-make-17-videos-a-week/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Check out our podcast gear: https://kit.co/linustechtips/lmg-podcast-gear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►Official Game Store: https://www.nexus.gg/ltt
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:29 Tuesday
7:42 Wednesday
11:29 Thursday
16:35 Friday
18:55 Conclusion

