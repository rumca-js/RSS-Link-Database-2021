# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## This is how the government robs the innocent | Civil Asset Forfeiture
 - [https://www.youtube.com/watch?v=ZWvh8Ttd9eA](https://www.youtube.com/watch?v=ZWvh8Ttd9eA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-06-04 00:00:00+00:00

The government can take anything from you for no reason - your cash, cars, even your entire home. It's called civil asset forfeiture. 
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F


Not to be confused with criminal forfeiture, which requires conviction of a defendant with proof beyond reasonable doubt, civil asset forfeiture allows the government to take your money or property of whatever value or amount, without you ever being convicted, charged, investigated or prosecuted. It is a civil action against an object, not a person, so no evidence of crime needs to be provided. Whatever the government takes is immediately put to use, auctioned for sale or kept for their own use if they like your stuff. 

Sources
Reports from the Justice Department can be found here: https://www.justice.gov/afp/reports-0
2020 DoJ Annual report https://www.justice.gov/afms/fy2020-asset-forfeiture-fund-reports-congress

Christian charity's assets forfeited https://www.washingtonpost.com/news/wonk/wp/2016/04/25/how-oklahoma-cops-took-53000-from-a-burmese-christian-band-a-church-in-omaha-and-an-orphanage-in-thailand/
Seizing prepaid cards https://oklahomawatch.org/2016/06/07/new-front-in-civil-forfeiture-okla-authorities-get-devices-to-seize-funds-loaded-onto-prepaid-cards/
https://www.huffpost.com/entry/oklahoma-police-erad_n_57584060e4b0e39a28ac2083
https://oklahomawatch.org/2016/06/13/highway-patrol-defends-use-of-prepaid-card-readers-blasts-internet-assassinations/
https://www.huffpost.com/entry/bob-colbert-oklahoma-civil-forfeiture_n_56fe92bce4b083f5c6077acf

Abuse in spending https://oklahomawatch.org/2015/07/15/law-enforcement-seizures-misspent-missing/
Oklahoma Sheriff extortion https://www.oklahoman.com/article/5488745/grand-jury-indicts-wagoner-county-sheriff-calls-for-his-removal?
Oklahoma audit on seized assets https://oklahomawatch.org/2015/07/15/audit-findings-for-seized-assets/
https://www.ajc.com/news/local-govt--politics/feds-want-reimbursement-for-gwinnett-sheriff-70k-muscle-car/zkOidGb5oRfCHGO5RlZGsL/

Civil Asset Forfeiture explained https://drugpolicy.org/sites/default/files/Drug_Policy_Alliance_Above_the_Law_Civil_Asset_Forfeiture_in_California.pdf
https://www.washingtonpost.com/investigations/holder-ends-seized-asset-sharing-process-that-split-billions-with-local-state-police/2015/01/16/0e7ca058-99d4-11e4-bcfb-059ec7a93ddc_story.html
https://www.washingtonpost.com/sf/investigative/collection/stop-and-seize-2/
https://www.newyorker.com/magazine/2013/08/12/taken
https://www.washingtonpost.com/sf/investigative/2014/09/07/police-intelligence-targets-cash/
https://www.nytimes.com/2019/02/20/us/politics/civil-asset-forfeiture-supreme-court.html?
https://www.propublica.org/article/law-to-clean-up-nuisances-costs-innocent-people-their-homes
https://ij.org/issues/private-property/civil-forfeiture/

IRS forfeiture https://www.washingtonpost.com/opinions/george-f-will-the-heavy-hand-of-the-irs/2014/04/30/7a56ca9e-cfc5-11e3-a6b1-45c4dffb85a6_story.html
US law lets government seize bank accounts with no crime required https://www.nytimes.com/2014/10/26/us/law-lets-irs-seize-accounts-on-suspicion-no-crime-required.html?_r=0 

Civil asset forfeiture doesn't help limit crime 
https://www.propublica.org/article/police-say-seizing-property-without-trial-helps-keep-crime-down-a-new-study-shows-theyre-wrong
https://www.washingtonpost.com/opinions/2019/06/11/study-civil-asset-forfeiture-doesnt-discourage-drug-use-or-help-police-solve-crimes/

FBI forfeiture of safe deposit boxes
https://reason.com/2021/05/10/the-fbi-seized-heirlooms-coins-and-cash-from-hundreds-of-safe-deposit-boxes-in-beverly-hills-despite-knowing-some-belonged-to-honest-citizens/

Illegal forfeiture cases
https://detroitnews.com/story/news/local/wayne-county/2018/12/06/suit-alleges-cops-illegally-seized-car-after-10-marijuana-buy/2218849002/

How asset forfeiture funds police budgets https://www.washingtonpost.com/sf/investigative/2014/10/11/asset-seizures-fuel-police-spending/

Police confiscates more than burglars steal https://www.washingtonpost.com/news/wonk/wp/2015/11/23/cops-took-more-stuff-from-people-than-burglars-did-last-year/?

Wish lists of police departments https://www.nytimes.com/2014/11/10/us/police-use-department-wish-list-when-deciding-which-assets-to-seize.html

Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

