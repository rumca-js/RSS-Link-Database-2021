# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## Zoom Education Has Failed An Entire Generation
 - [https://www.youtube.com/watch?v=mZTvHofa6Q4](https://www.youtube.com/watch?v=mZTvHofa6Q4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2021-06-04 00:00:00+00:00

As schools slowly return to in person classes, the education system and the students in it will never be the same. A year of Zoom classes and Google Meetings has forced teachers and students to adapt to more efficient means of learning at the cost of abandoning social circles. I interviewed students, teachers, and experts to help illuminate the uncertain future of education.

SPECIAL THANKS:

Intro animation made by Kobayashi'sEgo
https://twitter.com/KobayashisEgo

Song: Rock It On by Hideki Naganuma
https://www.youtube.com/watch?v=WhcNnZxop74

8 bit Cover of Campus by Vampire Weekend
Chiptune Planet:
https://youtu.be/3X4diGglhNY

Troublemaker Cover produced by Shuler, performed by Slush

"Social Games" song: Internet Friends by Negative XP

The G-Links:

https://twitter.com/GlinkLive
Twitter, where I publish all my hot takes and dank memes

https://www.reddit.com/r/glink/
Reddit, nobody uses this, but you can post memes here

https://www.instagram.com/glink_between_worlds/
Instagram, this is where things get real  a e s t h e t i c 

https://discord.gg/xtwYypf
My Discord, only for REAL gamers

https://www.patreon.com/Glink
Support me on Patreon and be included in Q & As, audio updates, discord roles, and credits at the end of my videos 

https://teespring.com/stores/shop-glink
Want to look fly while supporting my channel? Buy a T-shirt or poster here, all designs are custom made and completely original, not mention tasteful and artistic

https://www.youtube.com/channel/UChJT4Jg89AHMyybcXFeKp_A
My podcast with Slush

