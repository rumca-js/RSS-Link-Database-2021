# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Rick Doblin on Treating PTSD with MDMA Therapy
 - [https://www.youtube.com/watch?v=rcuGYKvvJEc](https://www.youtube.com/watch?v=rcuGYKvvJEc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-04 00:00:00+00:00

Taken from JRE #1661 w/Rick Doblin:
https://open.spotify.com/episode/1Z8lzhvHCMv0c8qZWXbzzK?si=f1J1bLg1Q0GsR4qlXowyyw

## Rick Doblin's DMT Realization About Hilter
 - [https://www.youtube.com/watch?v=Gd92fg1VWyU](https://www.youtube.com/watch?v=Gd92fg1VWyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-04 00:00:00+00:00

Taken from JRE #1661 w/Rick Doblin:
https://open.spotify.com/episode/1Z8lzhvHCMv0c8qZWXbzzK?si=f1J1bLg1Q0GsR4qlXowyyw

## David Lee Roth on the Origins of Van Halen
 - [https://www.youtube.com/watch?v=BoxXHTUPnJA](https://www.youtube.com/watch?v=BoxXHTUPnJA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-03 00:00:00+00:00

Taken from JRE #1660 w/David Lee Roth:
https://open.spotify.com/episode/7sSZQWUuvPfoqGU0RBoqiR?si=h3vb40kpQb-D0qb6SMpzwg

