# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Got Vaxxed?
 - [https://www.youtube.com/watch?v=M9aa_4qBpEU](https://www.youtube.com/watch?v=M9aa_4qBpEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2021-06-03 00:00:00+00:00

Get Surfshark VPN at https://surfshark.deals/nolke - Enter promo code NOLKE for 83% off and 3 extra months for FREE!

Donate to COVAX and help get the vaccine to those who need them most:
https://www.gavi.org/donate
https://www.unicef.org/supply/covax-ensuring-global-equitable-access-covid-19-vaccines

Written by: Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke

