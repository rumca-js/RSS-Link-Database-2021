# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## CDPROJEKT RED STARTS NEXT AAA GAME, E3 2021 BIGGEST LEAKS, & MORE
 - [https://www.youtube.com/watch?v=2f7SJMyX3kA](https://www.youtube.com/watch?v=2f7SJMyX3kA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-04 00:00:00+00:00

The E3 2021 rumors keep rolling in, AMD is finally releasing their open upscaling graphics tech to compete with Nvidia, Switch Pro is happening, and more in a week full of gaming news.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​

Jake’s other channel:
https://youtu.be/Y40h9NCi6co



 ~~~~STORIES~~~~



AMD rolling out Fidelity FX
https://youtu.be/eHPmkJzwOFc
https://www.overclock3d.net/news/gpu_displays/it_s_official_amd_s_fidelityfx_super_resolution_technology_is_coming_soon/1


3080 TI
https://www.theverge.com/2021/6/1/22461660/nvidia-geforce-rtx-3080-ti-specs-price-release-date-features

CD Projekt Red
https://www.dualshockers.com/cd-projekt-reds-next-game-already-in-the-works-according-to-job-listing/

God of War 2022 (also will be on PS4)
https://twitter.com/SonySantaMonica/status/1400135437763584002
https://www.theverge.com/2021/6/2/22465232/god-of-war-ragnorok-ps5-ps4-delay-2022



More Switch Pro rumors
https://www.gizmochina.com/2021/06/04/nintendo-switch-pro-spotted-french-retailers-listing/
https://www.gamesradar.com/nintendo-switch-pro-reveal-is-supposedly-coming-this-week/



2k leaks
https://venturebeat.com/2021/06/03/xcom-style-avengers-game-from-2k-is-real-so-is-the-rest-of-the-leak/
https://screenrant.com/guardians-galaxy-game-reveal-rumored-e3-2021/




More No Man’s Sky (Prisms)
https://twitter.com/NoMansSky/status/1400074728249909248?s=20

Crysis Remastered trilogy
https://www.youtube.com/watch?v=nQVzmXDFxVY

Chivalry 2 launch trailer
https://youtu.be/HKlYVpCuab0

Psychonauts 2 gameplay
https://youtu.be/lgqvv33oXxo

Cool Ghosts trick
https://www.reddit.com/r/ghostoftsushima/comments/ns28sf/the_freerange_camera_glitch_allows_seeing/




New Warhammer 40k game
https://www.eurogamer.net/articles/2021-06-03-warhammer-40-000-chaos-gate-daemonhunters-is-a-turn-based-tactical-rpg


Funny Tesla thing
https://www.techradar.com/in/news/teslas-new-in-car-gaming-system-is-basically-a-mini-ps5

## Dying Light 2 - 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=rXoQaF7FM64](https://www.youtube.com/watch?v=rXoQaF7FM64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-03 00:00:00+00:00

Dying Light 2 (PC , PS5, Xbox Series X/S/ One, PS4) finally finally gave us tons of new information, including a release date. Here's everything you need to know.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


Additional sources:
https://wccftech.com/dying-light-2-is-strongly-connected-to-events-in-the-first-game-gre-organization-will-be-featured-in-the-sequel/
https://segmentnext.com/2021/06/01/dying-light-2-blueprints-upgraded/

