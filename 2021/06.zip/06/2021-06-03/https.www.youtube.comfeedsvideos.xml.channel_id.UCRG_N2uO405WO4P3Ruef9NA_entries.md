# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## HarmonyOS is official: I decoded the marketing BS
 - [https://www.youtube.com/watch?v=DLc-sp6FuWo](https://www.youtube.com/watch?v=DLc-sp6FuWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-06-04 00:00:00+00:00

Sponsored by ExpressVPN. Get 3 months for free at https://expressvpn.com/fridaycheckout

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
►►► This video ◄◄◄

This week, Huawei officially released HarmonyOS and it's still mostly Android in disguise, AMD announced their collaboration with Samsung's Exynos chips, and Google copied some of Apple's best privacy practices in Android.

Episode 50

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd

Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-harmonyos-is-official-i-decoded-the-marketing-bs

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
►►► Other TechAltar links ◄◄◄


Merch: http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:37 Release Monitor
2:00 HarmonyOS - decoded
7:32 AMD x Exynos
8:53 Android privacy updates

