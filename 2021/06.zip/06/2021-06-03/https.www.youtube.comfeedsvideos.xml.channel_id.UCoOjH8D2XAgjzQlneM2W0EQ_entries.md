# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Boxing is getting out of hand...
 - [https://www.youtube.com/watch?v=qh_Jm8d31_M](https://www.youtube.com/watch?v=qh_Jm8d31_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2021-06-04 00:00:00+00:00

The first 5000 to sign-up using this link https://faves.media/signup?r=jaketran will get early access to the Faves app! Sign up before everyone else floods in 🔥

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

💸 Win $1,000! https://jake.yt/1000 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✨ Follow us on TikTok: https://jake.yt/tiktok
🎙️ Subscribe to the 2nd channel, Intellectual Dropouts: https://jake.yt/id
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: https://bit.ly/3z1jJVD

-----------------------
Floyd Mayweather is set to make an estimated $100,000,000 from his fight with Logan Paul. Cementing his position as one of the highest paid athletes in history. Logan Paul on the other hand is set to make $20,000,000, a fifth of what Mayweather gets.

At its most basic level, you have a boxing match, the Mayweather Paul fight, and each boxing match has a prize money pool that both fighters get a cut of no matter who wins. That prize money is also called the Purse. For the infamous Floyd Mayweather vs Manny Pacquiao fight back in 2015, that purse was reportedly half a billion dollars. In the case of the Mayweather vs Paul fight, the purse is an estimated $100m. But in this case, Mayweather gets not 60% of that purse, but 80%, or $80m. While Logan Paul only gets to walk away with $20m. Why the uneven split? Simple - it’s because the prize money is made up how many people buy the pay-per-view show, ticket sales, and other broadcasts.

The first rumblings of a Mayweather/Pacquiao fight was way back in 2010. It took 5 whole years of trash talking, going back and forth, negotiating the prize money split, before the fight actually happened in 2015. In the business of boxing, everything leading up to the fight is theatre - both fighters have to do their part in making the fight marketable. Which usually includes a lot of trash talking and drama. So trash talk your way to a giant purse then walk home with $100m right?

As a football star in the NFL, your life is a lot easier. But as a boxer, you are literally your own business. You get paid as an independent contractor per fight, no regular paychecks, you don’t work for any of the boxing event promoters - If you don’t fight you don’t get paid.

Fans want to see the most dangerous, exciting fights. But Floyd realized that it was in his best interests to take on the least riskiest fights. Instead of going up against Pacquiao in his prime, Floyd waited 5 years for him to age a little, get a little worn down, build up more and more hype to increase that prize money. And then he fought a more tamed version of Pacquiao 5 years later and walked away with $100m.

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

