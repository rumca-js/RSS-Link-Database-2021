# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## How I accidentally discovered the biggest fraud of all time
 - [https://www.youtube.com/watch?v=RzBNKat9FRU](https://www.youtube.com/watch?v=RzBNKat9FRU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-06-04 00:00:00+00:00

Things are changing...🤖
Follow Coffeezilla
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1

Graphics Credit: Be Memorable on Youtube https://www.youtube.com/channel/UCbpjIfPcfm8GaHBWzW7pQTw

Robot Voice Acted by Technicals 
https://www.youtube.com/channel/UCZtN8iRZLufjebiFLkkWe4A

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.
#coffeezilla #fraud #robot

## I was Forced to Make This Video
 - [https://www.youtube.com/watch?v=XfmK1JD-Jbk](https://www.youtube.com/watch?v=XfmK1JD-Jbk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-06-03 00:00:00+00:00

🖱️🐛 
I'm no longer the owner of the safest galaxy domain! I forgot to renew it, lol. 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

