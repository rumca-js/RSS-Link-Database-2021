# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## 77 - 81 Gang of Four box set unboxing
 - [https://www.youtube.com/watch?v=DW-tetI-v4Y](https://www.youtube.com/watch?v=DW-tetI-v4Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

With the release of "77-81," Gang of Four have put together one of the best vault boxsets this side of Prince, featuring their first two studio albums along with bonus singles, a live concert recording, and an incredible photo book, documenting the post-punk band that would go on to influence everyone from Tom Morello to Flea to El-P from Run the Jewels. 

Jim McGuinn, host of "Teenage Kicks" on The Current, unboxes 77-81.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#gangoffour #boxset #unboxing

## Death Cab for Cutie - two live performances (2019)
 - [https://www.youtube.com/watch?v=If4zh-NdnAA](https://www.youtube.com/watch?v=If4zh-NdnAA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

This week in 2008, Death Cab for Cutie performed in our studio. Although we don't have footage from that session 13 years ago, we've had the pleasure of recording a number of performances by Death Cab for Cutie in our building as well as at the Palace Theatre in St. Paul. These two performances come from a Live From Here episode recorded live at the Durham Performing Arts Center (the "DPAC") in Durham, N.C., in 2019. Death Cab for Cutie perform songs from their 2018 album, "Thank You for Today." 

SONGS PERFORMED
0:00 "Northern Lights"
3:42 "60 & Punk"

PERSONNEL
Ben Gibbard – vocals, guitar
Dave Depper – guitar
Zac Rae – piano

CREDITS
Video & Photo: Ben Miller; American Public Media
Audio: Sam Hudson; American Public Media
Production: Tom Campbell; Jeffy Hnilicka; American Public Media

FIND MORE:
2008 studio session: https://www.thecurrent.org/feature/2008/06/02/death_cab_for_cutie
2015 studio session: https://www.thecurrent.org/feature/2015/05/05/death-cab-for-cutie-ben-gibbard-performs-in-the-current-studio
2018 MicroShow in the MPR Forum:
https://www.thecurrent.org/feature/2018/09/24/death-cab-for-cutie-perform-a-microshow-in-the-forum-at-mpr
2018 Palace Theatre concert:
https://www.thecurrent.org/feature/2018/10/06/watch-death-cab-for-cutie-live-in-concert-at-the-palace-theatre

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#deathcabforcutie #bengibbard

## Real Estate - Half a Human (live performance for The Current)
 - [https://www.youtube.com/watch?v=4rL0Eeo2rAE](https://www.youtube.com/watch?v=4rL0Eeo2rAE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Recorded live for The Current, watch @realestateband perform their 2021 track, "Half a Human," the title track from their latest EP. 

Don't miss Real Estate's full virtual session including an interview with Martin Courtney and Mary Lucia about pandemic scones, getting to stay home for a bit, and the perfect place to watch a Real Estate show: https://youtu.be/-bxkOpYLxa0

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Real Estate - Ribbon (live performance for The Current)
 - [https://www.youtube.com/watch?v=c45iSfc_hZQ](https://www.youtube.com/watch?v=c45iSfc_hZQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Recorded live for The Current, watch  @realestateband  perform their 2021 track, "Ribbon," the title track from their latest EP, 'Half a Human'. 

Don't miss Real Estate's full virtual session including an interview with Martin Courtney and Mary Lucia about pandemic scones, getting to stay home for a bit, and the perfect place to watch a Real Estate show: https://youtu.be/-bxkOpYLxa0

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Real Estate - Stained Glass (live performance for The Current)
 - [https://www.youtube.com/watch?v=QBjX_0qy3iM](https://www.youtube.com/watch?v=QBjX_0qy3iM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Recorded live for The Current, watch @realestateband perform their 2017 track, "Stained Glass" from the album 'In Mind'.

Don't miss Real Estate's full virtual session including an interview with Martin Courtney and Mary Lucia about pandemic scones, getting to stay home for a bit, and the perfect place to watch a Real Estate show: https://youtu.be/-bxkOpYLxa0

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Real Estate perform songs from 'Half A Human'
 - [https://www.youtube.com/watch?v=XDW7cO6dfZ8](https://www.youtube.com/watch?v=XDW7cO6dfZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Watch @realestateband perform a few tracks from their latest EP, Half A Human, plus a familiar favorite.. Don't miss Real Estate's full virtual session, including a conversation between Martin Courtney and Mary Lucia about pandemic scones, getting to stay home for a bit, and the perfect place to watch a Real Estate show: https://youtu.be/-bxkOpYLxa0

Songs Played: 
00:00 Half a Human
06:17 Stained Glass
10:47 Ribbon

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Wolf Alice - How Can I Make It Ok? (live performance for The Current)
 - [https://www.youtube.com/watch?v=Lo4wxDFEZn8](https://www.youtube.com/watch?v=Lo4wxDFEZn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Watch @wolfaliceband perform their 2021 track, "How Can I Make It Ok?" from their latest record 'Blue Weekend'. 

Don't miss Wolf Alice's full virtual session including an interview with Jill Riley about recording the album without tight timelines, playing this year's Glastonbury Festival, and more: https://youtu.be/RJGRKTjq51M

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Wolf Alice - Last Man On Earth (live performance for The Current)
 - [https://www.youtube.com/watch?v=jxHHc146pts](https://www.youtube.com/watch?v=jxHHc146pts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Watch @wolfaliceband perform their 2021 track, "Last Man On Earth" from their latest record 'Blue Weekend'. 

Don't miss Wolf Alice's full virtual session including an interview with Jill Riley about recording the album without tight timelines, playing this year's Glastonbury Festival, and more: https://youtu.be/RJGRKTjq51M

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Wolf Alice - Smile (live performance for The Current)
 - [https://www.youtube.com/watch?v=3sQPLZm0nNk](https://www.youtube.com/watch?v=3sQPLZm0nNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Watch @wolfaliceband perform their 2021 track, "Smile" from their latest record 'Blue Weekend'. 

Don't miss Wolf Alice's full virtual session including an interview with Jill Riley about recording the album without tight timelines, playing this year's Glastonbury Festival, and more: https://youtu.be/RJGRKTjq51M

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## Wolf Alice - Virtual Session
 - [https://www.youtube.com/watch?v=RJGRKTjq51M](https://www.youtube.com/watch?v=RJGRKTjq51M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

British alt-rockers Wolf Alice join The Current for a virtual session, and play songs from their new record, Blue Weekend. Ellie and Joff catch up with The Current's Jill Riley about recording the album without tight timelines, playing this year's Glastonbury Festival, and more.

Songs Played:
00:00  How Can I Make It Ok?
12:15 Smile
21:29 The Last Man On Earth

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​​
https://twitter.com/TheCurrent​​​​
https://www.instagram.com/thecurrent/​

Credits
Guests - Ellie Rowsell, Joff Oddie, Theo Ellis, Joel Amey
Host - Jill Riley
Producer - Anna Weggel
Digital Producer - Jesse Wiza
Technical Directors - Eric Romani

## Wolf Alice perform songs from 'Blue Weekend'
 - [https://www.youtube.com/watch?v=D1sPsyH9gNg](https://www.youtube.com/watch?v=D1sPsyH9gNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-04 00:00:00+00:00

Watch @wolfaliceband perform three tracks from their latest record 'Blue Weekend'. Don't miss Wolf Alice's full virtual session including an interview about the new record with The Current here: https://youtu.be/RJGRKTjq51M

Songs Played: 
00:00 How Can I Make It Ok?
03:41 Smile
06:32 The Last Man on Earth

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/​​​
https://twitter.com/TheCurrent​​​
https://www.instagram.com/thecurrent/

## The Twilight Hours - three songs at the Minnesota State Fair (2016)
 - [https://www.youtube.com/watch?v=4z1CKSQQIlI](https://www.youtube.com/watch?v=4z1CKSQQIlI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-03 00:00:00+00:00

Eleven years ago this week, the Twilight Hours performed live in The Current studio. Although we don't have video from that performance, here are three songs by Twilight Hours recorded live before an audience at the MPR Booth at the Minnesota State Fair in 2016. You can feel the energy of the live audience as The Twilight Hours play songs from their 2016 album "Black Beauty." 

SONGS PERFORMED
0:00 "Maybe"
4:05 "Rain"
7:44 "Sioux City Swinger"

PERSONNEL
Matt Wilson – vocals, guitar
John Munson – vocals, bass
Richard Medek – drums
Dave Salmela – keyboards, vocals
Jacques Wait – guitar

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark; Michael "Ozzie" Osborne
Production: Anna Weggel

FIND MORE:
2009 studio session: https://www.thecurrent.org/feature/2009/06/02/the_twilight_hours
2010 studio session: https://www.thecurrent.org/feature/2010/01/08/the-twilight-hours
2011 State Fair session:
https://www.thecurrent.org/feature/2011/08/26/twilight-hours-msf
2016 full State Fair session, including interview:
https://youtu.be/RQw_Xr07bdI 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#thetwilighthours #thecurrent #minnesotastatefair

