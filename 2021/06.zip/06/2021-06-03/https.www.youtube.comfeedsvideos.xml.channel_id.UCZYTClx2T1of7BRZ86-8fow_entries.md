# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## These Adorable Puppies Were Born Smart | SciShow News
 - [https://www.youtube.com/watch?v=lRtCO2aAeao](https://www.youtube.com/watch?v=lRtCO2aAeao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-06-04 00:00:00+00:00

This video was sponsored by Surfshark. Get Surfshark VPN at https://surfshark.deals/SciShow and enter promo code SciShow for 83% discount and 3 extra months for free!

It turns out that dogs are born with a lot of their ability to interact with people, and songbirds have to mute their minds to stay in sync during their quick back and forth duets.

Hosted by: Stefan Chin
Thumbnail Credit: Canine Companions for Independence

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Alisa Sherbow, Silas Emrys, Drew Hart. Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Jason A Saslow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.cell.com/current-biology/fulltext/S0960-9822(21)00602-3
https://www.sciencemag.org/news/2021/03/these-adorable-puppies-may-help-explain-why-dogs-understand-our-body-language

https://www.eurekalert.org/emb_releases/2021-05/njio-ds052721.php
https://doi.org/10.1073/pnas.2018188118

Images:
https://www.istockphoto.com/photo/toy-poodle-male-dog-morning-time-with-his-owner-asian-chinese-woman-on-sofa-bonding-gm1269851420-373025778
https://www.istockphoto.com/photo/groups-of-dogs-labrador-puppies-puppy-chocolate-labrador-retriever-in-front-of-white-gm1069531070-286100409
https://www.istockphoto.com/photo/the-golden-retriever-gives-a-paw-gm1272864653-375013885
https://commons.wikimedia.org/wiki/File:Canis_lupus_howling_on_glacial_erratic.jpg
https://www.istockphoto.com/photo/golden-retriever-puppies-sleeping-gm460831547-32433298
https://www.eurekalert.org/multimedia/pub/266193.php?from=504577
https://commons.wikimedia.org/wiki/File:Birdbrain.svg
https://commons.wikimedia.org/wiki/File:Plain-tailedwren2.jpg
https://commons.wikimedia.org/wiki/File:GABA_3D_ball.png
https://www.istockphoto.com/photo/two-female-singers-singing-a-duet-in-recording-studio-together-gm1284427566-381566914
https://www.istockphoto.com/photo/southeast-asian-girl-tired-with-distance-learning-from-home-gm1271905879-374344583

## Do You Need a Copper Pot?
 - [https://www.youtube.com/watch?v=GDKVtWikC50](https://www.youtube.com/watch?v=GDKVtWikC50)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-06-03 00:00:00+00:00

To discover more about Nature’s Fynd, visit https://naturesfynd.com. To learn about their remarkable nutritional fungi protein and fermentation process, visit https://www.youtube.com/watch?v=sodONlWRiE0.

Some chefs swear by copper pots and pans, but they are much more expensive than other materials. Are they worth it? Well, it all comes down to electrons!

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.bartleby.com/essay/Cooking-Is-The-Art-And-Science-Of-PCYYFBESKG 
https://vtechworks.lib.vt.edu/bitstream/handle/10919/86108/VCE_MHM_124.pdf?sequence=1 
https://www.independent.co.uk/life-style/food-and-drink/how-copper-cookware-became-kitchen-workhorse-a7998181.html 
http://www.bbc.co.uk/ahistoryoftheworld/objects/2h96AO-tQju7ukx2y_E1JA 
https://heritagesciencejournal.springeropen.com/articles/10.1186/s40494-020-00365-4 
https://www.consumerreports.org/frying-pans-other-/the-best-copper-frying-pans/ 
https://www.escoffier.edu/blog/culinary-arts/copper-cookware-is-it-worth-it/ 
https://www.sciencedirect.com/topics/chemistry/heat-capacity 
https://www.seriouseats.com/2019/01/buying-copper-cookware.html 
https://www.sciencedirect.com/topics/materials-science/thermal-conductivity 
https://depts.washington.edu/matseed/mse_resources/Webpage/Metals/metalstructure.htm 
https://www.sciencedirect.com/science/article/pii/S0079670016300156 
https://copperalliance.org.uk/knowledge-base/education/education-resources/copper-properties-applications/ 
http://www.cookingforengineers.com/article/120/Common-Materials-of-Cookware 
https://chem.libretexts.org/Bookshelves/Introductory_Chemistry/Book%3A_Introductory_Chemistry_(CK-12)/08%3A_Ionic_and_Metallic_Bonding/8.12%3A_Alloys 
https://iopscience.iop.org/article/10.1088/0143-0807/24/4/353 
https://chem.libretexts.org/Ancillary_Materials/Exemplars_and_Case_Studies/Exemplars/Everyday_Life/The_Cooking_Efficiency_of_Pots_and_Pans 
https://www.lehigh.edu/~amb4/wbi/kwardlow/conductivity.htm 
https://www.insidehook.com/article/food-and-drink/duparquet-cookware-solid-sterling-silver-pans 
https://www.thekitchn.com/how-to-sear-meat-47333 
https://www.insider.com/copper-cookware-pros-cons 
https://www.seriouseats.com/2019/01/buying-copper-cookware.html 
https://www.thecookwareadvisor.com/copper-cookware-11-burning-questions-answered/ 
https://www.sciencedirect.com/science/article/abs/pii/S0010938X98000936 
https://www.nist.gov/nist-time-capsule/fixed-life-nist-help/keeping-lady-lamp-standing-tall 
https://medlineplus.gov/ency/article/002461.htm 
https://food52.com/blog/25739-how-to-clean-copper-pans 
https://link.springer.com/article/10.1007/s11356-020-09970-z 
https://www.frontiersin.org/articles/10.3389/fmats.2019.00232/full 
https://www.epicurious.com/expert-advice/guide-to-copper-cookware-article 
https://lifehacker.com/science-explains-why-thicker-pans-are-better-for-cookin-5963540 

Image Sources:
https://en.wikipedia.org/wiki/File:Simple_definition_of_thermal_conductivity.png
https://commons.wikimedia.org/wiki/File:Detroit_Photographic_Company_(0707)_(cropped).jpg

## Why Some DNA Is Selfish
 - [https://www.youtube.com/watch?v=hixBGjM7Ld8](https://www.youtube.com/watch?v=hixBGjM7Ld8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-06-03 00:00:00+00:00

Your DNA is a part of you, but it might not share your sense of who's numero uno.

Hosted by: Michael Aranda

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:

https://journals.plos.org/plosgenetics/article?id=10.1371/journal.pgen.1007700 
https://www.nature.com/articles/284604a0 
http://www.sas.rochester.edu/bio/labs/WerrenLab/My%20Papers/2001_Hurst&Werren.pdf 
https://www.jstor.org/stable/10.1086/656220?seq=1 
https://link.springer.com/article/10.1007/s00439-012-1257-0 
https://link.springer.com/protocol/10.1007/978-1-4939-9074-0_6 
https://www.jci.org/articles/view/116400/pdf 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2874221/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3013285 
https://link.springer.com/referenceworkentry/10.1007%2F978-3-642-16483-5_3360 
https://www.genome.gov/genetics-glossary/Crossing-Over 
https://embryo.asu.edu/pages/meiosis-humans 
https://www.annualreviews.org/doi/abs/10.1146/annurev-genet-112618-043905 
https://www.sciencedirect.com/science/article/pii/B9780123014634500061 
https://pubmed.ncbi.nlm.nih.gov/23242375/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5133486/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5959745/ 
https://www.sciencedirect.com/science/article/pii/S0960982218313642 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3701898/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3338262/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1201875/pdf/519.pdf 
https://www.sciencedirect.com/topics/neuroscience/selfish-dna 
https://www.genetics.org/content/172/2/1309 
https://bio.libretexts.org/Bookshelves/Human_Biology/Book%3A_Human_Biology_(Wakim_and_Grewal)/24%3A_Ecology/24.04%3A_Community_Relationships 
https://medlineplus.gov/genetics/understanding/basics/noncodingdna/ 
https://www.cell.com/current-biology/comments/S0960-9822(12)01154-2 
https://www.researchgate.net/publication/235907922_Largest_and_Smallest_Genome_in_the_World 
https://www.theguardian.com/science/2013/feb/24/scientists-attacked-over-junk-dna-claim 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3439153/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4014423/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3619371/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4859970/ 
https://www.cell.com/cell-metabolism/pdf/S1550-4131(19)30120-2.pdf 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5857283/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7061985/ 
 

Image Sources:
https://www.storyblocks.com/video/stock/double-helical-structure-of-dna-strand-close-up-animation-s-xhcmjp8k8r4yuhn
 https://www.istockphoto.com/photo/dogs-gm463752425-32802234
https://www.istockphoto.com/photo/yellow-wheat-field-gm1152174842-312490894

