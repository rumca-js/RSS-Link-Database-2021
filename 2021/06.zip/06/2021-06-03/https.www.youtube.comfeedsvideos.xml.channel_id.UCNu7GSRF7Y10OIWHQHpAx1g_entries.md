# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## No road leads to this place
 - [https://www.youtube.com/watch?v=REUPD9Ab6h4](https://www.youtube.com/watch?v=REUPD9Ab6h4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2021-06-03 00:00:00+00:00

Atelier Aquatic:
Donations: https://www.atelieraquatic.org
Etsy: https://www.etsy.com/uk/shop/EcoArtAtelierAquatic
Shopify: https://atelier-aquatic.myshopify.com/collections/all

Translation: justyna.obrusnik@gmail.com

kursfilmowaniaimontazu.pl
Kod: bezplanu100

All episodes chronologically: http://bit.ly/2MqAO7Q
(you can also click the "Next Episode" tab that appears at the top right of each movie at the end)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Support on Patronite: http://bit.ly/2KsFTZk
Instagram: http://instagram.com/bezplanu_czukesky
Facebook: https://www.facebook.com/BezPlanu.tv

