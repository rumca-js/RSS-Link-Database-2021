# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Everything You Need To Know About E3 Week | Play For All Kickoff Show
 - [https://www.youtube.com/watch?v=EWVwq4v9m_k](https://www.youtube.com/watch?v=EWVwq4v9m_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-04 00:00:00+00:00

Help us raise money for AbleGamers: https://tiltify.com/@playforall2021/playforall2021

GameSpot's kicking off our summer gaming event, Play For All, by detailing everything you need you know about E3 and the many upcoming gaming events.

## History Of E3 (2021)
 - [https://www.youtube.com/watch?v=enrVDHSRwqE](https://www.youtube.com/watch?v=enrVDHSRwqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-04 00:00:00+00:00

Let's take a look back at the history of E3 and maybe laugh at all the dorky 90s outfits.

For the last two decades, some of the biggest gaming news and reveals have come during the Electronic Entertainment Expo or E3. the yearly video game industry trade show, where the newest titles and products are on full display. Many for the first time. But even though the show has drawn 10s of thousands of people to its convention centers every summer, the show itself has gone through a whole lot of changes during this 27 year-long run… well, 26 if you exclude the canceled one last year. So let's take a look back at the history of E3 and maybe laugh at all the dorky 90s outfits.

## Mario Golf: Super Rush - The Final Preview
 - [https://www.youtube.com/watch?v=lmAt_t171ZM](https://www.youtube.com/watch?v=lmAt_t171ZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-03 00:00:00+00:00

Nintendo's new Mario Golf game for Switch injects even more action into the sport.

You can read the full written preview by Kevin Knezevic on GameSpot: https://www.gamespot.com/articles/mario-golf-super-rushs-speed-golf-mode-looks-chaotic-in-the-best-way/1100-6492312/

Mario Golf: Super Rush will release on June 25th exclusively for Nintendo Switch. This is the first full Mario Golf game since Mario Golf: World Tour on the Nintendo 3DS, and the first home console Mario Golf game since Mario Golf: Toadstool Tour on the Nintendo GameCube. For more on Mario Golf: Super Rush, including our review, stay right here on GameSpot.

