# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Owner Drilled Through This S10+ - Can We Refurbish It?
 - [https://www.youtube.com/watch?v=OLyLGtuqByk](https://www.youtube.com/watch?v=OLyLGtuqByk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2021-06-19 00:00:00+00:00

The previous owner really screwed up this phone, let try and restore it!
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Tools I Use: https://www.hughjeffreys.com/tools

Get parts, tools, and thousands of free repair guides from iFixit at: 
                               https://iFixit.com/hughjeffreys
Australian Store: https://ifix.gd/2FPxhKy
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

