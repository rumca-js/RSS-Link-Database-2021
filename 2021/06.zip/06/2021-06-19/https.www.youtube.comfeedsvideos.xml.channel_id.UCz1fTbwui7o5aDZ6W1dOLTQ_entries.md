# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Literature Devil's 12 Rules for Writing
 - [https://www.youtube.com/watch?v=F91zrqbnI_4](https://www.youtube.com/watch?v=F91zrqbnI_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2021-06-20 00:00:00+00:00

Let's take a look at some of the most common mistakes I've seen made over my long history in independent fiction and how to hopefully avoid them!

"Get Surfshark VPN at https://surfshark.deals/literature and enter promo code  LITERATURE for 83% off and 3 extra months for free!"

Glib (Voice of Writing Imp): https://www.youtube.com/channel/UC9zuyLdn1FncxrKnDuErYeA

ShineyFX (Intro): https://www.youtube.com/channel/UCS4jTMx3GHWZLlT7Rqy5GTQ

Xofrats (Tutorial Demon and Writing Imps): https://twitter.com/xofrats

Chapters
0:00 Thumbnail
1:25 Introduction
4:23 Rule#1 Know Your Audience
6:12 Rule#2 Identify the Story
8:18 Rule#3 Establish Conflict
10:57 Rule#4 Create a Meaningful Beginning
16:37 Rule#5 Develop Your Craft
18:49 Rule#6 Maintain A Focused Narrative
21:42 Rule#7 Maintain Suspension of Disbelief
25:01 Rule#8 Dramatic Impact
29:39 Rule#9 Write Honestly
33:16 Rule#10 The Muse is a Luxury
35:41 Rule#11 Never Fear Mistakes
39:40 Rule#12 Find Your Voice
42:30 Rule#13 Never Give Up

https://www.thewrap.com/famous-jedi-showed-up-mandalorian-season-2-finale-fans-lost-their-minds/

Stan Lee: https://www.youtube.com/watch?v=sjobevGAYHQ

Minds: https://www.minds.com/literaturedevil/

Parler: https://parler.com/profile/LiteratureDevil/posts

Twitter: https://twitter.com/literaturedevil

Fight Censorship shirt (Color): https://teespring.com/fight-censorship-color?pid=387&cid=100163&sid=front

Fight Censorship: https://teespring.com/new-fight-censorship?pid=387&cid=101810&sid=front

Fight Censorship Mask: https://teespring.com/fight-censprship-mask?pid=972&cid=103974

Fight Censorship Mug (colored): https://teespring.com/fight-censorship-mug-colored?pid=658&cid=102908

Fight Censorship Mug: https://teespring.com/fight-censorship-mug-black?pid=658&cid=102950

SubscribeStar: https://www.subscribestar.com/literature-devil

Smudboy: https://www.youtube.com/user/smudboy
Shiney FX:https://www.youtube.com/channel/UCS4jTMx3GHWZLlT7Rqy5GTQ
Voice in the Radio: https://www.youtube.com/channel/UCvc8Ikvyuj_lHNWAo4Gu_lg
Glib: https://www.youtube.com/channel/UC9zuyLdn1FncxrKnDuErYeA
Lord Commander Dunn: https://www.youtube.com/channel/UCbRyEIfMmJ2oWUMyOlrg4CA

Reylo Tears Mug (White): https://teespring.com/reylo-tears-mug-white?pid=658&cid=102908

Reylo Tears Mug (Black): https://teespring.com/reylo-tears-mug-black?pid=658&cid=102950

