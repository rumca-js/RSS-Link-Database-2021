## ‘CDC has been wrong all along, and they knew it’, says Ron DeSantis as judge rules CDC can’t regulate cruises | The Independent
 - [https://www.independent.co.uk/news/world/americas/cdc-florida-covid-cruise-judge-b1869088.html](https://www.independent.co.uk/news/world/americas/cdc-florida-covid-cruise-judge-b1869088.html)
 - RSS feed: https://www.independent.co.uk
 - date published: 2021-06-19 19:30:04+00:00

‘CDC has been wrong all along, and they knew it’, says Ron DeSantis as judge rules CDC can’t regulate cruises | The Independent

