# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete Travels of Glorfindel | Tolkien Explained
 - [https://www.youtube.com/watch?v=gWlvIyxkgVo](https://www.youtube.com/watch?v=gWlvIyxkgVo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2021-06-19 00:00:00+00:00

Glorfindel is not only a fan-favorite character, but also one of the most powerful elves to ever walk Middle-earth.  Today, we cover his entire life - his birth in Valinor, his fatal fight against a balrog in Gondolin, and his reincarnation by the Valar.  After he re-embodied, he is sent back to Second Age Middle-earth, as an emissary to help the elves of Eriador in their fight against Sauron.  Eventually, we would meet him again as he helps Frodo get to Rivendell, and takes on five Ringwraiths single-handedly!


*Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!*  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, I highly recommend checking out these amazing artists online!
Ted Nasmith - https://www.tednasmith.com/shop/
Jenny Dolfen - https://goldseven.wordpress.com/
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc

Glorfindel and Ecthelion - Jenny Dolfen
Glorfindel - Jenny Dolfen
Glorfindel, Aragorn, and the hobbits - Fantasy Flight
Alqualonde - Ted Nasmith
Beleriand Map - Lamaarcana
Lords of Gondolin - Kazuki Mendou
Gondolin Falls - Federico Cimini
Glorfindel's Bane - Ted Nasmith
Glorfindel and the Balrog - Alan Lee
Barrow - Liam Reagan
Glorfindel and the Balrog  - Justin Gerard
Trees of Valinor - Helen Kei
Glorfindel Battles the Balrog - Alystraea Art
Sauron - Jerry Vanderstelt
Manwe Sulimo - Gustavo Malek
Glorfindel - Kenneth Sofia
The Nazgul - Istrandar
Glorfindel - Thomas Rouillard
Glorfindel - Gellihana
Glorfindel and the Balrog - John Howe
Rivendell Elf Rider - Nick Keller
Glorfindel and the Balrog - Anato Finnstark
Glorfindel and Asfaloth - Alystraea Art
Glorfindel - Audrey Hotte
Fire on Weathertop - Ted Nasmith
Glorfindel - Anke Eissmann
Ai na vedui, Dunedan - Abe Papakhian
Glorfindel at the Ford - Sebastian Giacobino Fantasy Flight
Glorfindel Returns to Rivendell - Jenny Dolfen
Glorfindel - Ulla Thynell
Glorfindel - Liiga Klavina
Elf - Sjoerd Bijkerk
Frodo flies to the fords of Bruinen upon Asfaloth - Donato Giancola
Glorfindel at the Ford - Alystraea Art
Nazgul and Glorfindel - Denis Gordeev
Frodo and the Nazgul - Magali Villeneuve
Frodo's Recovery - Donato Giancola
The Council of Rivendell - MellorianJ
The Council of Elrond - Alan Lee
Tom Bombadil - Borja Pindado
The Fellowship of the Ring - The Brothers Hildebrandt
Arwen and Elessar Wedding - The Brothers Hildebrandt
The Grey Havens - Francesco Amadio
Valinor Shores - dogasimsir_artwork
Glorfindel Finds His Grave - Alystraea

#glorfindel #tolkien #lordoftherings

