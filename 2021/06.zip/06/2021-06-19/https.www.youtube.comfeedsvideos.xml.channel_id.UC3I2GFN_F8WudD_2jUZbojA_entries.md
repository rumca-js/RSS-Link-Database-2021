# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## I Self Devine - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Lh08W2kkoGc](https://www.youtube.com/watch?v=Lh08W2kkoGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-06-19 00:00:00+00:00

http://KEXP.ORG presents I Self Devine & Orko Eloheim performing live, recorded exclusively for KEXP.

Songs:
Lord Help Me
We Are Soldiers
Get To It
This Is A Spiritual
Textures & Patterns

Performance partially recorded at Minneapolis Institute of Art, Rituals of Resilience exhibition, co-curated by Chaka Mkali (aka I Self Devine)
Video by solaceloquent

https://new.artsmia.org/exhibition/rituals-of-resilience
https://twitter.com/iselfdevine
http://kexp.org

