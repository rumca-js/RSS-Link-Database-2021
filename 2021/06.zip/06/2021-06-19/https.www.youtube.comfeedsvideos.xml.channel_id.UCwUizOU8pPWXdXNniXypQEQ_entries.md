# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## DANGER! The Military Has Gone Woke!
 - [https://www.youtube.com/watch?v=QL0u8JmfRU0](https://www.youtube.com/watch?v=QL0u8JmfRU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-06-19 00:00:00+00:00

Grab your Blue Light Blocking Glasses and other Blublox Products at https://blublox.com/jp
*** Limited Sale up to 30% Off Until June 30th!

Check out my NEW MERCH here! - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

DANGER! The military has gone woke! Learn about the exciting improvements to the military like teaching soldiers critical race theory and inclusivity instead of combat training and national defense. You’ve never been in softer hands.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

