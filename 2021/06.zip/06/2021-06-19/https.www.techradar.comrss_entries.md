# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## F1 TV on Roku: How to get it and start watching now
 - [https://www.techradar.com/news/f1-tv-on-roku-how-to-get-it-and-start-watching-now](https://www.techradar.com/news/f1-tv-on-roku-how-to-get-it-and-start-watching-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2021-06-19 08:03:23+00:00

Looking for how to stream F1 racing on Roku? It's now easier than ever thanks to the official F1 TV app, which supports most modern Roku devices. F1 TV supports Full HD, too.

