# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The REAL Story Behind ANOM:
 - [https://www.youtube.com/watch?v=pJryRIRCcTM](https://www.youtube.com/watch?v=pJryRIRCcTM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2021-06-20 00:00:00+00:00

The criminal underworld will never be the same again. The ANOM sting operation (Operation Trojan Shield in the US or Operation Ironside in AU) was a collaboration by several countries, from 2018 and 2021. The idea was to use so called "Privacy Phones" to break into the criminal syndicates to disrupt their plots. 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

