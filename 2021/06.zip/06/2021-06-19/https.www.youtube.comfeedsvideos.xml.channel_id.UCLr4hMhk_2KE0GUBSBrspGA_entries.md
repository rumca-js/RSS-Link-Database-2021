# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Kto zostanie właścicielem internetu? Oraz: realme GT 5G, Beats Studio Buds, Doom Ikea
 - [https://www.youtube.com/watch?v=RPkTfz04WCk](https://www.youtube.com/watch?v=RPkTfz04WCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2021-06-20 00:00:00+00:00

A także:
Kogo interesuje film o realme GT 5G: https://youtu.be/Nr_KQzsh-N8
Nowe słuchawki Sony w recenzji: https://youtu.be/yz3qkMigj9g
Nowe Beats Studio Buds: https://youtu.be/-XM7883VytU 
Nintendo nie pokazało nowego Switcha: https://bit.ly/3wDBuJb
Doom na żarówce z IKEI: https://bit.ly/2SOeFDN
Archiwalna dokumentacja: https://bit.ly/3zG49iD
Kup sobie internet: https://cnet.co/3wDBSHD
Canon uszczęśliwia pracowników: https://bit.ly/3zGY715
Tamagotchi wróciło: https://engt.co/3iU2jEU
Wristcam dostał 25M $ na rozwój: https://tcrn.ch/2TOSaPk
Petycja, żeby Bezos nie wracał z kosmosu: https://bit.ly/2SGUt74
Petycja, żeby Bezos zjadł Mona Lisę: https://bit.ly/3xxtucM

Moje sociale: 
Insta: https://www.instagram.com/kubaklawiter/
Twitter: https://twitter.com/KubaKlawiter

Spis treści:
00:00 Wstęp
00:15 Dobry wieczór!
00:20 W jutrzejszym vlogu - nowy MacBook 13 Pro M1
00:39 Realme GT 5G – zapowiedź filmu 100 pytań o…
02:20 Beats Studio Buds
02:33 O montowaniu materiałów
03:18 Czy muzyka jest istotna w filmach na YouTube?
03:46 Porównanie słuchawek Sony XM4 do Bose i AirPods Pro
04:25 Brak newsów technologicznych w Tech Weeku
04:59 Nowe słuchawki douszne Beats Studio Buds od Apple
06:36 Brak nowego Switcha od Nintendo 
06:48 Doom na żarówce z Ikei
07:32 Internet na sprzedaż w postaci NFT
08:00 Canon uszczęśliwia pracowników
08:36 Powrót Tamagotchi
09:03 Wristcam dostaje 2 mln $ na rozwój
09:35 Petycja, żeby Bezos nie wracał z kosmosu
09:46 Petycja, żeby Bezos kupił i zjadł Mona Lisę
09:53 Wspieranie ludzi słabszych i tych, którym nie wychodzi
10:19 Pożegnanie
10:27 Znośnego tygodnia

