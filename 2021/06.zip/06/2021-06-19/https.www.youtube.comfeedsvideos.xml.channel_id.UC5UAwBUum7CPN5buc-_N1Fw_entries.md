# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Slimbook Titan - a Portable Powerhouse running Linux
 - [https://www.youtube.com/watch?v=FKCtKVY_g48](https://www.youtube.com/watch?v=FKCtKVY_g48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2021-06-19 00:00:00+00:00

This is the Slimbook Titan, Slimbook's most powerful laptop that basically comes with all the options, including a mechanical keyboard, a high refresh rate display, and monster specs. Oh and also it's fast because it has RGB and Stickers. Let's take a look at what that thing can do!

Become a channel member to get access to a weekly patroncast and vote on the next topics I'll cover:
https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Support the channel on Patreon: 
https://www.patreon.com/thelinuxexperiment

Follow me on Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

Follow me on ODYSEE: https://odysee.com/@TheLinuxExperiment:e
Or join ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

The Linux Experiment merch: get your goodies there! https://teespring.com/en-GB/stores/the-linux-experiment


00:00 Intro
00:21 Specs
00:59 Build Quality
02:19 I/O
02:45 Display
03:51 Keyboard
04:32 Slimbook Desktop Keyboard
05:08 RGB
05:46 Touchpad
06:22 Performance
08:27 Battery Life
11:46 Conclusion

## Device

It uses a ryzen 9 5900HX, with an nvidia RTX 3070. It's paired to an amazing 1440p 15 inch IPS display with freesync, an opto mechanical keyboard.

It comes with 16Gb of RAM, and 500Gb of SSD.

The chassis is made of black aluminium for the most part, with only the bottom plate being made out of black plastic. It's a hefty laptop, at 2.2 kilograms, and it's a thicc boi, at 26mm.

The build quality is really, really good. There is absolutely no flex, or give, on the keyboard, or around it.

The branding on the back is nice and minimal, which I like, it gives a classy, professional look, but under the screen, it's a bit too big for my tastes.

Tt's got great I/O, with a USB 3.1 gen 2 port, an audio and a microhpone jack on the left side, a full size SD card reader and 2 USB 3.1 ports on the right side, and a USB C 3.2 gen 2 port with video out, an HDMI 2.1 port, a 2.5gigs ethernet jack, and the barrel charger on the back.

The display itself is a thing of beauty. First, the 1440p resolution on a 15 inch screen makes sense, even though it might be a bit small for some people.
Second, it can go up to a 165hz refresh rate, which makes it an excellent display for gaming.
Third, it's freesync compatible, which means no screen tearing.

The bezels are alright, except for the bottom one, which is pretty big, but it's a really good panel. Viewing angles are perfect, brightness is really high, and the contrast is quite nice too.

Now let's talk about that keyboard. It's an opto-mechanical one.
It's got a real nice feel to it, with a decent 2mm key travel, very good key stability, and the keycaps are nice and big, so typing is really easy on that thing. The sound is just right for me, but it might be a bit too clacky for some people who like their keyboards quiet.

The Titan comes with per-key LED RGB, which means that you can get some pretty crazy RGB effects in that keyboard.
If that's not enough RGB for you, there is also a light bar in the front, that you can also customize.

Moving on, the touchpad feels nice, smooth and responsive, it's precise, and supports gestures. Out of the box, Slimbook os allows for a 3 fingers up swipe to get to the GNOME activities, and 3 fingers swipe left and right to get back and forward gestures inside of Firefox.

Oh and also, you can remove the back plate, and upgrade the storage, the battery, and the RAM yourself, so this thing is pretty future proof as well.

## Performance
I pushed it to the maximum settings using the Slimbook Ryzen Controller, an app they ship by default to control the power profile of the CPU.

Running Geekbench 5, this device got up to 1511 in single core, and 8170 in multi core, which is pretty freaking high, destroying the ryzen 7 4800H of the KDE SLimbook, which scored 7307 in multi-core, and beats my desktop Ryzen 7 5800X in single core.

It is also a really, really noisy device. At full speed, this thing will fill the whole room with the fan noise.

In terms of battery life, with the screen at half brightness, with wifi on, and the ryzen controller set to low power, without any keyboard RGB the laptop lasted for just 3 hours, just playing youtube videos back to back in firefox, ads included.

That's pretty low, especially with the huge 93Wh battery, so why is that happening?

Turns out that screen brightness can't be controlled for the moment when both GPUs are active, and SLimbook had disabled the integrated AMD graphics as a result on my review unit. i re-enabled it in the BIOS, and ran the exact same battery test, with the screen brightness at 100%, and this got me 4h and a half hours.

I'd expect that with a brightness reduced to 50%, you could get up to 6 hours if you don't use the dedicated GPU.


The Titan will definitely not be very enduring, but that's also not really the intended goal for such a device

