# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Daria Zawiałow - Wojny i Noce - Wywiad MUZO.FM
 - [https://www.youtube.com/watch?v=tmHdFWVLGO4](https://www.youtube.com/watch?v=tmHdFWVLGO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2021-06-20 00:00:00+00:00

Daria Zawiałow - Wojny i Noce - to trzeci studyjny album artystyki. Na płycie można usłyszeć syntezatory inspirowane elektroniką z lat '80, ale nie brakuje też gitarowych brzmień. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Daria Zawiałow: http://www.facebook.com/dariazawialow
Instagram Daria Zawiałow: http://www.instagram.com/zavialovd
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

