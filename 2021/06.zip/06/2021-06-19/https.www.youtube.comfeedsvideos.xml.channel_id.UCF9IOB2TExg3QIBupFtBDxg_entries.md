# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Money for antivirals
 - [https://www.youtube.com/watch?v=Of5_oiuqDp8](https://www.youtube.com/watch?v=Of5_oiuqDp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2021-06-20 00:00:00+00:00

Money for antivirals, $3.2 billion
https://www.washingtonpost.com/health/2021/06/17/drugs-for-covid/?utm_campaign=wp_to_your_health&utm

Anthony S. Fauci, David Kessler, chief science officer for the covid-19 response

Reinvigorate the nation’s antiviral program

and test whether existing drugs show promise

David Kessler

We need this set of tools to close out this pandemic.

The hard thing is to recognize with all the success, there’s still several hundred deaths a day.

Coronavirus first, then other potential pandemic viruses

Pre orders for this pandemic, before they have been shown to work

Ann Kwong, virologist, (hepatitis C antiviral)

Investors are totally uninterested in antivirals. 

What they really want is a chronic treatment

Nobody ever gets cured of high cholesterol

Antivirals, 5 to 10 days

Last week, administration committed $1.2 billion

1.7 million doses of molnupiravir (if approved)

Merck and Ridgeback

Effect of Ivermectin on Anopheles gambiae Mosquitoes Fed on Humans: The Potential of Oral Insecticides in Malaria Control 

https://academic.oup.com/jid/article/202/1/113/888773

it was licensed for human use and was used in mass drug administration programs

to control river blindness; it was administered to  more than 80 million adults and children. 

The drug has proven to be safe. 

Doses up to 10 times the approved limit are well tolerated by healthy volunteers

Adverse reactions are few and usually mild

Barcelona Institute for Global Health

https://www.isglobal.org/en/healthisglobal/-/custom-blog-portlet/questions-and-answers-about-ivermectin-and-covid-19/2877257/0

More than three billion treatments have been distributed in the context of the Mectizan Donation Program alone

With an excellent safety profile. 

Most adverse reactions are mild, transitory

and associated with parasite death rather than with the drug itself.

Dr Soumya Swaminathan

https://www.ndtv.com/india-news/coronavirus-ivermectin-efficacy-safety-most-important-top-who-scientist-warns-against-ivermectin-use-2439290

Safety and efficacy are important when using any drug for a new indication. 

WHO recommends against use of 'ivermectin' for COVID-19 except within clinical trials

Bram Rochwerg, McMaster University

Co-chair, WHO panel that reviewed ivermectin

https://www.reuters.com/article/us-health-coronavirus-ivermectin-idUSKBN2BN2HH

We certainly need more data in order to make informed decisions

We did see an increase in adverse effects in patients that were randomised to ivermectin

Repurposed drugs, there can be more harm than any good

Merck Statement on Ivermectin use During the COVID-19 Pandemic

https://www.merck.com/news/merck-statement-on-ivermectin-use-during-the-covid-19-pandemic/

A concerning lack of safety data in the majority of studies.

