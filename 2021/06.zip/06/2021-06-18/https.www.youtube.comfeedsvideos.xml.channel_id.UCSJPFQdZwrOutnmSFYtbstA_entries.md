# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Picard Season 2 - How Is This Show Still Going?
 - [https://www.youtube.com/watch?v=UDNAdudbg1g](https://www.youtube.com/watch?v=UDNAdudbg1g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-06-18 00:00:00+00:00

The trailer for Star Trek Picard Season 2 just dropped, and it looks as predictably bad as expected. Join me as I break it down.

