# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Georgia removes 100,000 names from voter registration rolls
 - [https://www.cnn.com/2021/06/18/politics/georgia-voter-registration-file-removal/index.html](https://www.cnn.com/2021/06/18/politics/georgia-voter-registration-file-removal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 23:57:32+00:00

More than 100,000 names will be removed from Georgia's voter registration rolls in an attempt to keep the state's voter files "up to date," Georgia's secretary of state announced in a statement Friday.

## Utah cheerleading photo incident sends a message
 - [https://www.cnn.com/2021/06/18/opinions/down-syndrome-cheerleading-photo-utah-perry/index.html](https://www.cnn.com/2021/06/18/opinions/down-syndrome-cheerleading-photo-utah-perry/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 23:53:25+00:00

In second grade, my son's class finished the school year by doing theatrical re-creations of the books they had read. Parents even got a flyer announcing the activity with students listed under each book. My son was missing, and when I inquired, was told that "Nico would participate as an audience member."

## The absurd whitewashing of Trump's record reaches dangerous level
 - [https://www.cnn.com/collections/trump-intl-061821/](https://www.cnn.com/collections/trump-intl-061821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 23:18:19+00:00



## Bring the 'dad jokes,' we need 'em. (Warning: This story contains actual dad jokes)
 - [https://www.cnn.com/2021/06/18/health/go-ask-your-dad-jokes-wellness-parenting/index.html](https://www.cnn.com/2021/06/18/health/go-ask-your-dad-jokes-wellness-parenting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 22:52:33+00:00

In September 2019, just ahead of the Covid-19 pandemic -- so roughly before-anyone-can-remember ago -- Merriam-Webster added the term "dad joke" to the dictionary, to little fanfare.

## This Republican senator is now Enemy No. 1 for Trump
 - [https://www.cnn.com/2021/06/18/politics/lisa-murkowski-kelly-tshibaka-trump/index.html](https://www.cnn.com/2021/06/18/politics/lisa-murkowski-kelly-tshibaka-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 22:50:39+00:00



## US Catholic bishops advance communion document, setting up potential rebuke of Biden
 - [https://www.cnn.com/2021/06/18/politics/catholic-bishops-biden/index.html](https://www.cnn.com/2021/06/18/politics/catholic-bishops-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 22:45:42+00:00

The United States Conference of Catholic Bishops on Friday proceeded with a plan that would deny communion to public figures who support abortion rights, setting up a potential public rebuke of President Joe Biden.

## Teen is one of few kids vaccinated in the UK. Here's why
 - [https://www.cnn.com/videos/world/2021/06/18/uk-children-covid-19-vaccine-black-dnt-vpx.cnn](https://www.cnn.com/videos/world/2021/06/18/uk-children-covid-19-vaccine-black-dnt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 21:59:10+00:00

The United Kingdom is taking a cautious approach toward vaccinating young people, a stark contrast from the United States, where more than 5 million children under 18 are fully vaccinated. CNN's Phil Black has more.

## Brown presses GOP lawmaker to denounce new Capitol riot conspiracy
 - [https://www.cnn.com/videos/politics/2021/06/18/nancy-mace-capitol-riot-video-lead-brown-sot-vpx.cnn](https://www.cnn.com/videos/politics/2021/06/18/nancy-mace-capitol-riot-video-lead-brown-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 21:58:01+00:00

Rep. Nancy Mace (R-SC) shares her reaction to the latest videos released from the January 6 Capitol riot with CNN's Pamela Brown.

## 'The Black Crowes' share never-before-seen quarantine recording
 - [https://www.cnn.com/videos/us/2021/06/17/black-crowes-acfc-quarantine-performance-she-talks-to-angels-vpx.cnn](https://www.cnn.com/videos/us/2021/06/17/black-crowes-acfc-quarantine-performance-she-talks-to-angels-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 21:38:53+00:00

Chris & Rich Robinson from "The Black Crowes" joined Anderson Cooper Full Circle and shared never-before-seen footage of their hit "She Talks to Angels" recorded during a 2020 acoustic quarantine session. Watch "Full Circle" Monday, Wednesday and Friday at 6p E.T.

## 'You know that's not true': CNN reporter corrects man who stormed Capitol
 - [https://www.cnn.com/videos/politics/2021/06/18/capitol-riot-documentary-cnn-preview-drew-griffin-vpx.cnn](https://www.cnn.com/videos/politics/2021/06/18/capitol-riot-documentary-cnn-preview-drew-griffin-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 20:44:13+00:00

CNN's Drew Griffin speaks with Josh Pruitt, a member of the Proud Boys who stormed the Capitol on January 6.  Watch "Assault on Democracy: The Roots of Trump's Insurrection" at 6pm on June 20, 2021.

## Alleged financier for Venezuelan president says he fears being extradited to the US
 - [https://www.cnn.com/2021/06/18/americas/alex-saab-maduro-detention-interview/index.html](https://www.cnn.com/2021/06/18/americas/alex-saab-maduro-detention-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 20:35:56+00:00

He claims he was tortured by the authorities in Cape Verde and that even worse punishments await him if he is extradited to the United States. Alex Saab, the Colombian businessman who's also said to be a 'financier' and 'front man' of embattled Venezuelan President Nicolas Maduro, told CNN in an exclusive interview from his detention site in Cape Verde that he has no doubts about what will happen to him if sent to America.

## Man survives after he was shot next to children
 - [https://www.cnn.com/videos/us/2021/06/18/new-york-shooting-video-kids-nr-vpx.cnn](https://www.cnn.com/videos/us/2021/06/18/new-york-shooting-video-kids-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 19:34:25+00:00

The NYPD released surveillance video showing a man shot in broad daylight next to two children in the Bronx.

## How Trump weaponized the Justice Department
 - [https://www.cnn.com/videos/tv/2021/06/18/amanpour-honig-doj-trump-barr.cnn](https://www.cnn.com/videos/tv/2021/06/18/amanpour-honig-doj-trump-barr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 18:41:49+00:00

Elie Honig, author of the Bill Barr biography "Hatchet Man," breaks down attempts to undermine the Justice Department during the Trump administration.

## Nik Wallenda removes harness for the end of his high-wire walk
 - [https://www.cnn.com/videos/us/2021/06/18/nik-wallenda-high-wire-walk-buffalo-orig-bdk.cnn](https://www.cnn.com/videos/us/2021/06/18/nik-wallenda-high-wire-walk-buffalo-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 18:40:19+00:00

Daredevil Nik Wallenda performed a 320-foot high-wire walk during an event at D'Youville College campus in Buffalo, New York.

## This race massacre occurred years before Tulsa
 - [https://www.cnn.com/videos/tv/2021/06/18/amanpour-dawn-porter-tulsa-race-massacre-oklahoma-juneteenth-racism.cnn](https://www.cnn.com/videos/tv/2021/06/18/amanpour-dawn-porter-tulsa-race-massacre-oklahoma-juneteenth-racism.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 18:05:29+00:00

The Elaine Race Massacre left hundreds dead in 1919. "Rise Again" director Dawn Porter says like Tulsa, it was sparked by racist anger of Black progress.

## Newborn girl found abandoned in a box floating down river
 - [https://www.cnn.com/videos/world/2021/06/18/baby-found-in-box-india-ganges-lon-orig-sd-na.cnn](https://www.cnn.com/videos/world/2021/06/18/baby-found-in-box-india-ganges-lon-orig-sd-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 17:45:22+00:00

A boatman found the three-week-old baby in a wooden box, which also contained incense sticks, an image of a Hindu deity and the child's astrological birth chart, according to local police.

## Ted Cruz: Critical race theory is as racist as Klansmen
 - [https://www.cnn.com/videos/politics/2021/06/18/critical-race-theory-ted-cruz-sot-ip-vpx.cnn](https://www.cnn.com/videos/politics/2021/06/18/critical-race-theory-ted-cruz-sot-ip-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 17:17:45+00:00

Sen. Ted Cruz (R-TX) criticizes teaching critical race theory in schools, where he accuses it of being as racist as Klansmen in white sheets.

## Mel C says Spice Girls 'would be fools' not to tour again
 - [https://www.cnn.com/2021/06/18/entertainment/mel-c-spice-girls-reunion-intl-scli-gbr/index.html](https://www.cnn.com/2021/06/18/entertainment/mel-c-spice-girls-reunion-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 17:01:36+00:00

Two years after the Spice Girls performed their sellout reunion tour, Melanie Chisholm -- better known as Mel C or 'Sporty Spice' -- has hinted that the 90s girl group will returning to the stage.

## Christian Eriksen discharged from hospital after 'successful operation'
 - [https://www.cnn.com/2021/06/18/football/christian-eriksen-denmark-discharged-hospital-spt-intl/index.html](https://www.cnn.com/2021/06/18/football/christian-eriksen-denmark-discharged-hospital-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 16:53:42+00:00

Christian Eriksen has been discharged from hospital after undergoing a "successful operation," the Danish Football Association confirmed on Friday.

## 'The stuff of nightmares': Breaking down Nigeria's kidnapping epidemic
 - [https://www.cnn.com/videos/world/2021/06/18/nigeria-kidnapping-explainer-africa-asher-pkg-oneworld-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2021/06/18/nigeria-kidnapping-explainer-africa-asher-pkg-oneworld-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 16:22:52+00:00

CNN's Zain Asher explores the reasons why Nigeria is suffering through a wave of kidnappings.

## China is about to reach a staggering milestone in its Covid-19 vaccination drive
 - [https://www.cnn.com/2021/06/18/china/billion-vaccine-shots-mic-intl-hnk/index.html](https://www.cnn.com/2021/06/18/china/billion-vaccine-shots-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 16:15:58+00:00

• EU lifts restrictions for US travelers
• As the pandemic in the US slows, the fight against 'long haul' Covid is on

## The little-known 20th-century designer who could see our homes of the future
 - [https://www.cnn.com/style/article/charlotte-perriand-design-museum/index.html](https://www.cnn.com/style/article/charlotte-perriand-design-museum/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 16:06:31+00:00

The story of the late Charlotte Perriand is an inspiring tale of an adventurous designer whose ideas and creations left a lasting mark on homes around the world. But most people will have never heard of the pioneering maker -- her place in history is so often overshadowed by her male contemporaries.

## Serena Williams gives daughter tennis lesson in adorable video
 - [https://www.cnn.com/videos/business/2021/06/18/serena-williams-daughter-tennis-lesson-instagram-mxp-vpx.cnn](https://www.cnn.com/videos/business/2021/06/18/serena-williams-daughter-tennis-lesson-instagram-mxp-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 14:31:23+00:00

The 23-time grand slam winning champion Serena Williams took to Instagram to share an adorable video of her giving her 3-year-old daughter Olympia a tennis lesson.

## Tesla is following in the steps of an unlikely rival
 - [https://www.cnn.com/2021/06/18/cars/tesla-radar-autopilot/index.html](https://www.cnn.com/2021/06/18/cars/tesla-radar-autopilot/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 14:15:58+00:00

Tesla has long led the auto industry — sometimes controversially — with its driver-assist system Autopilot. Now, it finds itself suddenly following the lead of an unlikely rival: Subaru.

## This giant prehistoric rhino was the biggest land mammal to walk the Earth
 - [https://www.cnn.com/2021/06/18/asia/giant-rhino-fossil-study-scli-intl-hnk-scn/index.html](https://www.cnn.com/2021/06/18/asia/giant-rhino-fossil-study-scli-intl-hnk-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 12:48:13+00:00

Paleontologists working in China have discovered a new species of giant rhino, the largest land mammal ever to have walked the earth.

## Japan's top Covid-19 adviser says holding the Olympics without spectators is 'desirable'
 - [https://www.cnn.com/2021/06/18/sport/tokyo-olympics-spectators-spt-intl/index.html](https://www.cnn.com/2021/06/18/sport/tokyo-olympics-spectators-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 12:30:29+00:00

Japan's top coronavirus adviser said Friday that staging the Tokyo Olympics without spectators is "desirable" as it would be the lowest risk option amid the pandemic.

## To some, she's a patriot. To others, a domestic terrorist
 - [https://www.cnn.com/2021/06/18/politics/ashli-babbitt-capitol-hill-riot-death-invs/index.html](https://www.cnn.com/2021/06/18/politics/ashli-babbitt-capitol-hill-riot-death-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 12:11:17+00:00

On a sunny morning in February, as a bagpipe rendition of "Amazing Grace" filled the salt air, Ashli Babbitt's family and friends scattered her ashes into the Pacific Ocean off San Diego.

## Daredevil dies while practicing for a world record motorcycle jump
 - [https://www.cnn.com/2021/06/18/us/alex-harvill-death/index.html](https://www.cnn.com/2021/06/18/us/alex-harvill-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 12:06:12+00:00

Daredevil Alex Harvill died Thursday while practicing for a world record motorcycle ramp jump, officials in Washington state said. He was 28 years old.

## China's about to administer its billionth coronavirus shot. Yes, you read that right
 - [https://www.cnn.com/collections/intl-covid-vaccinations-061821/](https://www.cnn.com/collections/intl-covid-vaccinations-061821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 11:44:17+00:00



## How to go backpacking (and why it's worth the effort)
 - [https://www.cnn.com/travel/article/backpacking-for-beginners-tips-how-to/index.html](https://www.cnn.com/travel/article/backpacking-for-beginners-tips-how-to/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 11:37:34+00:00

Each summer, Emily Davenport spends days at a time hauling heavy loads through the White Mountains of New Hampshire.

## The trio seizing the US Supreme Court
 - [https://www.cnn.com/2021/06/18/politics/roberts-kavanaugh-barrett-supreme-court/index.html](https://www.cnn.com/2021/06/18/politics/roberts-kavanaugh-barrett-supreme-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 10:26:11+00:00

Chief Justice John Roberts, along with Justices Amy Coney Barrett and Brett Kavanaugh, demonstrated their collective power at America's highest court on Thursday.

## In North Korea a packet of coffee costs $100, and that's a problem for Kim Jong Un
 - [https://www.cnn.com/2021/06/18/asia/north-korea-united-states-intl-hnk/index.html](https://www.cnn.com/2021/06/18/asia/north-korea-united-states-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 10:17:42+00:00

North Korean leader Kim Jong Un has bigger problems than the United States right now. He needs to feed his people, and his options are not good.

## Victoria's Secret is overhauling its image. Is it enough to regain relevance?
 - [https://www.cnn.com/style/article/victorias-secret-rebrand-vs-collective/index.html](https://www.cnn.com/style/article/victorias-secret-rebrand-vs-collective/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 10:11:16+00:00

Less than two years after Victoria's Secret pulled the plug on its star-studded annual fashion show, known for runway looks that combined strappy lingerie with enormous wings, the brand is retiring its supermodel "Angels" for good.

## Pornhub sued for allegedly serving nonconsensual sex videos
 - [https://www.cnn.com/2021/06/17/tech/pornhub-lawsuit-filed/index.html](https://www.cnn.com/2021/06/17/tech/pornhub-lawsuit-filed/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 09:36:25+00:00

Dozens of women sued Pornhub and its parent company Thursday, alleging that the site knowingly profited from videos depicting rape, child sexual exploitation, trafficking and other nonconsensual sexual content.

## The tragedy behind Italy's famous pasta dish
 - [https://www.cnn.com/travel/article/italy-amatriciana-pasta-amatrice-earthquake/index.html](https://www.cnn.com/travel/article/italy-amatriciana-pasta-amatrice-earthquake/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 08:49:51+00:00

What's Italy's best pasta sauce? That's the kind of question that can start a fight in the home of spaghetti and tortellini.

## A huge backlog at China's ports could spoil your holiday shopping this year
 - [https://www.cnn.com/2021/06/17/business/china-ports-global-supply-chain-intl-hnk/index.html](https://www.cnn.com/2021/06/17/business/china-ports-global-supply-chain-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 08:16:30+00:00

A coronavirus outbreak in southern China has clogged ports critical to global trade, causing a shipping backlog that could take months to clear and lead to shortages during the year-end holiday shopping season.

## Bear shot dead after attacking four people in residential area in Japan
 - [https://www.cnn.com/2021/06/18/asia/bear-japan-shot-dead-intl-hnk-scli/index.html](https://www.cnn.com/2021/06/18/asia/bear-japan-shot-dead-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 07:59:17+00:00

A brown bear was shot dead in northern Japan after tearing through a residential area on Friday and injuring four people, according to Japanese public broadcaster NHK.

## These communities remain at high risk for dangerous Covid-19 variants rapidly increasing in US, expert warns
 - [https://www.cnn.com/2021/06/17/health/us-coronavirus-thursday/index.html](https://www.cnn.com/2021/06/17/health/us-coronavirus-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 06:37:01+00:00

The country continued this week on a path to reopening from the Covid-19 pandemic, with major population centers such as New York and California pulling back on restrictions following increased vaccinations and lowered infections.

## Hundreds of vaccinated Indonesian health workers get Covid-19, dozens in hospital
 - [https://www.cnn.com/2021/06/18/asia/vaccinated-indonesian-doctors-covid-19-intl-hnk/index.html](https://www.cnn.com/2021/06/18/asia/vaccinated-indonesian-doctors-covid-19-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 06:30:46+00:00

More than 350 doctors and medical workers have caught Covid-19 in Indonesia despite being vaccinated with Sinovac, officials said, as concerns grow about the efficacy of some vaccines against more infectious variants.

## Iranians vote in an all but decided presidential election
 - [https://www.cnn.com/2021/06/18/middleeast/iran-election-voting-intl/index.html](https://www.cnn.com/2021/06/18/middleeast/iran-election-voting-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 05:38:43+00:00

Iranians have begun voting in a controversial presidential election that will likely deliver a hardline president who lost the 2017 election and has headed the country's judiciary for the last two years.

## The Republican Party's mission: whitewash the Trump presidency
 - [https://www.cnn.com/2021/06/18/politics/republicans-trump-january-6-whitewashing/index.html](https://www.cnn.com/2021/06/18/politics/republicans-trump-january-6-whitewashing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 04:38:34+00:00

The Republican Party has turned to another page in the authoritarian playbook as it whitewashes the history of Donald Trump's presidency.

## US Navy denies 2021 class president's request to play in NFL
 - [https://www.cnn.com/videos/us/2021/06/18/cameron-kinley-navy-nfl-dlt-intv-vpx.cnn](https://www.cnn.com/videos/us/2021/06/18/cameron-kinley-navy-nfl-dlt-intv-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 04:29:44+00:00

CNN's Don Lemon talks with Navy football team captain Cameron Kinley after the US Navy denied his request to delay his military service and try to play in the National Football League.

## Hear Putin offer rare praise for President Biden
 - [https://www.cnn.com/videos/world/2021/06/18/putin-praises-biden-geneva-summit-robertson-lkl-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2021/06/18/putin-praises-biden-geneva-summit-robertson-lkl-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 04:04:37+00:00

Speaking during a video conference meeting with graduates from Russia's Graduate School of Public Administration, Russian President Vladimir Putin praised his US counterpart Joe Biden, describing him as a "professional" who is "completely knowledgeable on all issues." CNN's Nic Robertson reports.

## Estonia is a leader on all things cyber. Now it's offering to teach other countries
 - [https://www.cnn.com/2021/06/18/tech/estonia-cyber-security-lessons-intl-cmd/index.html](https://www.cnn.com/2021/06/18/tech/estonia-cyber-security-lessons-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 04:00:21+00:00

When people like the German Chancellor Angela Merkel or the King of Belgium want to learn more about cybersecurity, they go to Estonia.

## New Nielsen data shows that cable TV reigns supreme, but streaming is gaining fast
 - [https://www.cnn.com/2021/06/17/media/nielsen-data-tv-reliable-sources/index.html](https://www.cnn.com/2021/06/17/media/nielsen-data-tv-reliable-sources/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 03:44:49+00:00

A version of this article first appeared in the "Reliable Sources" newsletter. You can sign up for free right here.

## America's new national holiday sets off scramble to shut down governments
 - [https://www.cnn.com/2021/06/17/politics/juneteenth-federal-holiday-government-shut-down/index.html](https://www.cnn.com/2021/06/17/politics/juneteenth-federal-holiday-government-shut-down/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 03:22:49+00:00

States across the country are scrambling to close their government offices Friday after President Joe Biden signed legislation establishing Juneteenth as a US federal holiday.

## The 30 most bizarre lines from Donald Trump's interview with Sean Hannity
 - [https://www.cnn.com/2021/06/17/politics/donald-trump-sean-hannity/index.html](https://www.cnn.com/2021/06/17/politics/donald-trump-sean-hannity/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 02:53:59+00:00

Out of office and having shut down his revolutionary communications site blog, former President Donald Trump has lost much of his ability to drive the daily national political conversation.

## 1 person dead and a dozen hurt after 8 shootings in metro Phoenix
 - [https://www.cnn.com/2021/06/17/us/arizona-shootings-victims/index.html](https://www.cnn.com/2021/06/17/us/arizona-shootings-victims/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 02:38:31+00:00

Police departments in communities northwest of Phoenix told CNN there were multiple shootings in the West Valley region Thursday afternoon.

## They work abroad to feed their families. Now they can't send the money home
 - [https://www.cnn.com/2021/06/17/asia/thailand-myanmar-migrant-workers-intl-hnk/index.html](https://www.cnn.com/2021/06/17/asia/thailand-myanmar-migrant-workers-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 02:36:21+00:00

Su Thandar Win shows a photo of her 7-year-old son on her phone and a proud smile instinctively spreads across her face. But it soon fades when she explains why she hasn't seen him for well over two years.

## Giant Buddhist goddess in Japan gets face mask to pray for end of Covid-19
 - [https://www.cnn.com/2021/06/17/asia/giant-buddhist-goddess-japan-face-mask-intl-hnk/index.html](https://www.cnn.com/2021/06/17/asia/giant-buddhist-goddess-japan-face-mask-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 02:09:00+00:00

Workers scaled a giant statue of a Buddhist goddess in Japan on Tuesday to place a custom-made mask on her face, an act meant to be a prayer for the end of the coronavirus pandemic.

## We now have a good sense of how big the 'Always Trump' caucus is in Congress
 - [https://www.cnn.com/2021/06/17/politics/juneteenth-congressional-gold-medal-electoral-college/index.html](https://www.cnn.com/2021/06/17/politics/juneteenth-congressional-gold-medal-electoral-college/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 02:06:00+00:00

In the five months since Donald Trump grudgingly left the White House, one of the central questions kicking around American politics is this: How big, exactly, is the group of pure "Always Trumpers" in Congress?

## American journalist appears in Myanmar court after weeks in detention
 - [https://www.cnn.com/2021/06/17/asia/danny-fenster-myanmar-detention-intl/index.html](https://www.cnn.com/2021/06/17/asia/danny-fenster-myanmar-detention-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 01:59:54+00:00

Danny Fenster, a US journalist who was detained in Myanmar over three weeks ago, has appeared at a court in Yangon according to Frontier Myanmar, the news publication Fenster works for as managing editor.

## Stray dog is unrecognizable after 6 pounds of hair is removed
 - [https://www.cnn.com/videos/business/2021/06/17/dog-stray-viral-haircut-moos-pkg-vpx.cnn](https://www.cnn.com/videos/business/2021/06/17/dog-stray-viral-haircut-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 01:23:46+00:00

What IS that creature? A stray Shih Tzu needed a haircut so badly you could barely tell it was a dog. But post-shave, CNN's Jeanne Moos reports, a star is born.

## Wolves chase performers in China during shocking live show, raising safety fears
 - [https://www.cnn.com/2021/06/17/china/china-wolves-stage-performance-intl-hnk-scli/index.html](https://www.cnn.com/2021/06/17/china/china-wolves-stage-performance-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 01:13:02+00:00

A video showing wolves chasing actors across the stage during a live show in China has raised alarm about the safety of the performers and audience.

## They were split by Covid for 8 months, until they found a street at the border
 - [https://www.cnn.com/travel/article/hong-kong-shenzhen-china-cross-border-love-pandemic-cmb/index.html](https://www.cnn.com/travel/article/hong-kong-shenzhen-china-cross-border-love-pandemic-cmb/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 01:08:08+00:00

For three years, Eleanor Liao and her boyfriend Aaron Leung lived about 12 miles away from each other. But the onset of the coronavirus pandemic made them feel like they were in a long-distance relationship.

## They supported Trump in the riot. Now they're running for office
 - [https://www.cnn.com/videos/politics/2021/06/17/capitol-january-6-running-for-office-murray-pkg-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2021/06/17/capitol-january-6-running-for-office-murray-pkg-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 01:03:09+00:00

CNN's Sara Murray takes a closer look at a number of people who were at the insurrection at the Capitol on January 6, and now claim they plan to run for office.

## South Korea Paralympic basketball team inspired by coach who died of cancer
 - [https://www.cnn.com/2021/06/17/sport/south-korea-paralympic-basketball-team-cmd-spt-intl/index.html](https://www.cnn.com/2021/06/17/sport/south-korea-paralympic-basketball-team-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-18 00:37:58+00:00

South Korean Han Sa-hyun lived and breathed basketball both as a player and a coach.

