# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## David Sinclair on How Fasting Can Help Fight Against Aging
 - [https://www.youtube.com/watch?v=cUwd-D94pzE](https://www.youtube.com/watch?v=cUwd-D94pzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-18 00:00:00+00:00

Taken from JRE #1670 w/David Sinclair:
https://open.spotify.com/episode/55UlxYWPfV46f7puMkZPeD?si=WBxKap8wSb-hUv-dV7Q2ig&dl_branch=1

## Modern Conveniences Are Making Us Weaker
 - [https://www.youtube.com/watch?v=T2RO4ytfW5w](https://www.youtube.com/watch?v=T2RO4ytfW5w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-18 00:00:00+00:00

Taken from JRE #1670 w/David Sinclair:
https://open.spotify.com/episode/55UlxYWPfV46f7puMkZPeD?si=WBxKap8wSb-hUv-dV7Q2ig&dl_branch=1

