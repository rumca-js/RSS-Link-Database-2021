# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Why OPPO and OnePlus have merged
 - [https://www.youtube.com/watch?v=YAvgPcXXSoI](https://www.youtube.com/watch?v=YAvgPcXXSoI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2021-06-18 00:00:00+00:00

Sponsored by Audible. Get your free trial and listen to The Psychology of Money or other books at https://www.audible.com/fridaycheckout 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► This video ◄◄◄

This week, OPPO and OnePlus announced a merger, Intel wanted to buy SiFive for its RISC-V chips and we got our first glimpse of Windows 11 through a leaked build.

Episode 51

Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd   
Quiz: https://link.crrowd.com/quiz   

This video on Nebula: https://nebula.app/videos/the-friday-checkout-why-are-oppo-oneplus-merging

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Other TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 


Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
https://discord.gg/npKQebe

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

Leica phone video (カメラのコムロ): https://youtu.be/qFv7hh1677M?t=212
Windows 11 video (Windows Central): https://www.youtube.com/watch?v=VMHgM_hTzlw&t=319s

0:00 Intro
0:33 Release Monitor
1:38 OPPO x OnePlus
3:49 Intel x SiFive
5:27 Windows 11

