# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## How Bitcoin Can Enable A Dictatorship
 - [https://www.youtube.com/watch?v=aogw71PXvvc](https://www.youtube.com/watch?v=aogw71PXvvc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2021-06-18 00:00:00+00:00

Is it possible that autocratic rulers could use Bitcoin's transparent blockchain to crack down on their citizen? The tool of financial liberation could also be a tool of power consolidation.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

El Salvador is on the verge of a historic change. The country now led by a social media crafty 39-year-old millennial is rewriting its history. While until now, El Salvador has been most well-known for its endless struggles with gang wars, it may soon become a Central American hub for digital revolution of the blockchain technology. From September this year, every business in El Salvador will have to accept bitcoin as a payment method. But will this actually deliver Salvadorans on the Bitcoin’s promise of financial freedom? Or will El Salvador’s president use Bitcoin to prop up his regime? 

Sources
El Salvador approves Bitcoi as a legal tendern:
https://www.reuters.com/world/americas/el-salvador-approves-first-law-bitcoin-legal-tender-2021-06-09/
https://www.reuters.com/technology/el-salvador-presidents-bitcoin-push-casts-shadow-over-imf-efforts-2021-06-07/
https://www.nytimes.com/2021/06/09/world/americas/salvador-bitcoin.html
https://arstechnica.com/tech-policy/2021/06/bitcoin-now-legal-tender-in-el-salvador-first-nation-to-adopt-cryptocurrency/
Bitcoin mining: https://www.reuters.com/technology/el-savador-exploring-volcanic-bitcoin-mining-bukele-says-2021-06-09/
https://www.coindesk.com/volcano-powered-bitcoin-mining-goes-from-twitter-idea-to-state-policy-in-el-salvador


El Salvador Britannica https://www.britannica.com/place/El-Salvador
https://www.britannica.com/place/El-Salvador/Economy
CIA on El Salvador https://www.cia.gov/the-world-factbook/countries/el-salvador/

El Salvador World Bank overview: https://www.worldbank.org/en/country/elsalvador/overview
El Salvador GDP https://data.worldbank.org/indicator/NY.GDP.MKTP.KD.ZG?end=2019&locations=SV&start=1966&view=chart
Unbanked Salvadorans: https://globalfindex.worldbank.org/sites/globalfindex/files/chapters/2017%20Findex%20full%20report_chapter2.pdf
Countries by remittance revenue: https://www.worldbank.org/en/topic/migrationremittancesdiasporaissues/brief/migration-remittances-data

Homicide rates: https://insightcrime.org/news/analysis/2020-homicide-round-up/
https://insightcrime.org/news/analysis/homicide-drop-el-salvador/
https://dataunodc.un.org/data/homicide/Homicide%20rate%20by%20sex

El Salvador pandemic response https://apnews.com/article/san-salvador-coronavirus-pandemic-el-salvador-1623416c0ddc7aa238911f8a422b6c8b
Human rights abuses: https://www.hrw.org/news/2020/04/15/el-salvador-police-abuses-covid-19-response

Nayib Bukele path to rule and how it threatens democracy in El Salvador
https://news.yahoo.com/el-salvadors-fa-ade-democracy-121836174.html
https://foreignpolicy.com/2021/05/12/central-america-rule-of-law-under-attack-el-salvador-nicaragua-guatemala-honduras/
https://www.aljazeera.com/news/2021/3/8/how-nayib-bukele-won-over-voters-unlikely-place
https://www.aljazeera.com/news/2021/2/27/el-salvador-elections-president-bukele-set-to-gain-more-control
https://www.latimes.com/world-nation/story/2021-05-16/nayib-bukele-the-most-popular-president-in-the-world-is-a-man-with-one-ideology-power
https://www.latimes.com/world-nation/story/2020-02-28/el-salvadors-bukele-reformer-or-autocrat
https://www.bloomberg.com/news/articles/2021-05-05/el-salvador-s-bukele-defends-firing-attorney-general-top-judges

Gangs in El Salvador
https://www.theguardian.com/world/2019/nov/22/el-salvador-a-nation-held-hostage-a-photo-essay

Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

