# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Ratchet & Clank: Rift Apart - Game Review
 - [https://www.youtube.com/watch?v=VpBrEWQAJEc](https://www.youtube.com/watch?v=VpBrEWQAJEc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-06-18 00:00:00+00:00

A new Ratchet & Clank game built exclusively for the PS%, to show off all the ray tracing & fast load times a dimensional shifting enthusiast could ask for. Here's my review for RATCHET & CLANK: RIFT APART!

#RatchetAndClank #RiftApart #PS5

