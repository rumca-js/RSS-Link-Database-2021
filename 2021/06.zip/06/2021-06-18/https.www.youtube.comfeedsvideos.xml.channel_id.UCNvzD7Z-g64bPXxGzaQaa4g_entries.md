# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 RIDICULOUS Things Gamers Did In VIDEO GAMES
 - [https://www.youtube.com/watch?v=8jkjbRJunSo](https://www.youtube.com/watch?v=8jkjbRJunSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-19 00:00:00+00:00

Sometimes when dedicated people truly love games they can achieve amazing things. Here are some more of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:
#10 https://kotaku.com/fans-have-translated-all-of-the-native-american-dialogu-1846903065

#9 https://www.reddit.com/r/gaming/comments/9u0loc/congrats_to_serral_for_making_gaming_history/
https://www.mlg.com/watch/usKjhtzXTtu/serral-is-the-first-non-korean-player-to-win-starcraft-wcs

#8
https://www.reddit.com/r/skyrim/comments/n9wtd0/it_is_finished_2201_peoplenpcs_plus_over_2400/

#7
https://kotaku.com/player-completes-grand-theft-auto-v-in-nine-hours-witho-1846922215


#6
https://gamerant.com/pokemon-fan-catches-every-shiny-in-franchise/

#5
https://kotaku.com/guy-beats-fallout-4-without-killing-anyone-nearly-brea-1749882569

#4
https://www.youtube.com/watch?v=NgnQI9pWvw4

#3
https://www.youtube.com/watch?v=cJtmZpRTVO8&t=0s

#2
https://rsplayers.fandom.com/wiki/Lynx_Titan

#1 https://www.youtube.com/watch?v=nh1FMznHfHw&list=PLwH1xJhcXG0ch67P-LJESEV6Cm-R_uOBD

## BETHESDA'S FINAL MESSAGE TO PS5 FANS, NEW SILENT HILL KOJIMA THEORY, & MORE
 - [https://www.youtube.com/watch?v=k5GbTeqZdB0](https://www.youtube.com/watch?v=k5GbTeqZdB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-18 00:00:00+00:00

For your chance to win a dream Gaming Rig setup worth $20k and support a great cause, go to https://www.omaze.com/gameranx. Thanks to Omaze for sponsoring this video.

Gameranx's E3 videos here: https://youtube.com/playlist?list=PLJAzFcYKyx4QBMgSXKieHNRU8zttGrk_l

Jake’s E3 reactions: https://youtu.be/dy0jrAFZVcw



Follow:
 Instagram: https://goo.gl/HH6mTW​​​​​​​

Twitter: https://bit.ly/3deMHW7​​​​​​​





 ~~~~STORIES~~~~


Bethesda 
https://www.videogameschronicle.com/news/bethesda-says-it-understands-playstation-fans-being-pissed-about-xbox-exclusivity/
interviews: https://www.youtube.com/watch?v=-ZM22Vmiths
https://www.telegraph.co.uk/gaming/news/starfield-director-todd-howard-exclusive-want-everybody-able/


Kojima
https://www.ign.com/articles/abandoned-kojima-silent-hill-mystery-ps5


https://www.reddit.com/r/TheBlueBoxConspiracy/comments/o1s5oy/here_are_all_the_possible_hints_that_blue_box/
 




FF7 coming to PC?
https://twitter.com/Wario64/status/1405803861441347586



Rockstar servers
https://twitter.com/RockstarSupport/status/1405161662861168646?s=20

Cyberpunk returns to PSN
https://www.theverge.com/2021/6/15/22457000/cd-projekt-red-cyberpunk-2077-playstation-store-return-bug-fixes
https://www.cyberpunk.net/en/news/38612/patch-1-23

