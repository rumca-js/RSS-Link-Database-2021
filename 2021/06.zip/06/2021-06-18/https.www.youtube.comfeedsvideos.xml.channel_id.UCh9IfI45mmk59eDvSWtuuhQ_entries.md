# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## How Is The Ocean A Real Thing?
 - [https://www.youtube.com/watch?v=Bg_9BpjvTF4](https://www.youtube.com/watch?v=Bg_9BpjvTF4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2021-06-18 00:00:00+00:00

Visit https://on.likewise.com/ryangeorge to download the LIKEWISE app and get amazing recommendations, 100% free!

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

