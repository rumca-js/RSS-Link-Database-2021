# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Dane medyczne Polaków będą transferowane do Niemiec! Powstaje pandemiczne centrum wywiadowcze.
 - [https://www.youtube.com/watch?v=lyVojfNzNRY](https://www.youtube.com/watch?v=lyVojfNzNRY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2021-06-19 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3zEsLIE
2. https://bit.ly/3iVe1yX
3. https://bit.ly/2SFFQRs
4. https://cnb.cx/3qePwia
5. https://bit.ly/3xz7vlL
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę ze stron:
gov.pl
http://bit.ly/2lVWjQr
---
flickr.com / itupictures
https://bit.ly/2x1EiGD
---------------------------------------------------------------
💡 Tagi: #WHO
--------------------------------------------------------------

