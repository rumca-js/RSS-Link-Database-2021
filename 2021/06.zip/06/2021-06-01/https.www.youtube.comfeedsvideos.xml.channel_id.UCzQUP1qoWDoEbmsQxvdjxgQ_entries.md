# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Scott Eastwood Talks About His Dad, Clint Eastwood
 - [https://www.youtube.com/watch?v=XZpzwXVmyws](https://www.youtube.com/watch?v=XZpzwXVmyws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2021-06-02 00:00:00+00:00

Taken from JRE #1659 w/Scott Eastwood:
https://open.spotify.com/episode/0iIlNKRBNTmRRYF7RNUnXU?si=OMm2hOE_TuGlMe8TxOk-iw

