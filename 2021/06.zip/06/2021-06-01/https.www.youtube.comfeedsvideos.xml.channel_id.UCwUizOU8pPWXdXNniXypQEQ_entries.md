# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Fauci - Public Enemy #1?
 - [https://www.youtube.com/watch?v=QH6-seSJMBo](https://www.youtube.com/watch?v=QH6-seSJMBo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2021-06-01 00:00:00+00:00

Grab your Red/Blue Light Teeth Whitening Kit at https://naturalteethwhiteners.com/jp

Check out my NEW MERCH here! - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Explore the investigation into is Fauci public enemy #1? The nations top infectious disease villain has a load of mounting evidence stacked against him. Take an in-depth look at his ties to the Wuhan lab and the virus in this video. You be the judge.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

