## Why are people talking about Dr Anthony Fauci's emails?
 - [https://www.bbc.com/news/world-us-canada-57336280](https://www.bbc.com/news/world-us-canada-57336280)
 - RSS feed: https://www.bbc.com
 - date published: 2021-06-01 11:41:11+00:00

Why are people talking about Dr Anthony Fauci's emails?

