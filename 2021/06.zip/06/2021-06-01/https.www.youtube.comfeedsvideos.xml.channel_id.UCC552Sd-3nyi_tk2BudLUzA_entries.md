# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The Truth About Vaccines
 - [https://www.youtube.com/watch?v=bVi-GlOY9iM](https://www.youtube.com/watch?v=bVi-GlOY9iM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2021-06-02 00:00:00+00:00

Viral videos show people with "magnetic arms" after a vaccine, so what is GOING ON!?
The Reason Conspiracy Theories Work: https://youtu.be/tfVgHRPC7Ao
PODCAST on OUR VACCINE JOURNEY: https://youtu.be/b5NRK2rQK6U

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Greg Brown
Edited by: Luka Šarlija

Are COVID Vaccines Causing Magnetism? Viral videos show people with magnetic arms after getting the COVID-19 vaccine. We explain the science behind what is going on, why needles scare people and how we come up with wild ways to justify our fear of needles. Billy Eilish got her vaccine in order to make her "lost cause" video, Logan Paul got it to fight, all your faves are getting it, but why are we still so scared? The Truth About Needles and Vaccines.

References: 
https://pubmed.ncbi.nlm.nih.gov/30109720/
https://pubmed.ncbi.nlm.nih.gov/19283260/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4900413/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4900415/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7774419/
https://pubmed.ncbi.nlm.nih.gov/4025517/
https://pubmed.ncbi.nlm.nih.gov/16894439/
https://pubmed.ncbi.nlm.nih.gov/33813931/
https://pubmed.ncbi.nlm.nih.gov/16460906/

