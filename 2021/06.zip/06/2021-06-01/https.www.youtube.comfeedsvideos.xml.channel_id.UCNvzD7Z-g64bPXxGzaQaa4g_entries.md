# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Far Cry 6: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=vjqd640_feE](https://www.youtube.com/watch?v=vjqd640_feE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-02 00:00:00+00:00

Far Cry 6 (PC, PS5, Xbox Series X/S, PS4, Xbox One) is releasing this fall. Here's everything we know about the game so far.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources and references:

Dev interview via JorRaptor : https://youtu.be/tZE9icWOiFg

https://www.youtube.com/watch?v=VbF6REQyel4

https://www.youtube.com/watch?v=UXf1-U-4KsU

https://www.gamesradar.com/far-cry-6-gameplay-reveal-ubisoft/

https://www.reddit.com/r/farcry/comments/nn3j87/yara_full_map/

Summary of JorRaptor interview with devs: https://www.reddit.com/r/farcry/comments/npbmgy/new_fc6_information_from_jorraptor/

## 10 E3 2021 Announcements That Would FREAK Us Out
 - [https://www.youtube.com/watch?v=7IdbmCddm1w](https://www.youtube.com/watch?v=7IdbmCddm1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2021-06-01 00:00:00+00:00

E3 2021 is right around the corner. Here are some big (maybe unrealistic) wishes of things we'd like to see.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

