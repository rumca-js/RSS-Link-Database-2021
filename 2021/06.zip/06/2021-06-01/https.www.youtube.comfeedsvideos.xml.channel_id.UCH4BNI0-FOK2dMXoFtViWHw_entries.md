# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## How Your Brain Makes Its Own Electricity
 - [https://www.youtube.com/watch?v=UZthGjcuTDs](https://www.youtube.com/watch?v=UZthGjcuTDs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2021-06-02 00:00:00+00:00

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
Follow me to Animal IQ: https://youtu.be/yPrQ3Pl-iEM  
↓↓↓ More info and sources below ↓↓↓

Here’s a thought: What IS a thought? I know it involves my brain, and my brain is made of neurons. And my brain’s neurons are listening to other neurons all over my body. But how do those neurons actually work? Maybe you’ve heard that it involves electricity, but does that mean you’ve got little zaps and lightning bolts running through your veins like Pikachu? Don’t worry, I’m here to set you straight on what a neuron is, what an action potential is, and how fast your nervous system really communicates.

Neuron spiker box from Backyard Brains (they didn’t sponsor this video in any way, but their kits are very educational!) https://backyardbrains.com/ 

References: https://sites.google.com/view/galvani-nerve-brain/home 

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

-----------

Special thanks to our Brain Trust Patrons:

Andrew Campbell 
Brian Chang
Roy Lasris
Javier Soto
dani bowman
David Johnston
Zenimal
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Benjamin Teinby
Eric Meer
Peter Ehrnstrom
Dustin
Marcus Tuepker
Karen Haskell
AlecZero

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

