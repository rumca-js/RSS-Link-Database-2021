# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## When Smartphones Copy Each Other!
 - [https://www.youtube.com/watch?v=ZS-LwWzlKdc](https://www.youtube.com/watch?v=ZS-LwWzlKdc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2021-06-02 00:00:00+00:00

It's okay to copy... as long as you copy the good stuff. Then we all win.

CuriosityStream: http://curiositystream.com/MKBHD

A ZTE Axon 30 Ultra review: https://www.theverge.com/22458629/zte-axon-30-ultra-review-screen-price-specs

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Smartphone Provided by ZTE for video.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

