# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: 'Halston' captures iconic fashion designer's life amid '70s excess
 - [https://www.youtube.com/watch?v=m_6JLR0gQec](https://www.youtube.com/watch?v=m_6JLR0gQec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2021-06-02 00:00:00+00:00

The Netflix miniseries "HALSTON" follows the legendary fashion designer (played by Ewan McGregor), as he turns his single, invented name into a worldwide fashion empire.

McGregor is "one of my favorite actors," Mary says. "He's completely fearless."

Mary says you don't even need to be into fashion to appreciate the story. "Just to see how McGregor portrays Halston through the sort of progression of his horrifying cocaine addiction and his claim to fame and people trying to take [his name] away from him," Mary explains. "Think about that: What is it like? Maybe that's sometimes all you feel like you have is your name.

"It's so worth watching."

"HALSTON" also features Krysta Rodriguez as Halston's muse, Liza Minelli. The series is directed by Daniel Minahan, and it is streaming now on Netflix.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#marylucia #halston #netflix

