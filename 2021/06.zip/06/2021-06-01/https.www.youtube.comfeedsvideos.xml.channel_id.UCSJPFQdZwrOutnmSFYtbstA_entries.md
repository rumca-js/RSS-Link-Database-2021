# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Cruella - Why?
 - [https://www.youtube.com/watch?v=erznXozQy-Q](https://www.youtube.com/watch?v=erznXozQy-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2021-06-01 00:00:00+00:00

Cruella is the movie no one asked for. But someone has to review it so you don't have to.

