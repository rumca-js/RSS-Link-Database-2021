# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Eydís Evensen - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=yffYqosBu7Q](https://www.youtube.com/watch?v=yffYqosBu7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-06-02 00:00:00+00:00

http://KEXP.ORG presents Eydís Evensen sharing a live performance recorded exclusively for KEXP and talking to DJ Alex, host of Pacific Notions on KEXP. Recorded May 19, 2021.

Songs:
Dagdraumur 
Wandering I
Fyrir Mikael
Midnight Moon (ft. GDRN)
Brotin
The Northern Sky

Session recorded at Hljóðriti Studios, Hafnafjörður, Iceland
Directed by Einar Egils
Cinematography by Einar Egils and Ívar Ívarsson
Recording engineered by Guðmundur Kristinn Jónsson, with Friðjón Jónsson 

Piano - Eydís Evensen
Vocals - GDRN
Violin - Viktor Orri Árnason
Violin - Vera Panitch
Viola - Guðbjartur Hákonarson
Cello - Hrafnhildur Marta Guðmundsdóttir

https://www.eydis-evensen.com
https://www.hljodriti.is
http://kexp.org

