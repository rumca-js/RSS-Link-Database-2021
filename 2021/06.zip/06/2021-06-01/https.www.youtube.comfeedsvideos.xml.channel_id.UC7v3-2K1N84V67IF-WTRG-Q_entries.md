# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Conjuring: The Devil Made Me Do It - Movie Review
 - [https://www.youtube.com/watch?v=ps08JllpMiY](https://www.youtube.com/watch?v=ps08JllpMiY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2021-06-01 00:00:00+00:00

We've Had many movies in the Conjuring universe. Now we get part 3 of the core lore....which sounds and feels like a spin off. Here's my review for THE CONJURING: THE DEVIL MADE ME DO IT!

#TheConjuring #TheConjuring3

