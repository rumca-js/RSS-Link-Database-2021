# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Belarusian activist stabs his throat during a court hearing in Minsk
 - [https://www.cnn.com/2021/06/01/europe/belarus-activist-stabs-himself-court-intl/index.html](https://www.cnn.com/2021/06/01/europe/belarus-activist-stabs-himself-court-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 23:55:19+00:00

A Belarusian activist stabbed his own throat during a court hearing in Minsk on Tuesday, according to local human rights watchdog Viasna 96.

## Amazon changes employee policies for time off, marijuana
 - [https://www.cnn.com/2021/06/01/tech/amazon-marijuana-time-off-task/index.html](https://www.cnn.com/2021/06/01/tech/amazon-marijuana-time-off-task/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 23:54:45+00:00

Amazon announced Tuesday it supports the federal legalization of marijuana, and that the company is revising a controversial workplace policy critics say has been used to keep employees working at a breakneck pace.

## US demands release of US journalist imprisoned in Myanmar
 - [https://www.cnn.com/videos/world/2021/06/01/fenster-myanmar-prison-lead-coren-pkg-vpx.cnn](https://www.cnn.com/videos/world/2021/06/01/fenster-myanmar-prison-lead-coren-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 22:34:13+00:00

The State Department has called on Myanmar's military regime to release Danny Fenster, an American journalist based in Myanmar who was detained earlier this week as he tried to board a flight out of the country. CNN's Anna Coren reports.

## Teen mistakenly stumbles into an Airbnb rented by ... cops
 - [https://www.cnn.com/videos/us/2021/06/01/teen-airbnb-police-home-milwaukee-vpx.hln](https://www.cnn.com/videos/us/2021/06/01/teen-airbnb-police-home-milwaukee-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 22:23:07+00:00

Three Montana sheriff's deputies woke up to an unexpected and uninvited overnight guest at their downtown Milwaukee Airbnb ... a teenager who wound up in the wrong house.

## Gunmen kill Ugandan minister's daughter and driver in 'targeted shooting'
 - [https://www.cnn.com/2021/06/01/africa/uganda-minister-shooting-intl/index.html](https://www.cnn.com/2021/06/01/africa/uganda-minister-shooting-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 22:00:25+00:00

The daughter of Ugandan government minister General Edward Katumba Wamala has been killed in a drive-by attack targeting the general outside his home in Kampala on Tuesday, Ugandan police said in a statement.

## Book excerpt alleges Hannity scripted Trump campaign ad
 - [https://www.cnn.com/videos/media/2021/06/01/brian-stelter-fox-news-hannity-trump-ad-nr-vpx.cnn](https://www.cnn.com/videos/media/2021/06/01/brian-stelter-fox-news-hannity-trump-ad-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 21:46:36+00:00

A new book about Trump's 2020 campaign claims Fox News host Sean Hannity scripted one of the campaign's TV ads that the campaign then paid Fox news to run.

## Harris to lead Biden administration's efforts on voting rights
 - [https://www.cnn.com/2021/06/01/politics/kamala-harris-voting-rights-biden/index.html](https://www.cnn.com/2021/06/01/politics/kamala-harris-voting-rights-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 21:33:03+00:00

President Joe Biden announced Vice President Kamala Harris will lead his administration's efforts on voting rights in a speech Tuesday on the Tulsa Race Massacre in Oklahoma.

## Biden admin. reverses Trump-era decision on oil and gas drilling in Arctic refuge
 - [https://www.cnn.com/2021/06/01/politics/oil-and-gas-arctic-leaders/index.html](https://www.cnn.com/2021/06/01/politics/oil-and-gas-arctic-leaders/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 20:50:02+00:00

The Biden administration plans to suspend oil and gas leases in the Arctic National Wildlife Refuge, a senior administration official confirmed Tuesday, undoing a move made by the Trump administration late last year.

## Vatican revises Church law on sexual abuse and other issues
 - [https://www.cnn.com/2021/06/01/world/pope-francis-catholic-church-law-intl/index.html](https://www.cnn.com/2021/06/01/world/pope-francis-catholic-church-law-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 20:27:14+00:00

Pope Francis on Tuesday issued the most extensive revision to Catholic Church law in four decades, insisting that bishops take action against clerics who abuse minors and vulnerable adults, commit fraud or attempt to ordain women.

## US actor joins pro-Kremlin Russian party
 - [https://www.cnn.com/videos/world/2021/06/01/steven-seagal-russian-political-party-nic-robertson-hala-gorani-hgt-vpx.cnn](https://www.cnn.com/videos/world/2021/06/01/steven-seagal-russian-political-party-nic-robertson-hala-gorani-hgt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 20:04:44+00:00

CNN's Nic Robertson reports that American-born action star Steven Seagal, who also has Russian citizenship, has joined the Russian political party "A Just Russia For Truth," which is a pro-Kremlin organization.

## Asparagus recipe found in legal database after 'hilarious' mistake
 - [https://www.cnn.com/2021/06/01/europe/asparagus-belgium-legal-scli-intl/index.html](https://www.cnn.com/2021/06/01/europe/asparagus-belgium-legal-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 16:30:15+00:00

Asparagus is known to be a traditional side dish of the Flemish people, so much so perhaps that a recipe for the delicious shoot has mistakenly appeared in a Belgian law database.

## See drone crash into erupting Icelandic volcano
 - [https://www.cnn.com/videos/travel/2021/06/01/drone-crash-iceland-volcano-lon-orig-mrg.cnn](https://www.cnn.com/videos/travel/2021/06/01/drone-crash-iceland-volcano-lon-orig-mrg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 13:35:20+00:00

A drone crashed into Fagradalsfjall volcano's molten lava, providing a mesmerizing close-up view into the erupting crater. Drone operator and YouTuber Joey Helms uploaded the video to YouTube on Wednesday.

## Avlon: Blocked January 6 commission a gut punch to democracy
 - [https://www.cnn.com/videos/politics/2021/06/01/reality-check-january-6-commission-democracy-avlon-newday-vpx.cnn](https://www.cnn.com/videos/politics/2021/06/01/reality-check-january-6-commission-democracy-avlon-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 12:34:19+00:00

US could do to defend democracy in the wake of Republican senators blocked the bipartisan January 6 commission to investigate the Capitol attack, CNN's John Avlon says its time to make changes to the Senate's filibuster rule.

## 'People-slayer' freed after 25 years
 - [https://www.cnn.com/2021/06/01/europe/giovanni-brusca-sicilian-mafia-release-intl/index.html](https://www.cnn.com/2021/06/01/europe/giovanni-brusca-sicilian-mafia-release-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 12:33:46+00:00

Sicilian Mafia turncoat Giovanni Brusca, the man who detonated the bomb that killed judge Giovanni Falcone in 1992, has been released from jail after serving a 25-year sentence, causing grief and anger among the relatives of those he killed.

## Curiosity rover spies colorful iridescent clouds on Mars
 - [https://www.cnn.com/2021/06/01/world/mars-colorful-clouds-curiosity-rover-scn/index.html](https://www.cnn.com/2021/06/01/world/mars-colorful-clouds-curiosity-rover-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 12:14:10+00:00

The Curiosity rover has witnessed a colorful marvel on Mars: Shining clouds.

## Greece's Mykonos says it's ready to party like before Covid
 - [https://www.cnn.com/travel/article/greece-covid-free-islands-mykonos-cmd/index.html](https://www.cnn.com/travel/article/greece-covid-free-islands-mykonos-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 10:29:47+00:00

In Greece's best-known party island, white houses, blue shutters and scarlet bougainvillea all glimmer in the sun.

## Analysis: The stakes are rising for Biden this summer
 - [https://www.cnn.com/2021/06/01/politics/president-joe-biden-agenda-summer/index.html](https://www.cnn.com/2021/06/01/politics/president-joe-biden-agenda-summer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2021-06-01 10:14:18+00:00

• 
•

