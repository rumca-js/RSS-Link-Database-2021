# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Top 5 Characters of 2021 (So Far)
 - [https://www.youtube.com/watch?v=ea2Oz6p2xJA](https://www.youtube.com/watch?v=ea2Oz6p2xJA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-06-02 00:00:00+00:00

Let's talk about some of my favorite characters of 2021 so far! 
BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1

## Mistborn In Fortnite🗡️ WoT Casting💃 Sean Bean GoT Reaction🤦 -Fantasy News
 - [https://www.youtube.com/watch?v=bJP4XaKHqMI](https://www.youtube.com/watch?v=bJP4XaKHqMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2021-06-01 00:00:00+00:00

LET'S JUMP INTO THE FANTASY NEWS!!! 
BREACH OF PEACE LINKS: 
Amazon: https://amzn.to/3kHsyNJ (physical/ebook)
Audible: https://www.audible.com/pd/B08Z8L7D5Q/?source_code=AUDFPWS0223189MWT-BK-ACX0-245468&ref=acx_bty_BK_ACX0_245468_rh_us
B&N: https://tinyurl.com/3df3c2p4 (physical/ebook)
Book Depository: https://tinyurl.com/2hds7euy (physical)
Google: https://tinyurl.com/abkh6mn6 (ebook)
Apple: https://tinyurl.com/rc994r8k (ebook)
Kobo: https://www.kobo.com/us/en/ebook/breach-of-peace-1 (ebook)

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene 
Podcast: https://afictionalconversation.podbean.com/

Equipment: 
Camera: https://amzn.to/3siqgHv 
Lense: https://amzn.to/3ugGxhQ 
Lighting: https://amzn.to/3aI3brK 
Microphone: https://amzn.to/3pCGtWg 
Tripod: https://amzn.to/3kd9yq1 

NEWS: 
00:00 Intro 

00:32 Disney Must Pay 

01:17 Wheel of Time Casting: https://www.wotseries.com/2021/05/26/miss-planet-czech-republic-in-the-wheel-of-time/ 

02:06 Ogres: https://rebellionpublishing.com/revealing-the-cover-for-ogres-by-adrian-tchaikovsky/ 

02:50 The Kingdom Must Fall: https://www.grimdarkmagazine.com/exclusive-cover-reveal-for-the-king-must-fall/ 

03:28 Discworld Hardbacks  complete: https://twitter.com/terryandrob/status/1398250447190827014 

04:15 Kelsier in #Fortnite: https://twitter.com/FortniteGame/status/1398066493447806981?s=19  

05:35 Brandon’s Book Review: https://www.youtube.com/watch?v=z7Ote6xLOlM&ab_channel=BrandonSanderson  

06:25 Percy Jackson Update: https://discussingfilm.net/2021/04/27/percy-jackson-disney-series-finds-co-writer-with-black-sails-creator-exclusive/ 

06:54 Sean Bean reaction: https://www.independent.co.uk/arts-entertainment/tv/news/sean-bean-game-of-thrones-b1856268.html 

07:51 Unreal Engine: https://www.youtube.com/watch?v=d1ZnM7CH-v4&ab_channel=UnrealEngine 

08:47 JJ Abrams Duh: https://twitter.com/DiscussingFilm/status/1397628778180923396

