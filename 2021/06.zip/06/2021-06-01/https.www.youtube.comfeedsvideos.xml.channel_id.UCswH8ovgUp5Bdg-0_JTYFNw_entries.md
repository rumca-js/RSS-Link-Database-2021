# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Crypto Crackdown: Can Bitcoin Be BANNED?
 - [https://www.youtube.com/watch?v=y54M11yWCoM](https://www.youtube.com/watch?v=y54M11yWCoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2021-06-02 00:00:00+00:00

Recently the price of Bitcoin was affected after China imposed fresh curbs on crypto-currencies. What does this mean for Bitcoin? I spoke to Youtuber Andrei Jikh about this here - a clip taken from the upcoming episode of my podcast Under The Skin - subscribe to Luminary at http://luminary.link/russell
#bitcoin #china #crypto #AndreiJikh

You can see more of Andrei Jikh on his channel here: https://www.youtube.com/channel/UCGy7SkBjcIAgTiwkXEtPnYg

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://luminary.link/russell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

My Audible Original, ‘Revelation', is out NOW!
US: 
http://adbl.co/revelation
UK: 
http://adbl.co/revelationuk
AU: 
http://adbl.co/revelationau
CA: 
http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Gareth Roy

