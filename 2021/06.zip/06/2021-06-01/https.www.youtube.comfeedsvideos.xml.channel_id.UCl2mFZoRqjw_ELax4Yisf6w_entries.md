# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Thank you. All of you. ❤️
 - [https://www.youtube.com/watch?v=jFebKYIyAO8](https://www.youtube.com/watch?v=jFebKYIyAO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-06-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://newyork.repair.org/ Email or call your senator. Let them know why Right to Repair matters. You know what to say.

## leaving NYC, getting started.
 - [https://www.youtube.com/watch?v=KRfu1MAshxg](https://www.youtube.com/watch?v=KRfu1MAshxg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2021-06-01 00:00:00+00:00

https://tinyurl.com/rossmatrix

