## Digital Identity: EU to lay out plans for Europe-wide digital identity wallet
 - [https://www.nfcw.com/2021/06/01/372591/eu-to-lay-out-plans-for-europe-wide-digital-identity-wallet/](https://www.nfcw.com/2021/06/01/372591/eu-to-lay-out-plans-for-europe-wide-digital-identity-wallet/)
 - RSS feed: www.nfcw.com
 - date published: 2021-06-01 12:59:16+00:00



