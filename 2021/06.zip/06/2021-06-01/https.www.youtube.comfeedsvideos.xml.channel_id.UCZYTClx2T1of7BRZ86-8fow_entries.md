# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Maybe Yawning Protects You From...Snakes?
 - [https://www.youtube.com/watch?v=ZYttn2jHjZ8](https://www.youtube.com/watch?v=ZYttn2jHjZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2021-06-01 00:00:00+00:00

Why is yawning contagious? It might be your body trying to keep on the lookout for snakes.

Hosted by: Rose Bear Don't Walk

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Silas Emrys, Drew Hart, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Christopher R Boucher, Eric Jensen, Adam Brainard, Nazara, GrowingViolet, Ash, Laura Sanborn, Sam Lutfi, Piya Shedden, KatieMarie Magnone, charles george, Alex Hackman, Chris Peters, Kevin Bealer, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources: 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2780782/
https://link.springer.com/article/10.1007/s10071-020-01462-4
https://www.sciencedirect.com/science/article/abs/pii/S0031938419302665 
https://www.nytimes.com/2019/02/22/well/live/why-do-we-yawn.html 
https://apps.who.int/bloodproducts/snakeantivenoms/database/

IMAGE SOURCES
https://www.storyblocks.com/video/stock/two-spinning-fans-inside-a-computer-case-closeup-hagwxnfizjfkzchjx
https://www.storyblocks.com/video/stock/black-man-yawning-at-workplace-tired-man-supporting-head-sitting-near-notebook-in-office-male-professional-falling-asleep-at-coworking-space-hfzhkmayhjxa6sfq0
https://www.storyblocks.com/video/stock/python-snake-in-rainforest-fern-tree---diamond-python-rsgevlmalj15z0zke

