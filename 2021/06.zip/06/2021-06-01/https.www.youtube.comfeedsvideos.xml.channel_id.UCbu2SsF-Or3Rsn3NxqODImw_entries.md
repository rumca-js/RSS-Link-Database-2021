# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## E3 2021 Hype, Speculation, What We Want To See | GameSpot After Dark
 - [https://www.youtube.com/watch?v=4_oClUXWwHI](https://www.youtube.com/watch?v=4_oClUXWwHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-01 00:00:00+00:00

In 2021, more so than any other year, it's difficult to predict what games and announcements will be made—but that won't stop the GameSpot After Dark team from trying. In this video Tamoor, Jean-Luc, Lucy, and AbleGamers' Steve Spohn discuss some of the things we can reasonably expect to see at the show, including Halo: Infinite, which is pretty much a dead cert for the Microsoft and Bethesda showcase. The team has a little fun with the prediction and try and come up with fun crossover opportunities they'd like to see. 

On top of that, there's the potential to see Gotham Knights and Suicide Squad from Warner Bros. Interactive Entertainment, but then again WB may be saving those for its DC Fandom event. For Square Enix's part, the next entry in the Final Fantasy series could make its return to the press conference stage. Other games the team would love to see are the Dragon Age and, if the announcement gods will it, the next Mass Effect. 

Tamoor, Jean-Luc, Lucy, and Steve also throw out some of their fantasy picks for what they want to see, which includes some expected but also very unexpected picks.

