# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ivy Sole - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=JZpo4cca1Rc](https://www.youtube.com/watch?v=JZpo4cca1Rc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-06-05 00:00:00+00:00

http://KEXP.ORG presents Ivy Sole performing live, recorded exclusively for KEXP.

Songs:
NAME IT
Rollercoaster
Dangerous
John Redcorn
HEAVY

Session recorded at the Paul Robeson House & Museum
DP - Jesse Bronstein
2nd Cam - Harold Milton-Gorvie
Editor and Colorist - Ethan Boye-Doe
Audio Engineer - Lee Clarke

Band:
Keybass - Kayla Childs
Keyboard - Max Hoenig
Guitar - Larry Monroe Jr.
Drums - Cam Cephas

Check out Ivy Sole's new single, Dangerous: https://www.youtube.com/watch?v=TbH9nLIm5pE

https://www.ivysole.com
https://www.paulrobesonhouse.org
http://kexp.org

## Ivy Sole - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=NimUy7cLWtU](https://www.youtube.com/watch?v=NimUy7cLWtU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2021-06-04 00:00:00+00:00

http://KEXP.ORG presents Ivy Sole sharing a live performance recorded exclusively for KEXP and talking to Gabriel Teodros, host of Early on KEXP. Recorded May 20, 2021.

Songs:
NAME IT
Rollercoaster
Dangerous
John Redcorn
HEAVY

Session recorded at the Paul Robeson House & Museum
DP - Jesse Bronstein
2nd Cam - Harold Milton-Gorvie
Editor and Colorist - Ethan Boye-Doe
Audio Engineer - Lee Clarke

Band:
Keybass - Kayla Childs
Keyboard - Max Hoenig
Guitar - Larry Monroe Jr.
Drums - Cam Cephas

Check out Ivy Sole's new single, Dangerous: https://www.youtube.com/watch?v=TbH9nLIm5pE

https://www.ivysole.com
https://www.paulrobesonhouse.org
http://kexp.org

