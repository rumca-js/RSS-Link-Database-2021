# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Firearms Expert Reacts To Battlefield: Bad Company 2’s Guns
 - [https://www.youtube.com/watch?v=UQ0T2cGOmJc](https://www.youtube.com/watch?v=UQ0T2cGOmJc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-05 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the insane weaponry of Battlefield: Bad Company 2, including the XM8 assault rifle, the AEK-971 assault rifle, and the iconic Carl Gustaf recoilless rifle.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down the guns of Battlefield: Bad Company 2, and compares them to their real-life counterparts.

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can purchase Jonathan’s book here - https://www.headstamppublishing.com/bullpup-rifle-book

## Guerrilla Collective 2021 Showcase
 - [https://www.youtube.com/watch?v=H_wuLg5gE3w](https://www.youtube.com/watch?v=H_wuLg5gE3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-05 00:00:00+00:00

The Guerrilla Collective is back for 2021! Guerrilla Collective is a digital games festival to reveal fresh announcements, trailers, gameplay, and more, bringing together some of the hottest developers and publishers around the world!

## Everything You Need To Know About E3 Week | Play For All Kickoff Show
 - [https://www.youtube.com/watch?v=EWVwq4v9m_k](https://www.youtube.com/watch?v=EWVwq4v9m_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-04 00:00:00+00:00

Help us raise money for AbleGamers: https://tiltify.com/@playforall2021/playforall2021

GameSpot's kicking off our summer gaming event, Play For All, by detailing everything you need you know about E3 and the many upcoming gaming events.

## History Of E3 (2021)
 - [https://www.youtube.com/watch?v=enrVDHSRwqE](https://www.youtube.com/watch?v=enrVDHSRwqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2021-06-04 00:00:00+00:00

Let's take a look back at the history of E3 and maybe laugh at all the dorky 90s outfits.

For the last two decades, some of the biggest gaming news and reveals have come during the Electronic Entertainment Expo or E3. the yearly video game industry trade show, where the newest titles and products are on full display. Many for the first time. But even though the show has drawn 10s of thousands of people to its convention centers every summer, the show itself has gone through a whole lot of changes during this 27 year-long run… well, 26 if you exclude the canceled one last year. So let's take a look back at the history of E3 and maybe laugh at all the dorky 90s outfits.

