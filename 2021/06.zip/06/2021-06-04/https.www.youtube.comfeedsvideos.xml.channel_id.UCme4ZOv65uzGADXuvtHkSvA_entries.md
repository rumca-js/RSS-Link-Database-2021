# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#237] Spychologia stosowana
 - [https://www.youtube.com/watch?v=g6ro4R6mtUs](https://www.youtube.com/watch?v=g6ro4R6mtUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-05 00:00:00+00:00

​@Langustanapalmie 

Niedzielny komentarz do czytań, czyli kazano do okienka
X Niedziela Zwykła, Rok B

1. czytanie (Rdz 3, 9-15)

Gdy Adam spożył z drzewa, Pan Bóg zawołał na niego i zapytał go: «Gdzie jesteś?»
On odpowiedział: «Usłyszałem Twój głos w ogrodzie, przestraszyłem się, bo jestem nagi, i ukryłem się». Rzekł Bóg: «Któż ci powiedział, że jesteś nagi? Czy może zjadłeś z drzewa, z którego ci zakazałem jeść?» Mężczyzna odpowiedział: «Niewiasta, którą postawiłeś przy mnie, dała mi owoc z tego drzewa i zjadłem». Wtedy Pan Bóg rzekł do niewiasty: «Dlaczego to uczyniłaś?»
Niewiasta odpowiedziała: «Wąż mnie zwiódł i zjadłam».
Wtedy Pan Bóg rzekł do węża: «Ponieważ to uczyniłeś, bądź przeklęty wśród wszystkich zwierząt domowych i dzikich; na brzuchu będziesz się czołgał i proch będziesz jadł po wszystkie dni twego istnienia. Wprowadzam nieprzyjaźń między ciebie a niewiastę, pomiędzy potomstwo twoje a potomstwo jej: ono ugodzi cię w głowę, a ty ugodzisz je w piętę».

2. czytanie (2 Kor 4, 13 – 5, 1)

Bracia: Mamy tego samego ducha wiary, według którego napisano: «Uwierzyłem, dlatego przemówiłem», my także wierzymy i dlatego mówimy, przekonani, że Ten, który wskrzesił Jezusa, z Jezusem przywróci życie także nam i stawi nas przed sobą razem z wami. Wszystko to bowiem dla was, ażeby łaska, obfitująca we wdzięczność wielu, pomnażała się Bogu na chwałę.
Dlatego to nie poddajemy się zwątpieniu, chociaż bowiem niszczeje nasz człowiek zewnętrzny, to jednak ten, który jest wewnątrz, odnawia się z dnia na dzień. Niewielkie bowiem utrapienia nasze obecnego czasu gotują bezmiar chwały przyszłego wieku dla nas, którzy się wpatrujemy nie w to, co widzialne, lecz w to, co niewidzialne. To bowiem, co widzialne, przemija, to zaś, co niewidzialne, trwa wiecznie.
Wiemy bowiem, że kiedy nawet zniszczeje nasz przybytek doczesnego zamieszkania, będziemy mieli mieszkanie od Boga, dom nie ręką uczyniony, lecz wiecznie trwały w niebie.

Ewangelia (Mk 3, 20-35)

Jezus przyszedł z uczniami swoimi do domu, a tłum znów się zbierał, tak że nawet posilić się nie mogli. Gdy to posłyszeli Jego bliscy, wybrali się, żeby Go powstrzymać. Mówiono bowiem: «Odszedł od zmysłów». A uczeni w Piśmie, którzy przyszli z Jerozolimy, mówili: «Ma Belzebuba i mocą władcy złych duchów wyrzuca złe duchy». Wtedy przywołał ich do siebie i mówił im w przypowieściach: «Jak może Szatan wyrzucać Szatana? Jeśli jakieś królestwo jest wewnętrznie skłócone, takie królestwo nie może się ostać. I jeśli dom wewnętrznie jest skłócony, to taki dom nie będzie mógł się ostać. Jeśli więc Szatan powstał przeciw sobie i jest z sobą skłócony, to nie może się ostać, lecz koniec z nim. Nikt nie może wejść do domu mocarza i sprzęt mu zagrabić, jeśli mocarza wpierw nie zwiąże, i dopiero wtedy dom jego ograbi.
Zaprawdę, powiadam wam: Wszystkie grzechy i bluźnierstwa, których by się ludzie dopuścili, będą im odpuszczone. Kto by jednak zbluźnił przeciw Duchowi Świętemu, nigdy nie otrzyma odpuszczenia, lecz winien jest grzechu wiecznego». Mówili bowiem: «Ma ducha nieczystego».
Tymczasem nadeszła Jego Matka i bracia i stojąc na dworze, posłali po Niego, aby Go przywołać.
A tłum ludzi siedział wokół Niego, gdy Mu powiedzieli: «Oto Twoja Matka i bracia na dworze szukają Ciebie». Odpowiedział im: «Któż jest moją matką i którzy są moimi braćmi?»
I spoglądając na siedzących dokoła Niego, rzekł: «Oto moja matka i moi bracia. Bo kto pełni wolę Bożą, ten jest Mi bratem, siostrą i matką».
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Historie potłuczone [37] O Damianie, co nauczył się prosić
 - [https://www.youtube.com/watch?v=k8Ucl6uC-B0](https://www.youtube.com/watch?v=k8Ucl6uC-B0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-05 00:00:00+00:00

@Langustanapalmie  #historiepotluczone

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, https://freemusicarchive.org/music/Kai_Engel/Sustains/Kai_Engel_-_Sustains_-_01_Brand_New_World
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Ghost of Tsushima [23] Wprowadzaj ideały w życie
 - [https://www.youtube.com/watch?v=Zr1GXYeKonQ](https://www.youtube.com/watch?v=Zr1GXYeKonQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-05 00:00:00+00:00

@langustanapalmie #ksiadzgrawgre #GhostOfTsushima
-------------------------------------------------------
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Miniaturkę stworzył: Sebastian Gwóźdź

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Rodzaju || Rozdział 39
 - [https://www.youtube.com/watch?v=gkrvLJ2ZsOo](https://www.youtube.com/watch?v=gkrvLJ2ZsOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-05 00:00:00+00:00

UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#803] Cisza
 - [https://www.youtube.com/watch?v=BOCVk-zX-Gc](https://www.youtube.com/watch?v=BOCVk-zX-Gc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-05 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: The Last of Us [14] Decyzje niemożliwe
 - [https://www.youtube.com/watch?v=QW7Y2sbiexw](https://www.youtube.com/watch?v=QW7Y2sbiexw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-04 00:00:00+00:00

@langustanapalmie #ksiadzgrawgre #TheLastOfUs
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Rodzaju || Rozdział 38
 - [https://www.youtube.com/watch?v=5mTUok3ImUc](https://www.youtube.com/watch?v=5mTUok3ImUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-04 00:00:00+00:00

UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Oglądaj Langustę w Aplikacji dominikanie.pl
→ http://bit.ly/dominikanienaGoogle
→ http://apple.co/2LqWqAx

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#802] Skracanie
 - [https://www.youtube.com/watch?v=kcdx6ilTsec](https://www.youtube.com/watch?v=kcdx6ilTsec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2021-06-04 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

