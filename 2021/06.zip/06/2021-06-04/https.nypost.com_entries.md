## Who is Peter Daszak, the nonprofit exec who sent taxpayer money to Wuhan lab?
 - [https://nypost.com/2021/06/04/who-is-peter-daszak-exec-who-sent-taxpayer-money-to-wuhan-lab/](https://nypost.com/2021/06/04/who-is-peter-daszak-exec-who-sent-taxpayer-money-to-wuhan-lab/)
 - RSS feed: https://nypost.com
 - date published: 2021-06-04 07:17:33+00:00

Who is Peter Daszak, the nonprofit exec who sent taxpayer money to Wuhan lab?

