# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## I travelled 3000 miles to try FarCry VR so you don't have to
 - [https://www.youtube.com/watch?v=HZ2AtcKpLzU](https://www.youtube.com/watch?v=HZ2AtcKpLzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2021-06-05 00:00:00+00:00

Hello! I got to travel all the way to Reno, NV to try out Ubisoft's new FarCry VR game. At the zero latency location based in the Gran Sierra hotel I got to sit down and talk with a representative from the company to explain the technology, pros and cons of location based VR and also play quite a few sessions of FarCry VR. Here's everything about it and my proposed future of free roam location based VR. This was such a fun video and I got to do it with a good friend, LSToast. Hopefully you enjoy it!


Val VR Esports made this happen, thank them for this. They're doing a $300 giveaway for this event, all you have to do is enter through Gleam:
https://gleam.io/competitions/SB1eF-thrillseeker-zero-latency-vr-300-contest 


My links:
2nd Channel:
https://youtu.be/Xp-p5RGoGpM
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill


Sources:

